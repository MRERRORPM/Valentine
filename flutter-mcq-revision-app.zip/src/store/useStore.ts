// ============================================================
// ZUSTAND GLOBAL STORE — Equivalent to Riverpod providers
// Clean architecture with separate slices
// ============================================================

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { v4 as uuidv4 } from 'uuid';
import {
  User, MCQ, UserProgress, QuizSession, DashboardStats,
  FilterState, ConfidenceLevel, RevisionMode, ExamCategory,
  UserSettings, AppNotification
} from '../types';
import { SAMPLE_MCQS } from '../data/sampleMCQs';
import {
  updateProgressAfterAnswer, generateRevisionQueue,
  calculateStreak, isDueToday
} from '../engine/spacedRepetition';

// ── Default Settings ──────────────────────────────────────────
const DEFAULT_SETTINGS: UserSettings = {
  darkMode: false,
  dailyGoal: 20,
  notificationsEnabled: true,
  timerEnabled: false,
  showExplanationImmediately: false,
  shuffleOptions: false,
};

const DEFAULT_FILTER: FilterState = {
  subject: '',
  topic: '',
  difficulty: 'all',
  source: 'all',
  examCategory: 'ALL',
  confidenceLevel: 'all',
  isBookmarked: false,
  isDueToday: false,
  searchQuery: '',
  tags: [],
};

// ── Store Interface ───────────────────────────────────────────
interface AppState {
  // Auth
  user: User | null;
  isAuthenticated: boolean;

  // MCQ Database
  mcqs: MCQ[];

  // User Progress (MCQ ID -> Progress)
  progressMap: Record<string, UserProgress>;

  // Sessions
  sessions: QuizSession[];

  // Active Quiz
  activeSession: QuizSession | null;
  activeQuestionIndex: number;
  sessionTimer: number;

  // UI State
  currentPage: string;
  darkMode: boolean;
  sidebarOpen: boolean;
  filterState: FilterState;

  // Notifications
  notifications: AppNotification[];

  // Actions — Auth
  login: (email: string, password: string) => Promise<boolean>;
  signup: (name: string, email: string, password: string, exam: ExamCategory) => Promise<boolean>;
  logout: () => void;
  updateSettings: (settings: Partial<UserSettings>) => void;

  // Actions — Navigation
  setCurrentPage: (page: string) => void;
  toggleDarkMode: () => void;
  toggleSidebar: () => void;

  // Actions — MCQ
  addMCQ: (mcq: Omit<MCQ, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateMCQ: (id: string, updates: Partial<MCQ>) => void;
  deleteMCQ: (id: string) => void;
  bulkImportMCQs: (mcqs: Omit<MCQ, 'id' | 'createdAt' | 'updatedAt'>[]) => void;

  // Actions — Progress
  markAnswer: (mcqId: string, isCorrect: boolean, confidence: ConfidenceLevel, timeSpent: number) => void;
  toggleBookmark: (mcqId: string) => void;

  // Actions — Quiz Session
  startSession: (mode: RevisionMode, options?: { subject?: string; topic?: string; examCategory?: ExamCategory; limit?: number }) => void;
  nextQuestion: () => void;
  prevQuestion: () => void;
  answerQuestion: (optionIndex: number) => void;
  markConfidence: (confidence: ConfidenceLevel) => void;
  completeSession: () => void;
  abandonSession: () => void;

  // Actions — Filter
  setFilter: (updates: Partial<FilterState>) => void;
  resetFilter: () => void;

  // Computed
  getFilteredMCQs: () => MCQ[];
  getDashboardStats: () => DashboardStats;
  getDueTodayCount: () => number;
  getProgressForMCQ: (mcqId: string) => UserProgress | null;

  // Admin
  isAdmin: () => boolean;

  // Notifications
  addNotification: (notif: Omit<AppNotification, 'id' | 'createdAt'>) => void;
  markNotificationRead: (id: string) => void;
  clearAllNotifications: () => void;
}

// ── Demo Users ────────────────────────────────────────────────
const DEMO_USERS: (User & { password: string })[] = [
  {
    id: 'user-001',
    email: 'student@medrevise.in',
    password: 'student123',
    name: 'Priya Sharma',
    examTarget: 'NORCET',
    role: 'student',
    createdAt: '2024-01-01T00:00:00Z',
    settings: DEFAULT_SETTINGS,
  },
  {
    id: 'admin-001',
    email: 'admin@medrevise.in',
    password: 'admin123',
    name: 'Dr. Admin',
    examTarget: 'ALL',
    role: 'admin',
    createdAt: '2024-01-01T00:00:00Z',
    settings: { ...DEFAULT_SETTINGS, darkMode: true },
  },
];

// ── Zustand Store ─────────────────────────────────────────────
export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      // ── Initial State ─────────────────────────────────────
      user: null,
      isAuthenticated: false,
      mcqs: SAMPLE_MCQS,
      progressMap: {},
      sessions: [],
      activeSession: null,
      activeQuestionIndex: 0,
      sessionTimer: 0,
      currentPage: 'dashboard',
      darkMode: false,
      sidebarOpen: true,
      filterState: DEFAULT_FILTER,
      notifications: [],

      // ── Auth Actions ──────────────────────────────────────
      login: async (email, password) => {
        const user = DEMO_USERS.find(
          (u) => u.email === email && u.password === password
        );
        if (user) {
          const { password: _p, ...userData } = user;
          set({ user: userData, isAuthenticated: true, darkMode: userData.settings.darkMode });
          return true;
        }
        return false;
      },

      signup: async (name, email, _password, examTarget) => {
        const newUser: User = {
          id: uuidv4(),
          email,
          name,
          examTarget,
          role: 'student',
          createdAt: new Date().toISOString(),
          settings: DEFAULT_SETTINGS,
        };
        set({ user: newUser, isAuthenticated: true });
        return true;
      },

      logout: () =>
        set({
          user: null,
          isAuthenticated: false,
          activeSession: null,
          currentPage: 'dashboard',
        }),

      updateSettings: (settings) =>
        set((state) => {
          if (!state.user) return state;
          const updatedUser = {
            ...state.user,
            settings: { ...state.user.settings, ...settings },
          };
          return {
            user: updatedUser,
            darkMode: updatedUser.settings.darkMode,
          };
        }),

      // ── Navigation ────────────────────────────────────────
      setCurrentPage: (page) => set({ currentPage: page }),
      toggleDarkMode: () =>
        set((state) => {
          const dark = !state.darkMode;
          if (state.user) {
            return {
              darkMode: dark,
              user: {
                ...state.user,
                settings: { ...state.user.settings, darkMode: dark },
              },
            };
          }
          return { darkMode: dark };
        }),
      toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),

      // ── MCQ Actions ───────────────────────────────────────
      addMCQ: (mcqData) => {
        const mcq: MCQ = {
          ...mcqData,
          id: uuidv4(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        set((s) => ({ mcqs: [...s.mcqs, mcq] }));
      },

      updateMCQ: (id, updates) =>
        set((s) => ({
          mcqs: s.mcqs.map((m) =>
            m.id === id ? { ...m, ...updates, updatedAt: new Date().toISOString() } : m
          ),
        })),

      deleteMCQ: (id) =>
        set((s) => ({
          mcqs: s.mcqs.filter((m) => m.id !== id),
        })),

      bulkImportMCQs: (mcqsData) => {
        const newMCQs: MCQ[] = mcqsData.map((data) => ({
          ...data,
          id: uuidv4(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        }));
        set((s) => ({ mcqs: [...s.mcqs, ...newMCQs] }));
      },

      // ── Progress Actions ──────────────────────────────────
      markAnswer: (mcqId, isCorrect, confidence, timeSpent) => {
        const state = get();
        if (!state.user) return;
        const existing = state.progressMap[mcqId] ?? null;
        const updated = updateProgressAfterAnswer(
          existing, mcqId, state.user.id, isCorrect, confidence, timeSpent
        );
        set((s) => ({
          progressMap: { ...s.progressMap, [mcqId]: updated },
        }));
      },

      toggleBookmark: (mcqId) => {
        const state = get();
        if (!state.user) return;
        const existing = state.progressMap[mcqId];
        if (existing) {
          set((s) => ({
            progressMap: {
              ...s.progressMap,
              [mcqId]: {
                ...existing,
                isBookmarked: !existing.isBookmarked,
                updatedAt: new Date().toISOString(),
              },
            },
          }));
        } else {
          // Create new progress record just for bookmark
          const now = new Date().toISOString();
          const newProgress: UserProgress = {
            id: uuidv4(),
            userId: state.user.id,
            mcqId,
            confidenceLevel: 'unseen',
            lastReviewedAt: now,
            nextReviewAt: now,
            reviewCount: 0,
            correctCount: 0,
            wrongCount: 0,
            isBookmarked: true,
            timeSpentSeconds: 0,
            createdAt: now,
            updatedAt: now,
          };
          set((s) => ({
            progressMap: { ...s.progressMap, [mcqId]: newProgress },
          }));
        }
      },

      // ── Quiz Session Actions ──────────────────────────────
      startSession: (mode, options = {}) => {
        const state = get();
        let mcqs = [...state.mcqs];

        // Apply filters
        if (options.subject) {
          mcqs = mcqs.filter((m) => m.subject === options.subject);
        }
        if (options.topic) {
          mcqs = mcqs.filter((m) => m.topic === options.topic);
        }
        if (options.examCategory && options.examCategory !== 'ALL') {
          mcqs = mcqs.filter(
            (m) => m.examCategory === options.examCategory || m.examCategory === 'ALL'
          );
        }

        const queue = generateRevisionQueue(
          mcqs,
          state.progressMap,
          mode,
          options.limit ?? 20
        );

        if (queue.length === 0) return;

        const session: QuizSession = {
          id: uuidv4(),
          userId: state.user?.id ?? 'guest',
          mode,
          subject: options.subject,
          topic: options.topic,
          examCategory: options.examCategory,
          mcqIds: queue.map((m) => m.id),
          answers: {},
          confidenceMarks: {},
          startedAt: new Date().toISOString(),
          totalTime: 0,
          score: 0,
          total: queue.length,
        };

        set({ activeSession: session, activeQuestionIndex: 0, currentPage: 'quiz' });
      },

      nextQuestion: () =>
        set((s) => {
          if (!s.activeSession) return s;
          const next = Math.min(
            s.activeQuestionIndex + 1,
            s.activeSession.mcqIds.length - 1
          );
          return { activeQuestionIndex: next };
        }),

      prevQuestion: () =>
        set((s) => ({
          activeQuestionIndex: Math.max(s.activeQuestionIndex - 1, 0),
        })),

      answerQuestion: (optionIndex) =>
        set((s) => {
          if (!s.activeSession) return s;
          const mcqId = s.activeSession.mcqIds[s.activeQuestionIndex];
          return {
            activeSession: {
              ...s.activeSession,
              answers: { ...s.activeSession.answers, [mcqId]: optionIndex },
            },
          };
        }),

      markConfidence: (confidence) =>
        set((s) => {
          if (!s.activeSession) return s;
          const mcqId = s.activeSession.mcqIds[s.activeQuestionIndex];
          return {
            activeSession: {
              ...s.activeSession,
              confidenceMarks: { ...s.activeSession.confidenceMarks, [mcqId]: confidence },
            },
          };
        }),

      completeSession: () => {
        const state = get();
        if (!state.activeSession) return;

        const mcqs = state.mcqs;
        const session = state.activeSession;
        let score = 0;

        // Calculate score and update progress
        for (const mcqId of session.mcqIds) {
          const mcq = mcqs.find((m) => m.id === mcqId);
          if (!mcq) continue;
          const answer = session.answers[mcqId];
          const confidence = session.confidenceMarks[mcqId] ?? 'confused';
          const isCorrect = answer === mcq.correctAnswer;
          if (isCorrect) score++;

          // Update progress for each answered question
          if (answer !== null && answer !== undefined) {
            const existing = state.progressMap[mcqId] ?? null;
            const updated = updateProgressAfterAnswer(
              existing, mcqId, session.userId, isCorrect, confidence, 30
            );
            state.progressMap[mcqId] = updated;
          }
        }

        const completedSession: QuizSession = {
          ...session,
          completedAt: new Date().toISOString(),
          score,
          total: session.mcqIds.length,
        };

        set((s) => ({
          sessions: [completedSession, ...s.sessions],
          activeSession: null,
          activeQuestionIndex: 0,
          progressMap: { ...state.progressMap },
          currentPage: 'results',
        }));
      },

      abandonSession: () =>
        set({ activeSession: null, activeQuestionIndex: 0, currentPage: 'dashboard' }),

      // ── Filter Actions ────────────────────────────────────
      setFilter: (updates) =>
        set((s) => ({ filterState: { ...s.filterState, ...updates } })),
      resetFilter: () => set({ filterState: DEFAULT_FILTER }),

      // ── Computed ──────────────────────────────────────────
      getFilteredMCQs: () => {
        const { mcqs, progressMap, filterState } = get();
        return mcqs.filter((mcq) => {
          if (filterState.subject && mcq.subject !== filterState.subject) return false;
          if (filterState.topic && mcq.topic !== filterState.topic) return false;
          if (filterState.difficulty !== 'all' && mcq.difficulty !== filterState.difficulty) return false;
          if (filterState.source !== 'all' && mcq.source !== filterState.source) return false;
          if (filterState.examCategory !== 'ALL' && mcq.examCategory !== filterState.examCategory && mcq.examCategory !== 'ALL') return false;
          if (filterState.confidenceLevel !== 'all') {
            const p = progressMap[mcq.id];
            const level = p?.confidenceLevel ?? 'unseen';
            if (level !== filterState.confidenceLevel) return false;
          }
          if (filterState.isBookmarked && !progressMap[mcq.id]?.isBookmarked) return false;
          if (filterState.isDueToday) {
            const p = progressMap[mcq.id];
            if (p && !isDueToday(p)) return false;
          }
          if (filterState.searchQuery) {
            const q = filterState.searchQuery.toLowerCase();
            if (
              !mcq.question.toLowerCase().includes(q) &&
              !mcq.subject.toLowerCase().includes(q) &&
              !mcq.topic.toLowerCase().includes(q) &&
              !mcq.tags.some((t) => t.toLowerCase().includes(q))
            )
              return false;
          }
          if (filterState.tags.length > 0) {
            if (!filterState.tags.some((t) => mcq.tags.includes(t))) return false;
          }
          return true;
        });
      },

      getDashboardStats: () => {
        const { mcqs, progressMap, sessions } = get();

        const totalSolved = Object.keys(progressMap).filter(
          (id) => (progressMap[id]?.reviewCount ?? 0) > 0
        ).length;

        const totalCorrect = Object.values(progressMap).reduce(
          (sum, p) => sum + (p?.correctCount ?? 0), 0
        );
        const totalWrong = Object.values(progressMap).reduce(
          (sum, p) => sum + (p?.wrongCount ?? 0), 0
        );

        const accuracy = totalSolved > 0
          ? Math.round((totalCorrect / (totalCorrect + totalWrong)) * 100)
          : 0;

        const dueToday = mcqs.filter((m) => {
          const p = progressMap[m.id];
          if (!p || p.confidenceLevel === 'unseen') return true;
          return isDueToday(p);
        }).length;

        const bookmarked = Object.values(progressMap).filter((p) => p?.isBookmarked).length;

        // Subject stats
        const subjectMap: Record<string, { total: number; correct: number; due: number }> = {};
        for (const mcq of mcqs) {
          if (!subjectMap[mcq.subject]) {
            subjectMap[mcq.subject] = { total: 0, correct: 0, due: 0 };
          }
          subjectMap[mcq.subject].total++;
          const p = progressMap[mcq.id];
          if (p) {
            subjectMap[mcq.subject].correct += p.correctCount;
            if (isDueToday(p)) subjectMap[mcq.subject].due++;
          }
        }

        const bySubject = Object.entries(subjectMap).map(([subject, data]) => ({
          subject,
          total: data.total,
          correct: data.correct,
          accuracy: data.total > 0 ? Math.round((data.correct / data.total) * 100) : 0,
          dueToday: data.due,
        })).sort((a, b) => a.accuracy - b.accuracy);

        // Weekly activity
        const weeklyActivity = Array.from({ length: 7 }, (_, i) => {
          const date = new Date();
          date.setDate(date.getDate() - (6 - i));
          const dateStr = date.toISOString().split('T')[0];
          const daySessions = sessions.filter(
            (s) => s.completedAt?.startsWith(dateStr)
          );
          return {
            date: dateStr,
            solved: daySessions.reduce((sum, s) => sum + s.total, 0),
            correct: daySessions.reduce((sum, s) => sum + s.score, 0),
          };
        });

        // Confidence breakdown
        const confidenceBreakdown = {
          easy: 0, confused: 0, wrong: 0, important: 0, unseen: 0,
        };
        for (const mcq of mcqs) {
          const level = progressMap[mcq.id]?.confidenceLevel ?? 'unseen';
          confidenceBreakdown[level]++;
        }

        return {
          totalSolved,
          totalCorrect,
          totalWrong,
          accuracy,
          currentStreak: calculateStreak(sessions),
          longestStreak: calculateStreak(sessions),
          dueToday,
          bookmarked,
          bySubject,
          weeklyActivity,
          confidenceBreakdown,
          recentSessions: sessions.slice(0, 5),
        };
      },

      getDueTodayCount: () => {
        const { mcqs, progressMap } = get();
        return mcqs.filter((m) => {
          const p = progressMap[m.id];
          if (!p || p.confidenceLevel === 'unseen') return true;
          return isDueToday(p);
        }).length;
      },

      getProgressForMCQ: (mcqId) => {
        return get().progressMap[mcqId] ?? null;
      },

      isAdmin: () => get().user?.role === 'admin',

      // ── Notifications ─────────────────────────────────────
      addNotification: (notif) =>
        set((s) => ({
          notifications: [
            {
              ...notif,
              id: uuidv4(),
              createdAt: new Date().toISOString(),
            },
            ...s.notifications,
          ].slice(0, 50),
        })),

      markNotificationRead: (id) =>
        set((s) => ({
          notifications: s.notifications.map((n) =>
            n.id === id ? { ...n, isRead: true } : n
          ),
        })),

      clearAllNotifications: () => set({ notifications: [] }),
    }),
    {
      name: 'medrevise-storage',
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated,
        progressMap: state.progressMap,
        sessions: state.sessions,
        mcqs: state.mcqs,
        darkMode: state.darkMode,
        notifications: state.notifications,
      }),
    }
  )
);
