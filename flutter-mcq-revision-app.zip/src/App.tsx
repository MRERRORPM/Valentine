// ============================================================
// MAIN APP — MedRevise Pro
// Flutter-equivalent app shell with routing and layout
// ============================================================

import React, { useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import { AnimatePresence, motion } from 'framer-motion';

// Store
import { useStore } from './store/useStore';

// Screens
import { AuthScreen } from './screens/AuthScreen';
import { DashboardScreen } from './screens/DashboardScreen';
import { QuizScreen } from './screens/QuizScreen';
import { ResultsScreen } from './screens/ResultsScreen';
import { QuestionBankScreen } from './screens/QuestionBankScreen';
import { AnalyticsScreen } from './screens/AnalyticsScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { AdminScreen } from './screens/AdminScreen';
import { NotificationsScreen } from './screens/NotificationsScreen';
import { RevisionModesScreen } from './screens/RevisionModesScreen';

// Components
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';

const PAGE_MAP: Record<string, React.FC> = {
  dashboard: DashboardScreen,
  quiz: QuizScreen,
  results: ResultsScreen,
  'question-bank': QuestionBankScreen,
  analytics: AnalyticsScreen,
  settings: SettingsScreen,
  admin: AdminScreen,
  notifications: NotificationsScreen,
  revision: RevisionModesScreen,
  bookmarks: QuestionBankScreen,
};

const AppLayout: React.FC = () => {
  const { currentPage, filterState, setFilter } = useStore();

  // When navigating to bookmarks, set bookmark filter
  useEffect(() => {
    if (currentPage === 'bookmarks') {
      setFilter({ isBookmarked: true });
    } else if (currentPage === 'question-bank' && filterState.isBookmarked) {
      setFilter({ isBookmarked: false });
    }
  }, [currentPage]);

  const PageComponent = PAGE_MAP[currentPage] ?? DashboardScreen;

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50 dark:bg-slate-900">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header — hide on full-screen quiz */}
        {currentPage !== 'quiz' && <Header />}

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentPage}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              <PageComponent />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
};

function App() {
  const { isAuthenticated, darkMode } = useStore();

  // Apply dark mode class to <html>
  useEffect(() => {
    const html = document.documentElement;
    if (darkMode) {
      html.classList.add('dark');
    } else {
      html.classList.remove('dark');
    }
  }, [darkMode]);

  return (
    <div className={darkMode ? 'dark' : ''}>
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            borderRadius: '12px',
            fontFamily: 'Inter, sans-serif',
            fontSize: '14px',
            background: darkMode ? '#1e293b' : '#ffffff',
            color: darkMode ? '#f1f5f9' : '#0f172a',
            border: `1px solid ${darkMode ? '#334155' : '#e2e8f0'}`,
          },
          success: {
            iconTheme: {
              primary: '#6366f1',
              secondary: '#ffffff',
            },
          },
        }}
      />

      <AnimatePresence mode="wait">
        {!isAuthenticated ? (
          <motion.div
            key="auth"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <AuthScreen />
          </motion.div>
        ) : (
          <motion.div
            key="app"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="h-screen"
          >
            <AppLayout />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;
