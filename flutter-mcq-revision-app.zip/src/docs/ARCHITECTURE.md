# MedRevise Pro — Architecture Documentation

## 🏗️ Architecture Overview

This is a **React/Web implementation** of the Flutter + Supabase MCQ revision app,
implementing identical clean architecture patterns:

```
Flutter/Dart          →    React/TypeScript
Riverpod Provider     →    Zustand Store
Hive/SQLite           →    LocalStorage (via Zustand persist)
Supabase Auth         →    Demo auth (ready for Supabase SDK)
Clean Architecture    →    Feature-based folder structure
```

---

## 📁 Folder Structure

```
src/
├── types/          # Domain models (equivalent to Dart models)
│   └── index.ts   # MCQ, UserProgress, QuizSession, etc.
│
├── data/           # Static data & seed
│   └── sampleMCQs.ts   # 50+ production MCQs with explanations
│
├── engine/         # Business logic (pure functions)
│   └── spacedRepetition.ts  # SM-2 spaced repetition algorithm
│
├── store/          # State management (Zustand = Riverpod)
│   └── useStore.ts  # Global app state with persistence
│
├── screens/        # Feature screens (Flutter Screens)
│   ├── AuthScreen.tsx
│   ├── DashboardScreen.tsx
│   ├── QuizScreen.tsx
│   ├── ResultsScreen.tsx
│   ├── QuestionBankScreen.tsx
│   ├── AnalyticsScreen.tsx
│   ├── RevisionModesScreen.tsx
│   ├── NotificationsScreen.tsx
│   ├── SettingsScreen.tsx
│   └── AdminScreen.tsx
│
├── components/     # Reusable widgets (Flutter Widgets)
│   ├── Sidebar.tsx
│   └── Header.tsx
│
└── docs/           # Documentation
    └── ARCHITECTURE.md
```

---

## 🗄️ Supabase PostgreSQL Schema

```sql
-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── MCQs Table ──────────────────────────────────────────────
CREATE TABLE mcqs (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  question        TEXT NOT NULL,
  options         JSONB NOT NULL,  -- [string, string, string, string]
  correct_answer  SMALLINT NOT NULL CHECK (correct_answer BETWEEN 0 AND 3),
  explanation     TEXT NOT NULL,
  subject         VARCHAR(100) NOT NULL,
  topic           VARCHAR(100) NOT NULL,
  tags            TEXT[] DEFAULT '{}',
  difficulty      VARCHAR(10) NOT NULL CHECK (difficulty IN ('easy', 'medium', 'hard')),
  source          VARCHAR(20) NOT NULL,
  exam_category   VARCHAR(20) NOT NULL,
  image_url       TEXT,
  year            SMALLINT,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for fast filtering
CREATE INDEX idx_mcqs_subject ON mcqs(subject);
CREATE INDEX idx_mcqs_topic ON mcqs(topic);
CREATE INDEX idx_mcqs_difficulty ON mcqs(difficulty);
CREATE INDEX idx_mcqs_exam_category ON mcqs(exam_category);
CREATE INDEX idx_mcqs_source ON mcqs(source);
CREATE INDEX idx_mcqs_tags ON mcqs USING GIN(tags);

-- ── User Progress Table ──────────────────────────────────────
CREATE TABLE user_progress (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id             UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  mcq_id              UUID NOT NULL REFERENCES mcqs(id) ON DELETE CASCADE,
  confidence_level    VARCHAR(20) NOT NULL DEFAULT 'unseen'
                      CHECK (confidence_level IN ('easy', 'confused', 'wrong', 'important', 'unseen')),
  last_reviewed_at    TIMESTAMPTZ DEFAULT NOW(),
  next_review_at      TIMESTAMPTZ DEFAULT NOW(),
  review_count        INTEGER DEFAULT 0,
  correct_count       INTEGER DEFAULT 0,
  wrong_count         INTEGER DEFAULT 0,
  is_bookmarked       BOOLEAN DEFAULT FALSE,
  time_spent_seconds  INTEGER DEFAULT 0,
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, mcq_id)
);

-- Indexes for revision queries
CREATE INDEX idx_progress_user_id ON user_progress(user_id);
CREATE INDEX idx_progress_mcq_id ON user_progress(mcq_id);
CREATE INDEX idx_progress_confidence ON user_progress(confidence_level);
CREATE INDEX idx_progress_next_review ON user_progress(next_review_at);
CREATE INDEX idx_progress_bookmarked ON user_progress(is_bookmarked) WHERE is_bookmarked = true;

-- ── Quiz Sessions Table ──────────────────────────────────────
CREATE TABLE quiz_sessions (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  mode            VARCHAR(20) NOT NULL,
  subject         VARCHAR(100),
  topic           VARCHAR(100),
  exam_category   VARCHAR(20),
  mcq_ids         UUID[] NOT NULL,
  answers         JSONB DEFAULT '{}',  -- {mcq_id: option_index}
  confidence_marks JSONB DEFAULT '{}', -- {mcq_id: confidence_level}
  started_at      TIMESTAMPTZ DEFAULT NOW(),
  completed_at    TIMESTAMPTZ,
  total_time      INTEGER DEFAULT 0,  -- seconds
  score           INTEGER DEFAULT 0,
  total           INTEGER NOT NULL,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sessions_user_id ON quiz_sessions(user_id);
CREATE INDEX idx_sessions_completed ON quiz_sessions(completed_at);
CREATE INDEX idx_sessions_mode ON quiz_sessions(mode);

-- ── User Profiles Table ──────────────────────────────────────
CREATE TABLE user_profiles (
  id              UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name            VARCHAR(200) NOT NULL,
  exam_target     VARCHAR(20) DEFAULT 'NORCET',
  role            VARCHAR(20) DEFAULT 'student' CHECK (role IN ('student', 'admin')),
  settings        JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── Row Level Security (RLS) ─────────────────────────────────
ALTER TABLE mcqs ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE quiz_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- MCQs: anyone authenticated can read
CREATE POLICY "MCQs are readable by authenticated users"
  ON mcqs FOR SELECT USING (auth.role() = 'authenticated');

-- MCQs: only admins can insert/update/delete
CREATE POLICY "Only admins can modify MCQs"
  ON mcqs FOR ALL USING (
    auth.uid() IN (SELECT id FROM user_profiles WHERE role = 'admin')
  );

-- Progress: users can only CRUD their own progress
CREATE POLICY "Users manage own progress"
  ON user_progress FOR ALL USING (auth.uid() = user_id);

-- Sessions: users can only CRUD their own sessions
CREATE POLICY "Users manage own sessions"
  ON quiz_sessions FOR ALL USING (auth.uid() = user_id);

-- Profiles: users can read/update own profile
CREATE POLICY "Users manage own profile"
  ON user_profiles FOR ALL USING (auth.uid() = id);

-- ── Triggers ─────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER mcqs_updated_at BEFORE UPDATE ON mcqs
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER progress_updated_at BEFORE UPDATE ON user_progress
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ── Auto-create profile on signup ────────────────────────────
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO user_profiles (id, name, email)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'name', 'New User'),
    NEW.email
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();
```

---

## 📱 SQLite Schema (for Flutter offline)

```dart
// database/app_database.dart

final String createMCQsTable = '''
  CREATE TABLE mcqs (
    id TEXT PRIMARY KEY,
    question TEXT NOT NULL,
    option_a TEXT NOT NULL,
    option_b TEXT NOT NULL,
    option_c TEXT NOT NULL,
    option_d TEXT NOT NULL,
    correct_answer INTEGER NOT NULL,
    explanation TEXT NOT NULL,
    subject TEXT NOT NULL,
    topic TEXT NOT NULL,
    tags TEXT NOT NULL,  -- JSON encoded
    difficulty TEXT NOT NULL,
    source TEXT NOT NULL,
    exam_category TEXT NOT NULL,
    image_url TEXT,
    year INTEGER,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    is_synced INTEGER DEFAULT 1  -- 0 = pending sync
  )
''';

final String createProgressTable = '''
  CREATE TABLE user_progress (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    mcq_id TEXT NOT NULL REFERENCES mcqs(id),
    confidence_level TEXT NOT NULL DEFAULT 'unseen',
    last_reviewed_at TEXT NOT NULL,
    next_review_at TEXT NOT NULL,
    review_count INTEGER DEFAULT 0,
    correct_count INTEGER DEFAULT 0,
    wrong_count INTEGER DEFAULT 0,
    is_bookmarked INTEGER DEFAULT 0,
    time_spent_seconds INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    is_synced INTEGER DEFAULT 0,  -- 0 = pending sync
    UNIQUE(user_id, mcq_id)
  )
''';

final String createSessionsTable = '''
  CREATE TABLE quiz_sessions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    mode TEXT NOT NULL,
    subject TEXT,
    topic TEXT,
    exam_category TEXT,
    mcq_ids TEXT NOT NULL,  -- JSON encoded array
    answers TEXT NOT NULL,  -- JSON encoded map
    confidence_marks TEXT NOT NULL,  -- JSON encoded map
    started_at TEXT NOT NULL,
    completed_at TEXT,
    total_time INTEGER DEFAULT 0,
    score INTEGER DEFAULT 0,
    total INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    is_synced INTEGER DEFAULT 0
  )
''';

// Indexes
final String createIndexes = '''
  CREATE INDEX idx_mcqs_subject ON mcqs(subject);
  CREATE INDEX idx_mcqs_difficulty ON mcqs(difficulty);
  CREATE INDEX idx_mcqs_source ON mcqs(source);
  CREATE INDEX idx_progress_confidence ON user_progress(confidence_level);
  CREATE INDEX idx_progress_next_review ON user_progress(next_review_at);
  CREATE INDEX idx_progress_bookmark ON user_progress(is_bookmarked);
''';
```

---

## 🔄 Sync Strategy (Flutter Offline → Online)

```dart
class SyncService {
  // 1. On app start: check connectivity
  // 2. Pull new MCQs from Supabase (server → local)
  // 3. Push unsynced progress (local → server)
  // 4. Resolve conflicts: server wins for MCQs, latest wins for progress

  Future<void> sync() async {
    final isOnline = await ConnectivityService.isOnline();
    if (!isOnline) return;

    // Pull MCQs added/updated since last sync
    await _pullMCQs();

    // Push local progress changes
    await _pushProgress();

    // Push local sessions
    await _pushSessions();
  }

  Future<void> _pushProgress() async {
    final unsynced = await db.query(
      'user_progress',
      where: 'is_synced = 0',
    );

    for (final row in unsynced) {
      await supabase.from('user_progress').upsert(row);
      await db.update('user_progress',
        {'is_synced': 1},
        where: 'id = ?',
        whereArgs: [row['id']],
      );
    }
  }
}
```

---

## 🔐 Security Notes

1. **RLS enabled** on all tables — users can only access their own data
2. **Admin role** required to modify MCQs
3. **JWT validation** handled by Supabase auth middleware
4. **Answer validation** happens server-side (never trust client)
5. **Input sanitization** on all text fields
6. **Rate limiting** via Supabase API gateway

---

## 🚀 Flutter Dependencies (pubspec.yaml)

```yaml
dependencies:
  flutter:
    sdk: flutter

  # State Management
  flutter_riverpod: ^2.5.1
  riverpod_annotation: ^2.3.5

  # Supabase
  supabase_flutter: ^2.4.0

  # Local Database
  sqflite: ^2.3.3+1
  path: ^1.9.0

  # Navigation
  go_router: ^13.2.0

  # UI
  flutter_animate: ^4.5.0
  fl_chart: ^0.68.0
  shimmer: ^3.0.0
  cached_network_image: ^3.3.1

  # Utils
  freezed_annotation: ^2.4.1
  json_annotation: ^4.9.0
  uuid: ^4.3.3
  intl: ^0.19.0
  shared_preferences: ^2.2.3
  connectivity_plus: ^6.0.3
  flutter_local_notifications: ^17.1.2

dev_dependencies:
  build_runner: ^2.4.9
  freezed: ^2.5.2
  json_serializable: ^6.8.0
  riverpod_generator: ^2.4.0
```

---

## 📊 Performance Optimizations

1. **Lazy loading** — MCQs loaded in batches of 20
2. **Pagination** — Question bank shows 50 at a time
3. **Memoization** — Dashboard stats computed once per render
4. **Indexed queries** — All filter columns have database indexes
5. **Offline-first** — Local SQLite as primary source of truth
6. **CDN images** — Question images served via Supabase Storage CDN
