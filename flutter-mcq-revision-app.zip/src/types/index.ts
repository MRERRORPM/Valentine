// ============================================================
// CORE TYPES & INTERFACES — MedRevise Pro
// Mirrors Flutter/Dart models with full TypeScript safety
// ============================================================

export type ExamCategory = 'NORCET' | 'AIIMS' | 'NEET' | 'UPSC' | 'NURSING' | 'ALL';
export type Difficulty = 'easy' | 'medium' | 'hard';
export type QuestionSource = 'PYQ' | 'mock' | 'custom' | 'AIIMS_PYQ' | 'NORCET_PYQ' | 'NEET_PYQ' | 'NURSING' | 'UPSC';
export type ConfidenceLevel = 'easy' | 'confused' | 'wrong' | 'important' | 'unseen';
export type RevisionMode =
  | 'wrong'
  | 'confused'
  | 'important'
  | 'mixed'
  | 'subject'
  | 'topic'
  | 'rapid'
  | 'pyq'
  | 'bookmarked'
  | 'due_today';

// ── MCQ Model ────────────────────────────────────────────────
export interface MCQ {
  id: string;
  question: string;
  options: [string, string, string, string];
  correctAnswer: number; // 0-3 index
  explanation: string;
  subject: string;
  topic: string;
  tags: string[];
  difficulty: Difficulty;
  source: QuestionSource;
  examCategory: ExamCategory;
  imageUrl?: string;
  year?: number; // for PYQ
  createdAt: string;
  updatedAt: string;
}

// ── User Progress per MCQ ────────────────────────────────────
export interface UserProgress {
  id: string;
  userId: string;
  mcqId: string;
  confidenceLevel: ConfidenceLevel;
  lastReviewedAt: string;
  nextReviewAt: string;
  reviewCount: number;
  correctCount: number;
  wrongCount: number;
  isBookmarked: boolean;
  timeSpentSeconds: number;
  createdAt: string;
  updatedAt: string;
}

// ── Spaced Repetition Config ─────────────────────────────────
export interface SpacedRepetitionConfig {
  wrong: number;       // 1 day
  confused: number;    // 3 days
  important: number;   // 7 days
  easy: number;        // 15 days
}

export const SPACED_REPETITION_DAYS: SpacedRepetitionConfig = {
  wrong: 1,
  confused: 3,
  important: 7,
  easy: 15,
};

// ── Quiz Session ─────────────────────────────────────────────
export interface QuizSession {
  id: string;
  userId: string;
  mode: RevisionMode;
  subject?: string;
  topic?: string;
  examCategory?: ExamCategory;
  mcqIds: string[];
  answers: Record<string, number | null>; // mcqId -> chosen option index
  confidenceMarks: Record<string, ConfidenceLevel>;
  startedAt: string;
  completedAt?: string;
  totalTime: number; // seconds
  score: number;
  total: number;
}

// ── Dashboard Stats ──────────────────────────────────────────
export interface DashboardStats {
  totalSolved: number;
  totalCorrect: number;
  totalWrong: number;
  accuracy: number;
  currentStreak: number;
  longestStreak: number;
  dueToday: number;
  bookmarked: number;
  bySubject: SubjectStat[];
  weeklyActivity: DailyActivity[];
  confidenceBreakdown: ConfidenceBreakdown;
  recentSessions: QuizSession[];
}

export interface SubjectStat {
  subject: string;
  total: number;
  correct: number;
  accuracy: number;
  dueToday: number;
}

export interface DailyActivity {
  date: string;
  solved: number;
  correct: number;
}

export interface ConfidenceBreakdown {
  easy: number;
  confused: number;
  wrong: number;
  important: number;
  unseen: number;
}

// ── User / Auth ──────────────────────────────────────────────
export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  examTarget: ExamCategory;
  role: 'student' | 'admin';
  createdAt: string;
  settings: UserSettings;
}

export interface UserSettings {
  darkMode: boolean;
  dailyGoal: number;
  notificationsEnabled: boolean;
  timerEnabled: boolean;
  showExplanationImmediately: boolean;
  shuffleOptions: boolean;
}

// ── Filter State ─────────────────────────────────────────────
export interface FilterState {
  subject: string;
  topic: string;
  difficulty: Difficulty | 'all';
  source: QuestionSource | 'all';
  examCategory: ExamCategory;
  confidenceLevel: ConfidenceLevel | 'all';
  isBookmarked: boolean;
  isDueToday: boolean;
  searchQuery: string;
  tags: string[];
}

// ── Notification ─────────────────────────────────────────────
export interface AppNotification {
  id: string;
  type: 'revision_due' | 'streak' | 'achievement' | 'daily_reminder';
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

// ── Admin ────────────────────────────────────────────────────
export interface BulkImportRow {
  question: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
  correctAnswer: 'A' | 'B' | 'C' | 'D';
  explanation: string;
  subject: string;
  topic: string;
  tags: string;
  difficulty: Difficulty;
  source: QuestionSource;
  examCategory: ExamCategory;
  year?: number;
}
