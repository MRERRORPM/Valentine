// ============================================================
// SIDEBAR NAVIGATION — Responsive with mobile overlay
// ============================================================

import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BookOpen, LayoutDashboard, Brain, BarChart3, Search,
  Settings, LogOut, Shield, Bell, ChevronLeft, Zap,
  Target, BookMarked, Clock, Shuffle, X, Star, Award
} from 'lucide-react';
import { useStore } from '../store/useStore';

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  badge?: number | string;
  color?: string;
  adminOnly?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, color: 'text-blue-500' },
  { id: 'quiz', label: 'Start Revision', icon: Zap, color: 'text-amber-500' },
  { id: 'question-bank', label: 'Question Bank', icon: Search, color: 'text-indigo-500' },
  { id: 'revision', label: 'Revision Modes', icon: Brain, color: 'text-violet-500' },
  { id: 'bookmarks', label: 'Bookmarked', icon: BookMarked, color: 'text-rose-500' },
  { id: 'analytics', label: 'Analytics', icon: BarChart3, color: 'text-green-500' },
  { id: 'notifications', label: 'Notifications', icon: Bell, color: 'text-orange-500' },
];

const REVISION_QUICK: NavItem[] = [
  { id: 'wrong', label: 'Wrong Questions', icon: Target, color: 'text-red-500' },
  { id: 'confused', label: 'Confused', icon: Brain, color: 'text-yellow-500' },
  { id: 'important', label: 'Important', icon: Star, color: 'text-purple-500' },
  { id: 'rapid', label: 'Rapid Revision', icon: Shuffle, color: 'text-cyan-500' },
  { id: 'due', label: 'Due Today', icon: Clock, color: 'text-green-500' },
];

const BOTTOM_ITEMS: NavItem[] = [
  { id: 'admin', label: 'Admin Panel', icon: Shield, color: 'text-amber-500', adminOnly: true },
  { id: 'settings', label: 'Settings', icon: Settings, color: 'text-slate-500' },
];

export const Sidebar: React.FC = () => {
  const { currentPage, setCurrentPage, user, logout, sidebarOpen, toggleSidebar, getDueTodayCount, progressMap, isAdmin, notifications } = useStore();

  const dueCount = getDueTodayCount();
  const unreadNotifs = notifications.filter((n) => !n.isRead).length;
  const wrongCount = Object.values(progressMap).filter((p) => p?.confidenceLevel === 'wrong').length;

  const getBadge = (id: string) => {
    if (id === 'dashboard' || id === 'quiz' || id === 'due') return dueCount > 0 ? dueCount : undefined;
    if (id === 'wrong') return wrongCount > 0 ? wrongCount : undefined;
    if (id === 'notifications') return unreadNotifs > 0 ? unreadNotifs : undefined;
    return undefined;
  };

  const handleNav = (id: string) => {
    if (id === 'wrong' || id === 'confused' || id === 'important' || id === 'rapid' || id === 'due') {
      useStore.getState().startSession(id === 'due' ? 'due_today' : id as any);
    } else {
      setCurrentPage(id);
    }
    if (window.innerWidth < 1024) toggleSidebar();
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-slate-900 dark:bg-slate-950 text-white">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-5 border-b border-slate-700/50">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-indigo-600 rounded-xl flex items-center justify-center flex-shrink-0">
            <BookOpen className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="font-bold text-white text-base">MedRevise</span>
            <span className="text-indigo-400 font-bold text-base"> Pro</span>
            <p className="text-slate-400 text-xs">{user?.examTarget} Prep</p>
          </div>
        </div>
        <button
          onClick={toggleSidebar}
          className="lg:flex hidden w-7 h-7 rounded-lg hover:bg-slate-700/50 items-center justify-center transition-colors"
        >
          <ChevronLeft className="w-4 h-4 text-slate-400" />
        </button>
        <button
          onClick={toggleSidebar}
          className="lg:hidden w-7 h-7 rounded-lg hover:bg-slate-700/50 flex items-center justify-center"
        >
          <X className="w-4 h-4 text-slate-400" />
        </button>
      </div>

      {/* User Card */}
      <div className="mx-3 my-3 p-3 bg-slate-800/60 rounded-xl border border-slate-700/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-violet-500 rounded-full flex items-center justify-center flex-shrink-0">
            <span className="text-white font-bold text-sm">{user?.name?.charAt(0).toUpperCase()}</span>
          </div>
          <div className="min-w-0">
            <p className="text-white font-medium text-sm truncate">{user?.name}</p>
            <p className="text-slate-400 text-xs truncate">{user?.email}</p>
          </div>
          {isAdmin() && (
            <span className="ml-auto px-2 py-0.5 bg-amber-500/20 text-amber-400 text-xs rounded-full border border-amber-500/30 flex-shrink-0">
              Admin
            </span>
          )}
        </div>
        {/* Streak */}
        <div className="mt-3 flex items-center gap-2">
          <Award className="w-4 h-4 text-amber-400" />
          <span className="text-xs text-slate-300">
            {dueCount} due today
          </span>
          {dueCount > 0 && (
            <span className="ml-auto px-2 py-0.5 bg-red-500/20 text-red-400 text-xs rounded-full">!</span>
          )}
        </div>
      </div>

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1 scrollbar-thin">
        <p className="text-slate-500 text-[10px] font-semibold uppercase tracking-wider px-3 py-2">Main</p>
        {NAV_ITEMS.filter((item) => !item.adminOnly || isAdmin()).map((item) => {
          const Icon = item.icon;
          const badge = getBadge(item.id);
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleNav(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                isActive
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-300 hover:bg-slate-700/60 hover:text-white'
              }`}
            >
              <Icon className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-white' : item.color}`} />
              <span className="flex-1 text-left">{item.label}</span>
              {badge !== undefined && (
                <span className={`px-2 py-0.5 text-xs rounded-full font-semibold ${
                  isActive
                    ? 'bg-white/20 text-white'
                    : 'bg-indigo-500/20 text-indigo-400'
                }`}>
                  {badge}
                </span>
              )}
            </button>
          );
        })}

        {/* Quick Revision */}
        <p className="text-slate-500 text-[10px] font-semibold uppercase tracking-wider px-3 py-2 mt-2">Quick Revision</p>
        {REVISION_QUICK.map((item) => {
          const Icon = item.icon;
          const badge = getBadge(item.id);
          return (
            <button
              key={item.id}
              onClick={() => handleNav(item.id)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-300 hover:bg-slate-700/60 hover:text-white transition-all"
            >
              <Icon className={`w-4 h-4 flex-shrink-0 ${item.color}`} />
              <span className="flex-1 text-left">{item.label}</span>
              {badge !== undefined && (
                <span className="px-2 py-0.5 text-xs rounded-full bg-red-500/20 text-red-400 font-semibold">
                  {badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Bottom */}
      <div className="px-3 pb-4 pt-2 border-t border-slate-700/50 space-y-1">
        {BOTTOM_ITEMS.filter((item) => !item.adminOnly || isAdmin()).map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => handleNav(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                currentPage === item.id
                  ? 'bg-slate-700 text-white'
                  : 'text-slate-300 hover:bg-slate-700/60 hover:text-white'
              }`}
            >
              <Icon className={`w-4 h-4 ${item.color}`} />
              {item.label}
            </button>
          );
        })}
        <button
          onClick={() => { logout(); }}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-red-400 hover:bg-red-500/10 transition-all"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.aside
            initial={{ x: -280 }}
            animate={{ x: 0 }}
            exit={{ x: -280 }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="hidden lg:flex flex-col w-64 flex-shrink-0 h-screen sticky top-0 border-r border-slate-700/30"
          >
            <SidebarContent />
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Mobile Sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="lg:hidden fixed inset-0 bg-black/60 z-40 backdrop-blur-sm"
              onClick={toggleSidebar}
            />
            <motion.aside
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="lg:hidden fixed left-0 top-0 bottom-0 w-72 z-50"
            >
              <SidebarContent />
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
};
