// ============================================================
// HEADER COMPONENT — Top navigation bar
// ============================================================

import React from 'react';
import { Menu, Moon, Sun, Bell, Search } from 'lucide-react';
import { useStore } from '../store/useStore';

const PAGE_TITLES: Record<string, string> = {
  dashboard: 'Dashboard',
  quiz: 'MCQ Practice',
  results: 'Session Results',
  'question-bank': 'Question Bank',
  revision: 'Revision Modes',
  bookmarks: 'Bookmarked Questions',
  analytics: 'Performance Analytics',
  settings: 'Settings',
  admin: 'Admin Panel',
  notifications: 'Notifications',
};

export const Header: React.FC = () => {
  const { currentPage, toggleDarkMode, darkMode, toggleSidebar, notifications, setCurrentPage } = useStore();
  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <header className="sticky top-0 z-30 flex items-center gap-4 px-4 lg:px-6 h-16 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm border-b border-slate-200 dark:border-slate-700/50">
      <button
        onClick={toggleSidebar}
        className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-600 dark:text-slate-300"
      >
        <Menu className="w-5 h-5" />
      </button>

      <div className="flex-1">
        <h1 className="text-base font-semibold text-slate-800 dark:text-white">
          {PAGE_TITLES[currentPage] ?? 'MedRevise Pro'}
        </h1>
      </div>

      {/* Quick search */}
      <button
        onClick={() => setCurrentPage('question-bank')}
        className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 text-sm hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
      >
        <Search className="w-4 h-4" />
        <span className="text-xs">Search MCQs...</span>
        <span className="ml-2 px-1.5 py-0.5 bg-slate-200 dark:bg-slate-700 rounded text-xs">⌘K</span>
      </button>

      {/* Notifications */}
      <button
        onClick={() => setCurrentPage('notifications')}
        className="relative w-9 h-9 flex items-center justify-center rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-600 dark:text-slate-300"
      >
        <Bell className="w-5 h-5" />
        {unreadCount > 0 && (
          <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center text-[10px] text-white font-bold">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {/* Dark mode toggle */}
      <button
        onClick={toggleDarkMode}
        className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-600 dark:text-slate-300"
      >
        {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
      </button>
    </header>
  );
};
