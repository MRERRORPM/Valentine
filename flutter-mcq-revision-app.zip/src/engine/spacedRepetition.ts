// ============================================================
// SPACED REPETITION ENGINE
// Mirrors Flutter/Dart spaced repetition logic with
// SM-2 inspired algorithm adapted for medical exams
// ============================================================

import { addDays, isAfter, isBefore, isToday, parseISO, startOfDay } from 'date-fns';
import { ConfidenceLevel, MCQ, UserProgress, SPACED_REPETITION_DAYS } from '../types';

// ── Calculate Next Review Date ────────────────────────────────
export function calculateNextReviewDate(
  confidenceLevel: ConfidenceLevel,
  reviewCount: number = 0
): Date {
  const now = new Date();

  switch (confidenceLevel) {
    case 'wrong':
      return addDays(now, SPACED_REPETITION_DAYS.wrong);
    case 'confused':
      return addDays(now, SPACED_REPETITION_DAYS.confused);
    case 'important':
      return addDays(now, SPACED_REPETITION_DAYS.important);
    case 'easy': {
      // Progressive spacing: 15, 20, 25, 30 days max
      const days = Math.min(15 + reviewCount * 5, 30);
      return addDays(now, days);
    }
    case 'unseen':
      return now; // Due immediately
    default:
      return addDays(now, 1);
  }
}

// ── Check if Review is Due ────────────────────────────────────
export function isReviewDue(progress: UserProgress): boolean {
  if (progress.confidenceLevel === 'unseen') return true;
  const nextReview = parseISO(progress.nextReviewAt);
  return !isAfter(nextReview, startOfDay(new Date()));
}

// ── Check if Due Today ────────────────────────────────────────
export function isDueToday(progress: UserProgress): boolean {
  if (progress.confidenceLevel === 'unseen') return true;
  const nextReview = parseISO(progress.nextReviewAt);
  return isToday(nextReview) || isBefore(nextReview, new Date());
}

// ── Update Progress After Answer ─────────────────────────────
export function updateProgressAfterAnswer(
  existing: UserProgress | null,
  mcqId: string,
  userId: string,
  isCorrect: boolean,
  confidenceLevel: ConfidenceLevel,
  timeSpent: number
): UserProgress {
  const now = new Date().toISOString();
  const reviewCount = (existing?.reviewCount ?? 0) + 1;
  const correctCount = (existing?.correctCount ?? 0) + (isCorrect ? 1 : 0);
  const wrongCount = (existing?.wrongCount ?? 0) + (isCorrect ? 0 : 1);
  const nextReviewDate = calculateNextReviewDate(confidenceLevel, reviewCount);

  return {
    id: existing?.id ?? `prog-${mcqId}-${userId}`,
    userId,
    mcqId,
    confidenceLevel,
    lastReviewedAt: now,
    nextReviewAt: nextReviewDate.toISOString(),
    reviewCount,
    correctCount,
    wrongCount,
    isBookmarked: existing?.isBookmarked ?? false,
    timeSpentSeconds: (existing?.timeSpentSeconds ?? 0) + timeSpent,
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
  };
}

// ── Sort MCQs by Priority ─────────────────────────────────────
export function sortByRevisionPriority(
  mcqs: MCQ[],
  progressMap: Record<string, UserProgress>
): MCQ[] {
  return [...mcqs].sort((a, b) => {
    const pa = progressMap[a.id];
    const pb = progressMap[b.id];

    // Unseen questions first
    if (!pa || pa.confidenceLevel === 'unseen') return -1;
    if (!pb || pb.confidenceLevel === 'unseen') return 1;

    // Wrong questions second
    if (pa.confidenceLevel === 'wrong' && pb.confidenceLevel !== 'wrong') return -1;
    if (pb.confidenceLevel === 'wrong' && pa.confidenceLevel !== 'wrong') return 1;

    // Then by next review date
    const aDate = parseISO(pa.nextReviewAt);
    const bDate = parseISO(pb.nextReviewAt);
    return aDate.getTime() - bDate.getTime();
  });
}

// ── Filter Due MCQs ───────────────────────────────────────────
export function filterDueMCQs(
  mcqs: MCQ[],
  progressMap: Record<string, UserProgress>
): MCQ[] {
  return mcqs.filter((mcq) => {
    const progress = progressMap[mcq.id];
    if (!progress || progress.confidenceLevel === 'unseen') return true;
    return isDueToday(progress);
  });
}

// ── Calculate Streak ─────────────────────────────────────────
export function calculateStreak(sessions: Array<{ completedAt?: string }>): number {
  if (sessions.length === 0) return 0;

  const dates = sessions
    .filter((s) => s.completedAt)
    .map((s) => startOfDay(parseISO(s.completedAt!)).getTime())
    .filter((v, i, a) => a.indexOf(v) === i) // unique dates
    .sort((a, b) => b - a); // newest first

  if (dates.length === 0) return 0;

  let streak = 0;
  const today = startOfDay(new Date()).getTime();
  const yesterday = addDays(startOfDay(new Date()), -1).getTime();

  // Check if studied today or yesterday
  if (dates[0] !== today && dates[0] !== yesterday) return 0;

  let expected = dates[0] === today ? today : yesterday;

  for (const date of dates) {
    if (date === expected) {
      streak++;
      expected = addDays(new Date(expected), -1).getTime();
    } else {
      break;
    }
  }

  return streak;
}

// ── Generate Adaptive Difficulty Queue ───────────────────────
export function generateRevisionQueue(
  mcqs: MCQ[],
  progressMap: Record<string, UserProgress>,
  mode: string,
  limit: number = 20
): MCQ[] {
  let filtered: MCQ[] = [];

  switch (mode) {
    case 'wrong':
      filtered = mcqs.filter(
        (m) => progressMap[m.id]?.confidenceLevel === 'wrong'
      );
      break;
    case 'confused':
      filtered = mcqs.filter(
        (m) => progressMap[m.id]?.confidenceLevel === 'confused'
      );
      break;
    case 'important':
      filtered = mcqs.filter(
        (m) => progressMap[m.id]?.confidenceLevel === 'important'
      );
      break;
    case 'pyq':
      filtered = mcqs.filter(
        (m) => m.source.includes('PYQ')
      );
      break;
    case 'bookmarked':
      filtered = mcqs.filter((m) => progressMap[m.id]?.isBookmarked);
      break;
    case 'due_today':
      filtered = filterDueMCQs(mcqs, progressMap);
      break;
    case 'rapid':
      // Mix of wrong + confused + due
      filtered = mcqs.filter((m) => {
        const p = progressMap[m.id];
        if (!p || p.confidenceLevel === 'unseen') return true;
        return (
          p.confidenceLevel === 'wrong' ||
          p.confidenceLevel === 'confused' ||
          isDueToday(p)
        );
      });
      break;
    case 'mixed':
    default:
      filtered = [...mcqs];
      break;
  }

  const sorted = sortByRevisionPriority(filtered, progressMap);
  return sorted.slice(0, limit);
}
