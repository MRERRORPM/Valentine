// ============================================================
// NOTIFICATIONS SCREEN
// ============================================================

import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, Brain, Award, Clock, Flame, Check, Trash2, BookOpen } from 'lucide-react';
import { useStore } from '../store/useStore';
import { AppNotification } from '../types';
import { format, parseISO } from 'date-fns';

const NOTIF_ICONS: Record<AppNotification['type'], React.ElementType> = {
  revision_due: Clock,
  streak: Flame,
  achievement: Award,
  daily_reminder: Brain,
};

const NOTIF_COLORS: Record<AppNotification['type'], string> = {
  revision_due: 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400',
  streak: 'bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400',
  achievement: 'bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400',
  daily_reminder: 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400',
};

export const NotificationsScreen: React.FC = () => {
  const { notifications, markNotificationRead, clearAllNotifications, addNotification, getDueTodayCount } = useStore();
  const dueCount = getDueTodayCount();

  // Generate demo notifications on first load
  useEffect(() => {
    if (notifications.length === 0) {
      const demoNotifs = [
        {
          type: 'revision_due' as const,
          title: `${dueCount} MCQs Due Today`,
          message: 'Your spaced repetition schedule has questions waiting for review. Keep your streak alive!',
          isRead: false,
        },
        {
          type: 'daily_reminder' as const,
          title: 'Daily Study Reminder 📚',
          message: 'Set aside 30 minutes today for focused MCQ revision. Consistency beats intensity!',
          isRead: false,
        },
        {
          type: 'streak' as const,
          title: 'Build Your Streak 🔥',
          message: 'Complete at least one quiz session today to maintain your study streak.',
          isRead: true,
        },
        {
          type: 'achievement' as const,
          title: 'Welcome to MedRevise Pro! 🎉',
          message: 'Your account is set up and ready. Start with the Quick Revision mode to see your first questions.',
          isRead: true,
        },
      ];
      demoNotifs.forEach((n) => addNotification(n));
    }
  }, []);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <div className="p-4 lg:p-6 max-w-2xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <Bell className="w-5 h-5 text-indigo-500" />
            Notifications
            {unreadCount > 0 && (
              <span className="px-2 py-0.5 bg-red-500 text-white text-xs rounded-full">{unreadCount}</span>
            )}
          </h2>
          <p className="text-sm text-slate-400">{notifications.length} total notifications</p>
        </div>
        {notifications.length > 0 && (
          <button
            onClick={clearAllNotifications}
            className="flex items-center gap-1.5 text-sm text-slate-400 hover:text-red-500 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            Clear all
          </button>
        )}
      </div>

      {/* Notification List */}
      {notifications.length === 0 ? (
        <div className="text-center py-20">
          <Bell className="w-14 h-14 mx-auto text-slate-300 mb-4" />
          <p className="text-slate-500 dark:text-slate-400 font-medium">All caught up!</p>
          <p className="text-slate-400 dark:text-slate-500 text-sm mt-1">No new notifications</p>
        </div>
      ) : (
        <AnimatePresence>
          <div className="space-y-3">
            {notifications.map((notif) => {
              const Icon = NOTIF_ICONS[notif.type];
              const colorClass = NOTIF_COLORS[notif.type];
              return (
                <motion.div
                  key={notif.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className={`flex items-start gap-4 p-4 rounded-2xl border transition-colors ${
                    notif.isRead
                      ? 'bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700'
                      : 'bg-indigo-50/50 dark:bg-indigo-900/10 border-indigo-100 dark:border-indigo-800'
                  }`}
                >
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${colorClass}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <p className={`text-sm font-semibold ${notif.isRead ? 'text-slate-700 dark:text-slate-200' : 'text-slate-800 dark:text-white'}`}>
                        {notif.title}
                      </p>
                      {!notif.isRead && (
                        <div className="w-2 h-2 bg-indigo-500 rounded-full flex-shrink-0 mt-1" />
                      )}
                    </div>
                    <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5 leading-relaxed">
                      {notif.message}
                    </p>
                    <p className="text-[10px] text-slate-300 dark:text-slate-600 mt-1.5">
                      {format(parseISO(notif.createdAt), 'MMM dd, h:mm a')}
                    </p>
                  </div>
                  {!notif.isRead && (
                    <button
                      onClick={() => markNotificationRead(notif.id)}
                      className="flex-shrink-0 w-7 h-7 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center justify-center text-slate-400 transition-colors"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  )}
                </motion.div>
              );
            })}
          </div>
        </AnimatePresence>
      )}

      {/* Quick Actions */}
      <div className="mt-6 p-4 bg-gradient-to-r from-indigo-600 to-violet-600 rounded-2xl text-white">
        <div className="flex items-center gap-3 mb-2">
          <BookOpen className="w-5 h-5" />
          <span className="font-semibold">Ready to study?</span>
        </div>
        <p className="text-indigo-100 text-sm mb-3">
          {dueCount > 0
            ? `You have ${dueCount} MCQs due for revision today`
            : 'Great job! All your revisions are up to date'}
        </p>
        <button
          onClick={() => useStore.getState().startSession('due_today')}
          className="px-4 py-2 bg-white text-indigo-700 font-semibold text-sm rounded-xl hover:bg-indigo-50 transition-colors"
        >
          Start Revision
        </button>
      </div>
    </div>
  );
};
