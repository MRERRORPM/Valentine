// ============================================================
// QUIZ / MCQ SOLVING SCREEN — Full featured with animations
// ============================================================

import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ChevronLeft, ChevronRight, BookMarked, Flag,
  CheckCircle, XCircle, Lightbulb, Clock, X,
  Star, AlertTriangle, ThumbsDown, Check, SkipForward,
  BookOpen
} from 'lucide-react';
import { useStore } from '../store/useStore';
import { ConfidenceLevel } from '../types';
import toast from 'react-hot-toast';

const OPTION_LETTERS = ['A', 'B', 'C', 'D'];

const CONFIDENCE_OPTIONS: {
  level: ConfidenceLevel;
  label: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  borderColor: string;
  desc: string;
}[] = [
  {
    level: 'easy',
    label: 'Easy',
    icon: ThumbsDown,
    color: 'text-green-600 dark:text-green-400',
    bgColor: 'bg-green-50 dark:bg-green-900/20 hover:bg-green-100 dark:hover:bg-green-900/40',
    borderColor: 'border-green-200 dark:border-green-700',
    desc: 'Review in 15 days',
  },
  {
    level: 'confused',
    label: 'Confused',
    icon: AlertTriangle,
    color: 'text-yellow-600 dark:text-yellow-400',
    bgColor: 'bg-yellow-50 dark:bg-yellow-900/20 hover:bg-yellow-100 dark:hover:bg-yellow-900/40',
    borderColor: 'border-yellow-200 dark:border-yellow-700',
    desc: 'Review in 3 days',
  },
  {
    level: 'wrong',
    label: 'Wrong',
    icon: XCircle,
    color: 'text-red-600 dark:text-red-400',
    bgColor: 'bg-red-50 dark:bg-red-900/20 hover:bg-red-100 dark:hover:bg-red-900/40',
    borderColor: 'border-red-200 dark:border-red-700',
    desc: 'Review tomorrow',
  },
  {
    level: 'important',
    label: 'Important',
    icon: Star,
    color: 'text-purple-600 dark:text-purple-400',
    bgColor: 'bg-purple-50 dark:bg-purple-900/20 hover:bg-purple-100 dark:hover:bg-purple-900/40',
    borderColor: 'border-purple-200 dark:border-purple-700',
    desc: 'Review in 7 days',
  },
];

export const QuizScreen: React.FC = () => {
  const {
    activeSession,
    activeQuestionIndex,
    mcqs,
    progressMap,
    nextQuestion,
    prevQuestion,
    answerQuestion,
    markConfidence,
    completeSession,
    abandonSession,
    toggleBookmark,
    setCurrentPage,
  } = useStore();

  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  const [selectedConfidence, setSelectedConfidence] = useState<ConfidenceLevel | null>(null);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [showConfirmAbandon, setShowConfirmAbandon] = useState(false);

  const session = activeSession;
  const currentMcqId = session?.mcqIds[activeQuestionIndex] ?? '';
  const currentMCQ = mcqs.find((m) => m.id === currentMcqId);
  const isBookmarked = progressMap[currentMcqId]?.isBookmarked ?? false;
  const progress = session ? ((activeQuestionIndex) / session.mcqIds.length) * 100 : 0;
  const isLastQuestion = session ? activeQuestionIndex === session.mcqIds.length - 1 : false;
  const answeredCount = Object.keys(session?.answers ?? {}).length;

  // Timer
  useEffect(() => {
    const interval = setInterval(() => {
      setTimeElapsed((t) => t + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Reset per question
  useEffect(() => {
    if (!session) return;
    const existingAnswer = session.answers[currentMcqId];
    const existingConfidence = session.confidenceMarks[currentMcqId];
    if (existingAnswer !== undefined && existingAnswer !== null) {
      setSelectedOption(existingAnswer);
      setAnswered(true);
      setShowExplanation(false);
    } else {
      setSelectedOption(null);
      setAnswered(false);
      setShowExplanation(false);
    }
    setSelectedConfidence(existingConfidence ?? null);
  }, [activeQuestionIndex, currentMcqId]);

  const handleOptionSelect = useCallback((optionIndex: number) => {
    if (answered) return;
    setSelectedOption(optionIndex);
    setAnswered(true);
    answerQuestion(optionIndex);

    const isCorrect = optionIndex === currentMCQ?.correctAnswer;

    // Auto-suggest confidence based on correctness
    const autoConfidence: ConfidenceLevel = isCorrect ? 'easy' : 'wrong';
    setSelectedConfidence(autoConfidence);
    markConfidence(autoConfidence);

    // Feedback toast
    if (isCorrect) {
      toast.success('Correct! ✓', { duration: 1200, icon: '🎯' });
    } else {
      toast.error('Incorrect ✗', { duration: 1200 });
    }
  }, [answered, currentMCQ, answerQuestion, markConfidence]);

  const handleConfidenceSelect = (level: ConfidenceLevel) => {
    setSelectedConfidence(level);
    markConfidence(level);
  };

  const handleNext = () => {
    if (!selectedConfidence && answered) {
      toast('Please mark your confidence level', { icon: '⚠️' });
      return;
    }
    if (isLastQuestion) {
      completeSession();
    } else {
      nextQuestion();
    }
  };

  const handleSkip = () => {
    if (isLastQuestion) {
      completeSession();
    } else {
      nextQuestion();
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  if (!session || !currentMCQ) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <BookOpen className="w-16 h-16 mx-auto text-slate-300 mb-4" />
          <h3 className="text-lg font-semibold text-slate-600 dark:text-slate-300 mb-2">No session active</h3>
          <button
            onClick={() => setCurrentPage('dashboard')}
            className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors font-medium"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-full bg-slate-50 dark:bg-slate-900">
      {/* Quiz Header */}
      <div className="sticky top-0 z-20 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 px-4 py-3">
        <div className="max-w-3xl mx-auto flex items-center gap-4">
          <button
            onClick={() => setShowConfirmAbandon(true)}
            className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex-1">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-sm font-medium text-slate-600 dark:text-slate-300">
                Q{activeQuestionIndex + 1} of {session.mcqIds.length}
                <span className="ml-2 text-slate-400">• {answeredCount} answered</span>
              </span>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400 text-sm">
                  <Clock className="w-4 h-4" />
                  <span className="font-mono text-sm">{formatTime(timeElapsed)}</span>
                </div>
              </div>
            </div>
            <div className="h-1.5 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
              <div
                className="h-full bg-indigo-500 rounded-full transition-all duration-500"
                style={{ width: `${Math.max(progress, 2)}%` }}
              />
            </div>
          </div>

          {/* Bookmark */}
          <button
            onClick={() => toggleBookmark(currentMcqId)}
            className={`w-8 h-8 flex items-center justify-center rounded-lg transition-colors ${
              isBookmarked
                ? 'text-amber-500 bg-amber-50 dark:bg-amber-900/20'
                : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
            }`}
          >
            <BookMarked className="w-4 h-4" fill={isBookmarked ? 'currentColor' : 'none'} />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-4 py-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentMcqId}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.25 }}
            >
              {/* Question Metadata */}
              <div className="flex flex-wrap items-center gap-2 mb-4">
                <span className="px-2.5 py-1 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 text-xs rounded-lg font-medium border border-indigo-100 dark:border-indigo-800">
                  {currentMCQ.subject}
                </span>
                <span className="px-2.5 py-1 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs rounded-lg font-medium">
                  {currentMCQ.topic}
                </span>
                <span className={`px-2.5 py-1 text-xs rounded-lg font-medium ${
                  currentMCQ.difficulty === 'easy' ? 'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400' :
                  currentMCQ.difficulty === 'medium' ? 'bg-yellow-50 dark:bg-yellow-900/20 text-yellow-700 dark:text-yellow-400' :
                  'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400'
                }`}>
                  {currentMCQ.difficulty.charAt(0).toUpperCase() + currentMCQ.difficulty.slice(1)}
                </span>
                {currentMCQ.source.includes('PYQ') && (
                  <span className="px-2.5 py-1 bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400 text-xs rounded-lg font-medium border border-purple-100 dark:border-purple-800">
                    PYQ {currentMCQ.year ? `${currentMCQ.year}` : ''}
                  </span>
                )}
              </div>

              {/* Question Text */}
              <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5 lg:p-7 mb-5 shadow-sm">
                <p className="text-base lg:text-lg text-slate-800 dark:text-white leading-relaxed font-medium">
                  {currentMCQ.question}
                </p>
              </div>

              {/* Options */}
              <div className="space-y-3 mb-5">
                {currentMCQ.options.map((option, idx) => {
                  const isSelected = selectedOption === idx;
                  const isCorrect = idx === currentMCQ.correctAnswer;
                  const showResult = answered;

                  let optionClass = 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-indigo-300 dark:hover:border-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20';

                  if (showResult) {
                    if (isCorrect) {
                      optionClass = 'border-green-400 dark:border-green-500 bg-green-50 dark:bg-green-900/20 option-correct';
                    } else if (isSelected && !isCorrect) {
                      optionClass = 'border-red-400 dark:border-red-500 bg-red-50 dark:bg-red-900/20 option-wrong';
                    } else {
                      optionClass = 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 opacity-60';
                    }
                  } else if (isSelected) {
                    optionClass = 'border-indigo-400 dark:border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20';
                  }

                  return (
                    <motion.button
                      key={idx}
                      whileTap={!answered ? { scale: 0.99 } : {}}
                      onClick={() => handleOptionSelect(idx)}
                      disabled={answered}
                      className={`w-full flex items-start gap-4 p-4 rounded-xl border-2 transition-all text-left ${optionClass} ${!answered ? 'cursor-pointer' : 'cursor-default'}`}
                    >
                      <div className={`flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold transition-colors ${
                        showResult
                          ? isCorrect
                            ? 'bg-green-500 text-white'
                            : isSelected
                            ? 'bg-red-500 text-white'
                            : 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400'
                          : isSelected
                          ? 'bg-indigo-500 text-white'
                          : 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400'
                      }`}>
                        {showResult && isCorrect ? (
                          <Check className="w-4 h-4" />
                        ) : showResult && isSelected && !isCorrect ? (
                          <X className="w-4 h-4" />
                        ) : (
                          OPTION_LETTERS[idx]
                        )}
                      </div>
                      <span className={`text-sm lg:text-base leading-relaxed pt-0.5 ${
                        showResult
                          ? isCorrect
                            ? 'text-green-800 dark:text-green-200 font-medium'
                            : isSelected
                            ? 'text-red-800 dark:text-red-200'
                            : 'text-slate-500 dark:text-slate-500'
                          : 'text-slate-700 dark:text-slate-200'
                      }`}>
                        {option}
                      </span>
                      {showResult && isCorrect && (
                        <CheckCircle className="ml-auto flex-shrink-0 w-5 h-5 text-green-500" />
                      )}
                      {showResult && isSelected && !isCorrect && (
                        <XCircle className="ml-auto flex-shrink-0 w-5 h-5 text-red-500" />
                      )}
                    </motion.button>
                  );
                })}
              </div>

              {/* Explanation */}
              {answered && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  transition={{ duration: 0.3, delay: 0.2 }}
                >
                  <button
                    onClick={() => setShowExplanation(!showExplanation)}
                    className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-medium text-sm mb-3 hover:underline"
                  >
                    <Lightbulb className="w-4 h-4" />
                    {showExplanation ? 'Hide Explanation' : 'Show Explanation'}
                  </button>

                  <AnimatePresence>
                    {showExplanation && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.25 }}
                        className="overflow-hidden"
                      >
                        <div className="p-5 bg-amber-50 dark:bg-amber-900/10 rounded-2xl border border-amber-200 dark:border-amber-700/50 mb-5">
                          <div className="flex items-start gap-3">
                            <div className="w-8 h-8 bg-amber-100 dark:bg-amber-900/40 rounded-lg flex items-center justify-center flex-shrink-0">
                              <Lightbulb className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                            </div>
                            <div>
                              <p className="font-semibold text-amber-800 dark:text-amber-300 text-sm mb-2">Explanation</p>
                              <p className="text-sm text-amber-900 dark:text-amber-200 leading-relaxed">
                                {currentMCQ.explanation}
                              </p>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Confidence Marking */}
                  <div className="mb-5">
                    <p className="text-sm font-medium text-slate-600 dark:text-slate-300 mb-3 flex items-center gap-2">
                      <Flag className="w-4 h-4" />
                      How well did you know this?
                    </p>
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
                      {CONFIDENCE_OPTIONS.map(({ level, label, icon: Icon, color, bgColor, borderColor, desc }) => (
                        <button
                          key={level}
                          onClick={() => handleConfidenceSelect(level)}
                          className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border transition-all ${bgColor} ${
                            selectedConfidence === level
                              ? `${borderColor} ring-2 ring-offset-1 ring-current`
                              : 'border-transparent'
                          } ${color}`}
                        >
                          <Icon className="w-4 h-4" />
                          <span className="text-xs font-semibold">{label}</span>
                          <span className="text-[10px] opacity-70">{desc}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Tags */}
              {currentMCQ.tags.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mb-5">
                  {currentMCQ.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-0.5 text-xs text-slate-400 dark:text-slate-500 bg-slate-100 dark:bg-slate-800 rounded-full"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="sticky bottom-0 bg-white dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 px-4 py-4">
        <div className="max-w-3xl mx-auto flex items-center gap-3">
          <button
            onClick={prevQuestion}
            disabled={activeQuestionIndex === 0}
            className="w-10 h-10 flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <div className="flex-1 flex gap-2">
            {!answered && (
              <button
                onClick={handleSkip}
                className="flex-1 py-2.5 text-sm font-medium text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors flex items-center justify-center gap-2"
              >
                <SkipForward className="w-4 h-4" />
                Skip
              </button>
            )}

            <button
              onClick={answered ? handleNext : () => {}}
              disabled={!answered}
              className={`flex-1 py-2.5 text-sm font-semibold rounded-xl transition-all flex items-center justify-center gap-2 ${
                answered
                  ? 'bg-indigo-600 hover:bg-indigo-700 text-white'
                  : 'bg-slate-100 dark:bg-slate-700 text-slate-400 dark:text-slate-500 cursor-not-allowed'
              }`}
            >
              {isLastQuestion && answered ? (
                <>
                  <CheckCircle className="w-4 h-4" />
                  Finish Session
                </>
              ) : (
                <>
                  Next
                  <ChevronRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>

          <button
            onClick={prevQuestion}
            disabled={activeQuestionIndex === 0}
            className="hidden"
          />
        </div>

        {/* Question Navigator Pills */}
        <div className="max-w-3xl mx-auto mt-3 flex gap-1 overflow-x-auto pb-1">
          {session.mcqIds.slice(0, 20).map((mcqId, i) => {
            const ans = session.answers[mcqId];
            const mcq = mcqs.find((m) => m.id === mcqId);
            const isAnswered = ans !== undefined && ans !== null;
            const isCurrentQ = i === activeQuestionIndex;
            const isCorrectAns = isAnswered && mcq && ans === mcq.correctAnswer;

            return (
              <button
                key={mcqId}
                onClick={() => {
                  useStore.setState({ activeQuestionIndex: i });
                }}
                className={`flex-shrink-0 w-7 h-7 rounded-lg text-xs font-semibold transition-all ${
                  isCurrentQ
                    ? 'bg-indigo-600 text-white'
                    : isAnswered
                    ? isCorrectAns
                      ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400'
                      : 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400'
                    : 'bg-slate-100 dark:bg-slate-700 text-slate-400 dark:text-slate-500'
                }`}
              >
                {i + 1}
              </button>
            );
          })}
          {session.mcqIds.length > 20 && (
            <span className="flex-shrink-0 text-xs text-slate-400 self-center px-1">
              +{session.mcqIds.length - 20}
            </span>
          )}
        </div>
      </div>

      {/* Abandon Confirm Modal */}
      <AnimatePresence>
        {showConfirmAbandon && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white dark:bg-slate-800 rounded-2xl p-6 max-w-sm w-full shadow-2xl"
            >
              <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-2">Abandon Session?</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm mb-5">
                Your progress for this session will not be saved. Are you sure?
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowConfirmAbandon(false)}
                  className="flex-1 py-2.5 text-sm font-medium border border-slate-200 dark:border-slate-700 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
                >
                  Continue Quiz
                </button>
                <button
                  onClick={() => { setShowConfirmAbandon(false); abandonSession(); }}
                  className="flex-1 py-2.5 text-sm font-semibold bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors"
                >
                  Abandon
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
