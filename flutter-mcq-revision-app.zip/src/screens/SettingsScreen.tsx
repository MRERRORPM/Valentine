// ============================================================
// SETTINGS SCREEN — User preferences and app config
// ============================================================

import React from 'react';
import { motion } from 'framer-motion';
import {
  Moon, Sun, Bell, Target, Clock, Shuffle, Eye,
  Award, LogOut, BookOpen, Shield
} from 'lucide-react';
import { useStore } from '../store/useStore';
import { ExamCategory } from '../types';
import toast from 'react-hot-toast';

const EXAM_OPTIONS: { value: ExamCategory; label: string }[] = [
  { value: 'NORCET', label: 'NORCET' },
  { value: 'AIIMS', label: 'AIIMS' },
  { value: 'NEET', label: 'NEET' },
  { value: 'UPSC', label: 'UPSC' },
  { value: 'NURSING', label: 'State Nursing' },
  { value: 'ALL', label: 'All Exams' },
];

interface ToggleProps {
  checked: boolean;
  onChange: (v: boolean) => void;
}

const Toggle: React.FC<ToggleProps> = ({ checked, onChange }) => (
  <button
    onClick={() => onChange(!checked)}
    className={`relative w-12 h-6 rounded-full transition-colors ${checked ? 'bg-indigo-600' : 'bg-slate-200 dark:bg-slate-700'}`}
  >
    <div className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${checked ? 'translate-x-6' : ''}`} />
  </button>
);

interface SettingsRowProps {
  icon: React.ElementType;
  label: string;
  desc?: string;
  children: React.ReactNode;
}

const SettingsRow: React.FC<SettingsRowProps> = ({ icon: Icon, label, desc, children }) => (
  <div className="flex items-center justify-between py-4 border-b border-slate-100 dark:border-slate-700 last:border-0">
    <div className="flex items-center gap-3">
      <div className="w-8 h-8 bg-slate-100 dark:bg-slate-700 rounded-lg flex items-center justify-center">
        <Icon className="w-4 h-4 text-slate-500 dark:text-slate-400" />
      </div>
      <div>
        <p className="text-sm font-medium text-slate-700 dark:text-slate-200">{label}</p>
        {desc && <p className="text-xs text-slate-400">{desc}</p>}
      </div>
    </div>
    <div className="ml-4">{children}</div>
  </div>
);

export const SettingsScreen: React.FC = () => {
  const { user, updateSettings, darkMode, toggleDarkMode, logout } = useStore();

  if (!user) return null;

  const { settings } = user;

  const handleExamChange = (exam: ExamCategory) => {
    useStore.setState((s) => ({
      user: s.user ? { ...s.user, examTarget: exam } : null,
    }));
    toast.success(`Target exam set to ${exam}`);
  };

  return (
    <div className="p-4 lg:p-6 max-w-2xl mx-auto space-y-5">
      {/* Profile Card */}
      <div className="bg-gradient-to-br from-indigo-600 to-violet-600 rounded-2xl p-6 text-white">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center text-2xl font-bold">
            {user.name.charAt(0)}
          </div>
          <div>
            <h2 className="text-xl font-bold">{user.name}</h2>
            <p className="text-indigo-200 text-sm">{user.email}</p>
            <div className="flex items-center gap-2 mt-2">
              <span className="px-2.5 py-1 bg-white/20 rounded-full text-xs font-medium">
                {user.examTarget}
              </span>
              {user.role === 'admin' && (
                <span className="px-2.5 py-1 bg-amber-400/30 rounded-full text-xs font-medium">
                  Admin
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Appearance */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5"
      >
        <h3 className="font-semibold text-slate-800 dark:text-white mb-1 flex items-center gap-2">
          <Sun className="w-4 h-4 text-amber-500" />
          Appearance
        </h3>
        <div className="divide-y divide-slate-100 dark:divide-slate-700">
          <SettingsRow icon={Moon} label="Dark Mode" desc="Easy on the eyes during night study">
            <Toggle checked={darkMode} onChange={() => toggleDarkMode()} />
          </SettingsRow>
        </div>
      </motion.div>

      {/* Study Settings */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5"
      >
        <h3 className="font-semibold text-slate-800 dark:text-white mb-1 flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-indigo-500" />
          Study Preferences
        </h3>
        <div className="divide-y divide-slate-100 dark:divide-slate-700">
          <SettingsRow icon={Target} label="Daily Goal" desc={`Currently: ${settings.dailyGoal} MCQs/day`}>
            <select
              value={settings.dailyGoal}
              onChange={(e) => updateSettings({ dailyGoal: Number(e.target.value) })}
              className="px-3 py-1.5 text-sm border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-indigo-400"
            >
              {[10, 20, 30, 50, 100].map((n) => (
                <option key={n} value={n}>{n} MCQs/day</option>
              ))}
            </select>
          </SettingsRow>
          <SettingsRow icon={Eye} label="Show Explanation Immediately" desc="Display explanation without clicking">
            <Toggle
              checked={settings.showExplanationImmediately}
              onChange={(v) => updateSettings({ showExplanationImmediately: v })}
            />
          </SettingsRow>
          <SettingsRow icon={Shuffle} label="Shuffle Options" desc="Randomize A/B/C/D order">
            <Toggle
              checked={settings.shuffleOptions}
              onChange={(v) => updateSettings({ shuffleOptions: v })}
            />
          </SettingsRow>
          <SettingsRow icon={Clock} label="Timer Mode" desc="Show countdown timer per question">
            <Toggle
              checked={settings.timerEnabled}
              onChange={(v) => updateSettings({ timerEnabled: v })}
            />
          </SettingsRow>
        </div>
      </motion.div>

      {/* Notifications */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5"
      >
        <h3 className="font-semibold text-slate-800 dark:text-white mb-1 flex items-center gap-2">
          <Bell className="w-4 h-4 text-orange-500" />
          Notifications
        </h3>
        <div className="divide-y divide-slate-100 dark:divide-slate-700">
          <SettingsRow icon={Bell} label="Push Notifications" desc="Revision reminders and streak alerts">
            <Toggle
              checked={settings.notificationsEnabled}
              onChange={(v) => { updateSettings({ notificationsEnabled: v }); toast.success(v ? 'Notifications enabled' : 'Notifications disabled'); }}
            />
          </SettingsRow>
        </div>
      </motion.div>

      {/* Exam Target */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5"
      >
        <h3 className="font-semibold text-slate-800 dark:text-white mb-3 flex items-center gap-2">
          <Award className="w-4 h-4 text-green-500" />
          Target Exam
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-2">
          {EXAM_OPTIONS.map(({ value, label }) => (
            <button
              key={value}
              onClick={() => handleExamChange(value)}
              className={`py-2.5 px-4 rounded-xl text-sm font-medium border transition-all ${
                user.examTarget === value
                  ? 'bg-indigo-600 text-white border-indigo-600'
                  : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-indigo-300 dark:hover:border-indigo-600'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </motion.div>

      {/* Spaced Repetition Info */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-indigo-50 dark:bg-indigo-900/10 rounded-2xl border border-indigo-100 dark:border-indigo-800 p-5"
      >
        <h3 className="font-semibold text-indigo-800 dark:text-indigo-300 mb-3 flex items-center gap-2">
          <Shield className="w-4 h-4" />
          Spaced Repetition Schedule
        </h3>
        <div className="space-y-2">
          {[
            { level: 'Wrong', days: '1 day', color: 'bg-red-100 dark:bg-red-900/20 text-red-700 dark:text-red-400' },
            { level: 'Confused', days: '3 days', color: 'bg-yellow-100 dark:bg-yellow-900/20 text-yellow-700 dark:text-yellow-400' },
            { level: 'Important', days: '7 days', color: 'bg-purple-100 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400' },
            { level: 'Easy', days: '15-30 days', color: 'bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-400' },
          ].map(({ level, days, color }) => (
            <div key={level} className="flex items-center justify-between">
              <span className={`px-3 py-1 rounded-lg text-xs font-semibold ${color}`}>{level}</span>
              <span className="text-sm text-indigo-700 dark:text-indigo-300 font-medium">Review after {days}</span>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Sign Out */}
      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.25 }}
        onClick={() => { logout(); toast.success('Signed out successfully'); }}
        className="w-full py-3 flex items-center justify-center gap-2 text-red-600 dark:text-red-400 font-semibold border border-red-100 dark:border-red-800 rounded-2xl hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors"
      >
        <LogOut className="w-4 h-4" />
        Sign Out
      </motion.button>

      <p className="text-center text-xs text-slate-400 pb-6">
        MedRevise Pro v1.0.0 · Built for NORCET, AIIMS, NEET, UPSC
      </p>
    </div>
  );
};
