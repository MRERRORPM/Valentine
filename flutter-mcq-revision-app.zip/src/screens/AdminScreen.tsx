// ============================================================
// ADMIN PANEL — MCQ Management, Bulk Import, Statistics
// ============================================================

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus, Upload, Edit3, Trash2, Search,
  AlertCircle, Database, BarChart2, Save
} from 'lucide-react';
import { useStore } from '../store/useStore';
import { MCQ, Difficulty, ExamCategory, QuestionSource } from '../types';
import { SUBJECTS, EXAM_CATEGORIES } from '../data/sampleMCQs';
import toast from 'react-hot-toast';


const defaultForm = {
  question: '',
  optionA: '',
  optionB: '',
  optionC: '',
  optionD: '',
  correctAnswer: 0,
  explanation: '',
  subject: 'Anatomy',
  topic: '',
  tags: '',
  difficulty: 'medium' as Difficulty,
  source: 'custom' as QuestionSource,
  examCategory: 'ALL' as ExamCategory,
  year: '',
};

const SAMPLE_JSON = JSON.stringify([
  {
    question: "Which nerve innervates the deltoid muscle?",
    optionA: "Radial nerve",
    optionB: "Axillary nerve",
    optionC: "Median nerve",
    optionD: "Ulnar nerve",
    correctAnswer: "B",
    explanation: "The axillary nerve (C5, C6) innervates the deltoid and teres minor muscles.",
    subject: "Anatomy",
    topic: "Upper Limb",
    tags: "deltoid,axillary nerve,upper limb",
    difficulty: "easy",
    source: "NORCET_PYQ",
    examCategory: "NORCET",
    year: 2023
  }
], null, 2);

export const AdminScreen: React.FC = () => {
  const { mcqs, addMCQ, updateMCQ, deleteMCQ, bulkImportMCQs, isAdmin, progressMap } = useStore();
  const [activeTab, setActiveTab] = useState<'list' | 'add' | 'import' | 'stats'>('list');
  const [form, setForm] = useState(defaultForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [importJson, setImportJson] = useState('');
  const [importErrors, setImportErrors] = useState<string[]>([]);

  if (!isAdmin()) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-3" />
          <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-300">Access Denied</h3>
          <p className="text-slate-400 text-sm mt-1">Admin privileges required</p>
        </div>
      </div>
    );
  }

  const filteredMCQs = mcqs.filter((m) =>
    !searchQuery ||
    m.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.subject.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.question || !form.optionA || !form.optionB || !form.optionC || !form.optionD || !form.explanation) {
      toast.error('Please fill all required fields');
      return;
    }

    const mcqData = {
      question: form.question,
      options: [form.optionA, form.optionB, form.optionC, form.optionD] as [string, string, string, string],
      correctAnswer: form.correctAnswer,
      explanation: form.explanation,
      subject: form.subject,
      topic: form.topic,
      tags: form.tags.split(',').map((t) => t.trim()).filter(Boolean),
      difficulty: form.difficulty,
      source: form.source,
      examCategory: form.examCategory,
      year: form.year ? parseInt(form.year) : undefined,
    };

    if (editingId) {
      updateMCQ(editingId, mcqData);
      toast.success('MCQ updated successfully!');
      setEditingId(null);
    } else {
      addMCQ(mcqData);
      toast.success('MCQ added successfully!');
    }
    setForm(defaultForm);
    setActiveTab('list');
  };

  const handleEdit = (mcq: MCQ) => {
    setForm({
      question: mcq.question,
      optionA: mcq.options[0],
      optionB: mcq.options[1],
      optionC: mcq.options[2],
      optionD: mcq.options[3],
      correctAnswer: mcq.correctAnswer,
      explanation: mcq.explanation,
      subject: mcq.subject,
      topic: mcq.topic,
      tags: mcq.tags.join(', '),
      difficulty: mcq.difficulty,
      source: mcq.source,
      examCategory: mcq.examCategory,
      year: mcq.year?.toString() ?? '',
    });
    setEditingId(mcq.id);
    setActiveTab('add');
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Delete this MCQ permanently?')) {
      deleteMCQ(id);
      toast.success('MCQ deleted');
    }
  };

  const handleBulkImport = () => {
    setImportErrors([]);
    try {
      const parsed = JSON.parse(importJson);
      if (!Array.isArray(parsed)) {
        setImportErrors(['JSON must be an array of MCQ objects']);
        return;
      }

      const errors: string[] = [];
      const validMCQs: Omit<MCQ, 'id' | 'createdAt' | 'updatedAt'>[] = [];

      parsed.forEach((item: any, idx: number) => {
        if (!item.question) errors.push(`Row ${idx + 1}: Missing question`);
        if (!item.optionA || !item.optionB || !item.optionC || !item.optionD) {
          errors.push(`Row ${idx + 1}: Missing options`);
        }
        if (!['A', 'B', 'C', 'D'].includes(item.correctAnswer)) {
          errors.push(`Row ${idx + 1}: correctAnswer must be A, B, C, or D`);
        }
        if (!item.explanation) errors.push(`Row ${idx + 1}: Missing explanation`);

        if (errors.length === 0) {
          const answerMap: Record<string, number> = { A: 0, B: 1, C: 2, D: 3 };
          validMCQs.push({
            question: item.question,
            options: [item.optionA, item.optionB, item.optionC, item.optionD],
            correctAnswer: answerMap[item.correctAnswer] ?? 0,
            explanation: item.explanation,
            subject: item.subject ?? 'General',
            topic: item.topic ?? 'General',
            tags: (item.tags ?? '').split(',').map((t: string) => t.trim()).filter(Boolean),
            difficulty: item.difficulty ?? 'medium',
            source: item.source ?? 'custom',
            examCategory: item.examCategory ?? 'ALL',
            year: item.year,
          });
        }
      });

      if (errors.length > 0) {
        setImportErrors(errors.slice(0, 10));
        return;
      }

      bulkImportMCQs(validMCQs);
      toast.success(`✅ ${validMCQs.length} MCQs imported successfully!`);
      setImportJson('');
      setActiveTab('list');
    } catch {
      setImportErrors(['Invalid JSON format. Please check syntax.']);
    }
  };

  const TABS = [
    { id: 'list', label: 'MCQ List', icon: Database },
    { id: 'add', label: editingId ? 'Edit MCQ' : 'Add MCQ', icon: Plus },
    { id: 'import', label: 'Bulk Import', icon: Upload },
    { id: 'stats', label: 'Statistics', icon: BarChart2 },
  ];

  // Stats
  const totalSolved = Object.values(progressMap).filter((p) => p.reviewCount > 0).length;
  const bySubject = SUBJECTS.map((s) => ({
    subject: s,
    count: mcqs.filter((m) => m.subject === s).length,
  })).filter((s) => s.count > 0);

  return (
    <div className="p-4 lg:p-6 max-w-6xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-800 dark:text-white">Admin Panel</h2>
          <p className="text-sm text-slate-400">{mcqs.length} total MCQs in database</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-3 py-1 bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 text-xs rounded-full border border-amber-200 dark:border-amber-800 font-medium">
            Admin Access
          </span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => { setActiveTab(id as any); if (id === 'add' && editingId) { setEditingId(null); setForm(defaultForm); } }}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-sm font-medium transition-all ${
              activeTab === id
                ? 'bg-white dark:bg-slate-700 text-slate-800 dark:text-white shadow-sm'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
            }`}
          >
            <Icon className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{label}</span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        {activeTab === 'list' && (
          <motion.div key="list" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
            <div className="flex gap-3">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search MCQs..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white text-sm focus:border-indigo-400"
                />
              </div>
              <button
                onClick={() => { setActiveTab('add'); setEditingId(null); setForm(defaultForm); }}
                className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white text-sm font-medium rounded-xl hover:bg-indigo-700 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add MCQ
              </button>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-700/50">
                      <th className="text-left py-3 px-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">#</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Question</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Subject</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Difficulty</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Source</th>
                      <th className="text-right py-3 px-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 dark:divide-slate-700">
                    {filteredMCQs.slice(0, 50).map((mcq, idx) => (
                      <tr key={mcq.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                        <td className="py-3 px-4 text-xs text-slate-400">{idx + 1}</td>
                        <td className="py-3 px-4">
                          <p className="text-sm text-slate-700 dark:text-slate-200 line-clamp-1 max-w-xs">{mcq.question}</p>
                        </td>
                        <td className="py-3 px-4">
                          <span className="text-xs px-2 py-1 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300 rounded-lg">{mcq.subject}</span>
                        </td>
                        <td className="py-3 px-4">
                          <span className={`text-xs font-medium ${
                            mcq.difficulty === 'easy' ? 'text-green-600' :
                            mcq.difficulty === 'medium' ? 'text-yellow-600' : 'text-red-600'
                          }`}>{mcq.difficulty}</span>
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-400">{mcq.source}</td>
                        <td className="py-3 px-4">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => handleEdit(mcq)}
                              className="p-1.5 text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDelete(mcq.id)}
                              className="p-1.5 text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {filteredMCQs.length > 50 && (
                <div className="p-3 text-center text-sm text-slate-400 border-t border-slate-100 dark:border-slate-700">
                  Showing 50 of {filteredMCQs.length} questions
                </div>
              )}
            </div>
          </motion.div>
        )}

        {activeTab === 'add' && (
          <motion.div key="add" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <form onSubmit={handleFormSubmit} className="space-y-5">
              <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5 space-y-4">
                <h3 className="font-semibold text-slate-800 dark:text-white">
                  {editingId ? 'Edit MCQ' : 'Add New MCQ'}
                </h3>

                {/* Question */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    Question <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    value={form.question}
                    onChange={(e) => setForm({ ...form, question: e.target.value })}
                    rows={3}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white text-sm resize-none focus:border-indigo-400"
                    placeholder="Enter the question text..."
                  />
                </div>

                {/* Options */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                  {(['A', 'B', 'C', 'D'] as const).map((letter, idx) => {
                    const key = `option${letter}` as keyof typeof form;
                    return (
                      <div key={letter}>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                          Option {letter} {idx === form.correctAnswer && <span className="text-green-600 ml-1">(Correct)</span>}
                        </label>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => setForm({ ...form, correctAnswer: idx })}
                            className={`w-8 h-10 rounded-lg text-sm font-bold flex-shrink-0 transition-colors ${
                              form.correctAnswer === idx
                                ? 'bg-green-500 text-white'
                                : 'bg-slate-100 dark:bg-slate-700 text-slate-400 hover:bg-green-100 dark:hover:bg-green-900/20'
                            }`}
                          >
                            {letter}
                          </button>
                          <input
                            type="text"
                            value={form[key] as string}
                            onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                            className="flex-1 px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white text-sm focus:border-indigo-400"
                            placeholder={`Option ${letter}...`}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Explanation */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    Explanation <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    value={form.explanation}
                    onChange={(e) => setForm({ ...form, explanation: e.target.value })}
                    rows={4}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white text-sm resize-none focus:border-indigo-400"
                    placeholder="Detailed explanation of the correct answer..."
                  />
                </div>

                {/* Metadata */}
                <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Subject</label>
                    <select value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })}
                      className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-indigo-400">
                      {SUBJECTS.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Topic</label>
                    <input type="text" value={form.topic} onChange={(e) => setForm({ ...form, topic: e.target.value })}
                      className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-indigo-400"
                      placeholder="e.g., Upper Limb" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Difficulty</label>
                    <select value={form.difficulty} onChange={(e) => setForm({ ...form, difficulty: e.target.value as Difficulty })}
                      className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-indigo-400">
                      <option value="easy">Easy</option>
                      <option value="medium">Medium</option>
                      <option value="hard">Hard</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Exam Category</label>
                    <select value={form.examCategory} onChange={(e) => setForm({ ...form, examCategory: e.target.value as ExamCategory })}
                      className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-indigo-400">
                      {EXAM_CATEGORIES.map((e) => <option key={e} value={e}>{e}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Source</label>
                    <select value={form.source} onChange={(e) => setForm({ ...form, source: e.target.value as QuestionSource })}
                      className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-indigo-400">
                      <option value="custom">Custom</option>
                      <option value="mock">Mock Test</option>
                      <option value="PYQ">PYQ</option>
                      <option value="NORCET_PYQ">NORCET PYQ</option>
                      <option value="AIIMS_PYQ">AIIMS PYQ</option>
                      <option value="NEET_PYQ">NEET PYQ</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Year (PYQ)</label>
                    <input type="number" value={form.year} onChange={(e) => setForm({ ...form, year: e.target.value })}
                      className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-indigo-400"
                      placeholder="2023" />
                  </div>
                  <div className="col-span-2 lg:col-span-3">
                    <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Tags (comma-separated)</label>
                    <input type="text" value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })}
                      className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-indigo-400"
                      placeholder="e.g., nerve injury, humerus, fracture" />
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <button type="submit"
                    className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 transition-colors">
                    <Save className="w-4 h-4" />
                    {editingId ? 'Update MCQ' : 'Save MCQ'}
                  </button>
                  <button type="button" onClick={() => { setForm(defaultForm); setEditingId(null); setActiveTab('list'); }}
                    className="px-6 py-3 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold rounded-xl hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
                    Cancel
                  </button>
                </div>
              </div>
            </form>
          </motion.div>
        )}

        {activeTab === 'import' && (
          <motion.div key="import" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
            <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5">
              <h3 className="font-semibold text-slate-800 dark:text-white mb-3 flex items-center gap-2">
                <Upload className="w-4 h-4 text-indigo-500" />
                Bulk Import MCQs (JSON)
              </h3>

              {/* Sample format */}
              <div className="mb-4 p-3 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Expected JSON Format:</p>
                  <button
                    onClick={() => setImportJson(SAMPLE_JSON)}
                    className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
                  >
                    Load sample
                  </button>
                </div>
                <pre className="text-xs text-slate-600 dark:text-slate-300 overflow-x-auto font-mono">
                  {`[{
  "question": "...",
  "optionA": "...", "optionB": "...",
  "optionC": "...", "optionD": "...",
  "correctAnswer": "A|B|C|D",
  "explanation": "...",
  "subject": "Anatomy", "topic": "Upper Limb",
  "difficulty": "easy|medium|hard",
  "source": "NORCET_PYQ",
  "examCategory": "NORCET",
  "tags": "tag1,tag2",
  "year": 2023
}]`}
                </pre>
              </div>

              <textarea
                value={importJson}
                onChange={(e) => setImportJson(e.target.value)}
                rows={12}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white text-xs font-mono resize-none focus:border-indigo-400"
                placeholder="Paste JSON array of MCQs here..."
              />

              {importErrors.length > 0 && (
                <div className="mt-3 p-3 bg-red-50 dark:bg-red-900/20 rounded-xl border border-red-100 dark:border-red-800">
                  <p className="text-xs font-semibold text-red-700 dark:text-red-400 mb-1 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" /> Validation Errors:
                  </p>
                  {importErrors.map((err, i) => (
                    <p key={i} className="text-xs text-red-600 dark:text-red-400">{err}</p>
                  ))}
                </div>
              )}

              <div className="flex gap-3 mt-4">
                <button
                  onClick={handleBulkImport}
                  disabled={!importJson.trim()}
                  className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 disabled:opacity-40 transition-colors"
                >
                  <Upload className="w-4 h-4" />
                  Import MCQs
                </button>
                <button
                  onClick={() => { setImportJson(''); setImportErrors([]); }}
                  className="px-4 py-3 border border-slate-200 dark:border-slate-700 text-slate-500 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-700"
                >
                  Clear
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'stats' && (
          <motion.div key="stats" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { label: 'Total MCQs', value: mcqs.length, color: 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400' },
                { label: 'MCQs Solved', value: totalSolved, color: 'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400' },
                { label: 'PYQ Questions', value: mcqs.filter(m => m.source.includes('PYQ')).length, color: 'bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400' },
                { label: 'Custom Added', value: mcqs.filter(m => m.source === 'custom').length, color: 'bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400' },
              ].map(({ label, value, color }) => (
                <div key={label} className={`p-4 rounded-2xl ${color} border border-current/10`}>
                  <p className="text-2xl font-bold">{value}</p>
                  <p className="text-xs font-medium mt-1 opacity-80">{label}</p>
                </div>
              ))}
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5">
              <h3 className="font-semibold text-slate-800 dark:text-white mb-4">MCQs by Subject</h3>
              <div className="space-y-2">
                {bySubject.sort((a, b) => b.count - a.count).map(({ subject, count }) => (
                  <div key={subject}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-slate-600 dark:text-slate-300">{subject}</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-200">{count}</span>
                    </div>
                    <div className="h-1.5 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-indigo-500 rounded-full"
                        style={{ width: `${(count / mcqs.length) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
