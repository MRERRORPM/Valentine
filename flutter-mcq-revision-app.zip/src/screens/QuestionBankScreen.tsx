// ============================================================
// QUESTION BANK SCREEN — Browse, filter, and search MCQs
// ============================================================

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search, Filter, X, BookMarked, ChevronDown,
  CheckCircle, AlertCircle, Play, Eye,
} from 'lucide-react';
import { useStore } from '../store/useStore';
import { MCQ, Difficulty, ExamCategory, ConfidenceLevel } from '../types';
import { SUBJECTS, EXAM_CATEGORIES } from '../data/sampleMCQs';

const DIFFICULTY_OPTIONS: { value: Difficulty | 'all'; label: string }[] = [
  { value: 'all', label: 'All Difficulties' },
  { value: 'easy', label: 'Easy' },
  { value: 'medium', label: 'Medium' },
  { value: 'hard', label: 'Hard' },
];

interface MCQCardProps {
  mcq: MCQ;
  confidence?: ConfidenceLevel;
  isBookmarked: boolean;
  onToggleBookmark: () => void;
  onStartQuiz: () => void;
  onExpand: () => void;
  isExpanded: boolean;
}

const MCQCard: React.FC<MCQCardProps> = ({
  mcq, confidence, isBookmarked, onToggleBookmark, onStartQuiz, onExpand, isExpanded
}) => {
  const difficultyStyle = {
    easy: 'text-green-600 bg-green-50 dark:bg-green-900/20 dark:text-green-400',
    medium: 'text-yellow-600 bg-yellow-50 dark:bg-yellow-900/20 dark:text-yellow-400',
    hard: 'text-red-600 bg-red-50 dark:bg-red-900/20 dark:text-red-400',
  };

  const confidenceStyle: Record<ConfidenceLevel, string> = {
    easy: 'badge-easy',
    confused: 'badge-confused',
    wrong: 'badge-wrong',
    important: 'badge-important',
    unseen: 'badge-unseen',
  };

  return (
    <motion.div
      layout
      className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 overflow-hidden"
    >
      <div className="p-4">
        {/* Metadata row */}
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <span className="text-xs px-2.5 py-1 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300 rounded-lg font-medium">
            {mcq.subject}
          </span>
          <span className="text-xs px-2.5 py-1 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-lg">
            {mcq.topic}
          </span>
          <span className={`text-xs px-2.5 py-1 rounded-lg font-medium ${difficultyStyle[mcq.difficulty]}`}>
            {mcq.difficulty}
          </span>
          {mcq.source.includes('PYQ') && (
            <span className="text-xs px-2.5 py-1 bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400 rounded-lg border border-purple-100 dark:border-purple-800">
              PYQ {mcq.year}
            </span>
          )}
          {confidence && confidence !== 'unseen' && (
            <span className={`text-xs px-2.5 py-1 rounded-lg font-medium ${confidenceStyle[confidence]}`}>
              {confidence}
            </span>
          )}
        </div>

        {/* Question */}
        <p className="text-sm font-medium text-slate-700 dark:text-slate-200 leading-relaxed mb-3 line-clamp-3">
          {mcq.question}
        </p>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={onExpand}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg transition-colors"
          >
            <Eye className="w-3.5 h-3.5" />
            {isExpanded ? 'Collapse' : 'Preview'}
            <ChevronDown className={`w-3 h-3 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
          </button>

          <button
            onClick={onStartQuiz}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 rounded-lg transition-colors font-medium"
          >
            <Play className="w-3.5 h-3.5" />
            Start
          </button>

          <button
            onClick={onToggleBookmark}
            className={`ml-auto flex items-center gap-1.5 p-1.5 rounded-lg transition-colors ${
              isBookmarked
                ? 'text-amber-500 bg-amber-50 dark:bg-amber-900/20'
                : 'text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
            }`}
          >
            <BookMarked className="w-4 h-4" fill={isBookmarked ? 'currentColor' : 'none'} />
          </button>
        </div>
      </div>

      {/* Expanded View */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 pt-2 border-t border-slate-100 dark:border-slate-700">
              {/* Options */}
              <div className="space-y-2 mb-4">
                {mcq.options.map((opt, i) => (
                  <div
                    key={i}
                    className={`flex items-start gap-3 p-3 rounded-xl text-sm ${
                      i === mcq.correctAnswer
                        ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700'
                        : 'bg-slate-50 dark:bg-slate-700/50 border border-transparent'
                    }`}
                  >
                    <span className={`flex-shrink-0 w-6 h-6 rounded-md flex items-center justify-center text-xs font-bold ${
                      i === mcq.correctAnswer
                        ? 'bg-green-500 text-white'
                        : 'bg-slate-200 dark:bg-slate-600 text-slate-600 dark:text-slate-300'
                    }`}>
                      {['A', 'B', 'C', 'D'][i]}
                    </span>
                    <span className={i === mcq.correctAnswer ? 'text-green-800 dark:text-green-200 font-medium' : 'text-slate-600 dark:text-slate-300'}>
                      {opt}
                    </span>
                    {i === mcq.correctAnswer && (
                      <CheckCircle className="ml-auto flex-shrink-0 w-4 h-4 text-green-500" />
                    )}
                  </div>
                ))}
              </div>

              {/* Explanation */}
              <div className="p-3 bg-amber-50 dark:bg-amber-900/10 rounded-xl border border-amber-100 dark:border-amber-800">
                <p className="text-xs font-semibold text-amber-700 dark:text-amber-400 mb-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" /> Explanation
                </p>
                <p className="text-xs text-amber-800 dark:text-amber-200 leading-relaxed">{mcq.explanation}</p>
              </div>

              {/* Tags */}
              {mcq.tags.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-1">
                  {mcq.tags.map((tag) => (
                    <span key={tag} className="text-[10px] px-2 py-0.5 bg-slate-100 dark:bg-slate-700 text-slate-400 rounded-full">
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export const QuestionBankScreen: React.FC = () => {
  const { mcqs, progressMap, toggleBookmark, startSession, filterState, setFilter, resetFilter } = useStore();
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  const filteredMCQs = useMemo(() => {
    return mcqs.filter((mcq) => {
      if (filterState.subject && mcq.subject !== filterState.subject) return false;
      if (filterState.topic && mcq.topic !== filterState.topic) return false;
      if (filterState.difficulty !== 'all' && mcq.difficulty !== filterState.difficulty) return false;
      if (filterState.examCategory !== 'ALL' && mcq.examCategory !== filterState.examCategory && mcq.examCategory !== 'ALL') return false;
      if (filterState.confidenceLevel !== 'all') {
        const level = progressMap[mcq.id]?.confidenceLevel ?? 'unseen';
        if (level !== filterState.confidenceLevel) return false;
      }
      if (filterState.isBookmarked && !progressMap[mcq.id]?.isBookmarked) return false;
      if (filterState.searchQuery) {
        const q = filterState.searchQuery.toLowerCase();
        if (
          !mcq.question.toLowerCase().includes(q) &&
          !mcq.subject.toLowerCase().includes(q) &&
          !mcq.topic.toLowerCase().includes(q) &&
          !mcq.tags.some((t) => t.toLowerCase().includes(q))
        ) return false;
      }
      return true;
    });
  }, [mcqs, progressMap, filterState]);

  const hasActiveFilters = filterState.subject || filterState.topic ||
    filterState.difficulty !== 'all' || filterState.examCategory !== 'ALL' ||
    filterState.confidenceLevel !== 'all' || filterState.isBookmarked || filterState.searchQuery;

  return (
    <div className="p-4 lg:p-6 max-w-5xl mx-auto space-y-4">
      {/* Search bar */}
      <div className="flex gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={filterState.searchQuery}
            onChange={(e) => setFilter({ searchQuery: e.target.value })}
            placeholder="Search questions, topics, tags..."
            className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white placeholder-slate-400 focus:border-indigo-400 transition-colors text-sm"
          />
          {filterState.searchQuery && (
            <button
              onClick={() => setFilter({ searchQuery: '' })}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className={`flex items-center gap-2 px-4 py-3 rounded-xl border transition-colors text-sm font-medium ${
            showFilters || hasActiveFilters
              ? 'bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200 dark:border-indigo-700 text-indigo-700 dark:text-indigo-300'
              : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
          }`}
        >
          <Filter className="w-4 h-4" />
          Filters
          {hasActiveFilters && (
            <span className="w-5 h-5 bg-indigo-600 text-white text-xs rounded-full flex items-center justify-center">!</span>
          )}
        </button>
      </div>

      {/* Filters Panel */}
      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-4 grid grid-cols-2 lg:grid-cols-4 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5 block">Subject</label>
                <select
                  value={filterState.subject}
                  onChange={(e) => setFilter({ subject: e.target.value })}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-indigo-400"
                >
                  <option value="">All Subjects</option>
                  {SUBJECTS.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5 block">Exam</label>
                <select
                  value={filterState.examCategory}
                  onChange={(e) => setFilter({ examCategory: e.target.value as ExamCategory })}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-indigo-400"
                >
                  {EXAM_CATEGORIES.map((e) => <option key={e} value={e}>{e}</option>)}
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5 block">Difficulty</label>
                <select
                  value={filterState.difficulty}
                  onChange={(e) => setFilter({ difficulty: e.target.value as any })}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-indigo-400"
                >
                  {DIFFICULTY_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5 block">Status</label>
                <select
                  value={filterState.confidenceLevel}
                  onChange={(e) => setFilter({ confidenceLevel: e.target.value as any })}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:border-indigo-400"
                >
                  <option value="all">All Status</option>
                  <option value="unseen">Unseen</option>
                  <option value="easy">Easy</option>
                  <option value="confused">Confused</option>
                  <option value="wrong">Wrong</option>
                  <option value="important">Important</option>
                </select>
              </div>

              <div className="col-span-2 lg:col-span-4 flex items-center gap-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={filterState.isBookmarked}
                    onChange={(e) => setFilter({ isBookmarked: e.target.checked })}
                    className="w-4 h-4 rounded accent-indigo-600"
                  />
                  <span className="text-sm text-slate-600 dark:text-slate-300">Bookmarked only</span>
                </label>

                {hasActiveFilters && (
                  <button
                    onClick={resetFilter}
                    className="ml-auto flex items-center gap-1.5 text-sm text-red-500 hover:text-red-600"
                  >
                    <X className="w-4 h-4" /> Clear all filters
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Results header */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-500 dark:text-slate-400">
          <span className="font-semibold text-slate-700 dark:text-slate-200">{filteredMCQs.length}</span> questions
          {hasActiveFilters && ' (filtered)'}
        </p>
        <button
          onClick={() => {
            if (filteredMCQs.length > 0) {
              startSession('mixed', { limit: Math.min(filteredMCQs.length, 20) });
            }
          }}
          disabled={filteredMCQs.length === 0}
          className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-xl hover:bg-indigo-700 disabled:opacity-40 transition-colors"
        >
          <Play className="w-4 h-4" />
          Start Test ({Math.min(filteredMCQs.length, 20)})
        </button>
      </div>

      {/* MCQ List */}
      <div className="space-y-3">
        {filteredMCQs.length === 0 ? (
          <div className="text-center py-16">
            <Search className="w-12 h-12 mx-auto text-slate-300 mb-3" />
            <p className="text-slate-500 dark:text-slate-400 font-medium">No MCQs found</p>
            <p className="text-slate-400 dark:text-slate-500 text-sm mt-1">Try adjusting your filters</p>
            <button onClick={resetFilter} className="mt-4 text-sm text-indigo-600 dark:text-indigo-400 hover:underline">
              Clear filters
            </button>
          </div>
        ) : (
          filteredMCQs.map((mcq) => (
            <MCQCard
              key={mcq.id}
              mcq={mcq}
              confidence={progressMap[mcq.id]?.confidenceLevel}
              isBookmarked={progressMap[mcq.id]?.isBookmarked ?? false}
              onToggleBookmark={() => toggleBookmark(mcq.id)}
              onStartQuiz={() => startSession('mixed', { limit: 1 })}
              onExpand={() => setExpandedId(expandedId === mcq.id ? null : mcq.id)}
              isExpanded={expandedId === mcq.id}
            />
          ))
        )}
      </div>
    </div>
  );
};
