// ============================================================
// REVISION MODES SCREEN — All revision mode options
// ============================================================

import React from 'react';
import { motion } from 'framer-motion';
import {
  Brain, Target, Zap, Clock, BookMarked, Shuffle,
  Star, BarChart2, Play, BookOpen, TrendingUp
} from 'lucide-react';
import { useStore } from '../store/useStore';
import { SUBJECTS } from '../data/sampleMCQs';
import { ExamCategory, RevisionMode } from '../types';

const REVISION_CARDS = [
  {
    mode: 'wrong' as RevisionMode,
    title: 'Wrong Questions',
    desc: 'Practice questions you answered incorrectly. Spaced revision after 1 day.',
    icon: Target,
    gradient: 'from-red-500 to-rose-600',
    bg: 'bg-red-50 dark:bg-red-900/10',
    border: 'border-red-100 dark:border-red-800',
    iconBg: 'bg-red-100 dark:bg-red-900/30',
    iconColor: 'text-red-600 dark:text-red-400',
  },
  {
    mode: 'confused' as RevisionMode,
    title: 'Confused Topics',
    desc: 'Questions you found tricky. Review scheduled after 3 days.',
    icon: Brain,
    gradient: 'from-yellow-500 to-amber-600',
    bg: 'bg-yellow-50 dark:bg-yellow-900/10',
    border: 'border-yellow-100 dark:border-yellow-800',
    iconBg: 'bg-yellow-100 dark:bg-yellow-900/30',
    iconColor: 'text-yellow-600 dark:text-yellow-400',
  },
  {
    mode: 'important' as RevisionMode,
    title: 'Important Questions',
    desc: 'High-priority MCQs you marked. Review after 7 days.',
    icon: Star,
    gradient: 'from-purple-500 to-violet-600',
    bg: 'bg-purple-50 dark:bg-purple-900/10',
    border: 'border-purple-100 dark:border-purple-800',
    iconBg: 'bg-purple-100 dark:bg-purple-900/30',
    iconColor: 'text-purple-600 dark:text-purple-400',
  },
  {
    mode: 'due_today' as RevisionMode,
    title: 'Due Today',
    desc: "Today's spaced repetition queue. Must-do for streak maintenance.",
    icon: Clock,
    gradient: 'from-green-500 to-emerald-600',
    bg: 'bg-green-50 dark:bg-green-900/10',
    border: 'border-green-100 dark:border-green-800',
    iconBg: 'bg-green-100 dark:bg-green-900/30',
    iconColor: 'text-green-600 dark:text-green-400',
  },
  {
    mode: 'pyq' as RevisionMode,
    title: 'PYQ Revision',
    desc: 'Previous Year Questions from NORCET, AIIMS, NEET, UPSC.',
    icon: BookOpen,
    gradient: 'from-blue-500 to-indigo-600',
    bg: 'bg-blue-50 dark:bg-blue-900/10',
    border: 'border-blue-100 dark:border-blue-800',
    iconBg: 'bg-blue-100 dark:bg-blue-900/30',
    iconColor: 'text-blue-600 dark:text-blue-400',
  },
  {
    mode: 'bookmarked' as RevisionMode,
    title: 'Bookmarked',
    desc: 'Questions you saved for focused review.',
    icon: BookMarked,
    gradient: 'from-pink-500 to-rose-600',
    bg: 'bg-pink-50 dark:bg-pink-900/10',
    border: 'border-pink-100 dark:border-pink-800',
    iconBg: 'bg-pink-100 dark:bg-pink-900/30',
    iconColor: 'text-pink-600 dark:text-pink-400',
  },
  {
    mode: 'mixed' as RevisionMode,
    title: 'Mixed Random',
    desc: 'Random questions from all subjects and sources.',
    icon: Shuffle,
    gradient: 'from-cyan-500 to-blue-600',
    bg: 'bg-cyan-50 dark:bg-cyan-900/10',
    border: 'border-cyan-100 dark:border-cyan-800',
    iconBg: 'bg-cyan-100 dark:bg-cyan-900/30',
    iconColor: 'text-cyan-600 dark:text-cyan-400',
  },
  {
    mode: 'rapid' as RevisionMode,
    title: 'Rapid Revision',
    desc: '10-question high-speed sprint. Perfect for quick daily practice.',
    icon: Zap,
    gradient: 'from-amber-500 to-orange-600',
    bg: 'bg-amber-50 dark:bg-amber-900/10',
    border: 'border-amber-100 dark:border-amber-800',
    iconBg: 'bg-amber-100 dark:bg-amber-900/30',
    iconColor: 'text-amber-600 dark:text-amber-400',
  },
];

const EXAM_CATEGORIES: ExamCategory[] = ['NORCET', 'AIIMS', 'NEET', 'UPSC', 'NURSING'];

export const RevisionModesScreen: React.FC = () => {
  const { startSession, progressMap, getDashboardStats, mcqs } = useStore();
  const stats = getDashboardStats();

  const getModeCount = (mode: RevisionMode): number => {
    switch (mode) {
      case 'wrong': return stats.confidenceBreakdown.wrong;
      case 'confused': return stats.confidenceBreakdown.confused;
      case 'important': return stats.confidenceBreakdown.important;
      case 'bookmarked': return stats.bookmarked;
      case 'due_today': return stats.dueToday;
      case 'pyq': return mcqs.filter((m) => m.source.includes('PYQ')).length;
      case 'mixed': return mcqs.length;
      case 'rapid': return Math.min(mcqs.length, 10);
      default: return 0;
    }
  };

  return (
    <div className="p-4 lg:p-6 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-lg font-bold text-slate-800 dark:text-white">Revision Modes</h2>
        <p className="text-sm text-slate-400 mt-1">Choose your revision strategy</p>
      </div>

      {/* Spaced Repetition Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {REVISION_CARDS.map(({ mode, title, desc, icon: Icon, gradient, bg, border, iconBg, iconColor }) => {
          const count = getModeCount(mode);
          return (
            <motion.div
              key={mode}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`relative overflow-hidden ${bg} rounded-2xl border ${border} p-5 card-hover`}
            >
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 ${iconBg} rounded-2xl flex items-center justify-center flex-shrink-0`}>
                  <Icon className={`w-6 h-6 ${iconColor}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-slate-800 dark:text-white">{title}</h3>
                    {count > 0 && (
                      <span className="px-2 py-0.5 text-xs font-semibold bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-full">
                        {count}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">{desc}</p>
                </div>
              </div>
              <button
                onClick={() => startSession(mode, { limit: mode === 'rapid' ? 10 : 20 })}
                disabled={count === 0 && mode !== 'mixed' && mode !== 'rapid'}
                className={`mt-4 w-full py-2.5 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2 ${
                  count === 0 && mode !== 'mixed' && mode !== 'rapid'
                    ? 'bg-slate-100 dark:bg-slate-700 text-slate-400 dark:text-slate-500 cursor-not-allowed'
                    : `bg-gradient-to-r ${gradient} text-white hover:opacity-90`
                }`}
              >
                <Play className="w-4 h-4" />
                {count === 0 && mode !== 'mixed' && mode !== 'rapid'
                  ? 'No questions available'
                  : `Start ${mode === 'rapid' ? '10' : 'up to 20'} Questions`}
              </button>
            </motion.div>
          );
        })}
      </div>

      {/* Subject-wise Revision */}
      <div>
        <h3 className="font-semibold text-slate-800 dark:text-white mb-3 flex items-center gap-2">
          <BarChart2 className="w-4 h-4 text-indigo-500" />
          Subject-Wise Revision
        </h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {SUBJECTS.map((subject) => {
            const subjectMCQs = mcqs.filter((m) => m.subject === subject);
            const subjectProgress = subjectMCQs.map((m) => progressMap[m.id]).filter(Boolean);
            const correct = subjectProgress.reduce((s, p) => s + (p?.correctCount ?? 0), 0);
            const total = subjectProgress.reduce((s, p) => s + (p?.correctCount ?? 0) + (p?.wrongCount ?? 0), 0);
            const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;
            const solved = subjectProgress.filter((p) => (p?.reviewCount ?? 0) > 0).length;

            return (
              <div
                key={subject}
                className="flex items-center gap-3 p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700 hover:border-slate-200 dark:hover:border-slate-600 transition-colors"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-slate-700 dark:text-slate-200 truncate">{subject}</span>
                    <div className="flex items-center gap-2 ml-2">
                      <span className="text-xs text-slate-400">{solved}/{subjectMCQs.length}</span>
                      {accuracy > 0 && (
                        <span className={`text-xs font-semibold ${
                          accuracy >= 70 ? 'text-green-600 dark:text-green-400' :
                          accuracy >= 50 ? 'text-yellow-600 dark:text-yellow-400' :
                          'text-red-600 dark:text-red-400'
                        }`}>{accuracy}%</span>
                      )}
                    </div>
                  </div>
                  <div className="h-1.5 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-indigo-500 rounded-full transition-all"
                      style={{ width: `${subjectMCQs.length > 0 ? (solved / subjectMCQs.length) * 100 : 0}%` }}
                    />
                  </div>
                </div>
                <button
                  onClick={() => startSession('subject' as RevisionMode, { subject, limit: 20 })}
                  className="flex-shrink-0 w-8 h-8 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center hover:bg-indigo-100 dark:hover:bg-indigo-900/40 transition-colors"
                >
                  <Play className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Exam-wise Revision */}
      <div>
        <h3 className="font-semibold text-slate-800 dark:text-white mb-3 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-green-500" />
          Exam-Category Practice
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
          {EXAM_CATEGORIES.map((exam) => {
            const examMCQs = mcqs.filter((m) => m.examCategory === exam);
            return (
              <button
                key={exam}
                onClick={() => startSession('mixed', { examCategory: exam, limit: 20 })}
                className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700 hover:border-indigo-200 dark:hover:border-indigo-700 text-center card-hover transition-all"
              >
                <div className="text-lg font-bold text-indigo-600 dark:text-indigo-400">{exam}</div>
                <div className="text-xs text-slate-400 mt-1">{examMCQs.length} MCQs</div>
                <div className="mt-2 flex items-center justify-center gap-1 text-indigo-500">
                  <Play className="w-3 h-3" />
                  <span className="text-xs font-medium">Practice</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
