// ============================================================
// ANALYTICS SCREEN — Deep performance insights
// ============================================================

import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Cell, RadarChart, Radar, PolarGrid,
  PolarAngleAxis, AreaChart, Area
} from 'recharts';
import {
  TrendingUp, Award, Target, Brain, CheckCircle,
  Zap, BarChart2
} from 'lucide-react';
import { useStore } from '../store/useStore';
import { format, parseISO } from 'date-fns';

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-800 rounded-xl p-3 border border-slate-700 shadow-xl">
        <p className="text-slate-300 text-xs mb-1">{label}</p>
        {payload.map((p: any) => (
          <p key={p.name} className="text-sm font-semibold" style={{ color: p.color }}>
            {p.name}: {p.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export const AnalyticsScreen: React.FC = () => {
  const { getDashboardStats, sessions, mcqs } = useStore();
  const stats = useMemo(() => getDashboardStats(), [getDashboardStats]);

  const subjectBarData = stats.bySubject.map((s) => ({
    subject: s.subject.length > 8 ? s.subject.substring(0, 8) + '.' : s.subject,
    fullSubject: s.subject,
    accuracy: s.accuracy,
    total: s.total,
    dueToday: s.dueToday,
  }));

  const weeklyData = stats.weeklyActivity.map((d) => ({
    day: format(parseISO(d.date), 'EEE'),
    solved: d.solved,
    correct: d.correct,
    accuracy: d.solved > 0 ? Math.round((d.correct / d.solved) * 100) : 0,
  }));

  const radarData = stats.bySubject.slice(0, 7).map((s) => ({
    subject: s.subject.length > 10 ? s.subject.substring(0, 10) : s.subject,
    accuracy: s.accuracy,
    fullMark: 100,
  }));

  const confidenceData = [
    { name: 'Easy', value: stats.confidenceBreakdown.easy, color: '#22c55e' },
    { name: 'Confused', value: stats.confidenceBreakdown.confused, color: '#eab308' },
    { name: 'Wrong', value: stats.confidenceBreakdown.wrong, color: '#ef4444' },
    { name: 'Important', value: stats.confidenceBreakdown.important, color: '#a855f7' },
    { name: 'Unseen', value: stats.confidenceBreakdown.unseen, color: '#64748b' },
  ];

  const totalMCQs = mcqs.length;

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-6xl mx-auto">
      {/* Overview Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {
            label: 'Overall Accuracy', value: `${stats.accuracy}%`,
            icon: TrendingUp, color: 'text-green-600 dark:text-green-400',
            bg: 'bg-green-50 dark:bg-green-900/20'
          },
          {
            label: 'Total Solved', value: `${stats.totalSolved}/${totalMCQs}`,
            icon: CheckCircle, color: 'text-blue-600 dark:text-blue-400',
            bg: 'bg-blue-50 dark:bg-blue-900/20'
          },
          {
            label: 'Sessions Done', value: sessions.length,
            icon: Zap, color: 'text-indigo-600 dark:text-indigo-400',
            bg: 'bg-indigo-50 dark:bg-indigo-900/20'
          },
          {
            label: 'Longest Streak', value: `${stats.longestStreak}d`,
            icon: Award, color: 'text-amber-600 dark:text-amber-400',
            bg: 'bg-amber-50 dark:bg-amber-900/20'
          },
        ].map(({ label, value, icon: Icon, color, bg }, i) => (
          <motion.div
            key={label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className="bg-white dark:bg-slate-800 rounded-2xl p-5 border border-slate-100 dark:border-slate-700"
          >
            <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center mb-3`}>
              <Icon className={`w-5 h-5 ${color}`} />
            </div>
            <p className="text-2xl font-bold text-slate-800 dark:text-white">{value}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{label}</p>
          </motion.div>
        ))}
      </div>

      {/* Weekly Activity */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5">
        <h3 className="font-semibold text-slate-800 dark:text-white mb-5 flex items-center gap-2">
          <BarChart2 className="w-4 h-4 text-indigo-500" />
          Weekly Activity
        </h3>
        {weeklyData.some((d) => d.solved > 0) ? (
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={weeklyData}>
              <defs>
                <linearGradient id="aGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="bGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b20" />
              <XAxis dataKey="day" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="solved" stroke="#6366f1" strokeWidth={2} fill="url(#aGrad)" name="Solved" />
              <Area type="monotone" dataKey="correct" stroke="#22c55e" strokeWidth={2} fill="url(#bGrad)" name="Correct" />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-48 flex items-center justify-center text-slate-400">
            <div className="text-center">
              <BarChart2 className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="text-sm">Complete sessions to see weekly activity</p>
            </div>
          </div>
        )}
      </div>

      {/* Subject Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5">
          <h3 className="font-semibold text-slate-800 dark:text-white mb-5 flex items-center gap-2">
            <Target className="w-4 h-4 text-indigo-500" />
            Subject Accuracy (Bar)
          </h3>
          {subjectBarData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={subjectBarData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b20" horizontal={false} />
                <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="subject" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} width={80} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="accuracy" radius={[0, 6, 6, 0]} name="Accuracy %">
                  {subjectBarData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.accuracy >= 70 ? '#22c55e' : entry.accuracy >= 50 ? '#eab308' : '#ef4444'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-slate-400">
              <p className="text-sm">Solve questions to see subject stats</p>
            </div>
          )}
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5">
          <h3 className="font-semibold text-slate-800 dark:text-white mb-5 flex items-center gap-2">
            <Brain className="w-4 h-4 text-violet-500" />
            Subject Radar
          </h3>
          {radarData.length >= 3 ? (
            <ResponsiveContainer width="100%" height={250}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="#334155" />
                <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10, fill: '#94a3b8' }} />
                <Radar name="Accuracy" dataKey="accuracy" stroke="#6366f1" fill="#6366f1" fillOpacity={0.25} strokeWidth={2} />
                <Tooltip content={<CustomTooltip />} />
              </RadarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-slate-400">
              <div className="text-center">
                <Brain className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p className="text-sm">Solve MCQs from 3+ subjects</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Confidence Breakdown Chart */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5">
        <h3 className="font-semibold text-slate-800 dark:text-white mb-5 flex items-center gap-2">
          <Brain className="w-4 h-4 text-purple-500" />
          Knowledge Confidence Breakdown
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
          {confidenceData.map((d) => {
            const percentage = totalMCQs > 0 ? Math.round((d.value / totalMCQs) * 100) : 0;
            return (
              <div key={d.name} className="text-center p-4 rounded-xl bg-slate-50 dark:bg-slate-700/50">
                <div
                  className="w-12 h-12 rounded-full mx-auto mb-3 flex items-center justify-center text-white font-bold text-sm"
                  style={{ backgroundColor: d.color }}
                >
                  {percentage}%
                </div>
                <p className="text-lg font-bold text-slate-800 dark:text-white">{d.value}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">{d.name}</p>
              </div>
            );
          })}
        </div>

        {/* Progress bars */}
        <div className="mt-5 space-y-3">
          {confidenceData.map((d) => {
            const percentage = totalMCQs > 0 ? Math.round((d.value / totalMCQs) * 100) : 0;
            return (
              <div key={d.name}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-500 dark:text-slate-400 font-medium">{d.name}</span>
                  <span className="text-slate-600 dark:text-slate-300">{d.value} ({percentage}%)</span>
                </div>
                <div className="h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${percentage}%` }}
                    transition={{ duration: 1, delay: 0.3 }}
                    className="h-full rounded-full"
                    style={{ backgroundColor: d.color }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Subject Deep Dive */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 overflow-hidden">
        <div className="p-5 border-b border-slate-100 dark:border-slate-700">
          <h3 className="font-semibold text-slate-800 dark:text-white flex items-center gap-2">
            <Target className="w-4 h-4 text-indigo-500" />
            Subject Performance Table
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-700">
                <th className="text-left py-3 px-5 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Subject</th>
                <th className="text-right py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Total</th>
                <th className="text-right py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Correct</th>
                <th className="text-right py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Accuracy</th>
                <th className="text-right py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Due</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 dark:divide-slate-700">
              {stats.bySubject.length > 0 ? stats.bySubject.map((s) => (
                <tr key={s.subject} className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                  <td className="py-3 px-5 text-sm font-medium text-slate-700 dark:text-slate-200">{s.subject}</td>
                  <td className="py-3 px-4 text-sm text-right text-slate-500 dark:text-slate-400">{s.total}</td>
                  <td className="py-3 px-4 text-sm text-right text-slate-500 dark:text-slate-400">{s.correct}</td>
                  <td className="py-3 px-4 text-right">
                    <span className={`text-sm font-semibold ${
                      s.accuracy >= 70 ? 'text-green-600 dark:text-green-400' :
                      s.accuracy >= 50 ? 'text-yellow-600 dark:text-yellow-400' :
                      'text-red-600 dark:text-red-400'
                    }`}>{s.accuracy}%</span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    {s.dueToday > 0 ? (
                      <span className="text-xs px-2 py-0.5 bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 rounded-full font-medium">
                        {s.dueToday}
                      </span>
                    ) : (
                      <CheckCircle className="w-4 h-4 text-green-400 ml-auto" />
                    )}
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={5} className="text-center py-10 text-slate-400 text-sm">
                    No data yet. Start solving MCQs to see analytics.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
