// ============================================================
// DASHBOARD SCREEN — Full analytics + quick actions
// ============================================================

import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, RadarChart, Radar, PolarGrid, PolarAngleAxis,
  Area, AreaChart
} from 'recharts';
import {
  Brain, Target, Zap, Clock, BookMarked, TrendingUp,
  Award, CheckCircle, XCircle, AlertCircle, Flame,
  ChevronRight, BookOpen, Play, Star
} from 'lucide-react';
import { useStore } from '../store/useStore';
import { format, parseISO } from 'date-fns';



const STAT_CARD_VARIANTS = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.07, duration: 0.4 }
  }),
};

interface StatCardProps {
  icon: React.ElementType;
  label: string;
  value: string | number;
  sub?: string;
  color: string;
  bgColor: string;
  index: number;
  onClick?: () => void;
}

const StatCard: React.FC<StatCardProps> = ({ icon: Icon, label, value, sub, color, bgColor, index, onClick }) => (
  <motion.div
    variants={STAT_CARD_VARIANTS}
    initial="hidden"
    animate="visible"
    custom={index}
    onClick={onClick}
    className={`p-5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 card-hover ${onClick ? 'cursor-pointer' : ''}`}
  >
    <div className="flex items-start justify-between mb-3">
      <div className={`w-11 h-11 ${bgColor} rounded-xl flex items-center justify-center`}>
        <Icon className={`w-5 h-5 ${color}`} />
      </div>
    </div>
    <p className="text-2xl font-bold text-slate-800 dark:text-white">{value}</p>
    <p className="text-sm font-medium text-slate-600 dark:text-slate-300 mt-1">{label}</p>
    {sub && <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5">{sub}</p>}
  </motion.div>
);

export const DashboardScreen: React.FC = () => {
  const { getDashboardStats, startSession, setCurrentPage } = useStore();
  const stats = useMemo(() => getDashboardStats(), [getDashboardStats]);

  const pieData = [
    { name: 'Easy', value: stats.confidenceBreakdown.easy, color: '#22c55e' },
    { name: 'Confused', value: stats.confidenceBreakdown.confused, color: '#eab308' },
    { name: 'Wrong', value: stats.confidenceBreakdown.wrong, color: '#ef4444' },
    { name: 'Important', value: stats.confidenceBreakdown.important, color: '#a855f7' },
    { name: 'Unseen', value: stats.confidenceBreakdown.unseen, color: '#64748b' },
  ].filter((d) => d.value > 0);

  const weeklyData = stats.weeklyActivity.map((d) => ({
    day: format(parseISO(d.date), 'EEE'),
    solved: d.solved,
    correct: d.correct,
    accuracy: d.solved > 0 ? Math.round((d.correct / d.solved) * 100) : 0,
  }));

  const subjectRadarData = stats.bySubject.slice(0, 6).map((s) => ({
    subject: s.subject.length > 10 ? s.subject.substring(0, 10) + '.' : s.subject,
    accuracy: s.accuracy,
    fullMark: 100,
  }));

  const QUICK_ACTIONS = [
    {
      icon: Zap,
      label: 'Start Mixed Revision',
      desc: 'Random questions from all subjects',
      color: 'from-amber-500 to-orange-500',
      action: () => startSession('mixed'),
    },
    {
      icon: Target,
      label: 'Wrong Questions',
      desc: `${stats.confidenceBreakdown.wrong} questions to retry`,
      color: 'from-red-500 to-rose-500',
      action: () => startSession('wrong'),
    },
    {
      icon: Clock,
      label: 'Due Today',
      desc: `${stats.dueToday} MCQs need revision`,
      color: 'from-green-500 to-emerald-500',
      action: () => startSession('due_today'),
    },
    {
      icon: BookOpen,
      label: 'PYQ Practice',
      desc: 'Previous year questions',
      color: 'from-indigo-500 to-violet-500',
      action: () => startSession('pyq'),
    },
    {
      icon: Brain,
      label: 'Confused Topics',
      desc: `${stats.confidenceBreakdown.confused} to clarify`,
      color: 'from-yellow-500 to-amber-500',
      action: () => startSession('confused'),
    },
    {
      icon: Zap,
      label: 'Rapid Revision',
      desc: 'High-speed 10 MCQ sprint',
      color: 'from-cyan-500 to-blue-500',
      action: () => startSession('rapid', { limit: 10 }),
    },
  ];

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Welcome Banner */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden bg-gradient-to-br from-indigo-600 via-violet-600 to-purple-700 rounded-2xl p-6 lg:p-8 text-white"
      >
        <div className="absolute right-0 top-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
        <div className="absolute right-20 bottom-0 w-40 h-40 bg-white/5 rounded-full translate-y-1/2" />
        <div className="relative z-10">
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Flame className="w-5 h-5 text-amber-300" />
                <span className="text-amber-200 text-sm font-medium">
                  {stats.currentStreak > 0 ? `${stats.currentStreak} day streak! 🔥` : 'Start your streak today!'}
                </span>
              </div>
              <h2 className="text-2xl lg:text-3xl font-bold mb-1">
                {stats.dueToday > 0
                  ? `${stats.dueToday} MCQs due today`
                  : "You're all caught up! 🎉"}
              </h2>
              <p className="text-indigo-200">
                {stats.totalSolved > 0
                  ? `${stats.totalSolved} solved · ${stats.accuracy}% accuracy overall`
                  : 'Start your first revision session'}
              </p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => startSession('due_today')}
                className="px-5 py-2.5 bg-white text-indigo-700 font-semibold rounded-xl hover:bg-indigo-50 transition-colors flex items-center gap-2 text-sm"
              >
                <Play className="w-4 h-4" />
                Revise Now
              </button>
              <button
                onClick={() => startSession('mixed')}
                className="px-5 py-2.5 bg-white/20 text-white font-semibold rounded-xl hover:bg-white/30 transition-colors flex items-center gap-2 text-sm"
              >
                <Zap className="w-4 h-4" />
                Mixed Test
              </button>
            </div>
          </div>

          {/* Progress bar */}
          <div className="mt-4 flex items-center gap-3">
            <div className="flex-1 h-2 bg-white/20 rounded-full overflow-hidden">
              <div
                className="h-full bg-white rounded-full transition-all duration-1000"
                style={{ width: `${Math.min(stats.accuracy, 100)}%` }}
              />
            </div>
            <span className="text-white/80 text-sm font-medium">{stats.accuracy}%</span>
          </div>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard index={0} icon={BookOpen} label="Total Solved" value={stats.totalSolved}
          sub="questions answered" color="text-blue-600 dark:text-blue-400"
          bgColor="bg-blue-50 dark:bg-blue-900/30" />
        <StatCard index={1} icon={TrendingUp} label="Accuracy" value={`${stats.accuracy}%`}
          sub="correct responses" color="text-green-600 dark:text-green-400"
          bgColor="bg-green-50 dark:bg-green-900/30" />
        <StatCard index={2} icon={Flame} label="Day Streak" value={stats.currentStreak}
          sub="consecutive days" color="text-orange-600 dark:text-orange-400"
          bgColor="bg-orange-50 dark:bg-orange-900/30" />
        <StatCard index={3} icon={Clock} label="Due Today" value={stats.dueToday}
          sub="pending revisions" color="text-violet-600 dark:text-violet-400"
          bgColor="bg-violet-50 dark:bg-violet-900/30"
          onClick={() => startSession('due_today')} />
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-base font-semibold text-slate-700 dark:text-slate-200 mb-3">Quick Revision Modes</h3>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
          {QUICK_ACTIONS.map(({ icon: Icon, label, desc, color, action }) => (
            <button
              key={label}
              onClick={action}
              className="text-left p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 card-hover transition-all group"
            >
              <div className={`w-10 h-10 bg-gradient-to-br ${color} rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
              <p className="font-semibold text-slate-800 dark:text-white text-sm">{label}</p>
              <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5">{desc}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Weekly Activity */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-800 dark:text-white">Weekly Activity</h3>
            <span className="text-xs text-slate-400">Last 7 days</span>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={weeklyData}>
              <defs>
                <linearGradient id="solvedGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="correctGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="day" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1e293b',
                  border: 'none',
                  borderRadius: '12px',
                  color: '#f1f5f9',
                  fontSize: 12,
                }}
              />
              <Area type="monotone" dataKey="solved" stroke="#6366f1" strokeWidth={2} fill="url(#solvedGrad)" name="Solved" />
              <Area type="monotone" dataKey="correct" stroke="#22c55e" strokeWidth={2} fill="url(#correctGrad)" name="Correct" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Confidence Breakdown */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5">
          <h3 className="font-semibold text-slate-800 dark:text-white mb-4">Confidence Breakdown</h3>
          {pieData.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={140}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={65}
                    dataKey="value"
                    strokeWidth={0}
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1e293b',
                      border: 'none',
                      borderRadius: '8px',
                      color: '#f1f5f9',
                      fontSize: 12,
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-2 space-y-1.5">
                {pieData.map((d) => (
                  <div key={d.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: d.color }} />
                      <span className="text-xs text-slate-600 dark:text-slate-300">{d.name}</span>
                    </div>
                    <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">{d.value}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-40 text-slate-400">
              <Brain className="w-10 h-10 mb-2 opacity-30" />
              <p className="text-sm">No data yet</p>
              <p className="text-xs mt-1">Start solving MCQs!</p>
            </div>
          )}
        </div>
      </div>

      {/* Subject Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Subject Accuracy */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-800 dark:text-white">Subject Accuracy</h3>
            <button
              onClick={() => setCurrentPage('analytics')}
              className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
            >
              View all <ChevronRight className="w-3 h-3" />
            </button>
          </div>
          <div className="space-y-3">
            {stats.bySubject.slice(0, 6).map((s) => (
              <div key={s.subject}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-slate-600 dark:text-slate-300 truncate">{s.subject}</span>
                  <div className="flex items-center gap-2">
                    {s.dueToday > 0 && (
                      <span className="text-xs text-amber-500">{s.dueToday} due</span>
                    )}
                    <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">{s.accuracy}%</span>
                  </div>
                </div>
                <div className="h-1.5 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{
                      width: `${s.accuracy}%`,
                      backgroundColor: s.accuracy >= 70 ? '#22c55e' : s.accuracy >= 50 ? '#eab308' : '#ef4444'
                    }}
                  />
                </div>
              </div>
            ))}
            {stats.bySubject.length === 0 && (
              <div className="text-center py-8 text-slate-400">
                <Target className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p className="text-sm">Solve MCQs to see subject stats</p>
              </div>
            )}
          </div>
        </div>

        {/* Radar Chart */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5">
          <h3 className="font-semibold text-slate-800 dark:text-white mb-4">Subject Radar</h3>
          {subjectRadarData.length >= 3 ? (
            <ResponsiveContainer width="100%" height={200}>
              <RadarChart data={subjectRadarData}>
                <PolarGrid stroke="#e2e8f0" />
                <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10, fill: '#94a3b8' }} />
                <Radar name="Accuracy" dataKey="accuracy" stroke="#6366f1" fill="#6366f1" fillOpacity={0.2} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1e293b',
                    border: 'none',
                    borderRadius: '8px',
                    color: '#f1f5f9',
                    fontSize: 12,
                  }}
                />
              </RadarChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex flex-col items-center justify-center h-44 text-slate-400">
              <TrendingUp className="w-8 h-8 mb-2 opacity-30" />
              <p className="text-sm text-center">Solve questions from 3+ subjects to unlock radar chart</p>
            </div>
          )}
        </div>
      </div>

      {/* Recent Sessions */}
      {stats.recentSessions.length > 0 && (
        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-800 dark:text-white">Recent Sessions</h3>
          </div>
          <div className="space-y-3">
            {stats.recentSessions.map((session) => {
              const accuracy = session.total > 0
                ? Math.round((session.score / session.total) * 100)
                : 0;
              return (
                <div
                  key={session.id}
                  className="flex items-center gap-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-700/50"
                >
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    accuracy >= 70 ? 'bg-green-100 dark:bg-green-900/30' :
                    accuracy >= 50 ? 'bg-yellow-100 dark:bg-yellow-900/30' :
                    'bg-red-100 dark:bg-red-900/30'
                  }`}>
                    {accuracy >= 70
                      ? <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
                      : accuracy >= 50
                      ? <AlertCircle className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
                      : <XCircle className="w-5 h-5 text-red-600 dark:text-red-400" />
                    }
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-700 dark:text-slate-200 capitalize">
                      {session.mode.replace('_', ' ')} Mode
                    </p>
                    <p className="text-xs text-slate-400">
                      {session.completedAt
                        ? format(parseISO(session.completedAt), 'MMM dd, h:mm a')
                        : 'In progress'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-slate-800 dark:text-white">
                      {session.score}/{session.total}
                    </p>
                    <p className={`text-xs font-medium ${
                      accuracy >= 70 ? 'text-green-600 dark:text-green-400' :
                      accuracy >= 50 ? 'text-yellow-600 dark:text-yellow-400' :
                      'text-red-600 dark:text-red-400'
                    }`}>
                      {accuracy}%
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Bookmarked + Confidence Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Bookmarked', value: stats.bookmarked, icon: BookMarked, color: 'text-rose-500', bg: 'bg-rose-50 dark:bg-rose-900/20', action: () => startSession('bookmarked') },
          { label: 'Wrong', value: stats.confidenceBreakdown.wrong, icon: XCircle, color: 'text-red-500', bg: 'bg-red-50 dark:bg-red-900/20', action: () => startSession('wrong') },
          { label: 'Important', value: stats.confidenceBreakdown.important, icon: Star, color: 'text-purple-500', bg: 'bg-purple-50 dark:bg-purple-900/20', action: () => startSession('important') },
          { label: 'Mastered', value: stats.confidenceBreakdown.easy, icon: Award, color: 'text-green-500', bg: 'bg-green-50 dark:bg-green-900/20', action: () => startSession('mixed') },
        ].map(({ label, value, icon: Icon, color, bg, action }, i) => (
          <motion.button
            key={label}
            variants={STAT_CARD_VARIANTS}
            initial="hidden"
            animate="visible"
            custom={i}
            onClick={action}
            className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 text-left card-hover"
          >
            <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center mb-3`}>
              <Icon className={`w-5 h-5 ${color}`} />
            </div>
            <p className="text-xl font-bold text-slate-800 dark:text-white">{value}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{label}</p>
          </motion.button>
        ))}
      </div>
    </div>
  );
};
