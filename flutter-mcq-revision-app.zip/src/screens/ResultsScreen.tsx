// ============================================================
// RESULTS SCREEN — Post-session performance analysis
// ============================================================

import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  CheckCircle, XCircle, Target, RotateCcw,
  Home, TrendingUp
} from 'lucide-react';
import { useStore } from '../store/useStore';
import { format, parseISO } from 'date-fns';

export const ResultsScreen: React.FC = () => {
  const { sessions, mcqs, startSession, setCurrentPage } = useStore();
  const lastSession = sessions[0];

  const analysis = useMemo(() => {
    if (!lastSession) return null;

    const results = lastSession.mcqIds.map((mcqId) => {
      const mcq = mcqs.find((m) => m.id === mcqId);
      const answer = lastSession.answers[mcqId];
      const confidence = lastSession.confidenceMarks[mcqId];
      const isAnswered = answer !== null && answer !== undefined;
      const isCorrect = isAnswered && mcq ? answer === mcq.correctAnswer : false;
      return { mcq, answer, confidence, isAnswered, isCorrect };
    }).filter((r) => r.mcq);

    const answered = results.filter((r) => r.isAnswered).length;
    const correct = results.filter((r) => r.isCorrect).length;
    const wrong = results.filter((r) => r.isAnswered && !r.isCorrect).length;
    const skipped = results.filter((r) => !r.isAnswered).length;
    const accuracy = answered > 0 ? Math.round((correct / answered) * 100) : 0;

    return { results, answered, correct, wrong, skipped, accuracy };
  }, [lastSession, mcqs]);

  if (!lastSession || !analysis) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <p className="text-slate-500 dark:text-slate-400">No results to display</p>
          <button onClick={() => setCurrentPage('dashboard')} className="mt-4 px-6 py-2 bg-indigo-600 text-white rounded-xl">
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const { correct, wrong, skipped, accuracy, results } = analysis;
  const total = lastSession.mcqIds.length;
  const grade = accuracy >= 80 ? 'Excellent' : accuracy >= 60 ? 'Good' : accuracy >= 40 ? 'Average' : 'Needs Work';

  const gradeBg = accuracy >= 80 ? 'from-green-500 to-emerald-500' : accuracy >= 60 ? 'from-blue-500 to-indigo-500' : accuracy >= 40 ? 'from-yellow-500 to-amber-500' : 'from-red-500 to-rose-500';

  return (
    <div className="p-4 lg:p-6 max-w-3xl mx-auto space-y-6">
      {/* Score Card */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className={`relative overflow-hidden bg-gradient-to-br ${gradeBg} rounded-3xl p-8 text-white text-center`}
      >
        <div className="absolute inset-0">
          <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2" />
        </div>
        <div className="relative z-10">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', delay: 0.2, stiffness: 200 }}
            className="text-7xl font-black mb-2"
          >
            {accuracy}%
          </motion.div>
          <div className="text-2xl font-bold mb-1 opacity-90">{grade}!</div>
          <p className="text-white/70">
            {lastSession.mode.replace('_', ' ')} Mode · {format(parseISO(lastSession.startedAt), 'MMM dd, yyyy')}
          </p>
        </div>
      </motion.div>

      {/* Score Breakdown */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Correct', value: correct, icon: CheckCircle, color: 'text-green-600 dark:text-green-400', bg: 'bg-green-50 dark:bg-green-900/20' },
          { label: 'Wrong', value: wrong, icon: XCircle, color: 'text-red-600 dark:text-red-400', bg: 'bg-red-50 dark:bg-red-900/20' },
          { label: 'Skipped', value: skipped, icon: Target, color: 'text-slate-500 dark:text-slate-400', bg: 'bg-slate-50 dark:bg-slate-700' },
        ].map(({ label, value, icon: Icon, color, bg }, i) => (
          <motion.div
            key={label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * i }}
            className={`${bg} rounded-2xl p-4 text-center border border-transparent`}
          >
            <Icon className={`w-6 h-6 ${color} mx-auto mb-2`} />
            <p className="text-2xl font-bold text-slate-800 dark:text-white">{value}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">{label}</p>
          </motion.div>
        ))}
      </div>

      {/* Performance Analysis */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-5">
        <h3 className="font-semibold text-slate-800 dark:text-white mb-4 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-indigo-500" />
          Performance Analysis
        </h3>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-slate-500 dark:text-slate-400">Accuracy</span>
              <span className="font-semibold text-slate-700 dark:text-slate-200">{accuracy}%</span>
            </div>
            <div className="h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${accuracy}%` }}
                transition={{ duration: 1, delay: 0.5 }}
                className="h-full bg-indigo-500 rounded-full"
              />
            </div>
          </div>
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-slate-500 dark:text-slate-400">Completion</span>
              <span className="font-semibold text-slate-700 dark:text-slate-200">
                {total > 0 ? Math.round(((correct + wrong) / total) * 100) : 0}%
              </span>
            </div>
            <div className="h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${total > 0 ? ((correct + wrong) / total) * 100 : 0}%` }}
                transition={{ duration: 1, delay: 0.6 }}
                className="h-full bg-green-500 rounded-full"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => startSession(lastSession.mode, {
            subject: lastSession.subject,
            examCategory: lastSession.examCategory,
          })}
          className="flex items-center justify-center gap-2 py-3 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
          Retry Session
        </button>
        <button
          onClick={() => setCurrentPage('dashboard')}
          className="flex items-center justify-center gap-2 py-3 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
        >
          <Home className="w-4 h-4" />
          Dashboard
        </button>
        {wrong > 0 && (
          <button
            onClick={() => startSession('wrong')}
            className="col-span-2 flex items-center justify-center gap-2 py-3 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 font-semibold rounded-xl hover:bg-red-100 dark:hover:bg-red-900/30 border border-red-100 dark:border-red-800 transition-colors"
          >
            <Target className="w-4 h-4" />
            Revise {wrong} Wrong Questions Now
          </button>
        )}
      </div>

      {/* Question Review */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 overflow-hidden">
        <div className="p-4 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
          <h3 className="font-semibold text-slate-800 dark:text-white">Question Review</h3>
          <span className="text-xs text-slate-400">{total} questions</span>
        </div>
        <div className="divide-y divide-slate-100 dark:divide-slate-700 max-h-96 overflow-y-auto">
          {results.slice(0, 15).map(({ mcq, isCorrect, isAnswered, confidence }, idx) => {
            if (!mcq) return null;
            return (
              <div key={idx} className="p-4 flex items-start gap-3">
                <div className={`flex-shrink-0 w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                  !isAnswered
                    ? 'bg-slate-100 dark:bg-slate-700 text-slate-400'
                    : isCorrect
                    ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400'
                    : 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400'
                }`}>
                  {idx + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-700 dark:text-slate-200 line-clamp-2">{mcq.question}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs text-slate-400">{mcq.subject}</span>
                    {confidence && (
                      <span className={`text-xs px-1.5 py-0.5 rounded-full font-medium badge-${confidence}`}>
                        {confidence}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex-shrink-0">
                  {!isAnswered ? (
                    <span className="text-xs text-slate-400">Skipped</span>
                  ) : isCorrect ? (
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-500" />
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
