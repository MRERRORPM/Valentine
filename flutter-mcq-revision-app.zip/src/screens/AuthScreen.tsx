// ============================================================
// AUTHENTICATION SCREEN — Login / Signup / Forgot Password
// ============================================================

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Eye, EyeOff, BookOpen, Brain, Target, Zap, CheckCircle, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import { useStore } from '../store/useStore';
import { ExamCategory } from '../types';

type AuthMode = 'login' | 'signup' | 'forgot';

const EXAM_OPTIONS: { value: ExamCategory; label: string }[] = [
  { value: 'NORCET', label: 'NORCET (Nursing)' },
  { value: 'AIIMS', label: 'AIIMS Nursing Officer' },
  { value: 'NEET', label: 'NEET PG / UG' },
  { value: 'UPSC', label: 'UPSC CMS' },
  { value: 'NURSING', label: 'State Nursing Exams' },
];

const FEATURES = [
  { icon: Brain, text: 'Spaced Repetition Algorithm', color: 'text-violet-400' },
  { icon: Target, text: 'PYQ from AIIMS, NORCET, NEET', color: 'text-blue-400' },
  { icon: Zap, text: 'Smart Revision Scheduling', color: 'text-amber-400' },
  { icon: CheckCircle, text: '50,000+ MCQs with Explanations', color: 'text-green-400' },
];

export const AuthScreen: React.FC = () => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  // Login state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Signup state
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupConfirm, setSignupConfirm] = useState('');
  const [signupExam, setSignupExam] = useState<ExamCategory>('NORCET');

  // Forgot
  const [forgotEmail, setForgotEmail] = useState('');

  const { login, signup } = useStore();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail || !loginPassword) {
      toast.error('Please fill all fields');
      return;
    }
    setLoading(true);
    try {
      const success = await login(loginEmail, loginPassword);
      if (success) {
        toast.success('Welcome back! 🎉');
      } else {
        toast.error('Invalid credentials. Try: student@medrevise.in / student123');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!signupName || !signupEmail || !signupPassword) {
      toast.error('Please fill all fields');
      return;
    }
    if (signupPassword !== signupConfirm) {
      toast.error('Passwords do not match');
      return;
    }
    if (signupPassword.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }
    setLoading(true);
    try {
      await signup(signupName, signupEmail, signupPassword, signupExam);
      toast.success('Account created! Welcome to MedRevise Pro! 🎓');
    } finally {
      setLoading(false);
    }
  };

  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) {
      toast.error('Enter your email');
      return;
    }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1000));
    setLoading(false);
    toast.success('Password reset email sent! (Demo mode — check console)');
    setMode('login');
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Panel */}
      <div className="hidden lg:flex lg:w-[55%] relative overflow-hidden bg-gradient-to-br from-indigo-900 via-violet-900 to-purple-900">
        {/* Animated background */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-violet-500/20 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
          <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-purple-500/10 rounded-full blur-2xl -translate-x-1/2 -translate-y-1/2" />
        </div>

        <div className="relative z-10 flex flex-col justify-center px-16 py-12">
          {/* Logo */}
          <div className="flex items-center gap-3 mb-16">
            <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm">
              <BookOpen className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">MedRevise Pro</h1>
              <p className="text-indigo-300 text-sm">Smart Medical Exam Prep</p>
            </div>
          </div>

          {/* Headline */}
          <div className="mb-10">
            <h2 className="text-4xl font-bold text-white leading-tight mb-4">
              Ace your medical<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-300 to-pink-300">
                competitive exams
              </span>
            </h2>
            <p className="text-indigo-200 text-lg leading-relaxed">
              India's most intelligent MCQ revision platform with spaced repetition,
              PYQ tracking, and AI-powered insights.
            </p>
          </div>

          {/* Features */}
          <div className="space-y-4">
            {FEATURES.map(({ icon: Icon, text, color }) => (
              <div key={text} className="flex items-center gap-3">
                <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                  <Icon className={`w-4 h-4 ${color}`} />
                </div>
                <span className="text-white/90 font-medium">{text}</span>
              </div>
            ))}
          </div>

          {/* Exam badges */}
          <div className="mt-12 flex flex-wrap gap-2">
            {['NORCET', 'AIIMS', 'NEET', 'UPSC', 'Nursing'].map((exam) => (
              <span
                key={exam}
                className="px-3 py-1 bg-white/10 rounded-full text-white/80 text-sm font-medium backdrop-blur-sm border border-white/20"
              >
                {exam}
              </span>
            ))}
          </div>

          {/* Demo credentials */}
          <div className="mt-8 p-4 bg-white/10 rounded-2xl backdrop-blur-sm border border-white/20">
            <p className="text-white/60 text-xs font-medium uppercase tracking-wider mb-2">Demo Credentials</p>
            <div className="text-sm space-y-1">
              <p className="text-white/90"><span className="text-violet-300">Student:</span> student@medrevise.in / student123</p>
              <p className="text-white/90"><span className="text-amber-300">Admin:</span> admin@medrevise.in / admin123</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel */}
      <div className="flex-1 flex items-center justify-center p-6 bg-slate-50 dark:bg-slate-900">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="flex lg:hidden items-center gap-2 justify-center mb-8">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-slate-800 dark:text-white">MedRevise Pro</span>
          </div>

          <AnimatePresence mode="wait">
            {mode === 'login' && (
              <motion.div
                key="login"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Welcome back</h2>
                  <p className="text-slate-500 dark:text-slate-400 mt-1">Continue your revision journey</p>
                </div>

                <form onSubmit={handleLogin} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                      Email Address
                    </label>
                    <input
                      type="email"
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:border-indigo-500 dark:focus:border-indigo-400 transition-colors"
                      placeholder="student@medrevise.in"
                      autoComplete="email"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                      Password
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:border-indigo-500 dark:focus:border-indigo-400 transition-colors pr-12"
                        placeholder="••••••••"
                        autoComplete="current-password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1"
                      >
                        {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                    <div className="flex justify-end mt-1">
                      <button
                        type="button"
                        onClick={() => setMode('forgot')}
                        className="text-sm text-indigo-600 dark:text-indigo-400 hover:underline"
                      >
                        Forgot password?
                      </button>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 px-6 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-colors mt-2 flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : 'Sign In'}
                  </button>
                </form>

                <div className="mt-6 text-center">
                  <p className="text-slate-500 dark:text-slate-400">
                    New to MedRevise?{' '}
                    <button
                      onClick={() => setMode('signup')}
                      className="text-indigo-600 dark:text-indigo-400 font-medium hover:underline"
                    >
                      Create account
                    </button>
                  </p>
                </div>

                {/* Quick login */}
                <div className="mt-6 p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl border border-indigo-100 dark:border-indigo-800">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="w-4 h-4 text-indigo-500" />
                    <span className="text-xs font-medium text-indigo-700 dark:text-indigo-400">Quick Demo Login</span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => { setLoginEmail('student@medrevise.in'); setLoginPassword('student123'); }}
                      className="flex-1 text-xs py-2 bg-indigo-100 dark:bg-indigo-800/50 text-indigo-700 dark:text-indigo-300 rounded-lg hover:bg-indigo-200 dark:hover:bg-indigo-700/50 transition-colors font-medium"
                    >
                      Student Login
                    </button>
                    <button
                      onClick={() => { setLoginEmail('admin@medrevise.in'); setLoginPassword('admin123'); }}
                      className="flex-1 text-xs py-2 bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 rounded-lg hover:bg-amber-200 dark:hover:bg-amber-800/30 transition-colors font-medium"
                    >
                      Admin Login
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {mode === 'signup' && (
              <motion.div
                key="signup"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Create your account</h2>
                  <p className="text-slate-500 dark:text-slate-400 mt-1">Start your exam preparation journey</p>
                </div>

                <form onSubmit={handleSignup} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Full Name</label>
                    <input
                      type="text"
                      value={signupName}
                      onChange={(e) => setSignupName(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:border-indigo-500 transition-colors"
                      placeholder="Dr. Priya Sharma"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Email</label>
                    <input
                      type="email"
                      value={signupEmail}
                      onChange={(e) => setSignupEmail(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:border-indigo-500 transition-colors"
                      placeholder="your@email.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Target Exam</label>
                    <select
                      value={signupExam}
                      onChange={(e) => setSignupExam(e.target.value as ExamCategory)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:border-indigo-500 transition-colors"
                    >
                      {EXAM_OPTIONS.map((opt) => (
                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Password</label>
                      <input
                        type="password"
                        value={signupPassword}
                        onChange={(e) => setSignupPassword(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:border-indigo-500 transition-colors"
                        placeholder="Min 6 chars"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Confirm</label>
                      <input
                        type="password"
                        value={signupConfirm}
                        onChange={(e) => setSignupConfirm(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:border-indigo-500 transition-colors"
                        placeholder="Repeat"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 px-6 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white font-semibold rounded-xl transition-colors flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : 'Create Account'}
                  </button>
                </form>

                <div className="mt-6 text-center">
                  <button onClick={() => setMode('login')} className="text-indigo-600 dark:text-indigo-400 hover:underline">
                    Already have an account? Sign in
                  </button>
                </div>
              </motion.div>
            )}

            {mode === 'forgot' && (
              <motion.div
                key="forgot"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Reset Password</h2>
                  <p className="text-slate-500 dark:text-slate-400 mt-1">Enter your email to receive a reset link</p>
                </div>

                <form onSubmit={handleForgot} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Email</label>
                    <input
                      type="email"
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:border-indigo-500 transition-colors"
                      placeholder="your@email.com"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white font-semibold rounded-xl transition-colors flex items-center justify-center"
                  >
                    {loading ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : 'Send Reset Link'}
                  </button>
                </form>
                <div className="mt-6 text-center">
                  <button onClick={() => setMode('login')} className="text-indigo-600 dark:text-indigo-400 hover:underline">
                    ← Back to login
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
