# classes14.dex

.class final Lcom/vdocipher/PlaybackInfo$QualityLabels$QualityLabelsVerifier;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumVerifier;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$QualityLabels;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "QualityLabelsVerifier"
.end annotation


# static fields
.field static final INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 148
    new-instance v0, Lcom/vdocipher/PlaybackInfo$QualityLabels$QualityLabelsVerifier;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$QualityLabels$QualityLabelsVerifier;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$QualityLabels$QualityLabelsVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 146
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public isInRange(I)Z
    .registers 2

    .line 151
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$QualityLabels;->forNumber(I)Lcom/vdocipher/PlaybackInfo$QualityLabels;

    move-result-object p1

    if-eqz p1, :cond_8

    const/4 p1, 0x1

    return p1

    :cond_8
    const/4 p1, 0x0

    return p1
.end method
