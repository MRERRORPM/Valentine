# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Event$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$EventOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$Event;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$Event;",
        "Lcom/vdocipher/PlaybackSession$Event$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$EventOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 5913
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Event;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Event;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Event$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearName()Lcom/vdocipher/PlaybackSession$Event$Builder;
    .registers 2

    .line 5958
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Event$Builder;->copyOnWrite()V

    .line 5959
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Event$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Event;->-$$Nest$mclearName(Lcom/vdocipher/PlaybackSession$Event;)V

    return-object p0
.end method

.method public clearPayload()Lcom/vdocipher/PlaybackSession$Event$Builder;
    .registers 2

    .line 5996
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Event$Builder;->copyOnWrite()V

    .line 5997
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Event$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Event;->-$$Nest$mclearPayload(Lcom/vdocipher/PlaybackSession$Event;)V

    return-object p0
.end method

.method public clearTime()Lcom/vdocipher/PlaybackSession$Event$Builder;
    .registers 2

    .line 6035
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Event$Builder;->copyOnWrite()V

    .line 6036
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Event$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Event;->-$$Nest$mclearTime(Lcom/vdocipher/PlaybackSession$Event;)V

    return-object p0
.end method

.method public getName()Lcom/vdocipher/PlaybackSession$EventName;
    .registers 2

    .line 5941
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Event$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Event;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Event;->getName()Lcom/vdocipher/PlaybackSession$EventName;

    move-result-object v0

    return-object v0
.end method

.method public getNameValue()I
    .registers 2

    .line 5923
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Event$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Event;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Event;->getNameValue()I

    move-result v0

    return v0
.end method

.method public getPayload()Ljava/lang/String;
    .registers 2

    .line 5969
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Event$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Event;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Event;->getPayload()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getPayloadBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 5978
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Event$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Event;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Event;->getPayloadBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getTime()I
    .registers 2

    .line 6018
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Event$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Event;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Event;->getTime()I

    move-result v0

    return v0
.end method

.method public setName(Lcom/vdocipher/PlaybackSession$EventName;)Lcom/vdocipher/PlaybackSession$Event$Builder;
    .registers 3

    .line 5949
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Event$Builder;->copyOnWrite()V

    .line 5950
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Event$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Event;->-$$Nest$msetName(Lcom/vdocipher/PlaybackSession$Event;Lcom/vdocipher/PlaybackSession$EventName;)V

    return-object p0
.end method

.method public setNameValue(I)Lcom/vdocipher/PlaybackSession$Event$Builder;
    .registers 3

    .line 5931
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Event$Builder;->copyOnWrite()V

    .line 5932
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Event$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Event;->-$$Nest$msetNameValue(Lcom/vdocipher/PlaybackSession$Event;I)V

    return-object p0
.end method

.method public setPayload(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Event$Builder;
    .registers 3

    .line 5987
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Event$Builder;->copyOnWrite()V

    .line 5988
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Event$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Event;->-$$Nest$msetPayload(Lcom/vdocipher/PlaybackSession$Event;Ljava/lang/String;)V

    return-object p0
.end method

.method public setPayloadBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Event$Builder;
    .registers 3

    .line 6007
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Event$Builder;->copyOnWrite()V

    .line 6008
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Event$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Event;->-$$Nest$msetPayloadBytes(Lcom/vdocipher/PlaybackSession$Event;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setTime(I)Lcom/vdocipher/PlaybackSession$Event$Builder;
    .registers 3

    .line 6026
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Event$Builder;->copyOnWrite()V

    .line 6027
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Event$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Event;->-$$Nest$msetTime(Lcom/vdocipher/PlaybackSession$Event;I)V

    return-object p0
.end method
