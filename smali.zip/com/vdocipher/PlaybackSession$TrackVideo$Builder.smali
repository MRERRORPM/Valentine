# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$TrackVideoOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$TrackVideo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$TrackVideo;",
        "Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$TrackVideoOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 9552
    invoke-static {}, Lcom/vdocipher/PlaybackSession$TrackVideo;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$TrackVideo;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearBitrateKbps()Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;
    .registers 2

    .line 9579
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;->copyOnWrite()V

    .line 9580
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$TrackVideo;->-$$Nest$mclearBitrateKbps(Lcom/vdocipher/PlaybackSession$TrackVideo;)V

    return-object p0
.end method

.method public getBitrateKbps()I
    .registers 2

    .line 9562
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$TrackVideo;->getBitrateKbps()I

    move-result v0

    return v0
.end method

.method public setBitrateKbps(I)Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;
    .registers 3

    .line 9570
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;->copyOnWrite()V

    .line 9571
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$TrackVideo;->-$$Nest$msetBitrateKbps(Lcom/vdocipher/PlaybackSession$TrackVideo;I)V

    return-object p0
.end method
