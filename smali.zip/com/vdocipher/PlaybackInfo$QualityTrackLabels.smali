# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$QualityTrackLabelsOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "QualityTrackLabels"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;",
        "Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$QualityTrackLabelsOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

.field public static final LABEL_FIELD_NUMBER:I = 0x2

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;",
            ">;"
        }
    .end annotation
.end field

.field public static final SEPARATOR_FIELD_NUMBER:I = 0x1

.field private static final label_converter_:Lcom/google/protobuf/Internal$ListAdapter$Converter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ListAdapter$Converter<",
            "Ljava/lang/Integer;",
            "Lcom/vdocipher/PlaybackInfo$QualityLabels;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private labelMemoizedSerializedSize:I

.field private label_:Lcom/google/protobuf/Internal$IntList;

.field private separator_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$maddAllLabel(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->addAllLabel(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllLabelValue(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->addAllLabelValue(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddLabel(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;Lcom/vdocipher/PlaybackInfo$QualityLabels;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->addLabel(Lcom/vdocipher/PlaybackInfo$QualityLabels;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddLabelValue(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->addLabelValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLabel(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->clearLabel()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSeparator(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->clearSeparator()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLabel(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;ILcom/vdocipher/PlaybackInfo$QualityLabels;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->setLabel(ILcom/vdocipher/PlaybackInfo$QualityLabels;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLabelValue(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;II)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->setLabelValue(II)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSeparator(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->setSeparator(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSeparatorBytes(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->setSeparatorBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 1198
    new-instance v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_converter_:Lcom/google/protobuf/Internal$ListAdapter$Converter;

    .line 1647
    new-instance v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;-><init>()V

    .line 1650
    sput-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    .line 1651
    const-class v1, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 1144
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 1145
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->separator_:Ljava/lang/String;

    .line 1146
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->emptyIntList()Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_:Lcom/google/protobuf/Internal$IntList;

    return-void
.end method

.method private addAllLabel(Ljava/lang/Iterable;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$QualityLabels;",
            ">;)V"
        }
    .end annotation

    .line 1286
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->ensureLabelIsMutable()V

    .line 1287
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_7
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1d

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 1288
    iget-object v1, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_:Lcom/google/protobuf/Internal$IntList;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$QualityLabels;->getNumber()I

    move-result v0

    invoke-interface {v1, v0}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    goto :goto_7

    :cond_1d
    return-void
.end method

.method private addAllLabelValue(Ljava/lang/Iterable;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .line 1320
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->ensureLabelIsMutable()V

    .line 1321
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_7
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1d

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 1322
    iget-object v1, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v1, v0}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    goto :goto_7

    :cond_1d
    return-void
.end method

.method private addLabel(Lcom/vdocipher/PlaybackInfo$QualityLabels;)V
    .registers 3

    .line 1276
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1277
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->ensureLabelIsMutable()V

    .line 1278
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_:Lcom/google/protobuf/Internal$IntList;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$QualityLabels;->getNumber()I

    move-result p1

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    return-void
.end method

.method private addLabelValue(I)V
    .registers 3

    .line 1311
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->ensureLabelIsMutable()V

    .line 1312
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    return-void
.end method

.method private clearLabel()V
    .registers 2

    .line 1295
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->emptyIntList()Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_:Lcom/google/protobuf/Internal$IntList;

    return-void
.end method

.method private clearSeparator()V
    .registers 2

    .line 1182
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->getSeparator()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->separator_:Ljava/lang/String;

    return-void
.end method

.method private ensureLabelIsMutable()V
    .registers 3

    .line 1254
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_:Lcom/google/protobuf/Internal$IntList;

    .line 1255
    invoke-interface {v0}, Lcom/google/protobuf/Internal$IntList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 1257
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$IntList;)Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_:Lcom/google/protobuf/Internal$IntList;

    :cond_e
    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 1

    .line 1656
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;
    .registers 1

    .line 1403
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;
    .registers 2

    .line 1406
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1379
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1386
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1342
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1349
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1391
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1398
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1366
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1373
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1329
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1336
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1354
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1361
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;",
            ">;"
        }
    .end annotation

    .line 1662
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setLabel(ILcom/vdocipher/PlaybackInfo$QualityLabels;)V
    .registers 4

    .line 1267
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1268
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->ensureLabelIsMutable()V

    .line 1269
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_:Lcom/google/protobuf/Internal$IntList;

    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$QualityLabels;->getNumber()I

    move-result p2

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$IntList;->setInt(II)I

    return-void
.end method

.method private setLabelValue(II)V
    .registers 4

    .line 1303
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->ensureLabelIsMutable()V

    .line 1304
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$IntList;->setInt(II)I

    return-void
.end method

.method private setSeparator(Ljava/lang/String;)V
    .registers 2

    .line 1173
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1175
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->separator_:Ljava/lang/String;

    return-void
.end method

.method private setSeparatorBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 1190
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 1191
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->separator_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1598
    sget-object p2, Lcom/vdocipher/PlaybackInfo$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_54

    .line 1640
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 1634
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 1619
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 1621
    const-class p2, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    monitor-enter p2

    .line 1622
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 1624
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 1627
    sput-object p1, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->PARSER:Lcom/google/protobuf/Parser;

    .line 1629
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 1616
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object p1

    .line 1606
    :pswitch_36  #0x3
    const-string p1, "separator_"

    const-string p2, "label_"

    filled-new-array {p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    .line 1610
    const-string p2, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001Ȉ\u0002,"

    .line 1612
    sget-object p3, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 1603
    :pswitch_47  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;-><init>(Lcom/vdocipher/PlaybackInfo-IA;)V

    return-object p1

    .line 1600
    :pswitch_4d  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;-><init>()V

    return-object p1

    nop

    :pswitch_data_54
    .packed-switch 0x1
        :pswitch_4d  #00000001
        :pswitch_47  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getLabel(I)Lcom/vdocipher/PlaybackInfo$QualityLabels;
    .registers 3

    .line 1231
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->getInt(I)I

    move-result p1

    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$QualityLabels;->forNumber(I)Lcom/vdocipher/PlaybackInfo$QualityLabels;

    move-result-object p1

    if-nez p1, :cond_e

    .line 1232
    sget-object p1, Lcom/vdocipher/PlaybackInfo$QualityLabels;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    :cond_e
    return-object p1
.end method

.method public getLabelCount()I
    .registers 2

    .line 1222
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$IntList;->size()I

    move-result v0

    return v0
.end method

.method public getLabelList()Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$QualityLabels;",
            ">;"
        }
    .end annotation

    .line 1213
    new-instance v0, Lcom/google/protobuf/Internal$ListAdapter;

    iget-object v1, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_:Lcom/google/protobuf/Internal$IntList;

    sget-object v2, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_converter_:Lcom/google/protobuf/Internal$ListAdapter$Converter;

    invoke-direct {v0, v1, v2}, Lcom/google/protobuf/Internal$ListAdapter;-><init>(Ljava/util/List;Lcom/google/protobuf/Internal$ListAdapter$Converter;)V

    return-object v0
.end method

.method public getLabelValue(I)I
    .registers 3

    .line 1250
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->getInt(I)I

    move-result p1

    return p1
.end method

.method public getLabelValueList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 1241
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->label_:Lcom/google/protobuf/Internal$IntList;

    return-object v0
.end method

.method public getSeparator()Ljava/lang/String;
    .registers 2

    .line 1156
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->separator_:Ljava/lang/String;

    return-object v0
.end method

.method public getSeparatorBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 1165
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->separator_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method
