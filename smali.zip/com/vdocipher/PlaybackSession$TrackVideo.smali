# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$TrackVideo;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$TrackVideoOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "TrackVideo"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$TrackVideo;",
        "Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$TrackVideoOrBuilder;"
    }
.end annotation


# static fields
.field public static final BITRATEKBPS_FIELD_NUMBER:I = 0x1

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

.field private static volatile PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$TrackVideo;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private bitrateKbps_:I


# direct methods
.method static bridge synthetic -$$Nest$mclearBitrateKbps(Lcom/vdocipher/PlaybackSession$TrackVideo;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$TrackVideo;->clearBitrateKbps()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetBitrateKbps(Lcom/vdocipher/PlaybackSession$TrackVideo;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$TrackVideo;->setBitrateKbps(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 9639
    new-instance v0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$TrackVideo;-><init>()V

    .line 9642
    sput-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    .line 9643
    const-class v1, Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 9431
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    return-void
.end method

.method private clearBitrateKbps()V
    .registers 2

    const/4 v0, 0x0

    .line 9456
    iput v0, p0, Lcom/vdocipher/PlaybackSession$TrackVideo;->bitrateKbps_:I

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 1

    .line 9648
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;
    .registers 1

    .line 9536
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$TrackVideo;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$TrackVideo;)Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;
    .registers 2

    .line 9539
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$TrackVideo;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9512
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$TrackVideo;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9519
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$TrackVideo;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9475
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9482
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9524
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9531
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9499
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9506
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9462
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9469
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9487
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9494
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackVideo;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$TrackVideo;",
            ">;"
        }
    .end annotation

    .line 9654
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$TrackVideo;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setBitrateKbps(I)V
    .registers 2

    .line 9449
    iput p1, p0, Lcom/vdocipher/PlaybackSession$TrackVideo;->bitrateKbps_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 9591
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_52

    .line 9632
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 9626
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 9611
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$TrackVideo;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 9613
    const-class p2, Lcom/vdocipher/PlaybackSession$TrackVideo;

    monitor-enter p2

    .line 9614
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$TrackVideo;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 9616
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 9619
    sput-object p1, Lcom/vdocipher/PlaybackSession$TrackVideo;->PARSER:Lcom/google/protobuf/Parser;

    .line 9621
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 9608
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    return-object p1

    .line 9599
    :pswitch_36  #0x3
    const-string p1, "bitrateKbps_"

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    .line 9602
    const-string p2, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u000b"

    .line 9604
    sget-object p3, Lcom/vdocipher/PlaybackSession$TrackVideo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$TrackVideo;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 9596
    :pswitch_45  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 9593
    :pswitch_4b  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$TrackVideo;-><init>()V

    return-object p1

    nop

    :pswitch_data_52
    .packed-switch 0x1
        :pswitch_4b  #00000001
        :pswitch_45  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getBitrateKbps()I
    .registers 2

    .line 9441
    iget v0, p0, Lcom/vdocipher/PlaybackSession$TrackVideo;->bitrateKbps_:I

    return v0
.end method
