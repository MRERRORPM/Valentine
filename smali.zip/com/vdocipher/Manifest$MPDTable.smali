# classes14.dex

.class public final Lcom/vdocipher/Manifest$MPDTable;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$MPDTableOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "MPDTable"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$MPDTable$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/Manifest$MPDTable;",
        "Lcom/vdocipher/Manifest$MPDTable$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$MPDTableOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

.field public static final MEDIAPRESENTATIONDURATION_FIELD_NUMBER:I = 0x8

.field public static final MINBUFFERTIME_FIELD_NUMBER:I = 0x6

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$MPDTable;",
            ">;"
        }
    .end annotation
.end field

.field public static final PERIODS_FIELD_NUMBER:I = 0x9

.field public static final PROFILES_FIELD_NUMBER:I = 0x5

.field public static final TYPE_FIELD_NUMBER:I = 0x7

.field public static final XMLNSCENC_FIELD_NUMBER:I = 0x4

.field public static final XMLNSXSI_FIELD_NUMBER:I = 0x2

.field public static final XMLNS_FIELD_NUMBER:I = 0x1

.field public static final XSISCHEMALOCATION_FIELD_NUMBER:I = 0x3


# instance fields
.field private bitField0_:I

.field private mediaPresentationDuration_:F

.field private minBufferTime_:D

.field private periods_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/Manifest$Period;",
            ">;"
        }
    .end annotation
.end field

.field private profiles_:Ljava/lang/String;

.field private type_:I

.field private xmlnsCenc_:Ljava/lang/String;

.field private xmlnsXsi_:Ljava/lang/String;

.field private xmlns_:Ljava/lang/String;

.field private xsiSchemaLocation_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$maddAllPeriods(Lcom/vdocipher/Manifest$MPDTable;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->addAllPeriods(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddPeriods(Lcom/vdocipher/Manifest$MPDTable;ILcom/vdocipher/Manifest$Period;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$MPDTable;->addPeriods(ILcom/vdocipher/Manifest$Period;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddPeriods(Lcom/vdocipher/Manifest$MPDTable;Lcom/vdocipher/Manifest$Period;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->addPeriods(Lcom/vdocipher/Manifest$Period;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMediaPresentationDuration(Lcom/vdocipher/Manifest$MPDTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$MPDTable;->clearMediaPresentationDuration()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMinBufferTime(Lcom/vdocipher/Manifest$MPDTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$MPDTable;->clearMinBufferTime()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPeriods(Lcom/vdocipher/Manifest$MPDTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$MPDTable;->clearPeriods()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearProfiles(Lcom/vdocipher/Manifest$MPDTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$MPDTable;->clearProfiles()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearType(Lcom/vdocipher/Manifest$MPDTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$MPDTable;->clearType()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearXmlns(Lcom/vdocipher/Manifest$MPDTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$MPDTable;->clearXmlns()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearXmlnsCenc(Lcom/vdocipher/Manifest$MPDTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$MPDTable;->clearXmlnsCenc()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearXmlnsXsi(Lcom/vdocipher/Manifest$MPDTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$MPDTable;->clearXmlnsXsi()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearXsiSchemaLocation(Lcom/vdocipher/Manifest$MPDTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$MPDTable;->clearXsiSchemaLocation()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremovePeriods(Lcom/vdocipher/Manifest$MPDTable;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->removePeriods(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMediaPresentationDuration(Lcom/vdocipher/Manifest$MPDTable;F)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->setMediaPresentationDuration(F)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMinBufferTime(Lcom/vdocipher/Manifest$MPDTable;D)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$MPDTable;->setMinBufferTime(D)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPeriods(Lcom/vdocipher/Manifest$MPDTable;ILcom/vdocipher/Manifest$Period;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$MPDTable;->setPeriods(ILcom/vdocipher/Manifest$Period;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetProfiles(Lcom/vdocipher/Manifest$MPDTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->setProfiles(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetProfilesBytes(Lcom/vdocipher/Manifest$MPDTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->setProfilesBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetType(Lcom/vdocipher/Manifest$MPDTable;Lcom/vdocipher/Manifest$MPDType;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->setType(Lcom/vdocipher/Manifest$MPDType;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTypeValue(Lcom/vdocipher/Manifest$MPDTable;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->setTypeValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetXmlns(Lcom/vdocipher/Manifest$MPDTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->setXmlns(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetXmlnsBytes(Lcom/vdocipher/Manifest$MPDTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->setXmlnsBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetXmlnsCenc(Lcom/vdocipher/Manifest$MPDTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->setXmlnsCenc(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetXmlnsCencBytes(Lcom/vdocipher/Manifest$MPDTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->setXmlnsCencBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetXmlnsXsi(Lcom/vdocipher/Manifest$MPDTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->setXmlnsXsi(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetXmlnsXsiBytes(Lcom/vdocipher/Manifest$MPDTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->setXmlnsXsiBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetXsiSchemaLocation(Lcom/vdocipher/Manifest$MPDTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->setXsiSchemaLocation(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetXsiSchemaLocationBytes(Lcom/vdocipher/Manifest$MPDTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->setXsiSchemaLocationBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$MPDTable;
    .registers 1

    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 10009
    new-instance v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$MPDTable;-><init>()V

    .line 10012
    sput-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    .line 10013
    const-class v1, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 8868
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 8869
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlns_:Ljava/lang/String;

    .line 8870
    iput-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlnsXsi_:Ljava/lang/String;

    .line 8871
    iput-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xsiSchemaLocation_:Ljava/lang/String;

    .line 8872
    iput-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlnsCenc_:Ljava/lang/String;

    .line 8873
    iput-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->profiles_:Ljava/lang/String;

    .line 8874
    invoke-static {}, Lcom/vdocipher/Manifest$MPDTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->periods_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private addAllPeriods(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$Period;",
            ">;)V"
        }
    .end annotation

    .line 9330
    invoke-direct {p0}, Lcom/vdocipher/Manifest$MPDTable;->ensurePeriodsIsMutable()V

    .line 9331
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->periods_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addPeriods(ILcom/vdocipher/Manifest$Period;)V
    .registers 4

    .line 9321
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9322
    invoke-direct {p0}, Lcom/vdocipher/Manifest$MPDTable;->ensurePeriodsIsMutable()V

    .line 9323
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->periods_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addPeriods(Lcom/vdocipher/Manifest$Period;)V
    .registers 3

    .line 9312
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9313
    invoke-direct {p0}, Lcom/vdocipher/Manifest$MPDTable;->ensurePeriodsIsMutable()V

    .line 9314
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->periods_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private clearMediaPresentationDuration()V
    .registers 2

    const/4 v0, 0x0

    .line 9251
    iput v0, p0, Lcom/vdocipher/Manifest$MPDTable;->mediaPresentationDuration_:F

    return-void
.end method

.method private clearMinBufferTime()V
    .registers 3

    .line 9182
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x21

    iput v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    const-wide/16 v0, 0x0

    .line 9183
    iput-wide v0, p0, Lcom/vdocipher/Manifest$MPDTable;->minBufferTime_:D

    return-void
.end method

.method private clearPeriods()V
    .registers 2

    .line 9338
    invoke-static {}, Lcom/vdocipher/Manifest$MPDTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->periods_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearProfiles()V
    .registers 2

    .line 9138
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x11

    iput v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    .line 9139
    invoke-static {}, Lcom/vdocipher/Manifest$MPDTable;->getDefaultInstance()Lcom/vdocipher/Manifest$MPDTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getProfiles()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->profiles_:Ljava/lang/String;

    return-void
.end method

.method private clearType()V
    .registers 2

    const/4 v0, 0x0

    .line 9225
    iput v0, p0, Lcom/vdocipher/Manifest$MPDTable;->type_:I

    return-void
.end method

.method private clearXmlns()V
    .registers 2

    .line 8918
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x2

    iput v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    .line 8919
    invoke-static {}, Lcom/vdocipher/Manifest$MPDTable;->getDefaultInstance()Lcom/vdocipher/Manifest$MPDTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getXmlns()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlns_:Ljava/lang/String;

    return-void
.end method

.method private clearXmlnsCenc()V
    .registers 2

    .line 9083
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x9

    iput v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    .line 9084
    invoke-static {}, Lcom/vdocipher/Manifest$MPDTable;->getDefaultInstance()Lcom/vdocipher/Manifest$MPDTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getXmlnsCenc()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlnsCenc_:Ljava/lang/String;

    return-void
.end method

.method private clearXmlnsXsi()V
    .registers 2

    .line 8973
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x3

    iput v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    .line 8974
    invoke-static {}, Lcom/vdocipher/Manifest$MPDTable;->getDefaultInstance()Lcom/vdocipher/Manifest$MPDTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getXmlnsXsi()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlnsXsi_:Ljava/lang/String;

    return-void
.end method

.method private clearXsiSchemaLocation()V
    .registers 2

    .line 9028
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x5

    iput v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    .line 9029
    invoke-static {}, Lcom/vdocipher/Manifest$MPDTable;->getDefaultInstance()Lcom/vdocipher/Manifest$MPDTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getXsiSchemaLocation()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xsiSchemaLocation_:Ljava/lang/String;

    return-void
.end method

.method private ensurePeriodsIsMutable()V
    .registers 3

    .line 9292
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->periods_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 9293
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 9295
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->periods_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/Manifest$MPDTable;
    .registers 1

    .line 10018
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 1

    .line 9425
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/Manifest$MPDTable;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 2

    .line 9428
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0, p0}, Lcom/vdocipher/Manifest$MPDTable;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$MPDTable$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$MPDTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9401
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p0}, Lcom/vdocipher/Manifest$MPDTable;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$MPDTable;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$MPDTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9408
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/Manifest$MPDTable;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$MPDTable;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$MPDTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9364
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$MPDTable;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$MPDTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9371
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$MPDTable;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/Manifest$MPDTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9413
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$MPDTable;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$MPDTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9420
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$MPDTable;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$MPDTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9388
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$MPDTable;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$MPDTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9395
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$MPDTable;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/Manifest$MPDTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9351
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$MPDTable;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$MPDTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9358
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$MPDTable;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/Manifest$MPDTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9376
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$MPDTable;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$MPDTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9383
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$MPDTable;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$MPDTable;",
            ">;"
        }
    .end annotation

    .line 10024
    sget-object v0, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private removePeriods(I)V
    .registers 3

    .line 9344
    invoke-direct {p0}, Lcom/vdocipher/Manifest$MPDTable;->ensurePeriodsIsMutable()V

    .line 9345
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->periods_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private setMediaPresentationDuration(F)V
    .registers 2

    .line 9244
    iput p1, p0, Lcom/vdocipher/Manifest$MPDTable;->mediaPresentationDuration_:F

    return-void
.end method

.method private setMinBufferTime(D)V
    .registers 4

    .line 9175
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    or-int/lit8 v0, v0, 0x20

    iput v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    .line 9176
    iput-wide p1, p0, Lcom/vdocipher/Manifest$MPDTable;->minBufferTime_:D

    return-void
.end method

.method private setPeriods(ILcom/vdocipher/Manifest$Period;)V
    .registers 4

    .line 9304
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9305
    invoke-direct {p0}, Lcom/vdocipher/Manifest$MPDTable;->ensurePeriodsIsMutable()V

    .line 9306
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->periods_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setProfiles(Ljava/lang/String;)V
    .registers 3

    .line 9130
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9131
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    or-int/lit8 v0, v0, 0x10

    iput v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    .line 9132
    iput-object p1, p0, Lcom/vdocipher/Manifest$MPDTable;->profiles_:Ljava/lang/String;

    return-void
.end method

.method private setProfilesBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 9147
    invoke-static {p1}, Lcom/vdocipher/Manifest$MPDTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 9148
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$MPDTable;->profiles_:Ljava/lang/String;

    .line 9149
    iget p1, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x10

    iput p1, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    return-void
.end method

.method private setType(Lcom/vdocipher/Manifest$MPDType;)V
    .registers 2

    .line 9217
    invoke-virtual {p1}, Lcom/vdocipher/Manifest$MPDType;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/Manifest$MPDTable;->type_:I

    return-void
.end method

.method private setTypeValue(I)V
    .registers 2

    .line 9210
    iput p1, p0, Lcom/vdocipher/Manifest$MPDTable;->type_:I

    return-void
.end method

.method private setXmlns(Ljava/lang/String;)V
    .registers 3

    .line 8910
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8911
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    or-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    .line 8912
    iput-object p1, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlns_:Ljava/lang/String;

    return-void
.end method

.method private setXmlnsBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 8927
    invoke-static {p1}, Lcom/vdocipher/Manifest$MPDTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 8928
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlns_:Ljava/lang/String;

    .line 8929
    iget p1, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    return-void
.end method

.method private setXmlnsCenc(Ljava/lang/String;)V
    .registers 3

    .line 9075
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9076
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    or-int/lit8 v0, v0, 0x8

    iput v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    .line 9077
    iput-object p1, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlnsCenc_:Ljava/lang/String;

    return-void
.end method

.method private setXmlnsCencBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 9092
    invoke-static {p1}, Lcom/vdocipher/Manifest$MPDTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 9093
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlnsCenc_:Ljava/lang/String;

    .line 9094
    iget p1, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x8

    iput p1, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    return-void
.end method

.method private setXmlnsXsi(Ljava/lang/String;)V
    .registers 3

    .line 8965
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8966
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    or-int/lit8 v0, v0, 0x2

    iput v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    .line 8967
    iput-object p1, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlnsXsi_:Ljava/lang/String;

    return-void
.end method

.method private setXmlnsXsiBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 8982
    invoke-static {p1}, Lcom/vdocipher/Manifest$MPDTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 8983
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlnsXsi_:Ljava/lang/String;

    .line 8984
    iget p1, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x2

    iput p1, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    return-void
.end method

.method private setXsiSchemaLocation(Ljava/lang/String;)V
    .registers 3

    .line 9020
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9021
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    or-int/lit8 v0, v0, 0x4

    iput v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    .line 9022
    iput-object p1, p0, Lcom/vdocipher/Manifest$MPDTable;->xsiSchemaLocation_:Ljava/lang/String;

    return-void
.end method

.method private setXsiSchemaLocationBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 9037
    invoke-static {p1}, Lcom/vdocipher/Manifest$MPDTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 9038
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$MPDTable;->xsiSchemaLocation_:Ljava/lang/String;

    .line 9039
    iget p1, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x4

    iput p1, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 15

    .line 9949
    sget-object p2, Lcom/vdocipher/Manifest$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_6c

    .line 10002
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 9996
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 9981
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/Manifest$MPDTable;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_33

    .line 9983
    const-class p2, Lcom/vdocipher/Manifest$MPDTable;

    monitor-enter p2

    .line 9984
    :try_start_20
    sget-object p1, Lcom/vdocipher/Manifest$MPDTable;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 9986
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 9989
    sput-object p1, Lcom/vdocipher/Manifest$MPDTable;->PARSER:Lcom/google/protobuf/Parser;

    .line 9991
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception v0

    move-object p1, v0

    monitor-exit p2
    :try_end_32
    .catchall {:try_start_20 .. :try_end_32} :catchall_2f

    throw p1

    :cond_33
    return-object p1

    .line 9978
    :pswitch_34  #0x4
    sget-object p1, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    return-object p1

    .line 9957
    :pswitch_37  #0x3
    const-string v0, "bitField0_"

    const-string/jumbo v1, "xmlns_"

    const-string/jumbo v2, "xmlnsXsi_"

    const-string/jumbo v3, "xsiSchemaLocation_"

    const-string/jumbo v4, "xmlnsCenc_"

    const-string v5, "profiles_"

    const-string v6, "minBufferTime_"

    const-string/jumbo v7, "type_"

    const-string v8, "mediaPresentationDuration_"

    const-string v9, "periods_"

    const-class v10, Lcom/vdocipher/Manifest$Period;

    filled-new-array/range {v0 .. v10}, [Ljava/lang/Object;

    move-result-object p1

    .line 9970
    const-string p2, "\u0000\t\u0000\u0001\u0001\t\t\u0000\u0001\u0000\u0001ለ\u0000\u0002ለ\u0001\u0003ለ\u0002\u0004ለ\u0003\u0005ለ\u0004\u0006က\u0005\u0007\f\b\u0001\t\u001b"

    .line 9974
    sget-object p3, Lcom/vdocipher/Manifest$MPDTable;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/Manifest$MPDTable;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 9954
    :pswitch_5f  #0x2
    new-instance p1, Lcom/vdocipher/Manifest$MPDTable$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/Manifest$MPDTable$Builder;-><init>(Lcom/vdocipher/Manifest-IA;)V

    return-object p1

    .line 9951
    :pswitch_65  #0x1
    new-instance p1, Lcom/vdocipher/Manifest$MPDTable;

    invoke-direct {p1}, Lcom/vdocipher/Manifest$MPDTable;-><init>()V

    return-object p1

    nop

    :pswitch_data_6c
    .packed-switch 0x1
        :pswitch_65  #00000001
        :pswitch_5f  #00000002
        :pswitch_37  #00000003
        :pswitch_34  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getMediaPresentationDuration()F
    .registers 2

    .line 9236
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->mediaPresentationDuration_:F

    return v0
.end method

.method public getMinBufferTime()D
    .registers 3

    .line 9168
    iget-wide v0, p0, Lcom/vdocipher/Manifest$MPDTable;->minBufferTime_:D

    return-wide v0
.end method

.method public getPeriods(I)Lcom/vdocipher/Manifest$Period;
    .registers 3

    .line 9282
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->periods_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$Period;

    return-object p1
.end method

.method public getPeriodsCount()I
    .registers 2

    .line 9275
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->periods_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getPeriodsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$Period;",
            ">;"
        }
    .end annotation

    .line 9261
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->periods_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getPeriodsOrBuilder(I)Lcom/vdocipher/Manifest$PeriodOrBuilder;
    .registers 3

    .line 9289
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->periods_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$PeriodOrBuilder;

    return-object p1
.end method

.method public getPeriodsOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/Manifest$PeriodOrBuilder;",
            ">;"
        }
    .end annotation

    .line 9268
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->periods_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getProfiles()Ljava/lang/String;
    .registers 2

    .line 9113
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->profiles_:Ljava/lang/String;

    return-object v0
.end method

.method public getProfilesBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9122
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->profiles_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getType()Lcom/vdocipher/Manifest$MPDType;
    .registers 2

    .line 9202
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->type_:I

    invoke-static {v0}, Lcom/vdocipher/Manifest$MPDType;->forNumber(I)Lcom/vdocipher/Manifest$MPDType;

    move-result-object v0

    if-nez v0, :cond_a

    .line 9203
    sget-object v0, Lcom/vdocipher/Manifest$MPDType;->UNRECOGNIZED:Lcom/vdocipher/Manifest$MPDType;

    :cond_a
    return-object v0
.end method

.method public getTypeValue()I
    .registers 2

    .line 9194
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->type_:I

    return v0
.end method

.method public getXmlns()Ljava/lang/String;
    .registers 2

    .line 8893
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlns_:Ljava/lang/String;

    return-object v0
.end method

.method public getXmlnsBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8902
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlns_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getXmlnsCenc()Ljava/lang/String;
    .registers 2

    .line 9058
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlnsCenc_:Ljava/lang/String;

    return-object v0
.end method

.method public getXmlnsCencBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9067
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlnsCenc_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getXmlnsXsi()Ljava/lang/String;
    .registers 2

    .line 8948
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlnsXsi_:Ljava/lang/String;

    return-object v0
.end method

.method public getXmlnsXsiBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8957
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xmlnsXsi_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getXsiSchemaLocation()Ljava/lang/String;
    .registers 2

    .line 9003
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xsiSchemaLocation_:Ljava/lang/String;

    return-object v0
.end method

.method public getXsiSchemaLocationBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9012
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable;->xsiSchemaLocation_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public hasMinBufferTime()Z
    .registers 2

    .line 9160
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x20

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasProfiles()Z
    .registers 2

    .line 9105
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasXmlns()Z
    .registers 3

    .line 8885
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_7

    return v1

    :cond_7
    const/4 v0, 0x0

    return v0
.end method

.method public hasXmlnsCenc()Z
    .registers 2

    .line 9050
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x8

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasXmlnsXsi()Z
    .registers 2

    .line 8940
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasXsiSchemaLocation()Z
    .registers 2

    .line 8995
    iget v0, p0, Lcom/vdocipher/Manifest$MPDTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method
