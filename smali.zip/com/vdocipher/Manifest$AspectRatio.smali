# classes14.dex

.class public final Lcom/vdocipher/Manifest$AspectRatio;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$AspectRatioOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "AspectRatio"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$AspectRatio$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/Manifest$AspectRatio;",
        "Lcom/vdocipher/Manifest$AspectRatio$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$AspectRatioOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

.field public static final HEIGHT_FIELD_NUMBER:I = 0x2

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$AspectRatio;",
            ">;"
        }
    .end annotation
.end field

.field public static final WIDTH_FIELD_NUMBER:I = 0x1


# instance fields
.field private height_:I

.field private width_:I


# direct methods
.method static bridge synthetic -$$Nest$mclearHeight(Lcom/vdocipher/Manifest$AspectRatio;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AspectRatio;->clearHeight()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearWidth(Lcom/vdocipher/Manifest$AspectRatio;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AspectRatio;->clearWidth()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetHeight(Lcom/vdocipher/Manifest$AspectRatio;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AspectRatio;->setHeight(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetWidth(Lcom/vdocipher/Manifest$AspectRatio;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AspectRatio;->setWidth(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$AspectRatio;
    .registers 1

    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 674
    new-instance v0, Lcom/vdocipher/Manifest$AspectRatio;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$AspectRatio;-><init>()V

    .line 677
    sput-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    .line 678
    const-class v1, Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 410
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    return-void
.end method

.method private clearHeight()V
    .registers 2

    const/4 v0, 0x0

    .line 461
    iput v0, p0, Lcom/vdocipher/Manifest$AspectRatio;->height_:I

    return-void
.end method

.method private clearWidth()V
    .registers 2

    const/4 v0, 0x0

    .line 435
    iput v0, p0, Lcom/vdocipher/Manifest$AspectRatio;->width_:I

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/Manifest$AspectRatio;
    .registers 1

    .line 683
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/Manifest$AspectRatio$Builder;
    .registers 1

    .line 541
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AspectRatio;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/Manifest$AspectRatio$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/Manifest$AspectRatio;)Lcom/vdocipher/Manifest$AspectRatio$Builder;
    .registers 2

    .line 544
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-virtual {v0, p0}, Lcom/vdocipher/Manifest$AspectRatio;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AspectRatio$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$AspectRatio;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 517
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p0}, Lcom/vdocipher/Manifest$AspectRatio;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AspectRatio;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AspectRatio;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 524
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/Manifest$AspectRatio;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AspectRatio;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$AspectRatio;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 480
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AspectRatio;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AspectRatio;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 487
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AspectRatio;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/Manifest$AspectRatio;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 529
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AspectRatio;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AspectRatio;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 536
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AspectRatio;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$AspectRatio;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 504
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AspectRatio;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AspectRatio;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 511
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AspectRatio;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/Manifest$AspectRatio;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 467
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AspectRatio;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AspectRatio;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 474
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AspectRatio;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/Manifest$AspectRatio;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 492
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AspectRatio;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AspectRatio;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 499
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AspectRatio;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$AspectRatio;",
            ">;"
        }
    .end annotation

    .line 689
    sget-object v0, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AspectRatio;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setHeight(I)V
    .registers 2

    .line 454
    iput p1, p0, Lcom/vdocipher/Manifest$AspectRatio;->height_:I

    return-void
.end method

.method private setWidth(I)V
    .registers 2

    .line 428
    iput p1, p0, Lcom/vdocipher/Manifest$AspectRatio;->width_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 624
    sget-object p2, Lcom/vdocipher/Manifest$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_54

    .line 667
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 661
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 646
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/Manifest$AspectRatio;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 648
    const-class p2, Lcom/vdocipher/Manifest$AspectRatio;

    monitor-enter p2

    .line 649
    :try_start_20
    sget-object p1, Lcom/vdocipher/Manifest$AspectRatio;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 651
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 654
    sput-object p1, Lcom/vdocipher/Manifest$AspectRatio;->PARSER:Lcom/google/protobuf/Parser;

    .line 656
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 643
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    return-object p1

    .line 632
    :pswitch_36  #0x3
    const-string/jumbo p1, "width_"

    const-string p2, "height_"

    filled-new-array {p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    .line 636
    const-string p2, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u000b\u0002\u000b"

    .line 639
    sget-object p3, Lcom/vdocipher/Manifest$AspectRatio;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/Manifest$AspectRatio;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 629
    :pswitch_48  #0x2
    new-instance p1, Lcom/vdocipher/Manifest$AspectRatio$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/Manifest$AspectRatio$Builder;-><init>(Lcom/vdocipher/Manifest-IA;)V

    return-object p1

    .line 626
    :pswitch_4e  #0x1
    new-instance p1, Lcom/vdocipher/Manifest$AspectRatio;

    invoke-direct {p1}, Lcom/vdocipher/Manifest$AspectRatio;-><init>()V

    return-object p1

    :pswitch_data_54
    .packed-switch 0x1
        :pswitch_4e  #00000001
        :pswitch_48  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getHeight()I
    .registers 2

    .line 446
    iget v0, p0, Lcom/vdocipher/Manifest$AspectRatio;->height_:I

    return v0
.end method

.method public getWidth()I
    .registers 2

    .line 420
    iget v0, p0, Lcom/vdocipher/Manifest$AspectRatio;->width_:I

    return v0
.end method
