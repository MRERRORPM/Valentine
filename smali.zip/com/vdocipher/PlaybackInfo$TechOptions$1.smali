# classes14.dex

.class Lcom/vdocipher/PlaybackInfo$TechOptions$1;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLiteMap;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$TechOptions;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/google/protobuf/Internal$EnumLiteMap<",
        "Lcom/vdocipher/PlaybackInfo$TechOptions;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .line 705
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic findValueByNumber(I)Lcom/google/protobuf/Internal$EnumLite;
    .registers 2

    .line 705
    invoke-virtual {p0, p1}, Lcom/vdocipher/PlaybackInfo$TechOptions$1;->findValueByNumber(I)Lcom/vdocipher/PlaybackInfo$TechOptions;

    move-result-object p1

    return-object p1
.end method

.method public findValueByNumber(I)Lcom/vdocipher/PlaybackInfo$TechOptions;
    .registers 2

    .line 708
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$TechOptions;->forNumber(I)Lcom/vdocipher/PlaybackInfo$TechOptions;

    move-result-object p1

    return-object p1
.end method
