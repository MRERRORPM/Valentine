# classes14.dex

.class public final Lcom/vdocipher/Manifest$AdaptationSet;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$AdaptationSetOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "AdaptationSet"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/Manifest$AdaptationSet;",
        "Lcom/vdocipher/Manifest$AdaptationSet$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$AdaptationSetOrBuilder;"
    }
.end annotation


# static fields
.field public static final CONTENTPROTECTION_FIELD_NUMBER:I = 0xf

.field public static final CONTENTTYPE_FIELD_NUMBER:I = 0x2

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

.field public static final FRAMERATE_FIELD_NUMBER:I = 0x6

.field public static final HEIGHT_FIELD_NUMBER:I = 0x5

.field public static final ID_FIELD_NUMBER:I = 0x1

.field public static final LANG_FIELD_NUMBER:I = 0x3

.field public static final MAXFRAMERATE_FIELD_NUMBER:I = 0x9

.field public static final MAXHEIGHT_FIELD_NUMBER:I = 0x8

.field public static final MAXWIDTH_FIELD_NUMBER:I = 0x7

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$AdaptationSet;",
            ">;"
        }
    .end annotation
.end field

.field public static final PAR_FIELD_NUMBER:I = 0xa

.field public static final REPRESENTATION_FIELD_NUMBER:I = 0x10

.field public static final ROLE_FIELD_NUMBER:I = 0xd

.field public static final SUBSEGMENTALIGNMENT_FIELD_NUMBER:I = 0xc

.field public static final SUBSEGMENTSTARTSWITHSAP_FIELD_NUMBER:I = 0xb

.field public static final SUPPLEMENTALPROPERTY_FIELD_NUMBER:I = 0xe

.field public static final WIDTH_FIELD_NUMBER:I = 0x4


# instance fields
.field private bitField0_:I

.field private contentProtection_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/Manifest$ContentProtection;",
            ">;"
        }
    .end annotation
.end field

.field private contentType_:I

.field private frameRate_:Ljava/lang/String;

.field private height_:I

.field private id_:I

.field private lang_:Ljava/lang/String;

.field private maxFrameRate_:Ljava/lang/String;

.field private maxHeight_:I

.field private maxWidth_:I

.field private par_:Lcom/vdocipher/Manifest$AspectRatio;

.field private representation_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/Manifest$Representation;",
            ">;"
        }
    .end annotation
.end field

.field private role_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/Manifest$Role;",
            ">;"
        }
    .end annotation
.end field

.field private subsegmentAlignment_:Z

.field private subsegmentStartsWithSAP_:I

.field private supplementalProperty_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/Manifest$SupplementalProperty;",
            ">;"
        }
    .end annotation
.end field

.field private width_:I


# direct methods
.method static bridge synthetic -$$Nest$maddAllContentProtection(Lcom/vdocipher/Manifest$AdaptationSet;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->addAllContentProtection(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllRepresentation(Lcom/vdocipher/Manifest$AdaptationSet;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->addAllRepresentation(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllRole(Lcom/vdocipher/Manifest$AdaptationSet;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->addAllRole(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllSupplementalProperty(Lcom/vdocipher/Manifest$AdaptationSet;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->addAllSupplementalProperty(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddContentProtection(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$ContentProtection;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->addContentProtection(ILcom/vdocipher/Manifest$ContentProtection;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddContentProtection(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$ContentProtection;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->addContentProtection(Lcom/vdocipher/Manifest$ContentProtection;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddRepresentation(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$Representation;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->addRepresentation(ILcom/vdocipher/Manifest$Representation;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddRepresentation(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$Representation;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->addRepresentation(Lcom/vdocipher/Manifest$Representation;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddRole(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$Role;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->addRole(ILcom/vdocipher/Manifest$Role;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddRole(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$Role;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->addRole(Lcom/vdocipher/Manifest$Role;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddSupplementalProperty(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$SupplementalProperty;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->addSupplementalProperty(ILcom/vdocipher/Manifest$SupplementalProperty;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddSupplementalProperty(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$SupplementalProperty;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->addSupplementalProperty(Lcom/vdocipher/Manifest$SupplementalProperty;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearContentProtection(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearContentProtection()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearContentType(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearContentType()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearFrameRate(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearFrameRate()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearHeight(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearHeight()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearId(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearId()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLang(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearLang()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMaxFrameRate(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearMaxFrameRate()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMaxHeight(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearMaxHeight()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMaxWidth(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearMaxWidth()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPar(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearPar()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearRepresentation(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearRepresentation()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearRole(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearRole()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSubsegmentAlignment(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearSubsegmentAlignment()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSubsegmentStartsWithSAP(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearSubsegmentStartsWithSAP()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSupplementalProperty(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearSupplementalProperty()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearWidth(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->clearWidth()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergePar(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$AspectRatio;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->mergePar(Lcom/vdocipher/Manifest$AspectRatio;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveContentProtection(Lcom/vdocipher/Manifest$AdaptationSet;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->removeContentProtection(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveRepresentation(Lcom/vdocipher/Manifest$AdaptationSet;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->removeRepresentation(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveRole(Lcom/vdocipher/Manifest$AdaptationSet;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->removeRole(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveSupplementalProperty(Lcom/vdocipher/Manifest$AdaptationSet;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->removeSupplementalProperty(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetContentProtection(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$ContentProtection;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->setContentProtection(ILcom/vdocipher/Manifest$ContentProtection;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetContentType(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$ContentType;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setContentType(Lcom/vdocipher/Manifest$ContentType;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetContentTypeValue(Lcom/vdocipher/Manifest$AdaptationSet;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setContentTypeValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetFrameRate(Lcom/vdocipher/Manifest$AdaptationSet;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setFrameRate(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetFrameRateBytes(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setFrameRateBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetHeight(Lcom/vdocipher/Manifest$AdaptationSet;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setHeight(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetId(Lcom/vdocipher/Manifest$AdaptationSet;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setId(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLang(Lcom/vdocipher/Manifest$AdaptationSet;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setLang(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLangBytes(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setLangBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMaxFrameRate(Lcom/vdocipher/Manifest$AdaptationSet;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setMaxFrameRate(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMaxFrameRateBytes(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setMaxFrameRateBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMaxHeight(Lcom/vdocipher/Manifest$AdaptationSet;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setMaxHeight(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMaxWidth(Lcom/vdocipher/Manifest$AdaptationSet;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setMaxWidth(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPar(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$AspectRatio;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setPar(Lcom/vdocipher/Manifest$AspectRatio;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetRepresentation(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$Representation;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->setRepresentation(ILcom/vdocipher/Manifest$Representation;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetRole(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$Role;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->setRole(ILcom/vdocipher/Manifest$Role;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSubsegmentAlignment(Lcom/vdocipher/Manifest$AdaptationSet;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setSubsegmentAlignment(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSubsegmentStartsWithSAP(Lcom/vdocipher/Manifest$AdaptationSet;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setSubsegmentStartsWithSAP(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSupplementalProperty(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$SupplementalProperty;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->setSupplementalProperty(ILcom/vdocipher/Manifest$SupplementalProperty;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetWidth(Lcom/vdocipher/Manifest$AdaptationSet;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->setWidth(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 1

    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 8118
    new-instance v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$AdaptationSet;-><init>()V

    .line 8121
    sput-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    .line 8122
    const-class v1, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 6174
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 6175
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->lang_:Ljava/lang/String;

    .line 6176
    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->frameRate_:Ljava/lang/String;

    .line 6177
    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->maxFrameRate_:Ljava/lang/String;

    .line 6178
    invoke-static {}, Lcom/vdocipher/Manifest$AdaptationSet;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->role_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 6179
    invoke-static {}, Lcom/vdocipher/Manifest$AdaptationSet;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->supplementalProperty_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 6180
    invoke-static {}, Lcom/vdocipher/Manifest$AdaptationSet;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentProtection_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 6181
    invoke-static {}, Lcom/vdocipher/Manifest$AdaptationSet;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->representation_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private addAllContentProtection(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$ContentProtection;",
            ">;)V"
        }
    .end annotation

    .line 6923
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureContentProtectionIsMutable()V

    .line 6924
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentProtection_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAllRepresentation(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$Representation;",
            ">;)V"
        }
    .end annotation

    .line 7017
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureRepresentationIsMutable()V

    .line 7018
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->representation_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAllRole(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$Role;",
            ">;)V"
        }
    .end annotation

    .line 6735
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureRoleIsMutable()V

    .line 6736
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->role_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAllSupplementalProperty(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$SupplementalProperty;",
            ">;)V"
        }
    .end annotation

    .line 6829
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureSupplementalPropertyIsMutable()V

    .line 6830
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->supplementalProperty_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addContentProtection(ILcom/vdocipher/Manifest$ContentProtection;)V
    .registers 4

    .line 6914
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6915
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureContentProtectionIsMutable()V

    .line 6916
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentProtection_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addContentProtection(Lcom/vdocipher/Manifest$ContentProtection;)V
    .registers 3

    .line 6905
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6906
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureContentProtectionIsMutable()V

    .line 6907
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentProtection_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addRepresentation(ILcom/vdocipher/Manifest$Representation;)V
    .registers 4

    .line 7008
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7009
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureRepresentationIsMutable()V

    .line 7010
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->representation_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addRepresentation(Lcom/vdocipher/Manifest$Representation;)V
    .registers 3

    .line 6999
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7000
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureRepresentationIsMutable()V

    .line 7001
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->representation_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addRole(ILcom/vdocipher/Manifest$Role;)V
    .registers 4

    .line 6726
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6727
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureRoleIsMutable()V

    .line 6728
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->role_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addRole(Lcom/vdocipher/Manifest$Role;)V
    .registers 3

    .line 6717
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6718
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureRoleIsMutable()V

    .line 6719
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->role_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addSupplementalProperty(ILcom/vdocipher/Manifest$SupplementalProperty;)V
    .registers 4

    .line 6820
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6821
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureSupplementalPropertyIsMutable()V

    .line 6822
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->supplementalProperty_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addSupplementalProperty(Lcom/vdocipher/Manifest$SupplementalProperty;)V
    .registers 3

    .line 6811
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6812
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureSupplementalPropertyIsMutable()V

    .line 6813
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->supplementalProperty_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private clearContentProtection()V
    .registers 2

    .line 6931
    invoke-static {}, Lcom/vdocipher/Manifest$AdaptationSet;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentProtection_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearContentType()V
    .registers 2

    const/4 v0, 0x0

    .line 6249
    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentType_:I

    return-void
.end method

.method private clearFrameRate()V
    .registers 2

    .line 6416
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit8 v0, v0, -0x9

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    .line 6417
    invoke-static {}, Lcom/vdocipher/Manifest$AdaptationSet;->getDefaultInstance()Lcom/vdocipher/Manifest$AdaptationSet;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getFrameRate()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->frameRate_:Ljava/lang/String;

    return-void
.end method

.method private clearHeight()V
    .registers 2

    .line 6371
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit8 v0, v0, -0x5

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    const/4 v0, 0x0

    .line 6372
    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->height_:I

    return-void
.end method

.method private clearId()V
    .registers 2

    const/4 v0, 0x0

    .line 6207
    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->id_:I

    return-void
.end method

.method private clearLang()V
    .registers 2

    .line 6293
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit8 v0, v0, -0x2

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    .line 6294
    invoke-static {}, Lcom/vdocipher/Manifest$AdaptationSet;->getDefaultInstance()Lcom/vdocipher/Manifest$AdaptationSet;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getLang()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->lang_:Ljava/lang/String;

    return-void
.end method

.method private clearMaxFrameRate()V
    .registers 2

    .line 6539
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit8 v0, v0, -0x41

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    .line 6540
    invoke-static {}, Lcom/vdocipher/Manifest$AdaptationSet;->getDefaultInstance()Lcom/vdocipher/Manifest$AdaptationSet;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getMaxFrameRate()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->maxFrameRate_:Ljava/lang/String;

    return-void
.end method

.method private clearMaxHeight()V
    .registers 2

    .line 6494
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit8 v0, v0, -0x21

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    const/4 v0, 0x0

    .line 6495
    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->maxHeight_:I

    return-void
.end method

.method private clearMaxWidth()V
    .registers 2

    .line 6460
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit8 v0, v0, -0x11

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    const/4 v0, 0x0

    .line 6461
    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->maxWidth_:I

    return-void
.end method

.method private clearPar()V
    .registers 2

    const/4 v0, 0x0

    .line 6595
    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->par_:Lcom/vdocipher/Manifest$AspectRatio;

    .line 6596
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit16 v0, v0, -0x81

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    return-void
.end method

.method private clearRepresentation()V
    .registers 2

    .line 7025
    invoke-static {}, Lcom/vdocipher/Manifest$AdaptationSet;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->representation_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearRole()V
    .registers 2

    .line 6743
    invoke-static {}, Lcom/vdocipher/Manifest$AdaptationSet;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->role_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearSubsegmentAlignment()V
    .registers 2

    const/4 v0, 0x0

    .line 6656
    iput-boolean v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->subsegmentAlignment_:Z

    return-void
.end method

.method private clearSubsegmentStartsWithSAP()V
    .registers 2

    .line 6629
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit16 v0, v0, -0x101

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    const/4 v0, 0x0

    .line 6630
    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->subsegmentStartsWithSAP_:I

    return-void
.end method

.method private clearSupplementalProperty()V
    .registers 2

    .line 6837
    invoke-static {}, Lcom/vdocipher/Manifest$AdaptationSet;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->supplementalProperty_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearWidth()V
    .registers 2

    .line 6337
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit8 v0, v0, -0x3

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    const/4 v0, 0x0

    .line 6338
    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->width_:I

    return-void
.end method

.method private ensureContentProtectionIsMutable()V
    .registers 3

    .line 6885
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentProtection_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 6886
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 6888
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentProtection_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method private ensureRepresentationIsMutable()V
    .registers 3

    .line 6979
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->representation_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 6980
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 6982
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->representation_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method private ensureRoleIsMutable()V
    .registers 3

    .line 6697
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->role_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 6698
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 6700
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->role_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method private ensureSupplementalPropertyIsMutable()V
    .registers 3

    .line 6791
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->supplementalProperty_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 6792
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 6794
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->supplementalProperty_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 1

    .line 8127
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    return-object v0
.end method

.method private mergePar(Lcom/vdocipher/Manifest$AspectRatio;)V
    .registers 4

    .line 6582
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6583
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->par_:Lcom/vdocipher/Manifest$AspectRatio;

    if-eqz v0, :cond_22

    .line 6584
    invoke-static {}, Lcom/vdocipher/Manifest$AspectRatio;->getDefaultInstance()Lcom/vdocipher/Manifest$AspectRatio;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 6585
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->par_:Lcom/vdocipher/Manifest$AspectRatio;

    .line 6586
    invoke-static {v0}, Lcom/vdocipher/Manifest$AspectRatio;->newBuilder(Lcom/vdocipher/Manifest$AspectRatio;)Lcom/vdocipher/Manifest$AspectRatio$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/Manifest$AspectRatio$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$AspectRatio$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$AspectRatio$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$AspectRatio;

    iput-object p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->par_:Lcom/vdocipher/Manifest$AspectRatio;

    goto :goto_24

    .line 6588
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->par_:Lcom/vdocipher/Manifest$AspectRatio;

    .line 6590
    :goto_24
    iget p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    or-int/lit16 p1, p1, 0x80

    iput p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    return-void
.end method

.method public static newBuilder()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 1

    .line 7112
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/Manifest$AdaptationSet;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7115
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0, p0}, Lcom/vdocipher/Manifest$AdaptationSet;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7088
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p0}, Lcom/vdocipher/Manifest$AdaptationSet;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AdaptationSet;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7095
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AdaptationSet;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7051
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AdaptationSet;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7058
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AdaptationSet;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7100
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AdaptationSet;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7107
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AdaptationSet;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7075
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AdaptationSet;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7082
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AdaptationSet;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7038
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AdaptationSet;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7045
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AdaptationSet;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7063
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AdaptationSet;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7070
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AdaptationSet;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$AdaptationSet;",
            ">;"
        }
    .end annotation

    .line 8133
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private removeContentProtection(I)V
    .registers 3

    .line 6937
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureContentProtectionIsMutable()V

    .line 6938
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentProtection_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private removeRepresentation(I)V
    .registers 3

    .line 7031
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureRepresentationIsMutable()V

    .line 7032
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->representation_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private removeRole(I)V
    .registers 3

    .line 6749
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureRoleIsMutable()V

    .line 6750
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->role_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private removeSupplementalProperty(I)V
    .registers 3

    .line 6843
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureSupplementalPropertyIsMutable()V

    .line 6844
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->supplementalProperty_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private setContentProtection(ILcom/vdocipher/Manifest$ContentProtection;)V
    .registers 4

    .line 6897
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6898
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureContentProtectionIsMutable()V

    .line 6899
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentProtection_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setContentType(Lcom/vdocipher/Manifest$ContentType;)V
    .registers 2

    .line 6241
    invoke-virtual {p1}, Lcom/vdocipher/Manifest$ContentType;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentType_:I

    return-void
.end method

.method private setContentTypeValue(I)V
    .registers 2

    .line 6234
    iput p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentType_:I

    return-void
.end method

.method private setFrameRate(Ljava/lang/String;)V
    .registers 3

    .line 6408
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6409
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    or-int/lit8 v0, v0, 0x8

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    .line 6410
    iput-object p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->frameRate_:Ljava/lang/String;

    return-void
.end method

.method private setFrameRateBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 6425
    invoke-static {p1}, Lcom/vdocipher/Manifest$AdaptationSet;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 6426
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->frameRate_:Ljava/lang/String;

    .line 6427
    iget p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    or-int/lit8 p1, p1, 0x8

    iput p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    return-void
.end method

.method private setHeight(I)V
    .registers 3

    .line 6364
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    or-int/lit8 v0, v0, 0x4

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    .line 6365
    iput p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->height_:I

    return-void
.end method

.method private setId(I)V
    .registers 2

    .line 6200
    iput p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->id_:I

    return-void
.end method

.method private setLang(Ljava/lang/String;)V
    .registers 3

    .line 6285
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6286
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    or-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    .line 6287
    iput-object p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->lang_:Ljava/lang/String;

    return-void
.end method

.method private setLangBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 6302
    invoke-static {p1}, Lcom/vdocipher/Manifest$AdaptationSet;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 6303
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->lang_:Ljava/lang/String;

    .line 6304
    iget p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    return-void
.end method

.method private setMaxFrameRate(Ljava/lang/String;)V
    .registers 3

    .line 6531
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6532
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    or-int/lit8 v0, v0, 0x40

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    .line 6533
    iput-object p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->maxFrameRate_:Ljava/lang/String;

    return-void
.end method

.method private setMaxFrameRateBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 6548
    invoke-static {p1}, Lcom/vdocipher/Manifest$AdaptationSet;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 6549
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->maxFrameRate_:Ljava/lang/String;

    .line 6550
    iget p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    or-int/lit8 p1, p1, 0x40

    iput p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    return-void
.end method

.method private setMaxHeight(I)V
    .registers 3

    .line 6487
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    or-int/lit8 v0, v0, 0x20

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    .line 6488
    iput p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->maxHeight_:I

    return-void
.end method

.method private setMaxWidth(I)V
    .registers 3

    .line 6453
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    or-int/lit8 v0, v0, 0x10

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    .line 6454
    iput p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->maxWidth_:I

    return-void
.end method

.method private setPar(Lcom/vdocipher/Manifest$AspectRatio;)V
    .registers 2

    .line 6573
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6574
    iput-object p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->par_:Lcom/vdocipher/Manifest$AspectRatio;

    .line 6575
    iget p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    or-int/lit16 p1, p1, 0x80

    iput p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    return-void
.end method

.method private setRepresentation(ILcom/vdocipher/Manifest$Representation;)V
    .registers 4

    .line 6991
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6992
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureRepresentationIsMutable()V

    .line 6993
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->representation_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setRole(ILcom/vdocipher/Manifest$Role;)V
    .registers 4

    .line 6709
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6710
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureRoleIsMutable()V

    .line 6711
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->role_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setSubsegmentAlignment(Z)V
    .registers 2

    .line 6649
    iput-boolean p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->subsegmentAlignment_:Z

    return-void
.end method

.method private setSubsegmentStartsWithSAP(I)V
    .registers 3

    .line 6622
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    or-int/lit16 v0, v0, 0x100

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    .line 6623
    iput p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->subsegmentStartsWithSAP_:I

    return-void
.end method

.method private setSupplementalProperty(ILcom/vdocipher/Manifest$SupplementalProperty;)V
    .registers 4

    .line 6803
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6804
    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet;->ensureSupplementalPropertyIsMutable()V

    .line 6805
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->supplementalProperty_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setWidth(I)V
    .registers 3

    .line 6330
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    or-int/lit8 v0, v0, 0x2

    iput v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    .line 6331
    iput p1, p0, Lcom/vdocipher/Manifest$AdaptationSet;->width_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 27

    .line 8047
    sget-object v0, Lcom/vdocipher/Manifest$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual/range {p1 .. p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_7e

    .line 8111
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0

    :pswitch_12  #0x7
    return-object v1

    :pswitch_13  #0x6
    const/4 v0, 0x1

    .line 8105
    invoke-static {v0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v0

    return-object v0

    .line 8090
    :pswitch_19  #0x5
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->PARSER:Lcom/google/protobuf/Parser;

    if-nez v0, :cond_32

    .line 8092
    const-class v1, Lcom/vdocipher/Manifest$AdaptationSet;

    monitor-enter v1

    .line 8093
    :try_start_20
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->PARSER:Lcom/google/protobuf/Parser;

    if-nez v0, :cond_2d

    .line 8095
    new-instance v0, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object v2, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-direct {v0, v2}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 8098
    sput-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->PARSER:Lcom/google/protobuf/Parser;

    .line 8100
    :cond_2d
    monitor-exit v1

    return-object v0

    :catchall_2f
    move-exception v0

    monitor-exit v1
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw v0

    :cond_32
    return-object v0

    .line 8087
    :pswitch_33  #0x4
    sget-object v0, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    return-object v0

    .line 8055
    :pswitch_36  #0x3
    const-string v2, "bitField0_"

    const-string v3, "id_"

    const-string v4, "contentType_"

    const-string v5, "lang_"

    const-string/jumbo v6, "width_"

    const-string v7, "height_"

    const-string v8, "frameRate_"

    const-string v9, "maxWidth_"

    const-string v10, "maxHeight_"

    const-string v11, "maxFrameRate_"

    const-string v12, "par_"

    const-string/jumbo v13, "subsegmentStartsWithSAP_"

    const-string/jumbo v14, "subsegmentAlignment_"

    const-string v15, "role_"

    const-class v16, Lcom/vdocipher/Manifest$Role;

    const-string/jumbo v17, "supplementalProperty_"

    const-class v18, Lcom/vdocipher/Manifest$SupplementalProperty;

    const-string v19, "contentProtection_"

    const-class v20, Lcom/vdocipher/Manifest$ContentProtection;

    const-string v21, "representation_"

    const-class v22, Lcom/vdocipher/Manifest$Representation;

    filled-new-array/range {v2 .. v22}, [Ljava/lang/Object;

    move-result-object v0

    .line 8078
    const-string v1, "\u0000\u0010\u0000\u0001\u0001\u0010\u0010\u0000\u0004\u0000\u0001\u000b\u0002\f\u0003ለ\u0000\u0004ဋ\u0001\u0005ဋ\u0002\u0006ለ\u0003\u0007ဋ\u0004\bဋ\u0005\tለ\u0006\nဉ\u0007\u000bဋ\b\f\u0007\r\u001b\u000e\u001b\u000f\u001b\u0010\u001b"

    .line 8083
    sget-object v2, Lcom/vdocipher/Manifest$AdaptationSet;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v2, v1, v0}, Lcom/vdocipher/Manifest$AdaptationSet;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    .line 8052
    :pswitch_71  #0x2
    new-instance v0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;

    invoke-direct {v0, v1}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;-><init>(Lcom/vdocipher/Manifest-IA;)V

    return-object v0

    .line 8049
    :pswitch_77  #0x1
    new-instance v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$AdaptationSet;-><init>()V

    return-object v0

    nop

    :pswitch_data_7e
    .packed-switch 0x1
        :pswitch_77  #00000001
        :pswitch_71  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getContentProtection(I)Lcom/vdocipher/Manifest$ContentProtection;
    .registers 3

    .line 6875
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentProtection_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$ContentProtection;

    return-object p1
.end method

.method public getContentProtectionCount()I
    .registers 2

    .line 6868
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentProtection_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getContentProtectionList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$ContentProtection;",
            ">;"
        }
    .end annotation

    .line 6854
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentProtection_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getContentProtectionOrBuilder(I)Lcom/vdocipher/Manifest$ContentProtectionOrBuilder;
    .registers 3

    .line 6882
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentProtection_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$ContentProtectionOrBuilder;

    return-object p1
.end method

.method public getContentProtectionOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/Manifest$ContentProtectionOrBuilder;",
            ">;"
        }
    .end annotation

    .line 6861
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentProtection_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getContentType()Lcom/vdocipher/Manifest$ContentType;
    .registers 2

    .line 6226
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentType_:I

    invoke-static {v0}, Lcom/vdocipher/Manifest$ContentType;->forNumber(I)Lcom/vdocipher/Manifest$ContentType;

    move-result-object v0

    if-nez v0, :cond_a

    .line 6227
    sget-object v0, Lcom/vdocipher/Manifest$ContentType;->UNRECOGNIZED:Lcom/vdocipher/Manifest$ContentType;

    :cond_a
    return-object v0
.end method

.method public getContentTypeValue()I
    .registers 2

    .line 6218
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->contentType_:I

    return v0
.end method

.method public getFrameRate()Ljava/lang/String;
    .registers 2

    .line 6391
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->frameRate_:Ljava/lang/String;

    return-object v0
.end method

.method public getFrameRateBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 6400
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->frameRate_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getHeight()I
    .registers 2

    .line 6357
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->height_:I

    return v0
.end method

.method public getId()I
    .registers 2

    .line 6192
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->id_:I

    return v0
.end method

.method public getLang()Ljava/lang/String;
    .registers 2

    .line 6268
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->lang_:Ljava/lang/String;

    return-object v0
.end method

.method public getLangBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 6277
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->lang_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getMaxFrameRate()Ljava/lang/String;
    .registers 2

    .line 6514
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->maxFrameRate_:Ljava/lang/String;

    return-object v0
.end method

.method public getMaxFrameRateBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 6523
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->maxFrameRate_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getMaxHeight()I
    .registers 2

    .line 6480
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->maxHeight_:I

    return v0
.end method

.method public getMaxWidth()I
    .registers 2

    .line 6446
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->maxWidth_:I

    return v0
.end method

.method public getPar()Lcom/vdocipher/Manifest$AspectRatio;
    .registers 2

    .line 6567
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->par_:Lcom/vdocipher/Manifest$AspectRatio;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/Manifest$AspectRatio;->getDefaultInstance()Lcom/vdocipher/Manifest$AspectRatio;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getRepresentation(I)Lcom/vdocipher/Manifest$Representation;
    .registers 3

    .line 6969
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->representation_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$Representation;

    return-object p1
.end method

.method public getRepresentationCount()I
    .registers 2

    .line 6962
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->representation_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getRepresentationList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$Representation;",
            ">;"
        }
    .end annotation

    .line 6948
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->representation_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getRepresentationOrBuilder(I)Lcom/vdocipher/Manifest$RepresentationOrBuilder;
    .registers 3

    .line 6976
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->representation_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$RepresentationOrBuilder;

    return-object p1
.end method

.method public getRepresentationOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/Manifest$RepresentationOrBuilder;",
            ">;"
        }
    .end annotation

    .line 6955
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->representation_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getRole(I)Lcom/vdocipher/Manifest$Role;
    .registers 3

    .line 6687
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->role_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$Role;

    return-object p1
.end method

.method public getRoleCount()I
    .registers 2

    .line 6680
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->role_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getRoleList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$Role;",
            ">;"
        }
    .end annotation

    .line 6666
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->role_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getRoleOrBuilder(I)Lcom/vdocipher/Manifest$RoleOrBuilder;
    .registers 3

    .line 6694
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->role_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$RoleOrBuilder;

    return-object p1
.end method

.method public getRoleOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/Manifest$RoleOrBuilder;",
            ">;"
        }
    .end annotation

    .line 6673
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->role_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getSubsegmentAlignment()Z
    .registers 2

    .line 6641
    iget-boolean v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->subsegmentAlignment_:Z

    return v0
.end method

.method public getSubsegmentStartsWithSAP()I
    .registers 2

    .line 6615
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->subsegmentStartsWithSAP_:I

    return v0
.end method

.method public getSupplementalProperty(I)Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 3

    .line 6781
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->supplementalProperty_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object p1
.end method

.method public getSupplementalPropertyCount()I
    .registers 2

    .line 6774
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->supplementalProperty_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getSupplementalPropertyList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$SupplementalProperty;",
            ">;"
        }
    .end annotation

    .line 6760
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->supplementalProperty_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getSupplementalPropertyOrBuilder(I)Lcom/vdocipher/Manifest$SupplementalPropertyOrBuilder;
    .registers 3

    .line 6788
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->supplementalProperty_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$SupplementalPropertyOrBuilder;

    return-object p1
.end method

.method public getSupplementalPropertyOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/Manifest$SupplementalPropertyOrBuilder;",
            ">;"
        }
    .end annotation

    .line 6767
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->supplementalProperty_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getWidth()I
    .registers 2

    .line 6323
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->width_:I

    return v0
.end method

.method public hasFrameRate()Z
    .registers 2

    .line 6383
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit8 v0, v0, 0x8

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasHeight()Z
    .registers 2

    .line 6349
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasLang()Z
    .registers 3

    .line 6260
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_7

    return v1

    :cond_7
    const/4 v0, 0x0

    return v0
.end method

.method public hasMaxFrameRate()Z
    .registers 2

    .line 6506
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit8 v0, v0, 0x40

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasMaxHeight()Z
    .registers 2

    .line 6472
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit8 v0, v0, 0x20

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasMaxWidth()Z
    .registers 2

    .line 6438
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasPar()Z
    .registers 2

    .line 6560
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit16 v0, v0, 0x80

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasSubsegmentStartsWithSAP()Z
    .registers 2

    .line 6607
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit16 v0, v0, 0x100

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasWidth()Z
    .registers 2

    .line 6315
    iget v0, p0, Lcom/vdocipher/Manifest$AdaptationSet;->bitField0_:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method
