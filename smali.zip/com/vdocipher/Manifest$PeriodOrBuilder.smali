# classes14.dex

.class public interface abstract Lcom/vdocipher/Manifest$PeriodOrBuilder;
.super Ljava/lang/Object;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "PeriodOrBuilder"
.end annotation


# virtual methods
.method public abstract getAdaptationSet(I)Lcom/vdocipher/Manifest$AdaptationSet;
.end method

.method public abstract getAdaptationSetCount()I
.end method

.method public abstract getAdaptationSetList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$AdaptationSet;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getDuration()Ljava/lang/String;
.end method

.method public abstract getDurationBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getId()I
.end method

.method public abstract hasDuration()Z
.end method
