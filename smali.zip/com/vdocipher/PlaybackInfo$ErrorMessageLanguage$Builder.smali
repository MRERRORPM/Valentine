# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguageOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;",
        "Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguageOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 10358
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackInfo-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearDirection()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 2

    .line 10501
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->copyOnWrite()V

    .line 10502
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$mclearDirection(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V

    return-object p0
.end method

.method public clearHash()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 2

    .line 10444
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->copyOnWrite()V

    .line 10445
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$mclearHash(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V

    return-object p0
.end method

.method public clearId()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 2

    .line 10395
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->copyOnWrite()V

    .line 10396
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$mclearId(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V

    return-object p0
.end method

.method public clearLanguage()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 2

    .line 10588
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->copyOnWrite()V

    .line 10589
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$mclearLanguage(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V

    return-object p0
.end method

.method public clearName()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 2

    .line 10539
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->copyOnWrite()V

    .line 10540
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$mclearName(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V

    return-object p0
.end method

.method public getDirection()Lcom/vdocipher/PlaybackInfo$MessageDirection;
    .registers 2

    .line 10484
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getDirection()Lcom/vdocipher/PlaybackInfo$MessageDirection;

    move-result-object v0

    return-object v0
.end method

.method public getDirectionValue()I
    .registers 2

    .line 10466
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getDirectionValue()I

    move-result v0

    return v0
.end method

.method public getHash()Ljava/lang/String;
    .registers 2

    .line 10417
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getHash()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getHashBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 10426
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getHashBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getId()Ljava/lang/String;
    .registers 2

    .line 10368
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getIdBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 10377
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getIdBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getLanguage()Ljava/lang/String;
    .registers 2

    .line 10561
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getLanguage()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getLanguageBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 10570
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getLanguageBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getName()Ljava/lang/String;
    .registers 2

    .line 10512
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getNameBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 10521
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getNameBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setDirection(Lcom/vdocipher/PlaybackInfo$MessageDirection;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 3

    .line 10492
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->copyOnWrite()V

    .line 10493
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$msetDirection(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Lcom/vdocipher/PlaybackInfo$MessageDirection;)V

    return-object p0
.end method

.method public setDirectionValue(I)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 3

    .line 10474
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->copyOnWrite()V

    .line 10475
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$msetDirectionValue(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;I)V

    return-object p0
.end method

.method public setHash(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 3

    .line 10435
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->copyOnWrite()V

    .line 10436
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$msetHash(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Ljava/lang/String;)V

    return-object p0
.end method

.method public setHashBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 3

    .line 10455
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->copyOnWrite()V

    .line 10456
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$msetHashBytes(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setId(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 3

    .line 10386
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->copyOnWrite()V

    .line 10387
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$msetId(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Ljava/lang/String;)V

    return-object p0
.end method

.method public setIdBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 3

    .line 10406
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->copyOnWrite()V

    .line 10407
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$msetIdBytes(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setLanguage(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 3

    .line 10579
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->copyOnWrite()V

    .line 10580
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$msetLanguage(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Ljava/lang/String;)V

    return-object p0
.end method

.method public setLanguageBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 3

    .line 10599
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->copyOnWrite()V

    .line 10600
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$msetLanguageBytes(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setName(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 3

    .line 10530
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->copyOnWrite()V

    .line 10531
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$msetName(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Ljava/lang/String;)V

    return-object p0
.end method

.method public setNameBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 3

    .line 10550
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->copyOnWrite()V

    .line 10551
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->-$$Nest$msetNameBytes(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
