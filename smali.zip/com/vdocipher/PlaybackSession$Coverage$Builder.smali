# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Coverage$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$CoverageOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$Coverage;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$Coverage;",
        "Lcom/vdocipher/PlaybackSession$Coverage$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$CoverageOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 5414
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Coverage;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Coverage;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Coverage$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public addAllIndices(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackSession$Coverage$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Ljava/lang/Integer;",
            ">;)",
            "Lcom/vdocipher/PlaybackSession$Coverage$Builder;"
        }
    .end annotation

    .line 5473
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->copyOnWrite()V

    .line 5474
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Coverage;->-$$Nest$maddAllIndices(Lcom/vdocipher/PlaybackSession$Coverage;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllValues(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackSession$Coverage$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Ljava/lang/Integer;",
            ">;)",
            "Lcom/vdocipher/PlaybackSession$Coverage$Builder;"
        }
    .end annotation

    .line 5542
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->copyOnWrite()V

    .line 5543
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Coverage;->-$$Nest$maddAllValues(Lcom/vdocipher/PlaybackSession$Coverage;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addIndices(I)Lcom/vdocipher/PlaybackSession$Coverage$Builder;
    .registers 3

    .line 5462
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->copyOnWrite()V

    .line 5463
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Coverage;->-$$Nest$maddIndices(Lcom/vdocipher/PlaybackSession$Coverage;I)V

    return-object p0
.end method

.method public addValues(I)Lcom/vdocipher/PlaybackSession$Coverage$Builder;
    .registers 3

    .line 5531
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->copyOnWrite()V

    .line 5532
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Coverage;->-$$Nest$maddValues(Lcom/vdocipher/PlaybackSession$Coverage;I)V

    return-object p0
.end method

.method public clearIndices()Lcom/vdocipher/PlaybackSession$Coverage$Builder;
    .registers 2

    .line 5482
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->copyOnWrite()V

    .line 5483
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Coverage;->-$$Nest$mclearIndices(Lcom/vdocipher/PlaybackSession$Coverage;)V

    return-object p0
.end method

.method public clearLength()Lcom/vdocipher/PlaybackSession$Coverage$Builder;
    .registers 2

    .line 5579
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->copyOnWrite()V

    .line 5580
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Coverage;->-$$Nest$mclearLength(Lcom/vdocipher/PlaybackSession$Coverage;)V

    return-object p0
.end method

.method public clearValues()Lcom/vdocipher/PlaybackSession$Coverage$Builder;
    .registers 2

    .line 5551
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->copyOnWrite()V

    .line 5552
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Coverage;->-$$Nest$mclearValues(Lcom/vdocipher/PlaybackSession$Coverage;)V

    return-object p0
.end method

.method public getIndices(I)I
    .registers 3

    .line 5443
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$Coverage;->getIndices(I)I

    move-result p1

    return p1
.end method

.method public getIndicesCount()I
    .registers 2

    .line 5434
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Coverage;->getIndicesCount()I

    move-result v0

    return v0
.end method

.method public getIndicesList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 5425
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    .line 5426
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Coverage;->getIndicesList()Ljava/util/List;

    move-result-object v0

    .line 5425
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getLength()I
    .registers 2

    .line 5562
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Coverage;->getLength()I

    move-result v0

    return v0
.end method

.method public getValues(I)I
    .registers 3

    .line 5512
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$Coverage;->getValues(I)I

    move-result p1

    return p1
.end method

.method public getValuesCount()I
    .registers 2

    .line 5503
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Coverage;->getValuesCount()I

    move-result v0

    return v0
.end method

.method public getValuesList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 5494
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    .line 5495
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Coverage;->getValuesList()Ljava/util/List;

    move-result-object v0

    .line 5494
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public setIndices(II)Lcom/vdocipher/PlaybackSession$Coverage$Builder;
    .registers 4

    .line 5452
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->copyOnWrite()V

    .line 5453
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$Coverage;->-$$Nest$msetIndices(Lcom/vdocipher/PlaybackSession$Coverage;II)V

    return-object p0
.end method

.method public setLength(I)Lcom/vdocipher/PlaybackSession$Coverage$Builder;
    .registers 3

    .line 5570
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->copyOnWrite()V

    .line 5571
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Coverage;->-$$Nest$msetLength(Lcom/vdocipher/PlaybackSession$Coverage;I)V

    return-object p0
.end method

.method public setValues(II)Lcom/vdocipher/PlaybackSession$Coverage$Builder;
    .registers 4

    .line 5521
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->copyOnWrite()V

    .line 5522
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$Coverage;->-$$Nest$msetValues(Lcom/vdocipher/PlaybackSession$Coverage;II)V

    return-object p0
.end method
