# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Android;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$AndroidOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Android"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$Android$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$Android;",
        "Lcom/vdocipher/PlaybackSession$Android$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$AndroidOrBuilder;"
    }
.end annotation


# static fields
.field public static final APILEVEL_FIELD_NUMBER:I = 0x3

.field public static final DECODER_FIELD_NUMBER:I = 0xb

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

.field public static final DEVICE_FIELD_NUMBER:I = 0x4

.field public static final ISDEBUG_FIELD_NUMBER:I = 0x7

.field public static final ISSIGNED_FIELD_NUMBER:I = 0x8

.field public static final LASTBOOTTIME_FIELD_NUMBER:I = 0x9

.field public static final LASTOSUPDATETIME_FIELD_NUMBER:I = 0xa

.field public static final MANUFACTURER_FIELD_NUMBER:I = 0x6

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Android;",
            ">;"
        }
    .end annotation
.end field

.field public static final PRIMARYABI_FIELD_NUMBER:I = 0x1

.field public static final PRODUCT_FIELD_NUMBER:I = 0x5

.field public static final REFVERSION_FIELD_NUMBER:I = 0xc

.field public static final SECONDARYABI_FIELD_NUMBER:I = 0x2


# instance fields
.field private apiLevel_:I

.field private decoder_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/PlaybackSession$Decoder;",
            ">;"
        }
    .end annotation
.end field

.field private device_:Ljava/lang/String;

.field private isDebug_:Z

.field private isSigned_:Z

.field private lastBootTime_:I

.field private lastOSUpdateTime_:I

.field private manufacturer_:Ljava/lang/String;

.field private primaryAbi_:Ljava/lang/String;

.field private product_:Ljava/lang/String;

.field private refVersion_:Ljava/lang/String;

.field private secondaryAbi_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$maddAllDecoder(Lcom/vdocipher/PlaybackSession$Android;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->addAllDecoder(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddDecoder(Lcom/vdocipher/PlaybackSession$Android;ILcom/vdocipher/PlaybackSession$Decoder;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackSession$Android;->addDecoder(ILcom/vdocipher/PlaybackSession$Decoder;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddDecoder(Lcom/vdocipher/PlaybackSession$Android;Lcom/vdocipher/PlaybackSession$Decoder;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->addDecoder(Lcom/vdocipher/PlaybackSession$Decoder;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearApiLevel(Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->clearApiLevel()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearDecoder(Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->clearDecoder()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearDevice(Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->clearDevice()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearIsDebug(Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->clearIsDebug()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearIsSigned(Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->clearIsSigned()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLastBootTime(Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->clearLastBootTime()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLastOSUpdateTime(Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->clearLastOSUpdateTime()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearManufacturer(Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->clearManufacturer()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPrimaryAbi(Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->clearPrimaryAbi()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearProduct(Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->clearProduct()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearRefVersion(Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->clearRefVersion()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSecondaryAbi(Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->clearSecondaryAbi()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveDecoder(Lcom/vdocipher/PlaybackSession$Android;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->removeDecoder(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetApiLevel(Lcom/vdocipher/PlaybackSession$Android;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setApiLevel(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDecoder(Lcom/vdocipher/PlaybackSession$Android;ILcom/vdocipher/PlaybackSession$Decoder;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackSession$Android;->setDecoder(ILcom/vdocipher/PlaybackSession$Decoder;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDevice(Lcom/vdocipher/PlaybackSession$Android;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setDevice(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDeviceBytes(Lcom/vdocipher/PlaybackSession$Android;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setDeviceBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIsDebug(Lcom/vdocipher/PlaybackSession$Android;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setIsDebug(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIsSigned(Lcom/vdocipher/PlaybackSession$Android;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setIsSigned(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLastBootTime(Lcom/vdocipher/PlaybackSession$Android;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setLastBootTime(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLastOSUpdateTime(Lcom/vdocipher/PlaybackSession$Android;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setLastOSUpdateTime(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetManufacturer(Lcom/vdocipher/PlaybackSession$Android;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setManufacturer(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetManufacturerBytes(Lcom/vdocipher/PlaybackSession$Android;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setManufacturerBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPrimaryAbi(Lcom/vdocipher/PlaybackSession$Android;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setPrimaryAbi(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPrimaryAbiBytes(Lcom/vdocipher/PlaybackSession$Android;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setPrimaryAbiBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetProduct(Lcom/vdocipher/PlaybackSession$Android;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setProduct(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetProductBytes(Lcom/vdocipher/PlaybackSession$Android;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setProductBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetRefVersion(Lcom/vdocipher/PlaybackSession$Android;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setRefVersion(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetRefVersionBytes(Lcom/vdocipher/PlaybackSession$Android;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setRefVersionBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSecondaryAbi(Lcom/vdocipher/PlaybackSession$Android;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setSecondaryAbi(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSecondaryAbiBytes(Lcom/vdocipher/PlaybackSession$Android;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->setSecondaryAbiBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Android;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 13342
    new-instance v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$Android;-><init>()V

    .line 13345
    sput-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    .line 13346
    const-class v1, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 3

    .line 12125
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 12126
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->primaryAbi_:Ljava/lang/String;

    .line 12127
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->secondaryAbi_:Ljava/lang/String;

    .line 12128
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->device_:Ljava/lang/String;

    .line 12129
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->product_:Ljava/lang/String;

    .line 12130
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->manufacturer_:Ljava/lang/String;

    .line 12131
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Android;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v1

    iput-object v1, p0, Lcom/vdocipher/PlaybackSession$Android;->decoder_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 12132
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->refVersion_:Ljava/lang/String;

    return-void
.end method

.method private addAllDecoder(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackSession$Decoder;",
            ">;)V"
        }
    .end annotation

    .line 12575
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->ensureDecoderIsMutable()V

    .line 12576
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->decoder_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addDecoder(ILcom/vdocipher/PlaybackSession$Decoder;)V
    .registers 4

    .line 12566
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12567
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->ensureDecoderIsMutable()V

    .line 12568
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->decoder_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addDecoder(Lcom/vdocipher/PlaybackSession$Decoder;)V
    .registers 3

    .line 12557
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12558
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->ensureDecoderIsMutable()V

    .line 12559
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->decoder_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private clearApiLevel()V
    .registers 2

    const/4 v0, 0x0

    .line 12251
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Android;->apiLevel_:I

    return-void
.end method

.method private clearDecoder()V
    .registers 2

    .line 12583
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Android;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->decoder_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearDevice()V
    .registers 2

    .line 12288
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Android;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Android;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getDevice()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->device_:Ljava/lang/String;

    return-void
.end method

.method private clearIsDebug()V
    .registers 2

    const/4 v0, 0x0

    .line 12418
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Android;->isDebug_:Z

    return-void
.end method

.method private clearIsSigned()V
    .registers 2

    const/4 v0, 0x0

    .line 12444
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Android;->isSigned_:Z

    return-void
.end method

.method private clearLastBootTime()V
    .registers 2

    const/4 v0, 0x0

    .line 12470
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Android;->lastBootTime_:I

    return-void
.end method

.method private clearLastOSUpdateTime()V
    .registers 2

    const/4 v0, 0x0

    .line 12496
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Android;->lastOSUpdateTime_:I

    return-void
.end method

.method private clearManufacturer()V
    .registers 2

    .line 12382
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Android;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Android;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getManufacturer()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->manufacturer_:Ljava/lang/String;

    return-void
.end method

.method private clearPrimaryAbi()V
    .registers 2

    .line 12168
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Android;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Android;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getPrimaryAbi()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->primaryAbi_:Ljava/lang/String;

    return-void
.end method

.method private clearProduct()V
    .registers 2

    .line 12335
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Android;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Android;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getProduct()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->product_:Ljava/lang/String;

    return-void
.end method

.method private clearRefVersion()V
    .registers 2

    .line 12627
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Android;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Android;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getRefVersion()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->refVersion_:Ljava/lang/String;

    return-void
.end method

.method private clearSecondaryAbi()V
    .registers 2

    .line 12215
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Android;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Android;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getSecondaryAbi()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->secondaryAbi_:Ljava/lang/String;

    return-void
.end method

.method private ensureDecoderIsMutable()V
    .registers 3

    .line 12537
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->decoder_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 12538
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 12540
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->decoder_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$Android;
    .registers 1

    .line 13351
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 1

    .line 12717
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$Android;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 2

    .line 12720
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$Android;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Android$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Android;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 12693
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$Android;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Android;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Android;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 12700
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$Android;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Android;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Android;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 12656
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Android;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Android;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 12663
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Android;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$Android;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 12705
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Android;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Android;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 12712
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Android;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Android;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 12680
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Android;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Android;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 12687
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Android;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$Android;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 12643
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Android;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Android;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 12650
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Android;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$Android;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 12668
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Android;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Android;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 12675
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Android;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Android;",
            ">;"
        }
    .end annotation

    .line 13357
    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private removeDecoder(I)V
    .registers 3

    .line 12589
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->ensureDecoderIsMutable()V

    .line 12590
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->decoder_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private setApiLevel(I)V
    .registers 2

    .line 12244
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Android;->apiLevel_:I

    return-void
.end method

.method private setDecoder(ILcom/vdocipher/PlaybackSession$Decoder;)V
    .registers 4

    .line 12549
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12550
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android;->ensureDecoderIsMutable()V

    .line 12551
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->decoder_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setDevice(Ljava/lang/String;)V
    .registers 2

    .line 12279
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12281
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Android;->device_:Ljava/lang/String;

    return-void
.end method

.method private setDeviceBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 12296
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Android;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 12297
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Android;->device_:Ljava/lang/String;

    return-void
.end method

.method private setIsDebug(Z)V
    .registers 2

    .line 12411
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackSession$Android;->isDebug_:Z

    return-void
.end method

.method private setIsSigned(Z)V
    .registers 2

    .line 12437
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackSession$Android;->isSigned_:Z

    return-void
.end method

.method private setLastBootTime(I)V
    .registers 2

    .line 12463
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Android;->lastBootTime_:I

    return-void
.end method

.method private setLastOSUpdateTime(I)V
    .registers 2

    .line 12489
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Android;->lastOSUpdateTime_:I

    return-void
.end method

.method private setManufacturer(Ljava/lang/String;)V
    .registers 2

    .line 12373
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12375
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Android;->manufacturer_:Ljava/lang/String;

    return-void
.end method

.method private setManufacturerBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 12390
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Android;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 12391
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Android;->manufacturer_:Ljava/lang/String;

    return-void
.end method

.method private setPrimaryAbi(Ljava/lang/String;)V
    .registers 2

    .line 12159
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12161
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Android;->primaryAbi_:Ljava/lang/String;

    return-void
.end method

.method private setPrimaryAbiBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 12176
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Android;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 12177
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Android;->primaryAbi_:Ljava/lang/String;

    return-void
.end method

.method private setProduct(Ljava/lang/String;)V
    .registers 2

    .line 12326
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12328
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Android;->product_:Ljava/lang/String;

    return-void
.end method

.method private setProductBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 12343
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Android;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 12344
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Android;->product_:Ljava/lang/String;

    return-void
.end method

.method private setRefVersion(Ljava/lang/String;)V
    .registers 2

    .line 12618
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12620
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Android;->refVersion_:Ljava/lang/String;

    return-void
.end method

.method private setRefVersionBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 12635
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Android;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 12636
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Android;->refVersion_:Ljava/lang/String;

    return-void
.end method

.method private setSecondaryAbi(Ljava/lang/String;)V
    .registers 2

    .line 12206
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12208
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Android;->secondaryAbi_:Ljava/lang/String;

    return-void
.end method

.method private setSecondaryAbiBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 12223
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Android;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 12224
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Android;->secondaryAbi_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 17

    .line 13280
    sget-object v0, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, v0, p1

    const/4 v0, 0x0

    packed-switch p1, :pswitch_data_6a

    .line 13335
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object v0

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 13329
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 13314
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$Android;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_33

    .line 13316
    const-class v1, Lcom/vdocipher/PlaybackSession$Android;

    monitor-enter v1

    .line 13317
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$Android;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 13319
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object v0, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-direct {p1, v0}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 13322
    sput-object p1, Lcom/vdocipher/PlaybackSession$Android;->PARSER:Lcom/google/protobuf/Parser;

    .line 13324
    :cond_2d
    monitor-exit v1

    return-object p1

    :catchall_2f
    move-exception v0

    move-object p1, v0

    monitor-exit v1
    :try_end_32
    .catchall {:try_start_20 .. :try_end_32} :catchall_2f

    throw p1

    :cond_33
    return-object p1

    .line 13311
    :pswitch_34  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    return-object p1

    .line 13288
    :pswitch_37  #0x3
    const-string v0, "primaryAbi_"

    const-string v1, "secondaryAbi_"

    const-string v2, "apiLevel_"

    const-string v3, "device_"

    const-string v4, "product_"

    const-string v5, "manufacturer_"

    const-string v6, "isDebug_"

    const-string v7, "isSigned_"

    const-string v8, "lastBootTime_"

    const-string v9, "lastOSUpdateTime_"

    const-string v10, "decoder_"

    const-class v11, Lcom/vdocipher/PlaybackSession$Decoder;

    const-string v12, "refVersion_"

    filled-new-array/range {v0 .. v12}, [Ljava/lang/Object;

    move-result-object p1

    .line 13303
    const-string v0, "\u0000\f\u0000\u0000\u0001\f\f\u0000\u0001\u0000\u0001Ȉ\u0002Ȉ\u0003\u000b\u0004Ȉ\u0005Ȉ\u0006Ȉ\u0007\u0007\b\u0007\t\u000b\n\u000b\u000b\u001b\fȈ"

    .line 13307
    sget-object v1, Lcom/vdocipher/PlaybackSession$Android;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v1, v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 13285
    :pswitch_5e  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$Android$Builder;

    invoke-direct {p1, v0}, Lcom/vdocipher/PlaybackSession$Android$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 13282
    :pswitch_64  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$Android;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$Android;-><init>()V

    return-object p1

    :pswitch_data_6a
    .packed-switch 0x1
        :pswitch_64  #00000001
        :pswitch_5e  #00000002
        :pswitch_37  #00000003
        :pswitch_34  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getApiLevel()I
    .registers 2

    .line 12236
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Android;->apiLevel_:I

    return v0
.end method

.method public getDecoder(I)Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 3

    .line 12527
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->decoder_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Decoder;

    return-object p1
.end method

.method public getDecoderCount()I
    .registers 2

    .line 12520
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->decoder_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getDecoderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackSession$Decoder;",
            ">;"
        }
    .end annotation

    .line 12506
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->decoder_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getDecoderOrBuilder(I)Lcom/vdocipher/PlaybackSession$DecoderOrBuilder;
    .registers 3

    .line 12534
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->decoder_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$DecoderOrBuilder;

    return-object p1
.end method

.method public getDecoderOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/PlaybackSession$DecoderOrBuilder;",
            ">;"
        }
    .end annotation

    .line 12513
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->decoder_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getDevice()Ljava/lang/String;
    .registers 2

    .line 12262
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->device_:Ljava/lang/String;

    return-object v0
.end method

.method public getDeviceBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 12271
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->device_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getIsDebug()Z
    .registers 2

    .line 12403
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Android;->isDebug_:Z

    return v0
.end method

.method public getIsSigned()Z
    .registers 2

    .line 12429
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Android;->isSigned_:Z

    return v0
.end method

.method public getLastBootTime()I
    .registers 2

    .line 12455
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Android;->lastBootTime_:I

    return v0
.end method

.method public getLastOSUpdateTime()I
    .registers 2

    .line 12481
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Android;->lastOSUpdateTime_:I

    return v0
.end method

.method public getManufacturer()Ljava/lang/String;
    .registers 2

    .line 12356
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->manufacturer_:Ljava/lang/String;

    return-object v0
.end method

.method public getManufacturerBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 12365
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->manufacturer_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getPrimaryAbi()Ljava/lang/String;
    .registers 2

    .line 12142
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->primaryAbi_:Ljava/lang/String;

    return-object v0
.end method

.method public getPrimaryAbiBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 12151
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->primaryAbi_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getProduct()Ljava/lang/String;
    .registers 2

    .line 12309
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->product_:Ljava/lang/String;

    return-object v0
.end method

.method public getProductBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 12318
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->product_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getRefVersion()Ljava/lang/String;
    .registers 2

    .line 12601
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->refVersion_:Ljava/lang/String;

    return-object v0
.end method

.method public getRefVersionBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 12610
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->refVersion_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSecondaryAbi()Ljava/lang/String;
    .registers 2

    .line 12189
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->secondaryAbi_:Ljava/lang/String;

    return-object v0
.end method

.method public getSecondaryAbiBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 12198
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android;->secondaryAbi_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method
