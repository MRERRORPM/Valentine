# classes14.dex

.class public interface abstract Lcom/vdocipher/Manifest$AdaptationSetOrBuilder;
.super Ljava/lang/Object;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "AdaptationSetOrBuilder"
.end annotation


# virtual methods
.method public abstract getContentProtection(I)Lcom/vdocipher/Manifest$ContentProtection;
.end method

.method public abstract getContentProtectionCount()I
.end method

.method public abstract getContentProtectionList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$ContentProtection;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getContentType()Lcom/vdocipher/Manifest$ContentType;
.end method

.method public abstract getContentTypeValue()I
.end method

.method public abstract getFrameRate()Ljava/lang/String;
.end method

.method public abstract getFrameRateBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getHeight()I
.end method

.method public abstract getId()I
.end method

.method public abstract getLang()Ljava/lang/String;
.end method

.method public abstract getLangBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getMaxFrameRate()Ljava/lang/String;
.end method

.method public abstract getMaxFrameRateBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getMaxHeight()I
.end method

.method public abstract getMaxWidth()I
.end method

.method public abstract getPar()Lcom/vdocipher/Manifest$AspectRatio;
.end method

.method public abstract getRepresentation(I)Lcom/vdocipher/Manifest$Representation;
.end method

.method public abstract getRepresentationCount()I
.end method

.method public abstract getRepresentationList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$Representation;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getRole(I)Lcom/vdocipher/Manifest$Role;
.end method

.method public abstract getRoleCount()I
.end method

.method public abstract getRoleList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$Role;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getSubsegmentAlignment()Z
.end method

.method public abstract getSubsegmentStartsWithSAP()I
.end method

.method public abstract getSupplementalProperty(I)Lcom/vdocipher/Manifest$SupplementalProperty;
.end method

.method public abstract getSupplementalPropertyCount()I
.end method

.method public abstract getSupplementalPropertyList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$SupplementalProperty;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getWidth()I
.end method

.method public abstract hasFrameRate()Z
.end method

.method public abstract hasHeight()Z
.end method

.method public abstract hasLang()Z
.end method

.method public abstract hasMaxFrameRate()Z
.end method

.method public abstract hasMaxHeight()Z
.end method

.method public abstract hasMaxWidth()Z
.end method

.method public abstract hasPar()Z
.end method

.method public abstract hasSubsegmentStartsWithSAP()Z
.end method

.method public abstract hasWidth()Z
.end method
