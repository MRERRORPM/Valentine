# classes14.dex

.class final Lcom/vdocipher/PlaybackInfo$MessageDirection$MessageDirectionVerifier;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumVerifier;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$MessageDirection;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "MessageDirectionVerifier"
.end annotation


# static fields
.field static final INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 585
    new-instance v0, Lcom/vdocipher/PlaybackInfo$MessageDirection$MessageDirectionVerifier;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$MessageDirection$MessageDirectionVerifier;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$MessageDirection$MessageDirectionVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 583
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public isInRange(I)Z
    .registers 2

    .line 588
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$MessageDirection;->forNumber(I)Lcom/vdocipher/PlaybackInfo$MessageDirection;

    move-result-object p1

    if-eqz p1, :cond_8

    const/4 p1, 0x1

    return p1

    :cond_8
    const/4 p1, 0x0

    return p1
.end method
