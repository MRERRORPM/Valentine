# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$NavigatorPropsOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$NavigatorProps;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$NavigatorProps;",
        "Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$NavigatorPropsOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 4753
    invoke-static {}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$NavigatorProps;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearConcurrency()Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 2

    .line 4927
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 4928
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$mclearConcurrency(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V

    return-object p0
.end method

.method public clearDoNotTrack()Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 2

    .line 4955
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 4956
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$mclearDoNotTrack(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V

    return-object p0
.end method

.method public clearLangaugesKnown()Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 2

    .line 4839
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 4840
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$mclearLangaugesKnown(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V

    return-object p0
.end method

.method public clearLanguagePreferred()Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 2

    .line 4790
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 4791
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$mclearLanguagePreferred(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V

    return-object p0
.end method

.method public clearOnline()Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 2

    .line 4983
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 4984
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$mclearOnline(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V

    return-object p0
.end method

.method public clearPlatform()Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 2

    .line 4888
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 4889
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$mclearPlatform(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V

    return-object p0
.end method

.method public clearTouchPoints()Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 2

    .line 5011
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 5012
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$mclearTouchPoints(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V

    return-object p0
.end method

.method public getConcurrency()I
    .registers 2

    .line 4910
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getConcurrency()I

    move-result v0

    return v0
.end method

.method public getDoNotTrack()Z
    .registers 2

    .line 4938
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getDoNotTrack()Z

    move-result v0

    return v0
.end method

.method public getLangaugesKnown()Ljava/lang/String;
    .registers 2

    .line 4812
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getLangaugesKnown()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getLangaugesKnownBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 4821
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getLangaugesKnownBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getLanguagePreferred()Ljava/lang/String;
    .registers 2

    .line 4763
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getLanguagePreferred()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getLanguagePreferredBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 4772
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getLanguagePreferredBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getOnline()Z
    .registers 2

    .line 4966
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getOnline()Z

    move-result v0

    return v0
.end method

.method public getPlatform()Ljava/lang/String;
    .registers 2

    .line 4861
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getPlatform()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getPlatformBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 4870
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getPlatformBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getTouchPoints()I
    .registers 2

    .line 4994
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getTouchPoints()I

    move-result v0

    return v0
.end method

.method public setConcurrency(I)Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 3

    .line 4918
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 4919
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$msetConcurrency(Lcom/vdocipher/PlaybackSession$NavigatorProps;I)V

    return-object p0
.end method

.method public setDoNotTrack(Z)Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 3

    .line 4946
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 4947
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$msetDoNotTrack(Lcom/vdocipher/PlaybackSession$NavigatorProps;Z)V

    return-object p0
.end method

.method public setLangaugesKnown(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 3

    .line 4830
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 4831
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$msetLangaugesKnown(Lcom/vdocipher/PlaybackSession$NavigatorProps;Ljava/lang/String;)V

    return-object p0
.end method

.method public setLangaugesKnownBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 3

    .line 4850
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 4851
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$msetLangaugesKnownBytes(Lcom/vdocipher/PlaybackSession$NavigatorProps;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setLanguagePreferred(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 3

    .line 4781
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 4782
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$msetLanguagePreferred(Lcom/vdocipher/PlaybackSession$NavigatorProps;Ljava/lang/String;)V

    return-object p0
.end method

.method public setLanguagePreferredBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 3

    .line 4801
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 4802
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$msetLanguagePreferredBytes(Lcom/vdocipher/PlaybackSession$NavigatorProps;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setOnline(Z)Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 3

    .line 4974
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 4975
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$msetOnline(Lcom/vdocipher/PlaybackSession$NavigatorProps;Z)V

    return-object p0
.end method

.method public setPlatform(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 3

    .line 4879
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 4880
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$msetPlatform(Lcom/vdocipher/PlaybackSession$NavigatorProps;Ljava/lang/String;)V

    return-object p0
.end method

.method public setPlatformBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 3

    .line 4899
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 4900
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$msetPlatformBytes(Lcom/vdocipher/PlaybackSession$NavigatorProps;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setTouchPoints(I)Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 3

    .line 5002
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->copyOnWrite()V

    .line 5003
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->-$$Nest$msetTouchPoints(Lcom/vdocipher/PlaybackSession$NavigatorProps;I)V

    return-object p0
.end method
