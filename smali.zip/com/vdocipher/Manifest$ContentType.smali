# classes14.dex

.class public final enum Lcom/vdocipher/Manifest$ContentType;
.super Ljava/lang/Enum;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "ContentType"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$ContentType$ContentTypeVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/Manifest$ContentType;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/Manifest$ContentType;

.field public static final enum AUDIO:Lcom/vdocipher/Manifest$ContentType;

.field public static final AUDIO_VALUE:I = 0x0

.field public static final enum TEXT:Lcom/vdocipher/Manifest$ContentType;

.field public static final TEXT_VALUE:I = 0x2

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/Manifest$ContentType;

.field public static final enum VIDEO:Lcom/vdocipher/Manifest$ContentType;

.field public static final VIDEO_VALUE:I = 0x1

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/Manifest$ContentType;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 7

    .line 207
    new-instance v0, Lcom/vdocipher/Manifest$ContentType;

    const-string v1, "AUDIO"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/Manifest$ContentType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/Manifest$ContentType;->AUDIO:Lcom/vdocipher/Manifest$ContentType;

    .line 211
    new-instance v1, Lcom/vdocipher/Manifest$ContentType;

    const-string v2, "VIDEO"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/Manifest$ContentType;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/Manifest$ContentType;->VIDEO:Lcom/vdocipher/Manifest$ContentType;

    .line 215
    new-instance v2, Lcom/vdocipher/Manifest$ContentType;

    const-string v3, "TEXT"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4, v4}, Lcom/vdocipher/Manifest$ContentType;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/Manifest$ContentType;->TEXT:Lcom/vdocipher/Manifest$ContentType;

    .line 216
    new-instance v3, Lcom/vdocipher/Manifest$ContentType;

    const/4 v4, 0x3

    const/4 v5, -0x1

    const-string v6, "UNRECOGNIZED"

    invoke-direct {v3, v6, v4, v5}, Lcom/vdocipher/Manifest$ContentType;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lcom/vdocipher/Manifest$ContentType;->UNRECOGNIZED:Lcom/vdocipher/Manifest$ContentType;

    .line 202
    filled-new-array {v0, v1, v2, v3}, [Lcom/vdocipher/Manifest$ContentType;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/Manifest$ContentType;->$VALUES:[Lcom/vdocipher/Manifest$ContentType;

    .line 266
    new-instance v0, Lcom/vdocipher/Manifest$ContentType$1;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$ContentType$1;-><init>()V

    sput-object v0, Lcom/vdocipher/Manifest$ContentType;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 290
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 291
    iput p3, p0, Lcom/vdocipher/Manifest$ContentType;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/Manifest$ContentType;
    .registers 2

    if-eqz p0, :cond_10

    const/4 v0, 0x1

    if-eq p0, v0, :cond_d

    const/4 v0, 0x2

    if-eq p0, v0, :cond_a

    const/4 p0, 0x0

    return-object p0

    .line 256
    :cond_a
    sget-object p0, Lcom/vdocipher/Manifest$ContentType;->TEXT:Lcom/vdocipher/Manifest$ContentType;

    return-object p0

    .line 255
    :cond_d
    sget-object p0, Lcom/vdocipher/Manifest$ContentType;->VIDEO:Lcom/vdocipher/Manifest$ContentType;

    return-object p0

    .line 254
    :cond_10
    sget-object p0, Lcom/vdocipher/Manifest$ContentType;->AUDIO:Lcom/vdocipher/Manifest$ContentType;

    return-object p0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/Manifest$ContentType;",
            ">;"
        }
    .end annotation

    .line 263
    sget-object v0, Lcom/vdocipher/Manifest$ContentType;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 276
    sget-object v0, Lcom/vdocipher/Manifest$ContentType$ContentTypeVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/Manifest$ContentType;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 249
    invoke-static {p0}, Lcom/vdocipher/Manifest$ContentType;->forNumber(I)Lcom/vdocipher/Manifest$ContentType;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/Manifest$ContentType;
    .registers 2

    .line 202
    const-class v0, Lcom/vdocipher/Manifest$ContentType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$ContentType;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/Manifest$ContentType;
    .registers 1

    .line 202
    sget-object v0, Lcom/vdocipher/Manifest$ContentType;->$VALUES:[Lcom/vdocipher/Manifest$ContentType;

    invoke-virtual {v0}, [Lcom/vdocipher/Manifest$ContentType;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/Manifest$ContentType;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 235
    sget-object v0, Lcom/vdocipher/Manifest$ContentType;->UNRECOGNIZED:Lcom/vdocipher/Manifest$ContentType;

    if-eq p0, v0, :cond_7

    .line 239
    iget v0, p0, Lcom/vdocipher/Manifest$ContentType;->value:I

    return v0

    .line 236
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
