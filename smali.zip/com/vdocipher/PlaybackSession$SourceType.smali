# classes14.dex

.class public final enum Lcom/vdocipher/PlaybackSession$SourceType;
.super Ljava/lang/Enum;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "SourceType"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$SourceType$SourceTypeVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/PlaybackSession$SourceType;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/PlaybackSession$SourceType;

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$SourceType;

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$SourceType;",
            ">;"
        }
    .end annotation
.end field

.field public static final enum offline:Lcom/vdocipher/PlaybackSession$SourceType;

.field public static final offline_VALUE:I = 0x1

.field public static final enum streaming:Lcom/vdocipher/PlaybackSession$SourceType;

.field public static final streaming_VALUE:I


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 6

    .line 109
    new-instance v0, Lcom/vdocipher/PlaybackSession$SourceType;

    const-string/jumbo v1, "streaming"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/PlaybackSession$SourceType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$SourceType;->streaming:Lcom/vdocipher/PlaybackSession$SourceType;

    .line 113
    new-instance v1, Lcom/vdocipher/PlaybackSession$SourceType;

    const-string v2, "offline"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/PlaybackSession$SourceType;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$SourceType;->offline:Lcom/vdocipher/PlaybackSession$SourceType;

    .line 114
    new-instance v2, Lcom/vdocipher/PlaybackSession$SourceType;

    const/4 v3, 0x2

    const/4 v4, -0x1

    const-string v5, "UNRECOGNIZED"

    invoke-direct {v2, v5, v3, v4}, Lcom/vdocipher/PlaybackSession$SourceType;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/PlaybackSession$SourceType;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$SourceType;

    .line 104
    filled-new-array {v0, v1, v2}, [Lcom/vdocipher/PlaybackSession$SourceType;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/PlaybackSession$SourceType;->$VALUES:[Lcom/vdocipher/PlaybackSession$SourceType;

    .line 159
    new-instance v0, Lcom/vdocipher/PlaybackSession$SourceType$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$SourceType$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackSession$SourceType;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 183
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 184
    iput p3, p0, Lcom/vdocipher/PlaybackSession$SourceType;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/PlaybackSession$SourceType;
    .registers 2

    if-eqz p0, :cond_a

    const/4 v0, 0x1

    if-eq p0, v0, :cond_7

    const/4 p0, 0x0

    return-object p0

    .line 149
    :cond_7
    sget-object p0, Lcom/vdocipher/PlaybackSession$SourceType;->offline:Lcom/vdocipher/PlaybackSession$SourceType;

    return-object p0

    .line 148
    :cond_a
    sget-object p0, Lcom/vdocipher/PlaybackSession$SourceType;->streaming:Lcom/vdocipher/PlaybackSession$SourceType;

    return-object p0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$SourceType;",
            ">;"
        }
    .end annotation

    .line 156
    sget-object v0, Lcom/vdocipher/PlaybackSession$SourceType;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 169
    sget-object v0, Lcom/vdocipher/PlaybackSession$SourceType$SourceTypeVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/PlaybackSession$SourceType;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 143
    invoke-static {p0}, Lcom/vdocipher/PlaybackSession$SourceType;->forNumber(I)Lcom/vdocipher/PlaybackSession$SourceType;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$SourceType;
    .registers 2

    .line 104
    const-class v0, Lcom/vdocipher/PlaybackSession$SourceType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$SourceType;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/PlaybackSession$SourceType;
    .registers 1

    .line 104
    sget-object v0, Lcom/vdocipher/PlaybackSession$SourceType;->$VALUES:[Lcom/vdocipher/PlaybackSession$SourceType;

    invoke-virtual {v0}, [Lcom/vdocipher/PlaybackSession$SourceType;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/PlaybackSession$SourceType;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 129
    sget-object v0, Lcom/vdocipher/PlaybackSession$SourceType;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$SourceType;

    if-eq p0, v0, :cond_7

    .line 133
    iget v0, p0, Lcom/vdocipher/PlaybackSession$SourceType;->value:I

    return v0

    .line 130
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
