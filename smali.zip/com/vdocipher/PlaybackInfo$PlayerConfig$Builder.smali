# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$PlayerConfigOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$PlayerConfig;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackInfo$PlayerConfig;",
        "Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$PlayerConfigOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 5681
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackInfo-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearId()Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;
    .registers 2

    .line 5708
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->copyOnWrite()V

    .line 5709
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->-$$Nest$mclearId(Lcom/vdocipher/PlaybackInfo$PlayerConfig;)V

    return-object p0
.end method

.method public clearOptions()Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;
    .registers 2

    .line 5783
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->copyOnWrite()V

    .line 5784
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->-$$Nest$mclearOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfig;)V

    return-object p0
.end method

.method public clearTheme()Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;
    .registers 2

    .line 5736
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->copyOnWrite()V

    .line 5737
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->-$$Nest$mclearTheme(Lcom/vdocipher/PlaybackInfo$PlayerConfig;)V

    return-object p0
.end method

.method public getId()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 5691
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->getId()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getOptions()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 2

    .line 5753
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->getOptions()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    move-result-object v0

    return-object v0
.end method

.method public getTheme()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 5719
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->getTheme()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public hasOptions()Z
    .registers 2

    .line 5746
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->hasOptions()Z

    move-result v0

    return v0
.end method

.method public mergeOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;
    .registers 3

    .line 5776
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->copyOnWrite()V

    .line 5777
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->-$$Nest$mmergeOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfig;Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public setId(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;
    .registers 3

    .line 5699
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->copyOnWrite()V

    .line 5700
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->-$$Nest$msetId(Lcom/vdocipher/PlaybackInfo$PlayerConfig;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;)Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;
    .registers 3

    .line 5768
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->copyOnWrite()V

    .line 5769
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->-$$Nest$msetOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfig;Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public setOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;
    .registers 3

    .line 5759
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->copyOnWrite()V

    .line 5760
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->-$$Nest$msetOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfig;Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public setTheme(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;
    .registers 3

    .line 5727
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->copyOnWrite()V

    .line 5728
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->-$$Nest$msetTheme(Lcom/vdocipher/PlaybackInfo$PlayerConfig;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
