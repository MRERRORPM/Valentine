# classes14.dex

.class public final enum Lcom/vdocipher/Manifest$MPDType;
.super Ljava/lang/Enum;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "MPDType"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$MPDType$MPDTypeVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/Manifest$MPDType;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/Manifest$MPDType;

.field public static final enum LIVE:Lcom/vdocipher/Manifest$MPDType;

.field public static final LIVE_VALUE:I = 0x1

.field public static final enum STATIC:Lcom/vdocipher/Manifest$MPDType;

.field public static final STATIC_VALUE:I

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/Manifest$MPDType;

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/Manifest$MPDType;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 6

    .line 305
    new-instance v0, Lcom/vdocipher/Manifest$MPDType;

    const-string v1, "STATIC"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/Manifest$MPDType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/Manifest$MPDType;->STATIC:Lcom/vdocipher/Manifest$MPDType;

    .line 309
    new-instance v1, Lcom/vdocipher/Manifest$MPDType;

    const-string v2, "LIVE"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/Manifest$MPDType;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/Manifest$MPDType;->LIVE:Lcom/vdocipher/Manifest$MPDType;

    .line 310
    new-instance v2, Lcom/vdocipher/Manifest$MPDType;

    const/4 v3, 0x2

    const/4 v4, -0x1

    const-string v5, "UNRECOGNIZED"

    invoke-direct {v2, v5, v3, v4}, Lcom/vdocipher/Manifest$MPDType;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/Manifest$MPDType;->UNRECOGNIZED:Lcom/vdocipher/Manifest$MPDType;

    .line 300
    filled-new-array {v0, v1, v2}, [Lcom/vdocipher/Manifest$MPDType;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/Manifest$MPDType;->$VALUES:[Lcom/vdocipher/Manifest$MPDType;

    .line 355
    new-instance v0, Lcom/vdocipher/Manifest$MPDType$1;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$MPDType$1;-><init>()V

    sput-object v0, Lcom/vdocipher/Manifest$MPDType;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 379
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 380
    iput p3, p0, Lcom/vdocipher/Manifest$MPDType;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/Manifest$MPDType;
    .registers 2

    if-eqz p0, :cond_a

    const/4 v0, 0x1

    if-eq p0, v0, :cond_7

    const/4 p0, 0x0

    return-object p0

    .line 345
    :cond_7
    sget-object p0, Lcom/vdocipher/Manifest$MPDType;->LIVE:Lcom/vdocipher/Manifest$MPDType;

    return-object p0

    .line 344
    :cond_a
    sget-object p0, Lcom/vdocipher/Manifest$MPDType;->STATIC:Lcom/vdocipher/Manifest$MPDType;

    return-object p0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/Manifest$MPDType;",
            ">;"
        }
    .end annotation

    .line 352
    sget-object v0, Lcom/vdocipher/Manifest$MPDType;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 365
    sget-object v0, Lcom/vdocipher/Manifest$MPDType$MPDTypeVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/Manifest$MPDType;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 339
    invoke-static {p0}, Lcom/vdocipher/Manifest$MPDType;->forNumber(I)Lcom/vdocipher/Manifest$MPDType;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/Manifest$MPDType;
    .registers 2

    .line 300
    const-class v0, Lcom/vdocipher/Manifest$MPDType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$MPDType;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/Manifest$MPDType;
    .registers 1

    .line 300
    sget-object v0, Lcom/vdocipher/Manifest$MPDType;->$VALUES:[Lcom/vdocipher/Manifest$MPDType;

    invoke-virtual {v0}, [Lcom/vdocipher/Manifest$MPDType;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/Manifest$MPDType;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 325
    sget-object v0, Lcom/vdocipher/Manifest$MPDType;->UNRECOGNIZED:Lcom/vdocipher/Manifest$MPDType;

    if-eq p0, v0, :cond_7

    .line 329
    iget v0, p0, Lcom/vdocipher/Manifest$MPDType;->value:I

    return v0

    .line 326
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
