# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$FPS;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$FPSOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "FPS"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackInfo$FPS;",
        "Lcom/vdocipher/PlaybackInfo$FPS$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$FPSOrBuilder;"
    }
.end annotation


# static fields
.field public static final ASSETID_FIELD_NUMBER:I = 0x3

.field public static final CERTIFICATE_FIELD_NUMBER:I = 0x4

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

.field public static final FALLBACKLICENSESERVERS_FIELD_NUMBER:I = 0x5

.field public static final LICENSESERVER_FIELD_NUMBER:I = 0x2

.field public static final MANIFEST_FIELD_NUMBER:I = 0x1

.field private static volatile PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$FPS;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private assetId_:Lcom/google/protobuf/ByteString;

.field private certificate_:Ljava/lang/String;

.field private fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private licenseServer_:Ljava/lang/String;

.field private manifest_:Lcom/google/protobuf/ByteString;


# direct methods
.method static bridge synthetic -$$Nest$maddAllFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$FPS;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->addAllFallbackLicenseServers(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$FPS;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->addFallbackLicenseServers(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddFallbackLicenseServersBytes(Lcom/vdocipher/PlaybackInfo$FPS;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->addFallbackLicenseServersBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearAssetId(Lcom/vdocipher/PlaybackInfo$FPS;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$FPS;->clearAssetId()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearCertificate(Lcom/vdocipher/PlaybackInfo$FPS;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$FPS;->clearCertificate()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$FPS;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$FPS;->clearFallbackLicenseServers()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLicenseServer(Lcom/vdocipher/PlaybackInfo$FPS;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$FPS;->clearLicenseServer()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearManifest(Lcom/vdocipher/PlaybackInfo$FPS;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$FPS;->clearManifest()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAssetId(Lcom/vdocipher/PlaybackInfo$FPS;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->setAssetId(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCertificate(Lcom/vdocipher/PlaybackInfo$FPS;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->setCertificate(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCertificateBytes(Lcom/vdocipher/PlaybackInfo$FPS;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->setCertificateBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$FPS;ILjava/lang/String;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$FPS;->setFallbackLicenseServers(ILjava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLicenseServer(Lcom/vdocipher/PlaybackInfo$FPS;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->setLicenseServer(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLicenseServerBytes(Lcom/vdocipher/PlaybackInfo$FPS;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->setLicenseServerBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetManifest(Lcom/vdocipher/PlaybackInfo$FPS;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->setManifest(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 8593
    new-instance v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$FPS;-><init>()V

    .line 8596
    sput-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    .line 8597
    const-class v1, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 3

    .line 7942
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 7943
    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->manifest_:Lcom/google/protobuf/ByteString;

    .line 7944
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->licenseServer_:Ljava/lang/String;

    .line 7945
    sget-object v1, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    iput-object v1, p0, Lcom/vdocipher/PlaybackInfo$FPS;->assetId_:Lcom/google/protobuf/ByteString;

    .line 7946
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->certificate_:Ljava/lang/String;

    .line 7947
    invoke-static {}, Lcom/google/protobuf/GeneratedMessageLite;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private addAllFallbackLicenseServers(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 8169
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$FPS;->ensureFallbackLicenseServersIsMutable()V

    .line 8170
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addFallbackLicenseServers(Ljava/lang/String;)V
    .registers 3

    .line 8159
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8160
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$FPS;->ensureFallbackLicenseServersIsMutable()V

    .line 8161
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addFallbackLicenseServersBytes(Lcom/google/protobuf/ByteString;)V
    .registers 3

    .line 8185
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$FPS;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 8186
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$FPS;->ensureFallbackLicenseServersIsMutable()V

    .line 8187
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private clearAssetId()V
    .registers 2

    .line 8047
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$FPS;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$FPS;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->getAssetId()Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->assetId_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private clearCertificate()V
    .registers 2

    .line 8084
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$FPS;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$FPS;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->getCertificate()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->certificate_:Ljava/lang/String;

    return-void
.end method

.method private clearFallbackLicenseServers()V
    .registers 2

    .line 8177
    invoke-static {}, Lcom/google/protobuf/GeneratedMessageLite;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearLicenseServer()V
    .registers 2

    .line 8010
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$FPS;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$FPS;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->getLicenseServer()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->licenseServer_:Ljava/lang/String;

    return-void
.end method

.method private clearManifest()V
    .registers 2

    .line 7973
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$FPS;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$FPS;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->getManifest()Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->manifest_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private ensureFallbackLicenseServersIsMutable()V
    .registers 3

    .line 8136
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 8137
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 8139
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 1

    .line 8602
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 1

    .line 8267
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackInfo$FPS;)Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 2

    .line 8270
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$FPS;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8243
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackInfo$FPS;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$FPS;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8250
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$FPS;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8206
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$FPS;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8213
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$FPS;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8255
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$FPS;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8262
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$FPS;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8230
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$FPS;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8237
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$FPS;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8193
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$FPS;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8200
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$FPS;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8218
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$FPS;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8225
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$FPS;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$FPS;",
            ">;"
        }
    .end annotation

    .line 8608
    sget-object v0, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setAssetId(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 8038
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8040
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$FPS;->assetId_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private setCertificate(Ljava/lang/String;)V
    .registers 2

    .line 8075
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8077
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$FPS;->certificate_:Ljava/lang/String;

    return-void
.end method

.method private setCertificateBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 8092
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$FPS;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 8093
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$FPS;->certificate_:Ljava/lang/String;

    return-void
.end method

.method private setFallbackLicenseServers(ILjava/lang/String;)V
    .registers 4

    .line 8149
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8150
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$FPS;->ensureFallbackLicenseServersIsMutable()V

    .line 8151
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setLicenseServer(Ljava/lang/String;)V
    .registers 2

    .line 8001
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8003
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$FPS;->licenseServer_:Ljava/lang/String;

    return-void
.end method

.method private setLicenseServerBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 8018
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$FPS;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 8019
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$FPS;->licenseServer_:Ljava/lang/String;

    return-void
.end method

.method private setManifest(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 7964
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7966
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$FPS;->manifest_:Lcom/google/protobuf/ByteString;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 8540
    sget-object p2, Lcom/vdocipher/PlaybackInfo$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_5a

    .line 8586
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 8580
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 8565
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackInfo$FPS;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 8567
    const-class p2, Lcom/vdocipher/PlaybackInfo$FPS;

    monitor-enter p2

    .line 8568
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackInfo$FPS;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 8570
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 8573
    sput-object p1, Lcom/vdocipher/PlaybackInfo$FPS;->PARSER:Lcom/google/protobuf/Parser;

    .line 8575
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 8562
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    return-object p1

    .line 8548
    :pswitch_36  #0x3
    const-string p1, "manifest_"

    const-string p2, "licenseServer_"

    const-string p3, "assetId_"

    const-string v0, "certificate_"

    const-string v1, "fallbackLicenseServers_"

    filled-new-array {p1, p2, p3, v0, v1}, [Ljava/lang/Object;

    move-result-object p1

    .line 8555
    const-string p2, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0001\u0000\u0001\n\u0002Ȉ\u0003\n\u0004Ȉ\u0005Ț"

    .line 8558
    sget-object p3, Lcom/vdocipher/PlaybackInfo$FPS;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 8545
    :pswitch_4d  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackInfo$FPS$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;-><init>(Lcom/vdocipher/PlaybackInfo-IA;)V

    return-object p1

    .line 8542
    :pswitch_53  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackInfo$FPS;-><init>()V

    return-object p1

    nop

    :pswitch_data_5a
    .packed-switch 0x1
        :pswitch_53  #00000001
        :pswitch_4d  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getAssetId()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8031
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->assetId_:Lcom/google/protobuf/ByteString;

    return-object v0
.end method

.method public getCertificate()Ljava/lang/String;
    .registers 2

    .line 8058
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->certificate_:Ljava/lang/String;

    return-object v0
.end method

.method public getCertificateBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8067
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->certificate_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getFallbackLicenseServers(I)Ljava/lang/String;
    .registers 3

    .line 8122
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    return-object p1
.end method

.method public getFallbackLicenseServersBytes(I)Lcom/google/protobuf/ByteString;
    .registers 3

    .line 8132
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 8133
    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    .line 8132
    invoke-static {p1}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object p1

    return-object p1
.end method

.method public getFallbackLicenseServersCount()I
    .registers 2

    .line 8113
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getFallbackLicenseServersList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 8105
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getLicenseServer()Ljava/lang/String;
    .registers 2

    .line 7984
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->licenseServer_:Ljava/lang/String;

    return-object v0
.end method

.method public getLicenseServerBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 7993
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->licenseServer_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getManifest()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 7957
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS;->manifest_:Lcom/google/protobuf/ByteString;

    return-object v0
.end method
