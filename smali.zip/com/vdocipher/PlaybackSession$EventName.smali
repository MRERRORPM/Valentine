# classes14.dex

.class public final enum Lcom/vdocipher/PlaybackSession$EventName;
.super Ljava/lang/Enum;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "EventName"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$EventName$EventNameVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/PlaybackSession$EventName;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/PlaybackSession$EventName;

.field public static final enum DrmSession:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final DrmSession_VALUE:I = 0x23

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final enum acdc:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final acdc_VALUE:I = 0x1e

.field public static final enum adaptation:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final adaptation_VALUE:I = 0x1

.field public static final enum adaptiveStreamsStart:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final adaptiveStreamsStart_VALUE:I = 0x6

.field public static final enum apiConnected:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final apiConnected_VALUE:I = 0x3

.field public static final enum bufferStart:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final bufferStart_VALUE:I = 0x29

.field public static final enum bufferStop:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final bufferStop_VALUE:I = 0x2a

.field public static final enum captionLanguageChange:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final captionLanguageChange_VALUE:I = 0x24

.field public static final enum captionVisibilityFalse:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final captionVisibilityFalse_VALUE:I = 0x5

.field public static final enum captionVisibilityTrue:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final captionVisibilityTrue_VALUE:I = 0x4

.field public static final enum chromecastEnded:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final chromecastEnded_VALUE:I = 0x15

.field public static final enum chromecastStarted:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final chromecastStarted_VALUE:I = 0x14

.field public static final enum downloadChanged:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final downloadChanged_VALUE:I = 0xf

.field public static final enum downloadError:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final downloadError_VALUE:I = 0x11

.field public static final enum downloadRemoved:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final downloadRemoved_VALUE:I = 0x10

.field public static final enum error:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final error_VALUE:I = 0x2d

.field public static final enum fullScreenEnter:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final fullScreenEnter_VALUE:I = 0x27

.field public static final enum fullScreenExit:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final fullScreenExit_VALUE:I = 0x28

.field public static final enum hlsMeta:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final hlsMeta_VALUE:I = 0x26

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$EventName;",
            ">;"
        }
    .end annotation
.end field

.field public static final enum licenseDuration:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final licenseDuration_VALUE:I = 0x1d

.field public static final enum licenseLoad:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final licenseLoad_VALUE:I = 0x8

.field public static final enum loadError:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final loadError_VALUE:I = 0x2c

.field public static final enum loaded:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final loaded_VALUE:I = 0x1a

.field public static final enum metaDataLoadSuccess:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final metaDataLoadSuccess_VALUE:I = 0x0

.field public static final enum metaFailed:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final metaFailed_VALUE:I = 0xe

.field public static final enum mutedError:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final mutedError_VALUE:I = 0x2b

.field public static final enum pause:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final pause_VALUE:I = 0xc

.field public static final enum pipEnter:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final pipEnter_VALUE:I = 0x16

.field public static final enum pipExit:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final pipExit_VALUE:I = 0x17

.field public static final enum play:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final play_VALUE:I = 0xb

.field public static final enum rateChange:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final rateChange_VALUE:I = 0x25

.field public static final enum resumedVideoFromClient:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final resumedVideoFromClient_VALUE:I = 0x7

.field public static final enum saveOfflineAvailable:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final saveOfflineAvailable_VALUE:I = 0x2

.field public static final enum scriptError:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final scriptError_VALUE:I = 0xd

.field public static final enum seekComplete:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final seekComplete_VALUE:I = 0x1c

.field public static final enum seekStart:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final seekStart_VALUE:I = 0x1b

.field public static final enum seeked:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final seeked_VALUE:I = 0xa

.field public static final enum seeking:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final seeking_VALUE:I = 0x9

.field public static final enum stop:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final stop_VALUE:I = 0x22

.field public static final enum tags:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final tags_VALUE:I = 0x18

.field public static final enum trackChange:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final trackChange_VALUE:I = 0x20

.field public static final enum usingPlayerUI:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final usingPlayerUI_VALUE:I = 0x13

.field public static final enum vcdc:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final vcdc_VALUE:I = 0x1f

.field public static final enum videoEnded:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final videoEnded_VALUE:I = 0x21

.field public static final enum vsize:Lcom/vdocipher/PlaybackSession$EventName;

.field public static final vsize_VALUE:I = 0x19


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 49

    .line 296
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v0, "metaDataLoadSuccess"

    const/4 v2, 0x0

    invoke-direct {v1, v0, v2, v2}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->metaDataLoadSuccess:Lcom/vdocipher/PlaybackSession$EventName;

    .line 300
    new-instance v2, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v0, "adaptation"

    const/4 v3, 0x1

    invoke-direct {v2, v0, v3, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/PlaybackSession$EventName;->adaptation:Lcom/vdocipher/PlaybackSession$EventName;

    .line 304
    new-instance v3, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v0, "saveOfflineAvailable"

    const/4 v4, 0x2

    invoke-direct {v3, v0, v4, v4}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lcom/vdocipher/PlaybackSession$EventName;->saveOfflineAvailable:Lcom/vdocipher/PlaybackSession$EventName;

    .line 308
    new-instance v4, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v0, "apiConnected"

    const/4 v5, 0x3

    invoke-direct {v4, v0, v5, v5}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lcom/vdocipher/PlaybackSession$EventName;->apiConnected:Lcom/vdocipher/PlaybackSession$EventName;

    .line 312
    new-instance v5, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v0, "captionVisibilityTrue"

    const/4 v6, 0x4

    invoke-direct {v5, v0, v6, v6}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lcom/vdocipher/PlaybackSession$EventName;->captionVisibilityTrue:Lcom/vdocipher/PlaybackSession$EventName;

    .line 316
    new-instance v6, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v0, "captionVisibilityFalse"

    const/4 v7, 0x5

    invoke-direct {v6, v0, v7, v7}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lcom/vdocipher/PlaybackSession$EventName;->captionVisibilityFalse:Lcom/vdocipher/PlaybackSession$EventName;

    .line 320
    new-instance v7, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v0, "adaptiveStreamsStart"

    const/4 v8, 0x6

    invoke-direct {v7, v0, v8, v8}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lcom/vdocipher/PlaybackSession$EventName;->adaptiveStreamsStart:Lcom/vdocipher/PlaybackSession$EventName;

    .line 324
    new-instance v8, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v0, "resumedVideoFromClient"

    const/4 v9, 0x7

    invoke-direct {v8, v0, v9, v9}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v8, Lcom/vdocipher/PlaybackSession$EventName;->resumedVideoFromClient:Lcom/vdocipher/PlaybackSession$EventName;

    .line 328
    new-instance v9, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v0, "licenseLoad"

    const/16 v10, 0x8

    invoke-direct {v9, v0, v10, v10}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v9, Lcom/vdocipher/PlaybackSession$EventName;->licenseLoad:Lcom/vdocipher/PlaybackSession$EventName;

    .line 332
    new-instance v10, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v0, "seeking"

    const/16 v11, 0x9

    invoke-direct {v10, v0, v11, v11}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v10, Lcom/vdocipher/PlaybackSession$EventName;->seeking:Lcom/vdocipher/PlaybackSession$EventName;

    .line 336
    new-instance v11, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v0, "seeked"

    const/16 v12, 0xa

    invoke-direct {v11, v0, v12, v12}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v11, Lcom/vdocipher/PlaybackSession$EventName;->seeked:Lcom/vdocipher/PlaybackSession$EventName;

    .line 340
    new-instance v12, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v0, "play"

    const/16 v13, 0xb

    invoke-direct {v12, v0, v13, v13}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v12, Lcom/vdocipher/PlaybackSession$EventName;->play:Lcom/vdocipher/PlaybackSession$EventName;

    .line 344
    new-instance v13, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v0, "pause"

    const/16 v14, 0xc

    invoke-direct {v13, v0, v14, v14}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v13, Lcom/vdocipher/PlaybackSession$EventName;->pause:Lcom/vdocipher/PlaybackSession$EventName;

    .line 348
    new-instance v14, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v0, "scriptError"

    const/16 v15, 0xd

    invoke-direct {v14, v0, v15, v15}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v14, Lcom/vdocipher/PlaybackSession$EventName;->scriptError:Lcom/vdocipher/PlaybackSession$EventName;

    .line 352
    new-instance v15, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v0, "metaFailed"

    move-object/from16 v16, v1

    const/16 v1, 0xe

    invoke-direct {v15, v0, v1, v1}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v15, Lcom/vdocipher/PlaybackSession$EventName;->metaFailed:Lcom/vdocipher/PlaybackSession$EventName;

    .line 356
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v1, "downloadChanged"

    move-object/from16 v17, v2

    const/16 v2, 0xf

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->downloadChanged:Lcom/vdocipher/PlaybackSession$EventName;

    .line 360
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v2, "downloadRemoved"

    move-object/from16 v18, v0

    const/16 v0, 0x10

    invoke-direct {v1, v2, v0, v0}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->downloadRemoved:Lcom/vdocipher/PlaybackSession$EventName;

    .line 364
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v2, "downloadError"

    move-object/from16 v19, v1

    const/16 v1, 0x11

    invoke-direct {v0, v2, v1, v1}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->downloadError:Lcom/vdocipher/PlaybackSession$EventName;

    .line 368
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const-string/jumbo v2, "usingPlayerUI"

    move-object/from16 v20, v0

    const/16 v0, 0x12

    move-object/from16 v21, v3

    const/16 v3, 0x13

    invoke-direct {v1, v2, v0, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->usingPlayerUI:Lcom/vdocipher/PlaybackSession$EventName;

    .line 372
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v2, "chromecastStarted"

    move-object/from16 v22, v1

    const/16 v1, 0x14

    invoke-direct {v0, v2, v3, v1}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->chromecastStarted:Lcom/vdocipher/PlaybackSession$EventName;

    .line 376
    new-instance v2, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v3, "chromecastEnded"

    move-object/from16 v23, v0

    const/16 v0, 0x15

    invoke-direct {v2, v3, v1, v0}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/PlaybackSession$EventName;->chromecastEnded:Lcom/vdocipher/PlaybackSession$EventName;

    .line 380
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v3, "pipEnter"

    move-object/from16 v24, v2

    const/16 v2, 0x16

    invoke-direct {v1, v3, v0, v2}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->pipEnter:Lcom/vdocipher/PlaybackSession$EventName;

    .line 384
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName;

    const-string v3, "pipExit"

    move-object/from16 v25, v1

    const/16 v1, 0x17

    invoke-direct {v0, v3, v2, v1}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->pipExit:Lcom/vdocipher/PlaybackSession$EventName;

    .line 388
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x17

    const/16 v3, 0x18

    move-object/from16 v26, v0

    const-string/jumbo v0, "tags"

    invoke-direct {v1, v0, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->tags:Lcom/vdocipher/PlaybackSession$EventName;

    .line 392
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x18

    const/16 v3, 0x19

    move-object/from16 v27, v1

    const-string/jumbo v1, "vsize"

    invoke-direct {v0, v1, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->vsize:Lcom/vdocipher/PlaybackSession$EventName;

    .line 396
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x19

    const/16 v3, 0x1a

    move-object/from16 v28, v0

    const-string v0, "loaded"

    invoke-direct {v1, v0, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->loaded:Lcom/vdocipher/PlaybackSession$EventName;

    .line 400
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x1a

    const/16 v3, 0x1b

    move-object/from16 v29, v1

    const-string v1, "seekStart"

    invoke-direct {v0, v1, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->seekStart:Lcom/vdocipher/PlaybackSession$EventName;

    .line 404
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x1b

    const/16 v3, 0x1c

    move-object/from16 v30, v0

    const-string v0, "seekComplete"

    invoke-direct {v1, v0, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->seekComplete:Lcom/vdocipher/PlaybackSession$EventName;

    .line 408
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x1c

    const/16 v3, 0x1d

    move-object/from16 v31, v1

    const-string v1, "licenseDuration"

    invoke-direct {v0, v1, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->licenseDuration:Lcom/vdocipher/PlaybackSession$EventName;

    .line 412
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x1d

    const/16 v3, 0x1e

    move-object/from16 v32, v0

    const-string v0, "acdc"

    invoke-direct {v1, v0, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->acdc:Lcom/vdocipher/PlaybackSession$EventName;

    .line 416
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x1e

    const/16 v3, 0x1f

    move-object/from16 v33, v1

    const-string/jumbo v1, "vcdc"

    invoke-direct {v0, v1, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->vcdc:Lcom/vdocipher/PlaybackSession$EventName;

    .line 420
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x1f

    const/16 v3, 0x20

    move-object/from16 v34, v0

    const-string/jumbo v0, "trackChange"

    invoke-direct {v1, v0, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->trackChange:Lcom/vdocipher/PlaybackSession$EventName;

    .line 424
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x20

    const/16 v3, 0x21

    move-object/from16 v35, v1

    const-string/jumbo v1, "videoEnded"

    invoke-direct {v0, v1, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->videoEnded:Lcom/vdocipher/PlaybackSession$EventName;

    .line 428
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x21

    const/16 v3, 0x22

    move-object/from16 v36, v0

    const-string/jumbo v0, "stop"

    invoke-direct {v1, v0, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->stop:Lcom/vdocipher/PlaybackSession$EventName;

    .line 432
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x22

    const/16 v3, 0x23

    move-object/from16 v37, v1

    const-string v1, "DrmSession"

    invoke-direct {v0, v1, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->DrmSession:Lcom/vdocipher/PlaybackSession$EventName;

    .line 436
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x23

    const/16 v3, 0x24

    move-object/from16 v38, v0

    const-string v0, "captionLanguageChange"

    invoke-direct {v1, v0, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->captionLanguageChange:Lcom/vdocipher/PlaybackSession$EventName;

    .line 440
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x24

    const/16 v3, 0x25

    move-object/from16 v39, v1

    const-string v1, "rateChange"

    invoke-direct {v0, v1, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->rateChange:Lcom/vdocipher/PlaybackSession$EventName;

    .line 444
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x25

    const/16 v3, 0x26

    move-object/from16 v40, v0

    const-string v0, "hlsMeta"

    invoke-direct {v1, v0, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->hlsMeta:Lcom/vdocipher/PlaybackSession$EventName;

    .line 448
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x26

    const/16 v3, 0x27

    move-object/from16 v41, v1

    const-string v1, "fullScreenEnter"

    invoke-direct {v0, v1, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->fullScreenEnter:Lcom/vdocipher/PlaybackSession$EventName;

    .line 452
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x27

    const/16 v3, 0x28

    move-object/from16 v42, v0

    const-string v0, "fullScreenExit"

    invoke-direct {v1, v0, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->fullScreenExit:Lcom/vdocipher/PlaybackSession$EventName;

    .line 456
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x28

    const/16 v3, 0x29

    move-object/from16 v43, v1

    const-string v1, "bufferStart"

    invoke-direct {v0, v1, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->bufferStart:Lcom/vdocipher/PlaybackSession$EventName;

    .line 460
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x29

    const/16 v3, 0x2a

    move-object/from16 v44, v0

    const-string v0, "bufferStop"

    invoke-direct {v1, v0, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->bufferStop:Lcom/vdocipher/PlaybackSession$EventName;

    .line 464
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x2a

    const/16 v3, 0x2b

    move-object/from16 v45, v1

    const-string v1, "mutedError"

    invoke-direct {v0, v1, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->mutedError:Lcom/vdocipher/PlaybackSession$EventName;

    .line 468
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x2b

    const/16 v3, 0x2c

    move-object/from16 v46, v0

    const-string v0, "loadError"

    invoke-direct {v1, v0, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->loadError:Lcom/vdocipher/PlaybackSession$EventName;

    .line 472
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x2c

    const/16 v3, 0x2d

    move-object/from16 v47, v1

    const-string v1, "error"

    invoke-direct {v0, v1, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->error:Lcom/vdocipher/PlaybackSession$EventName;

    .line 473
    new-instance v1, Lcom/vdocipher/PlaybackSession$EventName;

    const/16 v2, 0x2d

    const/4 v3, -0x1

    move-object/from16 v48, v0

    const-string v0, "UNRECOGNIZED"

    invoke-direct {v1, v0, v2, v3}, Lcom/vdocipher/PlaybackSession$EventName;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$EventName;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$EventName;

    move-object/from16 v2, v17

    move-object/from16 v17, v19

    move-object/from16 v3, v21

    move-object/from16 v19, v22

    move-object/from16 v21, v24

    move-object/from16 v22, v25

    move-object/from16 v24, v27

    move-object/from16 v25, v28

    move-object/from16 v27, v30

    move-object/from16 v28, v31

    move-object/from16 v30, v33

    move-object/from16 v31, v34

    move-object/from16 v33, v36

    move-object/from16 v34, v37

    move-object/from16 v36, v39

    move-object/from16 v37, v40

    move-object/from16 v39, v42

    move-object/from16 v40, v43

    move-object/from16 v42, v45

    move-object/from16 v43, v46

    move-object/from16 v45, v48

    move-object/from16 v46, v1

    move-object/from16 v1, v16

    move-object/from16 v16, v18

    move-object/from16 v18, v20

    move-object/from16 v20, v23

    move-object/from16 v23, v26

    move-object/from16 v26, v29

    move-object/from16 v29, v32

    move-object/from16 v32, v35

    move-object/from16 v35, v38

    move-object/from16 v38, v41

    move-object/from16 v41, v44

    move-object/from16 v44, v47

    .line 291
    filled-new-array/range {v1 .. v46}, [Lcom/vdocipher/PlaybackSession$EventName;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->$VALUES:[Lcom/vdocipher/PlaybackSession$EventName;

    .line 733
    new-instance v0, Lcom/vdocipher/PlaybackSession$EventName$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$EventName$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackSession$EventName;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 757
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 758
    iput p3, p0, Lcom/vdocipher/PlaybackSession$EventName;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/PlaybackSession$EventName;
    .registers 1

    packed-switch p0, :pswitch_data_8c

    :pswitch_3  #0x12
    const/4 p0, 0x0

    return-object p0

    .line 723
    :pswitch_5  #0x2d
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->error:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 722
    :pswitch_8  #0x2c
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->loadError:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 721
    :pswitch_b  #0x2b
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->mutedError:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 720
    :pswitch_e  #0x2a
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->bufferStop:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 719
    :pswitch_11  #0x29
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->bufferStart:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 718
    :pswitch_14  #0x28
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->fullScreenExit:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 717
    :pswitch_17  #0x27
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->fullScreenEnter:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 716
    :pswitch_1a  #0x26
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->hlsMeta:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 715
    :pswitch_1d  #0x25
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->rateChange:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 714
    :pswitch_20  #0x24
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->captionLanguageChange:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 713
    :pswitch_23  #0x23
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->DrmSession:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 712
    :pswitch_26  #0x22
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->stop:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 711
    :pswitch_29  #0x21
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->videoEnded:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 710
    :pswitch_2c  #0x20
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->trackChange:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 709
    :pswitch_2f  #0x1f
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->vcdc:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 708
    :pswitch_32  #0x1e
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->acdc:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 707
    :pswitch_35  #0x1d
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->licenseDuration:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 706
    :pswitch_38  #0x1c
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->seekComplete:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 705
    :pswitch_3b  #0x1b
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->seekStart:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 704
    :pswitch_3e  #0x1a
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->loaded:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 703
    :pswitch_41  #0x19
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->vsize:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 702
    :pswitch_44  #0x18
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->tags:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 701
    :pswitch_47  #0x17
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->pipExit:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 700
    :pswitch_4a  #0x16
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->pipEnter:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 699
    :pswitch_4d  #0x15
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->chromecastEnded:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 698
    :pswitch_50  #0x14
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->chromecastStarted:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 697
    :pswitch_53  #0x13
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->usingPlayerUI:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 696
    :pswitch_56  #0x11
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->downloadError:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 695
    :pswitch_59  #0x10
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->downloadRemoved:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 694
    :pswitch_5c  #0xf
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->downloadChanged:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 693
    :pswitch_5f  #0xe
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->metaFailed:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 692
    :pswitch_62  #0xd
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->scriptError:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 691
    :pswitch_65  #0xc
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->pause:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 690
    :pswitch_68  #0xb
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->play:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 689
    :pswitch_6b  #0xa
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->seeked:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 688
    :pswitch_6e  #0x9
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->seeking:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 687
    :pswitch_71  #0x8
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->licenseLoad:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 686
    :pswitch_74  #0x7
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->resumedVideoFromClient:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 685
    :pswitch_77  #0x6
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->adaptiveStreamsStart:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 684
    :pswitch_7a  #0x5
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->captionVisibilityFalse:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 683
    :pswitch_7d  #0x4
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->captionVisibilityTrue:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 682
    :pswitch_80  #0x3
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->apiConnected:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 681
    :pswitch_83  #0x2
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->saveOfflineAvailable:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 680
    :pswitch_86  #0x1
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->adaptation:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    .line 679
    :pswitch_89  #0x0
    sget-object p0, Lcom/vdocipher/PlaybackSession$EventName;->metaDataLoadSuccess:Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0

    :pswitch_data_8c
    .packed-switch 0x0
        :pswitch_89  #00000000
        :pswitch_86  #00000001
        :pswitch_83  #00000002
        :pswitch_80  #00000003
        :pswitch_7d  #00000004
        :pswitch_7a  #00000005
        :pswitch_77  #00000006
        :pswitch_74  #00000007
        :pswitch_71  #00000008
        :pswitch_6e  #00000009
        :pswitch_6b  #0000000a
        :pswitch_68  #0000000b
        :pswitch_65  #0000000c
        :pswitch_62  #0000000d
        :pswitch_5f  #0000000e
        :pswitch_5c  #0000000f
        :pswitch_59  #00000010
        :pswitch_56  #00000011
        :pswitch_3  #00000012
        :pswitch_53  #00000013
        :pswitch_50  #00000014
        :pswitch_4d  #00000015
        :pswitch_4a  #00000016
        :pswitch_47  #00000017
        :pswitch_44  #00000018
        :pswitch_41  #00000019
        :pswitch_3e  #0000001a
        :pswitch_3b  #0000001b
        :pswitch_38  #0000001c
        :pswitch_35  #0000001d
        :pswitch_32  #0000001e
        :pswitch_2f  #0000001f
        :pswitch_2c  #00000020
        :pswitch_29  #00000021
        :pswitch_26  #00000022
        :pswitch_23  #00000023
        :pswitch_20  #00000024
        :pswitch_1d  #00000025
        :pswitch_1a  #00000026
        :pswitch_17  #00000027
        :pswitch_14  #00000028
        :pswitch_11  #00000029
        :pswitch_e  #0000002a
        :pswitch_b  #0000002b
        :pswitch_8  #0000002c
        :pswitch_5  #0000002d
    .end packed-switch
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$EventName;",
            ">;"
        }
    .end annotation

    .line 730
    sget-object v0, Lcom/vdocipher/PlaybackSession$EventName;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 743
    sget-object v0, Lcom/vdocipher/PlaybackSession$EventName$EventNameVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/PlaybackSession$EventName;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 674
    invoke-static {p0}, Lcom/vdocipher/PlaybackSession$EventName;->forNumber(I)Lcom/vdocipher/PlaybackSession$EventName;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$EventName;
    .registers 2

    .line 291
    const-class v0, Lcom/vdocipher/PlaybackSession$EventName;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$EventName;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/PlaybackSession$EventName;
    .registers 1

    .line 291
    sget-object v0, Lcom/vdocipher/PlaybackSession$EventName;->$VALUES:[Lcom/vdocipher/PlaybackSession$EventName;

    invoke-virtual {v0}, [Lcom/vdocipher/PlaybackSession$EventName;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/PlaybackSession$EventName;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 660
    sget-object v0, Lcom/vdocipher/PlaybackSession$EventName;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$EventName;

    if-eq p0, v0, :cond_7

    .line 664
    iget v0, p0, Lcom/vdocipher/PlaybackSession$EventName;->value:I

    return v0

    .line 661
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
