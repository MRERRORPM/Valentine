# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$TrackAudioOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$TrackAudio;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$TrackAudio;",
        "Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$TrackAudioOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 9256
    invoke-static {}, Lcom/vdocipher/PlaybackSession$TrackAudio;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$TrackAudio;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearBitrateKbps()Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;
    .registers 2

    .line 9283
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->copyOnWrite()V

    .line 9284
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$TrackAudio;->-$$Nest$mclearBitrateKbps(Lcom/vdocipher/PlaybackSession$TrackAudio;)V

    return-object p0
.end method

.method public clearLanguage()Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;
    .registers 2

    .line 9321
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->copyOnWrite()V

    .line 9322
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$TrackAudio;->-$$Nest$mclearLanguage(Lcom/vdocipher/PlaybackSession$TrackAudio;)V

    return-object p0
.end method

.method public getBitrateKbps()I
    .registers 2

    .line 9266
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$TrackAudio;->getBitrateKbps()I

    move-result v0

    return v0
.end method

.method public getLanguage()Ljava/lang/String;
    .registers 2

    .line 9294
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$TrackAudio;->getLanguage()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getLanguageBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9303
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$TrackAudio;->getLanguageBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setBitrateKbps(I)Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;
    .registers 3

    .line 9274
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->copyOnWrite()V

    .line 9275
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$TrackAudio;->-$$Nest$msetBitrateKbps(Lcom/vdocipher/PlaybackSession$TrackAudio;I)V

    return-object p0
.end method

.method public setLanguage(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;
    .registers 3

    .line 9312
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->copyOnWrite()V

    .line 9313
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$TrackAudio;->-$$Nest$msetLanguage(Lcom/vdocipher/PlaybackSession$TrackAudio;Ljava/lang/String;)V

    return-object p0
.end method

.method public setLanguageBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;
    .registers 3

    .line 9332
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->copyOnWrite()V

    .line 9333
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$TrackAudio;->-$$Nest$msetLanguageBytes(Lcom/vdocipher/PlaybackSession$TrackAudio;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
