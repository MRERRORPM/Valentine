# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Toolkit;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$ToolkitOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Toolkit"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$Toolkit$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$Toolkit;",
        "Lcom/vdocipher/PlaybackSession$Toolkit$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$ToolkitOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

.field public static final NAME_FIELD_NUMBER:I = 0x1

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Toolkit;",
            ">;"
        }
    .end annotation
.end field

.field public static final VERSIONCODE_FIELD_NUMBER:I = 0x3

.field public static final VERSIONMISMATCH_FIELD_NUMBER:I = 0x4

.field public static final VERSION_FIELD_NUMBER:I = 0x2


# instance fields
.field private name_:Ljava/lang/String;

.field private versionCode_:I

.field private versionMisMatch_:Z

.field private version_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$mclearName(Lcom/vdocipher/PlaybackSession$Toolkit;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Toolkit;->clearName()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearVersion(Lcom/vdocipher/PlaybackSession$Toolkit;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Toolkit;->clearVersion()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearVersionCode(Lcom/vdocipher/PlaybackSession$Toolkit;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Toolkit;->clearVersionCode()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearVersionMisMatch(Lcom/vdocipher/PlaybackSession$Toolkit;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Toolkit;->clearVersionMisMatch()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetName(Lcom/vdocipher/PlaybackSession$Toolkit;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->setName(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetNameBytes(Lcom/vdocipher/PlaybackSession$Toolkit;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->setNameBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVersion(Lcom/vdocipher/PlaybackSession$Toolkit;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->setVersion(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVersionBytes(Lcom/vdocipher/PlaybackSession$Toolkit;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->setVersionBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVersionCode(Lcom/vdocipher/PlaybackSession$Toolkit;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->setVersionCode(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVersionMisMatch(Lcom/vdocipher/PlaybackSession$Toolkit;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->setVersionMisMatch(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 11978
    new-instance v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;-><init>()V

    .line 11981
    sput-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    .line 11982
    const-class v1, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 11518
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 11519
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->name_:Ljava/lang/String;

    .line 11520
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->version_:Ljava/lang/String;

    return-void
.end method

.method private clearName()V
    .registers 2

    .line 11556
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Toolkit;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Toolkit;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;->getName()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->name_:Ljava/lang/String;

    return-void
.end method

.method private clearVersion()V
    .registers 2

    .line 11603
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Toolkit;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Toolkit;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;->getVersion()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->version_:Ljava/lang/String;

    return-void
.end method

.method private clearVersionCode()V
    .registers 2

    const/4 v0, 0x0

    .line 11639
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->versionCode_:I

    return-void
.end method

.method private clearVersionMisMatch()V
    .registers 2

    const/4 v0, 0x0

    .line 11665
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->versionMisMatch_:Z

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 1

    .line 11987
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$Toolkit$Builder;
    .registers 1

    .line 11745
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$Toolkit;)Lcom/vdocipher/PlaybackSession$Toolkit$Builder;
    .registers 2

    .line 11748
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$Toolkit;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11721
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$Toolkit;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Toolkit;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11728
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Toolkit;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11684
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Toolkit;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11691
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Toolkit;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11733
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Toolkit;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11740
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Toolkit;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11708
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Toolkit;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11715
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Toolkit;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11671
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Toolkit;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11678
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Toolkit;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11696
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Toolkit;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11703
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Toolkit;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Toolkit;",
            ">;"
        }
    .end annotation

    .line 11993
    sget-object v0, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setName(Ljava/lang/String;)V
    .registers 2

    .line 11547
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11549
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->name_:Ljava/lang/String;

    return-void
.end method

.method private setNameBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 11564
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 11565
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->name_:Ljava/lang/String;

    return-void
.end method

.method private setVersion(Ljava/lang/String;)V
    .registers 2

    .line 11594
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11596
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->version_:Ljava/lang/String;

    return-void
.end method

.method private setVersionBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 11611
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 11612
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->version_:Ljava/lang/String;

    return-void
.end method

.method private setVersionCode(I)V
    .registers 2

    .line 11632
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->versionCode_:I

    return-void
.end method

.method private setVersionMisMatch(Z)V
    .registers 2

    .line 11658
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->versionMisMatch_:Z

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 11926
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_5a

    .line 11971
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 11965
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 11950
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$Toolkit;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 11952
    const-class p2, Lcom/vdocipher/PlaybackSession$Toolkit;

    monitor-enter p2

    .line 11953
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$Toolkit;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 11955
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 11958
    sput-object p1, Lcom/vdocipher/PlaybackSession$Toolkit;->PARSER:Lcom/google/protobuf/Parser;

    .line 11960
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 11947
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    return-object p1

    .line 11934
    :pswitch_36  #0x3
    const-string p1, "name_"

    const-string/jumbo p2, "version_"

    const-string/jumbo p3, "versionCode_"

    const-string/jumbo v0, "versionMisMatch_"

    filled-new-array {p1, p2, p3, v0}, [Ljava/lang/Object;

    move-result-object p1

    .line 11940
    const-string p2, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003\u000b\u0004\u0007"

    .line 11943
    sget-object p3, Lcom/vdocipher/PlaybackSession$Toolkit;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 11931
    :pswitch_4e  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 11928
    :pswitch_54  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$Toolkit;-><init>()V

    return-object p1

    :pswitch_data_5a
    .packed-switch 0x1
        :pswitch_54  #00000001
        :pswitch_4e  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getName()Ljava/lang/String;
    .registers 2

    .line 11530
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->name_:Ljava/lang/String;

    return-object v0
.end method

.method public getNameBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 11539
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->name_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getVersion()Ljava/lang/String;
    .registers 2

    .line 11577
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->version_:Ljava/lang/String;

    return-object v0
.end method

.method public getVersionBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 11586
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->version_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getVersionCode()I
    .registers 2

    .line 11624
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->versionCode_:I

    return v0
.end method

.method public getVersionMisMatch()Z
    .registers 2

    .line 11650
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit;->versionMisMatch_:Z

    return v0
.end method
