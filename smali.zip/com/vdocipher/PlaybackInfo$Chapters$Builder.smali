# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$Chapters$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$ChaptersOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$Chapters;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackInfo$Chapters;",
        "Lcom/vdocipher/PlaybackInfo$Chapters$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$ChaptersOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 9772
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Chapters;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$Chapters;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackInfo-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearId()Lcom/vdocipher/PlaybackInfo$Chapters$Builder;
    .registers 2

    .line 9876
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->copyOnWrite()V

    .line 9877
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$Chapters;->-$$Nest$mclearId(Lcom/vdocipher/PlaybackInfo$Chapters;)V

    return-object p0
.end method

.method public clearStartTime()Lcom/vdocipher/PlaybackInfo$Chapters$Builder;
    .registers 2

    .line 9848
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->copyOnWrite()V

    .line 9849
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$Chapters;->-$$Nest$mclearStartTime(Lcom/vdocipher/PlaybackInfo$Chapters;)V

    return-object p0
.end method

.method public clearTitle()Lcom/vdocipher/PlaybackInfo$Chapters$Builder;
    .registers 2

    .line 9809
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->copyOnWrite()V

    .line 9810
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$Chapters;->-$$Nest$mclearTitle(Lcom/vdocipher/PlaybackInfo$Chapters;)V

    return-object p0
.end method

.method public getId()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9859
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Chapters;->getId()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getStartTime()I
    .registers 2

    .line 9831
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Chapters;->getStartTime()I

    move-result v0

    return v0
.end method

.method public getTitle()Ljava/lang/String;
    .registers 2

    .line 9782
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Chapters;->getTitle()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getTitleBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9791
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Chapters;->getTitleBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setId(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$Chapters$Builder;
    .registers 3

    .line 9867
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->copyOnWrite()V

    .line 9868
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Chapters;->-$$Nest$msetId(Lcom/vdocipher/PlaybackInfo$Chapters;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setStartTime(I)Lcom/vdocipher/PlaybackInfo$Chapters$Builder;
    .registers 3

    .line 9839
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->copyOnWrite()V

    .line 9840
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Chapters;->-$$Nest$msetStartTime(Lcom/vdocipher/PlaybackInfo$Chapters;I)V

    return-object p0
.end method

.method public setTitle(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$Chapters$Builder;
    .registers 3

    .line 9800
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->copyOnWrite()V

    .line 9801
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Chapters;->-$$Nest$msetTitle(Lcom/vdocipher/PlaybackInfo$Chapters;Ljava/lang/String;)V

    return-object p0
.end method

.method public setTitleBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$Chapters$Builder;
    .registers 3

    .line 9820
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->copyOnWrite()V

    .line 9821
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Chapters;->-$$Nest$msetTitleBytes(Lcom/vdocipher/PlaybackInfo$Chapters;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
