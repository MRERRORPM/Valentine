# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackSession$AndroidOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "AndroidOrBuilder"
.end annotation


# virtual methods
.method public abstract getApiLevel()I
.end method

.method public abstract getDecoder(I)Lcom/vdocipher/PlaybackSession$Decoder;
.end method

.method public abstract getDecoderCount()I
.end method

.method public abstract getDecoderList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackSession$Decoder;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getDevice()Ljava/lang/String;
.end method

.method public abstract getDeviceBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getIsDebug()Z
.end method

.method public abstract getIsSigned()Z
.end method

.method public abstract getLastBootTime()I
.end method

.method public abstract getLastOSUpdateTime()I
.end method

.method public abstract getManufacturer()Ljava/lang/String;
.end method

.method public abstract getManufacturerBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getPrimaryAbi()Ljava/lang/String;
.end method

.method public abstract getPrimaryAbiBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getProduct()Ljava/lang/String;
.end method

.method public abstract getProductBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getRefVersion()Ljava/lang/String;
.end method

.method public abstract getRefVersionBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getSecondaryAbi()Ljava/lang/String;
.end method

.method public abstract getSecondaryAbiBytes()Lcom/google/protobuf/ByteString;
.end method
