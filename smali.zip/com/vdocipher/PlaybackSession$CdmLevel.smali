# classes14.dex

.class public final enum Lcom/vdocipher/PlaybackSession$CdmLevel;
.super Ljava/lang/Enum;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "CdmLevel"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$CdmLevel$CdmLevelVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/PlaybackSession$CdmLevel;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/PlaybackSession$CdmLevel;

.field public static final enum L1:Lcom/vdocipher/PlaybackSession$CdmLevel;

.field public static final L1_VALUE:I = 0x0

.field public static final enum L2:Lcom/vdocipher/PlaybackSession$CdmLevel;

.field public static final L2_VALUE:I = 0x1

.field public static final enum L3:Lcom/vdocipher/PlaybackSession$CdmLevel;

.field public static final L3_VALUE:I = 0x2

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$CdmLevel;

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$CdmLevel;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 7

    .line 986
    new-instance v0, Lcom/vdocipher/PlaybackSession$CdmLevel;

    const-string v1, "L1"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/PlaybackSession$CdmLevel;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$CdmLevel;->L1:Lcom/vdocipher/PlaybackSession$CdmLevel;

    .line 990
    new-instance v1, Lcom/vdocipher/PlaybackSession$CdmLevel;

    const-string v2, "L2"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/PlaybackSession$CdmLevel;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$CdmLevel;->L2:Lcom/vdocipher/PlaybackSession$CdmLevel;

    .line 994
    new-instance v2, Lcom/vdocipher/PlaybackSession$CdmLevel;

    const-string v3, "L3"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4, v4}, Lcom/vdocipher/PlaybackSession$CdmLevel;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/PlaybackSession$CdmLevel;->L3:Lcom/vdocipher/PlaybackSession$CdmLevel;

    .line 995
    new-instance v3, Lcom/vdocipher/PlaybackSession$CdmLevel;

    const/4 v4, 0x3

    const/4 v5, -0x1

    const-string v6, "UNRECOGNIZED"

    invoke-direct {v3, v6, v4, v5}, Lcom/vdocipher/PlaybackSession$CdmLevel;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lcom/vdocipher/PlaybackSession$CdmLevel;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$CdmLevel;

    .line 981
    filled-new-array {v0, v1, v2, v3}, [Lcom/vdocipher/PlaybackSession$CdmLevel;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/PlaybackSession$CdmLevel;->$VALUES:[Lcom/vdocipher/PlaybackSession$CdmLevel;

    .line 1045
    new-instance v0, Lcom/vdocipher/PlaybackSession$CdmLevel$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$CdmLevel$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackSession$CdmLevel;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 1069
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1070
    iput p3, p0, Lcom/vdocipher/PlaybackSession$CdmLevel;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/PlaybackSession$CdmLevel;
    .registers 2

    if-eqz p0, :cond_10

    const/4 v0, 0x1

    if-eq p0, v0, :cond_d

    const/4 v0, 0x2

    if-eq p0, v0, :cond_a

    const/4 p0, 0x0

    return-object p0

    .line 1035
    :cond_a
    sget-object p0, Lcom/vdocipher/PlaybackSession$CdmLevel;->L3:Lcom/vdocipher/PlaybackSession$CdmLevel;

    return-object p0

    .line 1034
    :cond_d
    sget-object p0, Lcom/vdocipher/PlaybackSession$CdmLevel;->L2:Lcom/vdocipher/PlaybackSession$CdmLevel;

    return-object p0

    .line 1033
    :cond_10
    sget-object p0, Lcom/vdocipher/PlaybackSession$CdmLevel;->L1:Lcom/vdocipher/PlaybackSession$CdmLevel;

    return-object p0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$CdmLevel;",
            ">;"
        }
    .end annotation

    .line 1042
    sget-object v0, Lcom/vdocipher/PlaybackSession$CdmLevel;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 1055
    sget-object v0, Lcom/vdocipher/PlaybackSession$CdmLevel$CdmLevelVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/PlaybackSession$CdmLevel;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1028
    invoke-static {p0}, Lcom/vdocipher/PlaybackSession$CdmLevel;->forNumber(I)Lcom/vdocipher/PlaybackSession$CdmLevel;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$CdmLevel;
    .registers 2

    .line 981
    const-class v0, Lcom/vdocipher/PlaybackSession$CdmLevel;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$CdmLevel;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/PlaybackSession$CdmLevel;
    .registers 1

    .line 981
    sget-object v0, Lcom/vdocipher/PlaybackSession$CdmLevel;->$VALUES:[Lcom/vdocipher/PlaybackSession$CdmLevel;

    invoke-virtual {v0}, [Lcom/vdocipher/PlaybackSession$CdmLevel;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/PlaybackSession$CdmLevel;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 1014
    sget-object v0, Lcom/vdocipher/PlaybackSession$CdmLevel;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$CdmLevel;

    if-eq p0, v0, :cond_7

    .line 1018
    iget v0, p0, Lcom/vdocipher/PlaybackSession$CdmLevel;->value:I

    return v0

    .line 1015
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
