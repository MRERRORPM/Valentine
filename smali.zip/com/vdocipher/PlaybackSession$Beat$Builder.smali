# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Beat$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$BeatOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$Beat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$Beat;",
        "Lcom/vdocipher/PlaybackSession$Beat$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$BeatOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 7674
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Beat;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearBl()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 7757
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7758
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearBl(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearBw()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 8160
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 8161
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearBw(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearCc()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 7963
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7964
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearCc(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearFps()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 8188
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 8189
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearFps(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearIb()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 7897
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7898
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearIb(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearIs()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 7925
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7926
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearIs(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearIsInView()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 8076
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 8077
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearIsInView(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearIsVideoInFocus()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 8132
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 8133
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearIsVideoInFocus(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearIsWindowInFocus()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 8104
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 8105
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearIsWindowInFocus(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearPt()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 7729
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7730
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearPt(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearQb()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 8002
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 8003
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearQb(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearQp()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 8048
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 8049
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearQp(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearSt()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 7785
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7786
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearSt(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearT()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 7701
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7702
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearT(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearTc()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 7841
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7842
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearTc(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearTp()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 7813
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7814
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearTp(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public clearVo()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 7869
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7870
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$mclearVo(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public getBl()I
    .registers 2

    .line 7740
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getBl()I

    move-result v0

    return v0
.end method

.method public getBw()I
    .registers 2

    .line 8143
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getBw()I

    move-result v0

    return v0
.end method

.method public getCc()Ljava/lang/String;
    .registers 2

    .line 7936
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getCc()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getCcBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 7945
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getCcBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getFps()I
    .registers 2

    .line 8171
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getFps()I

    move-result v0

    return v0
.end method

.method public getIb()Z
    .registers 2

    .line 7880
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getIb()Z

    move-result v0

    return v0
.end method

.method public getIs()Z
    .registers 2

    .line 7908
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getIs()Z

    move-result v0

    return v0
.end method

.method public getIsInView()Z
    .registers 2

    .line 8059
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getIsInView()Z

    move-result v0

    return v0
.end method

.method public getIsVideoInFocus()Z
    .registers 2

    .line 8115
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getIsVideoInFocus()Z

    move-result v0

    return v0
.end method

.method public getIsWindowInFocus()Z
    .registers 2

    .line 8087
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getIsWindowInFocus()Z

    move-result v0

    return v0
.end method

.method public getPt()F
    .registers 2

    .line 7712
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getPt()F

    move-result v0

    return v0
.end method

.method public getQb()I
    .registers 2

    .line 7985
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getQb()I

    move-result v0

    return v0
.end method

.method public getQp()Lcom/vdocipher/PlaybackSession$QualityPreference;
    .registers 2

    .line 8031
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getQp()Lcom/vdocipher/PlaybackSession$QualityPreference;

    move-result-object v0

    return-object v0
.end method

.method public getQpValue()I
    .registers 2

    .line 8013
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getQpValue()I

    move-result v0

    return v0
.end method

.method public getSt()I
    .registers 2

    .line 7768
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getSt()I

    move-result v0

    return v0
.end method

.method public getT()I
    .registers 2

    .line 7684
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getT()I

    move-result v0

    return v0
.end method

.method public getTc()I
    .registers 2

    .line 7824
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getTc()I

    move-result v0

    return v0
.end method

.method public getTp()F
    .registers 2

    .line 7796
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getTp()F

    move-result v0

    return v0
.end method

.method public getVo()F
    .registers 2

    .line 7852
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getVo()F

    move-result v0

    return v0
.end method

.method public setBl(I)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 7748
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7749
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetBl(Lcom/vdocipher/PlaybackSession$Beat;I)V

    return-object p0
.end method

.method public setBw(I)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 8151
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 8152
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetBw(Lcom/vdocipher/PlaybackSession$Beat;I)V

    return-object p0
.end method

.method public setCc(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 7954
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7955
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetCc(Lcom/vdocipher/PlaybackSession$Beat;Ljava/lang/String;)V

    return-object p0
.end method

.method public setCcBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 7974
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7975
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetCcBytes(Lcom/vdocipher/PlaybackSession$Beat;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setFps(I)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 8179
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 8180
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetFps(Lcom/vdocipher/PlaybackSession$Beat;I)V

    return-object p0
.end method

.method public setIb(Z)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 7888
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7889
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetIb(Lcom/vdocipher/PlaybackSession$Beat;Z)V

    return-object p0
.end method

.method public setIs(Z)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 7916
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7917
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetIs(Lcom/vdocipher/PlaybackSession$Beat;Z)V

    return-object p0
.end method

.method public setIsInView(Z)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 8067
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 8068
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetIsInView(Lcom/vdocipher/PlaybackSession$Beat;Z)V

    return-object p0
.end method

.method public setIsVideoInFocus(Z)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 8123
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 8124
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetIsVideoInFocus(Lcom/vdocipher/PlaybackSession$Beat;Z)V

    return-object p0
.end method

.method public setIsWindowInFocus(Z)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 8095
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 8096
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetIsWindowInFocus(Lcom/vdocipher/PlaybackSession$Beat;Z)V

    return-object p0
.end method

.method public setPt(F)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 7720
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7721
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetPt(Lcom/vdocipher/PlaybackSession$Beat;F)V

    return-object p0
.end method

.method public setQb(I)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 7993
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7994
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetQb(Lcom/vdocipher/PlaybackSession$Beat;I)V

    return-object p0
.end method

.method public setQp(Lcom/vdocipher/PlaybackSession$QualityPreference;)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 8039
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 8040
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetQp(Lcom/vdocipher/PlaybackSession$Beat;Lcom/vdocipher/PlaybackSession$QualityPreference;)V

    return-object p0
.end method

.method public setQpValue(I)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 8021
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 8022
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetQpValue(Lcom/vdocipher/PlaybackSession$Beat;I)V

    return-object p0
.end method

.method public setSt(I)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 7776
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7777
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetSt(Lcom/vdocipher/PlaybackSession$Beat;I)V

    return-object p0
.end method

.method public setT(I)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 7692
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7693
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetT(Lcom/vdocipher/PlaybackSession$Beat;I)V

    return-object p0
.end method

.method public setTc(I)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 7832
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7833
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetTc(Lcom/vdocipher/PlaybackSession$Beat;I)V

    return-object p0
.end method

.method public setTp(F)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 7804
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7805
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetTp(Lcom/vdocipher/PlaybackSession$Beat;F)V

    return-object p0
.end method

.method public setVo(F)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 3

    .line 7860
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->copyOnWrite()V

    .line 7861
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->-$$Nest$msetVo(Lcom/vdocipher/PlaybackSession$Beat;F)V

    return-object p0
.end method
