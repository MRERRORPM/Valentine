# classes14.dex

.class public final enum Lcom/vdocipher/PlaybackInfo$PlayButtonShape;
.super Ljava/lang/Enum;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "PlayButtonShape"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$PlayButtonShape$PlayButtonShapeVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/PlaybackInfo$PlayButtonShape;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

.field public static final enum circle:Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

.field public static final circle_VALUE:I = 0x0

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackInfo$PlayButtonShape;",
            ">;"
        }
    .end annotation
.end field

.field public static final enum square:Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

.field public static final square_VALUE:I = 0x1


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 6

    .line 306
    new-instance v0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    const-string v1, "circle"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->circle:Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    .line 310
    new-instance v1, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    const-string/jumbo v2, "square"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->square:Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    .line 311
    new-instance v2, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    const/4 v3, 0x2

    const/4 v4, -0x1

    const-string v5, "UNRECOGNIZED"

    invoke-direct {v2, v5, v3, v4}, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    .line 301
    filled-new-array {v0, v1, v2}, [Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->$VALUES:[Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    .line 356
    new-instance v0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$PlayButtonShape$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 380
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 381
    iput p3, p0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/PlaybackInfo$PlayButtonShape;
    .registers 2

    if-eqz p0, :cond_a

    const/4 v0, 0x1

    if-eq p0, v0, :cond_7

    const/4 p0, 0x0

    return-object p0

    .line 346
    :cond_7
    sget-object p0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->square:Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    return-object p0

    .line 345
    :cond_a
    sget-object p0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->circle:Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    return-object p0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackInfo$PlayButtonShape;",
            ">;"
        }
    .end annotation

    .line 353
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 366
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape$PlayButtonShapeVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/PlaybackInfo$PlayButtonShape;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 340
    invoke-static {p0}, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->forNumber(I)Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$PlayButtonShape;
    .registers 2

    .line 301
    const-class v0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/PlaybackInfo$PlayButtonShape;
    .registers 1

    .line 301
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->$VALUES:[Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    invoke-virtual {v0}, [Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 326
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    if-eq p0, v0, :cond_7

    .line 330
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->value:I

    return v0

    .line 327
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
