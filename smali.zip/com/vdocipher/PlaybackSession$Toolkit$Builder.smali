# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Toolkit$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$ToolkitOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$Toolkit;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$Toolkit;",
        "Lcom/vdocipher/PlaybackSession$Toolkit$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$ToolkitOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 11761
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Toolkit;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Toolkit;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearName()Lcom/vdocipher/PlaybackSession$Toolkit$Builder;
    .registers 2

    .line 11798
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->copyOnWrite()V

    .line 11799
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;->-$$Nest$mclearName(Lcom/vdocipher/PlaybackSession$Toolkit;)V

    return-object p0
.end method

.method public clearVersion()Lcom/vdocipher/PlaybackSession$Toolkit$Builder;
    .registers 2

    .line 11847
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->copyOnWrite()V

    .line 11848
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;->-$$Nest$mclearVersion(Lcom/vdocipher/PlaybackSession$Toolkit;)V

    return-object p0
.end method

.method public clearVersionCode()Lcom/vdocipher/PlaybackSession$Toolkit$Builder;
    .registers 2

    .line 11886
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->copyOnWrite()V

    .line 11887
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;->-$$Nest$mclearVersionCode(Lcom/vdocipher/PlaybackSession$Toolkit;)V

    return-object p0
.end method

.method public clearVersionMisMatch()Lcom/vdocipher/PlaybackSession$Toolkit$Builder;
    .registers 2

    .line 11914
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->copyOnWrite()V

    .line 11915
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;->-$$Nest$mclearVersionMisMatch(Lcom/vdocipher/PlaybackSession$Toolkit;)V

    return-object p0
.end method

.method public getName()Ljava/lang/String;
    .registers 2

    .line 11771
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;->getName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getNameBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 11780
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;->getNameBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getVersion()Ljava/lang/String;
    .registers 2

    .line 11820
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;->getVersion()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getVersionBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 11829
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;->getVersionBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getVersionCode()I
    .registers 2

    .line 11869
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;->getVersionCode()I

    move-result v0

    return v0
.end method

.method public getVersionMisMatch()Z
    .registers 2

    .line 11897
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;->getVersionMisMatch()Z

    move-result v0

    return v0
.end method

.method public setName(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Toolkit$Builder;
    .registers 3

    .line 11789
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->copyOnWrite()V

    .line 11790
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->-$$Nest$msetName(Lcom/vdocipher/PlaybackSession$Toolkit;Ljava/lang/String;)V

    return-object p0
.end method

.method public setNameBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Toolkit$Builder;
    .registers 3

    .line 11809
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->copyOnWrite()V

    .line 11810
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->-$$Nest$msetNameBytes(Lcom/vdocipher/PlaybackSession$Toolkit;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setVersion(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Toolkit$Builder;
    .registers 3

    .line 11838
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->copyOnWrite()V

    .line 11839
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->-$$Nest$msetVersion(Lcom/vdocipher/PlaybackSession$Toolkit;Ljava/lang/String;)V

    return-object p0
.end method

.method public setVersionBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Toolkit$Builder;
    .registers 3

    .line 11858
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->copyOnWrite()V

    .line 11859
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->-$$Nest$msetVersionBytes(Lcom/vdocipher/PlaybackSession$Toolkit;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setVersionCode(I)Lcom/vdocipher/PlaybackSession$Toolkit$Builder;
    .registers 3

    .line 11877
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->copyOnWrite()V

    .line 11878
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->-$$Nest$msetVersionCode(Lcom/vdocipher/PlaybackSession$Toolkit;I)V

    return-object p0
.end method

.method public setVersionMisMatch(Z)Lcom/vdocipher/PlaybackSession$Toolkit$Builder;
    .registers 3

    .line 11905
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->copyOnWrite()V

    .line 11906
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Toolkit;->-$$Nest$msetVersionMisMatch(Lcom/vdocipher/PlaybackSession$Toolkit;Z)V

    return-object p0
.end method
