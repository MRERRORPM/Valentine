# classes14.dex

.class Lcom/vdocipher/PlaybackSession$SourceType$1;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLiteMap;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$SourceType;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/google/protobuf/Internal$EnumLiteMap<",
        "Lcom/vdocipher/PlaybackSession$SourceType;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .line 160
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic findValueByNumber(I)Lcom/google/protobuf/Internal$EnumLite;
    .registers 2

    .line 160
    invoke-virtual {p0, p1}, Lcom/vdocipher/PlaybackSession$SourceType$1;->findValueByNumber(I)Lcom/vdocipher/PlaybackSession$SourceType;

    move-result-object p1

    return-object p1
.end method

.method public findValueByNumber(I)Lcom/vdocipher/PlaybackSession$SourceType;
    .registers 2

    .line 163
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$SourceType;->forNumber(I)Lcom/vdocipher/PlaybackSession$SourceType;

    move-result-object p1

    return-object p1
.end method
