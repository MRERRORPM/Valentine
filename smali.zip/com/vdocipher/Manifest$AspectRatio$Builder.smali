# classes14.dex

.class public final Lcom/vdocipher/Manifest$AspectRatio$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$AspectRatioOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest$AspectRatio;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/Manifest$AspectRatio;",
        "Lcom/vdocipher/Manifest$AspectRatio$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$AspectRatioOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 557
    invoke-static {}, Lcom/vdocipher/Manifest$AspectRatio;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$AspectRatio;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/Manifest-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AspectRatio$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearHeight()Lcom/vdocipher/Manifest$AspectRatio$Builder;
    .registers 2

    .line 612
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AspectRatio$Builder;->copyOnWrite()V

    .line 613
    iget-object v0, p0, Lcom/vdocipher/Manifest$AspectRatio$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AspectRatio;->-$$Nest$mclearHeight(Lcom/vdocipher/Manifest$AspectRatio;)V

    return-object p0
.end method

.method public clearWidth()Lcom/vdocipher/Manifest$AspectRatio$Builder;
    .registers 2

    .line 584
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AspectRatio$Builder;->copyOnWrite()V

    .line 585
    iget-object v0, p0, Lcom/vdocipher/Manifest$AspectRatio$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AspectRatio;->-$$Nest$mclearWidth(Lcom/vdocipher/Manifest$AspectRatio;)V

    return-object p0
.end method

.method public getHeight()I
    .registers 2

    .line 595
    iget-object v0, p0, Lcom/vdocipher/Manifest$AspectRatio$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AspectRatio;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AspectRatio;->getHeight()I

    move-result v0

    return v0
.end method

.method public getWidth()I
    .registers 2

    .line 567
    iget-object v0, p0, Lcom/vdocipher/Manifest$AspectRatio$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AspectRatio;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AspectRatio;->getWidth()I

    move-result v0

    return v0
.end method

.method public setHeight(I)Lcom/vdocipher/Manifest$AspectRatio$Builder;
    .registers 3

    .line 603
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AspectRatio$Builder;->copyOnWrite()V

    .line 604
    iget-object v0, p0, Lcom/vdocipher/Manifest$AspectRatio$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AspectRatio;->-$$Nest$msetHeight(Lcom/vdocipher/Manifest$AspectRatio;I)V

    return-object p0
.end method

.method public setWidth(I)Lcom/vdocipher/Manifest$AspectRatio$Builder;
    .registers 3

    .line 575
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AspectRatio$Builder;->copyOnWrite()V

    .line 576
    iget-object v0, p0, Lcom/vdocipher/Manifest$AspectRatio$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AspectRatio;->-$$Nest$msetWidth(Lcom/vdocipher/Manifest$AspectRatio;I)V

    return-object p0
.end method
