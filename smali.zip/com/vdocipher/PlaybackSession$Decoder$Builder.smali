# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Decoder$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$DecoderOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$Decoder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$Decoder;",
        "Lcom/vdocipher/PlaybackSession$Decoder$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$DecoderOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 11292
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Decoder;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Decoder;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Decoder$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearDecoderName()Lcom/vdocipher/PlaybackSession$Decoder$Builder;
    .registers 2

    .line 11329
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->copyOnWrite()V

    .line 11330
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Decoder;->-$$Nest$mclearDecoderName(Lcom/vdocipher/PlaybackSession$Decoder;)V

    return-object p0
.end method

.method public clearSupportedTypes()Lcom/vdocipher/PlaybackSession$Decoder$Builder;
    .registers 2

    .line 11378
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->copyOnWrite()V

    .line 11379
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Decoder;->-$$Nest$mclearSupportedTypes(Lcom/vdocipher/PlaybackSession$Decoder;)V

    return-object p0
.end method

.method public getDecoderName()Ljava/lang/String;
    .registers 2

    .line 11302
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Decoder;->getDecoderName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getDecoderNameBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 11311
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Decoder;->getDecoderNameBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSupportedTypes()Ljava/lang/String;
    .registers 2

    .line 11351
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Decoder;->getSupportedTypes()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getSupportedTypesBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 11360
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Decoder;->getSupportedTypesBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setDecoderName(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Decoder$Builder;
    .registers 3

    .line 11320
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->copyOnWrite()V

    .line 11321
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Decoder;->-$$Nest$msetDecoderName(Lcom/vdocipher/PlaybackSession$Decoder;Ljava/lang/String;)V

    return-object p0
.end method

.method public setDecoderNameBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Decoder$Builder;
    .registers 3

    .line 11340
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->copyOnWrite()V

    .line 11341
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Decoder;->-$$Nest$msetDecoderNameBytes(Lcom/vdocipher/PlaybackSession$Decoder;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setSupportedTypes(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Decoder$Builder;
    .registers 3

    .line 11369
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->copyOnWrite()V

    .line 11370
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Decoder;->-$$Nest$msetSupportedTypes(Lcom/vdocipher/PlaybackSession$Decoder;Ljava/lang/String;)V

    return-object p0
.end method

.method public setSupportedTypesBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Decoder$Builder;
    .registers 3

    .line 11389
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->copyOnWrite()V

    .line 11390
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Decoder;->-$$Nest$msetSupportedTypesBytes(Lcom/vdocipher/PlaybackSession$Decoder;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
