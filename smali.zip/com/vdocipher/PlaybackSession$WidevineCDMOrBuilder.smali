# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackSession$WidevineCDMOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "WidevineCDMOrBuilder"
.end annotation


# virtual methods
.method public abstract getDeviceUniqueId()Ljava/lang/String;
.end method

.method public abstract getDeviceUniqueIdBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getDowngradedToL3()Z
.end method

.method public abstract getHdcpLevel()Lcom/vdocipher/PlaybackSession$HDCPLevel;
.end method

.method public abstract getHdcpLevelValue()I
.end method

.method public abstract getMaxHDCPLevel()Lcom/vdocipher/PlaybackSession$HDCPLevel;
.end method

.method public abstract getMaxHDCPLevelValue()I
.end method

.method public abstract getMaxNumberOfSessions()I
.end method

.method public abstract getNumberOfOpenSessions()I
.end method

.method public abstract getOemCryptoApiVersion()I
.end method

.method public abstract getSecurityLevel()Lcom/vdocipher/PlaybackSession$CdmLevel;
.end method

.method public abstract getSecurityLevelValue()I
.end method

.method public abstract getSystemId()I
.end method

.method public abstract getVersion()Ljava/lang/String;
.end method

.method public abstract getVersionBytes()Lcom/google/protobuf/ByteString;
.end method
