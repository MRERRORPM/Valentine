# classes14.dex

.class public interface abstract Lcom/vdocipher/Manifest$RoleOrBuilder;
.super Ljava/lang/Object;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "RoleOrBuilder"
.end annotation


# virtual methods
.method public abstract getSchemeIdUri()Ljava/lang/String;
.end method

.method public abstract getSchemeIdUriBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getValue()Ljava/lang/String;
.end method

.method public abstract getValueBytes()Lcom/google/protobuf/ByteString;
.end method
