# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Media$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$MediaOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$Media;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$Media;",
        "Lcom/vdocipher/PlaybackSession$Media$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$MediaOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 3376
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Media;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Media;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Media$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearId()Lcom/vdocipher/PlaybackSession$Media$Builder;
    .registers 2

    .line 3413
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Media$Builder;->copyOnWrite()V

    .line 3414
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Media$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Media;->-$$Nest$mclearId(Lcom/vdocipher/PlaybackSession$Media;)V

    return-object p0
.end method

.method public getId()Ljava/lang/String;
    .registers 2

    .line 3386
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Media$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Media;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Media;->getId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getIdBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 3395
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Media$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Media;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Media;->getIdBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setId(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Media$Builder;
    .registers 3

    .line 3404
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Media$Builder;->copyOnWrite()V

    .line 3405
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Media$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Media;->-$$Nest$msetId(Lcom/vdocipher/PlaybackSession$Media;Ljava/lang/String;)V

    return-object p0
.end method

.method public setIdBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Media$Builder;
    .registers 3

    .line 3424
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Media$Builder;->copyOnWrite()V

    .line 3425
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Media$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Media;->-$$Nest$msetIdBytes(Lcom/vdocipher/PlaybackSession$Media;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
