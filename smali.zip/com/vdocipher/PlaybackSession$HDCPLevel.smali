# classes14.dex

.class public final enum Lcom/vdocipher/PlaybackSession$HDCPLevel;
.super Ljava/lang/Enum;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "HDCPLevel"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$HDCPLevel$HDCPLevelVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/PlaybackSession$HDCPLevel;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/PlaybackSession$HDCPLevel;

.field public static final enum Disconnected:Lcom/vdocipher/PlaybackSession$HDCPLevel;

.field public static final Disconnected_VALUE:I = 0x0

.field public static final enum HDCP_2_2:Lcom/vdocipher/PlaybackSession$HDCPLevel;

.field public static final HDCP_2_2_VALUE:I = 0x2

.field public static final enum HDCP_2_3:Lcom/vdocipher/PlaybackSession$HDCPLevel;

.field public static final HDCP_2_3_VALUE:I = 0x3

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$HDCPLevel;

.field public static final enum Unprotected:Lcom/vdocipher/PlaybackSession$HDCPLevel;

.field public static final Unprotected_VALUE:I = 0x1

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$HDCPLevel;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 8

    .line 879
    new-instance v0, Lcom/vdocipher/PlaybackSession$HDCPLevel;

    const-string v1, "Disconnected"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/PlaybackSession$HDCPLevel;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$HDCPLevel;->Disconnected:Lcom/vdocipher/PlaybackSession$HDCPLevel;

    .line 883
    new-instance v1, Lcom/vdocipher/PlaybackSession$HDCPLevel;

    const-string v2, "Unprotected"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/PlaybackSession$HDCPLevel;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$HDCPLevel;->Unprotected:Lcom/vdocipher/PlaybackSession$HDCPLevel;

    .line 887
    new-instance v2, Lcom/vdocipher/PlaybackSession$HDCPLevel;

    const-string v3, "HDCP_2_2"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4, v4}, Lcom/vdocipher/PlaybackSession$HDCPLevel;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/PlaybackSession$HDCPLevel;->HDCP_2_2:Lcom/vdocipher/PlaybackSession$HDCPLevel;

    .line 891
    new-instance v3, Lcom/vdocipher/PlaybackSession$HDCPLevel;

    const-string v4, "HDCP_2_3"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5, v5}, Lcom/vdocipher/PlaybackSession$HDCPLevel;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lcom/vdocipher/PlaybackSession$HDCPLevel;->HDCP_2_3:Lcom/vdocipher/PlaybackSession$HDCPLevel;

    .line 892
    new-instance v4, Lcom/vdocipher/PlaybackSession$HDCPLevel;

    const/4 v5, 0x4

    const/4 v6, -0x1

    const-string v7, "UNRECOGNIZED"

    invoke-direct {v4, v7, v5, v6}, Lcom/vdocipher/PlaybackSession$HDCPLevel;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lcom/vdocipher/PlaybackSession$HDCPLevel;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$HDCPLevel;

    .line 874
    filled-new-array {v0, v1, v2, v3, v4}, [Lcom/vdocipher/PlaybackSession$HDCPLevel;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/PlaybackSession$HDCPLevel;->$VALUES:[Lcom/vdocipher/PlaybackSession$HDCPLevel;

    .line 947
    new-instance v0, Lcom/vdocipher/PlaybackSession$HDCPLevel$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$HDCPLevel$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackSession$HDCPLevel;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 971
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 972
    iput p3, p0, Lcom/vdocipher/PlaybackSession$HDCPLevel;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/PlaybackSession$HDCPLevel;
    .registers 2

    if-eqz p0, :cond_16

    const/4 v0, 0x1

    if-eq p0, v0, :cond_13

    const/4 v0, 0x2

    if-eq p0, v0, :cond_10

    const/4 v0, 0x3

    if-eq p0, v0, :cond_d

    const/4 p0, 0x0

    return-object p0

    .line 937
    :cond_d
    sget-object p0, Lcom/vdocipher/PlaybackSession$HDCPLevel;->HDCP_2_3:Lcom/vdocipher/PlaybackSession$HDCPLevel;

    return-object p0

    .line 936
    :cond_10
    sget-object p0, Lcom/vdocipher/PlaybackSession$HDCPLevel;->HDCP_2_2:Lcom/vdocipher/PlaybackSession$HDCPLevel;

    return-object p0

    .line 935
    :cond_13
    sget-object p0, Lcom/vdocipher/PlaybackSession$HDCPLevel;->Unprotected:Lcom/vdocipher/PlaybackSession$HDCPLevel;

    return-object p0

    .line 934
    :cond_16
    sget-object p0, Lcom/vdocipher/PlaybackSession$HDCPLevel;->Disconnected:Lcom/vdocipher/PlaybackSession$HDCPLevel;

    return-object p0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$HDCPLevel;",
            ">;"
        }
    .end annotation

    .line 944
    sget-object v0, Lcom/vdocipher/PlaybackSession$HDCPLevel;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 957
    sget-object v0, Lcom/vdocipher/PlaybackSession$HDCPLevel$HDCPLevelVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/PlaybackSession$HDCPLevel;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 929
    invoke-static {p0}, Lcom/vdocipher/PlaybackSession$HDCPLevel;->forNumber(I)Lcom/vdocipher/PlaybackSession$HDCPLevel;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$HDCPLevel;
    .registers 2

    .line 874
    const-class v0, Lcom/vdocipher/PlaybackSession$HDCPLevel;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$HDCPLevel;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/PlaybackSession$HDCPLevel;
    .registers 1

    .line 874
    sget-object v0, Lcom/vdocipher/PlaybackSession$HDCPLevel;->$VALUES:[Lcom/vdocipher/PlaybackSession$HDCPLevel;

    invoke-virtual {v0}, [Lcom/vdocipher/PlaybackSession$HDCPLevel;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/PlaybackSession$HDCPLevel;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 915
    sget-object v0, Lcom/vdocipher/PlaybackSession$HDCPLevel;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$HDCPLevel;

    if-eq p0, v0, :cond_7

    .line 919
    iget v0, p0, Lcom/vdocipher/PlaybackSession$HDCPLevel;->value:I

    return v0

    .line 916
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
