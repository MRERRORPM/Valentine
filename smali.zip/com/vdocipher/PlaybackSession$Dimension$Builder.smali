# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Dimension$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$DimensionOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$Dimension;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$Dimension;",
        "Lcom/vdocipher/PlaybackSession$Dimension$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$DimensionOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 2841
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Dimension;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearAvailScreenHeight()Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 2

    .line 2868
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 2869
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$mclearAvailScreenHeight(Lcom/vdocipher/PlaybackSession$Dimension;)V

    return-object p0
.end method

.method public clearAvailScreenWidth()Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 2

    .line 2896
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 2897
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$mclearAvailScreenWidth(Lcom/vdocipher/PlaybackSession$Dimension;)V

    return-object p0
.end method

.method public clearInnerWindowHeight()Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 2

    .line 3036
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 3037
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$mclearInnerWindowHeight(Lcom/vdocipher/PlaybackSession$Dimension;)V

    return-object p0
.end method

.method public clearInnerWindowWidth()Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 2

    .line 3064
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 3065
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$mclearInnerWindowWidth(Lcom/vdocipher/PlaybackSession$Dimension;)V

    return-object p0
.end method

.method public clearOuterWindowHeight()Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 2

    .line 3092
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 3093
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$mclearOuterWindowHeight(Lcom/vdocipher/PlaybackSession$Dimension;)V

    return-object p0
.end method

.method public clearOuterWindowWidth()Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 2

    .line 3120
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 3121
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$mclearOuterWindowWidth(Lcom/vdocipher/PlaybackSession$Dimension;)V

    return-object p0
.end method

.method public clearScreenHeight()Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 2

    .line 2924
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 2925
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$mclearScreenHeight(Lcom/vdocipher/PlaybackSession$Dimension;)V

    return-object p0
.end method

.method public clearScreenWidth()Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 2

    .line 2952
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 2953
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$mclearScreenWidth(Lcom/vdocipher/PlaybackSession$Dimension;)V

    return-object p0
.end method

.method public clearVideoHeight()Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 2

    .line 2980
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 2981
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$mclearVideoHeight(Lcom/vdocipher/PlaybackSession$Dimension;)V

    return-object p0
.end method

.method public clearVideoWidth()Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 2

    .line 3008
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 3009
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$mclearVideoWidth(Lcom/vdocipher/PlaybackSession$Dimension;)V

    return-object p0
.end method

.method public getAvailScreenHeight()I
    .registers 2

    .line 2851
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->getAvailScreenHeight()I

    move-result v0

    return v0
.end method

.method public getAvailScreenWidth()I
    .registers 2

    .line 2879
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->getAvailScreenWidth()I

    move-result v0

    return v0
.end method

.method public getInnerWindowHeight()I
    .registers 2

    .line 3019
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->getInnerWindowHeight()I

    move-result v0

    return v0
.end method

.method public getInnerWindowWidth()I
    .registers 2

    .line 3047
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->getInnerWindowWidth()I

    move-result v0

    return v0
.end method

.method public getOuterWindowHeight()I
    .registers 2

    .line 3075
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->getOuterWindowHeight()I

    move-result v0

    return v0
.end method

.method public getOuterWindowWidth()I
    .registers 2

    .line 3103
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->getOuterWindowWidth()I

    move-result v0

    return v0
.end method

.method public getScreenHeight()I
    .registers 2

    .line 2907
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->getScreenHeight()I

    move-result v0

    return v0
.end method

.method public getScreenWidth()I
    .registers 2

    .line 2935
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->getScreenWidth()I

    move-result v0

    return v0
.end method

.method public getVideoHeight()I
    .registers 2

    .line 2963
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->getVideoHeight()I

    move-result v0

    return v0
.end method

.method public getVideoWidth()I
    .registers 2

    .line 2991
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->getVideoWidth()I

    move-result v0

    return v0
.end method

.method public setAvailScreenHeight(I)Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 3

    .line 2859
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 2860
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$msetAvailScreenHeight(Lcom/vdocipher/PlaybackSession$Dimension;I)V

    return-object p0
.end method

.method public setAvailScreenWidth(I)Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 3

    .line 2887
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 2888
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$msetAvailScreenWidth(Lcom/vdocipher/PlaybackSession$Dimension;I)V

    return-object p0
.end method

.method public setInnerWindowHeight(I)Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 3

    .line 3027
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 3028
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$msetInnerWindowHeight(Lcom/vdocipher/PlaybackSession$Dimension;I)V

    return-object p0
.end method

.method public setInnerWindowWidth(I)Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 3

    .line 3055
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 3056
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$msetInnerWindowWidth(Lcom/vdocipher/PlaybackSession$Dimension;I)V

    return-object p0
.end method

.method public setOuterWindowHeight(I)Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 3

    .line 3083
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 3084
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$msetOuterWindowHeight(Lcom/vdocipher/PlaybackSession$Dimension;I)V

    return-object p0
.end method

.method public setOuterWindowWidth(I)Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 3

    .line 3111
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 3112
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$msetOuterWindowWidth(Lcom/vdocipher/PlaybackSession$Dimension;I)V

    return-object p0
.end method

.method public setScreenHeight(I)Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 3

    .line 2915
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 2916
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$msetScreenHeight(Lcom/vdocipher/PlaybackSession$Dimension;I)V

    return-object p0
.end method

.method public setScreenWidth(I)Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 3

    .line 2943
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 2944
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$msetScreenWidth(Lcom/vdocipher/PlaybackSession$Dimension;I)V

    return-object p0
.end method

.method public setVideoHeight(I)Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 3

    .line 2971
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 2972
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$msetVideoHeight(Lcom/vdocipher/PlaybackSession$Dimension;I)V

    return-object p0
.end method

.method public setVideoWidth(I)Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 3

    .line 2999
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->copyOnWrite()V

    .line 3000
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->-$$Nest$msetVideoWidth(Lcom/vdocipher/PlaybackSession$Dimension;I)V

    return-object p0
.end method
