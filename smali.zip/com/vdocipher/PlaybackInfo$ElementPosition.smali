# classes14.dex

.class public final enum Lcom/vdocipher/PlaybackInfo$ElementPosition;
.super Ljava/lang/Enum;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "ElementPosition"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$ElementPosition$ElementPositionVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/PlaybackInfo$ElementPosition;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/PlaybackInfo$ElementPosition;

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$ElementPosition;

.field public static final enum bottomLeft:Lcom/vdocipher/PlaybackInfo$ElementPosition;

.field public static final bottomLeft_VALUE:I = 0x3

.field public static final enum bottomRight:Lcom/vdocipher/PlaybackInfo$ElementPosition;

.field public static final bottomRight_VALUE:I = 0x4

.field public static final enum center:Lcom/vdocipher/PlaybackInfo$ElementPosition;

.field public static final center_VALUE:I = 0x5

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackInfo$ElementPosition;",
            ">;"
        }
    .end annotation
.end field

.field public static final enum none:Lcom/vdocipher/PlaybackInfo$ElementPosition;

.field public static final none_VALUE:I = 0x0

.field public static final enum topLeft:Lcom/vdocipher/PlaybackInfo$ElementPosition;

.field public static final topLeft_VALUE:I = 0x1

.field public static final enum topRight:Lcom/vdocipher/PlaybackInfo$ElementPosition;

.field public static final topRight_VALUE:I = 0x2


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 10

    .line 395
    new-instance v0, Lcom/vdocipher/PlaybackInfo$ElementPosition;

    const-string v1, "none"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/PlaybackInfo$ElementPosition;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$ElementPosition;->none:Lcom/vdocipher/PlaybackInfo$ElementPosition;

    .line 399
    new-instance v1, Lcom/vdocipher/PlaybackInfo$ElementPosition;

    const-string/jumbo v2, "topLeft"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/PlaybackInfo$ElementPosition;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackInfo$ElementPosition;->topLeft:Lcom/vdocipher/PlaybackInfo$ElementPosition;

    .line 403
    new-instance v2, Lcom/vdocipher/PlaybackInfo$ElementPosition;

    const-string/jumbo v3, "topRight"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4, v4}, Lcom/vdocipher/PlaybackInfo$ElementPosition;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/PlaybackInfo$ElementPosition;->topRight:Lcom/vdocipher/PlaybackInfo$ElementPosition;

    .line 407
    new-instance v3, Lcom/vdocipher/PlaybackInfo$ElementPosition;

    const-string v4, "bottomLeft"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5, v5}, Lcom/vdocipher/PlaybackInfo$ElementPosition;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lcom/vdocipher/PlaybackInfo$ElementPosition;->bottomLeft:Lcom/vdocipher/PlaybackInfo$ElementPosition;

    .line 411
    new-instance v4, Lcom/vdocipher/PlaybackInfo$ElementPosition;

    const-string v5, "bottomRight"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6, v6}, Lcom/vdocipher/PlaybackInfo$ElementPosition;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lcom/vdocipher/PlaybackInfo$ElementPosition;->bottomRight:Lcom/vdocipher/PlaybackInfo$ElementPosition;

    .line 415
    new-instance v5, Lcom/vdocipher/PlaybackInfo$ElementPosition;

    const-string v6, "center"

    const/4 v7, 0x5

    invoke-direct {v5, v6, v7, v7}, Lcom/vdocipher/PlaybackInfo$ElementPosition;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lcom/vdocipher/PlaybackInfo$ElementPosition;->center:Lcom/vdocipher/PlaybackInfo$ElementPosition;

    .line 416
    new-instance v6, Lcom/vdocipher/PlaybackInfo$ElementPosition;

    const/4 v7, 0x6

    const/4 v8, -0x1

    const-string v9, "UNRECOGNIZED"

    invoke-direct {v6, v9, v7, v8}, Lcom/vdocipher/PlaybackInfo$ElementPosition;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lcom/vdocipher/PlaybackInfo$ElementPosition;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$ElementPosition;

    .line 390
    filled-new-array/range {v0 .. v6}, [Lcom/vdocipher/PlaybackInfo$ElementPosition;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/PlaybackInfo$ElementPosition;->$VALUES:[Lcom/vdocipher/PlaybackInfo$ElementPosition;

    .line 481
    new-instance v0, Lcom/vdocipher/PlaybackInfo$ElementPosition$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$ElementPosition$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$ElementPosition;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 505
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 506
    iput p3, p0, Lcom/vdocipher/PlaybackInfo$ElementPosition;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/PlaybackInfo$ElementPosition;
    .registers 2

    if-eqz p0, :cond_22

    const/4 v0, 0x1

    if-eq p0, v0, :cond_1f

    const/4 v0, 0x2

    if-eq p0, v0, :cond_1c

    const/4 v0, 0x3

    if-eq p0, v0, :cond_19

    const/4 v0, 0x4

    if-eq p0, v0, :cond_16

    const/4 v0, 0x5

    if-eq p0, v0, :cond_13

    const/4 p0, 0x0

    return-object p0

    .line 471
    :cond_13
    sget-object p0, Lcom/vdocipher/PlaybackInfo$ElementPosition;->center:Lcom/vdocipher/PlaybackInfo$ElementPosition;

    return-object p0

    .line 470
    :cond_16
    sget-object p0, Lcom/vdocipher/PlaybackInfo$ElementPosition;->bottomRight:Lcom/vdocipher/PlaybackInfo$ElementPosition;

    return-object p0

    .line 469
    :cond_19
    sget-object p0, Lcom/vdocipher/PlaybackInfo$ElementPosition;->bottomLeft:Lcom/vdocipher/PlaybackInfo$ElementPosition;

    return-object p0

    .line 468
    :cond_1c
    sget-object p0, Lcom/vdocipher/PlaybackInfo$ElementPosition;->topRight:Lcom/vdocipher/PlaybackInfo$ElementPosition;

    return-object p0

    .line 467
    :cond_1f
    sget-object p0, Lcom/vdocipher/PlaybackInfo$ElementPosition;->topLeft:Lcom/vdocipher/PlaybackInfo$ElementPosition;

    return-object p0

    .line 466
    :cond_22
    sget-object p0, Lcom/vdocipher/PlaybackInfo$ElementPosition;->none:Lcom/vdocipher/PlaybackInfo$ElementPosition;

    return-object p0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackInfo$ElementPosition;",
            ">;"
        }
    .end annotation

    .line 478
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ElementPosition;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 491
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ElementPosition$ElementPositionVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/PlaybackInfo$ElementPosition;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 461
    invoke-static {p0}, Lcom/vdocipher/PlaybackInfo$ElementPosition;->forNumber(I)Lcom/vdocipher/PlaybackInfo$ElementPosition;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$ElementPosition;
    .registers 2

    .line 390
    const-class v0, Lcom/vdocipher/PlaybackInfo$ElementPosition;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ElementPosition;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/PlaybackInfo$ElementPosition;
    .registers 1

    .line 390
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ElementPosition;->$VALUES:[Lcom/vdocipher/PlaybackInfo$ElementPosition;

    invoke-virtual {v0}, [Lcom/vdocipher/PlaybackInfo$ElementPosition;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/PlaybackInfo$ElementPosition;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 447
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ElementPosition;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$ElementPosition;

    if-eq p0, v0, :cond_7

    .line 451
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$ElementPosition;->value:I

    return v0

    .line 448
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
