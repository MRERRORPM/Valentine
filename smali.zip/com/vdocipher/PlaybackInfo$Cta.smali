# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$Cta;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$CtaOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Cta"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$Cta$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackInfo$Cta;",
        "Lcom/vdocipher/PlaybackInfo$Cta$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$CtaOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

.field public static final ID_FIELD_NUMBER:I = 0x1

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$Cta;",
            ">;"
        }
    .end annotation
.end field

.field public static final TYPE_FIELD_NUMBER:I = 0x2


# instance fields
.field private id_:Ljava/lang/String;

.field private type_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$mclearId(Lcom/vdocipher/PlaybackInfo$Cta;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Cta;->clearId()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearType(Lcom/vdocipher/PlaybackInfo$Cta;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Cta;->clearType()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetId(Lcom/vdocipher/PlaybackInfo$Cta;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Cta;->setId(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIdBytes(Lcom/vdocipher/PlaybackInfo$Cta;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Cta;->setIdBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetType(Lcom/vdocipher/PlaybackInfo$Cta;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Cta;->setType(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTypeBytes(Lcom/vdocipher/PlaybackInfo$Cta;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Cta;->setTypeBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 11633
    new-instance v0, Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$Cta;-><init>()V

    .line 11636
    sput-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    .line 11637
    const-class v1, Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 11283
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 11284
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta;->id_:Ljava/lang/String;

    .line 11285
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta;->type_:Ljava/lang/String;

    return-void
.end method

.method private clearId()V
    .registers 2

    .line 11321
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Cta;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$Cta;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Cta;->getId()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta;->id_:Ljava/lang/String;

    return-void
.end method

.method private clearType()V
    .registers 2

    .line 11368
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Cta;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$Cta;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Cta;->getType()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta;->type_:Ljava/lang/String;

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 1

    .line 11642
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackInfo$Cta$Builder;
    .registers 1

    .line 11458
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Cta;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Cta$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackInfo$Cta;)Lcom/vdocipher/PlaybackInfo$Cta$Builder;
    .registers 2

    .line 11461
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$Cta;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Cta$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11434
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackInfo$Cta;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Cta;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11441
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackInfo$Cta;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Cta;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11397
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Cta;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11404
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Cta;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11446
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Cta;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11453
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Cta;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11421
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Cta;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11428
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Cta;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11384
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Cta;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11391
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Cta;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11409
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Cta;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11416
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Cta;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$Cta;",
            ">;"
        }
    .end annotation

    .line 11648
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Cta;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setId(Ljava/lang/String;)V
    .registers 2

    .line 11312
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11314
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Cta;->id_:Ljava/lang/String;

    return-void
.end method

.method private setIdBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 11329
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$Cta;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 11330
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Cta;->id_:Ljava/lang/String;

    return-void
.end method

.method private setType(Ljava/lang/String;)V
    .registers 2

    .line 11359
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11361
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Cta;->type_:Ljava/lang/String;

    return-void
.end method

.method private setTypeBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 11376
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$Cta;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 11377
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Cta;->type_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 11583
    sget-object p2, Lcom/vdocipher/PlaybackInfo$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_54

    .line 11626
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 11620
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 11605
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackInfo$Cta;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 11607
    const-class p2, Lcom/vdocipher/PlaybackInfo$Cta;

    monitor-enter p2

    .line 11608
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackInfo$Cta;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 11610
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 11613
    sput-object p1, Lcom/vdocipher/PlaybackInfo$Cta;->PARSER:Lcom/google/protobuf/Parser;

    .line 11615
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 11602
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    return-object p1

    .line 11591
    :pswitch_36  #0x3
    const-string p1, "id_"

    const-string/jumbo p2, "type_"

    filled-new-array {p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    .line 11595
    const-string p2, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ"

    .line 11598
    sget-object p3, Lcom/vdocipher/PlaybackInfo$Cta;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackInfo$Cta;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 11588
    :pswitch_48  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackInfo$Cta$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackInfo$Cta$Builder;-><init>(Lcom/vdocipher/PlaybackInfo-IA;)V

    return-object p1

    .line 11585
    :pswitch_4e  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackInfo$Cta;-><init>()V

    return-object p1

    :pswitch_data_54
    .packed-switch 0x1
        :pswitch_4e  #00000001
        :pswitch_48  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getId()Ljava/lang/String;
    .registers 2

    .line 11295
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta;->id_:Ljava/lang/String;

    return-object v0
.end method

.method public getIdBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 11304
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta;->id_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getType()Ljava/lang/String;
    .registers 2

    .line 11342
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta;->type_:Ljava/lang/String;

    return-object v0
.end method

.method public getTypeBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 11351
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta;->type_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method
