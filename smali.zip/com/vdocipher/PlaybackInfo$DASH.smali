# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$DASH;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$DASHOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "DASH"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackInfo$DASH;",
        "Lcom/vdocipher/PlaybackInfo$DASH$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$DASHOrBuilder;"
    }
.end annotation


# static fields
.field public static final ALLOWSAFETYDETECT_FIELD_NUMBER:I = 0xa

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

.field public static final ENFORCEAL3_FIELD_NUMBER:I = 0x4

.field public static final ENFORCEHARDWAREATTESTATION_FIELD_NUMBER:I = 0x9

.field public static final ENFORCEL3CONFIG_FIELD_NUMBER:I = 0x3

.field public static final ERRORCODESAL3_FIELD_NUMBER:I = 0x5

.field public static final FALLBACKLICENSESERVERS_FIELD_NUMBER:I = 0x7

.field public static final LICENSESERVERS_FIELD_NUMBER:I = 0x1

.field public static final MANIFEST_FIELD_NUMBER:I = 0x2

.field public static final MPDSTRING_FIELD_NUMBER:I = 0x6

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$DASH;",
            ">;"
        }
    .end annotation
.end field

.field public static final PSR_FIELD_NUMBER:I = 0x8


# instance fields
.field private allowSafetyDetect_:Z

.field private bitField0_:I

.field private enforceAL3_:Z

.field private enforceHardwareAttestation_:Z

.field private enforceL3Config_:Z

.field private errorCodesAL3MemoizedSerializedSize:I

.field private errorCodesAL3_:Lcom/google/protobuf/Internal$IntList;

.field private fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private licenseServers_:Ljava/lang/String;

.field private manifest_:Lcom/google/protobuf/ByteString;

.field private mpdString_:Lcom/google/protobuf/ByteString;

.field private psr_:Z


# direct methods
.method static bridge synthetic -$$Nest$maddAllErrorCodesAL3(Lcom/vdocipher/PlaybackInfo$DASH;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->addAllErrorCodesAL3(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$DASH;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->addAllFallbackLicenseServers(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddErrorCodesAL3(Lcom/vdocipher/PlaybackInfo$DASH;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->addErrorCodesAL3(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$DASH;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->addFallbackLicenseServers(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddFallbackLicenseServersBytes(Lcom/vdocipher/PlaybackInfo$DASH;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->addFallbackLicenseServersBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearAllowSafetyDetect(Lcom/vdocipher/PlaybackInfo$DASH;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->clearAllowSafetyDetect()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEnforceAL3(Lcom/vdocipher/PlaybackInfo$DASH;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->clearEnforceAL3()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEnforceHardwareAttestation(Lcom/vdocipher/PlaybackInfo$DASH;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->clearEnforceHardwareAttestation()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEnforceL3Config(Lcom/vdocipher/PlaybackInfo$DASH;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->clearEnforceL3Config()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearErrorCodesAL3(Lcom/vdocipher/PlaybackInfo$DASH;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->clearErrorCodesAL3()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$DASH;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->clearFallbackLicenseServers()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLicenseServers(Lcom/vdocipher/PlaybackInfo$DASH;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->clearLicenseServers()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearManifest(Lcom/vdocipher/PlaybackInfo$DASH;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->clearManifest()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMpdString(Lcom/vdocipher/PlaybackInfo$DASH;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->clearMpdString()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPsr(Lcom/vdocipher/PlaybackInfo$DASH;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->clearPsr()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAllowSafetyDetect(Lcom/vdocipher/PlaybackInfo$DASH;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->setAllowSafetyDetect(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnforceAL3(Lcom/vdocipher/PlaybackInfo$DASH;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->setEnforceAL3(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnforceHardwareAttestation(Lcom/vdocipher/PlaybackInfo$DASH;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->setEnforceHardwareAttestation(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnforceL3Config(Lcom/vdocipher/PlaybackInfo$DASH;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->setEnforceL3Config(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetErrorCodesAL3(Lcom/vdocipher/PlaybackInfo$DASH;II)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$DASH;->setErrorCodesAL3(II)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$DASH;ILjava/lang/String;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$DASH;->setFallbackLicenseServers(ILjava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLicenseServers(Lcom/vdocipher/PlaybackInfo$DASH;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->setLicenseServers(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLicenseServersBytes(Lcom/vdocipher/PlaybackInfo$DASH;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->setLicenseServersBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetManifest(Lcom/vdocipher/PlaybackInfo$DASH;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->setManifest(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMpdString(Lcom/vdocipher/PlaybackInfo$DASH;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->setMpdString(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPsr(Lcom/vdocipher/PlaybackInfo$DASH;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->setPsr(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 7850
    new-instance v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$DASH;-><init>()V

    .line 7853
    sput-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    .line 7854
    const-class v1, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 6829
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    const/4 v0, -0x1

    .line 6991
    iput v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->errorCodesAL3MemoizedSerializedSize:I

    .line 6830
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->licenseServers_:Ljava/lang/String;

    .line 6831
    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->manifest_:Lcom/google/protobuf/ByteString;

    .line 6832
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$DASH;->emptyIntList()Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->errorCodesAL3_:Lcom/google/protobuf/Internal$IntList;

    .line 6833
    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->mpdString_:Lcom/google/protobuf/ByteString;

    .line 6834
    invoke-static {}, Lcom/google/protobuf/GeneratedMessageLite;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private addAllErrorCodesAL3(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .line 7023
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->ensureErrorCodesAL3IsMutable()V

    .line 7024
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->errorCodesAL3_:Lcom/google/protobuf/Internal$IntList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAllFallbackLicenseServers(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 7133
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->ensureFallbackLicenseServersIsMutable()V

    .line 7134
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addErrorCodesAL3(I)V
    .registers 3

    .line 7014
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->ensureErrorCodesAL3IsMutable()V

    .line 7015
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->errorCodesAL3_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    return-void
.end method

.method private addFallbackLicenseServers(Ljava/lang/String;)V
    .registers 3

    .line 7123
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7124
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->ensureFallbackLicenseServersIsMutable()V

    .line 7125
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addFallbackLicenseServersBytes(Lcom/google/protobuf/ByteString;)V
    .registers 3

    .line 7149
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$DASH;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 7150
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->ensureFallbackLicenseServersIsMutable()V

    .line 7151
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private clearAllowSafetyDetect()V
    .registers 2

    .line 7252
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->bitField0_:I

    and-int/lit8 v0, v0, -0x5

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->bitField0_:I

    const/4 v0, 0x0

    .line 7253
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->allowSafetyDetect_:Z

    return-void
.end method

.method private clearEnforceAL3()V
    .registers 2

    const/4 v0, 0x0

    .line 6960
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->enforceAL3_:Z

    return-void
.end method

.method private clearEnforceHardwareAttestation()V
    .registers 2

    .line 7218
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->bitField0_:I

    and-int/lit8 v0, v0, -0x3

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->bitField0_:I

    const/4 v0, 0x0

    .line 7219
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->enforceHardwareAttestation_:Z

    return-void
.end method

.method private clearEnforceL3Config()V
    .registers 2

    const/4 v0, 0x0

    .line 6934
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->enforceL3Config_:Z

    return-void
.end method

.method private clearErrorCodesAL3()V
    .registers 2

    .line 7031
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$DASH;->emptyIntList()Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->errorCodesAL3_:Lcom/google/protobuf/Internal$IntList;

    return-void
.end method

.method private clearFallbackLicenseServers()V
    .registers 2

    .line 7141
    invoke-static {}, Lcom/google/protobuf/GeneratedMessageLite;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearLicenseServers()V
    .registers 2

    .line 6871
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$DASH;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$DASH;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getLicenseServers()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->licenseServers_:Ljava/lang/String;

    return-void
.end method

.method private clearManifest()V
    .registers 2

    .line 6908
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$DASH;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$DASH;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getManifest()Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->manifest_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private clearMpdString()V
    .registers 2

    .line 7058
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$DASH;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$DASH;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getMpdString()Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->mpdString_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private clearPsr()V
    .registers 2

    .line 7184
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->bitField0_:I

    and-int/lit8 v0, v0, -0x2

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->bitField0_:I

    const/4 v0, 0x0

    .line 7185
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->psr_:Z

    return-void
.end method

.method private ensureErrorCodesAL3IsMutable()V
    .registers 3

    .line 6993
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->errorCodesAL3_:Lcom/google/protobuf/Internal$IntList;

    .line 6994
    invoke-interface {v0}, Lcom/google/protobuf/Internal$IntList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 6996
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$IntList;)Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->errorCodesAL3_:Lcom/google/protobuf/Internal$IntList;

    :cond_e
    return-void
.end method

.method private ensureFallbackLicenseServersIsMutable()V
    .registers 3

    .line 7100
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 7101
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 7103
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 1

    .line 7859
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 1

    .line 7333
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackInfo$DASH;)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 2

    .line 7336
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$DASH;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7309
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackInfo$DASH;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$DASH;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7316
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$DASH;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7272
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$DASH;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7279
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$DASH;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7321
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$DASH;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7328
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$DASH;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7296
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$DASH;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7303
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$DASH;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7259
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$DASH;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7266
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$DASH;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7284
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$DASH;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7291
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$DASH;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$DASH;",
            ">;"
        }
    .end annotation

    .line 7865
    sget-object v0, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setAllowSafetyDetect(Z)V
    .registers 3

    .line 7245
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->bitField0_:I

    or-int/lit8 v0, v0, 0x4

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->bitField0_:I

    .line 7246
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$DASH;->allowSafetyDetect_:Z

    return-void
.end method

.method private setEnforceAL3(Z)V
    .registers 2

    .line 6953
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$DASH;->enforceAL3_:Z

    return-void
.end method

.method private setEnforceHardwareAttestation(Z)V
    .registers 3

    .line 7211
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->bitField0_:I

    or-int/lit8 v0, v0, 0x2

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->bitField0_:I

    .line 7212
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$DASH;->enforceHardwareAttestation_:Z

    return-void
.end method

.method private setEnforceL3Config(Z)V
    .registers 2

    .line 6927
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$DASH;->enforceL3Config_:Z

    return-void
.end method

.method private setErrorCodesAL3(II)V
    .registers 4

    .line 7006
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->ensureErrorCodesAL3IsMutable()V

    .line 7007
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->errorCodesAL3_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$IntList;->setInt(II)I

    return-void
.end method

.method private setFallbackLicenseServers(ILjava/lang/String;)V
    .registers 4

    .line 7113
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7114
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH;->ensureFallbackLicenseServersIsMutable()V

    .line 7115
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setLicenseServers(Ljava/lang/String;)V
    .registers 2

    .line 6862
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6864
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$DASH;->licenseServers_:Ljava/lang/String;

    return-void
.end method

.method private setLicenseServersBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 6879
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$DASH;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 6880
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$DASH;->licenseServers_:Ljava/lang/String;

    return-void
.end method

.method private setManifest(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 6899
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6901
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$DASH;->manifest_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private setMpdString(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 7049
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7051
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$DASH;->mpdString_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private setPsr(Z)V
    .registers 3

    .line 7177
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->bitField0_:I

    or-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->bitField0_:I

    .line 7178
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$DASH;->psr_:Z

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 15

    .line 7790
    sget-object p2, Lcom/vdocipher/PlaybackInfo$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_66

    .line 7843
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 7837
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 7822
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackInfo$DASH;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_33

    .line 7824
    const-class p2, Lcom/vdocipher/PlaybackInfo$DASH;

    monitor-enter p2

    .line 7825
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackInfo$DASH;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 7827
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 7830
    sput-object p1, Lcom/vdocipher/PlaybackInfo$DASH;->PARSER:Lcom/google/protobuf/Parser;

    .line 7832
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception v0

    move-object p1, v0

    monitor-exit p2
    :try_end_32
    .catchall {:try_start_20 .. :try_end_32} :catchall_2f

    throw p1

    :cond_33
    return-object p1

    .line 7819
    :pswitch_34  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    return-object p1

    .line 7798
    :pswitch_37  #0x3
    const-string v0, "bitField0_"

    const-string v1, "licenseServers_"

    const-string v2, "manifest_"

    const-string v3, "enforceL3Config_"

    const-string v4, "enforceAL3_"

    const-string v5, "errorCodesAL3_"

    const-string v6, "mpdString_"

    const-string v7, "fallbackLicenseServers_"

    const-string v8, "psr_"

    const-string v9, "enforceHardwareAttestation_"

    const-string v10, "allowSafetyDetect_"

    filled-new-array/range {v0 .. v10}, [Ljava/lang/Object;

    move-result-object p1

    .line 7811
    const-string p2, "\u0000\n\u0000\u0001\u0001\n\n\u0000\u0002\u0000\u0001Ȉ\u0002\n\u0003\u0007\u0004\u0007\u0005+\u0006\n\u0007Ț\bဇ\u0000\tဇ\u0001\nဇ\u0002"

    .line 7815
    sget-object p3, Lcom/vdocipher/PlaybackInfo$DASH;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 7795
    :pswitch_5a  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackInfo$DASH$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;-><init>(Lcom/vdocipher/PlaybackInfo-IA;)V

    return-object p1

    .line 7792
    :pswitch_60  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackInfo$DASH;-><init>()V

    return-object p1

    :pswitch_data_66
    .packed-switch 0x1
        :pswitch_60  #00000001
        :pswitch_5a  #00000002
        :pswitch_37  #00000003
        :pswitch_34  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getAllowSafetyDetect()Z
    .registers 2

    .line 7238
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->allowSafetyDetect_:Z

    return v0
.end method

.method public getEnforceAL3()Z
    .registers 2

    .line 6945
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->enforceAL3_:Z

    return v0
.end method

.method public getEnforceHardwareAttestation()Z
    .registers 2

    .line 7204
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->enforceHardwareAttestation_:Z

    return v0
.end method

.method public getEnforceL3Config()Z
    .registers 2

    .line 6919
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->enforceL3Config_:Z

    return v0
.end method

.method public getErrorCodesAL3(I)I
    .registers 3

    .line 6989
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->errorCodesAL3_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->getInt(I)I

    move-result p1

    return p1
.end method

.method public getErrorCodesAL3Count()I
    .registers 2

    .line 6980
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->errorCodesAL3_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$IntList;->size()I

    move-result v0

    return v0
.end method

.method public getErrorCodesAL3List()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 6972
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->errorCodesAL3_:Lcom/google/protobuf/Internal$IntList;

    return-object v0
.end method

.method public getFallbackLicenseServers(I)Ljava/lang/String;
    .registers 3

    .line 7086
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    return-object p1
.end method

.method public getFallbackLicenseServersBytes(I)Lcom/google/protobuf/ByteString;
    .registers 3

    .line 7096
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 7097
    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    .line 7096
    invoke-static {p1}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object p1

    return-object p1
.end method

.method public getFallbackLicenseServersCount()I
    .registers 2

    .line 7077
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getFallbackLicenseServersList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 7069
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getLicenseServers()Ljava/lang/String;
    .registers 2

    .line 6845
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->licenseServers_:Ljava/lang/String;

    return-object v0
.end method

.method public getLicenseServersBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 6854
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->licenseServers_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getManifest()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 6892
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->manifest_:Lcom/google/protobuf/ByteString;

    return-object v0
.end method

.method public getMpdString()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 7042
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->mpdString_:Lcom/google/protobuf/ByteString;

    return-object v0
.end method

.method public getPsr()Z
    .registers 2

    .line 7170
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->psr_:Z

    return v0
.end method

.method public hasAllowSafetyDetect()Z
    .registers 2

    .line 7230
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->bitField0_:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasEnforceHardwareAttestation()Z
    .registers 2

    .line 7196
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->bitField0_:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasPsr()Z
    .registers 3

    .line 7162
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$DASH;->bitField0_:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_7

    return v1

    :cond_7
    const/4 v0, 0x0

    return v0
.end method
