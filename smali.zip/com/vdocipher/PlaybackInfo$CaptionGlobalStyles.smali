# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$CaptionGlobalStylesOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "CaptionGlobalStyles"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;",
        "Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$CaptionGlobalStylesOrBuilder;"
    }
.end annotation


# static fields
.field public static final BACKGROUNDCOLOR_FIELD_NUMBER:I = 0x2

.field public static final CAPTIONMAXFONT_FIELD_NUMBER:I = 0x4

.field public static final CAPTIONSCALEFACTOR_FIELD_NUMBER:I = 0x5

.field public static final COLOR_FIELD_NUMBER:I = 0x1

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

.field public static final PADDING_FIELD_NUMBER:I = 0x3

.field private static volatile PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private backgroundColor_:Lcom/google/protobuf/ByteString;

.field private captionMaxFont_:F

.field private captionScaleFactor_:F

.field private color_:Lcom/google/protobuf/ByteString;

.field private padding_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$mclearBackgroundColor(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->clearBackgroundColor()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearCaptionMaxFont(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->clearCaptionMaxFont()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearCaptionScaleFactor(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->clearCaptionScaleFactor()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearColor(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->clearColor()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPadding(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->clearPadding()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetBackgroundColor(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->setBackgroundColor(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCaptionMaxFont(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;F)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->setCaptionMaxFont(F)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCaptionScaleFactor(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;F)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->setCaptionScaleFactor(F)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetColor(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->setColor(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPadding(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->setPadding(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPaddingBytes(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->setPaddingBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 2190
    new-instance v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;-><init>()V

    .line 2193
    sput-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    .line 2194
    const-class v1, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 1714
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 1715
    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->color_:Lcom/google/protobuf/ByteString;

    .line 1716
    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->backgroundColor_:Lcom/google/protobuf/ByteString;

    .line 1717
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->padding_:Ljava/lang/String;

    return-void
.end method

.method private clearBackgroundColor()V
    .registers 2

    .line 1770
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getBackgroundColor()Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->backgroundColor_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private clearCaptionMaxFont()V
    .registers 2

    const/4 v0, 0x0

    .line 1843
    iput v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->captionMaxFont_:F

    return-void
.end method

.method private clearCaptionScaleFactor()V
    .registers 2

    const/4 v0, 0x0

    .line 1869
    iput v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->captionScaleFactor_:F

    return-void
.end method

.method private clearColor()V
    .registers 2

    .line 1743
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getColor()Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->color_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private clearPadding()V
    .registers 2

    .line 1807
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getPadding()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->padding_:Ljava/lang/String;

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 1

    .line 2199
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;
    .registers 1

    .line 1949
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;
    .registers 2

    .line 1952
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1925
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1932
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1888
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1895
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1937
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1944
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1912
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1919
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1875
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1882
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1900
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1907
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;",
            ">;"
        }
    .end annotation

    .line 2205
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setBackgroundColor(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 1761
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1763
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->backgroundColor_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private setCaptionMaxFont(F)V
    .registers 2

    .line 1836
    iput p1, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->captionMaxFont_:F

    return-void
.end method

.method private setCaptionScaleFactor(F)V
    .registers 2

    .line 1862
    iput p1, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->captionScaleFactor_:F

    return-void
.end method

.method private setColor(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 1734
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1736
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->color_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private setPadding(Ljava/lang/String;)V
    .registers 2

    .line 1798
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1800
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->padding_:Ljava/lang/String;

    return-void
.end method

.method private setPaddingBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 1815
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 1816
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->padding_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 2137
    sget-object p2, Lcom/vdocipher/PlaybackInfo$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_5a

    .line 2183
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 2177
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 2162
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 2164
    const-class p2, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    monitor-enter p2

    .line 2165
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 2167
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 2170
    sput-object p1, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->PARSER:Lcom/google/protobuf/Parser;

    .line 2172
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 2159
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object p1

    .line 2145
    :pswitch_36  #0x3
    const-string p1, "color_"

    const-string p2, "backgroundColor_"

    const-string p3, "padding_"

    const-string v0, "captionMaxFont_"

    const-string v1, "captionScaleFactor_"

    filled-new-array {p1, p2, p3, v0, v1}, [Ljava/lang/Object;

    move-result-object p1

    .line 2152
    const-string p2, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0000\u0000\u0001\n\u0002\n\u0003Ȉ\u0004\u0001\u0005\u0001"

    .line 2155
    sget-object p3, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 2142
    :pswitch_4d  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;-><init>(Lcom/vdocipher/PlaybackInfo-IA;)V

    return-object p1

    .line 2139
    :pswitch_53  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;-><init>()V

    return-object p1

    nop

    :pswitch_data_5a
    .packed-switch 0x1
        :pswitch_53  #00000001
        :pswitch_4d  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getBackgroundColor()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 1754
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->backgroundColor_:Lcom/google/protobuf/ByteString;

    return-object v0
.end method

.method public getCaptionMaxFont()F
    .registers 2

    .line 1828
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->captionMaxFont_:F

    return v0
.end method

.method public getCaptionScaleFactor()F
    .registers 2

    .line 1854
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->captionScaleFactor_:F

    return v0
.end method

.method public getColor()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 1727
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->color_:Lcom/google/protobuf/ByteString;

    return-object v0
.end method

.method public getPadding()Ljava/lang/String;
    .registers 2

    .line 1781
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->padding_:Ljava/lang/String;

    return-object v0
.end method

.method public getPaddingBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 1790
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->padding_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method
