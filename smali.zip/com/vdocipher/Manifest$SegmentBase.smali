# classes14.dex

.class public final Lcom/vdocipher/Manifest$SegmentBase;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$SegmentBaseOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "SegmentBase"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$SegmentBase$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/Manifest$SegmentBase;",
        "Lcom/vdocipher/Manifest$SegmentBase$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$SegmentBaseOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

.field public static final INDEXRANGEEND_FIELD_NUMBER:I = 0x2

.field public static final INDEXRANGESTART_FIELD_NUMBER:I = 0x1

.field public static final INITIALIZATION_FIELD_NUMBER:I = 0x5

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$SegmentBase;",
            ">;"
        }
    .end annotation
.end field

.field public static final PRESENTATIONTIMEOFFSET_FIELD_NUMBER:I = 0x4

.field public static final TIMESCALE_FIELD_NUMBER:I = 0x3


# instance fields
.field private bitField0_:I

.field private indexRangeEnd_:I

.field private indexRangeStart_:I

.field private initialization_:Lcom/vdocipher/Manifest$Initialization;

.field private presentationTimeOffset_:I

.field private timescale_:I


# direct methods
.method static bridge synthetic -$$Nest$mclearIndexRangeEnd(Lcom/vdocipher/Manifest$SegmentBase;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentBase;->clearIndexRangeEnd()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearIndexRangeStart(Lcom/vdocipher/Manifest$SegmentBase;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentBase;->clearIndexRangeStart()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearInitialization(Lcom/vdocipher/Manifest$SegmentBase;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentBase;->clearInitialization()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPresentationTimeOffset(Lcom/vdocipher/Manifest$SegmentBase;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentBase;->clearPresentationTimeOffset()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearTimescale(Lcom/vdocipher/Manifest$SegmentBase;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentBase;->clearTimescale()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeInitialization(Lcom/vdocipher/Manifest$SegmentBase;Lcom/vdocipher/Manifest$Initialization;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentBase;->mergeInitialization(Lcom/vdocipher/Manifest$Initialization;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIndexRangeEnd(Lcom/vdocipher/Manifest$SegmentBase;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentBase;->setIndexRangeEnd(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIndexRangeStart(Lcom/vdocipher/Manifest$SegmentBase;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentBase;->setIndexRangeStart(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetInitialization(Lcom/vdocipher/Manifest$SegmentBase;Lcom/vdocipher/Manifest$Initialization;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentBase;->setInitialization(Lcom/vdocipher/Manifest$Initialization;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPresentationTimeOffset(Lcom/vdocipher/Manifest$SegmentBase;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentBase;->setPresentationTimeOffset(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTimescale(Lcom/vdocipher/Manifest$SegmentBase;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentBase;->setTimescale(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$SegmentBase;
    .registers 1

    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 2470
    new-instance v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$SegmentBase;-><init>()V

    .line 2473
    sput-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    .line 2474
    const-class v1, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 1984
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    return-void
.end method

.method private clearIndexRangeEnd()V
    .registers 2

    const/4 v0, 0x0

    .line 2036
    iput v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->indexRangeEnd_:I

    return-void
.end method

.method private clearIndexRangeStart()V
    .registers 2

    const/4 v0, 0x0

    .line 2010
    iput v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->indexRangeStart_:I

    return-void
.end method

.method private clearInitialization()V
    .registers 2

    const/4 v0, 0x0

    .line 2141
    iput-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->initialization_:Lcom/vdocipher/Manifest$Initialization;

    .line 2142
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->bitField0_:I

    and-int/lit8 v0, v0, -0x3

    iput v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->bitField0_:I

    return-void
.end method

.method private clearPresentationTimeOffset()V
    .registers 2

    .line 2095
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->bitField0_:I

    and-int/lit8 v0, v0, -0x2

    iput v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->bitField0_:I

    const/4 v0, 0x0

    .line 2096
    iput v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->presentationTimeOffset_:I

    return-void
.end method

.method private clearTimescale()V
    .registers 2

    const/4 v0, 0x0

    .line 2062
    iput v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->timescale_:I

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/Manifest$SegmentBase;
    .registers 1

    .line 2479
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    return-object v0
.end method

.method private mergeInitialization(Lcom/vdocipher/Manifest$Initialization;)V
    .registers 4

    .line 2128
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2129
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->initialization_:Lcom/vdocipher/Manifest$Initialization;

    if-eqz v0, :cond_22

    .line 2130
    invoke-static {}, Lcom/vdocipher/Manifest$Initialization;->getDefaultInstance()Lcom/vdocipher/Manifest$Initialization;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 2131
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->initialization_:Lcom/vdocipher/Manifest$Initialization;

    .line 2132
    invoke-static {v0}, Lcom/vdocipher/Manifest$Initialization;->newBuilder(Lcom/vdocipher/Manifest$Initialization;)Lcom/vdocipher/Manifest$Initialization$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/Manifest$Initialization$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$Initialization$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$Initialization$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$Initialization;

    iput-object p1, p0, Lcom/vdocipher/Manifest$SegmentBase;->initialization_:Lcom/vdocipher/Manifest$Initialization;

    goto :goto_24

    .line 2134
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/Manifest$SegmentBase;->initialization_:Lcom/vdocipher/Manifest$Initialization;

    .line 2136
    :goto_24
    iget p1, p0, Lcom/vdocipher/Manifest$SegmentBase;->bitField0_:I

    or-int/lit8 p1, p1, 0x2

    iput p1, p0, Lcom/vdocipher/Manifest$SegmentBase;->bitField0_:I

    return-void
.end method

.method public static newBuilder()Lcom/vdocipher/Manifest$SegmentBase$Builder;
    .registers 1

    .line 2222
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentBase;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/Manifest$SegmentBase;)Lcom/vdocipher/Manifest$SegmentBase$Builder;
    .registers 2

    .line 2225
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-virtual {v0, p0}, Lcom/vdocipher/Manifest$SegmentBase;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$SegmentBase;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2198
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p0}, Lcom/vdocipher/Manifest$SegmentBase;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentBase;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentBase;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2205
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/Manifest$SegmentBase;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentBase;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$SegmentBase;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2161
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentBase;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentBase;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2168
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentBase;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/Manifest$SegmentBase;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2210
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentBase;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentBase;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2217
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentBase;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$SegmentBase;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2185
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentBase;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentBase;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2192
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentBase;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/Manifest$SegmentBase;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2148
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentBase;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentBase;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2155
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentBase;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/Manifest$SegmentBase;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2173
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentBase;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentBase;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2180
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentBase;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$SegmentBase;",
            ">;"
        }
    .end annotation

    .line 2485
    sget-object v0, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentBase;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setIndexRangeEnd(I)V
    .registers 2

    .line 2029
    iput p1, p0, Lcom/vdocipher/Manifest$SegmentBase;->indexRangeEnd_:I

    return-void
.end method

.method private setIndexRangeStart(I)V
    .registers 2

    .line 2003
    iput p1, p0, Lcom/vdocipher/Manifest$SegmentBase;->indexRangeStart_:I

    return-void
.end method

.method private setInitialization(Lcom/vdocipher/Manifest$Initialization;)V
    .registers 2

    .line 2119
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2120
    iput-object p1, p0, Lcom/vdocipher/Manifest$SegmentBase;->initialization_:Lcom/vdocipher/Manifest$Initialization;

    .line 2121
    iget p1, p0, Lcom/vdocipher/Manifest$SegmentBase;->bitField0_:I

    or-int/lit8 p1, p1, 0x2

    iput p1, p0, Lcom/vdocipher/Manifest$SegmentBase;->bitField0_:I

    return-void
.end method

.method private setPresentationTimeOffset(I)V
    .registers 3

    .line 2088
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->bitField0_:I

    or-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->bitField0_:I

    .line 2089
    iput p1, p0, Lcom/vdocipher/Manifest$SegmentBase;->presentationTimeOffset_:I

    return-void
.end method

.method private setTimescale(I)V
    .registers 2

    .line 2055
    iput p1, p0, Lcom/vdocipher/Manifest$SegmentBase;->timescale_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 2416
    sget-object p2, Lcom/vdocipher/Manifest$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_5e

    .line 2463
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 2457
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 2442
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/Manifest$SegmentBase;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_33

    .line 2444
    const-class p2, Lcom/vdocipher/Manifest$SegmentBase;

    monitor-enter p2

    .line 2445
    :try_start_20
    sget-object p1, Lcom/vdocipher/Manifest$SegmentBase;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 2447
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 2450
    sput-object p1, Lcom/vdocipher/Manifest$SegmentBase;->PARSER:Lcom/google/protobuf/Parser;

    .line 2452
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception v0

    move-object p1, v0

    monitor-exit p2
    :try_end_32
    .catchall {:try_start_20 .. :try_end_32} :catchall_2f

    throw p1

    :cond_33
    return-object p1

    .line 2439
    :pswitch_34  #0x4
    sget-object p1, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    return-object p1

    .line 2424
    :pswitch_37  #0x3
    const-string v0, "bitField0_"

    const-string v1, "indexRangeStart_"

    const-string v2, "indexRangeEnd_"

    const-string/jumbo v3, "timescale_"

    const-string v4, "presentationTimeOffset_"

    const-string v5, "initialization_"

    filled-new-array/range {v0 .. v5}, [Ljava/lang/Object;

    move-result-object p1

    .line 2432
    const-string p2, "\u0000\u0005\u0000\u0001\u0001\u0005\u0005\u0000\u0000\u0000\u0001\u000b\u0002\u000b\u0003\u000b\u0004ဋ\u0000\u0005ဉ\u0001"

    .line 2435
    sget-object p3, Lcom/vdocipher/Manifest$SegmentBase;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/Manifest$SegmentBase;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 2421
    :pswitch_51  #0x2
    new-instance p1, Lcom/vdocipher/Manifest$SegmentBase$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/Manifest$SegmentBase$Builder;-><init>(Lcom/vdocipher/Manifest-IA;)V

    return-object p1

    .line 2418
    :pswitch_57  #0x1
    new-instance p1, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-direct {p1}, Lcom/vdocipher/Manifest$SegmentBase;-><init>()V

    return-object p1

    nop

    :pswitch_data_5e
    .packed-switch 0x1
        :pswitch_57  #00000001
        :pswitch_51  #00000002
        :pswitch_37  #00000003
        :pswitch_34  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getIndexRangeEnd()I
    .registers 2

    .line 2021
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->indexRangeEnd_:I

    return v0
.end method

.method public getIndexRangeStart()I
    .registers 2

    .line 1995
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->indexRangeStart_:I

    return v0
.end method

.method public getInitialization()Lcom/vdocipher/Manifest$Initialization;
    .registers 2

    .line 2113
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->initialization_:Lcom/vdocipher/Manifest$Initialization;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/Manifest$Initialization;->getDefaultInstance()Lcom/vdocipher/Manifest$Initialization;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getPresentationTimeOffset()I
    .registers 2

    .line 2081
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->presentationTimeOffset_:I

    return v0
.end method

.method public getTimescale()I
    .registers 2

    .line 2047
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->timescale_:I

    return v0
.end method

.method public hasInitialization()Z
    .registers 2

    .line 2106
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->bitField0_:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasPresentationTimeOffset()Z
    .registers 3

    .line 2073
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentBase;->bitField0_:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_7

    return v1

    :cond_7
    const/4 v0, 0x0

    return v0
.end method
