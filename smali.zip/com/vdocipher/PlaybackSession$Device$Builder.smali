# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Device$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$DeviceOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$Device;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$Device;",
        "Lcom/vdocipher/PlaybackSession$Device$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$DeviceOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 3963
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Device;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearBrand()Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 2

    .line 4046
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4047
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$mclearBrand(Lcom/vdocipher/PlaybackSession$Device;)V

    return-object p0
.end method

.method public clearModel()Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 2

    .line 4095
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4096
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$mclearModel(Lcom/vdocipher/PlaybackSession$Device;)V

    return-object p0
.end method

.method public clearSdkSessionId()Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 2

    .line 4242
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4243
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$mclearSdkSessionId(Lcom/vdocipher/PlaybackSession$Device;)V

    return-object p0
.end method

.method public clearSdkVersion()Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 2

    .line 4144
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4145
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$mclearSdkVersion(Lcom/vdocipher/PlaybackSession$Device;)V

    return-object p0
.end method

.method public clearType()Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 2

    .line 4008
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4009
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$mclearType(Lcom/vdocipher/PlaybackSession$Device;)V

    return-object p0
.end method

.method public clearVendor()Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 2

    .line 4193
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4194
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$mclearVendor(Lcom/vdocipher/PlaybackSession$Device;)V

    return-object p0
.end method

.method public getBrand()Ljava/lang/String;
    .registers 2

    .line 4019
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getBrand()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getBrandBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 4028
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getBrandBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getModel()Ljava/lang/String;
    .registers 2

    .line 4068
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getModel()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getModelBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 4077
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getModelBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSdkSessionId()Ljava/lang/String;
    .registers 2

    .line 4215
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getSdkSessionId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getSdkSessionIdBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 4224
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getSdkSessionIdBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSdkVersion()Ljava/lang/String;
    .registers 2

    .line 4117
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getSdkVersion()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getSdkVersionBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 4126
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getSdkVersionBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getType()Lcom/vdocipher/PlaybackSession$DeviceTypes;
    .registers 2

    .line 3991
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getType()Lcom/vdocipher/PlaybackSession$DeviceTypes;

    move-result-object v0

    return-object v0
.end method

.method public getTypeValue()I
    .registers 2

    .line 3973
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getTypeValue()I

    move-result v0

    return v0
.end method

.method public getVendor()Ljava/lang/String;
    .registers 2

    .line 4166
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getVendor()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getVendorBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 4175
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getVendorBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setBrand(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 3

    .line 4037
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4038
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$msetBrand(Lcom/vdocipher/PlaybackSession$Device;Ljava/lang/String;)V

    return-object p0
.end method

.method public setBrandBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 3

    .line 4057
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4058
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$msetBrandBytes(Lcom/vdocipher/PlaybackSession$Device;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setModel(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 3

    .line 4086
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4087
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$msetModel(Lcom/vdocipher/PlaybackSession$Device;Ljava/lang/String;)V

    return-object p0
.end method

.method public setModelBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 3

    .line 4106
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4107
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$msetModelBytes(Lcom/vdocipher/PlaybackSession$Device;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setSdkSessionId(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 3

    .line 4233
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4234
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$msetSdkSessionId(Lcom/vdocipher/PlaybackSession$Device;Ljava/lang/String;)V

    return-object p0
.end method

.method public setSdkSessionIdBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 3

    .line 4253
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4254
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$msetSdkSessionIdBytes(Lcom/vdocipher/PlaybackSession$Device;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setSdkVersion(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 3

    .line 4135
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4136
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$msetSdkVersion(Lcom/vdocipher/PlaybackSession$Device;Ljava/lang/String;)V

    return-object p0
.end method

.method public setSdkVersionBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 3

    .line 4155
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4156
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$msetSdkVersionBytes(Lcom/vdocipher/PlaybackSession$Device;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setType(Lcom/vdocipher/PlaybackSession$DeviceTypes;)Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 3

    .line 3999
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4000
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$msetType(Lcom/vdocipher/PlaybackSession$Device;Lcom/vdocipher/PlaybackSession$DeviceTypes;)V

    return-object p0
.end method

.method public setTypeValue(I)Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 3

    .line 3981
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 3982
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$msetTypeValue(Lcom/vdocipher/PlaybackSession$Device;I)V

    return-object p0
.end method

.method public setVendor(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 3

    .line 4184
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4185
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$msetVendor(Lcom/vdocipher/PlaybackSession$Device;Ljava/lang/String;)V

    return-object p0
.end method

.method public setVendorBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 3

    .line 4204
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Device$Builder;->copyOnWrite()V

    .line 4205
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Device;->-$$Nest$msetVendorBytes(Lcom/vdocipher/PlaybackSession$Device;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
