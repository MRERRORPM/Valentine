# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackSession$NavigatorPropsOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "NavigatorPropsOrBuilder"
.end annotation


# virtual methods
.method public abstract getConcurrency()I
.end method

.method public abstract getDoNotTrack()Z
.end method

.method public abstract getLangaugesKnown()Ljava/lang/String;
.end method

.method public abstract getLangaugesKnownBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getLanguagePreferred()Ljava/lang/String;
.end method

.method public abstract getLanguagePreferredBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getOnline()Z
.end method

.method public abstract getPlatform()Ljava/lang/String;
.end method

.method public abstract getPlatformBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getTouchPoints()I
.end method
