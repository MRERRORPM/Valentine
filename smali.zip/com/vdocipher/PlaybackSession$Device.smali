# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Device;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$DeviceOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Device"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$Device$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$Device;",
        "Lcom/vdocipher/PlaybackSession$Device$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$DeviceOrBuilder;"
    }
.end annotation


# static fields
.field public static final BRAND_FIELD_NUMBER:I = 0x2

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

.field public static final MODEL_FIELD_NUMBER:I = 0x3

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Device;",
            ">;"
        }
    .end annotation
.end field

.field public static final SDKSESSIONID_FIELD_NUMBER:I = 0x6

.field public static final SDKVERSION_FIELD_NUMBER:I = 0x4

.field public static final TYPE_FIELD_NUMBER:I = 0x1

.field public static final VENDOR_FIELD_NUMBER:I = 0x5


# instance fields
.field private brand_:Ljava/lang/String;

.field private model_:Ljava/lang/String;

.field private sdkSessionId_:Ljava/lang/String;

.field private sdkVersion_:Ljava/lang/String;

.field private type_:I

.field private vendor_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$mclearBrand(Lcom/vdocipher/PlaybackSession$Device;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Device;->clearBrand()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearModel(Lcom/vdocipher/PlaybackSession$Device;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Device;->clearModel()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSdkSessionId(Lcom/vdocipher/PlaybackSession$Device;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Device;->clearSdkSessionId()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSdkVersion(Lcom/vdocipher/PlaybackSession$Device;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Device;->clearSdkVersion()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearType(Lcom/vdocipher/PlaybackSession$Device;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Device;->clearType()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearVendor(Lcom/vdocipher/PlaybackSession$Device;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Device;->clearVendor()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetBrand(Lcom/vdocipher/PlaybackSession$Device;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Device;->setBrand(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetBrandBytes(Lcom/vdocipher/PlaybackSession$Device;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Device;->setBrandBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetModel(Lcom/vdocipher/PlaybackSession$Device;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Device;->setModel(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetModelBytes(Lcom/vdocipher/PlaybackSession$Device;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Device;->setModelBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSdkSessionId(Lcom/vdocipher/PlaybackSession$Device;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Device;->setSdkSessionId(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSdkSessionIdBytes(Lcom/vdocipher/PlaybackSession$Device;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Device;->setSdkSessionIdBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSdkVersion(Lcom/vdocipher/PlaybackSession$Device;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Device;->setSdkVersion(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSdkVersionBytes(Lcom/vdocipher/PlaybackSession$Device;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Device;->setSdkVersionBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetType(Lcom/vdocipher/PlaybackSession$Device;Lcom/vdocipher/PlaybackSession$DeviceTypes;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Device;->setType(Lcom/vdocipher/PlaybackSession$DeviceTypes;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTypeValue(Lcom/vdocipher/PlaybackSession$Device;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Device;->setTypeValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVendor(Lcom/vdocipher/PlaybackSession$Device;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Device;->setVendor(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVendorBytes(Lcom/vdocipher/PlaybackSession$Device;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Device;->setVendorBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Device;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 4319
    new-instance v0, Lcom/vdocipher/PlaybackSession$Device;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$Device;-><init>()V

    .line 4322
    sput-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    .line 4323
    const-class v1, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 3586
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 3587
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->brand_:Ljava/lang/String;

    .line 3588
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->model_:Ljava/lang/String;

    .line 3589
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->sdkVersion_:Ljava/lang/String;

    .line 3590
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->vendor_:Ljava/lang/String;

    .line 3591
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->sdkSessionId_:Ljava/lang/String;

    return-void
.end method

.method private clearBrand()V
    .registers 2

    .line 3669
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Device;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Device;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getBrand()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->brand_:Ljava/lang/String;

    return-void
.end method

.method private clearModel()V
    .registers 2

    .line 3716
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Device;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Device;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getModel()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->model_:Ljava/lang/String;

    return-void
.end method

.method private clearSdkSessionId()V
    .registers 2

    .line 3857
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Device;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Device;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getSdkSessionId()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->sdkSessionId_:Ljava/lang/String;

    return-void
.end method

.method private clearSdkVersion()V
    .registers 2

    .line 3763
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Device;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Device;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getSdkVersion()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->sdkVersion_:Ljava/lang/String;

    return-void
.end method

.method private clearType()V
    .registers 2

    const/4 v0, 0x0

    .line 3632
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Device;->type_:I

    return-void
.end method

.method private clearVendor()V
    .registers 2

    .line 3810
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Device;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Device;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getVendor()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->vendor_:Ljava/lang/String;

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$Device;
    .registers 1

    .line 4328
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 1

    .line 3947
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$Device$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$Device;)Lcom/vdocipher/PlaybackSession$Device$Builder;
    .registers 2

    .line 3950
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$Device;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Device$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Device;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3923
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$Device;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Device;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Device;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3930
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$Device;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Device;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Device;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3886
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Device;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Device;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3893
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Device;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$Device;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3935
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Device;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Device;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3942
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Device;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Device;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3910
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Device;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Device;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3917
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Device;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$Device;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3873
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Device;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Device;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3880
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Device;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$Device;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3898
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Device;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Device;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3905
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Device;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Device;",
            ">;"
        }
    .end annotation

    .line 4334
    sget-object v0, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Device;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setBrand(Ljava/lang/String;)V
    .registers 2

    .line 3660
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3662
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Device;->brand_:Ljava/lang/String;

    return-void
.end method

.method private setBrandBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 3677
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Device;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 3678
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Device;->brand_:Ljava/lang/String;

    return-void
.end method

.method private setModel(Ljava/lang/String;)V
    .registers 2

    .line 3707
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3709
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Device;->model_:Ljava/lang/String;

    return-void
.end method

.method private setModelBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 3724
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Device;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 3725
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Device;->model_:Ljava/lang/String;

    return-void
.end method

.method private setSdkSessionId(Ljava/lang/String;)V
    .registers 2

    .line 3848
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3850
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Device;->sdkSessionId_:Ljava/lang/String;

    return-void
.end method

.method private setSdkSessionIdBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 3865
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Device;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 3866
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Device;->sdkSessionId_:Ljava/lang/String;

    return-void
.end method

.method private setSdkVersion(Ljava/lang/String;)V
    .registers 2

    .line 3754
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3756
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Device;->sdkVersion_:Ljava/lang/String;

    return-void
.end method

.method private setSdkVersionBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 3771
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Device;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 3772
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Device;->sdkVersion_:Ljava/lang/String;

    return-void
.end method

.method private setType(Lcom/vdocipher/PlaybackSession$DeviceTypes;)V
    .registers 2

    .line 3624
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$DeviceTypes;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/PlaybackSession$Device;->type_:I

    return-void
.end method

.method private setTypeValue(I)V
    .registers 2

    .line 3617
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Device;->type_:I

    return-void
.end method

.method private setVendor(Ljava/lang/String;)V
    .registers 2

    .line 3801
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3803
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Device;->vendor_:Ljava/lang/String;

    return-void
.end method

.method private setVendorBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 3818
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Device;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 3819
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Device;->vendor_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 4265
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_5e

    .line 4312
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 4306
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 4291
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$Device;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_33

    .line 4293
    const-class p2, Lcom/vdocipher/PlaybackSession$Device;

    monitor-enter p2

    .line 4294
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$Device;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 4296
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 4299
    sput-object p1, Lcom/vdocipher/PlaybackSession$Device;->PARSER:Lcom/google/protobuf/Parser;

    .line 4301
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception v0

    move-object p1, v0

    monitor-exit p2
    :try_end_32
    .catchall {:try_start_20 .. :try_end_32} :catchall_2f

    throw p1

    :cond_33
    return-object p1

    .line 4288
    :pswitch_34  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    return-object p1

    .line 4273
    :pswitch_37  #0x3
    const-string/jumbo v0, "type_"

    const-string v1, "brand_"

    const-string v2, "model_"

    const-string v3, "sdkVersion_"

    const-string/jumbo v4, "vendor_"

    const-string v5, "sdkSessionId_"

    filled-new-array/range {v0 .. v5}, [Ljava/lang/Object;

    move-result-object p1

    .line 4281
    const-string p2, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0000\u0000\u0001\f\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005Ȉ\u0006Ȉ"

    .line 4284
    sget-object p3, Lcom/vdocipher/PlaybackSession$Device;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$Device;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 4270
    :pswitch_52  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$Device$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$Device$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 4267
    :pswitch_58  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$Device;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$Device;-><init>()V

    return-object p1

    :pswitch_data_5e
    .packed-switch 0x1
        :pswitch_58  #00000001
        :pswitch_52  #00000002
        :pswitch_37  #00000003
        :pswitch_34  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getBrand()Ljava/lang/String;
    .registers 2

    .line 3643
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->brand_:Ljava/lang/String;

    return-object v0
.end method

.method public getBrandBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 3652
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->brand_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getModel()Ljava/lang/String;
    .registers 2

    .line 3690
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->model_:Ljava/lang/String;

    return-object v0
.end method

.method public getModelBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 3699
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->model_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSdkSessionId()Ljava/lang/String;
    .registers 2

    .line 3831
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->sdkSessionId_:Ljava/lang/String;

    return-object v0
.end method

.method public getSdkSessionIdBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 3840
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->sdkSessionId_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSdkVersion()Ljava/lang/String;
    .registers 2

    .line 3737
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->sdkVersion_:Ljava/lang/String;

    return-object v0
.end method

.method public getSdkVersionBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 3746
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->sdkVersion_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getType()Lcom/vdocipher/PlaybackSession$DeviceTypes;
    .registers 2

    .line 3609
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Device;->type_:I

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$DeviceTypes;->forNumber(I)Lcom/vdocipher/PlaybackSession$DeviceTypes;

    move-result-object v0

    if-nez v0, :cond_a

    .line 3610
    sget-object v0, Lcom/vdocipher/PlaybackSession$DeviceTypes;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$DeviceTypes;

    :cond_a
    return-object v0
.end method

.method public getTypeValue()I
    .registers 2

    .line 3601
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Device;->type_:I

    return v0
.end method

.method public getVendor()Ljava/lang/String;
    .registers 2

    .line 3784
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->vendor_:Ljava/lang/String;

    return-object v0
.end method

.method public getVendorBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 3793
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Device;->vendor_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method
