# classes14.dex

.class final Lcom/vdocipher/PlaybackSession$HDCPLevel$HDCPLevelVerifier;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumVerifier;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$HDCPLevel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "HDCPLevelVerifier"
.end annotation


# static fields
.field static final INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 962
    new-instance v0, Lcom/vdocipher/PlaybackSession$HDCPLevel$HDCPLevelVerifier;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$HDCPLevel$HDCPLevelVerifier;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackSession$HDCPLevel$HDCPLevelVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 960
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public isInRange(I)Z
    .registers 2

    .line 965
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$HDCPLevel;->forNumber(I)Lcom/vdocipher/PlaybackSession$HDCPLevel;

    move-result-object p1

    if-eqz p1, :cond_8

    const/4 p1, 0x1

    return p1

    :cond_8
    const/4 p1, 0x0

    return p1
.end method
