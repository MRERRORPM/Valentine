# classes14.dex

.class public interface abstract Lcom/vdocipher/Manifest$RepresentationOrBuilder;
.super Ljava/lang/Object;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "RepresentationOrBuilder"
.end annotation


# virtual methods
.method public abstract getAudioChannelConfiguration(I)Lcom/vdocipher/Manifest$AudioChannelConfiguration;
.end method

.method public abstract getAudioChannelConfigurationCount()I
.end method

.method public abstract getAudioChannelConfigurationList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$AudioChannelConfiguration;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getAudioSamplingRate()I
.end method

.method public abstract getBandwidth()I
.end method

.method public abstract getBaseUrl()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getCodecs()Ljava/lang/String;
.end method

.method public abstract getCodecsBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getHeight()I
.end method

.method public abstract getId()I
.end method

.method public abstract getMimeType()Ljava/lang/String;
.end method

.method public abstract getMimeTypeBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getSar()Lcom/vdocipher/Manifest$AspectRatio;
.end method

.method public abstract getSegmentBase(I)Lcom/vdocipher/Manifest$SegmentBase;
.end method

.method public abstract getSegmentBaseCount()I
.end method

.method public abstract getSegmentBaseList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$SegmentBase;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getSegmentTemplate(I)Lcom/vdocipher/Manifest$SegmentTemplate;
.end method

.method public abstract getSegmentTemplateCount()I
.end method

.method public abstract getSegmentTemplateList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$SegmentTemplate;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getWidth()I
.end method

.method public abstract hasAudioSamplingRate()Z
.end method

.method public abstract hasCodecs()Z
.end method

.method public abstract hasHeight()Z
.end method

.method public abstract hasSar()Z
.end method

.method public abstract hasWidth()Z
.end method
