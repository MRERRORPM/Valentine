# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$FPS$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$FPSOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$FPS;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackInfo$FPS;",
        "Lcom/vdocipher/PlaybackInfo$FPS$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$FPSOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 8283
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$FPS;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackInfo-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public addAllFallbackLicenseServers(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$FPS$Builder;"
        }
    .end annotation

    .line 8508
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->copyOnWrite()V

    .line 8509
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$maddAllFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$FPS;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addFallbackLicenseServers(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 3

    .line 8497
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->copyOnWrite()V

    .line 8498
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$maddFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$FPS;Ljava/lang/String;)V

    return-object p0
.end method

.method public addFallbackLicenseServersBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 3

    .line 8528
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->copyOnWrite()V

    .line 8529
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$maddFallbackLicenseServersBytes(Lcom/vdocipher/PlaybackInfo$FPS;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public clearAssetId()Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 2

    .line 8387
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->copyOnWrite()V

    .line 8388
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$mclearAssetId(Lcom/vdocipher/PlaybackInfo$FPS;)V

    return-object p0
.end method

.method public clearCertificate()Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 2

    .line 8425
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->copyOnWrite()V

    .line 8426
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$mclearCertificate(Lcom/vdocipher/PlaybackInfo$FPS;)V

    return-object p0
.end method

.method public clearFallbackLicenseServers()Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 2

    .line 8517
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->copyOnWrite()V

    .line 8518
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$mclearFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$FPS;)V

    return-object p0
.end method

.method public clearLicenseServer()Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 2

    .line 8348
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->copyOnWrite()V

    .line 8349
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$mclearLicenseServer(Lcom/vdocipher/PlaybackInfo$FPS;)V

    return-object p0
.end method

.method public clearManifest()Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 2

    .line 8310
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->copyOnWrite()V

    .line 8311
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$mclearManifest(Lcom/vdocipher/PlaybackInfo$FPS;)V

    return-object p0
.end method

.method public getAssetId()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8370
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->getAssetId()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getCertificate()Ljava/lang/String;
    .registers 2

    .line 8398
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->getCertificate()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getCertificateBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8407
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->getCertificateBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getFallbackLicenseServers(I)Ljava/lang/String;
    .registers 3

    .line 8466
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->getFallbackLicenseServers(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public getFallbackLicenseServersBytes(I)Lcom/google/protobuf/ByteString;
    .registers 3

    .line 8476
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->getFallbackLicenseServersBytes(I)Lcom/google/protobuf/ByteString;

    move-result-object p1

    return-object p1
.end method

.method public getFallbackLicenseServersCount()I
    .registers 2

    .line 8457
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->getFallbackLicenseServersCount()I

    move-result v0

    return v0
.end method

.method public getFallbackLicenseServersList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 8448
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    .line 8449
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->getFallbackLicenseServersList()Ljava/util/List;

    move-result-object v0

    .line 8448
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getLicenseServer()Ljava/lang/String;
    .registers 2

    .line 8321
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->getLicenseServer()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getLicenseServerBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8330
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->getLicenseServerBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getManifest()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8293
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->getManifest()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setAssetId(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 3

    .line 8378
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->copyOnWrite()V

    .line 8379
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$msetAssetId(Lcom/vdocipher/PlaybackInfo$FPS;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setCertificate(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 3

    .line 8416
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->copyOnWrite()V

    .line 8417
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$msetCertificate(Lcom/vdocipher/PlaybackInfo$FPS;Ljava/lang/String;)V

    return-object p0
.end method

.method public setCertificateBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 3

    .line 8436
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->copyOnWrite()V

    .line 8437
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$msetCertificateBytes(Lcom/vdocipher/PlaybackInfo$FPS;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setFallbackLicenseServers(ILjava/lang/String;)Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 4

    .line 8486
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->copyOnWrite()V

    .line 8487
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$msetFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$FPS;ILjava/lang/String;)V

    return-object p0
.end method

.method public setLicenseServer(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 3

    .line 8339
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->copyOnWrite()V

    .line 8340
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$msetLicenseServer(Lcom/vdocipher/PlaybackInfo$FPS;Ljava/lang/String;)V

    return-object p0
.end method

.method public setLicenseServerBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 3

    .line 8359
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->copyOnWrite()V

    .line 8360
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$msetLicenseServerBytes(Lcom/vdocipher/PlaybackInfo$FPS;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setManifest(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$FPS$Builder;
    .registers 3

    .line 8301
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->copyOnWrite()V

    .line 8302
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$FPS;->-$$Nest$msetManifest(Lcom/vdocipher/PlaybackInfo$FPS;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
