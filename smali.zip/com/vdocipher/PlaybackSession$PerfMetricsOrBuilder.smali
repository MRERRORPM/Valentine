# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackSession$PerfMetricsOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "PerfMetricsOrBuilder"
.end annotation


# virtual methods
.method public abstract getAudioUnderrunRate()D
.end method

.method public abstract getDroppedFramesRate()D
.end method

.method public abstract getJoinTime()I
.end method

.method public abstract getLicenseLoadDuration()I
.end method

.method public abstract getMaxRebufferTime()I
.end method

.method public abstract getMeanBandwidth()D
.end method

.method public abstract getMeanSeekTime()I
.end method

.method public abstract getMetaLoadDuration()I
.end method

.method public abstract getRebufferCount()I
.end method

.method public abstract getRebufferRate()D
.end method

.method public abstract getRebufferTimeRatio()D
.end method
