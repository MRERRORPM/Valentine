# classes14.dex

.class public interface abstract Lcom/vdocipher/Manifest$SegmentTemplateOrBuilder;
.super Ljava/lang/Object;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "SegmentTemplateOrBuilder"
.end annotation


# virtual methods
.method public abstract getDuration()I
.end method

.method public abstract getIndexRangeExact()Z
.end method

.method public abstract getInitialization()Ljava/lang/String;
.end method

.method public abstract getInitializationBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getMedia()Ljava/lang/String;
.end method

.method public abstract getMediaBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getPresentationTimeOffset()I
.end method

.method public abstract getSegmentTimeline()Lcom/vdocipher/Manifest$SegmentTimeline;
.end method

.method public abstract getTimescale()I
.end method

.method public abstract hasSegmentTimeline()Z
.end method
