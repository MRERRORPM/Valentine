# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$TrackCount;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$TrackCountOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "TrackCount"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$TrackCount$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$TrackCount;",
        "Lcom/vdocipher/PlaybackSession$TrackCount$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$TrackCountOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$TrackCount;",
            ">;"
        }
    .end annotation
.end field

.field public static final VIDEO_FIELD_NUMBER:I = 0x1


# instance fields
.field private video_:I


# direct methods
.method static bridge synthetic -$$Nest$mclearVideo(Lcom/vdocipher/PlaybackSession$TrackCount;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$TrackCount;->clearVideo()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVideo(Lcom/vdocipher/PlaybackSession$TrackCount;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$TrackCount;->setVideo(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 8511
    new-instance v0, Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$TrackCount;-><init>()V

    .line 8514
    sput-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    .line 8515
    const-class v1, Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 8303
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    return-void
.end method

.method private clearVideo()V
    .registers 2

    const/4 v0, 0x0

    .line 8328
    iput v0, p0, Lcom/vdocipher/PlaybackSession$TrackCount;->video_:I

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 1

    .line 8520
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$TrackCount$Builder;
    .registers 1

    .line 8408
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$TrackCount;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackCount$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$TrackCount;)Lcom/vdocipher/PlaybackSession$TrackCount$Builder;
    .registers 2

    .line 8411
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$TrackCount;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackCount$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8384
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$TrackCount;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackCount;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8391
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$TrackCount;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackCount;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8347
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackCount;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8354
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackCount;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8396
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackCount;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8403
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackCount;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8371
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackCount;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8378
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackCount;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8334
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackCount;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8341
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackCount;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8359
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackCount;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8366
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackCount;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$TrackCount;",
            ">;"
        }
    .end annotation

    .line 8526
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$TrackCount;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setVideo(I)V
    .registers 2

    .line 8321
    iput p1, p0, Lcom/vdocipher/PlaybackSession$TrackCount;->video_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 8463
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_52

    .line 8504
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 8498
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 8483
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$TrackCount;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 8485
    const-class p2, Lcom/vdocipher/PlaybackSession$TrackCount;

    monitor-enter p2

    .line 8486
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$TrackCount;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 8488
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 8491
    sput-object p1, Lcom/vdocipher/PlaybackSession$TrackCount;->PARSER:Lcom/google/protobuf/Parser;

    .line 8493
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 8480
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    return-object p1

    .line 8471
    :pswitch_36  #0x3
    const-string/jumbo p1, "video_"

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    .line 8474
    const-string p2, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u000b"

    .line 8476
    sget-object p3, Lcom/vdocipher/PlaybackSession$TrackCount;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$TrackCount;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 8468
    :pswitch_46  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$TrackCount$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$TrackCount$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 8465
    :pswitch_4c  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$TrackCount;-><init>()V

    return-object p1

    :pswitch_data_52
    .packed-switch 0x1
        :pswitch_4c  #00000001
        :pswitch_46  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getVideo()I
    .registers 2

    .line 8313
    iget v0, p0, Lcom/vdocipher/PlaybackSession$TrackCount;->video_:I

    return v0
.end method
