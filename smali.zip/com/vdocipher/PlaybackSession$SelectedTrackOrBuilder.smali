# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackSession$SelectedTrackOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "SelectedTrackOrBuilder"
.end annotation


# virtual methods
.method public abstract getAudio()Lcom/vdocipher/PlaybackSession$TrackAudio;
.end method

.method public abstract getVideo()Lcom/vdocipher/PlaybackSession$TrackVideo;
.end method

.method public abstract hasAudio()Z
.end method

.method public abstract hasVideo()Z
.end method
