# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$PlaybackSessionTableOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "PlaybackSessionTable"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;",
        "Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$PlaybackSessionTableOrBuilder;"
    }
.end annotation


# static fields
.field public static final ANDROID_FIELD_NUMBER:I = 0x18

.field public static final BEATS_FIELD_NUMBER:I = 0x13

.field public static final CAPTIONSEARCH_FIELD_NUMBER:I = 0x10

.field public static final COVERAGE_FIELD_NUMBER:I = 0xd

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

.field public static final DEVICE_FIELD_NUMBER:I = 0xa

.field public static final DIMENSIONS_FIELD_NUMBER:I = 0x4

.field public static final DOWNLOADLOCATION_FIELD_NUMBER:I = 0x16

.field public static final EMBEDINFO_FIELD_NUMBER:I = 0x3

.field public static final ERROR_FIELD_NUMBER:I = 0x14

.field public static final EVENTS_FIELD_NUMBER:I = 0xe

.field public static final ISUIENABLED_FIELD_NUMBER:I = 0x11

.field public static final MEDIA_FIELD_NUMBER:I = 0x9

.field public static final NAVIGATORPROPS_FIELD_NUMBER:I = 0xc

.field public static final NAVIGATOR_FIELD_NUMBER:I = 0xb

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;",
            ">;"
        }
    .end annotation
.end field

.field public static final PLATFORM_FIELD_NUMBER:I = 0x7

.field public static final PLAYERPERF_FIELD_NUMBER:I = 0xf

.field public static final REFURL_FIELD_NUMBER:I = 0x5

.field public static final RESUMED_FIELD_NUMBER:I = 0x17

.field public static final SELECTEDTRACK_FIELD_NUMBER:I = 0x15

.field public static final SESSIONINITTIME_FIELD_NUMBER:I = 0x2

.field public static final SESSION_FIELD_NUMBER:I = 0x1

.field public static final TECH_FIELD_NUMBER:I = 0x6

.field public static final TOOLKIT_FIELD_NUMBER:I = 0x1a

.field public static final TRACKCOUNT_FIELD_NUMBER:I = 0x12

.field public static final VIEWER_FIELD_NUMBER:I = 0x8

.field public static final WATERMARKCOUNT_FIELD_NUMBER:I = 0x19

.field public static final WIDEVINECDM_FIELD_NUMBER:I = 0x1b


# instance fields
.field private android_:Lcom/vdocipher/PlaybackSession$Android;

.field private beats_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/PlaybackSession$Beat;",
            ">;"
        }
    .end annotation
.end field

.field private bitField0_:I

.field private captionSearch_:I

.field private coverage_:Lcom/vdocipher/PlaybackSession$Coverage;

.field private device_:Lcom/vdocipher/PlaybackSession$Device;

.field private dimensions_:Lcom/vdocipher/PlaybackSession$Dimension;

.field private downloadLocation_:Ljava/lang/String;

.field private embedInfo_:Lcom/vdocipher/PlaybackSession$EmbedInfo;

.field private error_:Lcom/vdocipher/PlaybackSession$Error;

.field private events_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/PlaybackSession$Event;",
            ">;"
        }
    .end annotation
.end field

.field private isUIEnabled_:Z

.field private media_:Lcom/vdocipher/PlaybackSession$Media;

.field private navigatorProps_:Lcom/vdocipher/PlaybackSession$NavigatorProps;

.field private navigator_:Ljava/lang/String;

.field private platform_:Ljava/lang/String;

.field private playerPerf_:Lcom/vdocipher/PlaybackSession$PerfMetrics;

.field private refUrl_:Ljava/lang/String;

.field private resumed_:Lcom/vdocipher/PlaybackSession$PlaybackResume;

.field private selectedTrack_:Lcom/vdocipher/PlaybackSession$SelectedTrack;

.field private sessionInitTime_:Ljava/lang/String;

.field private session_:Ljava/lang/String;

.field private tech_:I

.field private toolkit_:Lcom/vdocipher/PlaybackSession$Toolkit;

.field private trackCount_:Lcom/vdocipher/PlaybackSession$TrackCount;

.field private viewer_:Ljava/lang/String;

.field private watermarkCount_:I

.field private widevineCDM_:Lcom/vdocipher/PlaybackSession$WidevineCDM;


# direct methods
.method static bridge synthetic -$$Nest$maddAllBeats(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->addAllBeats(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllEvents(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->addAllEvents(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddBeats(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;ILcom/vdocipher/PlaybackSession$Beat;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->addBeats(ILcom/vdocipher/PlaybackSession$Beat;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddBeats(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->addBeats(Lcom/vdocipher/PlaybackSession$Beat;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddEvents(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;ILcom/vdocipher/PlaybackSession$Event;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->addEvents(ILcom/vdocipher/PlaybackSession$Event;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddEvents(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Event;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->addEvents(Lcom/vdocipher/PlaybackSession$Event;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearAndroid(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearAndroid()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearBeats(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearBeats()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearCaptionSearch(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearCaptionSearch()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearCoverage(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearCoverage()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearDevice(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearDevice()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearDimensions(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearDimensions()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearDownloadLocation(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearDownloadLocation()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEmbedInfo(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearEmbedInfo()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearError(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearError()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEvents(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearEvents()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearIsUIEnabled(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearIsUIEnabled()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMedia(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearMedia()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearNavigator(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearNavigator()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearNavigatorProps(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearNavigatorProps()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPlatform(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearPlatform()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPlayerPerf(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearPlayerPerf()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearRefUrl(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearRefUrl()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearResumed(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearResumed()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSelectedTrack(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearSelectedTrack()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSession(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearSession()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSessionInitTime(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearSessionInitTime()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearTech(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearTech()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearToolkit(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearToolkit()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearTrackCount(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearTrackCount()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearViewer(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearViewer()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearWatermarkCount(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearWatermarkCount()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearWidevineCDM(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->clearWidevineCDM()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeAndroid(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->mergeAndroid(Lcom/vdocipher/PlaybackSession$Android;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeCoverage(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Coverage;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->mergeCoverage(Lcom/vdocipher/PlaybackSession$Coverage;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeDevice(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Device;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->mergeDevice(Lcom/vdocipher/PlaybackSession$Device;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeDimensions(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Dimension;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->mergeDimensions(Lcom/vdocipher/PlaybackSession$Dimension;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeEmbedInfo(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$EmbedInfo;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->mergeEmbedInfo(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeError(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Error;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->mergeError(Lcom/vdocipher/PlaybackSession$Error;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeMedia(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Media;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->mergeMedia(Lcom/vdocipher/PlaybackSession$Media;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeNavigatorProps(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$NavigatorProps;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->mergeNavigatorProps(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergePlayerPerf(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$PerfMetrics;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->mergePlayerPerf(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeResumed(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$PlaybackResume;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->mergeResumed(Lcom/vdocipher/PlaybackSession$PlaybackResume;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeSelectedTrack(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$SelectedTrack;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->mergeSelectedTrack(Lcom/vdocipher/PlaybackSession$SelectedTrack;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeToolkit(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Toolkit;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->mergeToolkit(Lcom/vdocipher/PlaybackSession$Toolkit;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeTrackCount(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$TrackCount;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->mergeTrackCount(Lcom/vdocipher/PlaybackSession$TrackCount;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeWidevineCDM(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$WidevineCDM;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->mergeWidevineCDM(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveBeats(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->removeBeats(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveEvents(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->removeEvents(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAndroid(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setAndroid(Lcom/vdocipher/PlaybackSession$Android;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetBeats(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;ILcom/vdocipher/PlaybackSession$Beat;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setBeats(ILcom/vdocipher/PlaybackSession$Beat;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCaptionSearch(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$CaptionSearch;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setCaptionSearch(Lcom/vdocipher/PlaybackSession$CaptionSearch;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCaptionSearchValue(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setCaptionSearchValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCoverage(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Coverage;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setCoverage(Lcom/vdocipher/PlaybackSession$Coverage;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDevice(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Device;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setDevice(Lcom/vdocipher/PlaybackSession$Device;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDimensions(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Dimension;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setDimensions(Lcom/vdocipher/PlaybackSession$Dimension;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDownloadLocation(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setDownloadLocation(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDownloadLocationBytes(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setDownloadLocationBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEmbedInfo(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$EmbedInfo;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setEmbedInfo(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetError(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Error;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setError(Lcom/vdocipher/PlaybackSession$Error;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEvents(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;ILcom/vdocipher/PlaybackSession$Event;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setEvents(ILcom/vdocipher/PlaybackSession$Event;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIsUIEnabled(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setIsUIEnabled(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMedia(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Media;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setMedia(Lcom/vdocipher/PlaybackSession$Media;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetNavigator(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setNavigator(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetNavigatorBytes(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setNavigatorBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetNavigatorProps(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$NavigatorProps;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setNavigatorProps(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPlatform(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setPlatform(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPlatformBytes(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setPlatformBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPlayerPerf(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$PerfMetrics;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setPlayerPerf(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetRefUrl(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setRefUrl(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetRefUrlBytes(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setRefUrlBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetResumed(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$PlaybackResume;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setResumed(Lcom/vdocipher/PlaybackSession$PlaybackResume;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSelectedTrack(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$SelectedTrack;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setSelectedTrack(Lcom/vdocipher/PlaybackSession$SelectedTrack;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSession(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setSession(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSessionBytes(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setSessionBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSessionInitTime(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setSessionInitTime(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSessionInitTimeBytes(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setSessionInitTimeBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTech(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setTech(Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTechValue(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setTechValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetToolkit(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Toolkit;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setToolkit(Lcom/vdocipher/PlaybackSession$Toolkit;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTrackCount(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$TrackCount;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setTrackCount(Lcom/vdocipher/PlaybackSession$TrackCount;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetViewer(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setViewer(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetViewerBytes(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setViewerBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetWatermarkCount(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setWatermarkCount(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetWidevineCDM(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$WidevineCDM;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->setWidevineCDM(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 16867
    new-instance v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;-><init>()V

    .line 16870
    sput-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    .line 16871
    const-class v1, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 3

    .line 14019
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 14020
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->session_:Ljava/lang/String;

    .line 14021
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->sessionInitTime_:Ljava/lang/String;

    .line 14022
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->refUrl_:Ljava/lang/String;

    .line 14023
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->platform_:Ljava/lang/String;

    .line 14024
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->viewer_:Ljava/lang/String;

    .line 14025
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->navigator_:Ljava/lang/String;

    .line 14026
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v1

    iput-object v1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->events_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 14027
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v1

    iput-object v1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->beats_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 14028
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->downloadLocation_:Ljava/lang/String;

    return-void
.end method

.method private addAllBeats(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackSession$Beat;",
            ">;)V"
        }
    .end annotation

    .line 14961
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->ensureBeatsIsMutable()V

    .line 14962
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->beats_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAllEvents(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackSession$Event;",
            ">;)V"
        }
    .end annotation

    .line 14707
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->ensureEventsIsMutable()V

    .line 14708
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->events_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addBeats(ILcom/vdocipher/PlaybackSession$Beat;)V
    .registers 4

    .line 14952
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14953
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->ensureBeatsIsMutable()V

    .line 14954
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->beats_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addBeats(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 3

    .line 14943
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14944
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->ensureBeatsIsMutable()V

    .line 14945
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->beats_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addEvents(ILcom/vdocipher/PlaybackSession$Event;)V
    .registers 4

    .line 14698
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14699
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->ensureEventsIsMutable()V

    .line 14700
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->events_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addEvents(Lcom/vdocipher/PlaybackSession$Event;)V
    .registers 3

    .line 14689
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14690
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->ensureEventsIsMutable()V

    .line 14691
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->events_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private clearAndroid()V
    .registers 2

    const/4 v0, 0x0

    .line 15206
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->android_:Lcom/vdocipher/PlaybackSession$Android;

    .line 15207
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit16 v0, v0, -0x801

    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private clearBeats()V
    .registers 2

    .line 14969
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->beats_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearCaptionSearch()V
    .registers 2

    const/4 v0, 0x0

    .line 14810
    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->captionSearch_:I

    return-void
.end method

.method private clearCoverage()V
    .registers 2

    const/4 v0, 0x0

    .line 14627
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->coverage_:Lcom/vdocipher/PlaybackSession$Coverage;

    .line 14628
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x21

    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private clearDevice()V
    .registers 2

    const/4 v0, 0x0

    .line 14488
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->device_:Lcom/vdocipher/PlaybackSession$Device;

    .line 14489
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x9

    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private clearDimensions()V
    .registers 2

    const/4 v0, 0x0

    .line 14213
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->dimensions_:Lcom/vdocipher/PlaybackSession$Dimension;

    .line 14214
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x3

    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private clearDownloadLocation()V
    .registers 2

    .line 15105
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getDownloadLocation()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->downloadLocation_:Ljava/lang/String;

    return-void
.end method

.method private clearEmbedInfo()V
    .registers 2

    const/4 v0, 0x0

    .line 14167
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->embedInfo_:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    .line 14168
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x2

    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private clearError()V
    .registers 2

    const/4 v0, 0x0

    .line 15021
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->error_:Lcom/vdocipher/PlaybackSession$Error;

    .line 15022
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit16 v0, v0, -0x101

    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private clearEvents()V
    .registers 2

    .line 14715
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->events_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearIsUIEnabled()V
    .registers 2

    const/4 v0, 0x0

    .line 14836
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->isUIEnabled_:Z

    return-void
.end method

.method private clearMedia()V
    .registers 2

    const/4 v0, 0x0

    .line 14442
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->media_:Lcom/vdocipher/PlaybackSession$Media;

    .line 14443
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x5

    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private clearNavigator()V
    .registers 2

    .line 14526
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getNavigator()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->navigator_:Ljava/lang/String;

    return-void
.end method

.method private clearNavigatorProps()V
    .registers 2

    const/4 v0, 0x0

    .line 14581
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->navigatorProps_:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    .line 14582
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x11

    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private clearPlatform()V
    .registers 2

    .line 14340
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getPlatform()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->platform_:Ljava/lang/String;

    return-void
.end method

.method private clearPlayerPerf()V
    .registers 2

    const/4 v0, 0x0

    .line 14767
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->playerPerf_:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    .line 14768
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x41

    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private clearRefUrl()V
    .registers 2

    .line 14251
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getRefUrl()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->refUrl_:Ljava/lang/String;

    return-void
.end method

.method private clearResumed()V
    .registers 2

    const/4 v0, 0x0

    .line 15160
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->resumed_:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    .line 15161
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit16 v0, v0, -0x401

    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private clearSelectedTrack()V
    .registers 2

    const/4 v0, 0x0

    .line 15067
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->selectedTrack_:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    .line 15068
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit16 v0, v0, -0x201

    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private clearSession()V
    .registers 2

    .line 14065
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getSession()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->session_:Ljava/lang/String;

    return-void
.end method

.method private clearSessionInitTime()V
    .registers 2

    .line 14112
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getSessionInitTime()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->sessionInitTime_:Ljava/lang/String;

    return-void
.end method

.method private clearTech()V
    .registers 2

    const/4 v0, 0x0

    .line 14303
    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->tech_:I

    return-void
.end method

.method private clearToolkit()V
    .registers 2

    const/4 v0, 0x0

    .line 15278
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->toolkit_:Lcom/vdocipher/PlaybackSession$Toolkit;

    .line 15279
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit16 v0, v0, -0x1001

    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private clearTrackCount()V
    .registers 2

    const/4 v0, 0x0

    .line 14881
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->trackCount_:Lcom/vdocipher/PlaybackSession$TrackCount;

    .line 14882
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit16 v0, v0, -0x81

    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private clearViewer()V
    .registers 2

    .line 14387
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getViewer()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->viewer_:Ljava/lang/String;

    return-void
.end method

.method private clearWatermarkCount()V
    .registers 2

    const/4 v0, 0x0

    .line 15233
    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->watermarkCount_:I

    return-void
.end method

.method private clearWidevineCDM()V
    .registers 2

    const/4 v0, 0x0

    .line 15324
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->widevineCDM_:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    .line 15325
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit16 v0, v0, -0x2001

    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private ensureBeatsIsMutable()V
    .registers 3

    .line 14923
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->beats_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 14924
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 14926
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->beats_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method private ensureEventsIsMutable()V
    .registers 3

    .line 14669
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->events_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 14670
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 14672
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->events_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
    .registers 1

    .line 16876
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    return-object v0
.end method

.method private mergeAndroid(Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 4

    .line 15193
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15194
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->android_:Lcom/vdocipher/PlaybackSession$Android;

    if-eqz v0, :cond_22

    .line 15195
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Android;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Android;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 15196
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->android_:Lcom/vdocipher/PlaybackSession$Android;

    .line 15197
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Android;->newBuilder(Lcom/vdocipher/PlaybackSession$Android;)Lcom/vdocipher/PlaybackSession$Android$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$Android$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Android$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Android$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Android;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->android_:Lcom/vdocipher/PlaybackSession$Android;

    goto :goto_24

    .line 15199
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->android_:Lcom/vdocipher/PlaybackSession$Android;

    .line 15201
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x800

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private mergeCoverage(Lcom/vdocipher/PlaybackSession$Coverage;)V
    .registers 4

    .line 14614
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14615
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->coverage_:Lcom/vdocipher/PlaybackSession$Coverage;

    if-eqz v0, :cond_22

    .line 14616
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Coverage;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Coverage;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 14617
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->coverage_:Lcom/vdocipher/PlaybackSession$Coverage;

    .line 14618
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Coverage;->newBuilder(Lcom/vdocipher/PlaybackSession$Coverage;)Lcom/vdocipher/PlaybackSession$Coverage$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Coverage$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Coverage;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->coverage_:Lcom/vdocipher/PlaybackSession$Coverage;

    goto :goto_24

    .line 14620
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->coverage_:Lcom/vdocipher/PlaybackSession$Coverage;

    .line 14622
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x20

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private mergeDevice(Lcom/vdocipher/PlaybackSession$Device;)V
    .registers 4

    .line 14475
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14476
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->device_:Lcom/vdocipher/PlaybackSession$Device;

    if-eqz v0, :cond_22

    .line 14477
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Device;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Device;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 14478
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->device_:Lcom/vdocipher/PlaybackSession$Device;

    .line 14479
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Device;->newBuilder(Lcom/vdocipher/PlaybackSession$Device;)Lcom/vdocipher/PlaybackSession$Device$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$Device$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Device$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Device$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Device;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->device_:Lcom/vdocipher/PlaybackSession$Device;

    goto :goto_24

    .line 14481
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->device_:Lcom/vdocipher/PlaybackSession$Device;

    .line 14483
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x8

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private mergeDimensions(Lcom/vdocipher/PlaybackSession$Dimension;)V
    .registers 4

    .line 14200
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14201
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->dimensions_:Lcom/vdocipher/PlaybackSession$Dimension;

    if-eqz v0, :cond_22

    .line 14202
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Dimension;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Dimension;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 14203
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->dimensions_:Lcom/vdocipher/PlaybackSession$Dimension;

    .line 14204
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->newBuilder(Lcom/vdocipher/PlaybackSession$Dimension;)Lcom/vdocipher/PlaybackSession$Dimension$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Dimension$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Dimension;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->dimensions_:Lcom/vdocipher/PlaybackSession$Dimension;

    goto :goto_24

    .line 14206
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->dimensions_:Lcom/vdocipher/PlaybackSession$Dimension;

    .line 14208
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x2

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private mergeEmbedInfo(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V
    .registers 4

    .line 14154
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14155
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->embedInfo_:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    if-eqz v0, :cond_22

    .line 14156
    invoke-static {}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$EmbedInfo;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 14157
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->embedInfo_:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    .line 14158
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->newBuilder(Lcom/vdocipher/PlaybackSession$EmbedInfo;)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->embedInfo_:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    goto :goto_24

    .line 14160
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->embedInfo_:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    .line 14162
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private mergeError(Lcom/vdocipher/PlaybackSession$Error;)V
    .registers 4

    .line 15008
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15009
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->error_:Lcom/vdocipher/PlaybackSession$Error;

    if-eqz v0, :cond_22

    .line 15010
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Error;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Error;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 15011
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->error_:Lcom/vdocipher/PlaybackSession$Error;

    .line 15012
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Error;->newBuilder(Lcom/vdocipher/PlaybackSession$Error;)Lcom/vdocipher/PlaybackSession$Error$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$Error$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Error$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Error$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Error;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->error_:Lcom/vdocipher/PlaybackSession$Error;

    goto :goto_24

    .line 15014
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->error_:Lcom/vdocipher/PlaybackSession$Error;

    .line 15016
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x100

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private mergeMedia(Lcom/vdocipher/PlaybackSession$Media;)V
    .registers 4

    .line 14429
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14430
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->media_:Lcom/vdocipher/PlaybackSession$Media;

    if-eqz v0, :cond_22

    .line 14431
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Media;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Media;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 14432
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->media_:Lcom/vdocipher/PlaybackSession$Media;

    .line 14433
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Media;->newBuilder(Lcom/vdocipher/PlaybackSession$Media;)Lcom/vdocipher/PlaybackSession$Media$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$Media$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Media$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Media$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Media;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->media_:Lcom/vdocipher/PlaybackSession$Media;

    goto :goto_24

    .line 14435
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->media_:Lcom/vdocipher/PlaybackSession$Media;

    .line 14437
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x4

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private mergeNavigatorProps(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V
    .registers 4

    .line 14568
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14569
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->navigatorProps_:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    if-eqz v0, :cond_22

    .line 14570
    invoke-static {}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$NavigatorProps;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 14571
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->navigatorProps_:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    .line 14572
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->newBuilder(Lcom/vdocipher/PlaybackSession$NavigatorProps;)Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->navigatorProps_:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    goto :goto_24

    .line 14574
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->navigatorProps_:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    .line 14576
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x10

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private mergePlayerPerf(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V
    .registers 4

    .line 14754
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14755
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->playerPerf_:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    if-eqz v0, :cond_22

    .line 14756
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$PerfMetrics;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 14757
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->playerPerf_:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    .line 14758
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->newBuilder(Lcom/vdocipher/PlaybackSession$PerfMetrics;)Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->playerPerf_:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    goto :goto_24

    .line 14760
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->playerPerf_:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    .line 14762
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x40

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private mergeResumed(Lcom/vdocipher/PlaybackSession$PlaybackResume;)V
    .registers 4

    .line 15147
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15148
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->resumed_:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    if-eqz v0, :cond_22

    .line 15149
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$PlaybackResume;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 15150
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->resumed_:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    .line 15151
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->newBuilder(Lcom/vdocipher/PlaybackSession$PlaybackResume;)Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->resumed_:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    goto :goto_24

    .line 15153
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->resumed_:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    .line 15155
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x400

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private mergeSelectedTrack(Lcom/vdocipher/PlaybackSession$SelectedTrack;)V
    .registers 4

    .line 15054
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15055
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->selectedTrack_:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    if-eqz v0, :cond_22

    .line 15056
    invoke-static {}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$SelectedTrack;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 15057
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->selectedTrack_:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    .line 15058
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->newBuilder(Lcom/vdocipher/PlaybackSession$SelectedTrack;)Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->selectedTrack_:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    goto :goto_24

    .line 15060
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->selectedTrack_:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    .line 15062
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x200

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private mergeToolkit(Lcom/vdocipher/PlaybackSession$Toolkit;)V
    .registers 4

    .line 15265
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15266
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->toolkit_:Lcom/vdocipher/PlaybackSession$Toolkit;

    if-eqz v0, :cond_22

    .line 15267
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Toolkit;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Toolkit;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 15268
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->toolkit_:Lcom/vdocipher/PlaybackSession$Toolkit;

    .line 15269
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Toolkit;->newBuilder(Lcom/vdocipher/PlaybackSession$Toolkit;)Lcom/vdocipher/PlaybackSession$Toolkit$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Toolkit;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->toolkit_:Lcom/vdocipher/PlaybackSession$Toolkit;

    goto :goto_24

    .line 15271
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->toolkit_:Lcom/vdocipher/PlaybackSession$Toolkit;

    .line 15273
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x1000

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private mergeTrackCount(Lcom/vdocipher/PlaybackSession$TrackCount;)V
    .registers 4

    .line 14868
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14869
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->trackCount_:Lcom/vdocipher/PlaybackSession$TrackCount;

    if-eqz v0, :cond_22

    .line 14870
    invoke-static {}, Lcom/vdocipher/PlaybackSession$TrackCount;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$TrackCount;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 14871
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->trackCount_:Lcom/vdocipher/PlaybackSession$TrackCount;

    .line 14872
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$TrackCount;->newBuilder(Lcom/vdocipher/PlaybackSession$TrackCount;)Lcom/vdocipher/PlaybackSession$TrackCount$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$TrackCount$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$TrackCount$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$TrackCount$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$TrackCount;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->trackCount_:Lcom/vdocipher/PlaybackSession$TrackCount;

    goto :goto_24

    .line 14874
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->trackCount_:Lcom/vdocipher/PlaybackSession$TrackCount;

    .line 14876
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x80

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private mergeWidevineCDM(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V
    .registers 4

    .line 15311
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15312
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->widevineCDM_:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    if-eqz v0, :cond_22

    .line 15313
    invoke-static {}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$WidevineCDM;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 15314
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->widevineCDM_:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    .line 15315
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->newBuilder(Lcom/vdocipher/PlaybackSession$WidevineCDM;)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->widevineCDM_:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    goto :goto_24

    .line 15317
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->widevineCDM_:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    .line 15319
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x2000

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 1

    .line 15405
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 15408
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 15381
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 15388
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 15344
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 15351
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 15393
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 15400
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 15368
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 15375
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 15331
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 15338
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 15356
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 15363
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;",
            ">;"
        }
    .end annotation

    .line 16882
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private removeBeats(I)V
    .registers 3

    .line 14975
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->ensureBeatsIsMutable()V

    .line 14976
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->beats_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private removeEvents(I)V
    .registers 3

    .line 14721
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->ensureEventsIsMutable()V

    .line 14722
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->events_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private setAndroid(Lcom/vdocipher/PlaybackSession$Android;)V
    .registers 2

    .line 15184
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15185
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->android_:Lcom/vdocipher/PlaybackSession$Android;

    .line 15186
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x800

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private setBeats(ILcom/vdocipher/PlaybackSession$Beat;)V
    .registers 4

    .line 14935
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14936
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->ensureBeatsIsMutable()V

    .line 14937
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->beats_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setCaptionSearch(Lcom/vdocipher/PlaybackSession$CaptionSearch;)V
    .registers 2

    .line 14802
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$CaptionSearch;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->captionSearch_:I

    return-void
.end method

.method private setCaptionSearchValue(I)V
    .registers 2

    .line 14795
    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->captionSearch_:I

    return-void
.end method

.method private setCoverage(Lcom/vdocipher/PlaybackSession$Coverage;)V
    .registers 2

    .line 14605
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14606
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->coverage_:Lcom/vdocipher/PlaybackSession$Coverage;

    .line 14607
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x20

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private setDevice(Lcom/vdocipher/PlaybackSession$Device;)V
    .registers 2

    .line 14466
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14467
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->device_:Lcom/vdocipher/PlaybackSession$Device;

    .line 14468
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x8

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private setDimensions(Lcom/vdocipher/PlaybackSession$Dimension;)V
    .registers 2

    .line 14191
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14192
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->dimensions_:Lcom/vdocipher/PlaybackSession$Dimension;

    .line 14193
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x2

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private setDownloadLocation(Ljava/lang/String;)V
    .registers 2

    .line 15096
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15098
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->downloadLocation_:Ljava/lang/String;

    return-void
.end method

.method private setDownloadLocationBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 15113
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 15114
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->downloadLocation_:Ljava/lang/String;

    return-void
.end method

.method private setEmbedInfo(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V
    .registers 2

    .line 14145
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14146
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->embedInfo_:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    .line 14147
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private setError(Lcom/vdocipher/PlaybackSession$Error;)V
    .registers 2

    .line 14999
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15000
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->error_:Lcom/vdocipher/PlaybackSession$Error;

    .line 15001
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x100

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private setEvents(ILcom/vdocipher/PlaybackSession$Event;)V
    .registers 4

    .line 14681
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14682
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->ensureEventsIsMutable()V

    .line 14683
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->events_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setIsUIEnabled(Z)V
    .registers 2

    .line 14829
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->isUIEnabled_:Z

    return-void
.end method

.method private setMedia(Lcom/vdocipher/PlaybackSession$Media;)V
    .registers 2

    .line 14420
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14421
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->media_:Lcom/vdocipher/PlaybackSession$Media;

    .line 14422
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x4

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private setNavigator(Ljava/lang/String;)V
    .registers 2

    .line 14517
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14519
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->navigator_:Ljava/lang/String;

    return-void
.end method

.method private setNavigatorBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 14534
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 14535
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->navigator_:Ljava/lang/String;

    return-void
.end method

.method private setNavigatorProps(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V
    .registers 2

    .line 14559
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14560
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->navigatorProps_:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    .line 14561
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x10

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private setPlatform(Ljava/lang/String;)V
    .registers 2

    .line 14331
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14333
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->platform_:Ljava/lang/String;

    return-void
.end method

.method private setPlatformBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 14348
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 14349
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->platform_:Ljava/lang/String;

    return-void
.end method

.method private setPlayerPerf(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V
    .registers 2

    .line 14745
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14746
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->playerPerf_:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    .line 14747
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x40

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private setRefUrl(Ljava/lang/String;)V
    .registers 2

    .line 14242
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14244
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->refUrl_:Ljava/lang/String;

    return-void
.end method

.method private setRefUrlBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 14259
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 14260
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->refUrl_:Ljava/lang/String;

    return-void
.end method

.method private setResumed(Lcom/vdocipher/PlaybackSession$PlaybackResume;)V
    .registers 2

    .line 15138
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15139
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->resumed_:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    .line 15140
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x400

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private setSelectedTrack(Lcom/vdocipher/PlaybackSession$SelectedTrack;)V
    .registers 2

    .line 15045
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15046
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->selectedTrack_:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    .line 15047
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x200

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private setSession(Ljava/lang/String;)V
    .registers 2

    .line 14056
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14058
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->session_:Ljava/lang/String;

    return-void
.end method

.method private setSessionBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 14073
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 14074
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->session_:Ljava/lang/String;

    return-void
.end method

.method private setSessionInitTime(Ljava/lang/String;)V
    .registers 2

    .line 14103
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14105
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->sessionInitTime_:Ljava/lang/String;

    return-void
.end method

.method private setSessionInitTimeBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 14120
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 14121
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->sessionInitTime_:Ljava/lang/String;

    return-void
.end method

.method private setTech(Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;)V
    .registers 2

    .line 14295
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->tech_:I

    return-void
.end method

.method private setTechValue(I)V
    .registers 2

    .line 14288
    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->tech_:I

    return-void
.end method

.method private setToolkit(Lcom/vdocipher/PlaybackSession$Toolkit;)V
    .registers 2

    .line 15256
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15257
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->toolkit_:Lcom/vdocipher/PlaybackSession$Toolkit;

    .line 15258
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x1000

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private setTrackCount(Lcom/vdocipher/PlaybackSession$TrackCount;)V
    .registers 2

    .line 14859
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14860
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->trackCount_:Lcom/vdocipher/PlaybackSession$TrackCount;

    .line 14861
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x80

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method

.method private setViewer(Ljava/lang/String;)V
    .registers 2

    .line 14378
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14380
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->viewer_:Ljava/lang/String;

    return-void
.end method

.method private setViewerBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 14395
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 14396
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->viewer_:Ljava/lang/String;

    return-void
.end method

.method private setWatermarkCount(I)V
    .registers 2

    .line 15226
    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->watermarkCount_:I

    return-void
.end method

.method private setWidevineCDM(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V
    .registers 2

    .line 15302
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15303
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->widevineCDM_:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    .line 15304
    iget p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x2000

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 36

    .line 16785
    sget-object v0, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual/range {p1 .. p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_92

    .line 16860
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0

    :pswitch_12  #0x7
    return-object v1

    :pswitch_13  #0x6
    const/4 v0, 0x1

    .line 16854
    invoke-static {v0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v0

    return-object v0

    .line 16839
    :pswitch_19  #0x5
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->PARSER:Lcom/google/protobuf/Parser;

    if-nez v0, :cond_32

    .line 16841
    const-class v1, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    monitor-enter v1

    .line 16842
    :try_start_20
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->PARSER:Lcom/google/protobuf/Parser;

    if-nez v0, :cond_2d

    .line 16844
    new-instance v0, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object v2, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-direct {v0, v2}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 16847
    sput-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->PARSER:Lcom/google/protobuf/Parser;

    .line 16849
    :cond_2d
    monitor-exit v1

    return-object v0

    :catchall_2f
    move-exception v0

    monitor-exit v1
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw v0

    :cond_32
    return-object v0

    .line 16836
    :pswitch_33  #0x4
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    return-object v0

    .line 16793
    :pswitch_36  #0x3
    const-string v2, "bitField0_"

    const-string v3, "session_"

    const-string v4, "sessionInitTime_"

    const-string v5, "embedInfo_"

    const-string v6, "dimensions_"

    const-string v7, "refUrl_"

    const-string/jumbo v8, "tech_"

    const-string v9, "platform_"

    const-string/jumbo v10, "viewer_"

    const-string v11, "media_"

    const-string v12, "device_"

    const-string v13, "navigator_"

    const-string v14, "navigatorProps_"

    const-string v15, "coverage_"

    const-string v16, "events_"

    const-class v17, Lcom/vdocipher/PlaybackSession$Event;

    const-string v18, "playerPerf_"

    const-string v19, "captionSearch_"

    const-string v20, "isUIEnabled_"

    const-string/jumbo v21, "trackCount_"

    const-string v22, "beats_"

    const-class v23, Lcom/vdocipher/PlaybackSession$Beat;

    const-string v24, "error_"

    const-string v25, "selectedTrack_"

    const-string v26, "downloadLocation_"

    const-string v27, "resumed_"

    const-string v28, "android_"

    const-string/jumbo v29, "watermarkCount_"

    const-string/jumbo v30, "toolkit_"

    const-string/jumbo v31, "widevineCDM_"

    filled-new-array/range {v2 .. v31}, [Ljava/lang/Object;

    move-result-object v0

    .line 16825
    const-string v1, "\u0000\u001b\u0000\u0001\u0001\u001b\u001b\u0000\u0002\u0000\u0001Ȉ\u0002Ȉ\u0003ဉ\u0000\u0004ဉ\u0001\u0005Ȉ\u0006\f\u0007Ȉ\bȈ\tဉ\u0002\nဉ\u0003\u000bȈ\fဉ\u0004\rဉ\u0005\u000e\u001b\u000fဉ\u0006\u0010\f\u0011\u0007\u0012ဉ\u0007\u0013\u001b\u0014ဉ\b\u0015ဉ\t\u0016Ȉ\u0017ဉ\n\u0018ဉ\u000b\u0019\u000b\u001aဉ\f\u001bဉ\r"

    .line 16832
    sget-object v2, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v2, v1, v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    .line 16790
    :pswitch_85  #0x2
    new-instance v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;

    invoke-direct {v0, v1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object v0

    .line 16787
    :pswitch_8b  #0x1
    new-instance v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;-><init>()V

    return-object v0

    nop

    :pswitch_data_92
    .packed-switch 0x1
        :pswitch_8b  #00000001
        :pswitch_85  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getAndroid()Lcom/vdocipher/PlaybackSession$Android;
    .registers 2

    .line 15178
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->android_:Lcom/vdocipher/PlaybackSession$Android;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$Android;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Android;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getBeats(I)Lcom/vdocipher/PlaybackSession$Beat;
    .registers 3

    .line 14913
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->beats_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Beat;

    return-object p1
.end method

.method public getBeatsCount()I
    .registers 2

    .line 14906
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->beats_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getBeatsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackSession$Beat;",
            ">;"
        }
    .end annotation

    .line 14892
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->beats_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getBeatsOrBuilder(I)Lcom/vdocipher/PlaybackSession$BeatOrBuilder;
    .registers 3

    .line 14920
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->beats_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$BeatOrBuilder;

    return-object p1
.end method

.method public getBeatsOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/PlaybackSession$BeatOrBuilder;",
            ">;"
        }
    .end annotation

    .line 14899
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->beats_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getCaptionSearch()Lcom/vdocipher/PlaybackSession$CaptionSearch;
    .registers 2

    .line 14787
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->captionSearch_:I

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$CaptionSearch;->forNumber(I)Lcom/vdocipher/PlaybackSession$CaptionSearch;

    move-result-object v0

    if-nez v0, :cond_a

    .line 14788
    sget-object v0, Lcom/vdocipher/PlaybackSession$CaptionSearch;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$CaptionSearch;

    :cond_a
    return-object v0
.end method

.method public getCaptionSearchValue()I
    .registers 2

    .line 14779
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->captionSearch_:I

    return v0
.end method

.method public getCoverage()Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 2

    .line 14599
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->coverage_:Lcom/vdocipher/PlaybackSession$Coverage;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$Coverage;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Coverage;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getDevice()Lcom/vdocipher/PlaybackSession$Device;
    .registers 2

    .line 14460
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->device_:Lcom/vdocipher/PlaybackSession$Device;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$Device;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Device;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getDimensions()Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 2

    .line 14185
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->dimensions_:Lcom/vdocipher/PlaybackSession$Dimension;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$Dimension;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Dimension;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getDownloadLocation()Ljava/lang/String;
    .registers 2

    .line 15079
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->downloadLocation_:Ljava/lang/String;

    return-object v0
.end method

.method public getDownloadLocationBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 15088
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->downloadLocation_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getEmbedInfo()Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 2

    .line 14139
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->embedInfo_:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$EmbedInfo;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getError()Lcom/vdocipher/PlaybackSession$Error;
    .registers 2

    .line 14993
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->error_:Lcom/vdocipher/PlaybackSession$Error;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$Error;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Error;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getEvents(I)Lcom/vdocipher/PlaybackSession$Event;
    .registers 3

    .line 14659
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->events_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Event;

    return-object p1
.end method

.method public getEventsCount()I
    .registers 2

    .line 14652
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->events_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getEventsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackSession$Event;",
            ">;"
        }
    .end annotation

    .line 14638
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->events_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getEventsOrBuilder(I)Lcom/vdocipher/PlaybackSession$EventOrBuilder;
    .registers 3

    .line 14666
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->events_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$EventOrBuilder;

    return-object p1
.end method

.method public getEventsOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/PlaybackSession$EventOrBuilder;",
            ">;"
        }
    .end annotation

    .line 14645
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->events_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getIsUIEnabled()Z
    .registers 2

    .line 14821
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->isUIEnabled_:Z

    return v0
.end method

.method public getMedia()Lcom/vdocipher/PlaybackSession$Media;
    .registers 2

    .line 14414
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->media_:Lcom/vdocipher/PlaybackSession$Media;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$Media;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Media;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getNavigator()Ljava/lang/String;
    .registers 2

    .line 14500
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->navigator_:Ljava/lang/String;

    return-object v0
.end method

.method public getNavigatorBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 14509
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->navigator_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getNavigatorProps()Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 2

    .line 14553
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->navigatorProps_:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$NavigatorProps;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getPlatform()Ljava/lang/String;
    .registers 2

    .line 14314
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->platform_:Ljava/lang/String;

    return-object v0
.end method

.method public getPlatformBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 14323
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->platform_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getPlayerPerf()Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 2

    .line 14739
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->playerPerf_:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$PerfMetrics;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getRefUrl()Ljava/lang/String;
    .registers 2

    .line 14225
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->refUrl_:Ljava/lang/String;

    return-object v0
.end method

.method public getRefUrlBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 14234
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->refUrl_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getResumed()Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 2

    .line 15132
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->resumed_:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$PlaybackResume;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getSelectedTrack()Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 2

    .line 15039
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->selectedTrack_:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$SelectedTrack;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getSession()Ljava/lang/String;
    .registers 2

    .line 14039
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->session_:Ljava/lang/String;

    return-object v0
.end method

.method public getSessionBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 14048
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->session_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSessionInitTime()Ljava/lang/String;
    .registers 2

    .line 14086
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->sessionInitTime_:Ljava/lang/String;

    return-object v0
.end method

.method public getSessionInitTimeBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 14095
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->sessionInitTime_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getTech()Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;
    .registers 2

    .line 14280
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->tech_:I

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->forNumber(I)Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    move-result-object v0

    if-nez v0, :cond_a

    .line 14281
    sget-object v0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    :cond_a
    return-object v0
.end method

.method public getTechValue()I
    .registers 2

    .line 14272
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->tech_:I

    return v0
.end method

.method public getToolkit()Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 2

    .line 15250
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->toolkit_:Lcom/vdocipher/PlaybackSession$Toolkit;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$Toolkit;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Toolkit;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getTrackCount()Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 2

    .line 14853
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->trackCount_:Lcom/vdocipher/PlaybackSession$TrackCount;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$TrackCount;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$TrackCount;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getViewer()Ljava/lang/String;
    .registers 2

    .line 14361
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->viewer_:Ljava/lang/String;

    return-object v0
.end method

.method public getViewerBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 14370
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->viewer_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getWatermarkCount()I
    .registers 2

    .line 15218
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->watermarkCount_:I

    return v0
.end method

.method public getWidevineCDM()Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 2

    .line 15296
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->widevineCDM_:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$WidevineCDM;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public hasAndroid()Z
    .registers 2

    .line 15171
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit16 v0, v0, 0x800

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasCoverage()Z
    .registers 2

    .line 14592
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x20

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasDevice()Z
    .registers 2

    .line 14453
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x8

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasDimensions()Z
    .registers 2

    .line 14178
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasEmbedInfo()Z
    .registers 3

    .line 14132
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_7

    return v1

    :cond_7
    const/4 v0, 0x0

    return v0
.end method

.method public hasError()Z
    .registers 2

    .line 14986
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit16 v0, v0, 0x100

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasMedia()Z
    .registers 2

    .line 14407
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasNavigatorProps()Z
    .registers 2

    .line 14546
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasPlayerPerf()Z
    .registers 2

    .line 14732
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x40

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasResumed()Z
    .registers 2

    .line 15125
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit16 v0, v0, 0x400

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasSelectedTrack()Z
    .registers 2

    .line 15032
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit16 v0, v0, 0x200

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasToolkit()Z
    .registers 2

    .line 15243
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit16 v0, v0, 0x1000

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasTrackCount()Z
    .registers 2

    .line 14846
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit16 v0, v0, 0x80

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasWidevineCDM()Z
    .registers 2

    .line 15289
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->bitField0_:I

    and-int/lit16 v0, v0, 0x2000

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method
