# classes14.dex

.class public final Lcom/vdocipher/Manifest$AudioChannelConfiguration;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$AudioChannelConfigurationOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "AudioChannelConfiguration"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/Manifest$AudioChannelConfiguration;",
        "Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$AudioChannelConfigurationOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$AudioChannelConfiguration;",
            ">;"
        }
    .end annotation
.end field

.field public static final SCHEMEIDURI_FIELD_NUMBER:I = 0x1

.field public static final VALUE_FIELD_NUMBER:I = 0x2


# instance fields
.field private schemeIdUri_:Ljava/lang/String;

.field private value_:I


# direct methods
.method static bridge synthetic -$$Nest$mclearSchemeIdUri(Lcom/vdocipher/Manifest$AudioChannelConfiguration;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->clearSchemeIdUri()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearValue(Lcom/vdocipher/Manifest$AudioChannelConfiguration;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->clearValue()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSchemeIdUri(Lcom/vdocipher/Manifest$AudioChannelConfiguration;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->setSchemeIdUri(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSchemeIdUriBytes(Lcom/vdocipher/Manifest$AudioChannelConfiguration;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->setSchemeIdUriBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetValue(Lcom/vdocipher/Manifest$AudioChannelConfiguration;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->setValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 1

    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 1606
    new-instance v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;-><init>()V

    .line 1609
    sput-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    .line 1610
    const-class v1, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 1299
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 1300
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->schemeIdUri_:Ljava/lang/String;

    return-void
.end method

.method private clearSchemeIdUri()V
    .registers 2

    .line 1336
    invoke-static {}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->getDefaultInstance()Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->getSchemeIdUri()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->schemeIdUri_:Ljava/lang/String;

    return-void
.end method

.method private clearValue()V
    .registers 2

    const/4 v0, 0x0

    .line 1372
    iput v0, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->value_:I

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 1

    .line 1615
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;
    .registers 1

    .line 1452
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/Manifest$AudioChannelConfiguration;)Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;
    .registers 2

    .line 1455
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-virtual {v0, p0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1428
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1435
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1391
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1398
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1440
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1447
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1415
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1422
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1378
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1385
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1403
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1410
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$AudioChannelConfiguration;",
            ">;"
        }
    .end annotation

    .line 1621
    sget-object v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setSchemeIdUri(Ljava/lang/String;)V
    .registers 2

    .line 1327
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1329
    iput-object p1, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->schemeIdUri_:Ljava/lang/String;

    return-void
.end method

.method private setSchemeIdUriBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 1344
    invoke-static {p1}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 1345
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->schemeIdUri_:Ljava/lang/String;

    return-void
.end method

.method private setValue(I)V
    .registers 2

    .line 1365
    iput p1, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->value_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1556
    sget-object p2, Lcom/vdocipher/Manifest$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_54

    .line 1599
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 1593
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 1578
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 1580
    const-class p2, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    monitor-enter p2

    .line 1581
    :try_start_20
    sget-object p1, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 1583
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 1586
    sput-object p1, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->PARSER:Lcom/google/protobuf/Parser;

    .line 1588
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 1575
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object p1

    .line 1564
    :pswitch_36  #0x3
    const-string p1, "schemeIdUri_"

    const-string/jumbo p2, "value_"

    filled-new-array {p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    .line 1568
    const-string p2, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002\u000b"

    .line 1571
    sget-object p3, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 1561
    :pswitch_48  #0x2
    new-instance p1, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;-><init>(Lcom/vdocipher/Manifest-IA;)V

    return-object p1

    .line 1558
    :pswitch_4e  #0x1
    new-instance p1, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-direct {p1}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;-><init>()V

    return-object p1

    :pswitch_data_54
    .packed-switch 0x1
        :pswitch_4e  #00000001
        :pswitch_48  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getSchemeIdUri()Ljava/lang/String;
    .registers 2

    .line 1310
    iget-object v0, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->schemeIdUri_:Ljava/lang/String;

    return-object v0
.end method

.method public getSchemeIdUriBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 1319
    iget-object v0, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->schemeIdUri_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getValue()I
    .registers 2

    .line 1357
    iget v0, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->value_:I

    return v0
.end method
