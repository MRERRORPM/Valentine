# classes14.dex

.class public final enum Lcom/vdocipher/PlaybackInfo$TechOptions;
.super Ljava/lang/Enum;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "TechOptions"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$TechOptions$TechOptionsVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/PlaybackInfo$TechOptions;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/PlaybackInfo$TechOptions;

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$TechOptions;

.field public static final enum cbcsi:Lcom/vdocipher/PlaybackInfo$TechOptions;

.field public static final cbcsi_VALUE:I = 0x1

.field public static final enum dash:Lcom/vdocipher/PlaybackInfo$TechOptions;

.field public static final dash_VALUE:I = 0x0

.field public static final enum fps:Lcom/vdocipher/PlaybackInfo$TechOptions;

.field public static final fps_VALUE:I = 0x2

.field public static final enum h1:Lcom/vdocipher/PlaybackInfo$TechOptions;

.field public static final h1_VALUE:I = 0x6

.field public static final enum h6:Lcom/vdocipher/PlaybackInfo$TechOptions;

.field public static final h6_VALUE:I = 0x4

.field public static final enum hlse:Lcom/vdocipher/PlaybackInfo$TechOptions;

.field public static final hlse_VALUE:I = 0x5

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackInfo$TechOptions;",
            ">;"
        }
    .end annotation
.end field

.field public static final enum zen:Lcom/vdocipher/PlaybackInfo$TechOptions;

.field public static final zen_VALUE:I = 0x3


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 11

    .line 609
    new-instance v0, Lcom/vdocipher/PlaybackInfo$TechOptions;

    const-string v1, "dash"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/PlaybackInfo$TechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$TechOptions;->dash:Lcom/vdocipher/PlaybackInfo$TechOptions;

    .line 613
    new-instance v1, Lcom/vdocipher/PlaybackInfo$TechOptions;

    const-string v2, "cbcsi"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/PlaybackInfo$TechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackInfo$TechOptions;->cbcsi:Lcom/vdocipher/PlaybackInfo$TechOptions;

    .line 617
    new-instance v2, Lcom/vdocipher/PlaybackInfo$TechOptions;

    const-string v3, "fps"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4, v4}, Lcom/vdocipher/PlaybackInfo$TechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/PlaybackInfo$TechOptions;->fps:Lcom/vdocipher/PlaybackInfo$TechOptions;

    .line 621
    new-instance v3, Lcom/vdocipher/PlaybackInfo$TechOptions;

    const-string/jumbo v4, "zen"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5, v5}, Lcom/vdocipher/PlaybackInfo$TechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lcom/vdocipher/PlaybackInfo$TechOptions;->zen:Lcom/vdocipher/PlaybackInfo$TechOptions;

    .line 625
    new-instance v4, Lcom/vdocipher/PlaybackInfo$TechOptions;

    const-string v5, "h6"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6, v6}, Lcom/vdocipher/PlaybackInfo$TechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lcom/vdocipher/PlaybackInfo$TechOptions;->h6:Lcom/vdocipher/PlaybackInfo$TechOptions;

    .line 629
    new-instance v5, Lcom/vdocipher/PlaybackInfo$TechOptions;

    const-string v6, "hlse"

    const/4 v7, 0x5

    invoke-direct {v5, v6, v7, v7}, Lcom/vdocipher/PlaybackInfo$TechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lcom/vdocipher/PlaybackInfo$TechOptions;->hlse:Lcom/vdocipher/PlaybackInfo$TechOptions;

    .line 633
    new-instance v6, Lcom/vdocipher/PlaybackInfo$TechOptions;

    const-string v7, "h1"

    const/4 v8, 0x6

    invoke-direct {v6, v7, v8, v8}, Lcom/vdocipher/PlaybackInfo$TechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lcom/vdocipher/PlaybackInfo$TechOptions;->h1:Lcom/vdocipher/PlaybackInfo$TechOptions;

    .line 634
    new-instance v7, Lcom/vdocipher/PlaybackInfo$TechOptions;

    const/4 v8, 0x7

    const/4 v9, -0x1

    const-string v10, "UNRECOGNIZED"

    invoke-direct {v7, v10, v8, v9}, Lcom/vdocipher/PlaybackInfo$TechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lcom/vdocipher/PlaybackInfo$TechOptions;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$TechOptions;

    .line 604
    filled-new-array/range {v0 .. v7}, [Lcom/vdocipher/PlaybackInfo$TechOptions;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/PlaybackInfo$TechOptions;->$VALUES:[Lcom/vdocipher/PlaybackInfo$TechOptions;

    .line 704
    new-instance v0, Lcom/vdocipher/PlaybackInfo$TechOptions$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$TechOptions$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$TechOptions;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 728
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 729
    iput p3, p0, Lcom/vdocipher/PlaybackInfo$TechOptions;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/PlaybackInfo$TechOptions;
    .registers 1

    packed-switch p0, :pswitch_data_1a

    const/4 p0, 0x0

    return-object p0

    .line 694
    :pswitch_5  #0x6
    sget-object p0, Lcom/vdocipher/PlaybackInfo$TechOptions;->h1:Lcom/vdocipher/PlaybackInfo$TechOptions;

    return-object p0

    .line 693
    :pswitch_8  #0x5
    sget-object p0, Lcom/vdocipher/PlaybackInfo$TechOptions;->hlse:Lcom/vdocipher/PlaybackInfo$TechOptions;

    return-object p0

    .line 692
    :pswitch_b  #0x4
    sget-object p0, Lcom/vdocipher/PlaybackInfo$TechOptions;->h6:Lcom/vdocipher/PlaybackInfo$TechOptions;

    return-object p0

    .line 691
    :pswitch_e  #0x3
    sget-object p0, Lcom/vdocipher/PlaybackInfo$TechOptions;->zen:Lcom/vdocipher/PlaybackInfo$TechOptions;

    return-object p0

    .line 690
    :pswitch_11  #0x2
    sget-object p0, Lcom/vdocipher/PlaybackInfo$TechOptions;->fps:Lcom/vdocipher/PlaybackInfo$TechOptions;

    return-object p0

    .line 689
    :pswitch_14  #0x1
    sget-object p0, Lcom/vdocipher/PlaybackInfo$TechOptions;->cbcsi:Lcom/vdocipher/PlaybackInfo$TechOptions;

    return-object p0

    .line 688
    :pswitch_17  #0x0
    sget-object p0, Lcom/vdocipher/PlaybackInfo$TechOptions;->dash:Lcom/vdocipher/PlaybackInfo$TechOptions;

    return-object p0

    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_17  #00000000
        :pswitch_14  #00000001
        :pswitch_11  #00000002
        :pswitch_e  #00000003
        :pswitch_b  #00000004
        :pswitch_8  #00000005
        :pswitch_5  #00000006
    .end packed-switch
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackInfo$TechOptions;",
            ">;"
        }
    .end annotation

    .line 701
    sget-object v0, Lcom/vdocipher/PlaybackInfo$TechOptions;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 714
    sget-object v0, Lcom/vdocipher/PlaybackInfo$TechOptions$TechOptionsVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/PlaybackInfo$TechOptions;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 683
    invoke-static {p0}, Lcom/vdocipher/PlaybackInfo$TechOptions;->forNumber(I)Lcom/vdocipher/PlaybackInfo$TechOptions;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$TechOptions;
    .registers 2

    .line 604
    const-class v0, Lcom/vdocipher/PlaybackInfo$TechOptions;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$TechOptions;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/PlaybackInfo$TechOptions;
    .registers 1

    .line 604
    sget-object v0, Lcom/vdocipher/PlaybackInfo$TechOptions;->$VALUES:[Lcom/vdocipher/PlaybackInfo$TechOptions;

    invoke-virtual {v0}, [Lcom/vdocipher/PlaybackInfo$TechOptions;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/PlaybackInfo$TechOptions;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 669
    sget-object v0, Lcom/vdocipher/PlaybackInfo$TechOptions;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$TechOptions;

    if-eq p0, v0, :cond_7

    .line 673
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$TechOptions;->value:I

    return v0

    .line 670
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
