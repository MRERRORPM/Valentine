# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackSession$DeviceOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "DeviceOrBuilder"
.end annotation


# virtual methods
.method public abstract getBrand()Ljava/lang/String;
.end method

.method public abstract getBrandBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getModel()Ljava/lang/String;
.end method

.method public abstract getModelBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getSdkSessionId()Ljava/lang/String;
.end method

.method public abstract getSdkSessionIdBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getSdkVersion()Ljava/lang/String;
.end method

.method public abstract getSdkVersionBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getType()Lcom/vdocipher/PlaybackSession$DeviceTypes;
.end method

.method public abstract getTypeValue()I
.end method

.method public abstract getVendor()Ljava/lang/String;
.end method

.method public abstract getVendorBytes()Lcom/google/protobuf/ByteString;
.end method
