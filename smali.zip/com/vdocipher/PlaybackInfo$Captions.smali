# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$Captions;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$CaptionsOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Captions"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackInfo$Captions;",
        "Lcom/vdocipher/PlaybackInfo$Captions$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$CaptionsOrBuilder;"
    }
.end annotation


# static fields
.field public static final CAPTIONNAME_FIELD_NUMBER:I = 0x5

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

.field public static final ISDEFAULT_FIELD_NUMBER:I = 0x4

.field public static final LABEL_FIELD_NUMBER:I = 0x3

.field public static final LANG_FIELD_NUMBER:I = 0x2

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$Captions;",
            ">;"
        }
    .end annotation
.end field

.field public static final SUBTITLENAME_FIELD_NUMBER:I = 0x6

.field public static final URL_FIELD_NUMBER:I = 0x1


# instance fields
.field private bitField0_:I

.field private captionName_:Ljava/lang/String;

.field private isDefault_:Z

.field private label_:Ljava/lang/String;

.field private lang_:Ljava/lang/String;

.field private subtitleName_:Ljava/lang/String;

.field private url_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$mclearCaptionName(Lcom/vdocipher/PlaybackInfo$Captions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Captions;->clearCaptionName()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearIsDefault(Lcom/vdocipher/PlaybackInfo$Captions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Captions;->clearIsDefault()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLabel(Lcom/vdocipher/PlaybackInfo$Captions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Captions;->clearLabel()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLang(Lcom/vdocipher/PlaybackInfo$Captions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Captions;->clearLang()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSubtitleName(Lcom/vdocipher/PlaybackInfo$Captions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Captions;->clearSubtitleName()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearUrl(Lcom/vdocipher/PlaybackInfo$Captions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Captions;->clearUrl()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCaptionName(Lcom/vdocipher/PlaybackInfo$Captions;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->setCaptionName(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCaptionNameBytes(Lcom/vdocipher/PlaybackInfo$Captions;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->setCaptionNameBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIsDefault(Lcom/vdocipher/PlaybackInfo$Captions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->setIsDefault(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLabel(Lcom/vdocipher/PlaybackInfo$Captions;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->setLabel(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLabelBytes(Lcom/vdocipher/PlaybackInfo$Captions;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->setLabelBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLang(Lcom/vdocipher/PlaybackInfo$Captions;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->setLang(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLangBytes(Lcom/vdocipher/PlaybackInfo$Captions;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->setLangBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSubtitleName(Lcom/vdocipher/PlaybackInfo$Captions;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->setSubtitleName(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSubtitleNameBytes(Lcom/vdocipher/PlaybackInfo$Captions;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->setSubtitleNameBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetUrl(Lcom/vdocipher/PlaybackInfo$Captions;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->setUrl(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetUrlBytes(Lcom/vdocipher/PlaybackInfo$Captions;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->setUrlBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 6687
    new-instance v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$Captions;-><init>()V

    .line 6690
    sput-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    .line 6691
    const-class v1, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 5954
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 5955
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->url_:Ljava/lang/String;

    .line 5956
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->lang_:Ljava/lang/String;

    .line 5957
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->label_:Ljava/lang/String;

    .line 5958
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->captionName_:Ljava/lang/String;

    .line 5959
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->subtitleName_:Ljava/lang/String;

    return-void
.end method

.method private clearCaptionName()V
    .registers 2

    .line 6178
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->bitField0_:I

    and-int/lit8 v0, v0, -0x3

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->bitField0_:I

    .line 6179
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Captions;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$Captions;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getCaptionName()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->captionName_:Ljava/lang/String;

    return-void
.end method

.method private clearIsDefault()V
    .registers 2

    const/4 v0, 0x0

    .line 6134
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->isDefault_:Z

    return-void
.end method

.method private clearLabel()V
    .registers 2

    .line 6097
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->bitField0_:I

    and-int/lit8 v0, v0, -0x2

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->bitField0_:I

    .line 6098
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Captions;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$Captions;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getLabel()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->label_:Ljava/lang/String;

    return-void
.end method

.method private clearLang()V
    .registers 2

    .line 6043
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Captions;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$Captions;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getLang()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->lang_:Ljava/lang/String;

    return-void
.end method

.method private clearSubtitleName()V
    .registers 2

    .line 6226
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Captions;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$Captions;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getSubtitleName()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->subtitleName_:Ljava/lang/String;

    return-void
.end method

.method private clearUrl()V
    .registers 2

    .line 5996
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Captions;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$Captions;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getUrl()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->url_:Ljava/lang/String;

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 1

    .line 6696
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 1

    .line 6316
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackInfo$Captions;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 2

    .line 6319
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$Captions;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 6292
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackInfo$Captions;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Captions;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 6299
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Captions;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 6255
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Captions;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 6262
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Captions;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 6304
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Captions;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 6311
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Captions;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 6279
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Captions;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 6286
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Captions;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 6242
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Captions;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 6249
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Captions;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 6267
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Captions;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 6274
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Captions;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$Captions;",
            ">;"
        }
    .end annotation

    .line 6702
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setCaptionName(Ljava/lang/String;)V
    .registers 3

    .line 6170
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6171
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->bitField0_:I

    or-int/lit8 v0, v0, 0x2

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->bitField0_:I

    .line 6172
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Captions;->captionName_:Ljava/lang/String;

    return-void
.end method

.method private setCaptionNameBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 6187
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$Captions;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 6188
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Captions;->captionName_:Ljava/lang/String;

    .line 6189
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$Captions;->bitField0_:I

    or-int/lit8 p1, p1, 0x2

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$Captions;->bitField0_:I

    return-void
.end method

.method private setIsDefault(Z)V
    .registers 2

    .line 6127
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$Captions;->isDefault_:Z

    return-void
.end method

.method private setLabel(Ljava/lang/String;)V
    .registers 3

    .line 6089
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6090
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->bitField0_:I

    or-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->bitField0_:I

    .line 6091
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Captions;->label_:Ljava/lang/String;

    return-void
.end method

.method private setLabelBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 6106
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$Captions;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 6107
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Captions;->label_:Ljava/lang/String;

    .line 6108
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$Captions;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$Captions;->bitField0_:I

    return-void
.end method

.method private setLang(Ljava/lang/String;)V
    .registers 2

    .line 6034
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6036
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Captions;->lang_:Ljava/lang/String;

    return-void
.end method

.method private setLangBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 6051
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$Captions;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 6052
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Captions;->lang_:Ljava/lang/String;

    return-void
.end method

.method private setSubtitleName(Ljava/lang/String;)V
    .registers 2

    .line 6217
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6219
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Captions;->subtitleName_:Ljava/lang/String;

    return-void
.end method

.method private setSubtitleNameBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 6234
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$Captions;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 6235
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Captions;->subtitleName_:Ljava/lang/String;

    return-void
.end method

.method private setUrl(Ljava/lang/String;)V
    .registers 2

    .line 5987
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5989
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Captions;->url_:Ljava/lang/String;

    return-void
.end method

.method private setUrlBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 6004
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$Captions;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 6005
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Captions;->url_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    .line 6632
    sget-object p2, Lcom/vdocipher/PlaybackInfo$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_60

    .line 6680
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 6674
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 6659
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackInfo$Captions;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_33

    .line 6661
    const-class p2, Lcom/vdocipher/PlaybackInfo$Captions;

    monitor-enter p2

    .line 6662
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackInfo$Captions;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 6664
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 6667
    sput-object p1, Lcom/vdocipher/PlaybackInfo$Captions;->PARSER:Lcom/google/protobuf/Parser;

    .line 6669
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception v0

    move-object p1, v0

    monitor-exit p2
    :try_end_32
    .catchall {:try_start_20 .. :try_end_32} :catchall_2f

    throw p1

    :cond_33
    return-object p1

    .line 6656
    :pswitch_34  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    return-object p1

    .line 6640
    :pswitch_37  #0x3
    const-string v0, "bitField0_"

    const-string/jumbo v1, "url_"

    const-string v2, "lang_"

    const-string v3, "label_"

    const-string v4, "isDefault_"

    const-string v5, "captionName_"

    const-string/jumbo v6, "subtitleName_"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/Object;

    move-result-object p1

    .line 6649
    const-string p2, "\u0000\u0006\u0000\u0001\u0001\u0006\u0006\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003ለ\u0000\u0004\u0007\u0005ለ\u0001\u0006Ȉ"

    .line 6652
    sget-object p3, Lcom/vdocipher/PlaybackInfo$Captions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 6637
    :pswitch_54  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackInfo$Captions$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;-><init>(Lcom/vdocipher/PlaybackInfo-IA;)V

    return-object p1

    .line 6634
    :pswitch_5a  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackInfo$Captions;-><init>()V

    return-object p1

    :pswitch_data_60
    .packed-switch 0x1
        :pswitch_5a  #00000001
        :pswitch_54  #00000002
        :pswitch_37  #00000003
        :pswitch_34  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getCaptionName()Ljava/lang/String;
    .registers 2

    .line 6153
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->captionName_:Ljava/lang/String;

    return-object v0
.end method

.method public getCaptionNameBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 6162
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->captionName_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getIsDefault()Z
    .registers 2

    .line 6119
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->isDefault_:Z

    return v0
.end method

.method public getLabel()Ljava/lang/String;
    .registers 2

    .line 6072
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->label_:Ljava/lang/String;

    return-object v0
.end method

.method public getLabelBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 6081
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->label_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getLang()Ljava/lang/String;
    .registers 2

    .line 6017
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->lang_:Ljava/lang/String;

    return-object v0
.end method

.method public getLangBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 6026
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->lang_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSubtitleName()Ljava/lang/String;
    .registers 2

    .line 6200
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->subtitleName_:Ljava/lang/String;

    return-object v0
.end method

.method public getSubtitleNameBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 6209
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->subtitleName_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getUrl()Ljava/lang/String;
    .registers 2

    .line 5970
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->url_:Ljava/lang/String;

    return-object v0
.end method

.method public getUrlBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 5979
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->url_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public hasCaptionName()Z
    .registers 2

    .line 6145
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->bitField0_:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasLabel()Z
    .registers 3

    .line 6064
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$Captions;->bitField0_:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_7

    return v1

    :cond_7
    const/4 v0, 0x0

    return v0
.end method
