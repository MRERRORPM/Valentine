# classes14.dex

.class public final Lcom/vdocipher/Manifest$Period;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$PeriodOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Period"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$Period$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/Manifest$Period;",
        "Lcom/vdocipher/Manifest$Period$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$PeriodOrBuilder;"
    }
.end annotation


# static fields
.field public static final ADAPTATIONSET_FIELD_NUMBER:I = 0x2

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

.field public static final DURATION_FIELD_NUMBER:I = 0x3

.field public static final ID_FIELD_NUMBER:I = 0x1

.field private static volatile PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$Period;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private adaptationSet_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/Manifest$AdaptationSet;",
            ">;"
        }
    .end annotation
.end field

.field private bitField0_:I

.field private duration_:Ljava/lang/String;

.field private id_:I


# direct methods
.method static bridge synthetic -$$Nest$maddAdaptationSet(Lcom/vdocipher/Manifest$Period;ILcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$Period;->addAdaptationSet(ILcom/vdocipher/Manifest$AdaptationSet;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAdaptationSet(Lcom/vdocipher/Manifest$Period;Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Period;->addAdaptationSet(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllAdaptationSet(Lcom/vdocipher/Manifest$Period;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Period;->addAllAdaptationSet(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearAdaptationSet(Lcom/vdocipher/Manifest$Period;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Period;->clearAdaptationSet()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearDuration(Lcom/vdocipher/Manifest$Period;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Period;->clearDuration()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearId(Lcom/vdocipher/Manifest$Period;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Period;->clearId()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveAdaptationSet(Lcom/vdocipher/Manifest$Period;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Period;->removeAdaptationSet(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAdaptationSet(Lcom/vdocipher/Manifest$Period;ILcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$Period;->setAdaptationSet(ILcom/vdocipher/Manifest$AdaptationSet;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDuration(Lcom/vdocipher/Manifest$Period;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Period;->setDuration(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDurationBytes(Lcom/vdocipher/Manifest$Period;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Period;->setDurationBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetId(Lcom/vdocipher/Manifest$Period;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Period;->setId(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$Period;
    .registers 1

    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 8710
    new-instance v0, Lcom/vdocipher/Manifest$Period;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$Period;-><init>()V

    .line 8713
    sput-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    .line 8714
    const-class v1, Lcom/vdocipher/Manifest$Period;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 8186
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 8187
    invoke-static {}, Lcom/vdocipher/Manifest$Period;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Period;->adaptationSet_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 8188
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/Manifest$Period;->duration_:Ljava/lang/String;

    return-void
.end method

.method private addAdaptationSet(ILcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 4

    .line 8284
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8285
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Period;->ensureAdaptationSetIsMutable()V

    .line 8286
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period;->adaptationSet_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addAdaptationSet(Lcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 3

    .line 8275
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8276
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Period;->ensureAdaptationSetIsMutable()V

    .line 8277
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period;->adaptationSet_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addAllAdaptationSet(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$AdaptationSet;",
            ">;)V"
        }
    .end annotation

    .line 8293
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Period;->ensureAdaptationSetIsMutable()V

    .line 8294
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period;->adaptationSet_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private clearAdaptationSet()V
    .registers 2

    .line 8301
    invoke-static {}, Lcom/vdocipher/Manifest$Period;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Period;->adaptationSet_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearDuration()V
    .registers 2

    .line 8352
    iget v0, p0, Lcom/vdocipher/Manifest$Period;->bitField0_:I

    and-int/lit8 v0, v0, -0x2

    iput v0, p0, Lcom/vdocipher/Manifest$Period;->bitField0_:I

    .line 8353
    invoke-static {}, Lcom/vdocipher/Manifest$Period;->getDefaultInstance()Lcom/vdocipher/Manifest$Period;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Period;->getDuration()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Period;->duration_:Ljava/lang/String;

    return-void
.end method

.method private clearId()V
    .registers 2

    const/4 v0, 0x0

    .line 8214
    iput v0, p0, Lcom/vdocipher/Manifest$Period;->id_:I

    return-void
.end method

.method private ensureAdaptationSetIsMutable()V
    .registers 3

    .line 8255
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period;->adaptationSet_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 8256
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 8258
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Period;->adaptationSet_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/Manifest$Period;
    .registers 1

    .line 8719
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/Manifest$Period$Builder;
    .registers 1

    .line 8443
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Period;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/Manifest$Period$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/Manifest$Period;)Lcom/vdocipher/Manifest$Period$Builder;
    .registers 2

    .line 8446
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-virtual {v0, p0}, Lcom/vdocipher/Manifest$Period;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Period$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$Period;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8419
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p0}, Lcom/vdocipher/Manifest$Period;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Period;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Period;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8426
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/Manifest$Period;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Period;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$Period;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8382
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Period;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Period;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8389
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Period;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/Manifest$Period;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8431
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Period;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Period;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8438
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Period;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$Period;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8406
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Period;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Period;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8413
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Period;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/Manifest$Period;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8369
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Period;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Period;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8376
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Period;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/Manifest$Period;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8394
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Period;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Period;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8401
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Period;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$Period;",
            ">;"
        }
    .end annotation

    .line 8725
    sget-object v0, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Period;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private removeAdaptationSet(I)V
    .registers 3

    .line 8307
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Period;->ensureAdaptationSetIsMutable()V

    .line 8308
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period;->adaptationSet_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private setAdaptationSet(ILcom/vdocipher/Manifest$AdaptationSet;)V
    .registers 4

    .line 8267
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8268
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Period;->ensureAdaptationSetIsMutable()V

    .line 8269
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period;->adaptationSet_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setDuration(Ljava/lang/String;)V
    .registers 3

    .line 8344
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8345
    iget v0, p0, Lcom/vdocipher/Manifest$Period;->bitField0_:I

    or-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/vdocipher/Manifest$Period;->bitField0_:I

    .line 8346
    iput-object p1, p0, Lcom/vdocipher/Manifest$Period;->duration_:Ljava/lang/String;

    return-void
.end method

.method private setDurationBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 8361
    invoke-static {p1}, Lcom/vdocipher/Manifest$Period;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 8362
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$Period;->duration_:Ljava/lang/String;

    .line 8363
    iget p1, p0, Lcom/vdocipher/Manifest$Period;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/Manifest$Period;->bitField0_:I

    return-void
.end method

.method private setId(I)V
    .registers 2

    .line 8207
    iput p1, p0, Lcom/vdocipher/Manifest$Period;->id_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 8657
    sget-object p2, Lcom/vdocipher/Manifest$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_5a

    .line 8703
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 8697
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 8682
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/Manifest$Period;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 8684
    const-class p2, Lcom/vdocipher/Manifest$Period;

    monitor-enter p2

    .line 8685
    :try_start_20
    sget-object p1, Lcom/vdocipher/Manifest$Period;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 8687
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 8690
    sput-object p1, Lcom/vdocipher/Manifest$Period;->PARSER:Lcom/google/protobuf/Parser;

    .line 8692
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 8679
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    return-object p1

    .line 8665
    :pswitch_36  #0x3
    const-string p1, "bitField0_"

    const-string p2, "id_"

    const-string p3, "adaptationSet_"

    const-class v0, Lcom/vdocipher/Manifest$AdaptationSet;

    const-string v1, "duration_"

    filled-new-array {p1, p2, p3, v0, v1}, [Ljava/lang/Object;

    move-result-object p1

    .line 8672
    const-string p2, "\u0000\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0001\u0000\u0001\u000b\u0002\u001b\u0003ለ\u0000"

    .line 8675
    sget-object p3, Lcom/vdocipher/Manifest$Period;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Period;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/Manifest$Period;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 8662
    :pswitch_4d  #0x2
    new-instance p1, Lcom/vdocipher/Manifest$Period$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/Manifest$Period$Builder;-><init>(Lcom/vdocipher/Manifest-IA;)V

    return-object p1

    .line 8659
    :pswitch_53  #0x1
    new-instance p1, Lcom/vdocipher/Manifest$Period;

    invoke-direct {p1}, Lcom/vdocipher/Manifest$Period;-><init>()V

    return-object p1

    nop

    :pswitch_data_5a
    .packed-switch 0x1
        :pswitch_53  #00000001
        :pswitch_4d  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getAdaptationSet(I)Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 3

    .line 8245
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period;->adaptationSet_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$AdaptationSet;

    return-object p1
.end method

.method public getAdaptationSetCount()I
    .registers 2

    .line 8238
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period;->adaptationSet_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getAdaptationSetList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$AdaptationSet;",
            ">;"
        }
    .end annotation

    .line 8224
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period;->adaptationSet_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getAdaptationSetOrBuilder(I)Lcom/vdocipher/Manifest$AdaptationSetOrBuilder;
    .registers 3

    .line 8252
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period;->adaptationSet_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$AdaptationSetOrBuilder;

    return-object p1
.end method

.method public getAdaptationSetOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/Manifest$AdaptationSetOrBuilder;",
            ">;"
        }
    .end annotation

    .line 8231
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period;->adaptationSet_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getDuration()Ljava/lang/String;
    .registers 2

    .line 8327
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period;->duration_:Ljava/lang/String;

    return-object v0
.end method

.method public getDurationBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8336
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period;->duration_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getId()I
    .registers 2

    .line 8199
    iget v0, p0, Lcom/vdocipher/Manifest$Period;->id_:I

    return v0
.end method

.method public hasDuration()Z
    .registers 3

    .line 8319
    iget v0, p0, Lcom/vdocipher/Manifest$Period;->bitField0_:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_7

    return v1

    :cond_7
    const/4 v0, 0x0

    return v0
.end method
