# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$NavigatorProps;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$NavigatorPropsOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "NavigatorProps"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$NavigatorProps;",
        "Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$NavigatorPropsOrBuilder;"
    }
.end annotation


# static fields
.field public static final CONCURRENCY_FIELD_NUMBER:I = 0x4

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

.field public static final DONOTTRACK_FIELD_NUMBER:I = 0x5

.field public static final LANGAUGESKNOWN_FIELD_NUMBER:I = 0x2

.field public static final LANGUAGEPREFERRED_FIELD_NUMBER:I = 0x1

.field public static final ONLINE_FIELD_NUMBER:I = 0x6

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$NavigatorProps;",
            ">;"
        }
    .end annotation
.end field

.field public static final PLATFORM_FIELD_NUMBER:I = 0x3

.field public static final TOUCHPOINTS_FIELD_NUMBER:I = 0x7


# instance fields
.field private concurrency_:I

.field private doNotTrack_:Z

.field private langaugesKnown_:Ljava/lang/String;

.field private languagePreferred_:Ljava/lang/String;

.field private online_:Z

.field private platform_:Ljava/lang/String;

.field private touchPoints_:I


# direct methods
.method static bridge synthetic -$$Nest$mclearConcurrency(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->clearConcurrency()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearDoNotTrack(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->clearDoNotTrack()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLangaugesKnown(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->clearLangaugesKnown()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLanguagePreferred(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->clearLanguagePreferred()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearOnline(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->clearOnline()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPlatform(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->clearPlatform()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearTouchPoints(Lcom/vdocipher/PlaybackSession$NavigatorProps;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->clearTouchPoints()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetConcurrency(Lcom/vdocipher/PlaybackSession$NavigatorProps;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->setConcurrency(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDoNotTrack(Lcom/vdocipher/PlaybackSession$NavigatorProps;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->setDoNotTrack(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLangaugesKnown(Lcom/vdocipher/PlaybackSession$NavigatorProps;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->setLangaugesKnown(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLangaugesKnownBytes(Lcom/vdocipher/PlaybackSession$NavigatorProps;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->setLangaugesKnownBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLanguagePreferred(Lcom/vdocipher/PlaybackSession$NavigatorProps;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->setLanguagePreferred(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLanguagePreferredBytes(Lcom/vdocipher/PlaybackSession$NavigatorProps;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->setLanguagePreferredBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetOnline(Lcom/vdocipher/PlaybackSession$NavigatorProps;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->setOnline(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPlatform(Lcom/vdocipher/PlaybackSession$NavigatorProps;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->setPlatform(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPlatformBytes(Lcom/vdocipher/PlaybackSession$NavigatorProps;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->setPlatformBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTouchPoints(Lcom/vdocipher/PlaybackSession$NavigatorProps;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->setTouchPoints(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 5078
    new-instance v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;-><init>()V

    .line 5081
    sput-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    .line 5082
    const-class v1, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 4410
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 4411
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->languagePreferred_:Ljava/lang/String;

    .line 4412
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->langaugesKnown_:Ljava/lang/String;

    .line 4413
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->platform_:Ljava/lang/String;

    return-void
.end method

.method private clearConcurrency()V
    .registers 2

    const/4 v0, 0x0

    .line 4579
    iput v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->concurrency_:I

    return-void
.end method

.method private clearDoNotTrack()V
    .registers 2

    const/4 v0, 0x0

    .line 4605
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->doNotTrack_:Z

    return-void
.end method

.method private clearLangaugesKnown()V
    .registers 2

    .line 4496
    invoke-static {}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$NavigatorProps;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getLangaugesKnown()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->langaugesKnown_:Ljava/lang/String;

    return-void
.end method

.method private clearLanguagePreferred()V
    .registers 2

    .line 4449
    invoke-static {}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$NavigatorProps;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getLanguagePreferred()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->languagePreferred_:Ljava/lang/String;

    return-void
.end method

.method private clearOnline()V
    .registers 2

    const/4 v0, 0x0

    .line 4631
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->online_:Z

    return-void
.end method

.method private clearPlatform()V
    .registers 2

    .line 4543
    invoke-static {}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$NavigatorProps;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getPlatform()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->platform_:Ljava/lang/String;

    return-void
.end method

.method private clearTouchPoints()V
    .registers 2

    const/4 v0, 0x0

    .line 4657
    iput v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->touchPoints_:I

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 1

    .line 5087
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 1

    .line 4737
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$NavigatorProps;)Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;
    .registers 2

    .line 4740
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 4713
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 4720
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 4676
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 4683
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 4725
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 4732
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 4700
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 4707
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 4663
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 4670
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 4688
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 4695
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$NavigatorProps;",
            ">;"
        }
    .end annotation

    .line 5093
    sget-object v0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setConcurrency(I)V
    .registers 2

    .line 4572
    iput p1, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->concurrency_:I

    return-void
.end method

.method private setDoNotTrack(Z)V
    .registers 2

    .line 4598
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->doNotTrack_:Z

    return-void
.end method

.method private setLangaugesKnown(Ljava/lang/String;)V
    .registers 2

    .line 4487
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4489
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->langaugesKnown_:Ljava/lang/String;

    return-void
.end method

.method private setLangaugesKnownBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 4504
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 4505
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->langaugesKnown_:Ljava/lang/String;

    return-void
.end method

.method private setLanguagePreferred(Ljava/lang/String;)V
    .registers 2

    .line 4440
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4442
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->languagePreferred_:Ljava/lang/String;

    return-void
.end method

.method private setLanguagePreferredBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 4457
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 4458
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->languagePreferred_:Ljava/lang/String;

    return-void
.end method

.method private setOnline(Z)V
    .registers 2

    .line 4624
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->online_:Z

    return-void
.end method

.method private setPlatform(Ljava/lang/String;)V
    .registers 2

    .line 4534
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4536
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->platform_:Ljava/lang/String;

    return-void
.end method

.method private setPlatformBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 4551
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 4552
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->platform_:Ljava/lang/String;

    return-void
.end method

.method private setTouchPoints(I)V
    .registers 2

    .line 4650
    iput p1, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->touchPoints_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    .line 5023
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_60

    .line 5071
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 5065
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 5050
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$NavigatorProps;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_33

    .line 5052
    const-class p2, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    monitor-enter p2

    .line 5053
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$NavigatorProps;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 5055
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 5058
    sput-object p1, Lcom/vdocipher/PlaybackSession$NavigatorProps;->PARSER:Lcom/google/protobuf/Parser;

    .line 5060
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception v0

    move-object p1, v0

    monitor-exit p2
    :try_end_32
    .catchall {:try_start_20 .. :try_end_32} :catchall_2f

    throw p1

    :cond_33
    return-object p1

    .line 5047
    :pswitch_34  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    return-object p1

    .line 5031
    :pswitch_37  #0x3
    const-string v0, "languagePreferred_"

    const-string v1, "langaugesKnown_"

    const-string v2, "platform_"

    const-string v3, "concurrency_"

    const-string v4, "doNotTrack_"

    const-string v5, "online_"

    const-string/jumbo v6, "touchPoints_"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/Object;

    move-result-object p1

    .line 5040
    const-string p2, "\u0000\u0007\u0000\u0000\u0001\u0007\u0007\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004\u000b\u0005\u0007\u0006\u0007\u0007\u000b"

    .line 5043
    sget-object p3, Lcom/vdocipher/PlaybackSession$NavigatorProps;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 5028
    :pswitch_53  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 5025
    :pswitch_59  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps;-><init>()V

    return-object p1

    nop

    :pswitch_data_60
    .packed-switch 0x1
        :pswitch_59  #00000001
        :pswitch_53  #00000002
        :pswitch_37  #00000003
        :pswitch_34  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getConcurrency()I
    .registers 2

    .line 4564
    iget v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->concurrency_:I

    return v0
.end method

.method public getDoNotTrack()Z
    .registers 2

    .line 4590
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->doNotTrack_:Z

    return v0
.end method

.method public getLangaugesKnown()Ljava/lang/String;
    .registers 2

    .line 4470
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->langaugesKnown_:Ljava/lang/String;

    return-object v0
.end method

.method public getLangaugesKnownBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 4479
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->langaugesKnown_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getLanguagePreferred()Ljava/lang/String;
    .registers 2

    .line 4423
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->languagePreferred_:Ljava/lang/String;

    return-object v0
.end method

.method public getLanguagePreferredBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 4432
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->languagePreferred_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getOnline()Z
    .registers 2

    .line 4616
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->online_:Z

    return v0
.end method

.method public getPlatform()Ljava/lang/String;
    .registers 2

    .line 4517
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->platform_:Ljava/lang/String;

    return-object v0
.end method

.method public getPlatformBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 4526
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->platform_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getTouchPoints()I
    .registers 2

    .line 4642
    iget v0, p0, Lcom/vdocipher/PlaybackSession$NavigatorProps;->touchPoints_:I

    return v0
.end method
