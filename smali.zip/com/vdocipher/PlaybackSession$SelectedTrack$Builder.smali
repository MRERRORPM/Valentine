# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$SelectedTrackOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$SelectedTrack;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$SelectedTrack;",
        "Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$SelectedTrackOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 9880
    invoke-static {}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$SelectedTrack;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearAudio()Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;
    .registers 2

    .line 9926
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->copyOnWrite()V

    .line 9927
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->-$$Nest$mclearAudio(Lcom/vdocipher/PlaybackSession$SelectedTrack;)V

    return-object p0
.end method

.method public clearVideo()Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;
    .registers 2

    .line 9973
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->copyOnWrite()V

    .line 9974
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->-$$Nest$mclearVideo(Lcom/vdocipher/PlaybackSession$SelectedTrack;)V

    return-object p0
.end method

.method public getAudio()Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 2

    .line 9896
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->getAudio()Lcom/vdocipher/PlaybackSession$TrackAudio;

    move-result-object v0

    return-object v0
.end method

.method public getVideo()Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 2

    .line 9943
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->getVideo()Lcom/vdocipher/PlaybackSession$TrackVideo;

    move-result-object v0

    return-object v0
.end method

.method public hasAudio()Z
    .registers 2

    .line 9889
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->hasAudio()Z

    move-result v0

    return v0
.end method

.method public hasVideo()Z
    .registers 2

    .line 9936
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->hasVideo()Z

    move-result v0

    return v0
.end method

.method public mergeAudio(Lcom/vdocipher/PlaybackSession$TrackAudio;)Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;
    .registers 3

    .line 9919
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->copyOnWrite()V

    .line 9920
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->-$$Nest$mmergeAudio(Lcom/vdocipher/PlaybackSession$SelectedTrack;Lcom/vdocipher/PlaybackSession$TrackAudio;)V

    return-object p0
.end method

.method public mergeVideo(Lcom/vdocipher/PlaybackSession$TrackVideo;)Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;
    .registers 3

    .line 9966
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->copyOnWrite()V

    .line 9967
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->-$$Nest$mmergeVideo(Lcom/vdocipher/PlaybackSession$SelectedTrack;Lcom/vdocipher/PlaybackSession$TrackVideo;)V

    return-object p0
.end method

.method public setAudio(Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;)Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;
    .registers 3

    .line 9911
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->copyOnWrite()V

    .line 9912
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->-$$Nest$msetAudio(Lcom/vdocipher/PlaybackSession$SelectedTrack;Lcom/vdocipher/PlaybackSession$TrackAudio;)V

    return-object p0
.end method

.method public setAudio(Lcom/vdocipher/PlaybackSession$TrackAudio;)Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;
    .registers 3

    .line 9902
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->copyOnWrite()V

    .line 9903
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->-$$Nest$msetAudio(Lcom/vdocipher/PlaybackSession$SelectedTrack;Lcom/vdocipher/PlaybackSession$TrackAudio;)V

    return-object p0
.end method

.method public setVideo(Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;)Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;
    .registers 3

    .line 9958
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->copyOnWrite()V

    .line 9959
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$TrackVideo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->-$$Nest$msetVideo(Lcom/vdocipher/PlaybackSession$SelectedTrack;Lcom/vdocipher/PlaybackSession$TrackVideo;)V

    return-object p0
.end method

.method public setVideo(Lcom/vdocipher/PlaybackSession$TrackVideo;)Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;
    .registers 3

    .line 9949
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->copyOnWrite()V

    .line 9950
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->-$$Nest$msetVideo(Lcom/vdocipher/PlaybackSession$SelectedTrack;Lcom/vdocipher/PlaybackSession$TrackVideo;)V

    return-object p0
.end method
