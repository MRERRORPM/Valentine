# classes14.dex

.class public final Lcom/vdocipher/Manifest$Role$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$RoleOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest$Role;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/Manifest$Role;",
        "Lcom/vdocipher/Manifest$Role$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$RoleOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 5788
    invoke-static {}, Lcom/vdocipher/Manifest$Role;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$Role;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/Manifest-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Role$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearSchemeIdUri()Lcom/vdocipher/Manifest$Role$Builder;
    .registers 2

    .line 5825
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Role$Builder;->copyOnWrite()V

    .line 5826
    iget-object v0, p0, Lcom/vdocipher/Manifest$Role$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Role;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Role;->-$$Nest$mclearSchemeIdUri(Lcom/vdocipher/Manifest$Role;)V

    return-object p0
.end method

.method public clearValue()Lcom/vdocipher/Manifest$Role$Builder;
    .registers 2

    .line 5874
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Role$Builder;->copyOnWrite()V

    .line 5875
    iget-object v0, p0, Lcom/vdocipher/Manifest$Role$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Role;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Role;->-$$Nest$mclearValue(Lcom/vdocipher/Manifest$Role;)V

    return-object p0
.end method

.method public getSchemeIdUri()Ljava/lang/String;
    .registers 2

    .line 5798
    iget-object v0, p0, Lcom/vdocipher/Manifest$Role$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Role;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Role;->getSchemeIdUri()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getSchemeIdUriBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 5807
    iget-object v0, p0, Lcom/vdocipher/Manifest$Role$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Role;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Role;->getSchemeIdUriBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getValue()Ljava/lang/String;
    .registers 2

    .line 5847
    iget-object v0, p0, Lcom/vdocipher/Manifest$Role$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Role;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Role;->getValue()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getValueBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 5856
    iget-object v0, p0, Lcom/vdocipher/Manifest$Role$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Role;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Role;->getValueBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setSchemeIdUri(Ljava/lang/String;)Lcom/vdocipher/Manifest$Role$Builder;
    .registers 3

    .line 5816
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Role$Builder;->copyOnWrite()V

    .line 5817
    iget-object v0, p0, Lcom/vdocipher/Manifest$Role$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Role;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Role;->-$$Nest$msetSchemeIdUri(Lcom/vdocipher/Manifest$Role;Ljava/lang/String;)V

    return-object p0
.end method

.method public setSchemeIdUriBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$Role$Builder;
    .registers 3

    .line 5836
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Role$Builder;->copyOnWrite()V

    .line 5837
    iget-object v0, p0, Lcom/vdocipher/Manifest$Role$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Role;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Role;->-$$Nest$msetSchemeIdUriBytes(Lcom/vdocipher/Manifest$Role;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setValue(Ljava/lang/String;)Lcom/vdocipher/Manifest$Role$Builder;
    .registers 3

    .line 5865
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Role$Builder;->copyOnWrite()V

    .line 5866
    iget-object v0, p0, Lcom/vdocipher/Manifest$Role$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Role;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Role;->-$$Nest$msetValue(Lcom/vdocipher/Manifest$Role;Ljava/lang/String;)V

    return-object p0
.end method

.method public setValueBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$Role$Builder;
    .registers 3

    .line 5885
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Role$Builder;->copyOnWrite()V

    .line 5886
    iget-object v0, p0, Lcom/vdocipher/Manifest$Role$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Role;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Role;->-$$Nest$msetValueBytes(Lcom/vdocipher/Manifest$Role;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
