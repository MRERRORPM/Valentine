# classes14.dex

.class public final Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$AudioChannelConfigurationOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest$AudioChannelConfiguration;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/Manifest$AudioChannelConfiguration;",
        "Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$AudioChannelConfigurationOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 1468
    invoke-static {}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/Manifest-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearSchemeIdUri()Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;
    .registers 2

    .line 1505
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->copyOnWrite()V

    .line 1506
    iget-object v0, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->-$$Nest$mclearSchemeIdUri(Lcom/vdocipher/Manifest$AudioChannelConfiguration;)V

    return-object p0
.end method

.method public clearValue()Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;
    .registers 2

    .line 1544
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->copyOnWrite()V

    .line 1545
    iget-object v0, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->-$$Nest$mclearValue(Lcom/vdocipher/Manifest$AudioChannelConfiguration;)V

    return-object p0
.end method

.method public getSchemeIdUri()Ljava/lang/String;
    .registers 2

    .line 1478
    iget-object v0, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->getSchemeIdUri()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getSchemeIdUriBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 1487
    iget-object v0, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->getSchemeIdUriBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getValue()I
    .registers 2

    .line 1527
    iget-object v0, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->getValue()I

    move-result v0

    return v0
.end method

.method public setSchemeIdUri(Ljava/lang/String;)Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;
    .registers 3

    .line 1496
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->copyOnWrite()V

    .line 1497
    iget-object v0, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->-$$Nest$msetSchemeIdUri(Lcom/vdocipher/Manifest$AudioChannelConfiguration;Ljava/lang/String;)V

    return-object p0
.end method

.method public setSchemeIdUriBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;
    .registers 3

    .line 1516
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->copyOnWrite()V

    .line 1517
    iget-object v0, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->-$$Nest$msetSchemeIdUriBytes(Lcom/vdocipher/Manifest$AudioChannelConfiguration;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setValue(I)Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;
    .registers 3

    .line 1535
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->copyOnWrite()V

    .line 1536
    iget-object v0, p0, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AudioChannelConfiguration;->-$$Nest$msetValue(Lcom/vdocipher/Manifest$AudioChannelConfiguration;I)V

    return-object p0
.end method
