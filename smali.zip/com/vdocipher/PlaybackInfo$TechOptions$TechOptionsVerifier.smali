# classes14.dex

.class final Lcom/vdocipher/PlaybackInfo$TechOptions$TechOptionsVerifier;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumVerifier;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$TechOptions;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "TechOptionsVerifier"
.end annotation


# static fields
.field static final INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 719
    new-instance v0, Lcom/vdocipher/PlaybackInfo$TechOptions$TechOptionsVerifier;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$TechOptions$TechOptionsVerifier;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$TechOptions$TechOptionsVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 717
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public isInRange(I)Z
    .registers 2

    .line 722
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$TechOptions;->forNumber(I)Lcom/vdocipher/PlaybackInfo$TechOptions;

    move-result-object p1

    if-eqz p1, :cond_8

    const/4 p1, 0x1

    return p1

    :cond_8
    const/4 p1, 0x0

    return p1
.end method
