# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$H6$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$H6OrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$H6;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackInfo$H6;",
        "Lcom/vdocipher/PlaybackInfo$H6$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$H6OrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 9433
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$H6;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$H6;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackInfo-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$H6$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearManifest()Lcom/vdocipher/PlaybackInfo$H6$Builder;
    .registers 2

    .line 9460
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$H6$Builder;->copyOnWrite()V

    .line 9461
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$H6$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$H6;->-$$Nest$mclearManifest(Lcom/vdocipher/PlaybackInfo$H6;)V

    return-object p0
.end method

.method public getManifest()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9443
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$H6$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$H6;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$H6;->getManifest()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setManifest(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$H6$Builder;
    .registers 3

    .line 9451
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$H6$Builder;->copyOnWrite()V

    .line 9452
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$H6$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$H6;->-$$Nest$msetManifest(Lcom/vdocipher/PlaybackInfo$H6;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
