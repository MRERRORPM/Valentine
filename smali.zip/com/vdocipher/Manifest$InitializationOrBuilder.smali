# classes14.dex

.class public interface abstract Lcom/vdocipher/Manifest$InitializationOrBuilder;
.super Ljava/lang/Object;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "InitializationOrBuilder"
.end annotation


# virtual methods
.method public abstract getEnd()I
.end method

.method public abstract getStart()I
.end method
