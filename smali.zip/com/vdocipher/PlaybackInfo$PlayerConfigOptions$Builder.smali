# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$PlayerConfigOptionsOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;",
        "Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$PlayerConfigOptionsOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 3941
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackInfo-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public addAllCollapseInSettings(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$CollapseSettings;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;"
        }
    .end annotation

    .line 4936
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4937
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$maddAllCollapseInSettings(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllCollapseInSettingsValue(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/Integer;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;"
        }
    .end annotation

    .line 4996
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4997
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$maddAllCollapseInSettingsValue(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllPlaybackSpeedOptions(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Ljava/lang/Double;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;"
        }
    .end annotation

    .line 4392
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4393
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$maddAllPlaybackSpeedOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addCollapseInSettings(Lcom/vdocipher/PlaybackInfo$CollapseSettings;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4925
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4926
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$maddCollapseInSettings(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$CollapseSettings;)V

    return-object p0
.end method

.method public addCollapseInSettingsValue(I)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4985
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4986
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$maddCollapseInSettingsValue(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;I)V

    return-object p0
.end method

.method public addPlaybackSpeedOptions(D)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 4

    .line 4381
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4382
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$maddPlaybackSpeedOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;D)V

    return-object p0
.end method

.method public clearCaptionGlobalStyles()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 5322
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5323
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearCaptionGlobalStyles(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearCaptionScaleFactor()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4877
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4878
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearCaptionScaleFactor(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearCollapseInSettings()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4944
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4945
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearCollapseInSettings(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearConfirmBeforeAutoResume()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4849
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4850
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearConfirmBeforeAutoResume(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearConserveQualityAcrossSession()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4765
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4766
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearConserveQualityAcrossSession(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearConserveSelectedCaptionLanguage()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4821
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4822
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearConserveSelectedCaptionLanguage(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearConserveSpeedAcrossSession()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4793
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4794
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearConserveSpeedAcrossSession(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearConserveVolumeAcrossSession()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4737
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4738
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearConserveVolumeAcrossSession(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearEnableAboutPlayer()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 5024
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5025
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearEnableAboutPlayer(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearEnableAirPlay()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4276
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4277
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearEnableAirPlay(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearEnableAutoResumeLocal()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4709
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4710
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearEnableAutoResumeLocal(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearEnableCaptionSearch()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4485
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4486
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearEnableCaptionSearch(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearEnableChapters()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 5172
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5173
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearEnableChapters(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearEnableChromecast()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4304
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4305
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearEnableChromecast(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearEnableDoubleTapSkip()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4625
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4626
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearEnableDoubleTapSkip(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearEnableKeyboardShortcuts()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4681
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4682
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearEnableKeyboardShortcuts(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearEnableLockControls()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4541
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4542
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearEnableLockControls(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearEnablePiP()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4457
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4458
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearEnablePiP(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearEnableReportBug()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 5052
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5053
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearEnableReportBug(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearEnableSaveOffline()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4653
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4654
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearEnableSaveOffline(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearHideContextMenu()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4569
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4570
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearHideContextMenu(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearHideControlsOnPause()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4332
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4333
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearHideControlsOnPause(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearInitialDurationPosition()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 5144
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5145
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearInitialDurationPosition(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearInitialPlayButtonShape()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 5098
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5099
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearInitialPlayButtonShape(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearPlaybackSpeedOptions()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4401
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4402
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearPlaybackSpeedOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearPrimaryColor()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 3968
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 3969
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearPrimaryColor(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearQualityTrackLabels()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 5275
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5276
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearQualityTrackLabels(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearShowBackward()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4248
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4249
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearShowBackward(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearShowCaptionsControl()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4136
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4137
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearShowCaptionsControl(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearShowCastWhenDeviceReady()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 5200
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5201
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearShowCastWhenDeviceReady(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearShowClearStorageOption()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 5228
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5229
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearShowClearStorageOption(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearShowForward()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4220
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4221
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearShowForward(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearShowFullScreen()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4164
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4165
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearShowFullScreen(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearShowPlayPauseBtn()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4024
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4025
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearShowPlayPauseBtn(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearShowProgressBar()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4052
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4053
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearShowProgressBar(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearShowQualityControl()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4108
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4109
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearShowQualityControl(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearShowReplayAtEnd()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4513
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4514
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearShowReplayAtEnd(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearShowScrubbingPreview()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4597
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4598
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearShowScrubbingPreview(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearShowSpeedControl()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4080
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4081
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearShowSpeedControl(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearShowTimeText()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 3996
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 3997
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearShowTimeText(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearShowVolume()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4192
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4193
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearShowVolume(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public clearSkipDuration()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 4429
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4430
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mclearSkipDuration(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-object p0
.end method

.method public getCaptionGlobalStyles()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 2

    .line 5292
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getCaptionGlobalStyles()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    move-result-object v0

    return-object v0
.end method

.method public getCaptionScaleFactor()I
    .registers 2

    .line 4860
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getCaptionScaleFactor()I

    move-result v0

    return v0
.end method

.method public getCollapseInSettings(I)Lcom/vdocipher/PlaybackInfo$CollapseSettings;
    .registers 3

    .line 4905
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getCollapseInSettings(I)Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    move-result-object p1

    return-object p1
.end method

.method public getCollapseInSettingsCount()I
    .registers 2

    .line 4896
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getCollapseInSettingsCount()I

    move-result v0

    return v0
.end method

.method public getCollapseInSettingsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$CollapseSettings;",
            ">;"
        }
    .end annotation

    .line 4888
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getCollapseInSettingsList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getCollapseInSettingsValue(I)I
    .registers 3

    .line 4965
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getCollapseInSettingsValue(I)I

    move-result p1

    return p1
.end method

.method public getCollapseInSettingsValueList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 4955
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    .line 4956
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getCollapseInSettingsValueList()Ljava/util/List;

    move-result-object v0

    .line 4955
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getConfirmBeforeAutoResume()Z
    .registers 2

    .line 4832
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getConfirmBeforeAutoResume()Z

    move-result v0

    return v0
.end method

.method public getConserveQualityAcrossSession()Z
    .registers 2

    .line 4748
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getConserveQualityAcrossSession()Z

    move-result v0

    return v0
.end method

.method public getConserveSelectedCaptionLanguage()Z
    .registers 2

    .line 4804
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getConserveSelectedCaptionLanguage()Z

    move-result v0

    return v0
.end method

.method public getConserveSpeedAcrossSession()Z
    .registers 2

    .line 4776
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getConserveSpeedAcrossSession()Z

    move-result v0

    return v0
.end method

.method public getConserveVolumeAcrossSession()Z
    .registers 2

    .line 4720
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getConserveVolumeAcrossSession()Z

    move-result v0

    return v0
.end method

.method public getEnableAboutPlayer()Z
    .registers 2

    .line 5007
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getEnableAboutPlayer()Z

    move-result v0

    return v0
.end method

.method public getEnableAirPlay()Z
    .registers 2

    .line 4259
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getEnableAirPlay()Z

    move-result v0

    return v0
.end method

.method public getEnableAutoResumeLocal()Z
    .registers 2

    .line 4692
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getEnableAutoResumeLocal()Z

    move-result v0

    return v0
.end method

.method public getEnableCaptionSearch()Z
    .registers 2

    .line 4468
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getEnableCaptionSearch()Z

    move-result v0

    return v0
.end method

.method public getEnableChapters()Z
    .registers 2

    .line 5155
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getEnableChapters()Z

    move-result v0

    return v0
.end method

.method public getEnableChromecast()Z
    .registers 2

    .line 4287
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getEnableChromecast()Z

    move-result v0

    return v0
.end method

.method public getEnableDoubleTapSkip()Z
    .registers 2

    .line 4608
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getEnableDoubleTapSkip()Z

    move-result v0

    return v0
.end method

.method public getEnableKeyboardShortcuts()Z
    .registers 2

    .line 4664
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getEnableKeyboardShortcuts()Z

    move-result v0

    return v0
.end method

.method public getEnableLockControls()Z
    .registers 2

    .line 4524
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getEnableLockControls()Z

    move-result v0

    return v0
.end method

.method public getEnablePiP()Z
    .registers 2

    .line 4440
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getEnablePiP()Z

    move-result v0

    return v0
.end method

.method public getEnableReportBug()Z
    .registers 2

    .line 5035
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getEnableReportBug()Z

    move-result v0

    return v0
.end method

.method public getEnableSaveOffline()Z
    .registers 2

    .line 4636
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getEnableSaveOffline()Z

    move-result v0

    return v0
.end method

.method public getHideContextMenu()Z
    .registers 2

    .line 4552
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getHideContextMenu()Z

    move-result v0

    return v0
.end method

.method public getHideControlsOnPause()Z
    .registers 2

    .line 4315
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getHideControlsOnPause()Z

    move-result v0

    return v0
.end method

.method public getInitialDurationPosition()Lcom/vdocipher/PlaybackInfo$ElementPosition;
    .registers 2

    .line 5127
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getInitialDurationPosition()Lcom/vdocipher/PlaybackInfo$ElementPosition;

    move-result-object v0

    return-object v0
.end method

.method public getInitialDurationPositionValue()I
    .registers 2

    .line 5109
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getInitialDurationPositionValue()I

    move-result v0

    return v0
.end method

.method public getInitialPlayButtonShape()Lcom/vdocipher/PlaybackInfo$PlayButtonShape;
    .registers 2

    .line 5081
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getInitialPlayButtonShape()Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    move-result-object v0

    return-object v0
.end method

.method public getInitialPlayButtonShapeValue()I
    .registers 2

    .line 5063
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getInitialPlayButtonShapeValue()I

    move-result v0

    return v0
.end method

.method public getPlaybackSpeedOptions(I)D
    .registers 4

    .line 4362
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getPlaybackSpeedOptions(I)D

    move-result-wide v0

    return-wide v0
.end method

.method public getPlaybackSpeedOptionsCount()I
    .registers 2

    .line 4353
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getPlaybackSpeedOptionsCount()I

    move-result v0

    return v0
.end method

.method public getPlaybackSpeedOptionsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Double;",
            ">;"
        }
    .end annotation

    .line 4344
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    .line 4345
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getPlaybackSpeedOptionsList()Ljava/util/List;

    move-result-object v0

    .line 4344
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getPrimaryColor()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 3951
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getPrimaryColor()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getQualityTrackLabels()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 2

    .line 5245
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getQualityTrackLabels()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    move-result-object v0

    return-object v0
.end method

.method public getShowBackward()Z
    .registers 2

    .line 4231
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getShowBackward()Z

    move-result v0

    return v0
.end method

.method public getShowCaptionsControl()Z
    .registers 2

    .line 4119
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getShowCaptionsControl()Z

    move-result v0

    return v0
.end method

.method public getShowCastWhenDeviceReady()Z
    .registers 2

    .line 5183
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getShowCastWhenDeviceReady()Z

    move-result v0

    return v0
.end method

.method public getShowClearStorageOption()Z
    .registers 2

    .line 5211
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getShowClearStorageOption()Z

    move-result v0

    return v0
.end method

.method public getShowForward()Z
    .registers 2

    .line 4203
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getShowForward()Z

    move-result v0

    return v0
.end method

.method public getShowFullScreen()Z
    .registers 2

    .line 4147
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getShowFullScreen()Z

    move-result v0

    return v0
.end method

.method public getShowPlayPauseBtn()Z
    .registers 2

    .line 4007
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getShowPlayPauseBtn()Z

    move-result v0

    return v0
.end method

.method public getShowProgressBar()Z
    .registers 2

    .line 4035
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getShowProgressBar()Z

    move-result v0

    return v0
.end method

.method public getShowQualityControl()Z
    .registers 2

    .line 4091
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getShowQualityControl()Z

    move-result v0

    return v0
.end method

.method public getShowReplayAtEnd()Z
    .registers 2

    .line 4496
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getShowReplayAtEnd()Z

    move-result v0

    return v0
.end method

.method public getShowScrubbingPreview()Z
    .registers 2

    .line 4580
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getShowScrubbingPreview()Z

    move-result v0

    return v0
.end method

.method public getShowSpeedControl()Z
    .registers 2

    .line 4063
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getShowSpeedControl()Z

    move-result v0

    return v0
.end method

.method public getShowTimeText()Z
    .registers 2

    .line 3979
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getShowTimeText()Z

    move-result v0

    return v0
.end method

.method public getShowVolume()Z
    .registers 2

    .line 4175
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getShowVolume()Z

    move-result v0

    return v0
.end method

.method public getSkipDuration()I
    .registers 2

    .line 4412
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getSkipDuration()I

    move-result v0

    return v0
.end method

.method public hasCaptionGlobalStyles()Z
    .registers 2

    .line 5285
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->hasCaptionGlobalStyles()Z

    move-result v0

    return v0
.end method

.method public hasQualityTrackLabels()Z
    .registers 2

    .line 5238
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->hasQualityTrackLabels()Z

    move-result v0

    return v0
.end method

.method public mergeCaptionGlobalStyles(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 5315
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5316
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mmergeCaptionGlobalStyles(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V

    return-object p0
.end method

.method public mergeQualityTrackLabels(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 5268
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5269
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$mmergeQualityTrackLabels(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)V

    return-object p0
.end method

.method public setCaptionGlobalStyles(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 5307
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5308
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetCaptionGlobalStyles(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V

    return-object p0
.end method

.method public setCaptionGlobalStyles(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 5298
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5299
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetCaptionGlobalStyles(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V

    return-object p0
.end method

.method public setCaptionScaleFactor(I)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4868
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4869
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetCaptionScaleFactor(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;I)V

    return-object p0
.end method

.method public setCollapseInSettings(ILcom/vdocipher/PlaybackInfo$CollapseSettings;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 4

    .line 4915
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4916
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetCollapseInSettings(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;ILcom/vdocipher/PlaybackInfo$CollapseSettings;)V

    return-object p0
.end method

.method public setCollapseInSettingsValue(II)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 4

    .line 4975
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4976
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetCollapseInSettingsValue(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;II)V

    return-object p0
.end method

.method public setConfirmBeforeAutoResume(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4840
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4841
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetConfirmBeforeAutoResume(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setConserveQualityAcrossSession(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4756
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4757
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetConserveQualityAcrossSession(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setConserveSelectedCaptionLanguage(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4812
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4813
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetConserveSelectedCaptionLanguage(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setConserveSpeedAcrossSession(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4784
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4785
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetConserveSpeedAcrossSession(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setConserveVolumeAcrossSession(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4728
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4729
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetConserveVolumeAcrossSession(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setEnableAboutPlayer(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 5015
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5016
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetEnableAboutPlayer(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setEnableAirPlay(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4267
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4268
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetEnableAirPlay(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setEnableAutoResumeLocal(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4700
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4701
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetEnableAutoResumeLocal(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setEnableCaptionSearch(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4476
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4477
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetEnableCaptionSearch(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setEnableChapters(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 5163
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5164
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetEnableChapters(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setEnableChromecast(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4295
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4296
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetEnableChromecast(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setEnableDoubleTapSkip(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4616
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4617
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetEnableDoubleTapSkip(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setEnableKeyboardShortcuts(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4672
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4673
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetEnableKeyboardShortcuts(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setEnableLockControls(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4532
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4533
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetEnableLockControls(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setEnablePiP(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4448
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4449
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetEnablePiP(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setEnableReportBug(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 5043
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5044
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetEnableReportBug(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setEnableSaveOffline(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4644
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4645
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetEnableSaveOffline(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setHideContextMenu(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4560
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4561
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetHideContextMenu(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setHideControlsOnPause(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4323
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4324
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetHideControlsOnPause(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setInitialDurationPosition(Lcom/vdocipher/PlaybackInfo$ElementPosition;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 5135
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5136
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetInitialDurationPosition(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$ElementPosition;)V

    return-object p0
.end method

.method public setInitialDurationPositionValue(I)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 5117
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5118
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetInitialDurationPositionValue(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;I)V

    return-object p0
.end method

.method public setInitialPlayButtonShape(Lcom/vdocipher/PlaybackInfo$PlayButtonShape;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 5089
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5090
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetInitialPlayButtonShape(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$PlayButtonShape;)V

    return-object p0
.end method

.method public setInitialPlayButtonShapeValue(I)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 5071
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5072
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetInitialPlayButtonShapeValue(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;I)V

    return-object p0
.end method

.method public setPlaybackSpeedOptions(ID)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 5

    .line 4371
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4372
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1, p2, p3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetPlaybackSpeedOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;ID)V

    return-object p0
.end method

.method public setPrimaryColor(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 3959
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 3960
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetPrimaryColor(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setQualityTrackLabels(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 5260
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5261
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetQualityTrackLabels(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)V

    return-object p0
.end method

.method public setQualityTrackLabels(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 5251
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5252
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetQualityTrackLabels(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)V

    return-object p0
.end method

.method public setShowBackward(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4239
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4240
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetShowBackward(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setShowCaptionsControl(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4127
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4128
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetShowCaptionsControl(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setShowCastWhenDeviceReady(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 5191
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5192
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetShowCastWhenDeviceReady(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setShowClearStorageOption(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 5219
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 5220
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetShowClearStorageOption(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setShowForward(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4211
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4212
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetShowForward(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setShowFullScreen(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4155
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4156
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetShowFullScreen(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setShowPlayPauseBtn(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4015
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4016
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetShowPlayPauseBtn(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setShowProgressBar(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4043
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4044
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetShowProgressBar(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setShowQualityControl(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4099
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4100
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetShowQualityControl(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setShowReplayAtEnd(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4504
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4505
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetShowReplayAtEnd(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setShowScrubbingPreview(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4588
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4589
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetShowScrubbingPreview(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setShowSpeedControl(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4071
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4072
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetShowSpeedControl(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setShowTimeText(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 3987
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 3988
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetShowTimeText(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setShowVolume(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4183
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4184
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetShowVolume(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V

    return-object p0
.end method

.method public setSkipDuration(I)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 3

    .line 4420
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->copyOnWrite()V

    .line 4421
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->-$$Nest$msetSkipDuration(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;I)V

    return-object p0
.end method
