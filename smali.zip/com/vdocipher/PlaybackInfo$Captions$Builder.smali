# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$Captions$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$CaptionsOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$Captions;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackInfo$Captions;",
        "Lcom/vdocipher/PlaybackInfo$Captions$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$CaptionsOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 6332
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$Captions;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackInfo-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearCaptionName()Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 2

    .line 6560
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6561
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$mclearCaptionName(Lcom/vdocipher/PlaybackInfo$Captions;)V

    return-object p0
.end method

.method public clearIsDefault()Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 2

    .line 6514
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6515
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$mclearIsDefault(Lcom/vdocipher/PlaybackInfo$Captions;)V

    return-object p0
.end method

.method public clearLabel()Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 2

    .line 6475
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6476
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$mclearLabel(Lcom/vdocipher/PlaybackInfo$Captions;)V

    return-object p0
.end method

.method public clearLang()Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 2

    .line 6418
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6419
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$mclearLang(Lcom/vdocipher/PlaybackInfo$Captions;)V

    return-object p0
.end method

.method public clearSubtitleName()Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 2

    .line 6609
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6610
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$mclearSubtitleName(Lcom/vdocipher/PlaybackInfo$Captions;)V

    return-object p0
.end method

.method public clearUrl()Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 2

    .line 6369
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6370
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$mclearUrl(Lcom/vdocipher/PlaybackInfo$Captions;)V

    return-object p0
.end method

.method public getCaptionName()Ljava/lang/String;
    .registers 2

    .line 6533
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getCaptionName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getCaptionNameBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 6542
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getCaptionNameBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getIsDefault()Z
    .registers 2

    .line 6497
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getIsDefault()Z

    move-result v0

    return v0
.end method

.method public getLabel()Ljava/lang/String;
    .registers 2

    .line 6448
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getLabel()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getLabelBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 6457
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getLabelBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getLang()Ljava/lang/String;
    .registers 2

    .line 6391
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getLang()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getLangBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 6400
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getLangBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSubtitleName()Ljava/lang/String;
    .registers 2

    .line 6582
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getSubtitleName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getSubtitleNameBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 6591
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getSubtitleNameBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getUrl()Ljava/lang/String;
    .registers 2

    .line 6342
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getUrl()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getUrlBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 6351
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->getUrlBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public hasCaptionName()Z
    .registers 2

    .line 6525
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->hasCaptionName()Z

    move-result v0

    return v0
.end method

.method public hasLabel()Z
    .registers 2

    .line 6440
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Captions;->hasLabel()Z

    move-result v0

    return v0
.end method

.method public setCaptionName(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 3

    .line 6551
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6552
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$msetCaptionName(Lcom/vdocipher/PlaybackInfo$Captions;Ljava/lang/String;)V

    return-object p0
.end method

.method public setCaptionNameBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 3

    .line 6571
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6572
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$msetCaptionNameBytes(Lcom/vdocipher/PlaybackInfo$Captions;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setIsDefault(Z)Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 3

    .line 6505
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6506
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$msetIsDefault(Lcom/vdocipher/PlaybackInfo$Captions;Z)V

    return-object p0
.end method

.method public setLabel(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 3

    .line 6466
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6467
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$msetLabel(Lcom/vdocipher/PlaybackInfo$Captions;Ljava/lang/String;)V

    return-object p0
.end method

.method public setLabelBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 3

    .line 6486
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6487
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$msetLabelBytes(Lcom/vdocipher/PlaybackInfo$Captions;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setLang(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 3

    .line 6409
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6410
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$msetLang(Lcom/vdocipher/PlaybackInfo$Captions;Ljava/lang/String;)V

    return-object p0
.end method

.method public setLangBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 3

    .line 6429
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6430
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$msetLangBytes(Lcom/vdocipher/PlaybackInfo$Captions;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setSubtitleName(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 3

    .line 6600
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6601
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$msetSubtitleName(Lcom/vdocipher/PlaybackInfo$Captions;Ljava/lang/String;)V

    return-object p0
.end method

.method public setSubtitleNameBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 3

    .line 6620
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6621
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$msetSubtitleNameBytes(Lcom/vdocipher/PlaybackInfo$Captions;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setUrl(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 3

    .line 6360
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6361
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$msetUrl(Lcom/vdocipher/PlaybackInfo$Captions;Ljava/lang/String;)V

    return-object p0
.end method

.method public setUrlBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;
    .registers 3

    .line 6380
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->copyOnWrite()V

    .line 6381
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Captions;->-$$Nest$msetUrlBytes(Lcom/vdocipher/PlaybackInfo$Captions;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
