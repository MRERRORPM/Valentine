# classes14.dex

.class public final enum Lcom/vdocipher/PlaybackInfo$QualityLabels;
.super Ljava/lang/Enum;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "QualityLabels"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$QualityLabels$QualityLabelsVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/PlaybackInfo$QualityLabels;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/PlaybackInfo$QualityLabels;

.field public static final enum DIMENSION:Lcom/vdocipher/PlaybackInfo$QualityLabels;

.field public static final DIMENSION_VALUE:I = 0x7

.field public static final enum GB_PER_HOUR:Lcom/vdocipher/PlaybackInfo$QualityLabels;

.field public static final GB_PER_HOUR_VALUE:I = 0x5

.field public static final enum KBPS:Lcom/vdocipher/PlaybackInfo$QualityLabels;

.field public static final KBPS_VALUE:I = 0x4

.field public static final enum MB:Lcom/vdocipher/PlaybackInfo$QualityLabels;

.field public static final MB_VALUE:I = 0x0

.field public static final enum NATURAL:Lcom/vdocipher/PlaybackInfo$QualityLabels;

.field public static final NATURAL_VALUE:I = 0x8

.field public static final enum PIXELS:Lcom/vdocipher/PlaybackInfo$QualityLabels;

.field public static final PIXELS_VALUE:I = 0x6

.field public static final enum ROUNDED_KBPS:Lcom/vdocipher/PlaybackInfo$QualityLabels;

.field public static final ROUNDED_KBPS_VALUE:I = 0x3

.field public static final enum STANDARD_HD:Lcom/vdocipher/PlaybackInfo$QualityLabels;

.field public static final STANDARD_HD_VALUE:I = 0x2

.field public static final enum STANDARD_HQ:Lcom/vdocipher/PlaybackInfo$QualityLabels;

.field public static final STANDARD_HQ_VALUE:I = 0x1

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$QualityLabels;

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackInfo$QualityLabels;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 13

    .line 20
    new-instance v0, Lcom/vdocipher/PlaybackInfo$QualityLabels;

    const-string v1, "MB"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/PlaybackInfo$QualityLabels;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->MB:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 24
    new-instance v1, Lcom/vdocipher/PlaybackInfo$QualityLabels;

    const-string v2, "STANDARD_HQ"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/PlaybackInfo$QualityLabels;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackInfo$QualityLabels;->STANDARD_HQ:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 28
    new-instance v2, Lcom/vdocipher/PlaybackInfo$QualityLabels;

    const-string v3, "STANDARD_HD"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4, v4}, Lcom/vdocipher/PlaybackInfo$QualityLabels;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/PlaybackInfo$QualityLabels;->STANDARD_HD:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 32
    new-instance v3, Lcom/vdocipher/PlaybackInfo$QualityLabels;

    const-string v4, "ROUNDED_KBPS"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5, v5}, Lcom/vdocipher/PlaybackInfo$QualityLabels;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lcom/vdocipher/PlaybackInfo$QualityLabels;->ROUNDED_KBPS:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 36
    new-instance v4, Lcom/vdocipher/PlaybackInfo$QualityLabels;

    const-string v5, "KBPS"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6, v6}, Lcom/vdocipher/PlaybackInfo$QualityLabels;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lcom/vdocipher/PlaybackInfo$QualityLabels;->KBPS:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 40
    new-instance v5, Lcom/vdocipher/PlaybackInfo$QualityLabels;

    const-string v6, "GB_PER_HOUR"

    const/4 v7, 0x5

    invoke-direct {v5, v6, v7, v7}, Lcom/vdocipher/PlaybackInfo$QualityLabels;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lcom/vdocipher/PlaybackInfo$QualityLabels;->GB_PER_HOUR:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 44
    new-instance v6, Lcom/vdocipher/PlaybackInfo$QualityLabels;

    const-string v7, "PIXELS"

    const/4 v8, 0x6

    invoke-direct {v6, v7, v8, v8}, Lcom/vdocipher/PlaybackInfo$QualityLabels;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lcom/vdocipher/PlaybackInfo$QualityLabels;->PIXELS:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 48
    new-instance v7, Lcom/vdocipher/PlaybackInfo$QualityLabels;

    const-string v8, "DIMENSION"

    const/4 v9, 0x7

    invoke-direct {v7, v8, v9, v9}, Lcom/vdocipher/PlaybackInfo$QualityLabels;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lcom/vdocipher/PlaybackInfo$QualityLabels;->DIMENSION:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 52
    new-instance v8, Lcom/vdocipher/PlaybackInfo$QualityLabels;

    const-string v9, "NATURAL"

    const/16 v10, 0x8

    invoke-direct {v8, v9, v10, v10}, Lcom/vdocipher/PlaybackInfo$QualityLabels;-><init>(Ljava/lang/String;II)V

    sput-object v8, Lcom/vdocipher/PlaybackInfo$QualityLabels;->NATURAL:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 53
    new-instance v9, Lcom/vdocipher/PlaybackInfo$QualityLabels;

    const/16 v10, 0x9

    const/4 v11, -0x1

    const-string v12, "UNRECOGNIZED"

    invoke-direct {v9, v12, v10, v11}, Lcom/vdocipher/PlaybackInfo$QualityLabels;-><init>(Ljava/lang/String;II)V

    sput-object v9, Lcom/vdocipher/PlaybackInfo$QualityLabels;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 15
    filled-new-array/range {v0 .. v9}, [Lcom/vdocipher/PlaybackInfo$QualityLabels;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->$VALUES:[Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 133
    new-instance v0, Lcom/vdocipher/PlaybackInfo$QualityLabels$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$QualityLabels$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 157
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 158
    iput p3, p0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/PlaybackInfo$QualityLabels;
    .registers 1

    packed-switch p0, :pswitch_data_20

    const/4 p0, 0x0

    return-object p0

    .line 123
    :pswitch_5  #0x8
    sget-object p0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->NATURAL:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    return-object p0

    .line 122
    :pswitch_8  #0x7
    sget-object p0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->DIMENSION:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    return-object p0

    .line 121
    :pswitch_b  #0x6
    sget-object p0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->PIXELS:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    return-object p0

    .line 120
    :pswitch_e  #0x5
    sget-object p0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->GB_PER_HOUR:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    return-object p0

    .line 119
    :pswitch_11  #0x4
    sget-object p0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->KBPS:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    return-object p0

    .line 118
    :pswitch_14  #0x3
    sget-object p0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->ROUNDED_KBPS:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    return-object p0

    .line 117
    :pswitch_17  #0x2
    sget-object p0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->STANDARD_HD:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    return-object p0

    .line 116
    :pswitch_1a  #0x1
    sget-object p0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->STANDARD_HQ:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    return-object p0

    .line 115
    :pswitch_1d  #0x0
    sget-object p0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->MB:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    return-object p0

    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_1d  #00000000
        :pswitch_1a  #00000001
        :pswitch_17  #00000002
        :pswitch_14  #00000003
        :pswitch_11  #00000004
        :pswitch_e  #00000005
        :pswitch_b  #00000006
        :pswitch_8  #00000007
        :pswitch_5  #00000008
    .end packed-switch
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackInfo$QualityLabels;",
            ">;"
        }
    .end annotation

    .line 130
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 143
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityLabels$QualityLabelsVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/PlaybackInfo$QualityLabels;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 110
    invoke-static {p0}, Lcom/vdocipher/PlaybackInfo$QualityLabels;->forNumber(I)Lcom/vdocipher/PlaybackInfo$QualityLabels;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$QualityLabels;
    .registers 2

    .line 15
    const-class v0, Lcom/vdocipher/PlaybackInfo$QualityLabels;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityLabels;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/PlaybackInfo$QualityLabels;
    .registers 1

    .line 15
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->$VALUES:[Lcom/vdocipher/PlaybackInfo$QualityLabels;

    invoke-virtual {v0}, [Lcom/vdocipher/PlaybackInfo$QualityLabels;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/PlaybackInfo$QualityLabels;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 96
    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    if-eq p0, v0, :cond_7

    .line 100
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->value:I

    return v0

    .line 97
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
