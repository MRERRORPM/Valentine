# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$CaptionGlobalStylesOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;",
        "Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$CaptionGlobalStylesOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 1965
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackInfo-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearBackgroundColor()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;
    .registers 2

    .line 2020
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->copyOnWrite()V

    .line 2021
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->-$$Nest$mclearBackgroundColor(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V

    return-object p0
.end method

.method public clearCaptionMaxFont()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;
    .registers 2

    .line 2097
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->copyOnWrite()V

    .line 2098
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->-$$Nest$mclearCaptionMaxFont(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V

    return-object p0
.end method

.method public clearCaptionScaleFactor()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;
    .registers 2

    .line 2125
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->copyOnWrite()V

    .line 2126
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->-$$Nest$mclearCaptionScaleFactor(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V

    return-object p0
.end method

.method public clearColor()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;
    .registers 2

    .line 1992
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->copyOnWrite()V

    .line 1993
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->-$$Nest$mclearColor(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V

    return-object p0
.end method

.method public clearPadding()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;
    .registers 2

    .line 2058
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->copyOnWrite()V

    .line 2059
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->-$$Nest$mclearPadding(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V

    return-object p0
.end method

.method public getBackgroundColor()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 2003
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getBackgroundColor()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getCaptionMaxFont()F
    .registers 2

    .line 2080
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getCaptionMaxFont()F

    move-result v0

    return v0
.end method

.method public getCaptionScaleFactor()F
    .registers 2

    .line 2108
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getCaptionScaleFactor()F

    move-result v0

    return v0
.end method

.method public getColor()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 1975
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getColor()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getPadding()Ljava/lang/String;
    .registers 2

    .line 2031
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getPadding()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getPaddingBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 2040
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getPaddingBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setBackgroundColor(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;
    .registers 3

    .line 2011
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->copyOnWrite()V

    .line 2012
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->-$$Nest$msetBackgroundColor(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setCaptionMaxFont(F)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;
    .registers 3

    .line 2088
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->copyOnWrite()V

    .line 2089
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->-$$Nest$msetCaptionMaxFont(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;F)V

    return-object p0
.end method

.method public setCaptionScaleFactor(F)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;
    .registers 3

    .line 2116
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->copyOnWrite()V

    .line 2117
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->-$$Nest$msetCaptionScaleFactor(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;F)V

    return-object p0
.end method

.method public setColor(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;
    .registers 3

    .line 1983
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->copyOnWrite()V

    .line 1984
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->-$$Nest$msetColor(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setPadding(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;
    .registers 3

    .line 2049
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->copyOnWrite()V

    .line 2050
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->-$$Nest$msetPadding(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;Ljava/lang/String;)V

    return-object p0
.end method

.method public setPaddingBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;
    .registers 3

    .line 2069
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->copyOnWrite()V

    .line 2070
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->-$$Nest$msetPaddingBytes(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
