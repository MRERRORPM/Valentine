# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackInfo$CaptionGlobalStylesOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "CaptionGlobalStylesOrBuilder"
.end annotation


# virtual methods
.method public abstract getBackgroundColor()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getCaptionMaxFont()F
.end method

.method public abstract getCaptionScaleFactor()F
.end method

.method public abstract getColor()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getPadding()Ljava/lang/String;
.end method

.method public abstract getPaddingBytes()Lcom/google/protobuf/ByteString;
.end method
