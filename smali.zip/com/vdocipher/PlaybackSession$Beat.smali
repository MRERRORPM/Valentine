# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Beat;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$BeatOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Beat"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$Beat$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$Beat;",
        "Lcom/vdocipher/PlaybackSession$Beat$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$BeatOrBuilder;"
    }
.end annotation


# static fields
.field public static final BL_FIELD_NUMBER:I = 0x3

.field public static final BW_FIELD_NUMBER:I = 0x10

.field public static final CC_FIELD_NUMBER:I = 0xa

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

.field public static final FPS_FIELD_NUMBER:I = 0x11

.field public static final IB_FIELD_NUMBER:I = 0x8

.field public static final ISINVIEW_FIELD_NUMBER:I = 0xd

.field public static final ISVIDEOINFOCUS_FIELD_NUMBER:I = 0xf

.field public static final ISWINDOWINFOCUS_FIELD_NUMBER:I = 0xe

.field public static final IS_FIELD_NUMBER:I = 0x9

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Beat;",
            ">;"
        }
    .end annotation
.end field

.field public static final PT_FIELD_NUMBER:I = 0x2

.field public static final QB_FIELD_NUMBER:I = 0xb

.field public static final QP_FIELD_NUMBER:I = 0xc

.field public static final ST_FIELD_NUMBER:I = 0x4

.field public static final TC_FIELD_NUMBER:I = 0x6

.field public static final TP_FIELD_NUMBER:I = 0x5

.field public static final T_FIELD_NUMBER:I = 0x1

.field public static final VO_FIELD_NUMBER:I = 0x7


# instance fields
.field private bl_:I

.field private bw_:I

.field private cc_:Ljava/lang/String;

.field private fps_:I

.field private ib_:Z

.field private isInView_:Z

.field private isVideoInFocus_:Z

.field private isWindowInFocus_:Z

.field private is_:Z

.field private pt_:F

.field private qb_:I

.field private qp_:I

.field private st_:I

.field private t_:I

.field private tc_:I

.field private tp_:F

.field private vo_:F


# direct methods
.method static bridge synthetic -$$Nest$mclearBl(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearBl()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearBw(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearBw()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearCc(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearCc()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearFps(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearFps()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearIb(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearIb()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearIs(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearIs()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearIsInView(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearIsInView()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearIsVideoInFocus(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearIsVideoInFocus()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearIsWindowInFocus(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearIsWindowInFocus()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPt(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearPt()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearQb(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearQb()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearQp(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearQp()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSt(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearSt()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearT(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearT()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearTc(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearTc()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearTp(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearTp()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearVo(Lcom/vdocipher/PlaybackSession$Beat;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Beat;->clearVo()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetBl(Lcom/vdocipher/PlaybackSession$Beat;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setBl(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetBw(Lcom/vdocipher/PlaybackSession$Beat;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setBw(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCc(Lcom/vdocipher/PlaybackSession$Beat;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setCc(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCcBytes(Lcom/vdocipher/PlaybackSession$Beat;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setCcBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetFps(Lcom/vdocipher/PlaybackSession$Beat;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setFps(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIb(Lcom/vdocipher/PlaybackSession$Beat;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setIb(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIs(Lcom/vdocipher/PlaybackSession$Beat;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setIs(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIsInView(Lcom/vdocipher/PlaybackSession$Beat;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setIsInView(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIsVideoInFocus(Lcom/vdocipher/PlaybackSession$Beat;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setIsVideoInFocus(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIsWindowInFocus(Lcom/vdocipher/PlaybackSession$Beat;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setIsWindowInFocus(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPt(Lcom/vdocipher/PlaybackSession$Beat;F)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setPt(F)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetQb(Lcom/vdocipher/PlaybackSession$Beat;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setQb(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetQp(Lcom/vdocipher/PlaybackSession$Beat;Lcom/vdocipher/PlaybackSession$QualityPreference;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setQp(Lcom/vdocipher/PlaybackSession$QualityPreference;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetQpValue(Lcom/vdocipher/PlaybackSession$Beat;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setQpValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSt(Lcom/vdocipher/PlaybackSession$Beat;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setSt(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetT(Lcom/vdocipher/PlaybackSession$Beat;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setT(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTc(Lcom/vdocipher/PlaybackSession$Beat;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setTc(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTp(Lcom/vdocipher/PlaybackSession$Beat;F)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setTp(F)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVo(Lcom/vdocipher/PlaybackSession$Beat;F)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->setVo(F)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Beat;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 8266
    new-instance v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$Beat;-><init>()V

    .line 8269
    sput-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    .line 8270
    const-class v1, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 7099
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 7100
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->cc_:Ljava/lang/String;

    return-void
.end method

.method private clearBl()V
    .registers 2

    const/4 v0, 0x0

    .line 7177
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->bl_:I

    return-void
.end method

.method private clearBw()V
    .registers 2

    const/4 v0, 0x0

    .line 7552
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->bw_:I

    return-void
.end method

.method private clearCc()V
    .registers 2

    .line 7370
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Beat;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Beat;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getCc()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->cc_:Ljava/lang/String;

    return-void
.end method

.method private clearFps()V
    .registers 2

    const/4 v0, 0x0

    .line 7578
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->fps_:I

    return-void
.end method

.method private clearIb()V
    .registers 2

    const/4 v0, 0x0

    .line 7307
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->ib_:Z

    return-void
.end method

.method private clearIs()V
    .registers 2

    const/4 v0, 0x0

    .line 7333
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->is_:Z

    return-void
.end method

.method private clearIsInView()V
    .registers 2

    const/4 v0, 0x0

    .line 7474
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->isInView_:Z

    return-void
.end method

.method private clearIsVideoInFocus()V
    .registers 2

    const/4 v0, 0x0

    .line 7526
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->isVideoInFocus_:Z

    return-void
.end method

.method private clearIsWindowInFocus()V
    .registers 2

    const/4 v0, 0x0

    .line 7500
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->isWindowInFocus_:Z

    return-void
.end method

.method private clearPt()V
    .registers 2

    const/4 v0, 0x0

    .line 7151
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->pt_:F

    return-void
.end method

.method private clearQb()V
    .registers 2

    const/4 v0, 0x0

    .line 7406
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->qb_:I

    return-void
.end method

.method private clearQp()V
    .registers 2

    const/4 v0, 0x0

    .line 7448
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->qp_:I

    return-void
.end method

.method private clearSt()V
    .registers 2

    const/4 v0, 0x0

    .line 7203
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->st_:I

    return-void
.end method

.method private clearT()V
    .registers 2

    const/4 v0, 0x0

    .line 7125
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->t_:I

    return-void
.end method

.method private clearTc()V
    .registers 2

    const/4 v0, 0x0

    .line 7255
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->tc_:I

    return-void
.end method

.method private clearTp()V
    .registers 2

    const/4 v0, 0x0

    .line 7229
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->tp_:F

    return-void
.end method

.method private clearVo()V
    .registers 2

    const/4 v0, 0x0

    .line 7281
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->vo_:F

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$Beat;
    .registers 1

    .line 8275
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 1

    .line 7658
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$Beat$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$Beat;)Lcom/vdocipher/PlaybackSession$Beat$Builder;
    .registers 2

    .line 7661
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$Beat;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Beat$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Beat;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7634
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$Beat;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Beat;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Beat;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7641
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$Beat;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Beat;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Beat;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7597
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Beat;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Beat;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7604
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Beat;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$Beat;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7646
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Beat;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Beat;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7653
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Beat;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Beat;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7621
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Beat;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Beat;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 7628
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Beat;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$Beat;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7584
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Beat;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Beat;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7591
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Beat;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$Beat;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7609
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Beat;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Beat;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 7616
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Beat;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Beat;",
            ">;"
        }
    .end annotation

    .line 8281
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Beat;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setBl(I)V
    .registers 2

    .line 7170
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->bl_:I

    return-void
.end method

.method private setBw(I)V
    .registers 2

    .line 7545
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->bw_:I

    return-void
.end method

.method private setCc(Ljava/lang/String;)V
    .registers 2

    .line 7361
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7363
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->cc_:Ljava/lang/String;

    return-void
.end method

.method private setCcBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 7378
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Beat;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 7379
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->cc_:Ljava/lang/String;

    return-void
.end method

.method private setFps(I)V
    .registers 2

    .line 7571
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->fps_:I

    return-void
.end method

.method private setIb(Z)V
    .registers 2

    .line 7300
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->ib_:Z

    return-void
.end method

.method private setIs(Z)V
    .registers 2

    .line 7326
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->is_:Z

    return-void
.end method

.method private setIsInView(Z)V
    .registers 2

    .line 7467
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->isInView_:Z

    return-void
.end method

.method private setIsVideoInFocus(Z)V
    .registers 2

    .line 7519
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->isVideoInFocus_:Z

    return-void
.end method

.method private setIsWindowInFocus(Z)V
    .registers 2

    .line 7493
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->isWindowInFocus_:Z

    return-void
.end method

.method private setPt(F)V
    .registers 2

    .line 7144
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->pt_:F

    return-void
.end method

.method private setQb(I)V
    .registers 2

    .line 7399
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->qb_:I

    return-void
.end method

.method private setQp(Lcom/vdocipher/PlaybackSession$QualityPreference;)V
    .registers 2

    .line 7440
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$QualityPreference;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->qp_:I

    return-void
.end method

.method private setQpValue(I)V
    .registers 2

    .line 7433
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->qp_:I

    return-void
.end method

.method private setSt(I)V
    .registers 2

    .line 7196
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->st_:I

    return-void
.end method

.method private setT(I)V
    .registers 2

    .line 7118
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->t_:I

    return-void
.end method

.method private setTc(I)V
    .registers 2

    .line 7248
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->tc_:I

    return-void
.end method

.method private setTp(F)V
    .registers 2

    .line 7222
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->tp_:F

    return-void
.end method

.method private setVo(F)V
    .registers 2

    .line 7274
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Beat;->vo_:F

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 23

    .line 8200
    sget-object v0, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual/range {p1 .. p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_76

    .line 8259
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0

    :pswitch_12  #0x7
    return-object v1

    :pswitch_13  #0x6
    const/4 v0, 0x1

    .line 8253
    invoke-static {v0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v0

    return-object v0

    .line 8238
    :pswitch_19  #0x5
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->PARSER:Lcom/google/protobuf/Parser;

    if-nez v0, :cond_32

    .line 8240
    const-class v1, Lcom/vdocipher/PlaybackSession$Beat;

    monitor-enter v1

    .line 8241
    :try_start_20
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->PARSER:Lcom/google/protobuf/Parser;

    if-nez v0, :cond_2d

    .line 8243
    new-instance v0, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object v2, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-direct {v0, v2}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 8246
    sput-object v0, Lcom/vdocipher/PlaybackSession$Beat;->PARSER:Lcom/google/protobuf/Parser;

    .line 8248
    :cond_2d
    monitor-exit v1

    return-object v0

    :catchall_2f
    move-exception v0

    monitor-exit v1
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw v0

    :cond_32
    return-object v0

    .line 8235
    :pswitch_33  #0x4
    sget-object v0, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    return-object v0

    .line 8208
    :pswitch_36  #0x3
    const-string/jumbo v2, "t_"

    const-string v3, "pt_"

    const-string v4, "bl_"

    const-string/jumbo v5, "st_"

    const-string/jumbo v6, "tp_"

    const-string/jumbo v7, "tc_"

    const-string/jumbo v8, "vo_"

    const-string v9, "ib_"

    const-string v10, "is_"

    const-string v11, "cc_"

    const-string v12, "qb_"

    const-string v13, "qp_"

    const-string v14, "isInView_"

    const-string v15, "isWindowInFocus_"

    const-string v16, "isVideoInFocus_"

    const-string v17, "bw_"

    const-string v18, "fps_"

    filled-new-array/range {v2 .. v18}, [Ljava/lang/Object;

    move-result-object v0

    .line 8227
    const-string v1, "\u0000\u0011\u0000\u0000\u0001\u0011\u0011\u0000\u0000\u0000\u0001\u000b\u0002\u0001\u0003\u000b\u0004\u0004\u0005\u0001\u0006\u000b\u0007\u0001\b\u0007\t\u0007\nȈ\u000b\u0004\f\f\r\u0007\u000e\u0007\u000f\u0007\u0010\u000b\u0011\u000b"

    .line 8231
    sget-object v2, Lcom/vdocipher/PlaybackSession$Beat;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v2, v1, v0}, Lcom/vdocipher/PlaybackSession$Beat;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    .line 8205
    :pswitch_6a  #0x2
    new-instance v0, Lcom/vdocipher/PlaybackSession$Beat$Builder;

    invoke-direct {v0, v1}, Lcom/vdocipher/PlaybackSession$Beat$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object v0

    .line 8202
    :pswitch_70  #0x1
    new-instance v0, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$Beat;-><init>()V

    return-object v0

    :pswitch_data_76
    .packed-switch 0x1
        :pswitch_70  #00000001
        :pswitch_6a  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getBl()I
    .registers 2

    .line 7162
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->bl_:I

    return v0
.end method

.method public getBw()I
    .registers 2

    .line 7537
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->bw_:I

    return v0
.end method

.method public getCc()Ljava/lang/String;
    .registers 2

    .line 7344
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->cc_:Ljava/lang/String;

    return-object v0
.end method

.method public getCcBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 7353
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->cc_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getFps()I
    .registers 2

    .line 7563
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->fps_:I

    return v0
.end method

.method public getIb()Z
    .registers 2

    .line 7292
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->ib_:Z

    return v0
.end method

.method public getIs()Z
    .registers 2

    .line 7318
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->is_:Z

    return v0
.end method

.method public getIsInView()Z
    .registers 2

    .line 7459
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->isInView_:Z

    return v0
.end method

.method public getIsVideoInFocus()Z
    .registers 2

    .line 7511
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->isVideoInFocus_:Z

    return v0
.end method

.method public getIsWindowInFocus()Z
    .registers 2

    .line 7485
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->isWindowInFocus_:Z

    return v0
.end method

.method public getPt()F
    .registers 2

    .line 7136
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->pt_:F

    return v0
.end method

.method public getQb()I
    .registers 2

    .line 7391
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->qb_:I

    return v0
.end method

.method public getQp()Lcom/vdocipher/PlaybackSession$QualityPreference;
    .registers 2

    .line 7425
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->qp_:I

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$QualityPreference;->forNumber(I)Lcom/vdocipher/PlaybackSession$QualityPreference;

    move-result-object v0

    if-nez v0, :cond_a

    .line 7426
    sget-object v0, Lcom/vdocipher/PlaybackSession$QualityPreference;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$QualityPreference;

    :cond_a
    return-object v0
.end method

.method public getQpValue()I
    .registers 2

    .line 7417
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->qp_:I

    return v0
.end method

.method public getSt()I
    .registers 2

    .line 7188
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->st_:I

    return v0
.end method

.method public getT()I
    .registers 2

    .line 7110
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->t_:I

    return v0
.end method

.method public getTc()I
    .registers 2

    .line 7240
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->tc_:I

    return v0
.end method

.method public getTp()F
    .registers 2

    .line 7214
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->tp_:F

    return v0
.end method

.method public getVo()F
    .registers 2

    .line 7266
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Beat;->vo_:F

    return v0
.end method
