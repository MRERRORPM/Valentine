# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$Posters$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$PostersOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$Posters;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackInfo$Posters;",
        "Lcom/vdocipher/PlaybackInfo$Posters$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$PostersOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 934
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Posters;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$Posters;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackInfo-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Posters$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearHeight()Lcom/vdocipher/PlaybackInfo$Posters$Builder;
    .registers 2

    .line 1010
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->copyOnWrite()V

    .line 1011
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$Posters;->-$$Nest$mclearHeight(Lcom/vdocipher/PlaybackInfo$Posters;)V

    return-object p0
.end method

.method public clearUrl()Lcom/vdocipher/PlaybackInfo$Posters$Builder;
    .registers 2

    .line 971
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->copyOnWrite()V

    .line 972
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$Posters;->-$$Nest$mclearUrl(Lcom/vdocipher/PlaybackInfo$Posters;)V

    return-object p0
.end method

.method public getHeight()I
    .registers 2

    .line 993
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Posters;->getHeight()I

    move-result v0

    return v0
.end method

.method public getUrl()Ljava/lang/String;
    .registers 2

    .line 944
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Posters;->getUrl()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getUrlBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 953
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Posters;->getUrlBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setHeight(I)Lcom/vdocipher/PlaybackInfo$Posters$Builder;
    .registers 3

    .line 1001
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->copyOnWrite()V

    .line 1002
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Posters;->-$$Nest$msetHeight(Lcom/vdocipher/PlaybackInfo$Posters;I)V

    return-object p0
.end method

.method public setUrl(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$Posters$Builder;
    .registers 3

    .line 962
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->copyOnWrite()V

    .line 963
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Posters;->-$$Nest$msetUrl(Lcom/vdocipher/PlaybackInfo$Posters;Ljava/lang/String;)V

    return-object p0
.end method

.method public setUrlBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$Posters$Builder;
    .registers 3

    .line 982
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->copyOnWrite()V

    .line 983
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Posters;->-$$Nest$msetUrlBytes(Lcom/vdocipher/PlaybackInfo$Posters;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
