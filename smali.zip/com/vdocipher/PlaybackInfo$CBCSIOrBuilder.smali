# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackInfo$CBCSIOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "CBCSIOrBuilder"
.end annotation


# virtual methods
.method public abstract getContentId()Ljava/lang/String;
.end method

.method public abstract getContentIdBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getFallbackLicenseServers(I)Ljava/lang/String;
.end method

.method public abstract getFallbackLicenseServersBytes(I)Lcom/google/protobuf/ByteString;
.end method

.method public abstract getFallbackLicenseServersCount()I
.end method

.method public abstract getFallbackLicenseServersList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getLicenseServer()Ljava/lang/String;
.end method

.method public abstract getLicenseServerBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getUrlI()Lcom/google/protobuf/ByteString;
.end method
