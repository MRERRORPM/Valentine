# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackInfo$DASHOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "DASHOrBuilder"
.end annotation


# virtual methods
.method public abstract getAllowSafetyDetect()Z
.end method

.method public abstract getEnforceAL3()Z
.end method

.method public abstract getEnforceHardwareAttestation()Z
.end method

.method public abstract getEnforceL3Config()Z
.end method

.method public abstract getErrorCodesAL3(I)I
.end method

.method public abstract getErrorCodesAL3Count()I
.end method

.method public abstract getErrorCodesAL3List()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getFallbackLicenseServers(I)Ljava/lang/String;
.end method

.method public abstract getFallbackLicenseServersBytes(I)Lcom/google/protobuf/ByteString;
.end method

.method public abstract getFallbackLicenseServersCount()I
.end method

.method public abstract getFallbackLicenseServersList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getLicenseServers()Ljava/lang/String;
.end method

.method public abstract getLicenseServersBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getManifest()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getMpdString()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getPsr()Z
.end method

.method public abstract hasAllowSafetyDetect()Z
.end method

.method public abstract hasEnforceHardwareAttestation()Z
.end method

.method public abstract hasPsr()Z
.end method
