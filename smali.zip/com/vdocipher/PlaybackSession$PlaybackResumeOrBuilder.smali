# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackSession$PlaybackResumeOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "PlaybackResumeOrBuilder"
.end annotation


# virtual methods
.method public abstract getTime()I
.end method

.method public abstract getType()Lcom/vdocipher/PlaybackSession$ResumeType;
.end method

.method public abstract getTypeValue()I
.end method
