# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$TrackAudio;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$TrackAudioOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "TrackAudio"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$TrackAudio;",
        "Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$TrackAudioOrBuilder;"
    }
.end annotation


# static fields
.field public static final BITRATEKBPS_FIELD_NUMBER:I = 0x1

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

.field public static final LANGUAGE_FIELD_NUMBER:I = 0x2

.field private static volatile PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$TrackAudio;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private bitrateKbps_:I

.field private language_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$mclearBitrateKbps(Lcom/vdocipher/PlaybackSession$TrackAudio;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$TrackAudio;->clearBitrateKbps()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLanguage(Lcom/vdocipher/PlaybackSession$TrackAudio;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$TrackAudio;->clearLanguage()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetBitrateKbps(Lcom/vdocipher/PlaybackSession$TrackAudio;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$TrackAudio;->setBitrateKbps(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLanguage(Lcom/vdocipher/PlaybackSession$TrackAudio;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$TrackAudio;->setLanguage(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLanguageBytes(Lcom/vdocipher/PlaybackSession$TrackAudio;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$TrackAudio;->setLanguageBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 9394
    new-instance v0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$TrackAudio;-><init>()V

    .line 9397
    sput-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    .line 9398
    const-class v1, Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 9087
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 9088
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackAudio;->language_:Ljava/lang/String;

    return-void
.end method

.method private clearBitrateKbps()V
    .registers 2

    const/4 v0, 0x0

    .line 9113
    iput v0, p0, Lcom/vdocipher/PlaybackSession$TrackAudio;->bitrateKbps_:I

    return-void
.end method

.method private clearLanguage()V
    .registers 2

    .line 9150
    invoke-static {}, Lcom/vdocipher/PlaybackSession$TrackAudio;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$TrackAudio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$TrackAudio;->getLanguage()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackAudio;->language_:Ljava/lang/String;

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 1

    .line 9403
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;
    .registers 1

    .line 9240
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$TrackAudio;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$TrackAudio;)Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;
    .registers 2

    .line 9243
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$TrackAudio;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9216
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$TrackAudio;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9223
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$TrackAudio;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9179
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9186
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9228
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9235
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9203
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9210
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9166
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9173
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9191
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9198
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$TrackAudio;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$TrackAudio;",
            ">;"
        }
    .end annotation

    .line 9409
    sget-object v0, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$TrackAudio;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setBitrateKbps(I)V
    .registers 2

    .line 9106
    iput p1, p0, Lcom/vdocipher/PlaybackSession$TrackAudio;->bitrateKbps_:I

    return-void
.end method

.method private setLanguage(Ljava/lang/String;)V
    .registers 2

    .line 9141
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9143
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$TrackAudio;->language_:Ljava/lang/String;

    return-void
.end method

.method private setLanguageBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 9158
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$TrackAudio;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 9159
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$TrackAudio;->language_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 9344
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_54

    .line 9387
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 9381
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 9366
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$TrackAudio;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 9368
    const-class p2, Lcom/vdocipher/PlaybackSession$TrackAudio;

    monitor-enter p2

    .line 9369
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$TrackAudio;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 9371
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 9374
    sput-object p1, Lcom/vdocipher/PlaybackSession$TrackAudio;->PARSER:Lcom/google/protobuf/Parser;

    .line 9376
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 9363
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    return-object p1

    .line 9352
    :pswitch_36  #0x3
    const-string p1, "bitrateKbps_"

    const-string p2, "language_"

    filled-new-array {p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    .line 9356
    const-string p2, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u000b\u0002Ȉ"

    .line 9359
    sget-object p3, Lcom/vdocipher/PlaybackSession$TrackAudio;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$TrackAudio;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 9349
    :pswitch_47  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 9346
    :pswitch_4d  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$TrackAudio;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$TrackAudio;-><init>()V

    return-object p1

    nop

    :pswitch_data_54
    .packed-switch 0x1
        :pswitch_4d  #00000001
        :pswitch_47  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getBitrateKbps()I
    .registers 2

    .line 9098
    iget v0, p0, Lcom/vdocipher/PlaybackSession$TrackAudio;->bitrateKbps_:I

    return v0
.end method

.method public getLanguage()Ljava/lang/String;
    .registers 2

    .line 9124
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackAudio;->language_:Ljava/lang/String;

    return-object v0
.end method

.method public getLanguageBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9133
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackAudio;->language_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method
