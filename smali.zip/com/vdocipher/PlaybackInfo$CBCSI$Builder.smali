# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$CBCSIOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$CBCSI;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackInfo$CBCSI;",
        "Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$CBCSIOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 8992
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$CBCSI;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$CBCSI;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackInfo-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public addAllFallbackLicenseServers(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;"
        }
    .end annotation

    .line 9189
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->copyOnWrite()V

    .line 9190
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->-$$Nest$maddAllFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$CBCSI;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addFallbackLicenseServers(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    .registers 3

    .line 9178
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->copyOnWrite()V

    .line 9179
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->-$$Nest$maddFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$CBCSI;Ljava/lang/String;)V

    return-object p0
.end method

.method public addFallbackLicenseServersBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    .registers 3

    .line 9209
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->copyOnWrite()V

    .line 9210
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->-$$Nest$maddFallbackLicenseServersBytes(Lcom/vdocipher/PlaybackInfo$CBCSI;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public clearContentId()Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    .registers 2

    .line 9029
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->copyOnWrite()V

    .line 9030
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->-$$Nest$mclearContentId(Lcom/vdocipher/PlaybackInfo$CBCSI;)V

    return-object p0
.end method

.method public clearFallbackLicenseServers()Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    .registers 2

    .line 9198
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->copyOnWrite()V

    .line 9199
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->-$$Nest$mclearFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$CBCSI;)V

    return-object p0
.end method

.method public clearLicenseServer()Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    .registers 2

    .line 9078
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->copyOnWrite()V

    .line 9079
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->-$$Nest$mclearLicenseServer(Lcom/vdocipher/PlaybackInfo$CBCSI;)V

    return-object p0
.end method

.method public clearUrlI()Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    .registers 2

    .line 9117
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->copyOnWrite()V

    .line 9118
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->-$$Nest$mclearUrlI(Lcom/vdocipher/PlaybackInfo$CBCSI;)V

    return-object p0
.end method

.method public getContentId()Ljava/lang/String;
    .registers 2

    .line 9002
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getContentId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getContentIdBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9011
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getContentIdBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getFallbackLicenseServers(I)Ljava/lang/String;
    .registers 3

    .line 9147
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getFallbackLicenseServers(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public getFallbackLicenseServersBytes(I)Lcom/google/protobuf/ByteString;
    .registers 3

    .line 9157
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getFallbackLicenseServersBytes(I)Lcom/google/protobuf/ByteString;

    move-result-object p1

    return-object p1
.end method

.method public getFallbackLicenseServersCount()I
    .registers 2

    .line 9138
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getFallbackLicenseServersCount()I

    move-result v0

    return v0
.end method

.method public getFallbackLicenseServersList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 9129
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    .line 9130
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getFallbackLicenseServersList()Ljava/util/List;

    move-result-object v0

    .line 9129
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getLicenseServer()Ljava/lang/String;
    .registers 2

    .line 9051
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getLicenseServer()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getLicenseServerBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9060
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getLicenseServerBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getUrlI()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9100
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getUrlI()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setContentId(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    .registers 3

    .line 9020
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->copyOnWrite()V

    .line 9021
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->-$$Nest$msetContentId(Lcom/vdocipher/PlaybackInfo$CBCSI;Ljava/lang/String;)V

    return-object p0
.end method

.method public setContentIdBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    .registers 3

    .line 9040
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->copyOnWrite()V

    .line 9041
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->-$$Nest$msetContentIdBytes(Lcom/vdocipher/PlaybackInfo$CBCSI;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setFallbackLicenseServers(ILjava/lang/String;)Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    .registers 4

    .line 9167
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->copyOnWrite()V

    .line 9168
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$CBCSI;->-$$Nest$msetFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$CBCSI;ILjava/lang/String;)V

    return-object p0
.end method

.method public setLicenseServer(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    .registers 3

    .line 9069
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->copyOnWrite()V

    .line 9070
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->-$$Nest$msetLicenseServer(Lcom/vdocipher/PlaybackInfo$CBCSI;Ljava/lang/String;)V

    return-object p0
.end method

.method public setLicenseServerBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    .registers 3

    .line 9089
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->copyOnWrite()V

    .line 9090
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->-$$Nest$msetLicenseServerBytes(Lcom/vdocipher/PlaybackInfo$CBCSI;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setUrlI(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    .registers 3

    .line 9108
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->copyOnWrite()V

    .line 9109
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->-$$Nest$msetUrlI(Lcom/vdocipher/PlaybackInfo$CBCSI;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
