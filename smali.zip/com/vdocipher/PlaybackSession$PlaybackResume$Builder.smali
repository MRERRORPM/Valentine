# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$PlaybackResumeOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$PlaybackResume;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$PlaybackResume;",
        "Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$PlaybackResumeOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 13553
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$PlaybackResume;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearTime()Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;
    .registers 2

    .line 13580
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->copyOnWrite()V

    .line 13581
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->-$$Nest$mclearTime(Lcom/vdocipher/PlaybackSession$PlaybackResume;)V

    return-object p0
.end method

.method public clearType()Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;
    .registers 2

    .line 13626
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->copyOnWrite()V

    .line 13627
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->-$$Nest$mclearType(Lcom/vdocipher/PlaybackSession$PlaybackResume;)V

    return-object p0
.end method

.method public getTime()I
    .registers 2

    .line 13563
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->getTime()I

    move-result v0

    return v0
.end method

.method public getType()Lcom/vdocipher/PlaybackSession$ResumeType;
    .registers 2

    .line 13609
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->getType()Lcom/vdocipher/PlaybackSession$ResumeType;

    move-result-object v0

    return-object v0
.end method

.method public getTypeValue()I
    .registers 2

    .line 13591
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->getTypeValue()I

    move-result v0

    return v0
.end method

.method public setTime(I)Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;
    .registers 3

    .line 13571
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->copyOnWrite()V

    .line 13572
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->-$$Nest$msetTime(Lcom/vdocipher/PlaybackSession$PlaybackResume;I)V

    return-object p0
.end method

.method public setType(Lcom/vdocipher/PlaybackSession$ResumeType;)Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;
    .registers 3

    .line 13617
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->copyOnWrite()V

    .line 13618
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->-$$Nest$msetType(Lcom/vdocipher/PlaybackSession$PlaybackResume;Lcom/vdocipher/PlaybackSession$ResumeType;)V

    return-object p0
.end method

.method public setTypeValue(I)Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;
    .registers 3

    .line 13599
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->copyOnWrite()V

    .line 13600
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->-$$Nest$msetTypeValue(Lcom/vdocipher/PlaybackSession$PlaybackResume;I)V

    return-object p0
.end method
