# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$CBCSI;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$CBCSIOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "CBCSI"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackInfo$CBCSI;",
        "Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$CBCSIOrBuilder;"
    }
.end annotation


# static fields
.field public static final CONTENTID_FIELD_NUMBER:I = 0x1

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

.field public static final FALLBACKLICENSESERVERS_FIELD_NUMBER:I = 0x4

.field public static final LICENSESERVER_FIELD_NUMBER:I = 0x2

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$CBCSI;",
            ">;"
        }
    .end annotation
.end field

.field public static final URLI_FIELD_NUMBER:I = 0x3


# instance fields
.field private contentId_:Ljava/lang/String;

.field private fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private licenseServer_:Ljava/lang/String;

.field private urlI_:Lcom/google/protobuf/ByteString;


# direct methods
.method static bridge synthetic -$$Nest$maddAllFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$CBCSI;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->addAllFallbackLicenseServers(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$CBCSI;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->addFallbackLicenseServers(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddFallbackLicenseServersBytes(Lcom/vdocipher/PlaybackInfo$CBCSI;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->addFallbackLicenseServersBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearContentId(Lcom/vdocipher/PlaybackInfo$CBCSI;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->clearContentId()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$CBCSI;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->clearFallbackLicenseServers()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLicenseServer(Lcom/vdocipher/PlaybackInfo$CBCSI;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->clearLicenseServer()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearUrlI(Lcom/vdocipher/PlaybackInfo$CBCSI;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->clearUrlI()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetContentId(Lcom/vdocipher/PlaybackInfo$CBCSI;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->setContentId(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetContentIdBytes(Lcom/vdocipher/PlaybackInfo$CBCSI;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->setContentIdBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$CBCSI;ILjava/lang/String;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$CBCSI;->setFallbackLicenseServers(ILjava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLicenseServer(Lcom/vdocipher/PlaybackInfo$CBCSI;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->setLicenseServer(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLicenseServerBytes(Lcom/vdocipher/PlaybackInfo$CBCSI;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->setLicenseServerBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetUrlI(Lcom/vdocipher/PlaybackInfo$CBCSI;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->setUrlI(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 9273
    new-instance v0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;-><init>()V

    .line 9276
    sput-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    .line 9277
    const-class v1, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 8679
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 8680
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->contentId_:Ljava/lang/String;

    .line 8681
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->licenseServer_:Ljava/lang/String;

    .line 8682
    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->urlI_:Lcom/google/protobuf/ByteString;

    .line 8683
    invoke-static {}, Lcom/google/protobuf/GeneratedMessageLite;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private addAllFallbackLicenseServers(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 8878
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->ensureFallbackLicenseServersIsMutable()V

    .line 8879
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addFallbackLicenseServers(Ljava/lang/String;)V
    .registers 3

    .line 8868
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8869
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->ensureFallbackLicenseServersIsMutable()V

    .line 8870
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addFallbackLicenseServersBytes(Lcom/google/protobuf/ByteString;)V
    .registers 3

    .line 8894
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 8895
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->ensureFallbackLicenseServersIsMutable()V

    .line 8896
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private clearContentId()V
    .registers 2

    .line 8719
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$CBCSI;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getContentId()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->contentId_:Ljava/lang/String;

    return-void
.end method

.method private clearFallbackLicenseServers()V
    .registers 2

    .line 8886
    invoke-static {}, Lcom/google/protobuf/GeneratedMessageLite;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearLicenseServer()V
    .registers 2

    .line 8766
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$CBCSI;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getLicenseServer()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->licenseServer_:Ljava/lang/String;

    return-void
.end method

.method private clearUrlI()V
    .registers 2

    .line 8803
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$CBCSI;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getUrlI()Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->urlI_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private ensureFallbackLicenseServersIsMutable()V
    .registers 3

    .line 8845
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 8846
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 8848
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 1

    .line 9282
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    .registers 1

    .line 8976
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackInfo$CBCSI;)Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;
    .registers 2

    .line 8979
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8952
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8959
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8915
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8922
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8964
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8971
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8939
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8946
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8902
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8909
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8927
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8934
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CBCSI;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$CBCSI;",
            ">;"
        }
    .end annotation

    .line 9288
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setContentId(Ljava/lang/String;)V
    .registers 2

    .line 8710
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8712
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->contentId_:Ljava/lang/String;

    return-void
.end method

.method private setContentIdBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 8727
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 8728
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->contentId_:Ljava/lang/String;

    return-void
.end method

.method private setFallbackLicenseServers(ILjava/lang/String;)V
    .registers 4

    .line 8858
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8859
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->ensureFallbackLicenseServersIsMutable()V

    .line 8860
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setLicenseServer(Ljava/lang/String;)V
    .registers 2

    .line 8757
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8759
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->licenseServer_:Ljava/lang/String;

    return-void
.end method

.method private setLicenseServerBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 8774
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 8775
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->licenseServer_:Ljava/lang/String;

    return-void
.end method

.method private setUrlI(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 8794
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8796
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->urlI_:Lcom/google/protobuf/ByteString;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 9221
    sget-object p2, Lcom/vdocipher/PlaybackInfo$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_58

    .line 9266
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 9260
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 9245
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackInfo$CBCSI;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 9247
    const-class p2, Lcom/vdocipher/PlaybackInfo$CBCSI;

    monitor-enter p2

    .line 9248
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackInfo$CBCSI;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 9250
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 9253
    sput-object p1, Lcom/vdocipher/PlaybackInfo$CBCSI;->PARSER:Lcom/google/protobuf/Parser;

    .line 9255
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 9242
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    return-object p1

    .line 9229
    :pswitch_36  #0x3
    const-string p1, "contentId_"

    const-string p2, "licenseServer_"

    const-string/jumbo p3, "urlI_"

    const-string v0, "fallbackLicenseServers_"

    filled-new-array {p1, p2, p3, v0}, [Ljava/lang/Object;

    move-result-object p1

    .line 9235
    const-string p2, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0001\u0000\u0001Ȉ\u0002Ȉ\u0003\n\u0004Ț"

    .line 9238
    sget-object p3, Lcom/vdocipher/PlaybackInfo$CBCSI;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 9226
    :pswitch_4c  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;-><init>(Lcom/vdocipher/PlaybackInfo-IA;)V

    return-object p1

    .line 9223
    :pswitch_52  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackInfo$CBCSI;-><init>()V

    return-object p1

    :pswitch_data_58
    .packed-switch 0x1
        :pswitch_52  #00000001
        :pswitch_4c  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getContentId()Ljava/lang/String;
    .registers 2

    .line 8693
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->contentId_:Ljava/lang/String;

    return-object v0
.end method

.method public getContentIdBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8702
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->contentId_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getFallbackLicenseServers(I)Ljava/lang/String;
    .registers 3

    .line 8831
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    return-object p1
.end method

.method public getFallbackLicenseServersBytes(I)Lcom/google/protobuf/ByteString;
    .registers 3

    .line 8841
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 8842
    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    .line 8841
    invoke-static {p1}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object p1

    return-object p1
.end method

.method public getFallbackLicenseServersCount()I
    .registers 2

    .line 8822
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getFallbackLicenseServersList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 8814
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->fallbackLicenseServers_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getLicenseServer()Ljava/lang/String;
    .registers 2

    .line 8740
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->licenseServer_:Ljava/lang/String;

    return-object v0
.end method

.method public getLicenseServerBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8749
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->licenseServer_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getUrlI()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8787
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$CBCSI;->urlI_:Lcom/google/protobuf/ByteString;

    return-object v0
.end method
