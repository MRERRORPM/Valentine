# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Error$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$ErrorOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$Error;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$Error;",
        "Lcom/vdocipher/PlaybackSession$Error$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$ErrorOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 8821
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Error;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Error;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Error$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearDisplayMsg()Lcom/vdocipher/PlaybackSession$Error$Builder;
    .registers 2

    .line 8963
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Error$Builder;->copyOnWrite()V

    .line 8964
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Error;->-$$Nest$mclearDisplayMsg(Lcom/vdocipher/PlaybackSession$Error;)V

    return-object p0
.end method

.method public clearInternalCode()Lcom/vdocipher/PlaybackSession$Error$Builder;
    .registers 2

    .line 8848
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Error$Builder;->copyOnWrite()V

    .line 8849
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Error;->-$$Nest$mclearInternalCode(Lcom/vdocipher/PlaybackSession$Error;)V

    return-object p0
.end method

.method public clearPayload()Lcom/vdocipher/PlaybackSession$Error$Builder;
    .registers 2

    .line 8914
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Error$Builder;->copyOnWrite()V

    .line 8915
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Error;->-$$Nest$mclearPayload(Lcom/vdocipher/PlaybackSession$Error;)V

    return-object p0
.end method

.method public clearVdo()Lcom/vdocipher/PlaybackSession$Error$Builder;
    .registers 2

    .line 8876
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Error$Builder;->copyOnWrite()V

    .line 8877
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Error;->-$$Nest$mclearVdo(Lcom/vdocipher/PlaybackSession$Error;)V

    return-object p0
.end method

.method public getDisplayMsg()Ljava/lang/String;
    .registers 2

    .line 8936
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Error;->getDisplayMsg()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getDisplayMsgBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8945
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Error;->getDisplayMsgBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getInternalCode()I
    .registers 2

    .line 8831
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Error;->getInternalCode()I

    move-result v0

    return v0
.end method

.method public getPayload()Ljava/lang/String;
    .registers 2

    .line 8887
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Error;->getPayload()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getPayloadBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8896
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Error;->getPayloadBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getVdo()I
    .registers 2

    .line 8859
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Error;->getVdo()I

    move-result v0

    return v0
.end method

.method public setDisplayMsg(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Error$Builder;
    .registers 3

    .line 8954
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Error$Builder;->copyOnWrite()V

    .line 8955
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Error;->-$$Nest$msetDisplayMsg(Lcom/vdocipher/PlaybackSession$Error;Ljava/lang/String;)V

    return-object p0
.end method

.method public setDisplayMsgBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Error$Builder;
    .registers 3

    .line 8974
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Error$Builder;->copyOnWrite()V

    .line 8975
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Error;->-$$Nest$msetDisplayMsgBytes(Lcom/vdocipher/PlaybackSession$Error;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setInternalCode(I)Lcom/vdocipher/PlaybackSession$Error$Builder;
    .registers 3

    .line 8839
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Error$Builder;->copyOnWrite()V

    .line 8840
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Error;->-$$Nest$msetInternalCode(Lcom/vdocipher/PlaybackSession$Error;I)V

    return-object p0
.end method

.method public setPayload(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Error$Builder;
    .registers 3

    .line 8905
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Error$Builder;->copyOnWrite()V

    .line 8906
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Error;->-$$Nest$msetPayload(Lcom/vdocipher/PlaybackSession$Error;Ljava/lang/String;)V

    return-object p0
.end method

.method public setPayloadBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Error$Builder;
    .registers 3

    .line 8925
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Error$Builder;->copyOnWrite()V

    .line 8926
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Error;->-$$Nest$msetPayloadBytes(Lcom/vdocipher/PlaybackSession$Error;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setVdo(I)Lcom/vdocipher/PlaybackSession$Error$Builder;
    .registers 3

    .line 8867
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Error$Builder;->copyOnWrite()V

    .line 8868
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Error;->-$$Nest$msetVdo(Lcom/vdocipher/PlaybackSession$Error;I)V

    return-object p0
.end method
