# classes14.dex

.class public final enum Lcom/vdocipher/Manifest$ContentProtectionValue;
.super Ljava/lang/Enum;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "ContentProtectionValue"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$ContentProtectionValue$ContentProtectionValueVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/Manifest$ContentProtectionValue;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/Manifest$ContentProtectionValue;

.field public static final enum CBCS:Lcom/vdocipher/Manifest$ContentProtectionValue;

.field public static final CBCS_VALUE:I = 0x1

.field public static final enum CENC:Lcom/vdocipher/Manifest$ContentProtectionValue;

.field public static final CENC_VALUE:I

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/Manifest$ContentProtectionValue;

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/Manifest$ContentProtectionValue;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 6

    .line 20
    new-instance v0, Lcom/vdocipher/Manifest$ContentProtectionValue;

    const-string v1, "CENC"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/Manifest$ContentProtectionValue;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/Manifest$ContentProtectionValue;->CENC:Lcom/vdocipher/Manifest$ContentProtectionValue;

    .line 24
    new-instance v1, Lcom/vdocipher/Manifest$ContentProtectionValue;

    const-string v2, "CBCS"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/Manifest$ContentProtectionValue;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/Manifest$ContentProtectionValue;->CBCS:Lcom/vdocipher/Manifest$ContentProtectionValue;

    .line 25
    new-instance v2, Lcom/vdocipher/Manifest$ContentProtectionValue;

    const/4 v3, 0x2

    const/4 v4, -0x1

    const-string v5, "UNRECOGNIZED"

    invoke-direct {v2, v5, v3, v4}, Lcom/vdocipher/Manifest$ContentProtectionValue;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/Manifest$ContentProtectionValue;->UNRECOGNIZED:Lcom/vdocipher/Manifest$ContentProtectionValue;

    .line 15
    filled-new-array {v0, v1, v2}, [Lcom/vdocipher/Manifest$ContentProtectionValue;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/Manifest$ContentProtectionValue;->$VALUES:[Lcom/vdocipher/Manifest$ContentProtectionValue;

    .line 70
    new-instance v0, Lcom/vdocipher/Manifest$ContentProtectionValue$1;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$ContentProtectionValue$1;-><init>()V

    sput-object v0, Lcom/vdocipher/Manifest$ContentProtectionValue;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 94
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 95
    iput p3, p0, Lcom/vdocipher/Manifest$ContentProtectionValue;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/Manifest$ContentProtectionValue;
    .registers 2

    if-eqz p0, :cond_a

    const/4 v0, 0x1

    if-eq p0, v0, :cond_7

    const/4 p0, 0x0

    return-object p0

    .line 60
    :cond_7
    sget-object p0, Lcom/vdocipher/Manifest$ContentProtectionValue;->CBCS:Lcom/vdocipher/Manifest$ContentProtectionValue;

    return-object p0

    .line 59
    :cond_a
    sget-object p0, Lcom/vdocipher/Manifest$ContentProtectionValue;->CENC:Lcom/vdocipher/Manifest$ContentProtectionValue;

    return-object p0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/Manifest$ContentProtectionValue;",
            ">;"
        }
    .end annotation

    .line 67
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtectionValue;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 80
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtectionValue$ContentProtectionValueVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/Manifest$ContentProtectionValue;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 54
    invoke-static {p0}, Lcom/vdocipher/Manifest$ContentProtectionValue;->forNumber(I)Lcom/vdocipher/Manifest$ContentProtectionValue;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/Manifest$ContentProtectionValue;
    .registers 2

    .line 15
    const-class v0, Lcom/vdocipher/Manifest$ContentProtectionValue;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$ContentProtectionValue;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/Manifest$ContentProtectionValue;
    .registers 1

    .line 15
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtectionValue;->$VALUES:[Lcom/vdocipher/Manifest$ContentProtectionValue;

    invoke-virtual {v0}, [Lcom/vdocipher/Manifest$ContentProtectionValue;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/Manifest$ContentProtectionValue;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 40
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtectionValue;->UNRECOGNIZED:Lcom/vdocipher/Manifest$ContentProtectionValue;

    if-eq p0, v0, :cond_7

    .line 44
    iget v0, p0, Lcom/vdocipher/Manifest$ContentProtectionValue;->value:I

    return v0

    .line 41
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
