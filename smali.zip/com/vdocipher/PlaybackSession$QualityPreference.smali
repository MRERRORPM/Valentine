# classes14.dex

.class public final enum Lcom/vdocipher/PlaybackSession$QualityPreference;
.super Ljava/lang/Enum;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "QualityPreference"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$QualityPreference$QualityPreferenceVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/PlaybackSession$QualityPreference;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/PlaybackSession$QualityPreference;

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$QualityPreference;

.field public static final enum auto:Lcom/vdocipher/PlaybackSession$QualityPreference;

.field public static final auto_VALUE:I = 0x0

.field public static final enum highest:Lcom/vdocipher/PlaybackSession$QualityPreference;

.field public static final highest_VALUE:I = 0x2

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$QualityPreference;",
            ">;"
        }
    .end annotation
.end field

.field public static final enum lowest:Lcom/vdocipher/PlaybackSession$QualityPreference;

.field public static final lowest_VALUE:I = 0x1

.field public static final enum middle:Lcom/vdocipher/PlaybackSession$QualityPreference;

.field public static final middle_VALUE:I = 0x3


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 8

    .line 772
    new-instance v0, Lcom/vdocipher/PlaybackSession$QualityPreference;

    const-string v1, "auto"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/PlaybackSession$QualityPreference;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$QualityPreference;->auto:Lcom/vdocipher/PlaybackSession$QualityPreference;

    .line 776
    new-instance v1, Lcom/vdocipher/PlaybackSession$QualityPreference;

    const-string v2, "lowest"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/PlaybackSession$QualityPreference;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$QualityPreference;->lowest:Lcom/vdocipher/PlaybackSession$QualityPreference;

    .line 780
    new-instance v2, Lcom/vdocipher/PlaybackSession$QualityPreference;

    const-string v3, "highest"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4, v4}, Lcom/vdocipher/PlaybackSession$QualityPreference;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/PlaybackSession$QualityPreference;->highest:Lcom/vdocipher/PlaybackSession$QualityPreference;

    .line 784
    new-instance v3, Lcom/vdocipher/PlaybackSession$QualityPreference;

    const-string v4, "middle"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5, v5}, Lcom/vdocipher/PlaybackSession$QualityPreference;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lcom/vdocipher/PlaybackSession$QualityPreference;->middle:Lcom/vdocipher/PlaybackSession$QualityPreference;

    .line 785
    new-instance v4, Lcom/vdocipher/PlaybackSession$QualityPreference;

    const/4 v5, 0x4

    const/4 v6, -0x1

    const-string v7, "UNRECOGNIZED"

    invoke-direct {v4, v7, v5, v6}, Lcom/vdocipher/PlaybackSession$QualityPreference;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lcom/vdocipher/PlaybackSession$QualityPreference;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$QualityPreference;

    .line 767
    filled-new-array {v0, v1, v2, v3, v4}, [Lcom/vdocipher/PlaybackSession$QualityPreference;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/PlaybackSession$QualityPreference;->$VALUES:[Lcom/vdocipher/PlaybackSession$QualityPreference;

    .line 840
    new-instance v0, Lcom/vdocipher/PlaybackSession$QualityPreference$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$QualityPreference$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackSession$QualityPreference;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 864
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 865
    iput p3, p0, Lcom/vdocipher/PlaybackSession$QualityPreference;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/PlaybackSession$QualityPreference;
    .registers 2

    if-eqz p0, :cond_16

    const/4 v0, 0x1

    if-eq p0, v0, :cond_13

    const/4 v0, 0x2

    if-eq p0, v0, :cond_10

    const/4 v0, 0x3

    if-eq p0, v0, :cond_d

    const/4 p0, 0x0

    return-object p0

    .line 830
    :cond_d
    sget-object p0, Lcom/vdocipher/PlaybackSession$QualityPreference;->middle:Lcom/vdocipher/PlaybackSession$QualityPreference;

    return-object p0

    .line 829
    :cond_10
    sget-object p0, Lcom/vdocipher/PlaybackSession$QualityPreference;->highest:Lcom/vdocipher/PlaybackSession$QualityPreference;

    return-object p0

    .line 828
    :cond_13
    sget-object p0, Lcom/vdocipher/PlaybackSession$QualityPreference;->lowest:Lcom/vdocipher/PlaybackSession$QualityPreference;

    return-object p0

    .line 827
    :cond_16
    sget-object p0, Lcom/vdocipher/PlaybackSession$QualityPreference;->auto:Lcom/vdocipher/PlaybackSession$QualityPreference;

    return-object p0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$QualityPreference;",
            ">;"
        }
    .end annotation

    .line 837
    sget-object v0, Lcom/vdocipher/PlaybackSession$QualityPreference;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 850
    sget-object v0, Lcom/vdocipher/PlaybackSession$QualityPreference$QualityPreferenceVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/PlaybackSession$QualityPreference;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 822
    invoke-static {p0}, Lcom/vdocipher/PlaybackSession$QualityPreference;->forNumber(I)Lcom/vdocipher/PlaybackSession$QualityPreference;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$QualityPreference;
    .registers 2

    .line 767
    const-class v0, Lcom/vdocipher/PlaybackSession$QualityPreference;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$QualityPreference;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/PlaybackSession$QualityPreference;
    .registers 1

    .line 767
    sget-object v0, Lcom/vdocipher/PlaybackSession$QualityPreference;->$VALUES:[Lcom/vdocipher/PlaybackSession$QualityPreference;

    invoke-virtual {v0}, [Lcom/vdocipher/PlaybackSession$QualityPreference;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/PlaybackSession$QualityPreference;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 808
    sget-object v0, Lcom/vdocipher/PlaybackSession$QualityPreference;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$QualityPreference;

    if-eq p0, v0, :cond_7

    .line 812
    iget v0, p0, Lcom/vdocipher/PlaybackSession$QualityPreference;->value:I

    return v0

    .line 809
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
