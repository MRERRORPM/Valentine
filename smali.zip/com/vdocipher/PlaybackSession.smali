# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession;
.super Ljava/lang/Object;
.source "PlaybackSession.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;,
        Lcom/vdocipher/PlaybackSession$PlaybackSessionTableOrBuilder;,
        Lcom/vdocipher/PlaybackSession$PlaybackResume;,
        Lcom/vdocipher/PlaybackSession$PlaybackResumeOrBuilder;,
        Lcom/vdocipher/PlaybackSession$Android;,
        Lcom/vdocipher/PlaybackSession$AndroidOrBuilder;,
        Lcom/vdocipher/PlaybackSession$Toolkit;,
        Lcom/vdocipher/PlaybackSession$ToolkitOrBuilder;,
        Lcom/vdocipher/PlaybackSession$Decoder;,
        Lcom/vdocipher/PlaybackSession$DecoderOrBuilder;,
        Lcom/vdocipher/PlaybackSession$WidevineCDM;,
        Lcom/vdocipher/PlaybackSession$WidevineCDMOrBuilder;,
        Lcom/vdocipher/PlaybackSession$SelectedTrack;,
        Lcom/vdocipher/PlaybackSession$SelectedTrackOrBuilder;,
        Lcom/vdocipher/PlaybackSession$TrackVideo;,
        Lcom/vdocipher/PlaybackSession$TrackVideoOrBuilder;,
        Lcom/vdocipher/PlaybackSession$TrackAudio;,
        Lcom/vdocipher/PlaybackSession$TrackAudioOrBuilder;,
        Lcom/vdocipher/PlaybackSession$Error;,
        Lcom/vdocipher/PlaybackSession$ErrorOrBuilder;,
        Lcom/vdocipher/PlaybackSession$TrackCount;,
        Lcom/vdocipher/PlaybackSession$TrackCountOrBuilder;,
        Lcom/vdocipher/PlaybackSession$Beat;,
        Lcom/vdocipher/PlaybackSession$BeatOrBuilder;,
        Lcom/vdocipher/PlaybackSession$PerfMetrics;,
        Lcom/vdocipher/PlaybackSession$PerfMetricsOrBuilder;,
        Lcom/vdocipher/PlaybackSession$Event;,
        Lcom/vdocipher/PlaybackSession$EventOrBuilder;,
        Lcom/vdocipher/PlaybackSession$Coverage;,
        Lcom/vdocipher/PlaybackSession$CoverageOrBuilder;,
        Lcom/vdocipher/PlaybackSession$NavigatorProps;,
        Lcom/vdocipher/PlaybackSession$NavigatorPropsOrBuilder;,
        Lcom/vdocipher/PlaybackSession$Device;,
        Lcom/vdocipher/PlaybackSession$DeviceOrBuilder;,
        Lcom/vdocipher/PlaybackSession$Media;,
        Lcom/vdocipher/PlaybackSession$MediaOrBuilder;,
        Lcom/vdocipher/PlaybackSession$Dimension;,
        Lcom/vdocipher/PlaybackSession$DimensionOrBuilder;,
        Lcom/vdocipher/PlaybackSession$EmbedInfo;,
        Lcom/vdocipher/PlaybackSession$EmbedInfoOrBuilder;,
        Lcom/vdocipher/PlaybackSession$CaptionSearch;,
        Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;,
        Lcom/vdocipher/PlaybackSession$ResumeType;,
        Lcom/vdocipher/PlaybackSession$CdmLevel;,
        Lcom/vdocipher/PlaybackSession$HDCPLevel;,
        Lcom/vdocipher/PlaybackSession$QualityPreference;,
        Lcom/vdocipher/PlaybackSession$EventName;,
        Lcom/vdocipher/PlaybackSession$DeviceTypes;,
        Lcom/vdocipher/PlaybackSession$SourceType;,
        Lcom/vdocipher/PlaybackSession$AuthType;
    }
.end annotation


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static registerAllExtensions(Lcom/google/protobuf/ExtensionRegistryLite;)V
    .registers 1

    return-void
.end method
