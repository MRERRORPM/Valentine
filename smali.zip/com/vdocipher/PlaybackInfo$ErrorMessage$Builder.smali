# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$ErrorMessageOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$ErrorMessage;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackInfo$ErrorMessage;",
        "Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$ErrorMessageOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 10999
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackInfo-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public addAllCodes(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Ljava/lang/Integer;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;"
        }
    .end annotation

    .line 11058
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->copyOnWrite()V

    .line 11059
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->-$$Nest$maddAllCodes(Lcom/vdocipher/PlaybackInfo$ErrorMessage;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addCodes(I)Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;
    .registers 3

    .line 11047
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->copyOnWrite()V

    .line 11048
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->-$$Nest$maddCodes(Lcom/vdocipher/PlaybackInfo$ErrorMessage;I)V

    return-object p0
.end method

.method public clearCodes()Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;
    .registers 2

    .line 11067
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->copyOnWrite()V

    .line 11068
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->-$$Nest$mclearCodes(Lcom/vdocipher/PlaybackInfo$ErrorMessage;)V

    return-object p0
.end method

.method public clearMsgDefault()Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;
    .registers 2

    .line 11154
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->copyOnWrite()V

    .line 11155
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->-$$Nest$mclearMsgDefault(Lcom/vdocipher/PlaybackInfo$ErrorMessage;)V

    return-object p0
.end method

.method public clearMsgKey()Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;
    .registers 2

    .line 11105
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->copyOnWrite()V

    .line 11106
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->-$$Nest$mclearMsgKey(Lcom/vdocipher/PlaybackInfo$ErrorMessage;)V

    return-object p0
.end method

.method public getCodes(I)I
    .registers 3

    .line 11028
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->getCodes(I)I

    move-result p1

    return p1
.end method

.method public getCodesCount()I
    .registers 2

    .line 11019
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->getCodesCount()I

    move-result v0

    return v0
.end method

.method public getCodesList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 11010
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    .line 11011
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->getCodesList()Ljava/util/List;

    move-result-object v0

    .line 11010
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getMsgDefault()Ljava/lang/String;
    .registers 2

    .line 11127
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->getMsgDefault()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getMsgDefaultBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 11136
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->getMsgDefaultBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getMsgKey()Ljava/lang/String;
    .registers 2

    .line 11078
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->getMsgKey()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getMsgKeyBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 11087
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->getMsgKeyBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setCodes(II)Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;
    .registers 4

    .line 11037
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->copyOnWrite()V

    .line 11038
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->-$$Nest$msetCodes(Lcom/vdocipher/PlaybackInfo$ErrorMessage;II)V

    return-object p0
.end method

.method public setMsgDefault(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;
    .registers 3

    .line 11145
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->copyOnWrite()V

    .line 11146
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->-$$Nest$msetMsgDefault(Lcom/vdocipher/PlaybackInfo$ErrorMessage;Ljava/lang/String;)V

    return-object p0
.end method

.method public setMsgDefaultBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;
    .registers 3

    .line 11165
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->copyOnWrite()V

    .line 11166
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->-$$Nest$msetMsgDefaultBytes(Lcom/vdocipher/PlaybackInfo$ErrorMessage;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setMsgKey(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;
    .registers 3

    .line 11096
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->copyOnWrite()V

    .line 11097
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->-$$Nest$msetMsgKey(Lcom/vdocipher/PlaybackInfo$ErrorMessage;Ljava/lang/String;)V

    return-object p0
.end method

.method public setMsgKeyBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;
    .registers 3

    .line 11116
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->copyOnWrite()V

    .line 11117
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->-$$Nest$msetMsgKeyBytes(Lcom/vdocipher/PlaybackInfo$ErrorMessage;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
