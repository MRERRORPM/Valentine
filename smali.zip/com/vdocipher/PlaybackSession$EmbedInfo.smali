# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$EmbedInfo;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$EmbedInfoOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "EmbedInfo"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$EmbedInfo;",
        "Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$EmbedInfoOrBuilder;"
    }
.end annotation


# static fields
.field public static final AUTHTYPE_FIELD_NUMBER:I = 0x1

.field public static final AUTH_FIELD_NUMBER:I = 0x4

.field public static final AUTOPLAY_FIELD_NUMBER:I = 0x6

.field public static final BUFFERINGGOAL_FIELD_NUMBER:I = 0x7

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

.field public static final LOOP_FIELD_NUMBER:I = 0x8

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$EmbedInfo;",
            ">;"
        }
    .end annotation
.end field

.field public static final PLAYBACKINFO_FIELD_NUMBER:I = 0x2

.field public static final PLUGIN_FIELD_NUMBER:I = 0x9

.field public static final SOURCETYPE_FIELD_NUMBER:I = 0x5

.field public static final THEME_FIELD_NUMBER:I = 0x3


# instance fields
.field private authType_:I

.field private auth_:Ljava/lang/String;

.field private autoplay_:Z

.field private bufferingGoal_:I

.field private loop_:Z

.field private playbackInfo_:Ljava/lang/String;

.field private plugin_:Ljava/lang/String;

.field private sourceType_:I

.field private theme_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$mclearAuth(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->clearAuth()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearAuthType(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->clearAuthType()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearAutoplay(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->clearAutoplay()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearBufferingGoal(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->clearBufferingGoal()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLoop(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->clearLoop()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPlaybackInfo(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->clearPlaybackInfo()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPlugin(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->clearPlugin()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSourceType(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->clearSourceType()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearTheme(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->clearTheme()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAuth(Lcom/vdocipher/PlaybackSession$EmbedInfo;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->setAuth(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAuthBytes(Lcom/vdocipher/PlaybackSession$EmbedInfo;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->setAuthBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAuthType(Lcom/vdocipher/PlaybackSession$EmbedInfo;Lcom/vdocipher/PlaybackSession$AuthType;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->setAuthType(Lcom/vdocipher/PlaybackSession$AuthType;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAuthTypeValue(Lcom/vdocipher/PlaybackSession$EmbedInfo;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->setAuthTypeValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAutoplay(Lcom/vdocipher/PlaybackSession$EmbedInfo;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->setAutoplay(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetBufferingGoal(Lcom/vdocipher/PlaybackSession$EmbedInfo;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->setBufferingGoal(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLoop(Lcom/vdocipher/PlaybackSession$EmbedInfo;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->setLoop(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPlaybackInfo(Lcom/vdocipher/PlaybackSession$EmbedInfo;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->setPlaybackInfo(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPlaybackInfoBytes(Lcom/vdocipher/PlaybackSession$EmbedInfo;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->setPlaybackInfoBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPlugin(Lcom/vdocipher/PlaybackSession$EmbedInfo;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->setPlugin(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPluginBytes(Lcom/vdocipher/PlaybackSession$EmbedInfo;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->setPluginBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSourceType(Lcom/vdocipher/PlaybackSession$EmbedInfo;Lcom/vdocipher/PlaybackSession$SourceType;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->setSourceType(Lcom/vdocipher/PlaybackSession$SourceType;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSourceTypeValue(Lcom/vdocipher/PlaybackSession$EmbedInfo;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->setSourceTypeValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTheme(Lcom/vdocipher/PlaybackSession$EmbedInfo;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->setTheme(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetThemeBytes(Lcom/vdocipher/PlaybackSession$EmbedInfo;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->setThemeBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 2395
    new-instance v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;-><init>()V

    .line 2398
    sput-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    .line 2399
    const-class v1, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 1506
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 1507
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->playbackInfo_:Ljava/lang/String;

    .line 1508
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->theme_:Ljava/lang/String;

    .line 1509
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->auth_:Ljava/lang/String;

    .line 1510
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->plugin_:Ljava/lang/String;

    return-void
.end method

.method private clearAuth()V
    .registers 2

    .line 1682
    invoke-static {}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$EmbedInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getAuth()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->auth_:Ljava/lang/String;

    return-void
.end method

.method private clearAuthType()V
    .registers 2

    const/4 v0, 0x0

    .line 1551
    iput v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->authType_:I

    return-void
.end method

.method private clearAutoplay()V
    .registers 2

    const/4 v0, 0x0

    .line 1760
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->autoplay_:Z

    return-void
.end method

.method private clearBufferingGoal()V
    .registers 2

    const/4 v0, 0x0

    .line 1786
    iput v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->bufferingGoal_:I

    return-void
.end method

.method private clearLoop()V
    .registers 2

    const/4 v0, 0x0

    .line 1812
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->loop_:Z

    return-void
.end method

.method private clearPlaybackInfo()V
    .registers 2

    .line 1588
    invoke-static {}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$EmbedInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getPlaybackInfo()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->playbackInfo_:Ljava/lang/String;

    return-void
.end method

.method private clearPlugin()V
    .registers 2

    .line 1849
    invoke-static {}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$EmbedInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getPlugin()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->plugin_:Ljava/lang/String;

    return-void
.end method

.method private clearSourceType()V
    .registers 2

    const/4 v0, 0x0

    .line 1734
    iput v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->sourceType_:I

    return-void
.end method

.method private clearTheme()V
    .registers 2

    .line 1635
    invoke-static {}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$EmbedInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getTheme()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->theme_:Ljava/lang/String;

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 1

    .line 2404
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 1

    .line 1939
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$EmbedInfo;)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 2

    .line 1942
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1915
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1922
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1878
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1885
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1927
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1934
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1902
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1909
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1865
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1872
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1890
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1897
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$EmbedInfo;",
            ">;"
        }
    .end annotation

    .line 2410
    sget-object v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setAuth(Ljava/lang/String;)V
    .registers 2

    .line 1673
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1675
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->auth_:Ljava/lang/String;

    return-void
.end method

.method private setAuthBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 1690
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 1691
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->auth_:Ljava/lang/String;

    return-void
.end method

.method private setAuthType(Lcom/vdocipher/PlaybackSession$AuthType;)V
    .registers 2

    .line 1543
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$AuthType;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->authType_:I

    return-void
.end method

.method private setAuthTypeValue(I)V
    .registers 2

    .line 1536
    iput p1, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->authType_:I

    return-void
.end method

.method private setAutoplay(Z)V
    .registers 2

    .line 1753
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->autoplay_:Z

    return-void
.end method

.method private setBufferingGoal(I)V
    .registers 2

    .line 1779
    iput p1, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->bufferingGoal_:I

    return-void
.end method

.method private setLoop(Z)V
    .registers 2

    .line 1805
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->loop_:Z

    return-void
.end method

.method private setPlaybackInfo(Ljava/lang/String;)V
    .registers 2

    .line 1579
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1581
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->playbackInfo_:Ljava/lang/String;

    return-void
.end method

.method private setPlaybackInfoBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 1596
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 1597
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->playbackInfo_:Ljava/lang/String;

    return-void
.end method

.method private setPlugin(Ljava/lang/String;)V
    .registers 2

    .line 1840
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1842
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->plugin_:Ljava/lang/String;

    return-void
.end method

.method private setPluginBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 1857
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 1858
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->plugin_:Ljava/lang/String;

    return-void
.end method

.method private setSourceType(Lcom/vdocipher/PlaybackSession$SourceType;)V
    .registers 2

    .line 1726
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$SourceType;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->sourceType_:I

    return-void
.end method

.method private setSourceTypeValue(I)V
    .registers 2

    .line 1719
    iput p1, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->sourceType_:I

    return-void
.end method

.method private setTheme(Ljava/lang/String;)V
    .registers 2

    .line 1626
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1628
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->theme_:Ljava/lang/String;

    return-void
.end method

.method private setThemeBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 1643
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 1644
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->theme_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 13

    .line 2338
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_64

    .line 2388
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 2382
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 2367
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$EmbedInfo;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_33

    .line 2369
    const-class p2, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    monitor-enter p2

    .line 2370
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$EmbedInfo;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 2372
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 2375
    sput-object p1, Lcom/vdocipher/PlaybackSession$EmbedInfo;->PARSER:Lcom/google/protobuf/Parser;

    .line 2377
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception v0

    move-object p1, v0

    monitor-exit p2
    :try_end_32
    .catchall {:try_start_20 .. :try_end_32} :catchall_2f

    throw p1

    :cond_33
    return-object p1

    .line 2364
    :pswitch_34  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    return-object p1

    .line 2346
    :pswitch_37  #0x3
    const-string v0, "authType_"

    const-string v1, "playbackInfo_"

    const-string/jumbo v2, "theme_"

    const-string v3, "auth_"

    const-string/jumbo v4, "sourceType_"

    const-string v5, "autoplay_"

    const-string v6, "bufferingGoal_"

    const-string v7, "loop_"

    const-string v8, "plugin_"

    filled-new-array/range {v0 .. v8}, [Ljava/lang/Object;

    move-result-object p1

    .line 2357
    const-string p2, "\u0000\t\u0000\u0000\u0001\t\t\u0000\u0000\u0000\u0001\f\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005\f\u0006\u0007\u0007\u000b\b\u0007\tȈ"

    .line 2360
    sget-object p3, Lcom/vdocipher/PlaybackSession$EmbedInfo;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 2343
    :pswitch_58  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 2340
    :pswitch_5e  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;-><init>()V

    return-object p1

    :pswitch_data_64
    .packed-switch 0x1
        :pswitch_5e  #00000001
        :pswitch_58  #00000002
        :pswitch_37  #00000003
        :pswitch_34  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getAuth()Ljava/lang/String;
    .registers 2

    .line 1656
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->auth_:Ljava/lang/String;

    return-object v0
.end method

.method public getAuthBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 1665
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->auth_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getAuthType()Lcom/vdocipher/PlaybackSession$AuthType;
    .registers 2

    .line 1528
    iget v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->authType_:I

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$AuthType;->forNumber(I)Lcom/vdocipher/PlaybackSession$AuthType;

    move-result-object v0

    if-nez v0, :cond_a

    .line 1529
    sget-object v0, Lcom/vdocipher/PlaybackSession$AuthType;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$AuthType;

    :cond_a
    return-object v0
.end method

.method public getAuthTypeValue()I
    .registers 2

    .line 1520
    iget v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->authType_:I

    return v0
.end method

.method public getAutoplay()Z
    .registers 2

    .line 1745
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->autoplay_:Z

    return v0
.end method

.method public getBufferingGoal()I
    .registers 2

    .line 1771
    iget v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->bufferingGoal_:I

    return v0
.end method

.method public getLoop()Z
    .registers 2

    .line 1797
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->loop_:Z

    return v0
.end method

.method public getPlaybackInfo()Ljava/lang/String;
    .registers 2

    .line 1562
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->playbackInfo_:Ljava/lang/String;

    return-object v0
.end method

.method public getPlaybackInfoBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 1571
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->playbackInfo_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getPlugin()Ljava/lang/String;
    .registers 2

    .line 1823
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->plugin_:Ljava/lang/String;

    return-object v0
.end method

.method public getPluginBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 1832
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->plugin_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSourceType()Lcom/vdocipher/PlaybackSession$SourceType;
    .registers 2

    .line 1711
    iget v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->sourceType_:I

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$SourceType;->forNumber(I)Lcom/vdocipher/PlaybackSession$SourceType;

    move-result-object v0

    if-nez v0, :cond_a

    .line 1712
    sget-object v0, Lcom/vdocipher/PlaybackSession$SourceType;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$SourceType;

    :cond_a
    return-object v0
.end method

.method public getSourceTypeValue()I
    .registers 2

    .line 1703
    iget v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->sourceType_:I

    return v0
.end method

.method public getTheme()Ljava/lang/String;
    .registers 2

    .line 1609
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->theme_:Ljava/lang/String;

    return-object v0
.end method

.method public getThemeBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 1618
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo;->theme_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method
