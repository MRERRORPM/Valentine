# classes14.dex

.class public interface abstract Lcom/vdocipher/Manifest$AspectRatioOrBuilder;
.super Ljava/lang/Object;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "AspectRatioOrBuilder"
.end annotation


# virtual methods
.method public abstract getHeight()I
.end method

.method public abstract getWidth()I
.end method
