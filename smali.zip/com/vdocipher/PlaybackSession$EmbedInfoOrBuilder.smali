# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackSession$EmbedInfoOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "EmbedInfoOrBuilder"
.end annotation


# virtual methods
.method public abstract getAuth()Ljava/lang/String;
.end method

.method public abstract getAuthBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getAuthType()Lcom/vdocipher/PlaybackSession$AuthType;
.end method

.method public abstract getAuthTypeValue()I
.end method

.method public abstract getAutoplay()Z
.end method

.method public abstract getBufferingGoal()I
.end method

.method public abstract getLoop()Z
.end method

.method public abstract getPlaybackInfo()Ljava/lang/String;
.end method

.method public abstract getPlaybackInfoBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getPlugin()Ljava/lang/String;
.end method

.method public abstract getPluginBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getSourceType()Lcom/vdocipher/PlaybackSession$SourceType;
.end method

.method public abstract getSourceTypeValue()I
.end method

.method public abstract getTheme()Ljava/lang/String;
.end method

.method public abstract getThemeBytes()Lcom/google/protobuf/ByteString;
.end method
