# classes14.dex

.class public final Lcom/vdocipher/Manifest$SegmentBase$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$SegmentBaseOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest$SegmentBase;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/Manifest$SegmentBase;",
        "Lcom/vdocipher/Manifest$SegmentBase$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$SegmentBaseOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 2238
    invoke-static {}, Lcom/vdocipher/Manifest$SegmentBase;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$SegmentBase;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/Manifest-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentBase$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearIndexRangeEnd()Lcom/vdocipher/Manifest$SegmentBase$Builder;
    .registers 2

    .line 2293
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentBase$Builder;->copyOnWrite()V

    .line 2294
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SegmentBase;->-$$Nest$mclearIndexRangeEnd(Lcom/vdocipher/Manifest$SegmentBase;)V

    return-object p0
.end method

.method public clearIndexRangeStart()Lcom/vdocipher/Manifest$SegmentBase$Builder;
    .registers 2

    .line 2265
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentBase$Builder;->copyOnWrite()V

    .line 2266
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SegmentBase;->-$$Nest$mclearIndexRangeStart(Lcom/vdocipher/Manifest$SegmentBase;)V

    return-object p0
.end method

.method public clearInitialization()Lcom/vdocipher/Manifest$SegmentBase$Builder;
    .registers 2

    .line 2404
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentBase$Builder;->copyOnWrite()V

    .line 2405
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SegmentBase;->-$$Nest$mclearInitialization(Lcom/vdocipher/Manifest$SegmentBase;)V

    return-object p0
.end method

.method public clearPresentationTimeOffset()Lcom/vdocipher/Manifest$SegmentBase$Builder;
    .registers 2

    .line 2357
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentBase$Builder;->copyOnWrite()V

    .line 2358
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SegmentBase;->-$$Nest$mclearPresentationTimeOffset(Lcom/vdocipher/Manifest$SegmentBase;)V

    return-object p0
.end method

.method public clearTimescale()Lcom/vdocipher/Manifest$SegmentBase$Builder;
    .registers 2

    .line 2321
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentBase$Builder;->copyOnWrite()V

    .line 2322
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SegmentBase;->-$$Nest$mclearTimescale(Lcom/vdocipher/Manifest$SegmentBase;)V

    return-object p0
.end method

.method public getIndexRangeEnd()I
    .registers 2

    .line 2276
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentBase;->getIndexRangeEnd()I

    move-result v0

    return v0
.end method

.method public getIndexRangeStart()I
    .registers 2

    .line 2248
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentBase;->getIndexRangeStart()I

    move-result v0

    return v0
.end method

.method public getInitialization()Lcom/vdocipher/Manifest$Initialization;
    .registers 2

    .line 2374
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentBase;->getInitialization()Lcom/vdocipher/Manifest$Initialization;

    move-result-object v0

    return-object v0
.end method

.method public getPresentationTimeOffset()I
    .registers 2

    .line 2340
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentBase;->getPresentationTimeOffset()I

    move-result v0

    return v0
.end method

.method public getTimescale()I
    .registers 2

    .line 2304
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentBase;->getTimescale()I

    move-result v0

    return v0
.end method

.method public hasInitialization()Z
    .registers 2

    .line 2367
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentBase;->hasInitialization()Z

    move-result v0

    return v0
.end method

.method public hasPresentationTimeOffset()Z
    .registers 2

    .line 2332
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentBase;->hasPresentationTimeOffset()Z

    move-result v0

    return v0
.end method

.method public mergeInitialization(Lcom/vdocipher/Manifest$Initialization;)Lcom/vdocipher/Manifest$SegmentBase$Builder;
    .registers 3

    .line 2397
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentBase$Builder;->copyOnWrite()V

    .line 2398
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentBase;->-$$Nest$mmergeInitialization(Lcom/vdocipher/Manifest$SegmentBase;Lcom/vdocipher/Manifest$Initialization;)V

    return-object p0
.end method

.method public setIndexRangeEnd(I)Lcom/vdocipher/Manifest$SegmentBase$Builder;
    .registers 3

    .line 2284
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentBase$Builder;->copyOnWrite()V

    .line 2285
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentBase;->-$$Nest$msetIndexRangeEnd(Lcom/vdocipher/Manifest$SegmentBase;I)V

    return-object p0
.end method

.method public setIndexRangeStart(I)Lcom/vdocipher/Manifest$SegmentBase$Builder;
    .registers 3

    .line 2256
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentBase$Builder;->copyOnWrite()V

    .line 2257
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentBase;->-$$Nest$msetIndexRangeStart(Lcom/vdocipher/Manifest$SegmentBase;I)V

    return-object p0
.end method

.method public setInitialization(Lcom/vdocipher/Manifest$Initialization$Builder;)Lcom/vdocipher/Manifest$SegmentBase$Builder;
    .registers 3

    .line 2389
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentBase$Builder;->copyOnWrite()V

    .line 2390
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$Initialization$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentBase;->-$$Nest$msetInitialization(Lcom/vdocipher/Manifest$SegmentBase;Lcom/vdocipher/Manifest$Initialization;)V

    return-object p0
.end method

.method public setInitialization(Lcom/vdocipher/Manifest$Initialization;)Lcom/vdocipher/Manifest$SegmentBase$Builder;
    .registers 3

    .line 2380
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentBase$Builder;->copyOnWrite()V

    .line 2381
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentBase;->-$$Nest$msetInitialization(Lcom/vdocipher/Manifest$SegmentBase;Lcom/vdocipher/Manifest$Initialization;)V

    return-object p0
.end method

.method public setPresentationTimeOffset(I)Lcom/vdocipher/Manifest$SegmentBase$Builder;
    .registers 3

    .line 2348
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentBase$Builder;->copyOnWrite()V

    .line 2349
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentBase;->-$$Nest$msetPresentationTimeOffset(Lcom/vdocipher/Manifest$SegmentBase;I)V

    return-object p0
.end method

.method public setTimescale(I)Lcom/vdocipher/Manifest$SegmentBase$Builder;
    .registers 3

    .line 2312
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentBase$Builder;->copyOnWrite()V

    .line 2313
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentBase$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentBase;->-$$Nest$msetTimescale(Lcom/vdocipher/Manifest$SegmentBase;I)V

    return-object p0
.end method
