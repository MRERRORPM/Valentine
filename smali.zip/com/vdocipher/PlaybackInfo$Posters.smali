# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$Posters;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$PostersOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Posters"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$Posters$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackInfo$Posters;",
        "Lcom/vdocipher/PlaybackInfo$Posters$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$PostersOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

.field public static final HEIGHT_FIELD_NUMBER:I = 0x2

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$Posters;",
            ">;"
        }
    .end annotation
.end field

.field public static final URL_FIELD_NUMBER:I = 0x1


# instance fields
.field private height_:I

.field private url_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$mclearHeight(Lcom/vdocipher/PlaybackInfo$Posters;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Posters;->clearHeight()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearUrl(Lcom/vdocipher/PlaybackInfo$Posters;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Posters;->clearUrl()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetHeight(Lcom/vdocipher/PlaybackInfo$Posters;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Posters;->setHeight(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetUrl(Lcom/vdocipher/PlaybackInfo$Posters;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Posters;->setUrl(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetUrlBytes(Lcom/vdocipher/PlaybackInfo$Posters;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Posters;->setUrlBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 1072
    new-instance v0, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$Posters;-><init>()V

    .line 1075
    sput-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    .line 1076
    const-class v1, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 765
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 766
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Posters;->url_:Ljava/lang/String;

    return-void
.end method

.method private clearHeight()V
    .registers 2

    const/4 v0, 0x0

    .line 838
    iput v0, p0, Lcom/vdocipher/PlaybackInfo$Posters;->height_:I

    return-void
.end method

.method private clearUrl()V
    .registers 2

    .line 802
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Posters;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$Posters;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Posters;->getUrl()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Posters;->url_:Ljava/lang/String;

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 1

    .line 1081
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackInfo$Posters$Builder;
    .registers 1

    .line 918
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Posters;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Posters$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackInfo$Posters;)Lcom/vdocipher/PlaybackInfo$Posters$Builder;
    .registers 2

    .line 921
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$Posters;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Posters$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 894
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackInfo$Posters;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Posters;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 901
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackInfo$Posters;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Posters;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 857
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Posters;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 864
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Posters;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 906
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Posters;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 913
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Posters;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 881
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Posters;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 888
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Posters;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 844
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Posters;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 851
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Posters;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 869
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Posters;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 876
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Posters;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$Posters;",
            ">;"
        }
    .end annotation

    .line 1087
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Posters;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setHeight(I)V
    .registers 2

    .line 831
    iput p1, p0, Lcom/vdocipher/PlaybackInfo$Posters;->height_:I

    return-void
.end method

.method private setUrl(Ljava/lang/String;)V
    .registers 2

    .line 793
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 795
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Posters;->url_:Ljava/lang/String;

    return-void
.end method

.method private setUrlBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 810
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$Posters;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 811
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Posters;->url_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1022
    sget-object p2, Lcom/vdocipher/PlaybackInfo$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_54

    .line 1065
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 1059
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 1044
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackInfo$Posters;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 1046
    const-class p2, Lcom/vdocipher/PlaybackInfo$Posters;

    monitor-enter p2

    .line 1047
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackInfo$Posters;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 1049
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 1052
    sput-object p1, Lcom/vdocipher/PlaybackInfo$Posters;->PARSER:Lcom/google/protobuf/Parser;

    .line 1054
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 1041
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    return-object p1

    .line 1030
    :pswitch_36  #0x3
    const-string/jumbo p1, "url_"

    const-string p2, "height_"

    filled-new-array {p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    .line 1034
    const-string p2, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002\u000b"

    .line 1037
    sget-object p3, Lcom/vdocipher/PlaybackInfo$Posters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackInfo$Posters;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 1027
    :pswitch_48  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackInfo$Posters$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackInfo$Posters$Builder;-><init>(Lcom/vdocipher/PlaybackInfo-IA;)V

    return-object p1

    .line 1024
    :pswitch_4e  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackInfo$Posters;-><init>()V

    return-object p1

    :pswitch_data_54
    .packed-switch 0x1
        :pswitch_4e  #00000001
        :pswitch_48  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getHeight()I
    .registers 2

    .line 823
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$Posters;->height_:I

    return v0
.end method

.method public getUrl()Ljava/lang/String;
    .registers 2

    .line 776
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Posters;->url_:Ljava/lang/String;

    return-object v0
.end method

.method public getUrlBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 785
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Posters;->url_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method
