# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackSession$ErrorOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "ErrorOrBuilder"
.end annotation


# virtual methods
.method public abstract getDisplayMsg()Ljava/lang/String;
.end method

.method public abstract getDisplayMsgBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getInternalCode()I
.end method

.method public abstract getPayload()Ljava/lang/String;
.end method

.method public abstract getPayloadBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getVdo()I
.end method
