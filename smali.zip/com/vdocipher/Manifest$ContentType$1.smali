# classes14.dex

.class Lcom/vdocipher/Manifest$ContentType$1;
.super Ljava/lang/Object;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLiteMap;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest$ContentType;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/google/protobuf/Internal$EnumLiteMap<",
        "Lcom/vdocipher/Manifest$ContentType;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .line 267
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic findValueByNumber(I)Lcom/google/protobuf/Internal$EnumLite;
    .registers 2

    .line 267
    invoke-virtual {p0, p1}, Lcom/vdocipher/Manifest$ContentType$1;->findValueByNumber(I)Lcom/vdocipher/Manifest$ContentType;

    move-result-object p1

    return-object p1
.end method

.method public findValueByNumber(I)Lcom/vdocipher/Manifest$ContentType;
    .registers 2

    .line 270
    invoke-static {p1}, Lcom/vdocipher/Manifest$ContentType;->forNumber(I)Lcom/vdocipher/Manifest$ContentType;

    move-result-object p1

    return-object p1
.end method
