# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$MetadataTableOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$MetadataTable;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackInfo$MetadataTable;",
        "Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$MetadataTableOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 13723
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$MetadataTable;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackInfo-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public addAllAltHosts(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;"
        }
    .end annotation

    .line 15197
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15198
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddAllAltHosts(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllCaptions(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$Captions;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;"
        }
    .end annotation

    .line 14492
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14493
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddAllCaptions(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllChapters(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$Chapters;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;"
        }
    .end annotation

    .line 14867
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14868
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddAllChapters(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllCtas(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$Cta;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;"
        }
    .end annotation

    .line 15303
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15304
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddAllCtas(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllErrorMsgs(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$ErrorMessage;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;"
        }
    .end annotation

    .line 15052
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15053
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddAllErrorMsgs(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllHostnames(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;"
        }
    .end annotation

    .line 13948
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13949
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddAllHostnames(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllPosters(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$Posters;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;"
        }
    .end annotation

    .line 14307
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14308
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddAllPosters(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllTech(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$TechOptions;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;"
        }
    .end annotation

    .line 14076
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14077
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddAllTech(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllTechValue(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/Integer;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;"
        }
    .end annotation

    .line 14136
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14137
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddAllTechValue(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAltHosts(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 15186
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15187
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddAltHosts(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public addAltHostsBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 15217
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15218
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddAltHostsBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public addCaptions(ILcom/vdocipher/PlaybackInfo$Captions$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 14482
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14483
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 14484
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackInfo$Captions;

    .line 14483
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddCaptions(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Captions;)V

    return-object p0
.end method

.method public addCaptions(ILcom/vdocipher/PlaybackInfo$Captions;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 14464
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14465
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddCaptions(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Captions;)V

    return-object p0
.end method

.method public addCaptions(Lcom/vdocipher/PlaybackInfo$Captions$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14473
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14474
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddCaptions(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$Captions;)V

    return-object p0
.end method

.method public addCaptions(Lcom/vdocipher/PlaybackInfo$Captions;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14455
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14456
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddCaptions(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$Captions;)V

    return-object p0
.end method

.method public addChapters(ILcom/vdocipher/PlaybackInfo$Chapters$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 14857
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14858
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 14859
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackInfo$Chapters;

    .line 14858
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddChapters(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Chapters;)V

    return-object p0
.end method

.method public addChapters(ILcom/vdocipher/PlaybackInfo$Chapters;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 14839
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14840
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddChapters(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Chapters;)V

    return-object p0
.end method

.method public addChapters(Lcom/vdocipher/PlaybackInfo$Chapters$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14848
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14849
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddChapters(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$Chapters;)V

    return-object p0
.end method

.method public addChapters(Lcom/vdocipher/PlaybackInfo$Chapters;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14830
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14831
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddChapters(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$Chapters;)V

    return-object p0
.end method

.method public addCtas(ILcom/vdocipher/PlaybackInfo$Cta$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 15293
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15294
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 15295
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackInfo$Cta;

    .line 15294
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddCtas(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Cta;)V

    return-object p0
.end method

.method public addCtas(ILcom/vdocipher/PlaybackInfo$Cta;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 15275
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15276
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddCtas(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Cta;)V

    return-object p0
.end method

.method public addCtas(Lcom/vdocipher/PlaybackInfo$Cta$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 15284
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15285
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddCtas(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$Cta;)V

    return-object p0
.end method

.method public addCtas(Lcom/vdocipher/PlaybackInfo$Cta;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 15266
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15267
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddCtas(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$Cta;)V

    return-object p0
.end method

.method public addErrorMsgs(ILcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 15042
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15043
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 15044
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    .line 15043
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddErrorMsgs(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$ErrorMessage;)V

    return-object p0
.end method

.method public addErrorMsgs(ILcom/vdocipher/PlaybackInfo$ErrorMessage;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 15024
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15025
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddErrorMsgs(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$ErrorMessage;)V

    return-object p0
.end method

.method public addErrorMsgs(Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 15033
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15034
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddErrorMsgs(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$ErrorMessage;)V

    return-object p0
.end method

.method public addErrorMsgs(Lcom/vdocipher/PlaybackInfo$ErrorMessage;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 15015
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15016
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddErrorMsgs(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$ErrorMessage;)V

    return-object p0
.end method

.method public addHostnames(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 13937
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13938
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddHostnames(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public addHostnamesBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 13968
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13969
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddHostnamesBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public addPosters(ILcom/vdocipher/PlaybackInfo$Posters$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 14297
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14298
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 14299
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackInfo$Posters;

    .line 14298
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddPosters(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Posters;)V

    return-object p0
.end method

.method public addPosters(ILcom/vdocipher/PlaybackInfo$Posters;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 14279
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14280
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddPosters(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Posters;)V

    return-object p0
.end method

.method public addPosters(Lcom/vdocipher/PlaybackInfo$Posters$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14288
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14289
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddPosters(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$Posters;)V

    return-object p0
.end method

.method public addPosters(Lcom/vdocipher/PlaybackInfo$Posters;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14270
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14271
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddPosters(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$Posters;)V

    return-object p0
.end method

.method public addTech(Lcom/vdocipher/PlaybackInfo$TechOptions;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14065
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14066
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddTech(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$TechOptions;)V

    return-object p0
.end method

.method public addTechValue(I)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14125
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14126
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$maddTechValue(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V

    return-object p0
.end method

.method public clearAltHosts()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 15206
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15207
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearAltHosts(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearAspectRatio()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 13876
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13877
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearAspectRatio(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearAudioOnly()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14164
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14165
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearAudioOnly(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearCanSkipIntegrityCheck()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14919
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14920
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearCanSkipIntegrityCheck(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearCaptions()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14500
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14501
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearCaptions(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearCbcs()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14649
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14650
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearCbcs(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearChapters()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14875
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14876
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearChapters(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearCtas()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 15311
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15312
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearCtas(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearDash()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14602
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14603
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearDash(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearDescription()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 13809
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13810
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearDescription(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearDesiredBitrate()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14359
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14360
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearDesiredBitrate(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearDuration()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 13848
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13849
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearDuration(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearEmbedUrl()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14006
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14007
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearEmbedUrl(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearErrorMsgs()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 15060
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15061
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearErrorMsgs(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearFps()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14555
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14556
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearFps(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearH6()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14696
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14697
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearH6(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearHostnames()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 13957
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13958
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearHostnames(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearIntegrityCloudId()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14742
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14743
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearIntegrityCloudId(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearLanguage()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14966
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14967
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearLanguage(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearPlayerConfig()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14406
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14407
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearPlayerConfig(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearPosters()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14315
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14316
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearPosters(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearScrubbingPreviewUrl()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 15114
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15115
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearScrubbingPreviewUrl(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearTech()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14084
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14085
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearTech(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearTitle()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 13760
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13761
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearTitle(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearVdocipherBranding()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14781
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14782
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearVdocipherBranding(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearVersion()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 15357
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15358
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearVersion(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public clearWhitelistHref()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 14210
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14211
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mclearWhitelistHref(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V

    return-object p0
.end method

.method public getAltHosts(I)Ljava/lang/String;
    .registers 3

    .line 15155
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getAltHosts(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public getAltHostsBytes(I)Lcom/google/protobuf/ByteString;
    .registers 3

    .line 15165
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getAltHostsBytes(I)Lcom/google/protobuf/ByteString;

    move-result-object p1

    return-object p1
.end method

.method public getAltHostsCount()I
    .registers 2

    .line 15146
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getAltHostsCount()I

    move-result v0

    return v0
.end method

.method public getAltHostsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 15137
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 15138
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getAltHostsList()Ljava/util/List;

    move-result-object v0

    .line 15137
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getAspectRatio()F
    .registers 2

    .line 13859
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getAspectRatio()F

    move-result v0

    return v0
.end method

.method public getAudioOnly()Z
    .registers 2

    .line 14147
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getAudioOnly()Z

    move-result v0

    return v0
.end method

.method public getCanSkipIntegrityCheck()Z
    .registers 2

    .line 14902
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getCanSkipIntegrityCheck()Z

    move-result v0

    return v0
.end method

.method public getCaptions(I)Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 3

    .line 14430
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getCaptions(I)Lcom/vdocipher/PlaybackInfo$Captions;

    move-result-object p1

    return-object p1
.end method

.method public getCaptionsCount()I
    .registers 2

    .line 14424
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getCaptionsCount()I

    move-result v0

    return v0
.end method

.method public getCaptionsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$Captions;",
            ">;"
        }
    .end annotation

    .line 14416
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 14417
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getCaptionsList()Ljava/util/List;

    move-result-object v0

    .line 14416
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getCbcs()Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 2

    .line 14619
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getCbcs()Lcom/vdocipher/PlaybackInfo$CBCSI;

    move-result-object v0

    return-object v0
.end method

.method public getChapters(I)Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 3

    .line 14805
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getChapters(I)Lcom/vdocipher/PlaybackInfo$Chapters;

    move-result-object p1

    return-object p1
.end method

.method public getChaptersCount()I
    .registers 2

    .line 14799
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getChaptersCount()I

    move-result v0

    return v0
.end method

.method public getChaptersList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$Chapters;",
            ">;"
        }
    .end annotation

    .line 14791
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 14792
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getChaptersList()Ljava/util/List;

    move-result-object v0

    .line 14791
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getCtas(I)Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 3

    .line 15241
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getCtas(I)Lcom/vdocipher/PlaybackInfo$Cta;

    move-result-object p1

    return-object p1
.end method

.method public getCtasCount()I
    .registers 2

    .line 15235
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getCtasCount()I

    move-result v0

    return v0
.end method

.method public getCtasList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$Cta;",
            ">;"
        }
    .end annotation

    .line 15227
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 15228
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getCtasList()Ljava/util/List;

    move-result-object v0

    .line 15227
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getDash()Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 2

    .line 14572
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDash()Lcom/vdocipher/PlaybackInfo$DASH;

    move-result-object v0

    return-object v0
.end method

.method public getDescription()Ljava/lang/String;
    .registers 2

    .line 13782
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDescription()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getDescriptionBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 13791
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDescriptionBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getDesiredBitrate()I
    .registers 2

    .line 14342
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDesiredBitrate()I

    move-result v0

    return v0
.end method

.method public getDuration()I
    .registers 2

    .line 13831
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDuration()I

    move-result v0

    return v0
.end method

.method public getEmbedUrl()Ljava/lang/String;
    .registers 2

    .line 13979
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getEmbedUrl()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getEmbedUrlBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 13988
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getEmbedUrlBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getErrorMsgs(I)Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 3

    .line 14990
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getErrorMsgs(I)Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    move-result-object p1

    return-object p1
.end method

.method public getErrorMsgsCount()I
    .registers 2

    .line 14984
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getErrorMsgsCount()I

    move-result v0

    return v0
.end method

.method public getErrorMsgsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$ErrorMessage;",
            ">;"
        }
    .end annotation

    .line 14976
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 14977
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getErrorMsgsList()Ljava/util/List;

    move-result-object v0

    .line 14976
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getFps()Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 2

    .line 14525
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getFps()Lcom/vdocipher/PlaybackInfo$FPS;

    move-result-object v0

    return-object v0
.end method

.method public getH6()Lcom/vdocipher/PlaybackInfo$H6;
    .registers 2

    .line 14666
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getH6()Lcom/vdocipher/PlaybackInfo$H6;

    move-result-object v0

    return-object v0
.end method

.method public getHostnames(I)Ljava/lang/String;
    .registers 3

    .line 13906
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getHostnames(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public getHostnamesBytes(I)Lcom/google/protobuf/ByteString;
    .registers 3

    .line 13916
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getHostnamesBytes(I)Lcom/google/protobuf/ByteString;

    move-result-object p1

    return-object p1
.end method

.method public getHostnamesCount()I
    .registers 2

    .line 13897
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getHostnamesCount()I

    move-result v0

    return v0
.end method

.method public getHostnamesList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 13888
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 13889
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getHostnamesList()Ljava/util/List;

    move-result-object v0

    .line 13888
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getIntegrityCloudId()Ljava/lang/String;
    .registers 2

    .line 14715
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getIntegrityCloudId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getIntegrityCloudIdBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 14724
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getIntegrityCloudIdBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getLanguage()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 2

    .line 14936
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getLanguage()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    move-result-object v0

    return-object v0
.end method

.method public getPlayerConfig()Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 2

    .line 14376
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getPlayerConfig()Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    move-result-object v0

    return-object v0
.end method

.method public getPosters(I)Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 3

    .line 14245
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getPosters(I)Lcom/vdocipher/PlaybackInfo$Posters;

    move-result-object p1

    return-object p1
.end method

.method public getPostersCount()I
    .registers 2

    .line 14239
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getPostersCount()I

    move-result v0

    return v0
.end method

.method public getPostersList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$Posters;",
            ">;"
        }
    .end annotation

    .line 14231
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 14232
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getPostersList()Ljava/util/List;

    move-result-object v0

    .line 14231
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getScrubbingPreviewUrl()Ljava/lang/String;
    .registers 2

    .line 15087
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getScrubbingPreviewUrl()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getScrubbingPreviewUrlBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 15096
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getScrubbingPreviewUrlBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getTech(I)Lcom/vdocipher/PlaybackInfo$TechOptions;
    .registers 3

    .line 14045
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getTech(I)Lcom/vdocipher/PlaybackInfo$TechOptions;

    move-result-object p1

    return-object p1
.end method

.method public getTechCount()I
    .registers 2

    .line 14036
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getTechCount()I

    move-result v0

    return v0
.end method

.method public getTechList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$TechOptions;",
            ">;"
        }
    .end annotation

    .line 14028
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getTechList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getTechValue(I)I
    .registers 3

    .line 14105
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getTechValue(I)I

    move-result p1

    return p1
.end method

.method public getTechValueList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 14095
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 14096
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getTechValueList()Ljava/util/List;

    move-result-object v0

    .line 14095
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getTitle()Ljava/lang/String;
    .registers 2

    .line 13733
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getTitle()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getTitleBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 13742
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getTitleBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getVdocipherBranding()Z
    .registers 2

    .line 14764
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getVdocipherBranding()Z

    move-result v0

    return v0
.end method

.method public getVersion()Ljava/lang/String;
    .registers 2

    .line 15330
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getVersion()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getVersionBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 15339
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getVersionBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getWhitelistHref()Ljava/lang/String;
    .registers 2

    .line 14183
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getWhitelistHref()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getWhitelistHrefBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 14192
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getWhitelistHrefBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public hasCanSkipIntegrityCheck()Z
    .registers 2

    .line 14894
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hasCanSkipIntegrityCheck()Z

    move-result v0

    return v0
.end method

.method public hasCbcs()Z
    .registers 2

    .line 14612
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hasCbcs()Z

    move-result v0

    return v0
.end method

.method public hasDash()Z
    .registers 2

    .line 14565
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hasDash()Z

    move-result v0

    return v0
.end method

.method public hasDesiredBitrate()Z
    .registers 2

    .line 14334
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hasDesiredBitrate()Z

    move-result v0

    return v0
.end method

.method public hasFps()Z
    .registers 2

    .line 14518
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hasFps()Z

    move-result v0

    return v0
.end method

.method public hasH6()Z
    .registers 2

    .line 14659
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hasH6()Z

    move-result v0

    return v0
.end method

.method public hasIntegrityCloudId()Z
    .registers 2

    .line 14707
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hasIntegrityCloudId()Z

    move-result v0

    return v0
.end method

.method public hasLanguage()Z
    .registers 2

    .line 14929
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hasLanguage()Z

    move-result v0

    return v0
.end method

.method public hasPlayerConfig()Z
    .registers 2

    .line 14369
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hasPlayerConfig()Z

    move-result v0

    return v0
.end method

.method public hasScrubbingPreviewUrl()Z
    .registers 2

    .line 15079
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hasScrubbingPreviewUrl()Z

    move-result v0

    return v0
.end method

.method public hasWhitelistHref()Z
    .registers 2

    .line 14175
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hasWhitelistHref()Z

    move-result v0

    return v0
.end method

.method public mergeCbcs(Lcom/vdocipher/PlaybackInfo$CBCSI;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14642
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14643
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mmergeCbcs(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$CBCSI;)V

    return-object p0
.end method

.method public mergeDash(Lcom/vdocipher/PlaybackInfo$DASH;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14595
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14596
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mmergeDash(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$DASH;)V

    return-object p0
.end method

.method public mergeFps(Lcom/vdocipher/PlaybackInfo$FPS;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14548
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14549
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mmergeFps(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$FPS;)V

    return-object p0
.end method

.method public mergeH6(Lcom/vdocipher/PlaybackInfo$H6;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14689
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14690
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mmergeH6(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$H6;)V

    return-object p0
.end method

.method public mergeLanguage(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14959
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14960
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mmergeLanguage(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V

    return-object p0
.end method

.method public mergePlayerConfig(Lcom/vdocipher/PlaybackInfo$PlayerConfig;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14399
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14400
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mmergePlayerConfig(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$PlayerConfig;)V

    return-object p0
.end method

.method public removeCaptions(I)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14508
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14509
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mremoveCaptions(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V

    return-object p0
.end method

.method public removeChapters(I)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14883
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14884
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mremoveChapters(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V

    return-object p0
.end method

.method public removeCtas(I)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 15319
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15320
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mremoveCtas(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V

    return-object p0
.end method

.method public removeErrorMsgs(I)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 15068
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15069
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mremoveErrorMsgs(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V

    return-object p0
.end method

.method public removePosters(I)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14323
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14324
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$mremovePosters(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V

    return-object p0
.end method

.method public setAltHosts(ILjava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 15175
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15176
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetAltHosts(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILjava/lang/String;)V

    return-object p0
.end method

.method public setAspectRatio(F)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 13867
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13868
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetAspectRatio(Lcom/vdocipher/PlaybackInfo$MetadataTable;F)V

    return-object p0
.end method

.method public setAudioOnly(Z)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14155
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14156
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetAudioOnly(Lcom/vdocipher/PlaybackInfo$MetadataTable;Z)V

    return-object p0
.end method

.method public setCanSkipIntegrityCheck(Z)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14910
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14911
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetCanSkipIntegrityCheck(Lcom/vdocipher/PlaybackInfo$MetadataTable;Z)V

    return-object p0
.end method

.method public setCaptions(ILcom/vdocipher/PlaybackInfo$Captions$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 14446
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14447
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 14448
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackInfo$Captions;

    .line 14447
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetCaptions(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Captions;)V

    return-object p0
.end method

.method public setCaptions(ILcom/vdocipher/PlaybackInfo$Captions;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 14437
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14438
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetCaptions(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Captions;)V

    return-object p0
.end method

.method public setCbcs(Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14634
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14635
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$CBCSI;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetCbcs(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$CBCSI;)V

    return-object p0
.end method

.method public setCbcs(Lcom/vdocipher/PlaybackInfo$CBCSI;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14625
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14626
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetCbcs(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$CBCSI;)V

    return-object p0
.end method

.method public setChapters(ILcom/vdocipher/PlaybackInfo$Chapters$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 14821
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14822
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 14823
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackInfo$Chapters;

    .line 14822
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetChapters(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Chapters;)V

    return-object p0
.end method

.method public setChapters(ILcom/vdocipher/PlaybackInfo$Chapters;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 14812
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14813
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetChapters(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Chapters;)V

    return-object p0
.end method

.method public setCtas(ILcom/vdocipher/PlaybackInfo$Cta$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 15257
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15258
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 15259
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackInfo$Cta;

    .line 15258
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetCtas(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Cta;)V

    return-object p0
.end method

.method public setCtas(ILcom/vdocipher/PlaybackInfo$Cta;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 15248
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15249
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetCtas(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Cta;)V

    return-object p0
.end method

.method public setDash(Lcom/vdocipher/PlaybackInfo$DASH$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14587
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14588
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetDash(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$DASH;)V

    return-object p0
.end method

.method public setDash(Lcom/vdocipher/PlaybackInfo$DASH;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14578
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14579
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetDash(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$DASH;)V

    return-object p0
.end method

.method public setDescription(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 13800
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13801
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetDescription(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setDescriptionBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 13820
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13821
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetDescriptionBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setDesiredBitrate(I)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14350
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14351
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetDesiredBitrate(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V

    return-object p0
.end method

.method public setDuration(I)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 13839
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13840
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetDuration(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V

    return-object p0
.end method

.method public setEmbedUrl(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 13997
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13998
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetEmbedUrl(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setEmbedUrlBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14017
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14018
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetEmbedUrlBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setErrorMsgs(ILcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 15006
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15007
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 15008
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    .line 15007
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetErrorMsgs(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$ErrorMessage;)V

    return-object p0
.end method

.method public setErrorMsgs(ILcom/vdocipher/PlaybackInfo$ErrorMessage;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 14997
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14998
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetErrorMsgs(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$ErrorMessage;)V

    return-object p0
.end method

.method public setFps(Lcom/vdocipher/PlaybackInfo$FPS$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14540
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14541
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$FPS;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetFps(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$FPS;)V

    return-object p0
.end method

.method public setFps(Lcom/vdocipher/PlaybackInfo$FPS;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14531
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14532
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetFps(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$FPS;)V

    return-object p0
.end method

.method public setH6(Lcom/vdocipher/PlaybackInfo$H6$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14681
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14682
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$H6$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetH6(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$H6;)V

    return-object p0
.end method

.method public setH6(Lcom/vdocipher/PlaybackInfo$H6;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14672
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14673
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetH6(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$H6;)V

    return-object p0
.end method

.method public setHostnames(ILjava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 13926
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13927
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetHostnames(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILjava/lang/String;)V

    return-object p0
.end method

.method public setIntegrityCloudId(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14733
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14734
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetIntegrityCloudId(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setIntegrityCloudIdBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14753
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14754
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetIntegrityCloudIdBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setLanguage(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14951
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14952
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetLanguage(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V

    return-object p0
.end method

.method public setLanguage(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14942
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14943
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetLanguage(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V

    return-object p0
.end method

.method public setPlayerConfig(Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14391
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14392
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetPlayerConfig(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$PlayerConfig;)V

    return-object p0
.end method

.method public setPlayerConfig(Lcom/vdocipher/PlaybackInfo$PlayerConfig;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14382
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14383
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetPlayerConfig(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$PlayerConfig;)V

    return-object p0
.end method

.method public setPosters(ILcom/vdocipher/PlaybackInfo$Posters$Builder;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 14261
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14262
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 14263
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackInfo$Posters;

    .line 14262
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetPosters(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Posters;)V

    return-object p0
.end method

.method public setPosters(ILcom/vdocipher/PlaybackInfo$Posters;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 14252
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14253
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetPosters(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Posters;)V

    return-object p0
.end method

.method public setScrubbingPreviewUrl(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 15105
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15106
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetScrubbingPreviewUrl(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setScrubbingPreviewUrlBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 15125
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15126
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetScrubbingPreviewUrlBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setTech(ILcom/vdocipher/PlaybackInfo$TechOptions;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 14055
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14056
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetTech(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$TechOptions;)V

    return-object p0
.end method

.method public setTechValue(II)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 4

    .line 14115
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14116
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetTechValue(Lcom/vdocipher/PlaybackInfo$MetadataTable;II)V

    return-object p0
.end method

.method public setTitle(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 13751
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13752
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetTitle(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setTitleBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 13771
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 13772
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetTitleBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setVdocipherBranding(Z)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14772
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14773
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetVdocipherBranding(Lcom/vdocipher/PlaybackInfo$MetadataTable;Z)V

    return-object p0
.end method

.method public setVersion(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 15348
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15349
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetVersion(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setVersionBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 15368
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 15369
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetVersionBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setWhitelistHref(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14201
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14202
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetWhitelistHref(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setWhitelistHrefBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 3

    .line 14221
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->copyOnWrite()V

    .line 14222
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->-$$Nest$msetWhitelistHrefBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
