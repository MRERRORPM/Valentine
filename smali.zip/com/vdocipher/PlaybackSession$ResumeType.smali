# classes14.dex

.class public final enum Lcom/vdocipher/PlaybackSession$ResumeType;
.super Ljava/lang/Enum;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "ResumeType"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$ResumeType$ResumeTypeVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/PlaybackSession$ResumeType;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/PlaybackSession$ResumeType;

.field public static final enum CLIENT:Lcom/vdocipher/PlaybackSession$ResumeType;

.field public static final CLIENT_VALUE:I = 0x0

.field public static final enum SDK:Lcom/vdocipher/PlaybackSession$ResumeType;

.field public static final SDK_VALUE:I = 0x1

.field public static final enum SERVER:Lcom/vdocipher/PlaybackSession$ResumeType;

.field public static final SERVER_VALUE:I = 0x2

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$ResumeType;

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$ResumeType;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 7

    .line 1084
    new-instance v0, Lcom/vdocipher/PlaybackSession$ResumeType;

    const-string v1, "CLIENT"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/PlaybackSession$ResumeType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$ResumeType;->CLIENT:Lcom/vdocipher/PlaybackSession$ResumeType;

    .line 1088
    new-instance v1, Lcom/vdocipher/PlaybackSession$ResumeType;

    const-string v2, "SDK"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/PlaybackSession$ResumeType;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$ResumeType;->SDK:Lcom/vdocipher/PlaybackSession$ResumeType;

    .line 1092
    new-instance v2, Lcom/vdocipher/PlaybackSession$ResumeType;

    const-string v3, "SERVER"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4, v4}, Lcom/vdocipher/PlaybackSession$ResumeType;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/PlaybackSession$ResumeType;->SERVER:Lcom/vdocipher/PlaybackSession$ResumeType;

    .line 1093
    new-instance v3, Lcom/vdocipher/PlaybackSession$ResumeType;

    const/4 v4, 0x3

    const/4 v5, -0x1

    const-string v6, "UNRECOGNIZED"

    invoke-direct {v3, v6, v4, v5}, Lcom/vdocipher/PlaybackSession$ResumeType;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lcom/vdocipher/PlaybackSession$ResumeType;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$ResumeType;

    .line 1079
    filled-new-array {v0, v1, v2, v3}, [Lcom/vdocipher/PlaybackSession$ResumeType;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/PlaybackSession$ResumeType;->$VALUES:[Lcom/vdocipher/PlaybackSession$ResumeType;

    .line 1143
    new-instance v0, Lcom/vdocipher/PlaybackSession$ResumeType$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$ResumeType$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackSession$ResumeType;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 1167
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1168
    iput p3, p0, Lcom/vdocipher/PlaybackSession$ResumeType;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/PlaybackSession$ResumeType;
    .registers 2

    if-eqz p0, :cond_10

    const/4 v0, 0x1

    if-eq p0, v0, :cond_d

    const/4 v0, 0x2

    if-eq p0, v0, :cond_a

    const/4 p0, 0x0

    return-object p0

    .line 1133
    :cond_a
    sget-object p0, Lcom/vdocipher/PlaybackSession$ResumeType;->SERVER:Lcom/vdocipher/PlaybackSession$ResumeType;

    return-object p0

    .line 1132
    :cond_d
    sget-object p0, Lcom/vdocipher/PlaybackSession$ResumeType;->SDK:Lcom/vdocipher/PlaybackSession$ResumeType;

    return-object p0

    .line 1131
    :cond_10
    sget-object p0, Lcom/vdocipher/PlaybackSession$ResumeType;->CLIENT:Lcom/vdocipher/PlaybackSession$ResumeType;

    return-object p0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$ResumeType;",
            ">;"
        }
    .end annotation

    .line 1140
    sget-object v0, Lcom/vdocipher/PlaybackSession$ResumeType;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 1153
    sget-object v0, Lcom/vdocipher/PlaybackSession$ResumeType$ResumeTypeVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/PlaybackSession$ResumeType;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1126
    invoke-static {p0}, Lcom/vdocipher/PlaybackSession$ResumeType;->forNumber(I)Lcom/vdocipher/PlaybackSession$ResumeType;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$ResumeType;
    .registers 2

    .line 1079
    const-class v0, Lcom/vdocipher/PlaybackSession$ResumeType;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$ResumeType;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/PlaybackSession$ResumeType;
    .registers 1

    .line 1079
    sget-object v0, Lcom/vdocipher/PlaybackSession$ResumeType;->$VALUES:[Lcom/vdocipher/PlaybackSession$ResumeType;

    invoke-virtual {v0}, [Lcom/vdocipher/PlaybackSession$ResumeType;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/PlaybackSession$ResumeType;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 1112
    sget-object v0, Lcom/vdocipher/PlaybackSession$ResumeType;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$ResumeType;

    if-eq p0, v0, :cond_7

    .line 1116
    iget v0, p0, Lcom/vdocipher/PlaybackSession$ResumeType;->value:I

    return v0

    .line 1113
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
