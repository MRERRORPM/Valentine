# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$SelectedTrack;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$SelectedTrackOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "SelectedTrack"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$SelectedTrack;",
        "Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$SelectedTrackOrBuilder;"
    }
.end annotation


# static fields
.field public static final AUDIO_FIELD_NUMBER:I = 0x1

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$SelectedTrack;",
            ">;"
        }
    .end annotation
.end field

.field public static final VIDEO_FIELD_NUMBER:I = 0x2


# instance fields
.field private audio_:Lcom/vdocipher/PlaybackSession$TrackAudio;

.field private bitField0_:I

.field private video_:Lcom/vdocipher/PlaybackSession$TrackVideo;


# direct methods
.method static bridge synthetic -$$Nest$mclearAudio(Lcom/vdocipher/PlaybackSession$SelectedTrack;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->clearAudio()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearVideo(Lcom/vdocipher/PlaybackSession$SelectedTrack;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->clearVideo()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeAudio(Lcom/vdocipher/PlaybackSession$SelectedTrack;Lcom/vdocipher/PlaybackSession$TrackAudio;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->mergeAudio(Lcom/vdocipher/PlaybackSession$TrackAudio;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeVideo(Lcom/vdocipher/PlaybackSession$SelectedTrack;Lcom/vdocipher/PlaybackSession$TrackVideo;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->mergeVideo(Lcom/vdocipher/PlaybackSession$TrackVideo;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAudio(Lcom/vdocipher/PlaybackSession$SelectedTrack;Lcom/vdocipher/PlaybackSession$TrackAudio;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->setAudio(Lcom/vdocipher/PlaybackSession$TrackAudio;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVideo(Lcom/vdocipher/PlaybackSession$SelectedTrack;Lcom/vdocipher/PlaybackSession$TrackVideo;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->setVideo(Lcom/vdocipher/PlaybackSession$TrackVideo;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 10036
    new-instance v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$SelectedTrack;-><init>()V

    .line 10039
    sput-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    .line 10040
    const-class v1, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 9692
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    return-void
.end method

.method private clearAudio()V
    .registers 2

    const/4 v0, 0x0

    .line 9737
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->audio_:Lcom/vdocipher/PlaybackSession$TrackAudio;

    .line 9738
    iget v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->bitField0_:I

    and-int/lit8 v0, v0, -0x2

    iput v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->bitField0_:I

    return-void
.end method

.method private clearVideo()V
    .registers 2

    const/4 v0, 0x0

    .line 9783
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->video_:Lcom/vdocipher/PlaybackSession$TrackVideo;

    .line 9784
    iget v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->bitField0_:I

    and-int/lit8 v0, v0, -0x3

    iput v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->bitField0_:I

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 1

    .line 10045
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    return-object v0
.end method

.method private mergeAudio(Lcom/vdocipher/PlaybackSession$TrackAudio;)V
    .registers 4

    .line 9724
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9725
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->audio_:Lcom/vdocipher/PlaybackSession$TrackAudio;

    if-eqz v0, :cond_22

    .line 9726
    invoke-static {}, Lcom/vdocipher/PlaybackSession$TrackAudio;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$TrackAudio;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 9727
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->audio_:Lcom/vdocipher/PlaybackSession$TrackAudio;

    .line 9728
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$TrackAudio;->newBuilder(Lcom/vdocipher/PlaybackSession$TrackAudio;)Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$TrackAudio$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$TrackAudio;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->audio_:Lcom/vdocipher/PlaybackSession$TrackAudio;

    goto :goto_24

    .line 9730
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->audio_:Lcom/vdocipher/PlaybackSession$TrackAudio;

    .line 9732
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->bitField0_:I

    return-void
.end method

.method private mergeVideo(Lcom/vdocipher/PlaybackSession$TrackVideo;)V
    .registers 4

    .line 9770
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9771
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->video_:Lcom/vdocipher/PlaybackSession$TrackVideo;

    if-eqz v0, :cond_22

    .line 9772
    invoke-static {}, Lcom/vdocipher/PlaybackSession$TrackVideo;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$TrackVideo;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 9773
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->video_:Lcom/vdocipher/PlaybackSession$TrackVideo;

    .line 9774
    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$TrackVideo;->newBuilder(Lcom/vdocipher/PlaybackSession$TrackVideo;)Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$TrackVideo$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$TrackVideo;

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->video_:Lcom/vdocipher/PlaybackSession$TrackVideo;

    goto :goto_24

    .line 9776
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->video_:Lcom/vdocipher/PlaybackSession$TrackVideo;

    .line 9778
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->bitField0_:I

    or-int/lit8 p1, p1, 0x2

    iput p1, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->bitField0_:I

    return-void
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;
    .registers 1

    .line 9864
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$SelectedTrack;)Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;
    .registers 2

    .line 9867
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9840
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9847
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9803
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9810
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9852
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9859
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9827
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9834
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9790
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9797
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9815
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9822
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$SelectedTrack;",
            ">;"
        }
    .end annotation

    .line 10051
    sget-object v0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setAudio(Lcom/vdocipher/PlaybackSession$TrackAudio;)V
    .registers 2

    .line 9715
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9716
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->audio_:Lcom/vdocipher/PlaybackSession$TrackAudio;

    .line 9717
    iget p1, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->bitField0_:I

    return-void
.end method

.method private setVideo(Lcom/vdocipher/PlaybackSession$TrackVideo;)V
    .registers 2

    .line 9761
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9762
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->video_:Lcom/vdocipher/PlaybackSession$TrackVideo;

    .line 9763
    iget p1, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->bitField0_:I

    or-int/lit8 p1, p1, 0x2

    iput p1, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->bitField0_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 9985
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_56

    .line 10029
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 10023
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 10008
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$SelectedTrack;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 10010
    const-class p2, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    monitor-enter p2

    .line 10011
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$SelectedTrack;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 10013
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 10016
    sput-object p1, Lcom/vdocipher/PlaybackSession$SelectedTrack;->PARSER:Lcom/google/protobuf/Parser;

    .line 10018
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 10005
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    return-object p1

    .line 9993
    :pswitch_36  #0x3
    const-string p1, "bitField0_"

    const-string p2, "audio_"

    const-string/jumbo p3, "video_"

    filled-new-array {p1, p2, p3}, [Ljava/lang/Object;

    move-result-object p1

    .line 9998
    const-string p2, "\u0000\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001ဉ\u0000\u0002ဉ\u0001"

    .line 10001
    sget-object p3, Lcom/vdocipher/PlaybackSession$SelectedTrack;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 9990
    :pswitch_4a  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 9987
    :pswitch_50  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack;-><init>()V

    return-object p1

    :pswitch_data_56
    .packed-switch 0x1
        :pswitch_50  #00000001
        :pswitch_4a  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getAudio()Lcom/vdocipher/PlaybackSession$TrackAudio;
    .registers 2

    .line 9709
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->audio_:Lcom/vdocipher/PlaybackSession$TrackAudio;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$TrackAudio;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$TrackAudio;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getVideo()Lcom/vdocipher/PlaybackSession$TrackVideo;
    .registers 2

    .line 9755
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->video_:Lcom/vdocipher/PlaybackSession$TrackVideo;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackSession$TrackVideo;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$TrackVideo;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public hasAudio()Z
    .registers 3

    .line 9702
    iget v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->bitField0_:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_7

    return v1

    :cond_7
    const/4 v0, 0x0

    return v0
.end method

.method public hasVideo()Z
    .registers 2

    .line 9748
    iget v0, p0, Lcom/vdocipher/PlaybackSession$SelectedTrack;->bitField0_:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method
