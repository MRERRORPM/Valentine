# classes14.dex

.class public final Lcom/vdocipher/Manifest$SegmentTimeline$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$SegmentTimelineOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest$SegmentTimeline;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/Manifest$SegmentTimeline;",
        "Lcom/vdocipher/Manifest$SegmentTimeline$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$SegmentTimelineOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 2660
    invoke-static {}, Lcom/vdocipher/Manifest$SegmentTimeline;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$SegmentTimeline;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/Manifest-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearDuration()Lcom/vdocipher/Manifest$SegmentTimeline$Builder;
    .registers 2

    .line 2687
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;->copyOnWrite()V

    .line 2688
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SegmentTimeline;->-$$Nest$mclearDuration(Lcom/vdocipher/Manifest$SegmentTimeline;)V

    return-object p0
.end method

.method public clearRepeat()Lcom/vdocipher/Manifest$SegmentTimeline$Builder;
    .registers 2

    .line 2715
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;->copyOnWrite()V

    .line 2716
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SegmentTimeline;->-$$Nest$mclearRepeat(Lcom/vdocipher/Manifest$SegmentTimeline;)V

    return-object p0
.end method

.method public getDuration()I
    .registers 2

    .line 2670
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTimeline;->getDuration()I

    move-result v0

    return v0
.end method

.method public getRepeat()I
    .registers 2

    .line 2698
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTimeline;->getRepeat()I

    move-result v0

    return v0
.end method

.method public setDuration(I)Lcom/vdocipher/Manifest$SegmentTimeline$Builder;
    .registers 3

    .line 2678
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;->copyOnWrite()V

    .line 2679
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentTimeline;->-$$Nest$msetDuration(Lcom/vdocipher/Manifest$SegmentTimeline;I)V

    return-object p0
.end method

.method public setRepeat(I)Lcom/vdocipher/Manifest$SegmentTimeline$Builder;
    .registers 3

    .line 2706
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;->copyOnWrite()V

    .line 2707
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentTimeline;->-$$Nest$msetRepeat(Lcom/vdocipher/Manifest$SegmentTimeline;I)V

    return-object p0
.end method
