# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$PerfMetrics;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$PerfMetricsOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "PerfMetrics"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$PerfMetrics;",
        "Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$PerfMetricsOrBuilder;"
    }
.end annotation


# static fields
.field public static final AUDIOUNDERRUNRATE_FIELD_NUMBER:I = 0xa

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

.field public static final DROPPEDFRAMESRATE_FIELD_NUMBER:I = 0xb

.field public static final JOINTIME_FIELD_NUMBER:I = 0x4

.field public static final LICENSELOADDURATION_FIELD_NUMBER:I = 0x2

.field public static final MAXREBUFFERTIME_FIELD_NUMBER:I = 0x8

.field public static final MEANBANDWIDTH_FIELD_NUMBER:I = 0x5

.field public static final MEANSEEKTIME_FIELD_NUMBER:I = 0x3

.field public static final METALOADDURATION_FIELD_NUMBER:I = 0x1

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$PerfMetrics;",
            ">;"
        }
    .end annotation
.end field

.field public static final REBUFFERCOUNT_FIELD_NUMBER:I = 0x9

.field public static final REBUFFERRATE_FIELD_NUMBER:I = 0x7

.field public static final REBUFFERTIMERATIO_FIELD_NUMBER:I = 0x6


# instance fields
.field private audioUnderrunRate_:D

.field private droppedFramesRate_:D

.field private joinTime_:I

.field private licenseLoadDuration_:I

.field private maxRebufferTime_:I

.field private meanBandwidth_:D

.field private meanSeekTime_:I

.field private metaLoadDuration_:I

.field private rebufferCount_:I

.field private rebufferRate_:D

.field private rebufferTimeRatio_:D


# direct methods
.method static bridge synthetic -$$Nest$mclearAudioUnderrunRate(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->clearAudioUnderrunRate()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearDroppedFramesRate(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->clearDroppedFramesRate()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearJoinTime(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->clearJoinTime()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLicenseLoadDuration(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->clearLicenseLoadDuration()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMaxRebufferTime(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->clearMaxRebufferTime()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMeanBandwidth(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->clearMeanBandwidth()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMeanSeekTime(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->clearMeanSeekTime()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMetaLoadDuration(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->clearMetaLoadDuration()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearRebufferCount(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->clearRebufferCount()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearRebufferRate(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->clearRebufferRate()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearRebufferTimeRatio(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->clearRebufferTimeRatio()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAudioUnderrunRate(Lcom/vdocipher/PlaybackSession$PerfMetrics;D)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->setAudioUnderrunRate(D)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDroppedFramesRate(Lcom/vdocipher/PlaybackSession$PerfMetrics;D)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->setDroppedFramesRate(D)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetJoinTime(Lcom/vdocipher/PlaybackSession$PerfMetrics;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->setJoinTime(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLicenseLoadDuration(Lcom/vdocipher/PlaybackSession$PerfMetrics;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->setLicenseLoadDuration(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMaxRebufferTime(Lcom/vdocipher/PlaybackSession$PerfMetrics;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->setMaxRebufferTime(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMeanBandwidth(Lcom/vdocipher/PlaybackSession$PerfMetrics;D)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->setMeanBandwidth(D)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMeanSeekTime(Lcom/vdocipher/PlaybackSession$PerfMetrics;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->setMeanSeekTime(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMetaLoadDuration(Lcom/vdocipher/PlaybackSession$PerfMetrics;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->setMetaLoadDuration(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetRebufferCount(Lcom/vdocipher/PlaybackSession$PerfMetrics;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->setRebufferCount(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetRebufferRate(Lcom/vdocipher/PlaybackSession$PerfMetrics;D)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->setRebufferRate(D)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetRebufferTimeRatio(Lcom/vdocipher/PlaybackSession$PerfMetrics;D)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->setRebufferTimeRatio(D)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 6955
    new-instance v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;-><init>()V

    .line 6958
    sput-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    .line 6959
    const-class v1, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 6195
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    return-void
.end method

.method private clearAudioUnderrunRate()V
    .registers 3

    const-wide/16 v0, 0x0

    .line 6454
    iput-wide v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->audioUnderrunRate_:D

    return-void
.end method

.method private clearDroppedFramesRate()V
    .registers 3

    const-wide/16 v0, 0x0

    .line 6480
    iput-wide v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->droppedFramesRate_:D

    return-void
.end method

.method private clearJoinTime()V
    .registers 2

    const/4 v0, 0x0

    .line 6298
    iput v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->joinTime_:I

    return-void
.end method

.method private clearLicenseLoadDuration()V
    .registers 2

    const/4 v0, 0x0

    .line 6246
    iput v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->licenseLoadDuration_:I

    return-void
.end method

.method private clearMaxRebufferTime()V
    .registers 2

    const/4 v0, 0x0

    .line 6402
    iput v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->maxRebufferTime_:I

    return-void
.end method

.method private clearMeanBandwidth()V
    .registers 3

    const-wide/16 v0, 0x0

    .line 6324
    iput-wide v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->meanBandwidth_:D

    return-void
.end method

.method private clearMeanSeekTime()V
    .registers 2

    const/4 v0, 0x0

    .line 6272
    iput v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->meanSeekTime_:I

    return-void
.end method

.method private clearMetaLoadDuration()V
    .registers 2

    const/4 v0, 0x0

    .line 6220
    iput v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->metaLoadDuration_:I

    return-void
.end method

.method private clearRebufferCount()V
    .registers 2

    const/4 v0, 0x0

    .line 6428
    iput v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->rebufferCount_:I

    return-void
.end method

.method private clearRebufferRate()V
    .registers 3

    const-wide/16 v0, 0x0

    .line 6376
    iput-wide v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->rebufferRate_:D

    return-void
.end method

.method private clearRebufferTimeRatio()V
    .registers 3

    const-wide/16 v0, 0x0

    .line 6350
    iput-wide v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->rebufferTimeRatio_:D

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 1

    .line 6964
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 1

    .line 6560
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$PerfMetrics;)Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 2

    .line 6563
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 6536
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 6543
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 6499
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 6506
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 6548
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 6555
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 6523
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 6530
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 6486
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 6493
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 6511
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 6518
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$PerfMetrics;",
            ">;"
        }
    .end annotation

    .line 6970
    sget-object v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setAudioUnderrunRate(D)V
    .registers 3

    .line 6447
    iput-wide p1, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->audioUnderrunRate_:D

    return-void
.end method

.method private setDroppedFramesRate(D)V
    .registers 3

    .line 6473
    iput-wide p1, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->droppedFramesRate_:D

    return-void
.end method

.method private setJoinTime(I)V
    .registers 2

    .line 6291
    iput p1, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->joinTime_:I

    return-void
.end method

.method private setLicenseLoadDuration(I)V
    .registers 2

    .line 6239
    iput p1, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->licenseLoadDuration_:I

    return-void
.end method

.method private setMaxRebufferTime(I)V
    .registers 2

    .line 6395
    iput p1, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->maxRebufferTime_:I

    return-void
.end method

.method private setMeanBandwidth(D)V
    .registers 3

    .line 6317
    iput-wide p1, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->meanBandwidth_:D

    return-void
.end method

.method private setMeanSeekTime(I)V
    .registers 2

    .line 6265
    iput p1, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->meanSeekTime_:I

    return-void
.end method

.method private setMetaLoadDuration(I)V
    .registers 2

    .line 6213
    iput p1, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->metaLoadDuration_:I

    return-void
.end method

.method private setRebufferCount(I)V
    .registers 2

    .line 6421
    iput p1, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->rebufferCount_:I

    return-void
.end method

.method private setRebufferRate(D)V
    .registers 3

    .line 6369
    iput-wide p1, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->rebufferRate_:D

    return-void
.end method

.method private setRebufferTimeRatio(D)V
    .registers 3

    .line 6343
    iput-wide p1, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->rebufferTimeRatio_:D

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 15

    .line 6895
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_66

    .line 6948
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 6942
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 6927
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$PerfMetrics;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_33

    .line 6929
    const-class p2, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    monitor-enter p2

    .line 6930
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$PerfMetrics;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 6932
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 6935
    sput-object p1, Lcom/vdocipher/PlaybackSession$PerfMetrics;->PARSER:Lcom/google/protobuf/Parser;

    .line 6937
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception v0

    move-object p1, v0

    monitor-exit p2
    :try_end_32
    .catchall {:try_start_20 .. :try_end_32} :catchall_2f

    throw p1

    :cond_33
    return-object p1

    .line 6924
    :pswitch_34  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    return-object p1

    .line 6903
    :pswitch_37  #0x3
    const-string v0, "metaLoadDuration_"

    const-string v1, "licenseLoadDuration_"

    const-string v2, "meanSeekTime_"

    const-string v3, "joinTime_"

    const-string v4, "meanBandwidth_"

    const-string v5, "rebufferTimeRatio_"

    const-string v6, "rebufferRate_"

    const-string v7, "maxRebufferTime_"

    const-string v8, "rebufferCount_"

    const-string v9, "audioUnderrunRate_"

    const-string v10, "droppedFramesRate_"

    filled-new-array/range {v0 .. v10}, [Ljava/lang/Object;

    move-result-object p1

    .line 6916
    const-string p2, "\u0000\u000b\u0000\u0000\u0001\u000b\u000b\u0000\u0000\u0000\u0001\u000b\u0002\u000b\u0003\u000b\u0004\u000b\u0005\u0000\u0006\u0000\u0007\u0000\b\u000b\t\u000b\n\u0000\u000b\u0000"

    .line 6920
    sget-object p3, Lcom/vdocipher/PlaybackSession$PerfMetrics;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 6900
    :pswitch_5a  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 6897
    :pswitch_60  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics;-><init>()V

    return-object p1

    :pswitch_data_66
    .packed-switch 0x1
        :pswitch_60  #00000001
        :pswitch_5a  #00000002
        :pswitch_37  #00000003
        :pswitch_34  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getAudioUnderrunRate()D
    .registers 3

    .line 6439
    iget-wide v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->audioUnderrunRate_:D

    return-wide v0
.end method

.method public getDroppedFramesRate()D
    .registers 3

    .line 6465
    iget-wide v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->droppedFramesRate_:D

    return-wide v0
.end method

.method public getJoinTime()I
    .registers 2

    .line 6283
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->joinTime_:I

    return v0
.end method

.method public getLicenseLoadDuration()I
    .registers 2

    .line 6231
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->licenseLoadDuration_:I

    return v0
.end method

.method public getMaxRebufferTime()I
    .registers 2

    .line 6387
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->maxRebufferTime_:I

    return v0
.end method

.method public getMeanBandwidth()D
    .registers 3

    .line 6309
    iget-wide v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->meanBandwidth_:D

    return-wide v0
.end method

.method public getMeanSeekTime()I
    .registers 2

    .line 6257
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->meanSeekTime_:I

    return v0
.end method

.method public getMetaLoadDuration()I
    .registers 2

    .line 6205
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->metaLoadDuration_:I

    return v0
.end method

.method public getRebufferCount()I
    .registers 2

    .line 6413
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->rebufferCount_:I

    return v0
.end method

.method public getRebufferRate()D
    .registers 3

    .line 6361
    iget-wide v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->rebufferRate_:D

    return-wide v0
.end method

.method public getRebufferTimeRatio()D
    .registers 3

    .line 6335
    iget-wide v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics;->rebufferTimeRatio_:D

    return-wide v0
.end method
