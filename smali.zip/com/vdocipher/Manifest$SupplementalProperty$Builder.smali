# classes14.dex

.class public final Lcom/vdocipher/Manifest$SupplementalProperty$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$SupplementalPropertyOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest$SupplementalProperty;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/Manifest$SupplementalProperty;",
        "Lcom/vdocipher/Manifest$SupplementalProperty$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$SupplementalPropertyOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 5383
    invoke-static {}, Lcom/vdocipher/Manifest$SupplementalProperty;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$SupplementalProperty;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/Manifest-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearSchemeIdUri()Lcom/vdocipher/Manifest$SupplementalProperty$Builder;
    .registers 2

    .line 5420
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->copyOnWrite()V

    .line 5421
    iget-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SupplementalProperty;->-$$Nest$mclearSchemeIdUri(Lcom/vdocipher/Manifest$SupplementalProperty;)V

    return-object p0
.end method

.method public clearValue()Lcom/vdocipher/Manifest$SupplementalProperty$Builder;
    .registers 2

    .line 5469
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->copyOnWrite()V

    .line 5470
    iget-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SupplementalProperty;->-$$Nest$mclearValue(Lcom/vdocipher/Manifest$SupplementalProperty;)V

    return-object p0
.end method

.method public getSchemeIdUri()Ljava/lang/String;
    .registers 2

    .line 5393
    iget-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SupplementalProperty;->getSchemeIdUri()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getSchemeIdUriBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 5402
    iget-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SupplementalProperty;->getSchemeIdUriBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getValue()Ljava/lang/String;
    .registers 2

    .line 5442
    iget-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SupplementalProperty;->getValue()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getValueBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 5451
    iget-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SupplementalProperty;->getValueBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setSchemeIdUri(Ljava/lang/String;)Lcom/vdocipher/Manifest$SupplementalProperty$Builder;
    .registers 3

    .line 5411
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->copyOnWrite()V

    .line 5412
    iget-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SupplementalProperty;->-$$Nest$msetSchemeIdUri(Lcom/vdocipher/Manifest$SupplementalProperty;Ljava/lang/String;)V

    return-object p0
.end method

.method public setSchemeIdUriBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$SupplementalProperty$Builder;
    .registers 3

    .line 5431
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->copyOnWrite()V

    .line 5432
    iget-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SupplementalProperty;->-$$Nest$msetSchemeIdUriBytes(Lcom/vdocipher/Manifest$SupplementalProperty;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setValue(Ljava/lang/String;)Lcom/vdocipher/Manifest$SupplementalProperty$Builder;
    .registers 3

    .line 5460
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->copyOnWrite()V

    .line 5461
    iget-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SupplementalProperty;->-$$Nest$msetValue(Lcom/vdocipher/Manifest$SupplementalProperty;Ljava/lang/String;)V

    return-object p0
.end method

.method public setValueBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$SupplementalProperty$Builder;
    .registers 3

    .line 5480
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->copyOnWrite()V

    .line 5481
    iget-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SupplementalProperty;->-$$Nest$msetValueBytes(Lcom/vdocipher/Manifest$SupplementalProperty;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
