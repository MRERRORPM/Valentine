# classes14.dex

.class public final enum Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;
.super Ljava/lang/Enum;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "ClipstatTechOptions"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$ClipstatTechOptions$ClipstatTechOptionsVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

.field public static final enum cbsci:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

.field public static final cbsci_VALUE:I = 0x1

.field public static final enum dash:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

.field public static final dash_VALUE:I = 0x0

.field public static final enum fps:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

.field public static final fps_VALUE:I = 0x2

.field public static final enum h1:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

.field public static final h1_VALUE:I = 0x6

.field public static final enum h6:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

.field public static final h6_VALUE:I = 0x4

.field public static final enum hlse:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

.field public static final hlse_VALUE:I = 0x5

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;",
            ">;"
        }
    .end annotation
.end field

.field public static final enum zen:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

.field public static final zen_VALUE:I = 0x3


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 11

    .line 1182
    new-instance v0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    const-string v1, "dash"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->dash:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    .line 1186
    new-instance v1, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    const-string v2, "cbsci"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->cbsci:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    .line 1190
    new-instance v2, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    const-string v3, "fps"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4, v4}, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->fps:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    .line 1194
    new-instance v3, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    const-string/jumbo v4, "zen"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5, v5}, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->zen:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    .line 1198
    new-instance v4, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    const-string v5, "h6"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6, v6}, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->h6:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    .line 1202
    new-instance v5, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    const-string v6, "hlse"

    const/4 v7, 0x5

    invoke-direct {v5, v6, v7, v7}, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->hlse:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    .line 1206
    new-instance v6, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    const-string v7, "h1"

    const/4 v8, 0x6

    invoke-direct {v6, v7, v8, v8}, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->h1:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    .line 1207
    new-instance v7, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    const/4 v8, 0x7

    const/4 v9, -0x1

    const-string v10, "UNRECOGNIZED"

    invoke-direct {v7, v10, v8, v9}, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    .line 1177
    filled-new-array/range {v0 .. v7}, [Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->$VALUES:[Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    .line 1277
    new-instance v0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 1301
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 1302
    iput p3, p0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;
    .registers 1

    packed-switch p0, :pswitch_data_1a

    const/4 p0, 0x0

    return-object p0

    .line 1267
    :pswitch_5  #0x6
    sget-object p0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->h1:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    return-object p0

    .line 1266
    :pswitch_8  #0x5
    sget-object p0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->hlse:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    return-object p0

    .line 1265
    :pswitch_b  #0x4
    sget-object p0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->h6:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    return-object p0

    .line 1264
    :pswitch_e  #0x3
    sget-object p0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->zen:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    return-object p0

    .line 1263
    :pswitch_11  #0x2
    sget-object p0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->fps:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    return-object p0

    .line 1262
    :pswitch_14  #0x1
    sget-object p0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->cbsci:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    return-object p0

    .line 1261
    :pswitch_17  #0x0
    sget-object p0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->dash:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    return-object p0

    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_17  #00000000
        :pswitch_14  #00000001
        :pswitch_11  #00000002
        :pswitch_e  #00000003
        :pswitch_b  #00000004
        :pswitch_8  #00000005
        :pswitch_5  #00000006
    .end packed-switch
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;",
            ">;"
        }
    .end annotation

    .line 1274
    sget-object v0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 1287
    sget-object v0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions$ClipstatTechOptionsVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1256
    invoke-static {p0}, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->forNumber(I)Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;
    .registers 2

    .line 1177
    const-class v0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;
    .registers 1

    .line 1177
    sget-object v0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->$VALUES:[Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    invoke-virtual {v0}, [Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 1242
    sget-object v0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    if-eq p0, v0, :cond_7

    .line 1246
    iget v0, p0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->value:I

    return v0

    .line 1243
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
