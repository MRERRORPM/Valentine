# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$PlaybackSessionTableOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;",
        "Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$PlaybackSessionTableOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 15421
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public addAllBeats(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackSession$Beat;",
            ">;)",
            "Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;"
        }
    .end annotation

    .line 16398
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16399
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$maddAllBeats(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllEvents(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackSession$Event;",
            ">;)",
            "Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;"
        }
    .end annotation

    .line 16128
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16129
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$maddAllEvents(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addBeats(ILcom/vdocipher/PlaybackSession$Beat$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 4

    .line 16388
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16389
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    .line 16390
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackSession$Beat;

    .line 16389
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$maddBeats(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;ILcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public addBeats(ILcom/vdocipher/PlaybackSession$Beat;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 4

    .line 16370
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16371
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$maddBeats(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;ILcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public addBeats(Lcom/vdocipher/PlaybackSession$Beat$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16379
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16380
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Beat;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$maddBeats(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public addBeats(Lcom/vdocipher/PlaybackSession$Beat;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16361
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16362
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$maddBeats(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public addEvents(ILcom/vdocipher/PlaybackSession$Event$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 4

    .line 16118
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16119
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    .line 16120
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackSession$Event$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackSession$Event;

    .line 16119
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$maddEvents(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;ILcom/vdocipher/PlaybackSession$Event;)V

    return-object p0
.end method

.method public addEvents(ILcom/vdocipher/PlaybackSession$Event;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 4

    .line 16100
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16101
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$maddEvents(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;ILcom/vdocipher/PlaybackSession$Event;)V

    return-object p0
.end method

.method public addEvents(Lcom/vdocipher/PlaybackSession$Event$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16109
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16110
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Event$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$maddEvents(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Event;)V

    return-object p0
.end method

.method public addEvents(Lcom/vdocipher/PlaybackSession$Event;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16091
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16092
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$maddEvents(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Event;)V

    return-object p0
.end method

.method public clearAndroid()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 16651
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16652
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearAndroid(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearBeats()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 16406
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16407
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearBeats(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearCaptionSearch()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 16237
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16238
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearCaptionSearch(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearCoverage()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 16042
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16043
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearCoverage(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearDevice()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 15899
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15900
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearDevice(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearDimensions()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 15612
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15613
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearDimensions(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearDownloadLocation()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 16546
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16547
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearDownloadLocation(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearEmbedInfo()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 15565
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15566
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearEmbedInfo(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearError()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 16461
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16462
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearError(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearEvents()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 16136
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16137
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearEvents(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearIsUIEnabled()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 16265
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16266
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearIsUIEnabled(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearMedia()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 15852
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15853
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearMedia(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearNavigator()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 15937
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15938
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearNavigator(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearNavigatorProps()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 15995
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15996
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearNavigatorProps(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearPlatform()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 15745
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15746
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearPlatform(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearPlayerPerf()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 16191
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16192
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearPlayerPerf(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearRefUrl()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 15650
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15651
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearRefUrl(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearResumed()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 16604
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16605
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearResumed(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearSelectedTrack()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 16508
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16509
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearSelectedTrack(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearSession()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 15458
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15459
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearSession(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearSessionInitTime()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 15507
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15508
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearSessionInitTime(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearTech()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 15707
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15708
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearTech(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearToolkit()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 16726
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16727
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearToolkit(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearTrackCount()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 16312
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16313
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearTrackCount(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearViewer()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 15794
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15795
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearViewer(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearWatermarkCount()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 16679
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16680
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearWatermarkCount(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public clearWidevineCDM()Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 2

    .line 16773
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16774
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mclearWidevineCDM(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;)V

    return-object p0
.end method

.method public getAndroid()Lcom/vdocipher/PlaybackSession$Android;
    .registers 2

    .line 16621
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getAndroid()Lcom/vdocipher/PlaybackSession$Android;

    move-result-object v0

    return-object v0
.end method

.method public getBeats(I)Lcom/vdocipher/PlaybackSession$Beat;
    .registers 3

    .line 16336
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getBeats(I)Lcom/vdocipher/PlaybackSession$Beat;

    move-result-object p1

    return-object p1
.end method

.method public getBeatsCount()I
    .registers 2

    .line 16330
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getBeatsCount()I

    move-result v0

    return v0
.end method

.method public getBeatsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackSession$Beat;",
            ">;"
        }
    .end annotation

    .line 16322
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    .line 16323
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getBeatsList()Ljava/util/List;

    move-result-object v0

    .line 16322
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getCaptionSearch()Lcom/vdocipher/PlaybackSession$CaptionSearch;
    .registers 2

    .line 16220
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getCaptionSearch()Lcom/vdocipher/PlaybackSession$CaptionSearch;

    move-result-object v0

    return-object v0
.end method

.method public getCaptionSearchValue()I
    .registers 2

    .line 16202
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getCaptionSearchValue()I

    move-result v0

    return v0
.end method

.method public getCoverage()Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 2

    .line 16012
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getCoverage()Lcom/vdocipher/PlaybackSession$Coverage;

    move-result-object v0

    return-object v0
.end method

.method public getDevice()Lcom/vdocipher/PlaybackSession$Device;
    .registers 2

    .line 15869
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getDevice()Lcom/vdocipher/PlaybackSession$Device;

    move-result-object v0

    return-object v0
.end method

.method public getDimensions()Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 2

    .line 15582
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getDimensions()Lcom/vdocipher/PlaybackSession$Dimension;

    move-result-object v0

    return-object v0
.end method

.method public getDownloadLocation()Ljava/lang/String;
    .registers 2

    .line 16519
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getDownloadLocation()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getDownloadLocationBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 16528
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getDownloadLocationBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getEmbedInfo()Lcom/vdocipher/PlaybackSession$EmbedInfo;
    .registers 2

    .line 15535
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getEmbedInfo()Lcom/vdocipher/PlaybackSession$EmbedInfo;

    move-result-object v0

    return-object v0
.end method

.method public getError()Lcom/vdocipher/PlaybackSession$Error;
    .registers 2

    .line 16431
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getError()Lcom/vdocipher/PlaybackSession$Error;

    move-result-object v0

    return-object v0
.end method

.method public getEvents(I)Lcom/vdocipher/PlaybackSession$Event;
    .registers 3

    .line 16066
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getEvents(I)Lcom/vdocipher/PlaybackSession$Event;

    move-result-object p1

    return-object p1
.end method

.method public getEventsCount()I
    .registers 2

    .line 16060
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getEventsCount()I

    move-result v0

    return v0
.end method

.method public getEventsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackSession$Event;",
            ">;"
        }
    .end annotation

    .line 16052
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    .line 16053
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getEventsList()Ljava/util/List;

    move-result-object v0

    .line 16052
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getIsUIEnabled()Z
    .registers 2

    .line 16248
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getIsUIEnabled()Z

    move-result v0

    return v0
.end method

.method public getMedia()Lcom/vdocipher/PlaybackSession$Media;
    .registers 2

    .line 15822
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getMedia()Lcom/vdocipher/PlaybackSession$Media;

    move-result-object v0

    return-object v0
.end method

.method public getNavigator()Ljava/lang/String;
    .registers 2

    .line 15910
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getNavigator()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getNavigatorBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 15919
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getNavigatorBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getNavigatorProps()Lcom/vdocipher/PlaybackSession$NavigatorProps;
    .registers 2

    .line 15965
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getNavigatorProps()Lcom/vdocipher/PlaybackSession$NavigatorProps;

    move-result-object v0

    return-object v0
.end method

.method public getPlatform()Ljava/lang/String;
    .registers 2

    .line 15718
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getPlatform()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getPlatformBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 15727
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getPlatformBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getPlayerPerf()Lcom/vdocipher/PlaybackSession$PerfMetrics;
    .registers 2

    .line 16161
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getPlayerPerf()Lcom/vdocipher/PlaybackSession$PerfMetrics;

    move-result-object v0

    return-object v0
.end method

.method public getRefUrl()Ljava/lang/String;
    .registers 2

    .line 15623
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getRefUrl()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getRefUrlBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 15632
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getRefUrlBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getResumed()Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 2

    .line 16574
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getResumed()Lcom/vdocipher/PlaybackSession$PlaybackResume;

    move-result-object v0

    return-object v0
.end method

.method public getSelectedTrack()Lcom/vdocipher/PlaybackSession$SelectedTrack;
    .registers 2

    .line 16478
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getSelectedTrack()Lcom/vdocipher/PlaybackSession$SelectedTrack;

    move-result-object v0

    return-object v0
.end method

.method public getSession()Ljava/lang/String;
    .registers 2

    .line 15431
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getSession()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getSessionBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 15440
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getSessionBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSessionInitTime()Ljava/lang/String;
    .registers 2

    .line 15480
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getSessionInitTime()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getSessionInitTimeBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 15489
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getSessionInitTimeBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getTech()Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;
    .registers 2

    .line 15690
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getTech()Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    move-result-object v0

    return-object v0
.end method

.method public getTechValue()I
    .registers 2

    .line 15672
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getTechValue()I

    move-result v0

    return v0
.end method

.method public getToolkit()Lcom/vdocipher/PlaybackSession$Toolkit;
    .registers 2

    .line 16696
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getToolkit()Lcom/vdocipher/PlaybackSession$Toolkit;

    move-result-object v0

    return-object v0
.end method

.method public getTrackCount()Lcom/vdocipher/PlaybackSession$TrackCount;
    .registers 2

    .line 16282
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getTrackCount()Lcom/vdocipher/PlaybackSession$TrackCount;

    move-result-object v0

    return-object v0
.end method

.method public getViewer()Ljava/lang/String;
    .registers 2

    .line 15767
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getViewer()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getViewerBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 15776
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getViewerBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getWatermarkCount()I
    .registers 2

    .line 16662
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getWatermarkCount()I

    move-result v0

    return v0
.end method

.method public getWidevineCDM()Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 2

    .line 16743
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->getWidevineCDM()Lcom/vdocipher/PlaybackSession$WidevineCDM;

    move-result-object v0

    return-object v0
.end method

.method public hasAndroid()Z
    .registers 2

    .line 16614
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->hasAndroid()Z

    move-result v0

    return v0
.end method

.method public hasCoverage()Z
    .registers 2

    .line 16005
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->hasCoverage()Z

    move-result v0

    return v0
.end method

.method public hasDevice()Z
    .registers 2

    .line 15862
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->hasDevice()Z

    move-result v0

    return v0
.end method

.method public hasDimensions()Z
    .registers 2

    .line 15575
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->hasDimensions()Z

    move-result v0

    return v0
.end method

.method public hasEmbedInfo()Z
    .registers 2

    .line 15528
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->hasEmbedInfo()Z

    move-result v0

    return v0
.end method

.method public hasError()Z
    .registers 2

    .line 16424
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->hasError()Z

    move-result v0

    return v0
.end method

.method public hasMedia()Z
    .registers 2

    .line 15815
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->hasMedia()Z

    move-result v0

    return v0
.end method

.method public hasNavigatorProps()Z
    .registers 2

    .line 15958
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->hasNavigatorProps()Z

    move-result v0

    return v0
.end method

.method public hasPlayerPerf()Z
    .registers 2

    .line 16154
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->hasPlayerPerf()Z

    move-result v0

    return v0
.end method

.method public hasResumed()Z
    .registers 2

    .line 16567
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->hasResumed()Z

    move-result v0

    return v0
.end method

.method public hasSelectedTrack()Z
    .registers 2

    .line 16471
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->hasSelectedTrack()Z

    move-result v0

    return v0
.end method

.method public hasToolkit()Z
    .registers 2

    .line 16689
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->hasToolkit()Z

    move-result v0

    return v0
.end method

.method public hasTrackCount()Z
    .registers 2

    .line 16275
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->hasTrackCount()Z

    move-result v0

    return v0
.end method

.method public hasWidevineCDM()Z
    .registers 2

    .line 16736
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->hasWidevineCDM()Z

    move-result v0

    return v0
.end method

.method public mergeAndroid(Lcom/vdocipher/PlaybackSession$Android;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16644
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16645
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mmergeAndroid(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Android;)V

    return-object p0
.end method

.method public mergeCoverage(Lcom/vdocipher/PlaybackSession$Coverage;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16035
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16036
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mmergeCoverage(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Coverage;)V

    return-object p0
.end method

.method public mergeDevice(Lcom/vdocipher/PlaybackSession$Device;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15892
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15893
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mmergeDevice(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Device;)V

    return-object p0
.end method

.method public mergeDimensions(Lcom/vdocipher/PlaybackSession$Dimension;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15605
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15606
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mmergeDimensions(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Dimension;)V

    return-object p0
.end method

.method public mergeEmbedInfo(Lcom/vdocipher/PlaybackSession$EmbedInfo;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15558
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15559
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mmergeEmbedInfo(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$EmbedInfo;)V

    return-object p0
.end method

.method public mergeError(Lcom/vdocipher/PlaybackSession$Error;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16454
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16455
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mmergeError(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Error;)V

    return-object p0
.end method

.method public mergeMedia(Lcom/vdocipher/PlaybackSession$Media;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15845
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15846
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mmergeMedia(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Media;)V

    return-object p0
.end method

.method public mergeNavigatorProps(Lcom/vdocipher/PlaybackSession$NavigatorProps;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15988
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15989
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mmergeNavigatorProps(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$NavigatorProps;)V

    return-object p0
.end method

.method public mergePlayerPerf(Lcom/vdocipher/PlaybackSession$PerfMetrics;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16184
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16185
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mmergePlayerPerf(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-object p0
.end method

.method public mergeResumed(Lcom/vdocipher/PlaybackSession$PlaybackResume;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16597
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16598
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mmergeResumed(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$PlaybackResume;)V

    return-object p0
.end method

.method public mergeSelectedTrack(Lcom/vdocipher/PlaybackSession$SelectedTrack;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16501
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16502
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mmergeSelectedTrack(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$SelectedTrack;)V

    return-object p0
.end method

.method public mergeToolkit(Lcom/vdocipher/PlaybackSession$Toolkit;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16719
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16720
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mmergeToolkit(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Toolkit;)V

    return-object p0
.end method

.method public mergeTrackCount(Lcom/vdocipher/PlaybackSession$TrackCount;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16305
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16306
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mmergeTrackCount(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$TrackCount;)V

    return-object p0
.end method

.method public mergeWidevineCDM(Lcom/vdocipher/PlaybackSession$WidevineCDM;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16766
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16767
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mmergeWidevineCDM(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$WidevineCDM;)V

    return-object p0
.end method

.method public removeBeats(I)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16414
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16415
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mremoveBeats(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;I)V

    return-object p0
.end method

.method public removeEvents(I)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16144
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16145
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$mremoveEvents(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;I)V

    return-object p0
.end method

.method public setAndroid(Lcom/vdocipher/PlaybackSession$Android$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16636
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16637
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Android$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetAndroid(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Android;)V

    return-object p0
.end method

.method public setAndroid(Lcom/vdocipher/PlaybackSession$Android;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16627
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16628
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetAndroid(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Android;)V

    return-object p0
.end method

.method public setBeats(ILcom/vdocipher/PlaybackSession$Beat$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 4

    .line 16352
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16353
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    .line 16354
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackSession$Beat$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackSession$Beat;

    .line 16353
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetBeats(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;ILcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public setBeats(ILcom/vdocipher/PlaybackSession$Beat;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 4

    .line 16343
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16344
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetBeats(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;ILcom/vdocipher/PlaybackSession$Beat;)V

    return-object p0
.end method

.method public setCaptionSearch(Lcom/vdocipher/PlaybackSession$CaptionSearch;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16228
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16229
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetCaptionSearch(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$CaptionSearch;)V

    return-object p0
.end method

.method public setCaptionSearchValue(I)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16210
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16211
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetCaptionSearchValue(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;I)V

    return-object p0
.end method

.method public setCoverage(Lcom/vdocipher/PlaybackSession$Coverage$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16027
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16028
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Coverage$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetCoverage(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Coverage;)V

    return-object p0
.end method

.method public setCoverage(Lcom/vdocipher/PlaybackSession$Coverage;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16018
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16019
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetCoverage(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Coverage;)V

    return-object p0
.end method

.method public setDevice(Lcom/vdocipher/PlaybackSession$Device$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15884
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15885
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Device$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Device;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetDevice(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Device;)V

    return-object p0
.end method

.method public setDevice(Lcom/vdocipher/PlaybackSession$Device;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15875
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15876
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetDevice(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Device;)V

    return-object p0
.end method

.method public setDimensions(Lcom/vdocipher/PlaybackSession$Dimension$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15597
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15598
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetDimensions(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Dimension;)V

    return-object p0
.end method

.method public setDimensions(Lcom/vdocipher/PlaybackSession$Dimension;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15588
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15589
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetDimensions(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Dimension;)V

    return-object p0
.end method

.method public setDownloadLocation(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16537
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16538
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetDownloadLocation(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setDownloadLocationBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16557
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16558
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetDownloadLocationBytes(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setEmbedInfo(Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15550
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15551
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetEmbedInfo(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$EmbedInfo;)V

    return-object p0
.end method

.method public setEmbedInfo(Lcom/vdocipher/PlaybackSession$EmbedInfo;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15541
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15542
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetEmbedInfo(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$EmbedInfo;)V

    return-object p0
.end method

.method public setError(Lcom/vdocipher/PlaybackSession$Error$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16446
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16447
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Error$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetError(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Error;)V

    return-object p0
.end method

.method public setError(Lcom/vdocipher/PlaybackSession$Error;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16437
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16438
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetError(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Error;)V

    return-object p0
.end method

.method public setEvents(ILcom/vdocipher/PlaybackSession$Event$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 4

    .line 16082
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16083
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    .line 16084
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackSession$Event$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackSession$Event;

    .line 16083
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetEvents(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;ILcom/vdocipher/PlaybackSession$Event;)V

    return-object p0
.end method

.method public setEvents(ILcom/vdocipher/PlaybackSession$Event;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 4

    .line 16073
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16074
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetEvents(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;ILcom/vdocipher/PlaybackSession$Event;)V

    return-object p0
.end method

.method public setIsUIEnabled(Z)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16256
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16257
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetIsUIEnabled(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Z)V

    return-object p0
.end method

.method public setMedia(Lcom/vdocipher/PlaybackSession$Media$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15837
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15838
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Media$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetMedia(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Media;)V

    return-object p0
.end method

.method public setMedia(Lcom/vdocipher/PlaybackSession$Media;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15828
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15829
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetMedia(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Media;)V

    return-object p0
.end method

.method public setNavigator(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15928
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15929
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetNavigator(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setNavigatorBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15948
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15949
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetNavigatorBytes(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setNavigatorProps(Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15980
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15981
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$NavigatorProps$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$NavigatorProps;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetNavigatorProps(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$NavigatorProps;)V

    return-object p0
.end method

.method public setNavigatorProps(Lcom/vdocipher/PlaybackSession$NavigatorProps;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15971
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15972
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetNavigatorProps(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$NavigatorProps;)V

    return-object p0
.end method

.method public setPlatform(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15736
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15737
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetPlatform(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setPlatformBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15756
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15757
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetPlatformBytes(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setPlayerPerf(Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16176
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16177
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetPlayerPerf(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-object p0
.end method

.method public setPlayerPerf(Lcom/vdocipher/PlaybackSession$PerfMetrics;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16167
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16168
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetPlayerPerf(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-object p0
.end method

.method public setRefUrl(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15641
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15642
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetRefUrl(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setRefUrlBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15661
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15662
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetRefUrlBytes(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setResumed(Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16589
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16590
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetResumed(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$PlaybackResume;)V

    return-object p0
.end method

.method public setResumed(Lcom/vdocipher/PlaybackSession$PlaybackResume;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16580
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16581
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetResumed(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$PlaybackResume;)V

    return-object p0
.end method

.method public setSelectedTrack(Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16493
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16494
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$SelectedTrack$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$SelectedTrack;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetSelectedTrack(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$SelectedTrack;)V

    return-object p0
.end method

.method public setSelectedTrack(Lcom/vdocipher/PlaybackSession$SelectedTrack;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16484
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16485
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetSelectedTrack(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$SelectedTrack;)V

    return-object p0
.end method

.method public setSession(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15449
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15450
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetSession(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setSessionBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15469
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15470
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetSessionBytes(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setSessionInitTime(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15498
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15499
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetSessionInitTime(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setSessionInitTimeBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15518
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15519
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetSessionInitTimeBytes(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setTech(Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15698
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15699
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetTech(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;)V

    return-object p0
.end method

.method public setTechValue(I)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15680
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15681
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetTechValue(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;I)V

    return-object p0
.end method

.method public setToolkit(Lcom/vdocipher/PlaybackSession$Toolkit$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16711
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16712
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Toolkit$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Toolkit;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetToolkit(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Toolkit;)V

    return-object p0
.end method

.method public setToolkit(Lcom/vdocipher/PlaybackSession$Toolkit;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16702
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16703
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetToolkit(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$Toolkit;)V

    return-object p0
.end method

.method public setTrackCount(Lcom/vdocipher/PlaybackSession$TrackCount$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16297
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16298
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$TrackCount$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetTrackCount(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$TrackCount;)V

    return-object p0
.end method

.method public setTrackCount(Lcom/vdocipher/PlaybackSession$TrackCount;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16288
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16289
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetTrackCount(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$TrackCount;)V

    return-object p0
.end method

.method public setViewer(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15785
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15786
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetViewer(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setViewerBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 15805
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 15806
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetViewerBytes(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setWatermarkCount(I)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16670
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16671
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetWatermarkCount(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;I)V

    return-object p0
.end method

.method public setWidevineCDM(Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16758
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16759
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetWidevineCDM(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$WidevineCDM;)V

    return-object p0
.end method

.method public setWidevineCDM(Lcom/vdocipher/PlaybackSession$WidevineCDM;)Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;
    .registers 3

    .line 16749
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->copyOnWrite()V

    .line 16750
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;->-$$Nest$msetWidevineCDM(Lcom/vdocipher/PlaybackSession$PlaybackSessionTable;Lcom/vdocipher/PlaybackSession$WidevineCDM;)V

    return-object p0
.end method
