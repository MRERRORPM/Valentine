# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$TrackCount$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$TrackCountOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$TrackCount;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$TrackCount;",
        "Lcom/vdocipher/PlaybackSession$TrackCount$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$TrackCountOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 8424
    invoke-static {}, Lcom/vdocipher/PlaybackSession$TrackCount;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$TrackCount;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$TrackCount$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearVideo()Lcom/vdocipher/PlaybackSession$TrackCount$Builder;
    .registers 2

    .line 8451
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$TrackCount$Builder;->copyOnWrite()V

    .line 8452
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackCount$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$TrackCount;->-$$Nest$mclearVideo(Lcom/vdocipher/PlaybackSession$TrackCount;)V

    return-object p0
.end method

.method public getVideo()I
    .registers 2

    .line 8434
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackCount$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$TrackCount;->getVideo()I

    move-result v0

    return v0
.end method

.method public setVideo(I)Lcom/vdocipher/PlaybackSession$TrackCount$Builder;
    .registers 3

    .line 8442
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$TrackCount$Builder;->copyOnWrite()V

    .line 8443
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$TrackCount$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$TrackCount;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$TrackCount;->-$$Nest$msetVideo(Lcom/vdocipher/PlaybackSession$TrackCount;I)V

    return-object p0
.end method
