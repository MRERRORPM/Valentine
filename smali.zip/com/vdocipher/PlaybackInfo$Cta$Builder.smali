# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$Cta$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$CtaOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$Cta;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackInfo$Cta;",
        "Lcom/vdocipher/PlaybackInfo$Cta$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$CtaOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 11474
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Cta;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$Cta;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackInfo-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Cta$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearId()Lcom/vdocipher/PlaybackInfo$Cta$Builder;
    .registers 2

    .line 11511
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->copyOnWrite()V

    .line 11512
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$Cta;->-$$Nest$mclearId(Lcom/vdocipher/PlaybackInfo$Cta;)V

    return-object p0
.end method

.method public clearType()Lcom/vdocipher/PlaybackInfo$Cta$Builder;
    .registers 2

    .line 11560
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->copyOnWrite()V

    .line 11561
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$Cta;->-$$Nest$mclearType(Lcom/vdocipher/PlaybackInfo$Cta;)V

    return-object p0
.end method

.method public getId()Ljava/lang/String;
    .registers 2

    .line 11484
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Cta;->getId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getIdBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 11493
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Cta;->getIdBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getType()Ljava/lang/String;
    .registers 2

    .line 11533
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Cta;->getType()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getTypeBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 11542
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Cta;->getTypeBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setId(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$Cta$Builder;
    .registers 3

    .line 11502
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->copyOnWrite()V

    .line 11503
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Cta;->-$$Nest$msetId(Lcom/vdocipher/PlaybackInfo$Cta;Ljava/lang/String;)V

    return-object p0
.end method

.method public setIdBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$Cta$Builder;
    .registers 3

    .line 11522
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->copyOnWrite()V

    .line 11523
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Cta;->-$$Nest$msetIdBytes(Lcom/vdocipher/PlaybackInfo$Cta;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setType(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$Cta$Builder;
    .registers 3

    .line 11551
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->copyOnWrite()V

    .line 11552
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Cta;->-$$Nest$msetType(Lcom/vdocipher/PlaybackInfo$Cta;Ljava/lang/String;)V

    return-object p0
.end method

.method public setTypeBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$Cta$Builder;
    .registers 3

    .line 11571
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->copyOnWrite()V

    .line 11572
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Cta$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Cta;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$Cta;->-$$Nest$msetTypeBytes(Lcom/vdocipher/PlaybackInfo$Cta;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
