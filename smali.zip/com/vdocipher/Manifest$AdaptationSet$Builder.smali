# classes14.dex

.class public final Lcom/vdocipher/Manifest$AdaptationSet$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$AdaptationSetOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest$AdaptationSet;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/Manifest$AdaptationSet;",
        "Lcom/vdocipher/Manifest$AdaptationSet$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$AdaptationSetOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 7128
    invoke-static {}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$AdaptationSet;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/Manifest-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public addAllContentProtection(Ljava/lang/Iterable;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$ContentProtection;",
            ">;)",
            "Lcom/vdocipher/Manifest$AdaptationSet$Builder;"
        }
    .end annotation

    .line 7917
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7918
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddAllContentProtection(Lcom/vdocipher/Manifest$AdaptationSet;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllRepresentation(Ljava/lang/Iterable;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$Representation;",
            ">;)",
            "Lcom/vdocipher/Manifest$AdaptationSet$Builder;"
        }
    .end annotation

    .line 8019
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 8020
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddAllRepresentation(Lcom/vdocipher/Manifest$AdaptationSet;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllRole(Ljava/lang/Iterable;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$Role;",
            ">;)",
            "Lcom/vdocipher/Manifest$AdaptationSet$Builder;"
        }
    .end annotation

    .line 7713
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7714
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddAllRole(Lcom/vdocipher/Manifest$AdaptationSet;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllSupplementalProperty(Ljava/lang/Iterable;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$SupplementalProperty;",
            ">;)",
            "Lcom/vdocipher/Manifest$AdaptationSet$Builder;"
        }
    .end annotation

    .line 7815
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7816
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddAllSupplementalProperty(Lcom/vdocipher/Manifest$AdaptationSet;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addContentProtection(ILcom/vdocipher/Manifest$ContentProtection$Builder;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 7907
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7908
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    .line 7909
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$ContentProtection$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$ContentProtection;

    .line 7908
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddContentProtection(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$ContentProtection;)V

    return-object p0
.end method

.method public addContentProtection(ILcom/vdocipher/Manifest$ContentProtection;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 7889
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7890
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddContentProtection(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$ContentProtection;)V

    return-object p0
.end method

.method public addContentProtection(Lcom/vdocipher/Manifest$ContentProtection$Builder;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7898
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7899
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$ContentProtection$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddContentProtection(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$ContentProtection;)V

    return-object p0
.end method

.method public addContentProtection(Lcom/vdocipher/Manifest$ContentProtection;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7880
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7881
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddContentProtection(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$ContentProtection;)V

    return-object p0
.end method

.method public addRepresentation(ILcom/vdocipher/Manifest$Representation$Builder;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 8009
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 8010
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    .line 8011
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$Representation$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$Representation;

    .line 8010
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddRepresentation(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public addRepresentation(ILcom/vdocipher/Manifest$Representation;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 7991
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7992
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddRepresentation(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public addRepresentation(Lcom/vdocipher/Manifest$Representation$Builder;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 8000
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 8001
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$Representation$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddRepresentation(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public addRepresentation(Lcom/vdocipher/Manifest$Representation;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7982
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7983
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddRepresentation(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public addRole(ILcom/vdocipher/Manifest$Role$Builder;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 7703
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7704
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    .line 7705
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$Role$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$Role;

    .line 7704
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddRole(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$Role;)V

    return-object p0
.end method

.method public addRole(ILcom/vdocipher/Manifest$Role;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 7685
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7686
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddRole(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$Role;)V

    return-object p0
.end method

.method public addRole(Lcom/vdocipher/Manifest$Role$Builder;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7694
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7695
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$Role$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$Role;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddRole(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$Role;)V

    return-object p0
.end method

.method public addRole(Lcom/vdocipher/Manifest$Role;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7676
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7677
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddRole(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$Role;)V

    return-object p0
.end method

.method public addSupplementalProperty(ILcom/vdocipher/Manifest$SupplementalProperty$Builder;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 7805
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7806
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    .line 7807
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$SupplementalProperty;

    .line 7806
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddSupplementalProperty(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$SupplementalProperty;)V

    return-object p0
.end method

.method public addSupplementalProperty(ILcom/vdocipher/Manifest$SupplementalProperty;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 7787
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7788
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddSupplementalProperty(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$SupplementalProperty;)V

    return-object p0
.end method

.method public addSupplementalProperty(Lcom/vdocipher/Manifest$SupplementalProperty$Builder;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7796
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7797
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddSupplementalProperty(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$SupplementalProperty;)V

    return-object p0
.end method

.method public addSupplementalProperty(Lcom/vdocipher/Manifest$SupplementalProperty;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7778
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7779
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$maddSupplementalProperty(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$SupplementalProperty;)V

    return-object p0
.end method

.method public clearContentProtection()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7925
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7926
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearContentProtection(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public clearContentType()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7201
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7202
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearContentType(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public clearFrameRate()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7376
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7377
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearFrameRate(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public clearHeight()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7330
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7331
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearHeight(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public clearId()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7155
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7156
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearId(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public clearLang()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7247
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7248
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearLang(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public clearMaxFrameRate()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7505
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7506
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearMaxFrameRate(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public clearMaxHeight()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7459
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7460
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearMaxHeight(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public clearMaxWidth()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7423
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7424
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearMaxWidth(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public clearPar()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7563
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7564
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearPar(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public clearRepresentation()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 8027
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 8028
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearRepresentation(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public clearRole()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7721
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7722
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearRole(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public clearSubsegmentAlignment()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7627
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7628
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearSubsegmentAlignment(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public clearSubsegmentStartsWithSAP()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7599
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7600
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearSubsegmentStartsWithSAP(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public clearSupplementalProperty()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7823
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7824
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearSupplementalProperty(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public clearWidth()Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 2

    .line 7294
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7295
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mclearWidth(Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public getContentProtection(I)Lcom/vdocipher/Manifest$ContentProtection;
    .registers 3

    .line 7855
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->getContentProtection(I)Lcom/vdocipher/Manifest$ContentProtection;

    move-result-object p1

    return-object p1
.end method

.method public getContentProtectionCount()I
    .registers 2

    .line 7849
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getContentProtectionCount()I

    move-result v0

    return v0
.end method

.method public getContentProtectionList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$ContentProtection;",
            ">;"
        }
    .end annotation

    .line 7841
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    .line 7842
    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getContentProtectionList()Ljava/util/List;

    move-result-object v0

    .line 7841
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getContentType()Lcom/vdocipher/Manifest$ContentType;
    .registers 2

    .line 7184
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getContentType()Lcom/vdocipher/Manifest$ContentType;

    move-result-object v0

    return-object v0
.end method

.method public getContentTypeValue()I
    .registers 2

    .line 7166
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getContentTypeValue()I

    move-result v0

    return v0
.end method

.method public getFrameRate()Ljava/lang/String;
    .registers 2

    .line 7349
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getFrameRate()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getFrameRateBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 7358
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getFrameRateBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getHeight()I
    .registers 2

    .line 7313
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getHeight()I

    move-result v0

    return v0
.end method

.method public getId()I
    .registers 2

    .line 7138
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getId()I

    move-result v0

    return v0
.end method

.method public getLang()Ljava/lang/String;
    .registers 2

    .line 7220
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getLang()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getLangBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 7229
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getLangBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getMaxFrameRate()Ljava/lang/String;
    .registers 2

    .line 7478
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getMaxFrameRate()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getMaxFrameRateBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 7487
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getMaxFrameRateBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getMaxHeight()I
    .registers 2

    .line 7442
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getMaxHeight()I

    move-result v0

    return v0
.end method

.method public getMaxWidth()I
    .registers 2

    .line 7406
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getMaxWidth()I

    move-result v0

    return v0
.end method

.method public getPar()Lcom/vdocipher/Manifest$AspectRatio;
    .registers 2

    .line 7533
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getPar()Lcom/vdocipher/Manifest$AspectRatio;

    move-result-object v0

    return-object v0
.end method

.method public getRepresentation(I)Lcom/vdocipher/Manifest$Representation;
    .registers 3

    .line 7957
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->getRepresentation(I)Lcom/vdocipher/Manifest$Representation;

    move-result-object p1

    return-object p1
.end method

.method public getRepresentationCount()I
    .registers 2

    .line 7951
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getRepresentationCount()I

    move-result v0

    return v0
.end method

.method public getRepresentationList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$Representation;",
            ">;"
        }
    .end annotation

    .line 7943
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    .line 7944
    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getRepresentationList()Ljava/util/List;

    move-result-object v0

    .line 7943
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getRole(I)Lcom/vdocipher/Manifest$Role;
    .registers 3

    .line 7651
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->getRole(I)Lcom/vdocipher/Manifest$Role;

    move-result-object p1

    return-object p1
.end method

.method public getRoleCount()I
    .registers 2

    .line 7645
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getRoleCount()I

    move-result v0

    return v0
.end method

.method public getRoleList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$Role;",
            ">;"
        }
    .end annotation

    .line 7637
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    .line 7638
    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getRoleList()Ljava/util/List;

    move-result-object v0

    .line 7637
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getSubsegmentAlignment()Z
    .registers 2

    .line 7610
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getSubsegmentAlignment()Z

    move-result v0

    return v0
.end method

.method public getSubsegmentStartsWithSAP()I
    .registers 2

    .line 7582
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getSubsegmentStartsWithSAP()I

    move-result v0

    return v0
.end method

.method public getSupplementalProperty(I)Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 3

    .line 7753
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->getSupplementalProperty(I)Lcom/vdocipher/Manifest$SupplementalProperty;

    move-result-object p1

    return-object p1
.end method

.method public getSupplementalPropertyCount()I
    .registers 2

    .line 7747
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getSupplementalPropertyCount()I

    move-result v0

    return v0
.end method

.method public getSupplementalPropertyList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$SupplementalProperty;",
            ">;"
        }
    .end annotation

    .line 7739
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    .line 7740
    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getSupplementalPropertyList()Ljava/util/List;

    move-result-object v0

    .line 7739
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getWidth()I
    .registers 2

    .line 7277
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->getWidth()I

    move-result v0

    return v0
.end method

.method public hasFrameRate()Z
    .registers 2

    .line 7341
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->hasFrameRate()Z

    move-result v0

    return v0
.end method

.method public hasHeight()Z
    .registers 2

    .line 7305
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->hasHeight()Z

    move-result v0

    return v0
.end method

.method public hasLang()Z
    .registers 2

    .line 7212
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->hasLang()Z

    move-result v0

    return v0
.end method

.method public hasMaxFrameRate()Z
    .registers 2

    .line 7470
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->hasMaxFrameRate()Z

    move-result v0

    return v0
.end method

.method public hasMaxHeight()Z
    .registers 2

    .line 7434
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->hasMaxHeight()Z

    move-result v0

    return v0
.end method

.method public hasMaxWidth()Z
    .registers 2

    .line 7398
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->hasMaxWidth()Z

    move-result v0

    return v0
.end method

.method public hasPar()Z
    .registers 2

    .line 7526
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->hasPar()Z

    move-result v0

    return v0
.end method

.method public hasSubsegmentStartsWithSAP()Z
    .registers 2

    .line 7574
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->hasSubsegmentStartsWithSAP()Z

    move-result v0

    return v0
.end method

.method public hasWidth()Z
    .registers 2

    .line 7269
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$AdaptationSet;->hasWidth()Z

    move-result v0

    return v0
.end method

.method public mergePar(Lcom/vdocipher/Manifest$AspectRatio;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7556
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7557
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mmergePar(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$AspectRatio;)V

    return-object p0
.end method

.method public removeContentProtection(I)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7933
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7934
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mremoveContentProtection(Lcom/vdocipher/Manifest$AdaptationSet;I)V

    return-object p0
.end method

.method public removeRepresentation(I)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 8035
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 8036
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mremoveRepresentation(Lcom/vdocipher/Manifest$AdaptationSet;I)V

    return-object p0
.end method

.method public removeRole(I)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7729
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7730
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mremoveRole(Lcom/vdocipher/Manifest$AdaptationSet;I)V

    return-object p0
.end method

.method public removeSupplementalProperty(I)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7831
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7832
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$mremoveSupplementalProperty(Lcom/vdocipher/Manifest$AdaptationSet;I)V

    return-object p0
.end method

.method public setContentProtection(ILcom/vdocipher/Manifest$ContentProtection$Builder;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 7871
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7872
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    .line 7873
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$ContentProtection$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$ContentProtection;

    .line 7872
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetContentProtection(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$ContentProtection;)V

    return-object p0
.end method

.method public setContentProtection(ILcom/vdocipher/Manifest$ContentProtection;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 7862
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7863
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetContentProtection(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$ContentProtection;)V

    return-object p0
.end method

.method public setContentType(Lcom/vdocipher/Manifest$ContentType;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7192
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7193
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetContentType(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$ContentType;)V

    return-object p0
.end method

.method public setContentTypeValue(I)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7174
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7175
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetContentTypeValue(Lcom/vdocipher/Manifest$AdaptationSet;I)V

    return-object p0
.end method

.method public setFrameRate(Ljava/lang/String;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7367
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7368
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetFrameRate(Lcom/vdocipher/Manifest$AdaptationSet;Ljava/lang/String;)V

    return-object p0
.end method

.method public setFrameRateBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7387
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7388
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetFrameRateBytes(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setHeight(I)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7321
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7322
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetHeight(Lcom/vdocipher/Manifest$AdaptationSet;I)V

    return-object p0
.end method

.method public setId(I)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7146
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7147
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetId(Lcom/vdocipher/Manifest$AdaptationSet;I)V

    return-object p0
.end method

.method public setLang(Ljava/lang/String;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7238
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7239
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetLang(Lcom/vdocipher/Manifest$AdaptationSet;Ljava/lang/String;)V

    return-object p0
.end method

.method public setLangBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7258
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7259
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetLangBytes(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setMaxFrameRate(Ljava/lang/String;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7496
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7497
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetMaxFrameRate(Lcom/vdocipher/Manifest$AdaptationSet;Ljava/lang/String;)V

    return-object p0
.end method

.method public setMaxFrameRateBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7516
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7517
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetMaxFrameRateBytes(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setMaxHeight(I)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7450
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7451
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetMaxHeight(Lcom/vdocipher/Manifest$AdaptationSet;I)V

    return-object p0
.end method

.method public setMaxWidth(I)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7414
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7415
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetMaxWidth(Lcom/vdocipher/Manifest$AdaptationSet;I)V

    return-object p0
.end method

.method public setPar(Lcom/vdocipher/Manifest$AspectRatio$Builder;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7548
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7549
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$AspectRatio$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetPar(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$AspectRatio;)V

    return-object p0
.end method

.method public setPar(Lcom/vdocipher/Manifest$AspectRatio;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7539
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7540
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetPar(Lcom/vdocipher/Manifest$AdaptationSet;Lcom/vdocipher/Manifest$AspectRatio;)V

    return-object p0
.end method

.method public setRepresentation(ILcom/vdocipher/Manifest$Representation$Builder;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 7973
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7974
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    .line 7975
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$Representation$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$Representation;

    .line 7974
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetRepresentation(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public setRepresentation(ILcom/vdocipher/Manifest$Representation;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 7964
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7965
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetRepresentation(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public setRole(ILcom/vdocipher/Manifest$Role$Builder;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 7667
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7668
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    .line 7669
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$Role$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$Role;

    .line 7668
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetRole(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$Role;)V

    return-object p0
.end method

.method public setRole(ILcom/vdocipher/Manifest$Role;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 7658
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7659
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetRole(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$Role;)V

    return-object p0
.end method

.method public setSubsegmentAlignment(Z)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7618
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7619
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetSubsegmentAlignment(Lcom/vdocipher/Manifest$AdaptationSet;Z)V

    return-object p0
.end method

.method public setSubsegmentStartsWithSAP(I)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7590
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7591
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetSubsegmentStartsWithSAP(Lcom/vdocipher/Manifest$AdaptationSet;I)V

    return-object p0
.end method

.method public setSupplementalProperty(ILcom/vdocipher/Manifest$SupplementalProperty$Builder;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 7769
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7770
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    .line 7771
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$SupplementalProperty;

    .line 7770
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetSupplementalProperty(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$SupplementalProperty;)V

    return-object p0
.end method

.method public setSupplementalProperty(ILcom/vdocipher/Manifest$SupplementalProperty;)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 4

    .line 7760
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7761
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetSupplementalProperty(Lcom/vdocipher/Manifest$AdaptationSet;ILcom/vdocipher/Manifest$SupplementalProperty;)V

    return-object p0
.end method

.method public setWidth(I)Lcom/vdocipher/Manifest$AdaptationSet$Builder;
    .registers 3

    .line 7285
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->copyOnWrite()V

    .line 7286
    iget-object v0, p0, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$AdaptationSet;->-$$Nest$msetWidth(Lcom/vdocipher/Manifest$AdaptationSet;I)V

    return-object p0
.end method
