# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$ErrorMessage;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$ErrorMessageOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "ErrorMessage"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackInfo$ErrorMessage;",
        "Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$ErrorMessageOrBuilder;"
    }
.end annotation


# static fields
.field public static final CODES_FIELD_NUMBER:I = 0x1

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

.field public static final MSGDEFAULT_FIELD_NUMBER:I = 0x3

.field public static final MSGKEY_FIELD_NUMBER:I = 0x2

.field private static volatile PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$ErrorMessage;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private codesMemoizedSerializedSize:I

.field private codes_:Lcom/google/protobuf/Internal$IntList;

.field private msgDefault_:Ljava/lang/String;

.field private msgKey_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$maddAllCodes(Lcom/vdocipher/PlaybackInfo$ErrorMessage;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->addAllCodes(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddCodes(Lcom/vdocipher/PlaybackInfo$ErrorMessage;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->addCodes(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearCodes(Lcom/vdocipher/PlaybackInfo$ErrorMessage;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->clearCodes()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMsgDefault(Lcom/vdocipher/PlaybackInfo$ErrorMessage;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->clearMsgDefault()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMsgKey(Lcom/vdocipher/PlaybackInfo$ErrorMessage;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->clearMsgKey()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCodes(Lcom/vdocipher/PlaybackInfo$ErrorMessage;II)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->setCodes(II)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMsgDefault(Lcom/vdocipher/PlaybackInfo$ErrorMessage;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->setMsgDefault(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMsgDefaultBytes(Lcom/vdocipher/PlaybackInfo$ErrorMessage;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->setMsgDefaultBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMsgKey(Lcom/vdocipher/PlaybackInfo$ErrorMessage;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->setMsgKey(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMsgKeyBytes(Lcom/vdocipher/PlaybackInfo$ErrorMessage;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->setMsgKeyBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 11228
    new-instance v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;-><init>()V

    .line 11231
    sput-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    .line 11232
    const-class v1, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 10736
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    const/4 v0, -0x1

    .line 10769
    iput v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->codesMemoizedSerializedSize:I

    .line 10737
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->emptyIntList()Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->codes_:Lcom/google/protobuf/Internal$IntList;

    .line 10738
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->msgKey_:Ljava/lang/String;

    .line 10739
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->msgDefault_:Ljava/lang/String;

    return-void
.end method

.method private addAllCodes(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .line 10801
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->ensureCodesIsMutable()V

    .line 10802
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->codes_:Lcom/google/protobuf/Internal$IntList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addCodes(I)V
    .registers 3

    .line 10792
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->ensureCodesIsMutable()V

    .line 10793
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->codes_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    return-void
.end method

.method private clearCodes()V
    .registers 2

    .line 10809
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->emptyIntList()Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->codes_:Lcom/google/protobuf/Internal$IntList;

    return-void
.end method

.method private clearMsgDefault()V
    .registers 2

    .line 10893
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->getMsgDefault()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->msgDefault_:Ljava/lang/String;

    return-void
.end method

.method private clearMsgKey()V
    .registers 2

    .line 10846
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->getMsgKey()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->msgKey_:Ljava/lang/String;

    return-void
.end method

.method private ensureCodesIsMutable()V
    .registers 3

    .line 10771
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->codes_:Lcom/google/protobuf/Internal$IntList;

    .line 10772
    invoke-interface {v0}, Lcom/google/protobuf/Internal$IntList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 10774
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$IntList;)Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->codes_:Lcom/google/protobuf/Internal$IntList;

    :cond_e
    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 1

    .line 11237
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;
    .registers 1

    .line 10983
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackInfo$ErrorMessage;)Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;
    .registers 2

    .line 10986
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10959
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10966
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10922
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10929
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10971
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10978
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10946
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10953
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10909
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10916
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10934
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10941
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$ErrorMessage;",
            ">;"
        }
    .end annotation

    .line 11243
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setCodes(II)V
    .registers 4

    .line 10784
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->ensureCodesIsMutable()V

    .line 10785
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->codes_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$IntList;->setInt(II)I

    return-void
.end method

.method private setMsgDefault(Ljava/lang/String;)V
    .registers 2

    .line 10884
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10886
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->msgDefault_:Ljava/lang/String;

    return-void
.end method

.method private setMsgDefaultBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 10901
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 10902
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->msgDefault_:Ljava/lang/String;

    return-void
.end method

.method private setMsgKey(Ljava/lang/String;)V
    .registers 2

    .line 10837
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10839
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->msgKey_:Ljava/lang/String;

    return-void
.end method

.method private setMsgKeyBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 10854
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 10855
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->msgKey_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 11177
    sget-object p2, Lcom/vdocipher/PlaybackInfo$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_56

    .line 11221
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 11215
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 11200
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 11202
    const-class p2, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    monitor-enter p2

    .line 11203
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 11205
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 11208
    sput-object p1, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->PARSER:Lcom/google/protobuf/Parser;

    .line 11210
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 11197
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object p1

    .line 11185
    :pswitch_36  #0x3
    const-string p1, "codes_"

    const-string p2, "msgKey_"

    const-string p3, "msgDefault_"

    filled-new-array {p1, p2, p3}, [Ljava/lang/Object;

    move-result-object p1

    .line 11190
    const-string p2, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0001\u0000\u0001+\u0002Ȉ\u0003Ȉ"

    .line 11193
    sget-object p3, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 11182
    :pswitch_49  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;-><init>(Lcom/vdocipher/PlaybackInfo-IA;)V

    return-object p1

    .line 11179
    :pswitch_4f  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;-><init>()V

    return-object p1

    nop

    :pswitch_data_56
    .packed-switch 0x1
        :pswitch_4f  #00000001
        :pswitch_49  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getCodes(I)I
    .registers 3

    .line 10767
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->codes_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->getInt(I)I

    move-result p1

    return p1
.end method

.method public getCodesCount()I
    .registers 2

    .line 10758
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->codes_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$IntList;->size()I

    move-result v0

    return v0
.end method

.method public getCodesList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 10750
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->codes_:Lcom/google/protobuf/Internal$IntList;

    return-object v0
.end method

.method public getMsgDefault()Ljava/lang/String;
    .registers 2

    .line 10867
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->msgDefault_:Ljava/lang/String;

    return-object v0
.end method

.method public getMsgDefaultBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 10876
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->msgDefault_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getMsgKey()Ljava/lang/String;
    .registers 2

    .line 10820
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->msgKey_:Ljava/lang/String;

    return-object v0
.end method

.method public getMsgKeyBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 10829
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->msgKey_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method
