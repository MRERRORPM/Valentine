# classes14.dex

.class public final Lcom/vdocipher/Manifest$Period$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$PeriodOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest$Period;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/Manifest$Period;",
        "Lcom/vdocipher/Manifest$Period$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$PeriodOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 8459
    invoke-static {}, Lcom/vdocipher/Manifest$Period;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$Period;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/Manifest-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Period$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public addAdaptationSet(ILcom/vdocipher/Manifest$AdaptationSet$Builder;)Lcom/vdocipher/Manifest$Period$Builder;
    .registers 4

    .line 8562
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Period$Builder;->copyOnWrite()V

    .line 8563
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    .line 8564
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$AdaptationSet;

    .line 8563
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Period;->-$$Nest$maddAdaptationSet(Lcom/vdocipher/Manifest$Period;ILcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public addAdaptationSet(ILcom/vdocipher/Manifest$AdaptationSet;)Lcom/vdocipher/Manifest$Period$Builder;
    .registers 4

    .line 8544
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Period$Builder;->copyOnWrite()V

    .line 8545
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Period;->-$$Nest$maddAdaptationSet(Lcom/vdocipher/Manifest$Period;ILcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public addAdaptationSet(Lcom/vdocipher/Manifest$AdaptationSet$Builder;)Lcom/vdocipher/Manifest$Period$Builder;
    .registers 3

    .line 8553
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Period$Builder;->copyOnWrite()V

    .line 8554
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$AdaptationSet;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Period;->-$$Nest$maddAdaptationSet(Lcom/vdocipher/Manifest$Period;Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public addAdaptationSet(Lcom/vdocipher/Manifest$AdaptationSet;)Lcom/vdocipher/Manifest$Period$Builder;
    .registers 3

    .line 8535
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Period$Builder;->copyOnWrite()V

    .line 8536
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Period;->-$$Nest$maddAdaptationSet(Lcom/vdocipher/Manifest$Period;Lcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public addAllAdaptationSet(Ljava/lang/Iterable;)Lcom/vdocipher/Manifest$Period$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$AdaptationSet;",
            ">;)",
            "Lcom/vdocipher/Manifest$Period$Builder;"
        }
    .end annotation

    .line 8572
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Period$Builder;->copyOnWrite()V

    .line 8573
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Period;->-$$Nest$maddAllAdaptationSet(Lcom/vdocipher/Manifest$Period;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public clearAdaptationSet()Lcom/vdocipher/Manifest$Period$Builder;
    .registers 2

    .line 8580
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Period$Builder;->copyOnWrite()V

    .line 8581
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Period;->-$$Nest$mclearAdaptationSet(Lcom/vdocipher/Manifest$Period;)V

    return-object p0
.end method

.method public clearDuration()Lcom/vdocipher/Manifest$Period$Builder;
    .registers 2

    .line 8634
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Period$Builder;->copyOnWrite()V

    .line 8635
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Period;->-$$Nest$mclearDuration(Lcom/vdocipher/Manifest$Period;)V

    return-object p0
.end method

.method public clearId()Lcom/vdocipher/Manifest$Period$Builder;
    .registers 2

    .line 8486
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Period$Builder;->copyOnWrite()V

    .line 8487
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Period;->-$$Nest$mclearId(Lcom/vdocipher/Manifest$Period;)V

    return-object p0
.end method

.method public getAdaptationSet(I)Lcom/vdocipher/Manifest$AdaptationSet;
    .registers 3

    .line 8510
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-virtual {v0, p1}, Lcom/vdocipher/Manifest$Period;->getAdaptationSet(I)Lcom/vdocipher/Manifest$AdaptationSet;

    move-result-object p1

    return-object p1
.end method

.method public getAdaptationSetCount()I
    .registers 2

    .line 8504
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Period;->getAdaptationSetCount()I

    move-result v0

    return v0
.end method

.method public getAdaptationSetList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$AdaptationSet;",
            ">;"
        }
    .end annotation

    .line 8496
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    .line 8497
    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Period;->getAdaptationSetList()Ljava/util/List;

    move-result-object v0

    .line 8496
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getDuration()Ljava/lang/String;
    .registers 2

    .line 8607
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Period;->getDuration()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getDurationBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8616
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Period;->getDurationBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getId()I
    .registers 2

    .line 8469
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Period;->getId()I

    move-result v0

    return v0
.end method

.method public hasDuration()Z
    .registers 2

    .line 8599
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Period;->hasDuration()Z

    move-result v0

    return v0
.end method

.method public removeAdaptationSet(I)Lcom/vdocipher/Manifest$Period$Builder;
    .registers 3

    .line 8588
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Period$Builder;->copyOnWrite()V

    .line 8589
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Period;->-$$Nest$mremoveAdaptationSet(Lcom/vdocipher/Manifest$Period;I)V

    return-object p0
.end method

.method public setAdaptationSet(ILcom/vdocipher/Manifest$AdaptationSet$Builder;)Lcom/vdocipher/Manifest$Period$Builder;
    .registers 4

    .line 8526
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Period$Builder;->copyOnWrite()V

    .line 8527
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    .line 8528
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$AdaptationSet$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$AdaptationSet;

    .line 8527
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Period;->-$$Nest$msetAdaptationSet(Lcom/vdocipher/Manifest$Period;ILcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public setAdaptationSet(ILcom/vdocipher/Manifest$AdaptationSet;)Lcom/vdocipher/Manifest$Period$Builder;
    .registers 4

    .line 8517
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Period$Builder;->copyOnWrite()V

    .line 8518
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Period;->-$$Nest$msetAdaptationSet(Lcom/vdocipher/Manifest$Period;ILcom/vdocipher/Manifest$AdaptationSet;)V

    return-object p0
.end method

.method public setDuration(Ljava/lang/String;)Lcom/vdocipher/Manifest$Period$Builder;
    .registers 3

    .line 8625
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Period$Builder;->copyOnWrite()V

    .line 8626
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Period;->-$$Nest$msetDuration(Lcom/vdocipher/Manifest$Period;Ljava/lang/String;)V

    return-object p0
.end method

.method public setDurationBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$Period$Builder;
    .registers 3

    .line 8645
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Period$Builder;->copyOnWrite()V

    .line 8646
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Period;->-$$Nest$msetDurationBytes(Lcom/vdocipher/Manifest$Period;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setId(I)Lcom/vdocipher/Manifest$Period$Builder;
    .registers 3

    .line 8477
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Period$Builder;->copyOnWrite()V

    .line 8478
    iget-object v0, p0, Lcom/vdocipher/Manifest$Period$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Period;->-$$Nest$msetId(Lcom/vdocipher/Manifest$Period;I)V

    return-object p0
.end method
