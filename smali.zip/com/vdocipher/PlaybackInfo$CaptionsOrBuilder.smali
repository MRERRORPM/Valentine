# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackInfo$CaptionsOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "CaptionsOrBuilder"
.end annotation


# virtual methods
.method public abstract getCaptionName()Ljava/lang/String;
.end method

.method public abstract getCaptionNameBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getIsDefault()Z
.end method

.method public abstract getLabel()Ljava/lang/String;
.end method

.method public abstract getLabelBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getLang()Ljava/lang/String;
.end method

.method public abstract getLangBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getSubtitleName()Ljava/lang/String;
.end method

.method public abstract getSubtitleNameBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getUrl()Ljava/lang/String;
.end method

.method public abstract getUrlBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract hasCaptionName()Z
.end method

.method public abstract hasLabel()Z
.end method
