# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackSession$DimensionOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "DimensionOrBuilder"
.end annotation


# virtual methods
.method public abstract getAvailScreenHeight()I
.end method

.method public abstract getAvailScreenWidth()I
.end method

.method public abstract getInnerWindowHeight()I
.end method

.method public abstract getInnerWindowWidth()I
.end method

.method public abstract getOuterWindowHeight()I
.end method

.method public abstract getOuterWindowWidth()I
.end method

.method public abstract getScreenHeight()I
.end method

.method public abstract getScreenWidth()I
.end method

.method public abstract getVideoHeight()I
.end method

.method public abstract getVideoWidth()I
.end method
