# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$WidevineCDM;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$WidevineCDMOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "WidevineCDM"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$WidevineCDM;",
        "Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$WidevineCDMOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

.field public static final DEVICEUNIQUEID_FIELD_NUMBER:I = 0x2

.field public static final DOWNGRADEDTOL3_FIELD_NUMBER:I = 0xa

.field public static final HDCPLEVEL_FIELD_NUMBER:I = 0x3

.field public static final MAXHDCPLEVEL_FIELD_NUMBER:I = 0x4

.field public static final MAXNUMBEROFSESSIONS_FIELD_NUMBER:I = 0x5

.field public static final NUMBEROFOPENSESSIONS_FIELD_NUMBER:I = 0x6

.field public static final OEMCRYPTOAPIVERSION_FIELD_NUMBER:I = 0x7

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$WidevineCDM;",
            ">;"
        }
    .end annotation
.end field

.field public static final SECURITYLEVEL_FIELD_NUMBER:I = 0x8

.field public static final SYSTEMID_FIELD_NUMBER:I = 0x9

.field public static final VERSION_FIELD_NUMBER:I = 0x1


# instance fields
.field private deviceUniqueId_:Ljava/lang/String;

.field private downgradedToL3_:Z

.field private hdcpLevel_:I

.field private maxHDCPLevel_:I

.field private maxNumberOfSessions_:I

.field private numberOfOpenSessions_:I

.field private oemCryptoApiVersion_:I

.field private securityLevel_:I

.field private systemId_:I

.field private version_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$mclearDeviceUniqueId(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->clearDeviceUniqueId()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearDowngradedToL3(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->clearDowngradedToL3()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearHdcpLevel(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->clearHdcpLevel()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMaxHDCPLevel(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->clearMaxHDCPLevel()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMaxNumberOfSessions(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->clearMaxNumberOfSessions()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearNumberOfOpenSessions(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->clearNumberOfOpenSessions()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearOemCryptoApiVersion(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->clearOemCryptoApiVersion()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSecurityLevel(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->clearSecurityLevel()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSystemId(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->clearSystemId()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearVersion(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->clearVersion()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDeviceUniqueId(Lcom/vdocipher/PlaybackSession$WidevineCDM;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->setDeviceUniqueId(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDeviceUniqueIdBytes(Lcom/vdocipher/PlaybackSession$WidevineCDM;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->setDeviceUniqueIdBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDowngradedToL3(Lcom/vdocipher/PlaybackSession$WidevineCDM;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->setDowngradedToL3(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetHdcpLevel(Lcom/vdocipher/PlaybackSession$WidevineCDM;Lcom/vdocipher/PlaybackSession$HDCPLevel;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->setHdcpLevel(Lcom/vdocipher/PlaybackSession$HDCPLevel;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetHdcpLevelValue(Lcom/vdocipher/PlaybackSession$WidevineCDM;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->setHdcpLevelValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMaxHDCPLevel(Lcom/vdocipher/PlaybackSession$WidevineCDM;Lcom/vdocipher/PlaybackSession$HDCPLevel;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->setMaxHDCPLevel(Lcom/vdocipher/PlaybackSession$HDCPLevel;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMaxHDCPLevelValue(Lcom/vdocipher/PlaybackSession$WidevineCDM;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->setMaxHDCPLevelValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMaxNumberOfSessions(Lcom/vdocipher/PlaybackSession$WidevineCDM;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->setMaxNumberOfSessions(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetNumberOfOpenSessions(Lcom/vdocipher/PlaybackSession$WidevineCDM;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->setNumberOfOpenSessions(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetOemCryptoApiVersion(Lcom/vdocipher/PlaybackSession$WidevineCDM;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->setOemCryptoApiVersion(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSecurityLevel(Lcom/vdocipher/PlaybackSession$WidevineCDM;Lcom/vdocipher/PlaybackSession$CdmLevel;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->setSecurityLevel(Lcom/vdocipher/PlaybackSession$CdmLevel;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSecurityLevelValue(Lcom/vdocipher/PlaybackSession$WidevineCDM;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->setSecurityLevelValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSystemId(Lcom/vdocipher/PlaybackSession$WidevineCDM;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->setSystemId(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVersion(Lcom/vdocipher/PlaybackSession$WidevineCDM;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->setVersion(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVersionBytes(Lcom/vdocipher/PlaybackSession$WidevineCDM;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->setVersionBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 11046
    new-instance v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;-><init>()V

    .line 11049
    sput-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    .line 11050
    const-class v1, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 10154
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 10155
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->version_:Ljava/lang/String;

    .line 10156
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->deviceUniqueId_:Ljava/lang/String;

    return-void
.end method

.method private clearDeviceUniqueId()V
    .registers 2

    .line 10239
    invoke-static {}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$WidevineCDM;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getDeviceUniqueId()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->deviceUniqueId_:Ljava/lang/String;

    return-void
.end method

.method private clearDowngradedToL3()V
    .registers 2

    const/4 v0, 0x0

    .line 10505
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->downgradedToL3_:Z

    return-void
.end method

.method private clearHdcpLevel()V
    .registers 2

    const/4 v0, 0x0

    .line 10291
    iput v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->hdcpLevel_:I

    return-void
.end method

.method private clearMaxHDCPLevel()V
    .registers 2

    const/4 v0, 0x0

    .line 10333
    iput v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->maxHDCPLevel_:I

    return-void
.end method

.method private clearMaxNumberOfSessions()V
    .registers 2

    const/4 v0, 0x0

    .line 10359
    iput v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->maxNumberOfSessions_:I

    return-void
.end method

.method private clearNumberOfOpenSessions()V
    .registers 2

    const/4 v0, 0x0

    .line 10385
    iput v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->numberOfOpenSessions_:I

    return-void
.end method

.method private clearOemCryptoApiVersion()V
    .registers 2

    const/4 v0, 0x0

    .line 10411
    iput v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->oemCryptoApiVersion_:I

    return-void
.end method

.method private clearSecurityLevel()V
    .registers 2

    const/4 v0, 0x0

    .line 10453
    iput v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->securityLevel_:I

    return-void
.end method

.method private clearSystemId()V
    .registers 2

    const/4 v0, 0x0

    .line 10479
    iput v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->systemId_:I

    return-void
.end method

.method private clearVersion()V
    .registers 2

    .line 10192
    invoke-static {}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$WidevineCDM;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getVersion()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->version_:Ljava/lang/String;

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 1

    .line 11055
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 1

    .line 10585
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$WidevineCDM;)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 2

    .line 10588
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10561
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10568
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10524
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10531
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10573
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10580
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10548
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10555
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10511
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10518
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10536
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$WidevineCDM;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10543
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$WidevineCDM;",
            ">;"
        }
    .end annotation

    .line 11061
    sget-object v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setDeviceUniqueId(Ljava/lang/String;)V
    .registers 2

    .line 10230
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10232
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->deviceUniqueId_:Ljava/lang/String;

    return-void
.end method

.method private setDeviceUniqueIdBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 10247
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 10248
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->deviceUniqueId_:Ljava/lang/String;

    return-void
.end method

.method private setDowngradedToL3(Z)V
    .registers 2

    .line 10498
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->downgradedToL3_:Z

    return-void
.end method

.method private setHdcpLevel(Lcom/vdocipher/PlaybackSession$HDCPLevel;)V
    .registers 2

    .line 10283
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$HDCPLevel;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->hdcpLevel_:I

    return-void
.end method

.method private setHdcpLevelValue(I)V
    .registers 2

    .line 10276
    iput p1, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->hdcpLevel_:I

    return-void
.end method

.method private setMaxHDCPLevel(Lcom/vdocipher/PlaybackSession$HDCPLevel;)V
    .registers 2

    .line 10325
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$HDCPLevel;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->maxHDCPLevel_:I

    return-void
.end method

.method private setMaxHDCPLevelValue(I)V
    .registers 2

    .line 10318
    iput p1, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->maxHDCPLevel_:I

    return-void
.end method

.method private setMaxNumberOfSessions(I)V
    .registers 2

    .line 10352
    iput p1, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->maxNumberOfSessions_:I

    return-void
.end method

.method private setNumberOfOpenSessions(I)V
    .registers 2

    .line 10378
    iput p1, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->numberOfOpenSessions_:I

    return-void
.end method

.method private setOemCryptoApiVersion(I)V
    .registers 2

    .line 10404
    iput p1, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->oemCryptoApiVersion_:I

    return-void
.end method

.method private setSecurityLevel(Lcom/vdocipher/PlaybackSession$CdmLevel;)V
    .registers 2

    .line 10445
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$CdmLevel;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->securityLevel_:I

    return-void
.end method

.method private setSecurityLevelValue(I)V
    .registers 2

    .line 10438
    iput p1, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->securityLevel_:I

    return-void
.end method

.method private setSystemId(I)V
    .registers 2

    .line 10472
    iput p1, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->systemId_:I

    return-void
.end method

.method private setVersion(Ljava/lang/String;)V
    .registers 2

    .line 10183
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10185
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->version_:Ljava/lang/String;

    return-void
.end method

.method private setVersionBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 10200
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 10201
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->version_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 14

    .line 10988
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_66

    .line 11039
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 11033
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 11018
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$WidevineCDM;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_33

    .line 11020
    const-class p2, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    monitor-enter p2

    .line 11021
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$WidevineCDM;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 11023
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 11026
    sput-object p1, Lcom/vdocipher/PlaybackSession$WidevineCDM;->PARSER:Lcom/google/protobuf/Parser;

    .line 11028
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception v0

    move-object p1, v0

    monitor-exit p2
    :try_end_32
    .catchall {:try_start_20 .. :try_end_32} :catchall_2f

    throw p1

    :cond_33
    return-object p1

    .line 11015
    :pswitch_34  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    return-object p1

    .line 10996
    :pswitch_37  #0x3
    const-string/jumbo v0, "version_"

    const-string v1, "deviceUniqueId_"

    const-string v2, "hdcpLevel_"

    const-string v3, "maxHDCPLevel_"

    const-string v4, "maxNumberOfSessions_"

    const-string v5, "numberOfOpenSessions_"

    const-string v6, "oemCryptoApiVersion_"

    const-string v7, "securityLevel_"

    const-string/jumbo v8, "systemId_"

    const-string v9, "downgradedToL3_"

    filled-new-array/range {v0 .. v9}, [Ljava/lang/Object;

    move-result-object p1

    .line 11008
    const-string p2, "\u0000\n\u0000\u0000\u0001\n\n\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003\f\u0004\f\u0005\u000b\u0006\u000b\u0007\u000b\b\f\t\u000b\n\u0007"

    .line 11011
    sget-object p3, Lcom/vdocipher/PlaybackSession$WidevineCDM;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 10993
    :pswitch_5a  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 10990
    :pswitch_60  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;-><init>()V

    return-object p1

    :pswitch_data_66
    .packed-switch 0x1
        :pswitch_60  #00000001
        :pswitch_5a  #00000002
        :pswitch_37  #00000003
        :pswitch_34  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getDeviceUniqueId()Ljava/lang/String;
    .registers 2

    .line 10213
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->deviceUniqueId_:Ljava/lang/String;

    return-object v0
.end method

.method public getDeviceUniqueIdBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 10222
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->deviceUniqueId_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getDowngradedToL3()Z
    .registers 2

    .line 10490
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->downgradedToL3_:Z

    return v0
.end method

.method public getHdcpLevel()Lcom/vdocipher/PlaybackSession$HDCPLevel;
    .registers 2

    .line 10268
    iget v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->hdcpLevel_:I

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$HDCPLevel;->forNumber(I)Lcom/vdocipher/PlaybackSession$HDCPLevel;

    move-result-object v0

    if-nez v0, :cond_a

    .line 10269
    sget-object v0, Lcom/vdocipher/PlaybackSession$HDCPLevel;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$HDCPLevel;

    :cond_a
    return-object v0
.end method

.method public getHdcpLevelValue()I
    .registers 2

    .line 10260
    iget v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->hdcpLevel_:I

    return v0
.end method

.method public getMaxHDCPLevel()Lcom/vdocipher/PlaybackSession$HDCPLevel;
    .registers 2

    .line 10310
    iget v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->maxHDCPLevel_:I

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$HDCPLevel;->forNumber(I)Lcom/vdocipher/PlaybackSession$HDCPLevel;

    move-result-object v0

    if-nez v0, :cond_a

    .line 10311
    sget-object v0, Lcom/vdocipher/PlaybackSession$HDCPLevel;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$HDCPLevel;

    :cond_a
    return-object v0
.end method

.method public getMaxHDCPLevelValue()I
    .registers 2

    .line 10302
    iget v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->maxHDCPLevel_:I

    return v0
.end method

.method public getMaxNumberOfSessions()I
    .registers 2

    .line 10344
    iget v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->maxNumberOfSessions_:I

    return v0
.end method

.method public getNumberOfOpenSessions()I
    .registers 2

    .line 10370
    iget v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->numberOfOpenSessions_:I

    return v0
.end method

.method public getOemCryptoApiVersion()I
    .registers 2

    .line 10396
    iget v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->oemCryptoApiVersion_:I

    return v0
.end method

.method public getSecurityLevel()Lcom/vdocipher/PlaybackSession$CdmLevel;
    .registers 2

    .line 10430
    iget v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->securityLevel_:I

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$CdmLevel;->forNumber(I)Lcom/vdocipher/PlaybackSession$CdmLevel;

    move-result-object v0

    if-nez v0, :cond_a

    .line 10431
    sget-object v0, Lcom/vdocipher/PlaybackSession$CdmLevel;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$CdmLevel;

    :cond_a
    return-object v0
.end method

.method public getSecurityLevelValue()I
    .registers 2

    .line 10422
    iget v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->securityLevel_:I

    return v0
.end method

.method public getSystemId()I
    .registers 2

    .line 10464
    iget v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->systemId_:I

    return v0
.end method

.method public getVersion()Ljava/lang/String;
    .registers 2

    .line 10166
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->version_:Ljava/lang/String;

    return-object v0
.end method

.method public getVersionBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 10175
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM;->version_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method
