# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$Chapters;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$ChaptersOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Chapters"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$Chapters$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackInfo$Chapters;",
        "Lcom/vdocipher/PlaybackInfo$Chapters$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$ChaptersOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

.field public static final ID_FIELD_NUMBER:I = 0x3

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$Chapters;",
            ">;"
        }
    .end annotation
.end field

.field public static final STARTTIME_FIELD_NUMBER:I = 0x2

.field public static final TITLE_FIELD_NUMBER:I = 0x1


# instance fields
.field private id_:Lcom/google/protobuf/ByteString;

.field private startTime_:I

.field private title_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$mclearId(Lcom/vdocipher/PlaybackInfo$Chapters;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Chapters;->clearId()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearStartTime(Lcom/vdocipher/PlaybackInfo$Chapters;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Chapters;->clearStartTime()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearTitle(Lcom/vdocipher/PlaybackInfo$Chapters;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$Chapters;->clearTitle()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetId(Lcom/vdocipher/PlaybackInfo$Chapters;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Chapters;->setId(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetStartTime(Lcom/vdocipher/PlaybackInfo$Chapters;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Chapters;->setStartTime(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTitle(Lcom/vdocipher/PlaybackInfo$Chapters;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Chapters;->setTitle(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTitleBytes(Lcom/vdocipher/PlaybackInfo$Chapters;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$Chapters;->setTitleBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 9939
    new-instance v0, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$Chapters;-><init>()V

    .line 9942
    sput-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    .line 9943
    const-class v1, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 9575
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 9576
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters;->title_:Ljava/lang/String;

    .line 9577
    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters;->id_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private clearId()V
    .registers 2

    .line 9676
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Chapters;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$Chapters;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Chapters;->getId()Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters;->id_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private clearStartTime()V
    .registers 2

    const/4 v0, 0x0

    .line 9649
    iput v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters;->startTime_:I

    return-void
.end method

.method private clearTitle()V
    .registers 2

    .line 9613
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Chapters;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$Chapters;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Chapters;->getTitle()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters;->title_:Ljava/lang/String;

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 1

    .line 9948
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackInfo$Chapters$Builder;
    .registers 1

    .line 9756
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Chapters;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackInfo$Chapters;)Lcom/vdocipher/PlaybackInfo$Chapters$Builder;
    .registers 2

    .line 9759
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$Chapters;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9732
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackInfo$Chapters;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9739
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackInfo$Chapters;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9695
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9702
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9744
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9751
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9719
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9726
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9682
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9689
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9707
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9714
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$Chapters;",
            ">;"
        }
    .end annotation

    .line 9954
    sget-object v0, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$Chapters;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setId(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 9667
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9669
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Chapters;->id_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private setStartTime(I)V
    .registers 2

    .line 9642
    iput p1, p0, Lcom/vdocipher/PlaybackInfo$Chapters;->startTime_:I

    return-void
.end method

.method private setTitle(Ljava/lang/String;)V
    .registers 2

    .line 9604
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9606
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Chapters;->title_:Ljava/lang/String;

    return-void
.end method

.method private setTitleBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 9621
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$Chapters;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 9622
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$Chapters;->title_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 9888
    sget-object p2, Lcom/vdocipher/PlaybackInfo$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_58

    .line 9932
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 9926
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 9911
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackInfo$Chapters;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 9913
    const-class p2, Lcom/vdocipher/PlaybackInfo$Chapters;

    monitor-enter p2

    .line 9914
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackInfo$Chapters;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 9916
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 9919
    sput-object p1, Lcom/vdocipher/PlaybackInfo$Chapters;->PARSER:Lcom/google/protobuf/Parser;

    .line 9921
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 9908
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object p1

    .line 9896
    :pswitch_36  #0x3
    const-string/jumbo p1, "title_"

    const-string/jumbo p2, "startTime_"

    const-string p3, "id_"

    filled-new-array {p1, p2, p3}, [Ljava/lang/Object;

    move-result-object p1

    .line 9901
    const-string p2, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002\u000b\u0003\n"

    .line 9904
    sget-object p3, Lcom/vdocipher/PlaybackInfo$Chapters;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackInfo$Chapters;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 9893
    :pswitch_4b  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;-><init>(Lcom/vdocipher/PlaybackInfo-IA;)V

    return-object p1

    .line 9890
    :pswitch_51  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackInfo$Chapters;-><init>()V

    return-object p1

    nop

    :pswitch_data_58
    .packed-switch 0x1
        :pswitch_51  #00000001
        :pswitch_4b  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getId()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9660
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters;->id_:Lcom/google/protobuf/ByteString;

    return-object v0
.end method

.method public getStartTime()I
    .registers 2

    .line 9634
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters;->startTime_:I

    return v0
.end method

.method public getTitle()Ljava/lang/String;
    .registers 2

    .line 9587
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters;->title_:Ljava/lang/String;

    return-object v0
.end method

.method public getTitleBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9596
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$Chapters;->title_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method
