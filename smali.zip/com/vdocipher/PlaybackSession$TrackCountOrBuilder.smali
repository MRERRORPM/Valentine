# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackSession$TrackCountOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "TrackCountOrBuilder"
.end annotation


# virtual methods
.method public abstract getVideo()I
.end method
