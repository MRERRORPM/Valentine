# classes14.dex

.class public final synthetic Lcom/vdocipher/Manifest-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
