# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$MetadataTable;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$MetadataTableOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "MetadataTable"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackInfo$MetadataTable;",
        "Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$MetadataTableOrBuilder;"
    }
.end annotation


# static fields
.field public static final ALTHOSTS_FIELD_NUMBER:I = 0x19

.field public static final ASPECTRATIO_FIELD_NUMBER:I = 0x4

.field public static final AUDIOONLY_FIELD_NUMBER:I = 0x8

.field public static final CANSKIPINTEGRITYCHECK_FIELD_NUMBER:I = 0x15

.field public static final CAPTIONS_FIELD_NUMBER:I = 0xd

.field public static final CBCS_FIELD_NUMBER:I = 0x10

.field public static final CHAPTERS_FIELD_NUMBER:I = 0x14

.field public static final CTAS_FIELD_NUMBER:I = 0x1a

.field public static final DASH_FIELD_NUMBER:I = 0xf

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

.field public static final DESCRIPTION_FIELD_NUMBER:I = 0x2

.field public static final DESIREDBITRATE_FIELD_NUMBER:I = 0xb

.field public static final DURATION_FIELD_NUMBER:I = 0x3

.field public static final EMBEDURL_FIELD_NUMBER:I = 0x6

.field public static final ERRORMSGS_FIELD_NUMBER:I = 0x17

.field public static final FPS_FIELD_NUMBER:I = 0xe

.field public static final H6_FIELD_NUMBER:I = 0x11

.field public static final HOSTNAMES_FIELD_NUMBER:I = 0x5

.field public static final INTEGRITYCLOUDID_FIELD_NUMBER:I = 0x12

.field public static final LANGUAGE_FIELD_NUMBER:I = 0x16

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$MetadataTable;",
            ">;"
        }
    .end annotation
.end field

.field public static final PLAYERCONFIG_FIELD_NUMBER:I = 0xc

.field public static final POSTERS_FIELD_NUMBER:I = 0xa

.field public static final SCRUBBINGPREVIEWURL_FIELD_NUMBER:I = 0x18

.field public static final TECH_FIELD_NUMBER:I = 0x7

.field public static final TITLE_FIELD_NUMBER:I = 0x1

.field public static final VDOCIPHERBRANDING_FIELD_NUMBER:I = 0x13

.field public static final VERSION_FIELD_NUMBER:I = 0x1b

.field public static final WHITELISTHREF_FIELD_NUMBER:I = 0x9

.field private static final tech_converter_:Lcom/google/protobuf/Internal$ListAdapter$Converter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ListAdapter$Converter<",
            "Ljava/lang/Integer;",
            "Lcom/vdocipher/PlaybackInfo$TechOptions;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private altHosts_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private aspectRatio_:F

.field private audioOnly_:Z

.field private bitField0_:I

.field private canSkipIntegrityCheck_:Z

.field private captions_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/PlaybackInfo$Captions;",
            ">;"
        }
    .end annotation
.end field

.field private cbcs_:Lcom/vdocipher/PlaybackInfo$CBCSI;

.field private chapters_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/PlaybackInfo$Chapters;",
            ">;"
        }
    .end annotation
.end field

.field private ctas_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/PlaybackInfo$Cta;",
            ">;"
        }
    .end annotation
.end field

.field private dash_:Lcom/vdocipher/PlaybackInfo$DASH;

.field private description_:Ljava/lang/String;

.field private desiredBitrate_:I

.field private duration_:I

.field private embedUrl_:Ljava/lang/String;

.field private errorMsgs_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/PlaybackInfo$ErrorMessage;",
            ">;"
        }
    .end annotation
.end field

.field private fps_:Lcom/vdocipher/PlaybackInfo$FPS;

.field private h6_:Lcom/vdocipher/PlaybackInfo$H6;

.field private hostnames_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private integrityCloudId_:Ljava/lang/String;

.field private language_:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

.field private playerConfig_:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

.field private posters_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/PlaybackInfo$Posters;",
            ">;"
        }
    .end annotation
.end field

.field private scrubbingPreviewUrl_:Ljava/lang/String;

.field private techMemoizedSerializedSize:I

.field private tech_:Lcom/google/protobuf/Internal$IntList;

.field private title_:Ljava/lang/String;

.field private vdocipherBranding_:Z

.field private version_:Ljava/lang/String;

.field private whitelistHref_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$maddAllAltHosts(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addAllAltHosts(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllCaptions(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addAllCaptions(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllChapters(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addAllChapters(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllCtas(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addAllCtas(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllErrorMsgs(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addAllErrorMsgs(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllHostnames(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addAllHostnames(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllPosters(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addAllPosters(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllTech(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addAllTech(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllTechValue(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addAllTechValue(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAltHosts(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addAltHosts(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAltHostsBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addAltHostsBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddCaptions(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Captions;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addCaptions(ILcom/vdocipher/PlaybackInfo$Captions;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddCaptions(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$Captions;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addCaptions(Lcom/vdocipher/PlaybackInfo$Captions;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddChapters(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Chapters;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addChapters(ILcom/vdocipher/PlaybackInfo$Chapters;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddChapters(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$Chapters;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addChapters(Lcom/vdocipher/PlaybackInfo$Chapters;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddCtas(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Cta;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addCtas(ILcom/vdocipher/PlaybackInfo$Cta;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddCtas(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$Cta;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addCtas(Lcom/vdocipher/PlaybackInfo$Cta;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddErrorMsgs(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$ErrorMessage;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addErrorMsgs(ILcom/vdocipher/PlaybackInfo$ErrorMessage;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddErrorMsgs(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$ErrorMessage;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addErrorMsgs(Lcom/vdocipher/PlaybackInfo$ErrorMessage;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddHostnames(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addHostnames(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddHostnamesBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addHostnamesBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddPosters(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Posters;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addPosters(ILcom/vdocipher/PlaybackInfo$Posters;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddPosters(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$Posters;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addPosters(Lcom/vdocipher/PlaybackInfo$Posters;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddTech(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$TechOptions;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addTech(Lcom/vdocipher/PlaybackInfo$TechOptions;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddTechValue(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->addTechValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearAltHosts(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearAltHosts()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearAspectRatio(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearAspectRatio()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearAudioOnly(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearAudioOnly()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearCanSkipIntegrityCheck(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearCanSkipIntegrityCheck()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearCaptions(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearCaptions()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearCbcs(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearCbcs()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearChapters(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearChapters()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearCtas(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearCtas()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearDash(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearDash()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearDescription(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearDescription()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearDesiredBitrate(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearDesiredBitrate()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearDuration(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearDuration()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEmbedUrl(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearEmbedUrl()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearErrorMsgs(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearErrorMsgs()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearFps(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearFps()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearH6(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearH6()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearHostnames(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearHostnames()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearIntegrityCloudId(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearIntegrityCloudId()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLanguage(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearLanguage()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPlayerConfig(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearPlayerConfig()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPosters(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearPosters()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearScrubbingPreviewUrl(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearScrubbingPreviewUrl()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearTech(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearTech()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearTitle(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearTitle()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearVdocipherBranding(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearVdocipherBranding()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearVersion(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearVersion()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearWhitelistHref(Lcom/vdocipher/PlaybackInfo$MetadataTable;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->clearWhitelistHref()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeCbcs(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$CBCSI;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->mergeCbcs(Lcom/vdocipher/PlaybackInfo$CBCSI;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeDash(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$DASH;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->mergeDash(Lcom/vdocipher/PlaybackInfo$DASH;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeFps(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$FPS;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->mergeFps(Lcom/vdocipher/PlaybackInfo$FPS;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeH6(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$H6;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->mergeH6(Lcom/vdocipher/PlaybackInfo$H6;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeLanguage(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->mergeLanguage(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergePlayerConfig(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$PlayerConfig;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->mergePlayerConfig(Lcom/vdocipher/PlaybackInfo$PlayerConfig;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveCaptions(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->removeCaptions(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveChapters(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->removeChapters(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveCtas(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->removeCtas(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveErrorMsgs(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->removeErrorMsgs(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremovePosters(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->removePosters(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAltHosts(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILjava/lang/String;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setAltHosts(ILjava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAspectRatio(Lcom/vdocipher/PlaybackInfo$MetadataTable;F)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setAspectRatio(F)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAudioOnly(Lcom/vdocipher/PlaybackInfo$MetadataTable;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setAudioOnly(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCanSkipIntegrityCheck(Lcom/vdocipher/PlaybackInfo$MetadataTable;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setCanSkipIntegrityCheck(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCaptions(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Captions;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setCaptions(ILcom/vdocipher/PlaybackInfo$Captions;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCbcs(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$CBCSI;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setCbcs(Lcom/vdocipher/PlaybackInfo$CBCSI;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetChapters(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Chapters;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setChapters(ILcom/vdocipher/PlaybackInfo$Chapters;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCtas(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Cta;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setCtas(ILcom/vdocipher/PlaybackInfo$Cta;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDash(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$DASH;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setDash(Lcom/vdocipher/PlaybackInfo$DASH;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDescription(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setDescription(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDescriptionBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setDescriptionBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDesiredBitrate(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setDesiredBitrate(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDuration(Lcom/vdocipher/PlaybackInfo$MetadataTable;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setDuration(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEmbedUrl(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setEmbedUrl(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEmbedUrlBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setEmbedUrlBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetErrorMsgs(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$ErrorMessage;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setErrorMsgs(ILcom/vdocipher/PlaybackInfo$ErrorMessage;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetFps(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$FPS;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setFps(Lcom/vdocipher/PlaybackInfo$FPS;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetH6(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$H6;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setH6(Lcom/vdocipher/PlaybackInfo$H6;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetHostnames(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILjava/lang/String;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setHostnames(ILjava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIntegrityCloudId(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setIntegrityCloudId(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIntegrityCloudIdBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setIntegrityCloudIdBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLanguage(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setLanguage(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPlayerConfig(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/vdocipher/PlaybackInfo$PlayerConfig;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setPlayerConfig(Lcom/vdocipher/PlaybackInfo$PlayerConfig;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPosters(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$Posters;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setPosters(ILcom/vdocipher/PlaybackInfo$Posters;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetScrubbingPreviewUrl(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setScrubbingPreviewUrl(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetScrubbingPreviewUrlBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setScrubbingPreviewUrlBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTech(Lcom/vdocipher/PlaybackInfo$MetadataTable;ILcom/vdocipher/PlaybackInfo$TechOptions;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setTech(ILcom/vdocipher/PlaybackInfo$TechOptions;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTechValue(Lcom/vdocipher/PlaybackInfo$MetadataTable;II)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setTechValue(II)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTitle(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setTitle(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTitleBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setTitleBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVdocipherBranding(Lcom/vdocipher/PlaybackInfo$MetadataTable;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setVdocipherBranding(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVersion(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setVersion(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVersionBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setVersionBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetWhitelistHref(Lcom/vdocipher/PlaybackInfo$MetadataTable;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setWhitelistHref(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetWhitelistHrefBytes(Lcom/vdocipher/PlaybackInfo$MetadataTable;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->setWhitelistHrefBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$MetadataTable;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 12331
    new-instance v0, Lcom/vdocipher/PlaybackInfo$MetadataTable$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_converter_:Lcom/google/protobuf/Internal$ListAdapter$Converter;

    .line 15464
    new-instance v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;-><init>()V

    .line 15467
    sput-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    .line 15468
    const-class v1, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 3

    .line 12024
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 12025
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->title_:Ljava/lang/String;

    .line 12026
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->description_:Ljava/lang/String;

    .line 12027
    invoke-static {}, Lcom/google/protobuf/GeneratedMessageLite;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v1

    iput-object v1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hostnames_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 12028
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->embedUrl_:Ljava/lang/String;

    .line 12029
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->emptyIntList()Lcom/google/protobuf/Internal$IntList;

    move-result-object v1

    iput-object v1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_:Lcom/google/protobuf/Internal$IntList;

    .line 12030
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->whitelistHref_:Ljava/lang/String;

    .line 12031
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v1

    iput-object v1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->posters_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 12032
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v1

    iput-object v1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->captions_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 12033
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->integrityCloudId_:Ljava/lang/String;

    .line 12034
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v1

    iput-object v1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->chapters_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 12035
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v1

    iput-object v1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->errorMsgs_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 12036
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->scrubbingPreviewUrl_:Ljava/lang/String;

    .line 12037
    invoke-static {}, Lcom/google/protobuf/GeneratedMessageLite;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v1

    iput-object v1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->altHosts_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 12038
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v1

    iput-object v1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ctas_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 12039
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->version_:Ljava/lang/String;

    return-void
.end method

.method private addAllAltHosts(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 13468
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureAltHostsIsMutable()V

    .line 13469
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->altHosts_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAllCaptions(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$Captions;",
            ">;)V"
        }
    .end annotation

    .line 12790
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureCaptionsIsMutable()V

    .line 12791
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->captions_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAllChapters(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$Chapters;",
            ">;)V"
        }
    .end annotation

    .line 13149
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureChaptersIsMutable()V

    .line 13150
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->chapters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAllCtas(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$Cta;",
            ">;)V"
        }
    .end annotation

    .line 13565
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureCtasIsMutable()V

    .line 13566
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ctas_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAllErrorMsgs(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$ErrorMessage;",
            ">;)V"
        }
    .end annotation

    .line 13323
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureErrorMsgsIsMutable()V

    .line 13324
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->errorMsgs_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAllHostnames(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 12260
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureHostnamesIsMutable()V

    .line 12261
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hostnames_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAllPosters(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$Posters;",
            ">;)V"
        }
    .end annotation

    .line 12616
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensurePostersIsMutable()V

    .line 12617
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->posters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAllTech(Ljava/lang/Iterable;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$TechOptions;",
            ">;)V"
        }
    .end annotation

    .line 12419
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureTechIsMutable()V

    .line 12420
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_7
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1d

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$TechOptions;

    .line 12421
    iget-object v1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_:Lcom/google/protobuf/Internal$IntList;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$TechOptions;->getNumber()I

    move-result v0

    invoke-interface {v1, v0}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    goto :goto_7

    :cond_1d
    return-void
.end method

.method private addAllTechValue(Ljava/lang/Iterable;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .line 12453
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureTechIsMutable()V

    .line 12454
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_7
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1d

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 12455
    iget-object v1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v1, v0}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    goto :goto_7

    :cond_1d
    return-void
.end method

.method private addAltHosts(Ljava/lang/String;)V
    .registers 3

    .line 13458
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13459
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureAltHostsIsMutable()V

    .line 13460
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->altHosts_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addAltHostsBytes(Lcom/google/protobuf/ByteString;)V
    .registers 3

    .line 13484
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 13485
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureAltHostsIsMutable()V

    .line 13486
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->altHosts_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addCaptions(ILcom/vdocipher/PlaybackInfo$Captions;)V
    .registers 4

    .line 12781
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12782
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureCaptionsIsMutable()V

    .line 12783
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->captions_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addCaptions(Lcom/vdocipher/PlaybackInfo$Captions;)V
    .registers 3

    .line 12772
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12773
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureCaptionsIsMutable()V

    .line 12774
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->captions_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addChapters(ILcom/vdocipher/PlaybackInfo$Chapters;)V
    .registers 4

    .line 13140
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13141
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureChaptersIsMutable()V

    .line 13142
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->chapters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addChapters(Lcom/vdocipher/PlaybackInfo$Chapters;)V
    .registers 3

    .line 13131
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13132
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureChaptersIsMutable()V

    .line 13133
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->chapters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addCtas(ILcom/vdocipher/PlaybackInfo$Cta;)V
    .registers 4

    .line 13556
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13557
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureCtasIsMutable()V

    .line 13558
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ctas_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addCtas(Lcom/vdocipher/PlaybackInfo$Cta;)V
    .registers 3

    .line 13547
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13548
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureCtasIsMutable()V

    .line 13549
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ctas_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addErrorMsgs(ILcom/vdocipher/PlaybackInfo$ErrorMessage;)V
    .registers 4

    .line 13314
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13315
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureErrorMsgsIsMutable()V

    .line 13316
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->errorMsgs_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addErrorMsgs(Lcom/vdocipher/PlaybackInfo$ErrorMessage;)V
    .registers 3

    .line 13305
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13306
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureErrorMsgsIsMutable()V

    .line 13307
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->errorMsgs_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addHostnames(Ljava/lang/String;)V
    .registers 3

    .line 12250
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12251
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureHostnamesIsMutable()V

    .line 12252
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hostnames_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addHostnamesBytes(Lcom/google/protobuf/ByteString;)V
    .registers 3

    .line 12276
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 12277
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureHostnamesIsMutable()V

    .line 12278
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hostnames_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addPosters(ILcom/vdocipher/PlaybackInfo$Posters;)V
    .registers 4

    .line 12607
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12608
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensurePostersIsMutable()V

    .line 12609
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->posters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addPosters(Lcom/vdocipher/PlaybackInfo$Posters;)V
    .registers 3

    .line 12598
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12599
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensurePostersIsMutable()V

    .line 12600
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->posters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addTech(Lcom/vdocipher/PlaybackInfo$TechOptions;)V
    .registers 3

    .line 12409
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12410
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureTechIsMutable()V

    .line 12411
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_:Lcom/google/protobuf/Internal$IntList;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$TechOptions;->getNumber()I

    move-result p1

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    return-void
.end method

.method private addTechValue(I)V
    .registers 3

    .line 12444
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureTechIsMutable()V

    .line 12445
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    return-void
.end method

.method private clearAltHosts()V
    .registers 2

    .line 13476
    invoke-static {}, Lcom/google/protobuf/GeneratedMessageLite;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->altHosts_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearAspectRatio()V
    .registers 2

    const/4 v0, 0x0

    .line 12185
    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->aspectRatio_:F

    return-void
.end method

.method private clearAudioOnly()V
    .registers 2

    const/4 v0, 0x0

    .line 12482
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->audioOnly_:Z

    return-void
.end method

.method private clearCanSkipIntegrityCheck()V
    .registers 2

    .line 13197
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit16 v0, v0, -0x101

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    const/4 v0, 0x0

    .line 13198
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->canSkipIntegrityCheck_:Z

    return-void
.end method

.method private clearCaptions()V
    .registers 2

    .line 12798
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->captions_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearCbcs()V
    .registers 2

    const/4 v0, 0x0

    .line 12942
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->cbcs_:Lcom/vdocipher/PlaybackInfo$CBCSI;

    .line 12943
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x21

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private clearChapters()V
    .registers 2

    .line 13157
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->chapters_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearCtas()V
    .registers 2

    .line 13573
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ctas_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearDash()V
    .registers 2

    const/4 v0, 0x0

    .line 12896
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->dash_:Lcom/vdocipher/PlaybackInfo$DASH;

    .line 12897
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x11

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private clearDescription()V
    .registers 2

    .line 12123
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$MetadataTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDescription()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->description_:Ljava/lang/String;

    return-void
.end method

.method private clearDesiredBitrate()V
    .registers 2

    .line 12664
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x3

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    const/4 v0, 0x0

    .line 12665
    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->desiredBitrate_:I

    return-void
.end method

.method private clearDuration()V
    .registers 2

    const/4 v0, 0x0

    .line 12159
    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->duration_:I

    return-void
.end method

.method private clearEmbedUrl()V
    .registers 2

    .line 12315
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$MetadataTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getEmbedUrl()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->embedUrl_:Ljava/lang/String;

    return-void
.end method

.method private clearErrorMsgs()V
    .registers 2

    .line 13331
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->errorMsgs_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearFps()V
    .registers 2

    const/4 v0, 0x0

    .line 12850
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->fps_:Lcom/vdocipher/PlaybackInfo$FPS;

    .line 12851
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x9

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private clearH6()V
    .registers 2

    const/4 v0, 0x0

    .line 12988
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->h6_:Lcom/vdocipher/PlaybackInfo$H6;

    .line 12989
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x41

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private clearHostnames()V
    .registers 2

    .line 12268
    invoke-static {}, Lcom/google/protobuf/GeneratedMessageLite;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hostnames_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearIntegrityCloudId()V
    .registers 2

    .line 13033
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit16 v0, v0, -0x81

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    .line 13034
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$MetadataTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getIntegrityCloudId()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->integrityCloudId_:Ljava/lang/String;

    return-void
.end method

.method private clearLanguage()V
    .registers 2

    const/4 v0, 0x0

    .line 13243
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->language_:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    .line 13244
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit16 v0, v0, -0x201

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private clearPlayerConfig()V
    .registers 2

    const/4 v0, 0x0

    .line 12710
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->playerConfig_:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    .line 12711
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x5

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private clearPosters()V
    .registers 2

    .line 12624
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->posters_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearScrubbingPreviewUrl()V
    .registers 2

    .line 13382
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit16 v0, v0, -0x401

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    .line 13383
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$MetadataTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getScrubbingPreviewUrl()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->scrubbingPreviewUrl_:Ljava/lang/String;

    return-void
.end method

.method private clearTech()V
    .registers 2

    .line 12428
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->emptyIntList()Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_:Lcom/google/protobuf/Internal$IntList;

    return-void
.end method

.method private clearTitle()V
    .registers 2

    .line 12076
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$MetadataTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getTitle()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->title_:Ljava/lang/String;

    return-void
.end method

.method private clearVdocipherBranding()V
    .registers 2

    const/4 v0, 0x0

    .line 13070
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->vdocipherBranding_:Z

    return-void
.end method

.method private clearVersion()V
    .registers 2

    .line 13617
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$MetadataTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getVersion()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->version_:Ljava/lang/String;

    return-void
.end method

.method private clearWhitelistHref()V
    .registers 2

    .line 12526
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit8 v0, v0, -0x2

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    .line 12527
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$MetadataTable;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getWhitelistHref()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->whitelistHref_:Ljava/lang/String;

    return-void
.end method

.method private ensureAltHostsIsMutable()V
    .registers 3

    .line 13435
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->altHosts_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 13436
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 13438
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->altHosts_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method private ensureCaptionsIsMutable()V
    .registers 3

    .line 12752
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->captions_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 12753
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 12755
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->captions_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method private ensureChaptersIsMutable()V
    .registers 3

    .line 13111
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->chapters_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 13112
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 13114
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->chapters_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method private ensureCtasIsMutable()V
    .registers 3

    .line 13527
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ctas_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 13528
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 13530
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ctas_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method private ensureErrorMsgsIsMutable()V
    .registers 3

    .line 13285
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->errorMsgs_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 13286
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 13288
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->errorMsgs_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method private ensureHostnamesIsMutable()V
    .registers 3

    .line 12227
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hostnames_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 12228
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 12230
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hostnames_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method private ensurePostersIsMutable()V
    .registers 3

    .line 12578
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->posters_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 12579
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 12581
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->posters_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method private ensureTechIsMutable()V
    .registers 3

    .line 12387
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_:Lcom/google/protobuf/Internal$IntList;

    .line 12388
    invoke-interface {v0}, Lcom/google/protobuf/Internal$IntList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 12390
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$IntList;)Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_:Lcom/google/protobuf/Internal$IntList;

    :cond_e
    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackInfo$MetadataTable;
    .registers 1

    .line 15473
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object v0
.end method

.method private mergeCbcs(Lcom/vdocipher/PlaybackInfo$CBCSI;)V
    .registers 4

    .line 12929
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12930
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->cbcs_:Lcom/vdocipher/PlaybackInfo$CBCSI;

    if-eqz v0, :cond_22

    .line 12931
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$CBCSI;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 12932
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->cbcs_:Lcom/vdocipher/PlaybackInfo$CBCSI;

    .line 12933
    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$CBCSI;->newBuilder(Lcom/vdocipher/PlaybackInfo$CBCSI;)Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$CBCSI$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$CBCSI;

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->cbcs_:Lcom/vdocipher/PlaybackInfo$CBCSI;

    goto :goto_24

    .line 12935
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->cbcs_:Lcom/vdocipher/PlaybackInfo$CBCSI;

    .line 12937
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x20

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private mergeDash(Lcom/vdocipher/PlaybackInfo$DASH;)V
    .registers 4

    .line 12883
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12884
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->dash_:Lcom/vdocipher/PlaybackInfo$DASH;

    if-eqz v0, :cond_22

    .line 12885
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$DASH;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$DASH;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 12886
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->dash_:Lcom/vdocipher/PlaybackInfo$DASH;

    .line 12887
    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->newBuilder(Lcom/vdocipher/PlaybackInfo$DASH;)Lcom/vdocipher/PlaybackInfo$DASH$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$DASH$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$DASH;

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->dash_:Lcom/vdocipher/PlaybackInfo$DASH;

    goto :goto_24

    .line 12889
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->dash_:Lcom/vdocipher/PlaybackInfo$DASH;

    .line 12891
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x10

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private mergeFps(Lcom/vdocipher/PlaybackInfo$FPS;)V
    .registers 4

    .line 12837
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12838
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->fps_:Lcom/vdocipher/PlaybackInfo$FPS;

    if-eqz v0, :cond_22

    .line 12839
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$FPS;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$FPS;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 12840
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->fps_:Lcom/vdocipher/PlaybackInfo$FPS;

    .line 12841
    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$FPS;->newBuilder(Lcom/vdocipher/PlaybackInfo$FPS;)Lcom/vdocipher/PlaybackInfo$FPS$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$FPS$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$FPS$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$FPS;

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->fps_:Lcom/vdocipher/PlaybackInfo$FPS;

    goto :goto_24

    .line 12843
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->fps_:Lcom/vdocipher/PlaybackInfo$FPS;

    .line 12845
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x8

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private mergeH6(Lcom/vdocipher/PlaybackInfo$H6;)V
    .registers 4

    .line 12975
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12976
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->h6_:Lcom/vdocipher/PlaybackInfo$H6;

    if-eqz v0, :cond_22

    .line 12977
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$H6;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$H6;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 12978
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->h6_:Lcom/vdocipher/PlaybackInfo$H6;

    .line 12979
    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$H6;->newBuilder(Lcom/vdocipher/PlaybackInfo$H6;)Lcom/vdocipher/PlaybackInfo$H6$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$H6$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$H6$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$H6$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$H6;

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->h6_:Lcom/vdocipher/PlaybackInfo$H6;

    goto :goto_24

    .line 12981
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->h6_:Lcom/vdocipher/PlaybackInfo$H6;

    .line 12983
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x40

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private mergeLanguage(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V
    .registers 4

    .line 13230
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13231
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->language_:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    if-eqz v0, :cond_22

    .line 13232
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 13233
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->language_:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    .line 13234
    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->newBuilder(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->language_:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    goto :goto_24

    .line 13236
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->language_:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    .line 13238
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x200

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private mergePlayerConfig(Lcom/vdocipher/PlaybackInfo$PlayerConfig;)V
    .registers 4

    .line 12697
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12698
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->playerConfig_:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    if-eqz v0, :cond_22

    .line 12699
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 12700
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->playerConfig_:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    .line 12701
    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->newBuilder(Lcom/vdocipher/PlaybackInfo$PlayerConfig;)Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->playerConfig_:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    goto :goto_24

    .line 12703
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->playerConfig_:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    .line 12705
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x4

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 1

    .line 13707
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackInfo$MetadataTable;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;
    .registers 2

    .line 13710
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$MetadataTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 13683
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$MetadataTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 13690
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$MetadataTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 13646
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$MetadataTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 13653
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackInfo$MetadataTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 13695
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$MetadataTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 13702
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$MetadataTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 13670
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$MetadataTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 13677
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackInfo$MetadataTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 13633
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$MetadataTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 13640
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackInfo$MetadataTable;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 13658
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$MetadataTable;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 13665
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$MetadataTable;",
            ">;"
        }
    .end annotation

    .line 15479
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private removeCaptions(I)V
    .registers 3

    .line 12804
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureCaptionsIsMutable()V

    .line 12805
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->captions_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private removeChapters(I)V
    .registers 3

    .line 13163
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureChaptersIsMutable()V

    .line 13164
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->chapters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private removeCtas(I)V
    .registers 3

    .line 13579
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureCtasIsMutable()V

    .line 13580
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ctas_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private removeErrorMsgs(I)V
    .registers 3

    .line 13337
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureErrorMsgsIsMutable()V

    .line 13338
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->errorMsgs_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private removePosters(I)V
    .registers 3

    .line 12630
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensurePostersIsMutable()V

    .line 12631
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->posters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private setAltHosts(ILjava/lang/String;)V
    .registers 4

    .line 13448
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13449
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureAltHostsIsMutable()V

    .line 13450
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->altHosts_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setAspectRatio(F)V
    .registers 2

    .line 12178
    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->aspectRatio_:F

    return-void
.end method

.method private setAudioOnly(Z)V
    .registers 2

    .line 12475
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->audioOnly_:Z

    return-void
.end method

.method private setCanSkipIntegrityCheck(Z)V
    .registers 3

    .line 13190
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit16 v0, v0, 0x100

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    .line 13191
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->canSkipIntegrityCheck_:Z

    return-void
.end method

.method private setCaptions(ILcom/vdocipher/PlaybackInfo$Captions;)V
    .registers 4

    .line 12764
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12765
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureCaptionsIsMutable()V

    .line 12766
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->captions_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setCbcs(Lcom/vdocipher/PlaybackInfo$CBCSI;)V
    .registers 2

    .line 12920
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12921
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->cbcs_:Lcom/vdocipher/PlaybackInfo$CBCSI;

    .line 12922
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x20

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private setChapters(ILcom/vdocipher/PlaybackInfo$Chapters;)V
    .registers 4

    .line 13123
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13124
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureChaptersIsMutable()V

    .line 13125
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->chapters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setCtas(ILcom/vdocipher/PlaybackInfo$Cta;)V
    .registers 4

    .line 13539
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13540
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureCtasIsMutable()V

    .line 13541
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ctas_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setDash(Lcom/vdocipher/PlaybackInfo$DASH;)V
    .registers 2

    .line 12874
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12875
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->dash_:Lcom/vdocipher/PlaybackInfo$DASH;

    .line 12876
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x10

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private setDescription(Ljava/lang/String;)V
    .registers 2

    .line 12114
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12116
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->description_:Ljava/lang/String;

    return-void
.end method

.method private setDescriptionBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 12131
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 12132
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->description_:Ljava/lang/String;

    return-void
.end method

.method private setDesiredBitrate(I)V
    .registers 3

    .line 12657
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit8 v0, v0, 0x2

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    .line 12658
    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->desiredBitrate_:I

    return-void
.end method

.method private setDuration(I)V
    .registers 2

    .line 12152
    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->duration_:I

    return-void
.end method

.method private setEmbedUrl(Ljava/lang/String;)V
    .registers 2

    .line 12306
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12308
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->embedUrl_:Ljava/lang/String;

    return-void
.end method

.method private setEmbedUrlBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 12323
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 12324
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->embedUrl_:Ljava/lang/String;

    return-void
.end method

.method private setErrorMsgs(ILcom/vdocipher/PlaybackInfo$ErrorMessage;)V
    .registers 4

    .line 13297
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13298
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureErrorMsgsIsMutable()V

    .line 13299
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->errorMsgs_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setFps(Lcom/vdocipher/PlaybackInfo$FPS;)V
    .registers 2

    .line 12828
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12829
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->fps_:Lcom/vdocipher/PlaybackInfo$FPS;

    .line 12830
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x8

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private setH6(Lcom/vdocipher/PlaybackInfo$H6;)V
    .registers 2

    .line 12966
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12967
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->h6_:Lcom/vdocipher/PlaybackInfo$H6;

    .line 12968
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x40

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private setHostnames(ILjava/lang/String;)V
    .registers 4

    .line 12240
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12241
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureHostnamesIsMutable()V

    .line 12242
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hostnames_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setIntegrityCloudId(Ljava/lang/String;)V
    .registers 3

    .line 13025
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13026
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit16 v0, v0, 0x80

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    .line 13027
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->integrityCloudId_:Ljava/lang/String;

    return-void
.end method

.method private setIntegrityCloudIdBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 13042
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 13043
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->integrityCloudId_:Ljava/lang/String;

    .line 13044
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x80

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private setLanguage(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V
    .registers 2

    .line 13221
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13222
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->language_:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    .line 13223
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x200

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private setPlayerConfig(Lcom/vdocipher/PlaybackInfo$PlayerConfig;)V
    .registers 2

    .line 12688
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12689
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->playerConfig_:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    .line 12690
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x4

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private setPosters(ILcom/vdocipher/PlaybackInfo$Posters;)V
    .registers 4

    .line 12590
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12591
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensurePostersIsMutable()V

    .line 12592
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->posters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setScrubbingPreviewUrl(Ljava/lang/String;)V
    .registers 3

    .line 13374
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13375
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit16 v0, v0, 0x400

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    .line 13376
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->scrubbingPreviewUrl_:Ljava/lang/String;

    return-void
.end method

.method private setScrubbingPreviewUrlBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 13391
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 13392
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->scrubbingPreviewUrl_:Ljava/lang/String;

    .line 13393
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit16 p1, p1, 0x400

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method

.method private setTech(ILcom/vdocipher/PlaybackInfo$TechOptions;)V
    .registers 4

    .line 12400
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12401
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureTechIsMutable()V

    .line 12402
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_:Lcom/google/protobuf/Internal$IntList;

    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$TechOptions;->getNumber()I

    move-result p2

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$IntList;->setInt(II)I

    return-void
.end method

.method private setTechValue(II)V
    .registers 4

    .line 12436
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ensureTechIsMutable()V

    .line 12437
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$IntList;->setInt(II)I

    return-void
.end method

.method private setTitle(Ljava/lang/String;)V
    .registers 2

    .line 12067
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12069
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->title_:Ljava/lang/String;

    return-void
.end method

.method private setTitleBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 12084
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 12085
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->title_:Ljava/lang/String;

    return-void
.end method

.method private setVdocipherBranding(Z)V
    .registers 2

    .line 13063
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->vdocipherBranding_:Z

    return-void
.end method

.method private setVersion(Ljava/lang/String;)V
    .registers 2

    .line 13608
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13610
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->version_:Ljava/lang/String;

    return-void
.end method

.method private setVersionBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 13625
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 13626
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->version_:Ljava/lang/String;

    return-void
.end method

.method private setWhitelistHref(Ljava/lang/String;)V
    .registers 3

    .line 12518
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12519
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    .line 12520
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->whitelistHref_:Ljava/lang/String;

    return-void
.end method

.method private setWhitelistHrefBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 12535
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 12536
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->whitelistHref_:Ljava/lang/String;

    .line 12537
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 39

    .line 15380
    sget-object v0, Lcom/vdocipher/PlaybackInfo$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual/range {p1 .. p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_96

    .line 15457
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0

    :pswitch_12  #0x7
    return-object v1

    :pswitch_13  #0x6
    const/4 v0, 0x1

    .line 15451
    invoke-static {v0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v0

    return-object v0

    .line 15436
    :pswitch_19  #0x5
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->PARSER:Lcom/google/protobuf/Parser;

    if-nez v0, :cond_32

    .line 15438
    const-class v1, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    monitor-enter v1

    .line 15439
    :try_start_20
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->PARSER:Lcom/google/protobuf/Parser;

    if-nez v0, :cond_2d

    .line 15441
    new-instance v0, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object v2, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-direct {v0, v2}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 15444
    sput-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->PARSER:Lcom/google/protobuf/Parser;

    .line 15446
    :cond_2d
    monitor-exit v1

    return-object v0

    :catchall_2f
    move-exception v0

    monitor-exit v1
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw v0

    :cond_32
    return-object v0

    .line 15433
    :pswitch_33  #0x4
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object v0

    .line 15388
    :pswitch_36  #0x3
    const-string v2, "bitField0_"

    const-string/jumbo v3, "title_"

    const-string v4, "description_"

    const-string v5, "duration_"

    const-string v6, "aspectRatio_"

    const-string v7, "hostnames_"

    const-string v8, "embedUrl_"

    const-string/jumbo v9, "tech_"

    const-string v10, "audioOnly_"

    const-string/jumbo v11, "whitelistHref_"

    const-string v12, "posters_"

    const-class v13, Lcom/vdocipher/PlaybackInfo$Posters;

    const-string v14, "desiredBitrate_"

    const-string v15, "playerConfig_"

    const-string v16, "captions_"

    const-class v17, Lcom/vdocipher/PlaybackInfo$Captions;

    const-string v18, "fps_"

    const-string v19, "dash_"

    const-string v20, "cbcs_"

    const-string v21, "h6_"

    const-string v22, "integrityCloudId_"

    const-string/jumbo v23, "vdocipherBranding_"

    const-string v24, "chapters_"

    const-class v25, Lcom/vdocipher/PlaybackInfo$Chapters;

    const-string v26, "canSkipIntegrityCheck_"

    const-string v27, "language_"

    const-string v28, "errorMsgs_"

    const-class v29, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    const-string v30, "scrubbingPreviewUrl_"

    const-string v31, "altHosts_"

    const-string v32, "ctas_"

    const-class v33, Lcom/vdocipher/PlaybackInfo$Cta;

    const-string/jumbo v34, "version_"

    filled-new-array/range {v2 .. v34}, [Ljava/lang/Object;

    move-result-object v0

    .line 15423
    const-string v1, "\u0000\u001b\u0000\u0001\u0001\u001b\u001b\u0000\b\u0000\u0001Ȉ\u0002Ȉ\u0003\u000b\u0004\u0001\u0005Ț\u0006Ȉ\u0007,\b\u0007\tለ\u0000\n\u001b\u000bဋ\u0001\fဉ\u0002\r\u001b\u000eဉ\u0003\u000fဉ\u0004\u0010ဉ\u0005\u0011ဉ\u0006\u0012ለ\u0007\u0013\u0007\u0014\u001b\u0015ဇ\b\u0016ဉ\t\u0017\u001b\u0018ለ\n\u0019Ț\u001a\u001b\u001bȈ"

    .line 15429
    sget-object v2, Lcom/vdocipher/PlaybackInfo$MetadataTable;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-static {v2, v1, v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    .line 15385
    :pswitch_8a  #0x2
    new-instance v0, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    invoke-direct {v0, v1}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;-><init>(Lcom/vdocipher/PlaybackInfo-IA;)V

    return-object v0

    .line 15382
    :pswitch_90  #0x1
    new-instance v0, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;-><init>()V

    return-object v0

    :pswitch_data_96
    .packed-switch 0x1
        :pswitch_90  #00000001
        :pswitch_8a  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getAltHosts(I)Ljava/lang/String;
    .registers 3

    .line 13421
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->altHosts_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    return-object p1
.end method

.method public getAltHostsBytes(I)Lcom/google/protobuf/ByteString;
    .registers 3

    .line 13431
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->altHosts_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 13432
    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    .line 13431
    invoke-static {p1}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object p1

    return-object p1
.end method

.method public getAltHostsCount()I
    .registers 2

    .line 13412
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->altHosts_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getAltHostsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 13404
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->altHosts_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getAspectRatio()F
    .registers 2

    .line 12170
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->aspectRatio_:F

    return v0
.end method

.method public getAudioOnly()Z
    .registers 2

    .line 12467
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->audioOnly_:Z

    return v0
.end method

.method public getCanSkipIntegrityCheck()Z
    .registers 2

    .line 13183
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->canSkipIntegrityCheck_:Z

    return v0
.end method

.method public getCaptions(I)Lcom/vdocipher/PlaybackInfo$Captions;
    .registers 3

    .line 12742
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->captions_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$Captions;

    return-object p1
.end method

.method public getCaptionsCount()I
    .registers 2

    .line 12735
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->captions_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getCaptionsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$Captions;",
            ">;"
        }
    .end annotation

    .line 12721
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->captions_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getCaptionsOrBuilder(I)Lcom/vdocipher/PlaybackInfo$CaptionsOrBuilder;
    .registers 3

    .line 12749
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->captions_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$CaptionsOrBuilder;

    return-object p1
.end method

.method public getCaptionsOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$CaptionsOrBuilder;",
            ">;"
        }
    .end annotation

    .line 12728
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->captions_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getCbcs()Lcom/vdocipher/PlaybackInfo$CBCSI;
    .registers 2

    .line 12914
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->cbcs_:Lcom/vdocipher/PlaybackInfo$CBCSI;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackInfo$CBCSI;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$CBCSI;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getChapters(I)Lcom/vdocipher/PlaybackInfo$Chapters;
    .registers 3

    .line 13101
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->chapters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$Chapters;

    return-object p1
.end method

.method public getChaptersCount()I
    .registers 2

    .line 13094
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->chapters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getChaptersList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$Chapters;",
            ">;"
        }
    .end annotation

    .line 13080
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->chapters_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getChaptersOrBuilder(I)Lcom/vdocipher/PlaybackInfo$ChaptersOrBuilder;
    .registers 3

    .line 13108
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->chapters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$ChaptersOrBuilder;

    return-object p1
.end method

.method public getChaptersOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$ChaptersOrBuilder;",
            ">;"
        }
    .end annotation

    .line 13087
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->chapters_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getCtas(I)Lcom/vdocipher/PlaybackInfo$Cta;
    .registers 3

    .line 13517
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ctas_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$Cta;

    return-object p1
.end method

.method public getCtasCount()I
    .registers 2

    .line 13510
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ctas_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getCtasList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$Cta;",
            ">;"
        }
    .end annotation

    .line 13496
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ctas_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getCtasOrBuilder(I)Lcom/vdocipher/PlaybackInfo$CtaOrBuilder;
    .registers 3

    .line 13524
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ctas_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$CtaOrBuilder;

    return-object p1
.end method

.method public getCtasOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$CtaOrBuilder;",
            ">;"
        }
    .end annotation

    .line 13503
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->ctas_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getDash()Lcom/vdocipher/PlaybackInfo$DASH;
    .registers 2

    .line 12868
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->dash_:Lcom/vdocipher/PlaybackInfo$DASH;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackInfo$DASH;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$DASH;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getDescription()Ljava/lang/String;
    .registers 2

    .line 12097
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->description_:Ljava/lang/String;

    return-object v0
.end method

.method public getDescriptionBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 12106
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->description_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getDesiredBitrate()I
    .registers 2

    .line 12650
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->desiredBitrate_:I

    return v0
.end method

.method public getDuration()I
    .registers 2

    .line 12144
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->duration_:I

    return v0
.end method

.method public getEmbedUrl()Ljava/lang/String;
    .registers 2

    .line 12289
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->embedUrl_:Ljava/lang/String;

    return-object v0
.end method

.method public getEmbedUrlBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 12298
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->embedUrl_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getErrorMsgs(I)Lcom/vdocipher/PlaybackInfo$ErrorMessage;
    .registers 3

    .line 13275
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->errorMsgs_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    return-object p1
.end method

.method public getErrorMsgsCount()I
    .registers 2

    .line 13268
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->errorMsgs_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getErrorMsgsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$ErrorMessage;",
            ">;"
        }
    .end annotation

    .line 13254
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->errorMsgs_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getErrorMsgsOrBuilder(I)Lcom/vdocipher/PlaybackInfo$ErrorMessageOrBuilder;
    .registers 3

    .line 13282
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->errorMsgs_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$ErrorMessageOrBuilder;

    return-object p1
.end method

.method public getErrorMsgsOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$ErrorMessageOrBuilder;",
            ">;"
        }
    .end annotation

    .line 13261
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->errorMsgs_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getFps()Lcom/vdocipher/PlaybackInfo$FPS;
    .registers 2

    .line 12822
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->fps_:Lcom/vdocipher/PlaybackInfo$FPS;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackInfo$FPS;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$FPS;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getH6()Lcom/vdocipher/PlaybackInfo$H6;
    .registers 2

    .line 12960
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->h6_:Lcom/vdocipher/PlaybackInfo$H6;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackInfo$H6;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$H6;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getHostnames(I)Ljava/lang/String;
    .registers 3

    .line 12213
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hostnames_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    return-object p1
.end method

.method public getHostnamesBytes(I)Lcom/google/protobuf/ByteString;
    .registers 3

    .line 12223
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hostnames_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 12224
    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    .line 12223
    invoke-static {p1}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object p1

    return-object p1
.end method

.method public getHostnamesCount()I
    .registers 2

    .line 12204
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hostnames_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getHostnamesList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 12196
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->hostnames_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getIntegrityCloudId()Ljava/lang/String;
    .registers 2

    .line 13008
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->integrityCloudId_:Ljava/lang/String;

    return-object v0
.end method

.method public getIntegrityCloudIdBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 13017
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->integrityCloudId_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getLanguage()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 2

    .line 13215
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->language_:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getPlayerConfig()Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 2

    .line 12682
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->playerConfig_:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getPosters(I)Lcom/vdocipher/PlaybackInfo$Posters;
    .registers 3

    .line 12568
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->posters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$Posters;

    return-object p1
.end method

.method public getPostersCount()I
    .registers 2

    .line 12561
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->posters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getPostersList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$Posters;",
            ">;"
        }
    .end annotation

    .line 12547
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->posters_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getPostersOrBuilder(I)Lcom/vdocipher/PlaybackInfo$PostersOrBuilder;
    .registers 3

    .line 12575
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->posters_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$PostersOrBuilder;

    return-object p1
.end method

.method public getPostersOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$PostersOrBuilder;",
            ">;"
        }
    .end annotation

    .line 12554
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->posters_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getScrubbingPreviewUrl()Ljava/lang/String;
    .registers 2

    .line 13357
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->scrubbingPreviewUrl_:Ljava/lang/String;

    return-object v0
.end method

.method public getScrubbingPreviewUrlBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 13366
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->scrubbingPreviewUrl_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getTech(I)Lcom/vdocipher/PlaybackInfo$TechOptions;
    .registers 3

    .line 12364
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->getInt(I)I

    move-result p1

    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$TechOptions;->forNumber(I)Lcom/vdocipher/PlaybackInfo$TechOptions;

    move-result-object p1

    if-nez p1, :cond_e

    .line 12365
    sget-object p1, Lcom/vdocipher/PlaybackInfo$TechOptions;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$TechOptions;

    :cond_e
    return-object p1
.end method

.method public getTechCount()I
    .registers 2

    .line 12355
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$IntList;->size()I

    move-result v0

    return v0
.end method

.method public getTechList()Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$TechOptions;",
            ">;"
        }
    .end annotation

    .line 12346
    new-instance v0, Lcom/google/protobuf/Internal$ListAdapter;

    iget-object v1, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_:Lcom/google/protobuf/Internal$IntList;

    sget-object v2, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_converter_:Lcom/google/protobuf/Internal$ListAdapter$Converter;

    invoke-direct {v0, v1, v2}, Lcom/google/protobuf/Internal$ListAdapter;-><init>(Ljava/util/List;Lcom/google/protobuf/Internal$ListAdapter$Converter;)V

    return-object v0
.end method

.method public getTechValue(I)I
    .registers 3

    .line 12383
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->getInt(I)I

    move-result p1

    return p1
.end method

.method public getTechValueList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 12374
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->tech_:Lcom/google/protobuf/Internal$IntList;

    return-object v0
.end method

.method public getTitle()Ljava/lang/String;
    .registers 2

    .line 12050
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->title_:Ljava/lang/String;

    return-object v0
.end method

.method public getTitleBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 12059
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->title_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getVdocipherBranding()Z
    .registers 2

    .line 13055
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->vdocipherBranding_:Z

    return v0
.end method

.method public getVersion()Ljava/lang/String;
    .registers 2

    .line 13591
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->version_:Ljava/lang/String;

    return-object v0
.end method

.method public getVersionBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 13600
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->version_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getWhitelistHref()Ljava/lang/String;
    .registers 2

    .line 12501
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->whitelistHref_:Ljava/lang/String;

    return-object v0
.end method

.method public getWhitelistHrefBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 12510
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->whitelistHref_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public hasCanSkipIntegrityCheck()Z
    .registers 2

    .line 13175
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit16 v0, v0, 0x100

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasCbcs()Z
    .registers 2

    .line 12907
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x20

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasDash()Z
    .registers 2

    .line 12861
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasDesiredBitrate()Z
    .registers 2

    .line 12642
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasFps()Z
    .registers 2

    .line 12815
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x8

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasH6()Z
    .registers 2

    .line 12953
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x40

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasIntegrityCloudId()Z
    .registers 2

    .line 13000
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit16 v0, v0, 0x80

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasLanguage()Z
    .registers 2

    .line 13208
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit16 v0, v0, 0x200

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasPlayerConfig()Z
    .registers 2

    .line 12675
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasScrubbingPreviewUrl()Z
    .registers 2

    .line 13349
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    and-int/lit16 v0, v0, 0x400

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasWhitelistHref()Z
    .registers 3

    .line 12493
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$MetadataTable;->bitField0_:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_7

    return v1

    :cond_7
    const/4 v0, 0x0

    return v0
.end method
