# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguageOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "ErrorMessageLanguageOrBuilder"
.end annotation


# virtual methods
.method public abstract getDirection()Lcom/vdocipher/PlaybackInfo$MessageDirection;
.end method

.method public abstract getDirectionValue()I
.end method

.method public abstract getHash()Ljava/lang/String;
.end method

.method public abstract getHashBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getId()Ljava/lang/String;
.end method

.method public abstract getIdBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getLanguage()Ljava/lang/String;
.end method

.method public abstract getLanguageBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getName()Ljava/lang/String;
.end method

.method public abstract getNameBytes()Lcom/google/protobuf/ByteString;
.end method
