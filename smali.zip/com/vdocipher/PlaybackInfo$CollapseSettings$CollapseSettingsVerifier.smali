# classes14.dex

.class final Lcom/vdocipher/PlaybackInfo$CollapseSettings$CollapseSettingsVerifier;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumVerifier;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$CollapseSettings;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "CollapseSettingsVerifier"
.end annotation


# static fields
.field static final INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 282
    new-instance v0, Lcom/vdocipher/PlaybackInfo$CollapseSettings$CollapseSettingsVerifier;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$CollapseSettings$CollapseSettingsVerifier;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$CollapseSettings$CollapseSettingsVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 280
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public isInRange(I)Z
    .registers 2

    .line 285
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->forNumber(I)Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    move-result-object p1

    if-eqz p1, :cond_8

    const/4 p1, 0x1

    return p1

    :cond_8
    const/4 p1, 0x0

    return p1
.end method
