# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Dimension;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$DimensionOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Dimension"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$Dimension;",
        "Lcom/vdocipher/PlaybackSession$Dimension$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$DimensionOrBuilder;"
    }
.end annotation


# static fields
.field public static final AVAILSCREENHEIGHT_FIELD_NUMBER:I = 0x1

.field public static final AVAILSCREENWIDTH_FIELD_NUMBER:I = 0x2

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

.field public static final INNERWINDOWHEIGHT_FIELD_NUMBER:I = 0x7

.field public static final INNERWINDOWWIDTH_FIELD_NUMBER:I = 0x8

.field public static final OUTERWINDOWHEIGHT_FIELD_NUMBER:I = 0x9

.field public static final OUTERWINDOWWIDTH_FIELD_NUMBER:I = 0xa

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Dimension;",
            ">;"
        }
    .end annotation
.end field

.field public static final SCREENHEIGHT_FIELD_NUMBER:I = 0x3

.field public static final SCREENWIDTH_FIELD_NUMBER:I = 0x4

.field public static final VIDEOHEIGHT_FIELD_NUMBER:I = 0x5

.field public static final VIDEOWIDTH_FIELD_NUMBER:I = 0x6


# instance fields
.field private availScreenHeight_:I

.field private availScreenWidth_:I

.field private innerWindowHeight_:I

.field private innerWindowWidth_:I

.field private outerWindowHeight_:I

.field private outerWindowWidth_:I

.field private screenHeight_:I

.field private screenWidth_:I

.field private videoHeight_:I

.field private videoWidth_:I


# direct methods
.method static bridge synthetic -$$Nest$mclearAvailScreenHeight(Lcom/vdocipher/PlaybackSession$Dimension;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Dimension;->clearAvailScreenHeight()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearAvailScreenWidth(Lcom/vdocipher/PlaybackSession$Dimension;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Dimension;->clearAvailScreenWidth()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearInnerWindowHeight(Lcom/vdocipher/PlaybackSession$Dimension;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Dimension;->clearInnerWindowHeight()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearInnerWindowWidth(Lcom/vdocipher/PlaybackSession$Dimension;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Dimension;->clearInnerWindowWidth()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearOuterWindowHeight(Lcom/vdocipher/PlaybackSession$Dimension;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Dimension;->clearOuterWindowHeight()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearOuterWindowWidth(Lcom/vdocipher/PlaybackSession$Dimension;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Dimension;->clearOuterWindowWidth()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearScreenHeight(Lcom/vdocipher/PlaybackSession$Dimension;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Dimension;->clearScreenHeight()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearScreenWidth(Lcom/vdocipher/PlaybackSession$Dimension;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Dimension;->clearScreenWidth()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearVideoHeight(Lcom/vdocipher/PlaybackSession$Dimension;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Dimension;->clearVideoHeight()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearVideoWidth(Lcom/vdocipher/PlaybackSession$Dimension;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Dimension;->clearVideoWidth()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAvailScreenHeight(Lcom/vdocipher/PlaybackSession$Dimension;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->setAvailScreenHeight(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAvailScreenWidth(Lcom/vdocipher/PlaybackSession$Dimension;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->setAvailScreenWidth(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetInnerWindowHeight(Lcom/vdocipher/PlaybackSession$Dimension;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->setInnerWindowHeight(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetInnerWindowWidth(Lcom/vdocipher/PlaybackSession$Dimension;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->setInnerWindowWidth(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetOuterWindowHeight(Lcom/vdocipher/PlaybackSession$Dimension;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->setOuterWindowHeight(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetOuterWindowWidth(Lcom/vdocipher/PlaybackSession$Dimension;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->setOuterWindowWidth(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetScreenHeight(Lcom/vdocipher/PlaybackSession$Dimension;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->setScreenHeight(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetScreenWidth(Lcom/vdocipher/PlaybackSession$Dimension;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->setScreenWidth(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVideoHeight(Lcom/vdocipher/PlaybackSession$Dimension;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->setVideoHeight(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVideoWidth(Lcom/vdocipher/PlaybackSession$Dimension;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->setVideoWidth(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 3190
    new-instance v0, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$Dimension;-><init>()V

    .line 3193
    sput-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    .line 3194
    const-class v1, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 2486
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    return-void
.end method

.method private clearAvailScreenHeight()V
    .registers 2

    const/4 v0, 0x0

    .line 2511
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->availScreenHeight_:I

    return-void
.end method

.method private clearAvailScreenWidth()V
    .registers 2

    const/4 v0, 0x0

    .line 2537
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->availScreenWidth_:I

    return-void
.end method

.method private clearInnerWindowHeight()V
    .registers 2

    const/4 v0, 0x0

    .line 2667
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->innerWindowHeight_:I

    return-void
.end method

.method private clearInnerWindowWidth()V
    .registers 2

    const/4 v0, 0x0

    .line 2693
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->innerWindowWidth_:I

    return-void
.end method

.method private clearOuterWindowHeight()V
    .registers 2

    const/4 v0, 0x0

    .line 2719
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->outerWindowHeight_:I

    return-void
.end method

.method private clearOuterWindowWidth()V
    .registers 2

    const/4 v0, 0x0

    .line 2745
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->outerWindowWidth_:I

    return-void
.end method

.method private clearScreenHeight()V
    .registers 2

    const/4 v0, 0x0

    .line 2563
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->screenHeight_:I

    return-void
.end method

.method private clearScreenWidth()V
    .registers 2

    const/4 v0, 0x0

    .line 2589
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->screenWidth_:I

    return-void
.end method

.method private clearVideoHeight()V
    .registers 2

    const/4 v0, 0x0

    .line 2615
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->videoHeight_:I

    return-void
.end method

.method private clearVideoWidth()V
    .registers 2

    const/4 v0, 0x0

    .line 2641
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->videoWidth_:I

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 1

    .line 3199
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 1

    .line 2825
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$Dimension;)Lcom/vdocipher/PlaybackSession$Dimension$Builder;
    .registers 2

    .line 2828
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$Dimension;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Dimension$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2801
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$Dimension;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Dimension;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2808
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Dimension;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2764
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Dimension;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2771
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Dimension;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2813
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Dimension;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2820
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Dimension;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2788
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Dimension;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2795
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Dimension;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2751
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Dimension;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2758
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Dimension;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2776
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Dimension;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Dimension;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2783
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Dimension;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Dimension;",
            ">;"
        }
    .end annotation

    .line 3205
    sget-object v0, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Dimension;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setAvailScreenHeight(I)V
    .registers 2

    .line 2504
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Dimension;->availScreenHeight_:I

    return-void
.end method

.method private setAvailScreenWidth(I)V
    .registers 2

    .line 2530
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Dimension;->availScreenWidth_:I

    return-void
.end method

.method private setInnerWindowHeight(I)V
    .registers 2

    .line 2660
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Dimension;->innerWindowHeight_:I

    return-void
.end method

.method private setInnerWindowWidth(I)V
    .registers 2

    .line 2686
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Dimension;->innerWindowWidth_:I

    return-void
.end method

.method private setOuterWindowHeight(I)V
    .registers 2

    .line 2712
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Dimension;->outerWindowHeight_:I

    return-void
.end method

.method private setOuterWindowWidth(I)V
    .registers 2

    .line 2738
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Dimension;->outerWindowWidth_:I

    return-void
.end method

.method private setScreenHeight(I)V
    .registers 2

    .line 2556
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Dimension;->screenHeight_:I

    return-void
.end method

.method private setScreenWidth(I)V
    .registers 2

    .line 2582
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Dimension;->screenWidth_:I

    return-void
.end method

.method private setVideoHeight(I)V
    .registers 2

    .line 2608
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Dimension;->videoHeight_:I

    return-void
.end method

.method private setVideoWidth(I)V
    .registers 2

    .line 2634
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Dimension;->videoWidth_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 14

    .line 3132
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_66

    .line 3183
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 3177
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 3162
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$Dimension;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_33

    .line 3164
    const-class p2, Lcom/vdocipher/PlaybackSession$Dimension;

    monitor-enter p2

    .line 3165
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$Dimension;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 3167
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 3170
    sput-object p1, Lcom/vdocipher/PlaybackSession$Dimension;->PARSER:Lcom/google/protobuf/Parser;

    .line 3172
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception v0

    move-object p1, v0

    monitor-exit p2
    :try_end_32
    .catchall {:try_start_20 .. :try_end_32} :catchall_2f

    throw p1

    :cond_33
    return-object p1

    .line 3159
    :pswitch_34  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    return-object p1

    .line 3140
    :pswitch_37  #0x3
    const-string v0, "availScreenHeight_"

    const-string v1, "availScreenWidth_"

    const-string v2, "screenHeight_"

    const-string v3, "screenWidth_"

    const-string/jumbo v4, "videoHeight_"

    const-string/jumbo v5, "videoWidth_"

    const-string v6, "innerWindowHeight_"

    const-string v7, "innerWindowWidth_"

    const-string v8, "outerWindowHeight_"

    const-string v9, "outerWindowWidth_"

    filled-new-array/range {v0 .. v9}, [Ljava/lang/Object;

    move-result-object p1

    .line 3152
    const-string p2, "\u0000\n\u0000\u0000\u0001\n\n\u0000\u0000\u0000\u0001\u000b\u0002\u000b\u0003\u000b\u0004\u000b\u0005\u000b\u0006\u000b\u0007\u000b\b\u000b\t\u000b\n\u000b"

    .line 3155
    sget-object p3, Lcom/vdocipher/PlaybackSession$Dimension;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$Dimension;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 3137
    :pswitch_5a  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$Dimension$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$Dimension$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 3134
    :pswitch_60  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$Dimension;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$Dimension;-><init>()V

    return-object p1

    :pswitch_data_66
    .packed-switch 0x1
        :pswitch_60  #00000001
        :pswitch_5a  #00000002
        :pswitch_37  #00000003
        :pswitch_34  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getAvailScreenHeight()I
    .registers 2

    .line 2496
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->availScreenHeight_:I

    return v0
.end method

.method public getAvailScreenWidth()I
    .registers 2

    .line 2522
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->availScreenWidth_:I

    return v0
.end method

.method public getInnerWindowHeight()I
    .registers 2

    .line 2652
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->innerWindowHeight_:I

    return v0
.end method

.method public getInnerWindowWidth()I
    .registers 2

    .line 2678
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->innerWindowWidth_:I

    return v0
.end method

.method public getOuterWindowHeight()I
    .registers 2

    .line 2704
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->outerWindowHeight_:I

    return v0
.end method

.method public getOuterWindowWidth()I
    .registers 2

    .line 2730
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->outerWindowWidth_:I

    return v0
.end method

.method public getScreenHeight()I
    .registers 2

    .line 2548
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->screenHeight_:I

    return v0
.end method

.method public getScreenWidth()I
    .registers 2

    .line 2574
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->screenWidth_:I

    return v0
.end method

.method public getVideoHeight()I
    .registers 2

    .line 2600
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->videoHeight_:I

    return v0
.end method

.method public getVideoWidth()I
    .registers 2

    .line 2626
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Dimension;->videoWidth_:I

    return v0
.end method
