# classes14.dex

.class public final Lcom/vdocipher/Manifest$SupplementalProperty;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$SupplementalPropertyOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "SupplementalProperty"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$SupplementalProperty$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/Manifest$SupplementalProperty;",
        "Lcom/vdocipher/Manifest$SupplementalProperty$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$SupplementalPropertyOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$SupplementalProperty;",
            ">;"
        }
    .end annotation
.end field

.field public static final SCHEMEIDURI_FIELD_NUMBER:I = 0x1

.field public static final VALUE_FIELD_NUMBER:I = 0x2


# instance fields
.field private schemeIdUri_:Ljava/lang/String;

.field private value_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$mclearSchemeIdUri(Lcom/vdocipher/Manifest$SupplementalProperty;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SupplementalProperty;->clearSchemeIdUri()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearValue(Lcom/vdocipher/Manifest$SupplementalProperty;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SupplementalProperty;->clearValue()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSchemeIdUri(Lcom/vdocipher/Manifest$SupplementalProperty;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SupplementalProperty;->setSchemeIdUri(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSchemeIdUriBytes(Lcom/vdocipher/Manifest$SupplementalProperty;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SupplementalProperty;->setSchemeIdUriBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetValue(Lcom/vdocipher/Manifest$SupplementalProperty;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SupplementalProperty;->setValue(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetValueBytes(Lcom/vdocipher/Manifest$SupplementalProperty;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SupplementalProperty;->setValueBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 1

    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 5542
    new-instance v0, Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$SupplementalProperty;-><init>()V

    .line 5545
    sput-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    .line 5546
    const-class v1, Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 5192
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 5193
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty;->schemeIdUri_:Ljava/lang/String;

    .line 5194
    iput-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty;->value_:Ljava/lang/String;

    return-void
.end method

.method private clearSchemeIdUri()V
    .registers 2

    .line 5230
    invoke-static {}, Lcom/vdocipher/Manifest$SupplementalProperty;->getDefaultInstance()Lcom/vdocipher/Manifest$SupplementalProperty;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SupplementalProperty;->getSchemeIdUri()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty;->schemeIdUri_:Ljava/lang/String;

    return-void
.end method

.method private clearValue()V
    .registers 2

    .line 5277
    invoke-static {}, Lcom/vdocipher/Manifest$SupplementalProperty;->getDefaultInstance()Lcom/vdocipher/Manifest$SupplementalProperty;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SupplementalProperty;->getValue()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty;->value_:Ljava/lang/String;

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 1

    .line 5551
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/Manifest$SupplementalProperty$Builder;
    .registers 1

    .line 5367
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SupplementalProperty;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/Manifest$SupplementalProperty;)Lcom/vdocipher/Manifest$SupplementalProperty$Builder;
    .registers 2

    .line 5370
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-virtual {v0, p0}, Lcom/vdocipher/Manifest$SupplementalProperty;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5343
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p0}, Lcom/vdocipher/Manifest$SupplementalProperty;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5350
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/Manifest$SupplementalProperty;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5306
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5313
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5355
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5362
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5330
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5337
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5293
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5300
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5318
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SupplementalProperty;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5325
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$SupplementalProperty;",
            ">;"
        }
    .end annotation

    .line 5557
    sget-object v0, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SupplementalProperty;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setSchemeIdUri(Ljava/lang/String;)V
    .registers 2

    .line 5221
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5223
    iput-object p1, p0, Lcom/vdocipher/Manifest$SupplementalProperty;->schemeIdUri_:Ljava/lang/String;

    return-void
.end method

.method private setSchemeIdUriBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 5238
    invoke-static {p1}, Lcom/vdocipher/Manifest$SupplementalProperty;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 5239
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$SupplementalProperty;->schemeIdUri_:Ljava/lang/String;

    return-void
.end method

.method private setValue(Ljava/lang/String;)V
    .registers 2

    .line 5268
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5270
    iput-object p1, p0, Lcom/vdocipher/Manifest$SupplementalProperty;->value_:Ljava/lang/String;

    return-void
.end method

.method private setValueBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 5285
    invoke-static {p1}, Lcom/vdocipher/Manifest$SupplementalProperty;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 5286
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$SupplementalProperty;->value_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 5492
    sget-object p2, Lcom/vdocipher/Manifest$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_54

    .line 5535
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 5529
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 5514
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/Manifest$SupplementalProperty;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 5516
    const-class p2, Lcom/vdocipher/Manifest$SupplementalProperty;

    monitor-enter p2

    .line 5517
    :try_start_20
    sget-object p1, Lcom/vdocipher/Manifest$SupplementalProperty;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 5519
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 5522
    sput-object p1, Lcom/vdocipher/Manifest$SupplementalProperty;->PARSER:Lcom/google/protobuf/Parser;

    .line 5524
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 5511
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    return-object p1

    .line 5500
    :pswitch_36  #0x3
    const-string p1, "schemeIdUri_"

    const-string/jumbo p2, "value_"

    filled-new-array {p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    .line 5504
    const-string p2, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ"

    .line 5507
    sget-object p3, Lcom/vdocipher/Manifest$SupplementalProperty;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/Manifest$SupplementalProperty;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 5497
    :pswitch_48  #0x2
    new-instance p1, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/Manifest$SupplementalProperty$Builder;-><init>(Lcom/vdocipher/Manifest-IA;)V

    return-object p1

    .line 5494
    :pswitch_4e  #0x1
    new-instance p1, Lcom/vdocipher/Manifest$SupplementalProperty;

    invoke-direct {p1}, Lcom/vdocipher/Manifest$SupplementalProperty;-><init>()V

    return-object p1

    :pswitch_data_54
    .packed-switch 0x1
        :pswitch_4e  #00000001
        :pswitch_48  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getSchemeIdUri()Ljava/lang/String;
    .registers 2

    .line 5204
    iget-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty;->schemeIdUri_:Ljava/lang/String;

    return-object v0
.end method

.method public getSchemeIdUriBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 5213
    iget-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty;->schemeIdUri_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getValue()Ljava/lang/String;
    .registers 2

    .line 5251
    iget-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty;->value_:Ljava/lang/String;

    return-object v0
.end method

.method public getValueBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 5260
    iget-object v0, p0, Lcom/vdocipher/Manifest$SupplementalProperty;->value_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method
