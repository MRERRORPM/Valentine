# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackInfo$MetadataTableOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "MetadataTableOrBuilder"
.end annotation


# virtual methods
.method public abstract getAltHosts(I)Ljava/lang/String;
.end method

.method public abstract getAltHostsBytes(I)Lcom/google/protobuf/ByteString;
.end method

.method public abstract getAltHostsCount()I
.end method

.method public abstract getAltHostsList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getAspectRatio()F
.end method

.method public abstract getAudioOnly()Z
.end method

.method public abstract getCanSkipIntegrityCheck()Z
.end method

.method public abstract getCaptions(I)Lcom/vdocipher/PlaybackInfo$Captions;
.end method

.method public abstract getCaptionsCount()I
.end method

.method public abstract getCaptionsList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$Captions;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getCbcs()Lcom/vdocipher/PlaybackInfo$CBCSI;
.end method

.method public abstract getChapters(I)Lcom/vdocipher/PlaybackInfo$Chapters;
.end method

.method public abstract getChaptersCount()I
.end method

.method public abstract getChaptersList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$Chapters;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getCtas(I)Lcom/vdocipher/PlaybackInfo$Cta;
.end method

.method public abstract getCtasCount()I
.end method

.method public abstract getCtasList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$Cta;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getDash()Lcom/vdocipher/PlaybackInfo$DASH;
.end method

.method public abstract getDescription()Ljava/lang/String;
.end method

.method public abstract getDescriptionBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getDesiredBitrate()I
.end method

.method public abstract getDuration()I
.end method

.method public abstract getEmbedUrl()Ljava/lang/String;
.end method

.method public abstract getEmbedUrlBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getErrorMsgs(I)Lcom/vdocipher/PlaybackInfo$ErrorMessage;
.end method

.method public abstract getErrorMsgsCount()I
.end method

.method public abstract getErrorMsgsList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$ErrorMessage;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getFps()Lcom/vdocipher/PlaybackInfo$FPS;
.end method

.method public abstract getH6()Lcom/vdocipher/PlaybackInfo$H6;
.end method

.method public abstract getHostnames(I)Ljava/lang/String;
.end method

.method public abstract getHostnamesBytes(I)Lcom/google/protobuf/ByteString;
.end method

.method public abstract getHostnamesCount()I
.end method

.method public abstract getHostnamesList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getIntegrityCloudId()Ljava/lang/String;
.end method

.method public abstract getIntegrityCloudIdBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getLanguage()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
.end method

.method public abstract getPlayerConfig()Lcom/vdocipher/PlaybackInfo$PlayerConfig;
.end method

.method public abstract getPosters(I)Lcom/vdocipher/PlaybackInfo$Posters;
.end method

.method public abstract getPostersCount()I
.end method

.method public abstract getPostersList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$Posters;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getScrubbingPreviewUrl()Ljava/lang/String;
.end method

.method public abstract getScrubbingPreviewUrlBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getTech(I)Lcom/vdocipher/PlaybackInfo$TechOptions;
.end method

.method public abstract getTechCount()I
.end method

.method public abstract getTechList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$TechOptions;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getTechValue(I)I
.end method

.method public abstract getTechValueList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getTitle()Ljava/lang/String;
.end method

.method public abstract getTitleBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getVdocipherBranding()Z
.end method

.method public abstract getVersion()Ljava/lang/String;
.end method

.method public abstract getVersionBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getWhitelistHref()Ljava/lang/String;
.end method

.method public abstract getWhitelistHrefBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract hasCanSkipIntegrityCheck()Z
.end method

.method public abstract hasCbcs()Z
.end method

.method public abstract hasDash()Z
.end method

.method public abstract hasDesiredBitrate()Z
.end method

.method public abstract hasFps()Z
.end method

.method public abstract hasH6()Z
.end method

.method public abstract hasIntegrityCloudId()Z
.end method

.method public abstract hasLanguage()Z
.end method

.method public abstract hasPlayerConfig()Z
.end method

.method public abstract hasScrubbingPreviewUrl()Z
.end method

.method public abstract hasWhitelistHref()Z
.end method
