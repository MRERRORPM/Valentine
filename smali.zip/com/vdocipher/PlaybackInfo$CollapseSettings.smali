# classes14.dex

.class public final enum Lcom/vdocipher/PlaybackInfo$CollapseSettings;
.super Ljava/lang/Enum;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "CollapseSettings"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$CollapseSettings$CollapseSettingsVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/PlaybackInfo$CollapseSettings;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/PlaybackInfo$CollapseSettings;

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

.field public static final enum captionSearch:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

.field public static final captionSearch_VALUE:I = 0x3

.field public static final enum captions:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

.field public static final captions_VALUE:I = 0x5

.field public static final enum chapters:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

.field public static final chapters_VALUE:I = 0x0

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackInfo$CollapseSettings;",
            ">;"
        }
    .end annotation
.end field

.field public static final enum quality:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

.field public static final quality_VALUE:I = 0x2

.field public static final enum saveOffline:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

.field public static final saveOffline_VALUE:I = 0x4

.field public static final enum saveVideoOffline:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

.field public static final saveVideoOffline_VALUE:I = 0x6

.field public static final enum speed:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

.field public static final speed_VALUE:I = 0x1


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 11

    .line 172
    new-instance v0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    const-string v1, "chapters"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->chapters:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    .line 176
    new-instance v1, Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    const-string/jumbo v2, "speed"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->speed:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    .line 180
    new-instance v2, Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    const-string v3, "quality"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4, v4}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->quality:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    .line 184
    new-instance v3, Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    const-string v4, "captionSearch"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5, v5}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->captionSearch:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    .line 188
    new-instance v4, Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    const-string v5, "saveOffline"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6, v6}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->saveOffline:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    .line 192
    new-instance v5, Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    const-string v6, "captions"

    const/4 v7, 0x5

    invoke-direct {v5, v6, v7, v7}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->captions:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    .line 196
    new-instance v6, Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    const-string v7, "saveVideoOffline"

    const/4 v8, 0x6

    invoke-direct {v6, v7, v8, v8}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->saveVideoOffline:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    .line 197
    new-instance v7, Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    const/4 v8, 0x7

    const/4 v9, -0x1

    const-string v10, "UNRECOGNIZED"

    invoke-direct {v7, v10, v8, v9}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    .line 167
    filled-new-array/range {v0 .. v7}, [Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->$VALUES:[Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    .line 267
    new-instance v0, Lcom/vdocipher/PlaybackInfo$CollapseSettings$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$CollapseSettings$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 291
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 292
    iput p3, p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/PlaybackInfo$CollapseSettings;
    .registers 1

    packed-switch p0, :pswitch_data_1a

    const/4 p0, 0x0

    return-object p0

    .line 257
    :pswitch_5  #0x6
    sget-object p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->saveVideoOffline:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    return-object p0

    .line 256
    :pswitch_8  #0x5
    sget-object p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->captions:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    return-object p0

    .line 255
    :pswitch_b  #0x4
    sget-object p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->saveOffline:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    return-object p0

    .line 254
    :pswitch_e  #0x3
    sget-object p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->captionSearch:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    return-object p0

    .line 253
    :pswitch_11  #0x2
    sget-object p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->quality:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    return-object p0

    .line 252
    :pswitch_14  #0x1
    sget-object p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->speed:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    return-object p0

    .line 251
    :pswitch_17  #0x0
    sget-object p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->chapters:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    return-object p0

    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_17  #00000000
        :pswitch_14  #00000001
        :pswitch_11  #00000002
        :pswitch_e  #00000003
        :pswitch_b  #00000004
        :pswitch_8  #00000005
        :pswitch_5  #00000006
    .end packed-switch
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackInfo$CollapseSettings;",
            ">;"
        }
    .end annotation

    .line 264
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 277
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CollapseSettings$CollapseSettingsVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/PlaybackInfo$CollapseSettings;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 246
    invoke-static {p0}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->forNumber(I)Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$CollapseSettings;
    .registers 2

    .line 167
    const-class v0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/PlaybackInfo$CollapseSettings;
    .registers 1

    .line 167
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->$VALUES:[Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    invoke-virtual {v0}, [Lcom/vdocipher/PlaybackInfo$CollapseSettings;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 232
    sget-object v0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    if-eq p0, v0, :cond_7

    .line 236
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->value:I

    return v0

    .line 233
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
