# classes14.dex

.class public interface abstract Lcom/vdocipher/Manifest$SegmentTimelineOrBuilder;
.super Ljava/lang/Object;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "SegmentTimelineOrBuilder"
.end annotation


# virtual methods
.method public abstract getDuration()I
.end method

.method public abstract getRepeat()I
.end method
