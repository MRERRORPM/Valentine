# classes14.dex

.class public final Lcom/vdocipher/Manifest$Representation;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$RepresentationOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Representation"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$Representation$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/Manifest$Representation;",
        "Lcom/vdocipher/Manifest$Representation$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$RepresentationOrBuilder;"
    }
.end annotation


# static fields
.field public static final AUDIOCHANNELCONFIGURATION_FIELD_NUMBER:I = 0x6

.field public static final AUDIOSAMPLINGRATE_FIELD_NUMBER:I = 0x5

.field public static final BANDWIDTH_FIELD_NUMBER:I = 0x2

.field public static final BASEURL_FIELD_NUMBER:I = 0xa

.field public static final CODECS_FIELD_NUMBER:I = 0x3

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

.field public static final HEIGHT_FIELD_NUMBER:I = 0x8

.field public static final ID_FIELD_NUMBER:I = 0x1

.field public static final MIMETYPE_FIELD_NUMBER:I = 0x4

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$Representation;",
            ">;"
        }
    .end annotation
.end field

.field public static final SAR_FIELD_NUMBER:I = 0x9

.field public static final SEGMENTBASE_FIELD_NUMBER:I = 0xb

.field public static final SEGMENTTEMPLATE_FIELD_NUMBER:I = 0xc

.field public static final WIDTH_FIELD_NUMBER:I = 0x7


# instance fields
.field private audioChannelConfiguration_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/Manifest$AudioChannelConfiguration;",
            ">;"
        }
    .end annotation
.end field

.field private audioSamplingRate_:I

.field private bandwidth_:I

.field private baseUrl_:Lcom/google/protobuf/ByteString;

.field private bitField0_:I

.field private codecs_:Ljava/lang/String;

.field private height_:I

.field private id_:I

.field private mimeType_:Ljava/lang/String;

.field private sar_:Lcom/vdocipher/Manifest$AspectRatio;

.field private segmentBase_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/Manifest$SegmentBase;",
            ">;"
        }
    .end annotation
.end field

.field private segmentTemplate_:Lcom/google/protobuf/Internal$ProtobufList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "Lcom/vdocipher/Manifest$SegmentTemplate;",
            ">;"
        }
    .end annotation
.end field

.field private width_:I


# direct methods
.method static bridge synthetic -$$Nest$maddAllAudioChannelConfiguration(Lcom/vdocipher/Manifest$Representation;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->addAllAudioChannelConfiguration(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllSegmentBase(Lcom/vdocipher/Manifest$Representation;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->addAllSegmentBase(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllSegmentTemplate(Lcom/vdocipher/Manifest$Representation;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->addAllSegmentTemplate(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAudioChannelConfiguration(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$AudioChannelConfiguration;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->addAudioChannelConfiguration(ILcom/vdocipher/Manifest$AudioChannelConfiguration;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAudioChannelConfiguration(Lcom/vdocipher/Manifest$Representation;Lcom/vdocipher/Manifest$AudioChannelConfiguration;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->addAudioChannelConfiguration(Lcom/vdocipher/Manifest$AudioChannelConfiguration;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddSegmentBase(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$SegmentBase;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->addSegmentBase(ILcom/vdocipher/Manifest$SegmentBase;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddSegmentBase(Lcom/vdocipher/Manifest$Representation;Lcom/vdocipher/Manifest$SegmentBase;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->addSegmentBase(Lcom/vdocipher/Manifest$SegmentBase;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddSegmentTemplate(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$SegmentTemplate;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->addSegmentTemplate(ILcom/vdocipher/Manifest$SegmentTemplate;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddSegmentTemplate(Lcom/vdocipher/Manifest$Representation;Lcom/vdocipher/Manifest$SegmentTemplate;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->addSegmentTemplate(Lcom/vdocipher/Manifest$SegmentTemplate;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearAudioChannelConfiguration(Lcom/vdocipher/Manifest$Representation;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->clearAudioChannelConfiguration()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearAudioSamplingRate(Lcom/vdocipher/Manifest$Representation;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->clearAudioSamplingRate()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearBandwidth(Lcom/vdocipher/Manifest$Representation;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->clearBandwidth()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearBaseUrl(Lcom/vdocipher/Manifest$Representation;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->clearBaseUrl()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearCodecs(Lcom/vdocipher/Manifest$Representation;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->clearCodecs()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearHeight(Lcom/vdocipher/Manifest$Representation;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->clearHeight()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearId(Lcom/vdocipher/Manifest$Representation;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->clearId()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMimeType(Lcom/vdocipher/Manifest$Representation;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->clearMimeType()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSar(Lcom/vdocipher/Manifest$Representation;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->clearSar()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSegmentBase(Lcom/vdocipher/Manifest$Representation;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->clearSegmentBase()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSegmentTemplate(Lcom/vdocipher/Manifest$Representation;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->clearSegmentTemplate()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearWidth(Lcom/vdocipher/Manifest$Representation;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->clearWidth()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeSar(Lcom/vdocipher/Manifest$Representation;Lcom/vdocipher/Manifest$AspectRatio;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->mergeSar(Lcom/vdocipher/Manifest$AspectRatio;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveAudioChannelConfiguration(Lcom/vdocipher/Manifest$Representation;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->removeAudioChannelConfiguration(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveSegmentBase(Lcom/vdocipher/Manifest$Representation;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->removeSegmentBase(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mremoveSegmentTemplate(Lcom/vdocipher/Manifest$Representation;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->removeSegmentTemplate(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAudioChannelConfiguration(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$AudioChannelConfiguration;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->setAudioChannelConfiguration(ILcom/vdocipher/Manifest$AudioChannelConfiguration;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetAudioSamplingRate(Lcom/vdocipher/Manifest$Representation;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->setAudioSamplingRate(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetBandwidth(Lcom/vdocipher/Manifest$Representation;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->setBandwidth(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetBaseUrl(Lcom/vdocipher/Manifest$Representation;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->setBaseUrl(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCodecs(Lcom/vdocipher/Manifest$Representation;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->setCodecs(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCodecsBytes(Lcom/vdocipher/Manifest$Representation;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->setCodecsBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetHeight(Lcom/vdocipher/Manifest$Representation;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->setHeight(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetId(Lcom/vdocipher/Manifest$Representation;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->setId(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMimeType(Lcom/vdocipher/Manifest$Representation;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->setMimeType(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMimeTypeBytes(Lcom/vdocipher/Manifest$Representation;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->setMimeTypeBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSar(Lcom/vdocipher/Manifest$Representation;Lcom/vdocipher/Manifest$AspectRatio;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->setSar(Lcom/vdocipher/Manifest$AspectRatio;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSegmentBase(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$SegmentBase;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->setSegmentBase(ILcom/vdocipher/Manifest$SegmentBase;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSegmentTemplate(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$SegmentTemplate;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->setSegmentTemplate(ILcom/vdocipher/Manifest$SegmentTemplate;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetWidth(Lcom/vdocipher/Manifest$Representation;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Representation;->setWidth(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$Representation;
    .registers 1

    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 5137
    new-instance v0, Lcom/vdocipher/Manifest$Representation;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$Representation;-><init>()V

    .line 5140
    sput-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    .line 5141
    const-class v1, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 3697
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 3698
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->codecs_:Ljava/lang/String;

    .line 3699
    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->mimeType_:Ljava/lang/String;

    .line 3700
    invoke-static {}, Lcom/vdocipher/Manifest$Representation;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->audioChannelConfiguration_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 3701
    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->baseUrl_:Lcom/google/protobuf/ByteString;

    .line 3702
    invoke-static {}, Lcom/vdocipher/Manifest$Representation;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentBase_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 3703
    invoke-static {}, Lcom/vdocipher/Manifest$Representation;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentTemplate_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private addAllAudioChannelConfiguration(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$AudioChannelConfiguration;",
            ">;)V"
        }
    .end annotation

    .line 3970
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->ensureAudioChannelConfigurationIsMutable()V

    .line 3971
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->audioChannelConfiguration_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAllSegmentBase(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$SegmentBase;",
            ">;)V"
        }
    .end annotation

    .line 4205
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->ensureSegmentBaseIsMutable()V

    .line 4206
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentBase_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAllSegmentTemplate(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$SegmentTemplate;",
            ">;)V"
        }
    .end annotation

    .line 4299
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->ensureSegmentTemplateIsMutable()V

    .line 4300
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentTemplate_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAudioChannelConfiguration(ILcom/vdocipher/Manifest$AudioChannelConfiguration;)V
    .registers 4

    .line 3961
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3962
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->ensureAudioChannelConfigurationIsMutable()V

    .line 3963
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->audioChannelConfiguration_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addAudioChannelConfiguration(Lcom/vdocipher/Manifest$AudioChannelConfiguration;)V
    .registers 3

    .line 3952
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3953
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->ensureAudioChannelConfigurationIsMutable()V

    .line 3954
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->audioChannelConfiguration_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addSegmentBase(ILcom/vdocipher/Manifest$SegmentBase;)V
    .registers 4

    .line 4196
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4197
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->ensureSegmentBaseIsMutable()V

    .line 4198
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentBase_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addSegmentBase(Lcom/vdocipher/Manifest$SegmentBase;)V
    .registers 3

    .line 4187
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4188
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->ensureSegmentBaseIsMutable()V

    .line 4189
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentBase_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private addSegmentTemplate(ILcom/vdocipher/Manifest$SegmentTemplate;)V
    .registers 4

    .line 4290
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4291
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->ensureSegmentTemplateIsMutable()V

    .line 4292
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentTemplate_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method private addSegmentTemplate(Lcom/vdocipher/Manifest$SegmentTemplate;)V
    .registers 3

    .line 4281
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4282
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->ensureSegmentTemplateIsMutable()V

    .line 4283
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentTemplate_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private clearAudioChannelConfiguration()V
    .registers 2

    .line 3978
    invoke-static {}, Lcom/vdocipher/Manifest$Representation;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->audioChannelConfiguration_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearAudioSamplingRate()V
    .registers 2

    .line 3890
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    and-int/lit8 v0, v0, -0x3

    iput v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    const/4 v0, 0x0

    .line 3891
    iput v0, p0, Lcom/vdocipher/Manifest$Representation;->audioSamplingRate_:I

    return-void
.end method

.method private clearBandwidth()V
    .registers 2

    const/4 v0, 0x0

    .line 3755
    iput v0, p0, Lcom/vdocipher/Manifest$Representation;->bandwidth_:I

    return-void
.end method

.method private clearBaseUrl()V
    .registers 2

    .line 4126
    invoke-static {}, Lcom/vdocipher/Manifest$Representation;->getDefaultInstance()Lcom/vdocipher/Manifest$Representation;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getBaseUrl()Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->baseUrl_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private clearCodecs()V
    .registers 2

    .line 3799
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    and-int/lit8 v0, v0, -0x2

    iput v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    .line 3800
    invoke-static {}, Lcom/vdocipher/Manifest$Representation;->getDefaultInstance()Lcom/vdocipher/Manifest$Representation;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getCodecs()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->codecs_:Ljava/lang/String;

    return-void
.end method

.method private clearHeight()V
    .registers 2

    .line 4052
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    and-int/lit8 v0, v0, -0x9

    iput v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    const/4 v0, 0x0

    .line 4053
    iput v0, p0, Lcom/vdocipher/Manifest$Representation;->height_:I

    return-void
.end method

.method private clearId()V
    .registers 2

    const/4 v0, 0x0

    .line 3729
    iput v0, p0, Lcom/vdocipher/Manifest$Representation;->id_:I

    return-void
.end method

.method private clearMimeType()V
    .registers 2

    .line 3847
    invoke-static {}, Lcom/vdocipher/Manifest$Representation;->getDefaultInstance()Lcom/vdocipher/Manifest$Representation;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getMimeType()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->mimeType_:Ljava/lang/String;

    return-void
.end method

.method private clearSar()V
    .registers 2

    const/4 v0, 0x0

    .line 4098
    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->sar_:Lcom/vdocipher/Manifest$AspectRatio;

    .line 4099
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    and-int/lit8 v0, v0, -0x11

    iput v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    return-void
.end method

.method private clearSegmentBase()V
    .registers 2

    .line 4213
    invoke-static {}, Lcom/vdocipher/Manifest$Representation;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentBase_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearSegmentTemplate()V
    .registers 2

    .line 4307
    invoke-static {}, Lcom/vdocipher/Manifest$Representation;->emptyProtobufList()Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentTemplate_:Lcom/google/protobuf/Internal$ProtobufList;

    return-void
.end method

.method private clearWidth()V
    .registers 2

    .line 4018
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    and-int/lit8 v0, v0, -0x5

    iput v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    const/4 v0, 0x0

    .line 4019
    iput v0, p0, Lcom/vdocipher/Manifest$Representation;->width_:I

    return-void
.end method

.method private ensureAudioChannelConfigurationIsMutable()V
    .registers 3

    .line 3932
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->audioChannelConfiguration_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 3933
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 3935
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->audioChannelConfiguration_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method private ensureSegmentBaseIsMutable()V
    .registers 3

    .line 4167
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentBase_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 4168
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 4170
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentBase_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method private ensureSegmentTemplateIsMutable()V
    .registers 3

    .line 4261
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentTemplate_:Lcom/google/protobuf/Internal$ProtobufList;

    .line 4262
    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 4264
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$ProtobufList;)Lcom/google/protobuf/Internal$ProtobufList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentTemplate_:Lcom/google/protobuf/Internal$ProtobufList;

    :cond_e
    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/Manifest$Representation;
    .registers 1

    .line 5146
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    return-object v0
.end method

.method private mergeSar(Lcom/vdocipher/Manifest$AspectRatio;)V
    .registers 4

    .line 4085
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4086
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->sar_:Lcom/vdocipher/Manifest$AspectRatio;

    if-eqz v0, :cond_22

    .line 4087
    invoke-static {}, Lcom/vdocipher/Manifest$AspectRatio;->getDefaultInstance()Lcom/vdocipher/Manifest$AspectRatio;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 4088
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->sar_:Lcom/vdocipher/Manifest$AspectRatio;

    .line 4089
    invoke-static {v0}, Lcom/vdocipher/Manifest$AspectRatio;->newBuilder(Lcom/vdocipher/Manifest$AspectRatio;)Lcom/vdocipher/Manifest$AspectRatio$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/Manifest$AspectRatio$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$AspectRatio$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$AspectRatio$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$AspectRatio;

    iput-object p1, p0, Lcom/vdocipher/Manifest$Representation;->sar_:Lcom/vdocipher/Manifest$AspectRatio;

    goto :goto_24

    .line 4091
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/Manifest$Representation;->sar_:Lcom/vdocipher/Manifest$AspectRatio;

    .line 4093
    :goto_24
    iget p1, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    or-int/lit8 p1, p1, 0x10

    iput p1, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    return-void
.end method

.method public static newBuilder()Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 1

    .line 4394
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/Manifest$Representation$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/Manifest$Representation;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 2

    .line 4397
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0, p0}, Lcom/vdocipher/Manifest$Representation;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Representation$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$Representation;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 4370
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p0}, Lcom/vdocipher/Manifest$Representation;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Representation;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Representation;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 4377
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/Manifest$Representation;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Representation;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$Representation;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 4333
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Representation;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Representation;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 4340
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Representation;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/Manifest$Representation;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 4382
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Representation;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Representation;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 4389
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Representation;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$Representation;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 4357
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Representation;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Representation;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 4364
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Representation;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/Manifest$Representation;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 4320
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Representation;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Representation;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 4327
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Representation;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/Manifest$Representation;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 4345
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Representation;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Representation;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 4352
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Representation;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$Representation;",
            ">;"
        }
    .end annotation

    .line 5152
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private removeAudioChannelConfiguration(I)V
    .registers 3

    .line 3984
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->ensureAudioChannelConfigurationIsMutable()V

    .line 3985
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->audioChannelConfiguration_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private removeSegmentBase(I)V
    .registers 3

    .line 4219
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->ensureSegmentBaseIsMutable()V

    .line 4220
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentBase_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private removeSegmentTemplate(I)V
    .registers 3

    .line 4313
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->ensureSegmentTemplateIsMutable()V

    .line 4314
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentTemplate_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method private setAudioChannelConfiguration(ILcom/vdocipher/Manifest$AudioChannelConfiguration;)V
    .registers 4

    .line 3944
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3945
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->ensureAudioChannelConfigurationIsMutable()V

    .line 3946
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->audioChannelConfiguration_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setAudioSamplingRate(I)V
    .registers 3

    .line 3883
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    or-int/lit8 v0, v0, 0x2

    iput v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    .line 3884
    iput p1, p0, Lcom/vdocipher/Manifest$Representation;->audioSamplingRate_:I

    return-void
.end method

.method private setBandwidth(I)V
    .registers 2

    .line 3748
    iput p1, p0, Lcom/vdocipher/Manifest$Representation;->bandwidth_:I

    return-void
.end method

.method private setBaseUrl(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 4117
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4119
    iput-object p1, p0, Lcom/vdocipher/Manifest$Representation;->baseUrl_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private setCodecs(Ljava/lang/String;)V
    .registers 3

    .line 3791
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3792
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    or-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    .line 3793
    iput-object p1, p0, Lcom/vdocipher/Manifest$Representation;->codecs_:Ljava/lang/String;

    return-void
.end method

.method private setCodecsBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 3808
    invoke-static {p1}, Lcom/vdocipher/Manifest$Representation;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 3809
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$Representation;->codecs_:Ljava/lang/String;

    .line 3810
    iget p1, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    return-void
.end method

.method private setHeight(I)V
    .registers 3

    .line 4045
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    or-int/lit8 v0, v0, 0x8

    iput v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    .line 4046
    iput p1, p0, Lcom/vdocipher/Manifest$Representation;->height_:I

    return-void
.end method

.method private setId(I)V
    .registers 2

    .line 3722
    iput p1, p0, Lcom/vdocipher/Manifest$Representation;->id_:I

    return-void
.end method

.method private setMimeType(Ljava/lang/String;)V
    .registers 2

    .line 3838
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3840
    iput-object p1, p0, Lcom/vdocipher/Manifest$Representation;->mimeType_:Ljava/lang/String;

    return-void
.end method

.method private setMimeTypeBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 3855
    invoke-static {p1}, Lcom/vdocipher/Manifest$Representation;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 3856
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$Representation;->mimeType_:Ljava/lang/String;

    return-void
.end method

.method private setSar(Lcom/vdocipher/Manifest$AspectRatio;)V
    .registers 2

    .line 4076
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4077
    iput-object p1, p0, Lcom/vdocipher/Manifest$Representation;->sar_:Lcom/vdocipher/Manifest$AspectRatio;

    .line 4078
    iget p1, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    or-int/lit8 p1, p1, 0x10

    iput p1, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    return-void
.end method

.method private setSegmentBase(ILcom/vdocipher/Manifest$SegmentBase;)V
    .registers 4

    .line 4179
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4180
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->ensureSegmentBaseIsMutable()V

    .line 4181
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentBase_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setSegmentTemplate(ILcom/vdocipher/Manifest$SegmentTemplate;)V
    .registers 4

    .line 4273
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4274
    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation;->ensureSegmentTemplateIsMutable()V

    .line 4275
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentTemplate_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$ProtobufList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private setWidth(I)V
    .registers 3

    .line 4011
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    or-int/lit8 v0, v0, 0x4

    iput v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    .line 4012
    iput p1, p0, Lcom/vdocipher/Manifest$Representation;->width_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 22

    .line 5072
    sget-object v0, Lcom/vdocipher/Manifest$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual/range {p1 .. p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_70

    .line 5130
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0

    :pswitch_12  #0x7
    return-object v1

    :pswitch_13  #0x6
    const/4 v0, 0x1

    .line 5124
    invoke-static {v0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v0

    return-object v0

    .line 5109
    :pswitch_19  #0x5
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->PARSER:Lcom/google/protobuf/Parser;

    if-nez v0, :cond_32

    .line 5111
    const-class v1, Lcom/vdocipher/Manifest$Representation;

    monitor-enter v1

    .line 5112
    :try_start_20
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->PARSER:Lcom/google/protobuf/Parser;

    if-nez v0, :cond_2d

    .line 5114
    new-instance v0, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object v2, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-direct {v0, v2}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 5117
    sput-object v0, Lcom/vdocipher/Manifest$Representation;->PARSER:Lcom/google/protobuf/Parser;

    .line 5119
    :cond_2d
    monitor-exit v1

    return-object v0

    :catchall_2f
    move-exception v0

    monitor-exit v1
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw v0

    :cond_32
    return-object v0

    .line 5106
    :pswitch_33  #0x4
    sget-object v0, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    return-object v0

    .line 5080
    :pswitch_36  #0x3
    const-string v2, "bitField0_"

    const-string v3, "id_"

    const-string v4, "bandwidth_"

    const-string v5, "codecs_"

    const-string v6, "mimeType_"

    const-string v7, "audioSamplingRate_"

    const-string v8, "audioChannelConfiguration_"

    const-class v9, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    const-string/jumbo v10, "width_"

    const-string v11, "height_"

    const-string v12, "sar_"

    const-string v13, "baseUrl_"

    const-string v14, "segmentBase_"

    const-class v15, Lcom/vdocipher/Manifest$SegmentBase;

    const-string v16, "segmentTemplate_"

    const-class v17, Lcom/vdocipher/Manifest$SegmentTemplate;

    filled-new-array/range {v2 .. v17}, [Ljava/lang/Object;

    move-result-object v0

    .line 5098
    const-string v1, "\u0000\f\u0000\u0001\u0001\f\f\u0000\u0003\u0000\u0001\u000b\u0002\u000b\u0003ለ\u0000\u0004Ȉ\u0005ဋ\u0001\u0006\u001b\u0007ဋ\u0002\bဋ\u0003\tဉ\u0004\n\n\u000b\u001b\f\u001b"

    .line 5102
    sget-object v2, Lcom/vdocipher/Manifest$Representation;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Representation;

    invoke-static {v2, v1, v0}, Lcom/vdocipher/Manifest$Representation;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    .line 5077
    :pswitch_64  #0x2
    new-instance v0, Lcom/vdocipher/Manifest$Representation$Builder;

    invoke-direct {v0, v1}, Lcom/vdocipher/Manifest$Representation$Builder;-><init>(Lcom/vdocipher/Manifest-IA;)V

    return-object v0

    .line 5074
    :pswitch_6a  #0x1
    new-instance v0, Lcom/vdocipher/Manifest$Representation;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$Representation;-><init>()V

    return-object v0

    :pswitch_data_70
    .packed-switch 0x1
        :pswitch_6a  #00000001
        :pswitch_64  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getAudioChannelConfiguration(I)Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 3

    .line 3922
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->audioChannelConfiguration_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    return-object p1
.end method

.method public getAudioChannelConfigurationCount()I
    .registers 2

    .line 3915
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->audioChannelConfiguration_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getAudioChannelConfigurationList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$AudioChannelConfiguration;",
            ">;"
        }
    .end annotation

    .line 3901
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->audioChannelConfiguration_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getAudioChannelConfigurationOrBuilder(I)Lcom/vdocipher/Manifest$AudioChannelConfigurationOrBuilder;
    .registers 3

    .line 3929
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->audioChannelConfiguration_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$AudioChannelConfigurationOrBuilder;

    return-object p1
.end method

.method public getAudioChannelConfigurationOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/Manifest$AudioChannelConfigurationOrBuilder;",
            ">;"
        }
    .end annotation

    .line 3908
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->audioChannelConfiguration_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getAudioSamplingRate()I
    .registers 2

    .line 3876
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->audioSamplingRate_:I

    return v0
.end method

.method public getBandwidth()I
    .registers 2

    .line 3740
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->bandwidth_:I

    return v0
.end method

.method public getBaseUrl()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 4110
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->baseUrl_:Lcom/google/protobuf/ByteString;

    return-object v0
.end method

.method public getCodecs()Ljava/lang/String;
    .registers 2

    .line 3774
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->codecs_:Ljava/lang/String;

    return-object v0
.end method

.method public getCodecsBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 3783
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->codecs_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getHeight()I
    .registers 2

    .line 4038
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->height_:I

    return v0
.end method

.method public getId()I
    .registers 2

    .line 3714
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->id_:I

    return v0
.end method

.method public getMimeType()Ljava/lang/String;
    .registers 2

    .line 3821
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->mimeType_:Ljava/lang/String;

    return-object v0
.end method

.method public getMimeTypeBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 3830
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->mimeType_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSar()Lcom/vdocipher/Manifest$AspectRatio;
    .registers 2

    .line 4070
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->sar_:Lcom/vdocipher/Manifest$AspectRatio;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/Manifest$AspectRatio;->getDefaultInstance()Lcom/vdocipher/Manifest$AspectRatio;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getSegmentBase(I)Lcom/vdocipher/Manifest$SegmentBase;
    .registers 3

    .line 4157
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentBase_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$SegmentBase;

    return-object p1
.end method

.method public getSegmentBaseCount()I
    .registers 2

    .line 4150
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentBase_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getSegmentBaseList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$SegmentBase;",
            ">;"
        }
    .end annotation

    .line 4136
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentBase_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getSegmentBaseOrBuilder(I)Lcom/vdocipher/Manifest$SegmentBaseOrBuilder;
    .registers 3

    .line 4164
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentBase_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$SegmentBaseOrBuilder;

    return-object p1
.end method

.method public getSegmentBaseOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/Manifest$SegmentBaseOrBuilder;",
            ">;"
        }
    .end annotation

    .line 4143
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentBase_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getSegmentTemplate(I)Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 3

    .line 4251
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentTemplate_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object p1
.end method

.method public getSegmentTemplateCount()I
    .registers 2

    .line 4244
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentTemplate_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$ProtobufList;->size()I

    move-result v0

    return v0
.end method

.method public getSegmentTemplateList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$SegmentTemplate;",
            ">;"
        }
    .end annotation

    .line 4230
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentTemplate_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getSegmentTemplateOrBuilder(I)Lcom/vdocipher/Manifest$SegmentTemplateOrBuilder;
    .registers 3

    .line 4258
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentTemplate_:Lcom/google/protobuf/Internal$ProtobufList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$ProtobufList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$SegmentTemplateOrBuilder;

    return-object p1
.end method

.method public getSegmentTemplateOrBuilderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/vdocipher/Manifest$SegmentTemplateOrBuilder;",
            ">;"
        }
    .end annotation

    .line 4237
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation;->segmentTemplate_:Lcom/google/protobuf/Internal$ProtobufList;

    return-object v0
.end method

.method public getWidth()I
    .registers 2

    .line 4004
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->width_:I

    return v0
.end method

.method public hasAudioSamplingRate()Z
    .registers 2

    .line 3868
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasCodecs()Z
    .registers 3

    .line 3766
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_7

    return v1

    :cond_7
    const/4 v0, 0x0

    return v0
.end method

.method public hasHeight()Z
    .registers 2

    .line 4030
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    and-int/lit8 v0, v0, 0x8

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasSar()Z
    .registers 2

    .line 4063
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasWidth()Z
    .registers 2

    .line 3996
    iget v0, p0, Lcom/vdocipher/Manifest$Representation;->bitField0_:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method
