# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguageOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "ErrorMessageLanguage"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;",
        "Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguageOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

.field public static final DIRECTION_FIELD_NUMBER:I = 0x3

.field public static final HASH_FIELD_NUMBER:I = 0x2

.field public static final ID_FIELD_NUMBER:I = 0x1

.field public static final LANGUAGE_FIELD_NUMBER:I = 0x5

.field public static final NAME_FIELD_NUMBER:I = 0x4

.field private static volatile PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private direction_:I

.field private hash_:Ljava/lang/String;

.field private id_:Ljava/lang/String;

.field private language_:Ljava/lang/String;

.field private name_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$mclearDirection(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->clearDirection()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearHash(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->clearHash()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearId(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->clearId()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLanguage(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->clearLanguage()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearName(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->clearName()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDirection(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Lcom/vdocipher/PlaybackInfo$MessageDirection;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->setDirection(Lcom/vdocipher/PlaybackInfo$MessageDirection;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDirectionValue(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->setDirectionValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetHash(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->setHash(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetHashBytes(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->setHashBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetId(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->setId(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIdBytes(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->setIdBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLanguage(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->setLanguage(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLanguageBytes(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->setLanguageBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetName(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->setName(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetNameBytes(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->setNameBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 10664
    new-instance v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;-><init>()V

    .line 10667
    sput-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    .line 10668
    const-class v1, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 10029
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 10030
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->id_:Ljava/lang/String;

    .line 10031
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->hash_:Ljava/lang/String;

    .line 10032
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->name_:Ljava/lang/String;

    .line 10033
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->language_:Ljava/lang/String;

    return-void
.end method

.method private clearDirection()V
    .registers 2

    const/4 v0, 0x0

    .line 10168
    iput v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->direction_:I

    return-void
.end method

.method private clearHash()V
    .registers 2

    .line 10116
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getHash()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->hash_:Ljava/lang/String;

    return-void
.end method

.method private clearId()V
    .registers 2

    .line 10069
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getId()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->id_:Ljava/lang/String;

    return-void
.end method

.method private clearLanguage()V
    .registers 2

    .line 10252
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getLanguage()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->language_:Ljava/lang/String;

    return-void
.end method

.method private clearName()V
    .registers 2

    .line 10205
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getName()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->name_:Ljava/lang/String;

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 1

    .line 10673
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 1

    .line 10342
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;
    .registers 2

    .line 10345
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10318
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10325
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10281
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10288
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10330
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10337
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10305
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 10312
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10268
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10275
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10293
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 10300
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;",
            ">;"
        }
    .end annotation

    .line 10679
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setDirection(Lcom/vdocipher/PlaybackInfo$MessageDirection;)V
    .registers 2

    .line 10160
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$MessageDirection;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->direction_:I

    return-void
.end method

.method private setDirectionValue(I)V
    .registers 2

    .line 10153
    iput p1, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->direction_:I

    return-void
.end method

.method private setHash(Ljava/lang/String;)V
    .registers 2

    .line 10107
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10109
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->hash_:Ljava/lang/String;

    return-void
.end method

.method private setHashBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 10124
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 10125
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->hash_:Ljava/lang/String;

    return-void
.end method

.method private setId(Ljava/lang/String;)V
    .registers 2

    .line 10060
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10062
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->id_:Ljava/lang/String;

    return-void
.end method

.method private setIdBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 10077
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 10078
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->id_:Ljava/lang/String;

    return-void
.end method

.method private setLanguage(Ljava/lang/String;)V
    .registers 2

    .line 10243
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10245
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->language_:Ljava/lang/String;

    return-void
.end method

.method private setLanguageBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 10260
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 10261
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->language_:Ljava/lang/String;

    return-void
.end method

.method private setName(Ljava/lang/String;)V
    .registers 2

    .line 10196
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10198
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->name_:Ljava/lang/String;

    return-void
.end method

.method private setNameBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 10213
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 10214
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->name_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 10611
    sget-object p2, Lcom/vdocipher/PlaybackInfo$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_5a

    .line 10657
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 10651
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 10636
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 10638
    const-class p2, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    monitor-enter p2

    .line 10639
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 10641
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 10644
    sput-object p1, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->PARSER:Lcom/google/protobuf/Parser;

    .line 10646
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 10633
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    return-object p1

    .line 10619
    :pswitch_36  #0x3
    const-string p1, "id_"

    const-string p2, "hash_"

    const-string p3, "direction_"

    const-string v0, "name_"

    const-string v1, "language_"

    filled-new-array {p1, p2, p3, v0, v1}, [Ljava/lang/Object;

    move-result-object p1

    .line 10626
    const-string p2, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003\f\u0004Ȉ\u0005Ȉ"

    .line 10629
    sget-object p3, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 10616
    :pswitch_4d  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;-><init>(Lcom/vdocipher/PlaybackInfo-IA;)V

    return-object p1

    .line 10613
    :pswitch_53  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;-><init>()V

    return-object p1

    nop

    :pswitch_data_5a
    .packed-switch 0x1
        :pswitch_53  #00000001
        :pswitch_4d  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getDirection()Lcom/vdocipher/PlaybackInfo$MessageDirection;
    .registers 2

    .line 10145
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->direction_:I

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$MessageDirection;->forNumber(I)Lcom/vdocipher/PlaybackInfo$MessageDirection;

    move-result-object v0

    if-nez v0, :cond_a

    .line 10146
    sget-object v0, Lcom/vdocipher/PlaybackInfo$MessageDirection;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$MessageDirection;

    :cond_a
    return-object v0
.end method

.method public getDirectionValue()I
    .registers 2

    .line 10137
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->direction_:I

    return v0
.end method

.method public getHash()Ljava/lang/String;
    .registers 2

    .line 10090
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->hash_:Ljava/lang/String;

    return-object v0
.end method

.method public getHashBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 10099
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->hash_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getId()Ljava/lang/String;
    .registers 2

    .line 10043
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->id_:Ljava/lang/String;

    return-object v0
.end method

.method public getIdBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 10052
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->id_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getLanguage()Ljava/lang/String;
    .registers 2

    .line 10226
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->language_:Ljava/lang/String;

    return-object v0
.end method

.method public getLanguageBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 10235
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->language_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getName()Ljava/lang/String;
    .registers 2

    .line 10179
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->name_:Ljava/lang/String;

    return-object v0
.end method

.method public getNameBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 10188
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->name_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method
