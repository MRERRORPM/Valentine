# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$EmbedInfoOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$EmbedInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$EmbedInfo;",
        "Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$EmbedInfoOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 1955
    invoke-static {}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$EmbedInfo;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearAuth()Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 2

    .line 2136
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2137
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$mclearAuth(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V

    return-object p0
.end method

.method public clearAuthType()Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 2

    .line 2000
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2001
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$mclearAuthType(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V

    return-object p0
.end method

.method public clearAutoplay()Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 2

    .line 2221
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2222
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$mclearAutoplay(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V

    return-object p0
.end method

.method public clearBufferingGoal()Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 2

    .line 2249
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2250
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$mclearBufferingGoal(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V

    return-object p0
.end method

.method public clearLoop()Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 2

    .line 2277
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2278
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$mclearLoop(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V

    return-object p0
.end method

.method public clearPlaybackInfo()Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 2

    .line 2038
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2039
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$mclearPlaybackInfo(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V

    return-object p0
.end method

.method public clearPlugin()Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 2

    .line 2315
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2316
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$mclearPlugin(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V

    return-object p0
.end method

.method public clearSourceType()Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 2

    .line 2193
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2194
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$mclearSourceType(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V

    return-object p0
.end method

.method public clearTheme()Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 2

    .line 2087
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2088
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$mclearTheme(Lcom/vdocipher/PlaybackSession$EmbedInfo;)V

    return-object p0
.end method

.method public getAuth()Ljava/lang/String;
    .registers 2

    .line 2109
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getAuth()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getAuthBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 2118
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getAuthBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getAuthType()Lcom/vdocipher/PlaybackSession$AuthType;
    .registers 2

    .line 1983
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getAuthType()Lcom/vdocipher/PlaybackSession$AuthType;

    move-result-object v0

    return-object v0
.end method

.method public getAuthTypeValue()I
    .registers 2

    .line 1965
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getAuthTypeValue()I

    move-result v0

    return v0
.end method

.method public getAutoplay()Z
    .registers 2

    .line 2204
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getAutoplay()Z

    move-result v0

    return v0
.end method

.method public getBufferingGoal()I
    .registers 2

    .line 2232
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getBufferingGoal()I

    move-result v0

    return v0
.end method

.method public getLoop()Z
    .registers 2

    .line 2260
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getLoop()Z

    move-result v0

    return v0
.end method

.method public getPlaybackInfo()Ljava/lang/String;
    .registers 2

    .line 2011
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getPlaybackInfo()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getPlaybackInfoBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 2020
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getPlaybackInfoBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getPlugin()Ljava/lang/String;
    .registers 2

    .line 2288
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getPlugin()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getPluginBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 2297
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getPluginBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSourceType()Lcom/vdocipher/PlaybackSession$SourceType;
    .registers 2

    .line 2176
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getSourceType()Lcom/vdocipher/PlaybackSession$SourceType;

    move-result-object v0

    return-object v0
.end method

.method public getSourceTypeValue()I
    .registers 2

    .line 2158
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getSourceTypeValue()I

    move-result v0

    return v0
.end method

.method public getTheme()Ljava/lang/String;
    .registers 2

    .line 2060
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getTheme()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getThemeBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 2069
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->getThemeBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setAuth(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 3

    .line 2127
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2128
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$msetAuth(Lcom/vdocipher/PlaybackSession$EmbedInfo;Ljava/lang/String;)V

    return-object p0
.end method

.method public setAuthBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 3

    .line 2147
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2148
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$msetAuthBytes(Lcom/vdocipher/PlaybackSession$EmbedInfo;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setAuthType(Lcom/vdocipher/PlaybackSession$AuthType;)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 3

    .line 1991
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 1992
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$msetAuthType(Lcom/vdocipher/PlaybackSession$EmbedInfo;Lcom/vdocipher/PlaybackSession$AuthType;)V

    return-object p0
.end method

.method public setAuthTypeValue(I)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 3

    .line 1973
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 1974
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$msetAuthTypeValue(Lcom/vdocipher/PlaybackSession$EmbedInfo;I)V

    return-object p0
.end method

.method public setAutoplay(Z)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 3

    .line 2212
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2213
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$msetAutoplay(Lcom/vdocipher/PlaybackSession$EmbedInfo;Z)V

    return-object p0
.end method

.method public setBufferingGoal(I)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 3

    .line 2240
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2241
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$msetBufferingGoal(Lcom/vdocipher/PlaybackSession$EmbedInfo;I)V

    return-object p0
.end method

.method public setLoop(Z)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 3

    .line 2268
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2269
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$msetLoop(Lcom/vdocipher/PlaybackSession$EmbedInfo;Z)V

    return-object p0
.end method

.method public setPlaybackInfo(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 3

    .line 2029
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2030
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$msetPlaybackInfo(Lcom/vdocipher/PlaybackSession$EmbedInfo;Ljava/lang/String;)V

    return-object p0
.end method

.method public setPlaybackInfoBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 3

    .line 2049
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2050
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$msetPlaybackInfoBytes(Lcom/vdocipher/PlaybackSession$EmbedInfo;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setPlugin(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 3

    .line 2306
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2307
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$msetPlugin(Lcom/vdocipher/PlaybackSession$EmbedInfo;Ljava/lang/String;)V

    return-object p0
.end method

.method public setPluginBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 3

    .line 2326
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2327
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$msetPluginBytes(Lcom/vdocipher/PlaybackSession$EmbedInfo;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setSourceType(Lcom/vdocipher/PlaybackSession$SourceType;)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 3

    .line 2184
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2185
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$msetSourceType(Lcom/vdocipher/PlaybackSession$EmbedInfo;Lcom/vdocipher/PlaybackSession$SourceType;)V

    return-object p0
.end method

.method public setSourceTypeValue(I)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 3

    .line 2166
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2167
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$msetSourceTypeValue(Lcom/vdocipher/PlaybackSession$EmbedInfo;I)V

    return-object p0
.end method

.method public setTheme(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 3

    .line 2078
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2079
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$msetTheme(Lcom/vdocipher/PlaybackSession$EmbedInfo;Ljava/lang/String;)V

    return-object p0
.end method

.method public setThemeBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;
    .registers 3

    .line 2098
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->copyOnWrite()V

    .line 2099
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$EmbedInfo$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$EmbedInfo;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$EmbedInfo;->-$$Nest$msetThemeBytes(Lcom/vdocipher/PlaybackSession$EmbedInfo;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
