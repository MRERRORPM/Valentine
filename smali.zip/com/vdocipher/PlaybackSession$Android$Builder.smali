# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Android$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$AndroidOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$Android;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$Android;",
        "Lcom/vdocipher/PlaybackSession$Android$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$AndroidOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 12733
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Android;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public addAllDecoder(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackSession$Decoder;",
            ">;)",
            "Lcom/vdocipher/PlaybackSession$Android$Builder;"
        }
    .end annotation

    .line 13203
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13204
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$maddAllDecoder(Lcom/vdocipher/PlaybackSession$Android;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addDecoder(ILcom/vdocipher/PlaybackSession$Decoder$Builder;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 4

    .line 13193
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13194
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    .line 13195
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackSession$Decoder;

    .line 13194
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$maddDecoder(Lcom/vdocipher/PlaybackSession$Android;ILcom/vdocipher/PlaybackSession$Decoder;)V

    return-object p0
.end method

.method public addDecoder(ILcom/vdocipher/PlaybackSession$Decoder;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 4

    .line 13175
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13176
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$maddDecoder(Lcom/vdocipher/PlaybackSession$Android;ILcom/vdocipher/PlaybackSession$Decoder;)V

    return-object p0
.end method

.method public addDecoder(Lcom/vdocipher/PlaybackSession$Decoder$Builder;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 13184
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13185
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$maddDecoder(Lcom/vdocipher/PlaybackSession$Android;Lcom/vdocipher/PlaybackSession$Decoder;)V

    return-object p0
.end method

.method public addDecoder(Lcom/vdocipher/PlaybackSession$Decoder;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 13166
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13167
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$maddDecoder(Lcom/vdocipher/PlaybackSession$Android;Lcom/vdocipher/PlaybackSession$Decoder;)V

    return-object p0
.end method

.method public clearApiLevel()Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 2

    .line 12858
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12859
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$mclearApiLevel(Lcom/vdocipher/PlaybackSession$Android;)V

    return-object p0
.end method

.method public clearDecoder()Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 2

    .line 13211
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13212
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$mclearDecoder(Lcom/vdocipher/PlaybackSession$Android;)V

    return-object p0
.end method

.method public clearDevice()Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 2

    .line 12896
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12897
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$mclearDevice(Lcom/vdocipher/PlaybackSession$Android;)V

    return-object p0
.end method

.method public clearIsDebug()Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 2

    .line 13033
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13034
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$mclearIsDebug(Lcom/vdocipher/PlaybackSession$Android;)V

    return-object p0
.end method

.method public clearIsSigned()Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 2

    .line 13061
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13062
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$mclearIsSigned(Lcom/vdocipher/PlaybackSession$Android;)V

    return-object p0
.end method

.method public clearLastBootTime()Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 2

    .line 13089
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13090
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$mclearLastBootTime(Lcom/vdocipher/PlaybackSession$Android;)V

    return-object p0
.end method

.method public clearLastOSUpdateTime()Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 2

    .line 13117
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13118
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$mclearLastOSUpdateTime(Lcom/vdocipher/PlaybackSession$Android;)V

    return-object p0
.end method

.method public clearManufacturer()Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 2

    .line 12994
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12995
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$mclearManufacturer(Lcom/vdocipher/PlaybackSession$Android;)V

    return-object p0
.end method

.method public clearPrimaryAbi()Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 2

    .line 12770
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12771
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$mclearPrimaryAbi(Lcom/vdocipher/PlaybackSession$Android;)V

    return-object p0
.end method

.method public clearProduct()Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 2

    .line 12945
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12946
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$mclearProduct(Lcom/vdocipher/PlaybackSession$Android;)V

    return-object p0
.end method

.method public clearRefVersion()Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 2

    .line 13257
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13258
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$mclearRefVersion(Lcom/vdocipher/PlaybackSession$Android;)V

    return-object p0
.end method

.method public clearSecondaryAbi()Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 2

    .line 12819
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12820
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$mclearSecondaryAbi(Lcom/vdocipher/PlaybackSession$Android;)V

    return-object p0
.end method

.method public getApiLevel()I
    .registers 2

    .line 12841
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getApiLevel()I

    move-result v0

    return v0
.end method

.method public getDecoder(I)Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 3

    .line 13141
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->getDecoder(I)Lcom/vdocipher/PlaybackSession$Decoder;

    move-result-object p1

    return-object p1
.end method

.method public getDecoderCount()I
    .registers 2

    .line 13135
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getDecoderCount()I

    move-result v0

    return v0
.end method

.method public getDecoderList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackSession$Decoder;",
            ">;"
        }
    .end annotation

    .line 13127
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    .line 13128
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getDecoderList()Ljava/util/List;

    move-result-object v0

    .line 13127
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getDevice()Ljava/lang/String;
    .registers 2

    .line 12869
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getDevice()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getDeviceBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 12878
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getDeviceBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getIsDebug()Z
    .registers 2

    .line 13016
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getIsDebug()Z

    move-result v0

    return v0
.end method

.method public getIsSigned()Z
    .registers 2

    .line 13044
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getIsSigned()Z

    move-result v0

    return v0
.end method

.method public getLastBootTime()I
    .registers 2

    .line 13072
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getLastBootTime()I

    move-result v0

    return v0
.end method

.method public getLastOSUpdateTime()I
    .registers 2

    .line 13100
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getLastOSUpdateTime()I

    move-result v0

    return v0
.end method

.method public getManufacturer()Ljava/lang/String;
    .registers 2

    .line 12967
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getManufacturer()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getManufacturerBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 12976
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getManufacturerBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getPrimaryAbi()Ljava/lang/String;
    .registers 2

    .line 12743
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getPrimaryAbi()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getPrimaryAbiBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 12752
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getPrimaryAbiBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getProduct()Ljava/lang/String;
    .registers 2

    .line 12918
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getProduct()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getProductBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 12927
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getProductBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getRefVersion()Ljava/lang/String;
    .registers 2

    .line 13230
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getRefVersion()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getRefVersionBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 13239
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getRefVersionBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSecondaryAbi()Ljava/lang/String;
    .registers 2

    .line 12792
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getSecondaryAbi()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getSecondaryAbiBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 12801
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Android;->getSecondaryAbiBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public removeDecoder(I)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 13219
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13220
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$mremoveDecoder(Lcom/vdocipher/PlaybackSession$Android;I)V

    return-object p0
.end method

.method public setApiLevel(I)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 12849
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12850
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetApiLevel(Lcom/vdocipher/PlaybackSession$Android;I)V

    return-object p0
.end method

.method public setDecoder(ILcom/vdocipher/PlaybackSession$Decoder$Builder;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 4

    .line 13157
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13158
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    .line 13159
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackSession$Decoder$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/PlaybackSession$Decoder;

    .line 13158
    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetDecoder(Lcom/vdocipher/PlaybackSession$Android;ILcom/vdocipher/PlaybackSession$Decoder;)V

    return-object p0
.end method

.method public setDecoder(ILcom/vdocipher/PlaybackSession$Decoder;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 4

    .line 13148
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13149
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetDecoder(Lcom/vdocipher/PlaybackSession$Android;ILcom/vdocipher/PlaybackSession$Decoder;)V

    return-object p0
.end method

.method public setDevice(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 12887
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12888
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetDevice(Lcom/vdocipher/PlaybackSession$Android;Ljava/lang/String;)V

    return-object p0
.end method

.method public setDeviceBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 12907
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12908
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetDeviceBytes(Lcom/vdocipher/PlaybackSession$Android;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setIsDebug(Z)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 13024
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13025
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetIsDebug(Lcom/vdocipher/PlaybackSession$Android;Z)V

    return-object p0
.end method

.method public setIsSigned(Z)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 13052
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13053
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetIsSigned(Lcom/vdocipher/PlaybackSession$Android;Z)V

    return-object p0
.end method

.method public setLastBootTime(I)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 13080
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13081
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetLastBootTime(Lcom/vdocipher/PlaybackSession$Android;I)V

    return-object p0
.end method

.method public setLastOSUpdateTime(I)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 13108
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13109
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetLastOSUpdateTime(Lcom/vdocipher/PlaybackSession$Android;I)V

    return-object p0
.end method

.method public setManufacturer(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 12985
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12986
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetManufacturer(Lcom/vdocipher/PlaybackSession$Android;Ljava/lang/String;)V

    return-object p0
.end method

.method public setManufacturerBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 13005
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13006
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetManufacturerBytes(Lcom/vdocipher/PlaybackSession$Android;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setPrimaryAbi(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 12761
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12762
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetPrimaryAbi(Lcom/vdocipher/PlaybackSession$Android;Ljava/lang/String;)V

    return-object p0
.end method

.method public setPrimaryAbiBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 12781
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12782
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetPrimaryAbiBytes(Lcom/vdocipher/PlaybackSession$Android;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setProduct(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 12936
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12937
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetProduct(Lcom/vdocipher/PlaybackSession$Android;Ljava/lang/String;)V

    return-object p0
.end method

.method public setProductBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 12956
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12957
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetProductBytes(Lcom/vdocipher/PlaybackSession$Android;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setRefVersion(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 13248
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13249
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetRefVersion(Lcom/vdocipher/PlaybackSession$Android;Ljava/lang/String;)V

    return-object p0
.end method

.method public setRefVersionBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 13268
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 13269
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetRefVersionBytes(Lcom/vdocipher/PlaybackSession$Android;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setSecondaryAbi(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 12810
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12811
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetSecondaryAbi(Lcom/vdocipher/PlaybackSession$Android;Ljava/lang/String;)V

    return-object p0
.end method

.method public setSecondaryAbiBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Android$Builder;
    .registers 3

    .line 12830
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$Android$Builder;->copyOnWrite()V

    .line 12831
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Android$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$Android;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$Android;->-$$Nest$msetSecondaryAbiBytes(Lcom/vdocipher/PlaybackSession$Android;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
