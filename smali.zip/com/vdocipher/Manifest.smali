# classes14.dex

.class public final Lcom/vdocipher/Manifest;
.super Ljava/lang/Object;
.source "Manifest.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$MPDTable;,
        Lcom/vdocipher/Manifest$MPDTableOrBuilder;,
        Lcom/vdocipher/Manifest$Period;,
        Lcom/vdocipher/Manifest$PeriodOrBuilder;,
        Lcom/vdocipher/Manifest$AdaptationSet;,
        Lcom/vdocipher/Manifest$AdaptationSetOrBuilder;,
        Lcom/vdocipher/Manifest$Role;,
        Lcom/vdocipher/Manifest$RoleOrBuilder;,
        Lcom/vdocipher/Manifest$SupplementalProperty;,
        Lcom/vdocipher/Manifest$SupplementalPropertyOrBuilder;,
        Lcom/vdocipher/Manifest$Representation;,
        Lcom/vdocipher/Manifest$RepresentationOrBuilder;,
        Lcom/vdocipher/Manifest$SegmentTemplate;,
        Lcom/vdocipher/Manifest$SegmentTemplateOrBuilder;,
        Lcom/vdocipher/Manifest$SegmentTimeline;,
        Lcom/vdocipher/Manifest$SegmentTimelineOrBuilder;,
        Lcom/vdocipher/Manifest$SegmentBase;,
        Lcom/vdocipher/Manifest$SegmentBaseOrBuilder;,
        Lcom/vdocipher/Manifest$Initialization;,
        Lcom/vdocipher/Manifest$InitializationOrBuilder;,
        Lcom/vdocipher/Manifest$AudioChannelConfiguration;,
        Lcom/vdocipher/Manifest$AudioChannelConfigurationOrBuilder;,
        Lcom/vdocipher/Manifest$ContentProtection;,
        Lcom/vdocipher/Manifest$ContentProtectionOrBuilder;,
        Lcom/vdocipher/Manifest$AspectRatio;,
        Lcom/vdocipher/Manifest$AspectRatioOrBuilder;,
        Lcom/vdocipher/Manifest$MPDType;,
        Lcom/vdocipher/Manifest$ContentType;,
        Lcom/vdocipher/Manifest$CpSchemeIdUri;,
        Lcom/vdocipher/Manifest$ContentProtectionValue;
    }
.end annotation


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static registerAllExtensions(Lcom/google/protobuf/ExtensionRegistryLite;)V
    .registers 1

    return-void
.end method
