# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$H6;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$H6OrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "H6"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$H6$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackInfo$H6;",
        "Lcom/vdocipher/PlaybackInfo$H6$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$H6OrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

.field public static final MANIFEST_FIELD_NUMBER:I = 0x1

.field private static volatile PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$H6;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private manifest_:Lcom/google/protobuf/ByteString;


# direct methods
.method static bridge synthetic -$$Nest$mclearManifest(Lcom/vdocipher/PlaybackInfo$H6;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$H6;->clearManifest()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetManifest(Lcom/vdocipher/PlaybackInfo$H6;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$H6;->setManifest(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$H6;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 9520
    new-instance v0, Lcom/vdocipher/PlaybackInfo$H6;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$H6;-><init>()V

    .line 9523
    sput-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    .line 9524
    const-class v1, Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 9310
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 9311
    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$H6;->manifest_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private clearManifest()V
    .registers 2

    .line 9337
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$H6;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$H6;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$H6;->getManifest()Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$H6;->manifest_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackInfo$H6;
    .registers 1

    .line 9529
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackInfo$H6$Builder;
    .registers 1

    .line 9417
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$H6;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$H6$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackInfo$H6;)Lcom/vdocipher/PlaybackInfo$H6$Builder;
    .registers 2

    .line 9420
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$H6;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$H6$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$H6;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9393
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackInfo$H6;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$H6;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$H6;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9400
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackInfo$H6;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$H6;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$H6;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9356
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$H6;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$H6;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9363
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$H6;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackInfo$H6;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9405
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$H6;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$H6;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9412
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$H6;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$H6;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9380
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$H6;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$H6;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 9387
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$H6;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackInfo$H6;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9343
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$H6;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$H6;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9350
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$H6;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackInfo$H6;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9368
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$H6;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$H6;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 9375
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$H6;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$H6;",
            ">;"
        }
    .end annotation

    .line 9535
    sget-object v0, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$H6;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setManifest(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 9328
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9330
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$H6;->manifest_:Lcom/google/protobuf/ByteString;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 9472
    sget-object p2, Lcom/vdocipher/PlaybackInfo$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_52

    .line 9513
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 9507
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 9492
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackInfo$H6;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 9494
    const-class p2, Lcom/vdocipher/PlaybackInfo$H6;

    monitor-enter p2

    .line 9495
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackInfo$H6;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 9497
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 9500
    sput-object p1, Lcom/vdocipher/PlaybackInfo$H6;->PARSER:Lcom/google/protobuf/Parser;

    .line 9502
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 9489
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    return-object p1

    .line 9480
    :pswitch_36  #0x3
    const-string p1, "manifest_"

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    .line 9483
    const-string p2, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\n"

    .line 9485
    sget-object p3, Lcom/vdocipher/PlaybackInfo$H6;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$H6;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackInfo$H6;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 9477
    :pswitch_45  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackInfo$H6$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackInfo$H6$Builder;-><init>(Lcom/vdocipher/PlaybackInfo-IA;)V

    return-object p1

    .line 9474
    :pswitch_4b  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackInfo$H6;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackInfo$H6;-><init>()V

    return-object p1

    nop

    :pswitch_data_52
    .packed-switch 0x1
        :pswitch_4b  #00000001
        :pswitch_45  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getManifest()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9321
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$H6;->manifest_:Lcom/google/protobuf/ByteString;

    return-object v0
.end method
