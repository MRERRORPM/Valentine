# classes14.dex

.class public final Lcom/vdocipher/Manifest$ContentProtection$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$ContentProtectionOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest$ContentProtection;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/Manifest$ContentProtection;",
        "Lcom/vdocipher/Manifest$ContentProtection$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$ContentProtectionOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 1014
    invoke-static {}, Lcom/vdocipher/Manifest$ContentProtection;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$ContentProtection;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/Manifest-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/Manifest$ContentProtection$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearCencDefaultKid()Lcom/vdocipher/Manifest$ContentProtection$Builder;
    .registers 2

    .line 1149
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$ContentProtection$Builder;->copyOnWrite()V

    .line 1150
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0}, Lcom/vdocipher/Manifest$ContentProtection;->-$$Nest$mclearCencDefaultKid(Lcom/vdocipher/Manifest$ContentProtection;)V

    return-object p0
.end method

.method public clearPssh()Lcom/vdocipher/Manifest$ContentProtection$Builder;
    .registers 2

    .line 1185
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$ContentProtection$Builder;->copyOnWrite()V

    .line 1186
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0}, Lcom/vdocipher/Manifest$ContentProtection;->-$$Nest$mclearPssh(Lcom/vdocipher/Manifest$ContentProtection;)V

    return-object p0
.end method

.method public clearSchemeIdUri()Lcom/vdocipher/Manifest$ContentProtection$Builder;
    .registers 2

    .line 1113
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$ContentProtection$Builder;->copyOnWrite()V

    .line 1114
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0}, Lcom/vdocipher/Manifest$ContentProtection;->-$$Nest$mclearSchemeIdUri(Lcom/vdocipher/Manifest$ContentProtection;)V

    return-object p0
.end method

.method public clearValue()Lcom/vdocipher/Manifest$ContentProtection$Builder;
    .registers 2

    .line 1067
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$ContentProtection$Builder;->copyOnWrite()V

    .line 1068
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0}, Lcom/vdocipher/Manifest$ContentProtection;->-$$Nest$mclearValue(Lcom/vdocipher/Manifest$ContentProtection;)V

    return-object p0
.end method

.method public getCencDefaultKid()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 1132
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$ContentProtection;->getCencDefaultKid()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getPssh()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 1168
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$ContentProtection;->getPssh()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSchemeIdUri()Lcom/vdocipher/Manifest$CpSchemeIdUri;
    .registers 2

    .line 1096
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$ContentProtection;->getSchemeIdUri()Lcom/vdocipher/Manifest$CpSchemeIdUri;

    move-result-object v0

    return-object v0
.end method

.method public getSchemeIdUriValue()I
    .registers 2

    .line 1078
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$ContentProtection;->getSchemeIdUriValue()I

    move-result v0

    return v0
.end method

.method public getValue()Lcom/vdocipher/Manifest$ContentProtectionValue;
    .registers 2

    .line 1050
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$ContentProtection;->getValue()Lcom/vdocipher/Manifest$ContentProtectionValue;

    move-result-object v0

    return-object v0
.end method

.method public getValueValue()I
    .registers 2

    .line 1032
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$ContentProtection;->getValueValue()I

    move-result v0

    return v0
.end method

.method public hasCencDefaultKid()Z
    .registers 2

    .line 1124
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$ContentProtection;->hasCencDefaultKid()Z

    move-result v0

    return v0
.end method

.method public hasPssh()Z
    .registers 2

    .line 1160
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$ContentProtection;->hasPssh()Z

    move-result v0

    return v0
.end method

.method public hasValue()Z
    .registers 2

    .line 1024
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$ContentProtection;->hasValue()Z

    move-result v0

    return v0
.end method

.method public setCencDefaultKid(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$ContentProtection$Builder;
    .registers 3

    .line 1140
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$ContentProtection$Builder;->copyOnWrite()V

    .line 1141
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$ContentProtection;->-$$Nest$msetCencDefaultKid(Lcom/vdocipher/Manifest$ContentProtection;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setPssh(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$ContentProtection$Builder;
    .registers 3

    .line 1176
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$ContentProtection$Builder;->copyOnWrite()V

    .line 1177
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$ContentProtection;->-$$Nest$msetPssh(Lcom/vdocipher/Manifest$ContentProtection;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setSchemeIdUri(Lcom/vdocipher/Manifest$CpSchemeIdUri;)Lcom/vdocipher/Manifest$ContentProtection$Builder;
    .registers 3

    .line 1104
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$ContentProtection$Builder;->copyOnWrite()V

    .line 1105
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$ContentProtection;->-$$Nest$msetSchemeIdUri(Lcom/vdocipher/Manifest$ContentProtection;Lcom/vdocipher/Manifest$CpSchemeIdUri;)V

    return-object p0
.end method

.method public setSchemeIdUriValue(I)Lcom/vdocipher/Manifest$ContentProtection$Builder;
    .registers 3

    .line 1086
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$ContentProtection$Builder;->copyOnWrite()V

    .line 1087
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$ContentProtection;->-$$Nest$msetSchemeIdUriValue(Lcom/vdocipher/Manifest$ContentProtection;I)V

    return-object p0
.end method

.method public setValue(Lcom/vdocipher/Manifest$ContentProtectionValue;)Lcom/vdocipher/Manifest$ContentProtection$Builder;
    .registers 3

    .line 1058
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$ContentProtection$Builder;->copyOnWrite()V

    .line 1059
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$ContentProtection;->-$$Nest$msetValue(Lcom/vdocipher/Manifest$ContentProtection;Lcom/vdocipher/Manifest$ContentProtectionValue;)V

    return-object p0
.end method

.method public setValueValue(I)Lcom/vdocipher/Manifest$ContentProtection$Builder;
    .registers 3

    .line 1040
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$ContentProtection$Builder;->copyOnWrite()V

    .line 1041
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$ContentProtection;->-$$Nest$msetValueValue(Lcom/vdocipher/Manifest$ContentProtection;I)V

    return-object p0
.end method
