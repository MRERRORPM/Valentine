# classes14.dex

.class public final Lcom/vdocipher/Manifest$ContentProtection;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$ContentProtectionOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "ContentProtection"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$ContentProtection$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/Manifest$ContentProtection;",
        "Lcom/vdocipher/Manifest$ContentProtection$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$ContentProtectionOrBuilder;"
    }
.end annotation


# static fields
.field public static final CENCDEFAULTKID_FIELD_NUMBER:I = 0x3

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$ContentProtection;",
            ">;"
        }
    .end annotation
.end field

.field public static final PSSH_FIELD_NUMBER:I = 0x4

.field public static final SCHEMEIDURI_FIELD_NUMBER:I = 0x2

.field public static final VALUE_FIELD_NUMBER:I = 0x1


# instance fields
.field private bitField0_:I

.field private cencDefaultKid_:Lcom/google/protobuf/ByteString;

.field private pssh_:Lcom/google/protobuf/ByteString;

.field private schemeIdUri_:I

.field private value_:I


# direct methods
.method static bridge synthetic -$$Nest$mclearCencDefaultKid(Lcom/vdocipher/Manifest$ContentProtection;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$ContentProtection;->clearCencDefaultKid()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPssh(Lcom/vdocipher/Manifest$ContentProtection;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$ContentProtection;->clearPssh()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSchemeIdUri(Lcom/vdocipher/Manifest$ContentProtection;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$ContentProtection;->clearSchemeIdUri()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearValue(Lcom/vdocipher/Manifest$ContentProtection;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$ContentProtection;->clearValue()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCencDefaultKid(Lcom/vdocipher/Manifest$ContentProtection;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$ContentProtection;->setCencDefaultKid(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPssh(Lcom/vdocipher/Manifest$ContentProtection;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$ContentProtection;->setPssh(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSchemeIdUri(Lcom/vdocipher/Manifest$ContentProtection;Lcom/vdocipher/Manifest$CpSchemeIdUri;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$ContentProtection;->setSchemeIdUri(Lcom/vdocipher/Manifest$CpSchemeIdUri;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSchemeIdUriValue(Lcom/vdocipher/Manifest$ContentProtection;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$ContentProtection;->setSchemeIdUriValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetValue(Lcom/vdocipher/Manifest$ContentProtection;Lcom/vdocipher/Manifest$ContentProtectionValue;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$ContentProtection;->setValue(Lcom/vdocipher/Manifest$ContentProtectionValue;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetValueValue(Lcom/vdocipher/Manifest$ContentProtection;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$ContentProtection;->setValueValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$ContentProtection;
    .registers 1

    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 1250
    new-instance v0, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$ContentProtection;-><init>()V

    .line 1253
    sput-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    .line 1254
    const-class v1, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 754
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 755
    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    iput-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->cencDefaultKid_:Lcom/google/protobuf/ByteString;

    .line 756
    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    iput-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->pssh_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private clearCencDefaultKid()V
    .registers 2

    .line 882
    iget v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    and-int/lit8 v0, v0, -0x3

    iput v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    .line 883
    invoke-static {}, Lcom/vdocipher/Manifest$ContentProtection;->getDefaultInstance()Lcom/vdocipher/Manifest$ContentProtection;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$ContentProtection;->getCencDefaultKid()Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->cencDefaultKid_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private clearPssh()V
    .registers 2

    .line 917
    iget v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    and-int/lit8 v0, v0, -0x5

    iput v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    .line 918
    invoke-static {}, Lcom/vdocipher/Manifest$ContentProtection;->getDefaultInstance()Lcom/vdocipher/Manifest$ContentProtection;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$ContentProtection;->getPssh()Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->pssh_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private clearSchemeIdUri()V
    .registers 2

    const/4 v0, 0x0

    .line 848
    iput v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->schemeIdUri_:I

    return-void
.end method

.method private clearValue()V
    .registers 2

    .line 805
    iget v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    and-int/lit8 v0, v0, -0x2

    iput v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    const/4 v0, 0x0

    .line 806
    iput v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->value_:I

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/Manifest$ContentProtection;
    .registers 1

    .line 1259
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/Manifest$ContentProtection$Builder;
    .registers 1

    .line 998
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$ContentProtection;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/Manifest$ContentProtection$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/Manifest$ContentProtection;)Lcom/vdocipher/Manifest$ContentProtection$Builder;
    .registers 2

    .line 1001
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-virtual {v0, p0}, Lcom/vdocipher/Manifest$ContentProtection;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$ContentProtection$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$ContentProtection;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 974
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p0}, Lcom/vdocipher/Manifest$ContentProtection;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$ContentProtection;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$ContentProtection;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 981
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/Manifest$ContentProtection;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$ContentProtection;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$ContentProtection;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 937
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$ContentProtection;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$ContentProtection;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 944
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$ContentProtection;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/Manifest$ContentProtection;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 986
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$ContentProtection;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$ContentProtection;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 993
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$ContentProtection;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$ContentProtection;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 961
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$ContentProtection;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$ContentProtection;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 968
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$ContentProtection;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/Manifest$ContentProtection;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 924
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$ContentProtection;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$ContentProtection;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 931
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$ContentProtection;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/Manifest$ContentProtection;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 949
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$ContentProtection;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$ContentProtection;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 956
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$ContentProtection;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$ContentProtection;",
            ">;"
        }
    .end annotation

    .line 1265
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$ContentProtection;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setCencDefaultKid(Lcom/google/protobuf/ByteString;)V
    .registers 3

    .line 874
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 875
    iget v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    or-int/lit8 v0, v0, 0x2

    iput v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    .line 876
    iput-object p1, p0, Lcom/vdocipher/Manifest$ContentProtection;->cencDefaultKid_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private setPssh(Lcom/google/protobuf/ByteString;)V
    .registers 3

    .line 909
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 910
    iget v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    or-int/lit8 v0, v0, 0x4

    iput v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    .line 911
    iput-object p1, p0, Lcom/vdocipher/Manifest$ContentProtection;->pssh_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private setSchemeIdUri(Lcom/vdocipher/Manifest$CpSchemeIdUri;)V
    .registers 2

    .line 840
    invoke-virtual {p1}, Lcom/vdocipher/Manifest$CpSchemeIdUri;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/Manifest$ContentProtection;->schemeIdUri_:I

    return-void
.end method

.method private setSchemeIdUriValue(I)V
    .registers 2

    .line 833
    iput p1, p0, Lcom/vdocipher/Manifest$ContentProtection;->schemeIdUri_:I

    return-void
.end method

.method private setValue(Lcom/vdocipher/Manifest$ContentProtectionValue;)V
    .registers 2

    .line 798
    invoke-virtual {p1}, Lcom/vdocipher/Manifest$ContentProtectionValue;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/Manifest$ContentProtection;->value_:I

    .line 799
    iget p1, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    return-void
.end method

.method private setValueValue(I)V
    .registers 3

    .line 791
    iget v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    or-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    iput p1, p0, Lcom/vdocipher/Manifest$ContentProtection;->value_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1197
    sget-object p2, Lcom/vdocipher/Manifest$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_5a

    .line 1243
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 1237
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 1222
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/Manifest$ContentProtection;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 1224
    const-class p2, Lcom/vdocipher/Manifest$ContentProtection;

    monitor-enter p2

    .line 1225
    :try_start_20
    sget-object p1, Lcom/vdocipher/Manifest$ContentProtection;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 1227
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 1230
    sput-object p1, Lcom/vdocipher/Manifest$ContentProtection;->PARSER:Lcom/google/protobuf/Parser;

    .line 1232
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 1219
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    return-object p1

    .line 1205
    :pswitch_36  #0x3
    const-string p1, "bitField0_"

    const-string/jumbo p2, "value_"

    const-string p3, "schemeIdUri_"

    const-string v0, "cencDefaultKid_"

    const-string v1, "pssh_"

    filled-new-array {p1, p2, p3, v0, v1}, [Ljava/lang/Object;

    move-result-object p1

    .line 1212
    const-string p2, "\u0000\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001ဌ\u0000\u0002\f\u0003ည\u0001\u0004ည\u0002"

    .line 1215
    sget-object p3, Lcom/vdocipher/Manifest$ContentProtection;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$ContentProtection;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/Manifest$ContentProtection;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 1202
    :pswitch_4e  #0x2
    new-instance p1, Lcom/vdocipher/Manifest$ContentProtection$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/Manifest$ContentProtection$Builder;-><init>(Lcom/vdocipher/Manifest-IA;)V

    return-object p1

    .line 1199
    :pswitch_54  #0x1
    new-instance p1, Lcom/vdocipher/Manifest$ContentProtection;

    invoke-direct {p1}, Lcom/vdocipher/Manifest$ContentProtection;-><init>()V

    return-object p1

    :pswitch_data_5a
    .packed-switch 0x1
        :pswitch_54  #00000001
        :pswitch_4e  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getCencDefaultKid()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 867
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->cencDefaultKid_:Lcom/google/protobuf/ByteString;

    return-object v0
.end method

.method public getPssh()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 902
    iget-object v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->pssh_:Lcom/google/protobuf/ByteString;

    return-object v0
.end method

.method public getSchemeIdUri()Lcom/vdocipher/Manifest$CpSchemeIdUri;
    .registers 2

    .line 825
    iget v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->schemeIdUri_:I

    invoke-static {v0}, Lcom/vdocipher/Manifest$CpSchemeIdUri;->forNumber(I)Lcom/vdocipher/Manifest$CpSchemeIdUri;

    move-result-object v0

    if-nez v0, :cond_a

    .line 826
    sget-object v0, Lcom/vdocipher/Manifest$CpSchemeIdUri;->UNRECOGNIZED:Lcom/vdocipher/Manifest$CpSchemeIdUri;

    :cond_a
    return-object v0
.end method

.method public getSchemeIdUriValue()I
    .registers 2

    .line 817
    iget v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->schemeIdUri_:I

    return v0
.end method

.method public getValue()Lcom/vdocipher/Manifest$ContentProtectionValue;
    .registers 2

    .line 783
    iget v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->value_:I

    invoke-static {v0}, Lcom/vdocipher/Manifest$ContentProtectionValue;->forNumber(I)Lcom/vdocipher/Manifest$ContentProtectionValue;

    move-result-object v0

    if-nez v0, :cond_a

    .line 784
    sget-object v0, Lcom/vdocipher/Manifest$ContentProtectionValue;->UNRECOGNIZED:Lcom/vdocipher/Manifest$ContentProtectionValue;

    :cond_a
    return-object v0
.end method

.method public getValueValue()I
    .registers 2

    .line 775
    iget v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->value_:I

    return v0
.end method

.method public hasCencDefaultKid()Z
    .registers 2

    .line 859
    iget v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasPssh()Z
    .registers 2

    .line 894
    iget v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasValue()Z
    .registers 3

    .line 767
    iget v0, p0, Lcom/vdocipher/Manifest$ContentProtection;->bitField0_:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_7

    return v1

    :cond_7
    const/4 v0, 0x0

    return v0
.end method
