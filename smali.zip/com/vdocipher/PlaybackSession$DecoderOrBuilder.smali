# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackSession$DecoderOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "DecoderOrBuilder"
.end annotation


# virtual methods
.method public abstract getDecoderName()Ljava/lang/String;
.end method

.method public abstract getDecoderNameBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getSupportedTypes()Ljava/lang/String;
.end method

.method public abstract getSupportedTypesBytes()Lcom/google/protobuf/ByteString;
.end method
