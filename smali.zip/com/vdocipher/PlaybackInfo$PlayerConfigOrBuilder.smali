# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackInfo$PlayerConfigOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "PlayerConfigOrBuilder"
.end annotation


# virtual methods
.method public abstract getId()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getOptions()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
.end method

.method public abstract getTheme()Lcom/google/protobuf/ByteString;
.end method

.method public abstract hasOptions()Z
.end method
