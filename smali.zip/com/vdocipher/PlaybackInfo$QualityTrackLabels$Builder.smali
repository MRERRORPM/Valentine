# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$QualityTrackLabelsOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;",
        "Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$QualityTrackLabelsOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 1419
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackInfo-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public addAllLabel(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$QualityLabels;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;"
        }
    .end annotation

    .line 1526
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->copyOnWrite()V

    .line 1527
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->-$$Nest$maddAllLabel(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllLabelValue(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/Integer;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;"
        }
    .end annotation

    .line 1586
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->copyOnWrite()V

    .line 1587
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->-$$Nest$maddAllLabelValue(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addLabel(Lcom/vdocipher/PlaybackInfo$QualityLabels;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;
    .registers 3

    .line 1515
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->copyOnWrite()V

    .line 1516
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->-$$Nest$maddLabel(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;Lcom/vdocipher/PlaybackInfo$QualityLabels;)V

    return-object p0
.end method

.method public addLabelValue(I)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;
    .registers 3

    .line 1575
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->copyOnWrite()V

    .line 1576
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->-$$Nest$maddLabelValue(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;I)V

    return-object p0
.end method

.method public clearLabel()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;
    .registers 2

    .line 1534
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->copyOnWrite()V

    .line 1535
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->-$$Nest$mclearLabel(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)V

    return-object p0
.end method

.method public clearSeparator()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;
    .registers 2

    .line 1456
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->copyOnWrite()V

    .line 1457
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->-$$Nest$mclearSeparator(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)V

    return-object p0
.end method

.method public getLabel(I)Lcom/vdocipher/PlaybackInfo$QualityLabels;
    .registers 3

    .line 1495
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->getLabel(I)Lcom/vdocipher/PlaybackInfo$QualityLabels;

    move-result-object p1

    return-object p1
.end method

.method public getLabelCount()I
    .registers 2

    .line 1486
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->getLabelCount()I

    move-result v0

    return v0
.end method

.method public getLabelList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$QualityLabels;",
            ">;"
        }
    .end annotation

    .line 1478
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->getLabelList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getLabelValue(I)I
    .registers 3

    .line 1555
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->getLabelValue(I)I

    move-result p1

    return p1
.end method

.method public getLabelValueList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 1545
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    .line 1546
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->getLabelValueList()Ljava/util/List;

    move-result-object v0

    .line 1545
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getSeparator()Ljava/lang/String;
    .registers 2

    .line 1429
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->getSeparator()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getSeparatorBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 1438
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->getSeparatorBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setLabel(ILcom/vdocipher/PlaybackInfo$QualityLabels;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;
    .registers 4

    .line 1505
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->copyOnWrite()V

    .line 1506
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->-$$Nest$msetLabel(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;ILcom/vdocipher/PlaybackInfo$QualityLabels;)V

    return-object p0
.end method

.method public setLabelValue(II)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;
    .registers 4

    .line 1565
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->copyOnWrite()V

    .line 1566
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->-$$Nest$msetLabelValue(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;II)V

    return-object p0
.end method

.method public setSeparator(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;
    .registers 3

    .line 1447
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->copyOnWrite()V

    .line 1448
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->-$$Nest$msetSeparator(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;Ljava/lang/String;)V

    return-object p0
.end method

.method public setSeparatorBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;
    .registers 3

    .line 1467
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->copyOnWrite()V

    .line 1468
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->-$$Nest$msetSeparatorBytes(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
