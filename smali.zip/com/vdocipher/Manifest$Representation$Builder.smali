# classes14.dex

.class public final Lcom/vdocipher/Manifest$Representation$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$RepresentationOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest$Representation;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/Manifest$Representation;",
        "Lcom/vdocipher/Manifest$Representation$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$RepresentationOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 4410
    invoke-static {}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$Representation;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/Manifest-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Representation$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public addAllAudioChannelConfiguration(Ljava/lang/Iterable;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$AudioChannelConfiguration;",
            ">;)",
            "Lcom/vdocipher/Manifest$Representation$Builder;"
        }
    .end annotation

    .line 4693
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4694
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$maddAllAudioChannelConfiguration(Lcom/vdocipher/Manifest$Representation;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllSegmentBase(Ljava/lang/Iterable;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$SegmentBase;",
            ">;)",
            "Lcom/vdocipher/Manifest$Representation$Builder;"
        }
    .end annotation

    .line 4942
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4943
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$maddAllSegmentBase(Lcom/vdocipher/Manifest$Representation;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllSegmentTemplate(Ljava/lang/Iterable;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$SegmentTemplate;",
            ">;)",
            "Lcom/vdocipher/Manifest$Representation$Builder;"
        }
    .end annotation

    .line 5044
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 5045
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$maddAllSegmentTemplate(Lcom/vdocipher/Manifest$Representation;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAudioChannelConfiguration(ILcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 4

    .line 4683
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4684
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    .line 4685
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    .line 4684
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$maddAudioChannelConfiguration(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$AudioChannelConfiguration;)V

    return-object p0
.end method

.method public addAudioChannelConfiguration(ILcom/vdocipher/Manifest$AudioChannelConfiguration;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 4

    .line 4665
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4666
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$maddAudioChannelConfiguration(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$AudioChannelConfiguration;)V

    return-object p0
.end method

.method public addAudioChannelConfiguration(Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4674
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4675
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$maddAudioChannelConfiguration(Lcom/vdocipher/Manifest$Representation;Lcom/vdocipher/Manifest$AudioChannelConfiguration;)V

    return-object p0
.end method

.method public addAudioChannelConfiguration(Lcom/vdocipher/Manifest$AudioChannelConfiguration;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4656
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4657
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$maddAudioChannelConfiguration(Lcom/vdocipher/Manifest$Representation;Lcom/vdocipher/Manifest$AudioChannelConfiguration;)V

    return-object p0
.end method

.method public addSegmentBase(ILcom/vdocipher/Manifest$SegmentBase$Builder;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 4

    .line 4932
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4933
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    .line 4934
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$SegmentBase$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$SegmentBase;

    .line 4933
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$maddSegmentBase(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$SegmentBase;)V

    return-object p0
.end method

.method public addSegmentBase(ILcom/vdocipher/Manifest$SegmentBase;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 4

    .line 4914
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4915
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$maddSegmentBase(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$SegmentBase;)V

    return-object p0
.end method

.method public addSegmentBase(Lcom/vdocipher/Manifest$SegmentBase$Builder;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4923
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4924
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$SegmentBase$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$SegmentBase;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$maddSegmentBase(Lcom/vdocipher/Manifest$Representation;Lcom/vdocipher/Manifest$SegmentBase;)V

    return-object p0
.end method

.method public addSegmentBase(Lcom/vdocipher/Manifest$SegmentBase;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4905
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4906
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$maddSegmentBase(Lcom/vdocipher/Manifest$Representation;Lcom/vdocipher/Manifest$SegmentBase;)V

    return-object p0
.end method

.method public addSegmentTemplate(ILcom/vdocipher/Manifest$SegmentTemplate$Builder;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 4

    .line 5034
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 5035
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    .line 5036
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$SegmentTemplate;

    .line 5035
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$maddSegmentTemplate(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$SegmentTemplate;)V

    return-object p0
.end method

.method public addSegmentTemplate(ILcom/vdocipher/Manifest$SegmentTemplate;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 4

    .line 5016
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 5017
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$maddSegmentTemplate(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$SegmentTemplate;)V

    return-object p0
.end method

.method public addSegmentTemplate(Lcom/vdocipher/Manifest$SegmentTemplate$Builder;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 5025
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 5026
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$maddSegmentTemplate(Lcom/vdocipher/Manifest$Representation;Lcom/vdocipher/Manifest$SegmentTemplate;)V

    return-object p0
.end method

.method public addSegmentTemplate(Lcom/vdocipher/Manifest$SegmentTemplate;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 5007
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 5008
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$maddSegmentTemplate(Lcom/vdocipher/Manifest$Representation;Lcom/vdocipher/Manifest$SegmentTemplate;)V

    return-object p0
.end method

.method public clearAudioChannelConfiguration()Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 2

    .line 4701
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4702
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mclearAudioChannelConfiguration(Lcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public clearAudioSamplingRate()Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 2

    .line 4607
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4608
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mclearAudioSamplingRate(Lcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public clearBandwidth()Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 2

    .line 4465
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4466
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mclearBandwidth(Lcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public clearBaseUrl()Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 2

    .line 4856
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4857
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mclearBaseUrl(Lcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public clearCodecs()Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 2

    .line 4511
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4512
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mclearCodecs(Lcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public clearHeight()Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 2

    .line 4781
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4782
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mclearHeight(Lcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public clearId()Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 2

    .line 4437
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4438
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mclearId(Lcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public clearMimeType()Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 2

    .line 4560
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4561
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mclearMimeType(Lcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public clearSar()Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 2

    .line 4828
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4829
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mclearSar(Lcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public clearSegmentBase()Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 2

    .line 4950
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4951
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mclearSegmentBase(Lcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public clearSegmentTemplate()Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 2

    .line 5052
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 5053
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mclearSegmentTemplate(Lcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public clearWidth()Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 2

    .line 4745
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4746
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mclearWidth(Lcom/vdocipher/Manifest$Representation;)V

    return-object p0
.end method

.method public getAudioChannelConfiguration(I)Lcom/vdocipher/Manifest$AudioChannelConfiguration;
    .registers 3

    .line 4631
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0, p1}, Lcom/vdocipher/Manifest$Representation;->getAudioChannelConfiguration(I)Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    move-result-object p1

    return-object p1
.end method

.method public getAudioChannelConfigurationCount()I
    .registers 2

    .line 4625
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getAudioChannelConfigurationCount()I

    move-result v0

    return v0
.end method

.method public getAudioChannelConfigurationList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$AudioChannelConfiguration;",
            ">;"
        }
    .end annotation

    .line 4617
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    .line 4618
    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getAudioChannelConfigurationList()Ljava/util/List;

    move-result-object v0

    .line 4617
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getAudioSamplingRate()I
    .registers 2

    .line 4590
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getAudioSamplingRate()I

    move-result v0

    return v0
.end method

.method public getBandwidth()I
    .registers 2

    .line 4448
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getBandwidth()I

    move-result v0

    return v0
.end method

.method public getBaseUrl()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 4839
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getBaseUrl()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getCodecs()Ljava/lang/String;
    .registers 2

    .line 4484
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getCodecs()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getCodecsBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 4493
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getCodecsBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getHeight()I
    .registers 2

    .line 4764
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getHeight()I

    move-result v0

    return v0
.end method

.method public getId()I
    .registers 2

    .line 4420
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getId()I

    move-result v0

    return v0
.end method

.method public getMimeType()Ljava/lang/String;
    .registers 2

    .line 4533
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getMimeType()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getMimeTypeBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 4542
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getMimeTypeBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSar()Lcom/vdocipher/Manifest$AspectRatio;
    .registers 2

    .line 4798
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getSar()Lcom/vdocipher/Manifest$AspectRatio;

    move-result-object v0

    return-object v0
.end method

.method public getSegmentBase(I)Lcom/vdocipher/Manifest$SegmentBase;
    .registers 3

    .line 4880
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0, p1}, Lcom/vdocipher/Manifest$Representation;->getSegmentBase(I)Lcom/vdocipher/Manifest$SegmentBase;

    move-result-object p1

    return-object p1
.end method

.method public getSegmentBaseCount()I
    .registers 2

    .line 4874
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getSegmentBaseCount()I

    move-result v0

    return v0
.end method

.method public getSegmentBaseList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$SegmentBase;",
            ">;"
        }
    .end annotation

    .line 4866
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    .line 4867
    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getSegmentBaseList()Ljava/util/List;

    move-result-object v0

    .line 4866
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getSegmentTemplate(I)Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 3

    .line 4982
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0, p1}, Lcom/vdocipher/Manifest$Representation;->getSegmentTemplate(I)Lcom/vdocipher/Manifest$SegmentTemplate;

    move-result-object p1

    return-object p1
.end method

.method public getSegmentTemplateCount()I
    .registers 2

    .line 4976
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getSegmentTemplateCount()I

    move-result v0

    return v0
.end method

.method public getSegmentTemplateList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$SegmentTemplate;",
            ">;"
        }
    .end annotation

    .line 4968
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    .line 4969
    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getSegmentTemplateList()Ljava/util/List;

    move-result-object v0

    .line 4968
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getWidth()I
    .registers 2

    .line 4728
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->getWidth()I

    move-result v0

    return v0
.end method

.method public hasAudioSamplingRate()Z
    .registers 2

    .line 4582
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->hasAudioSamplingRate()Z

    move-result v0

    return v0
.end method

.method public hasCodecs()Z
    .registers 2

    .line 4476
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->hasCodecs()Z

    move-result v0

    return v0
.end method

.method public hasHeight()Z
    .registers 2

    .line 4756
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->hasHeight()Z

    move-result v0

    return v0
.end method

.method public hasSar()Z
    .registers 2

    .line 4791
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->hasSar()Z

    move-result v0

    return v0
.end method

.method public hasWidth()Z
    .registers 2

    .line 4720
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Representation;->hasWidth()Z

    move-result v0

    return v0
.end method

.method public mergeSar(Lcom/vdocipher/Manifest$AspectRatio;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4821
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4822
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mmergeSar(Lcom/vdocipher/Manifest$Representation;Lcom/vdocipher/Manifest$AspectRatio;)V

    return-object p0
.end method

.method public removeAudioChannelConfiguration(I)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4709
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4710
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mremoveAudioChannelConfiguration(Lcom/vdocipher/Manifest$Representation;I)V

    return-object p0
.end method

.method public removeSegmentBase(I)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4958
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4959
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mremoveSegmentBase(Lcom/vdocipher/Manifest$Representation;I)V

    return-object p0
.end method

.method public removeSegmentTemplate(I)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 5060
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 5061
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$mremoveSegmentTemplate(Lcom/vdocipher/Manifest$Representation;I)V

    return-object p0
.end method

.method public setAudioChannelConfiguration(ILcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 4

    .line 4647
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4648
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    .line 4649
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$AudioChannelConfiguration$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$AudioChannelConfiguration;

    .line 4648
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetAudioChannelConfiguration(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$AudioChannelConfiguration;)V

    return-object p0
.end method

.method public setAudioChannelConfiguration(ILcom/vdocipher/Manifest$AudioChannelConfiguration;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 4

    .line 4638
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4639
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetAudioChannelConfiguration(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$AudioChannelConfiguration;)V

    return-object p0
.end method

.method public setAudioSamplingRate(I)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4598
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4599
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetAudioSamplingRate(Lcom/vdocipher/Manifest$Representation;I)V

    return-object p0
.end method

.method public setBandwidth(I)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4456
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4457
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetBandwidth(Lcom/vdocipher/Manifest$Representation;I)V

    return-object p0
.end method

.method public setBaseUrl(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4847
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4848
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetBaseUrl(Lcom/vdocipher/Manifest$Representation;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setCodecs(Ljava/lang/String;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4502
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4503
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetCodecs(Lcom/vdocipher/Manifest$Representation;Ljava/lang/String;)V

    return-object p0
.end method

.method public setCodecsBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4522
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4523
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetCodecsBytes(Lcom/vdocipher/Manifest$Representation;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setHeight(I)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4772
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4773
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetHeight(Lcom/vdocipher/Manifest$Representation;I)V

    return-object p0
.end method

.method public setId(I)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4428
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4429
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetId(Lcom/vdocipher/Manifest$Representation;I)V

    return-object p0
.end method

.method public setMimeType(Ljava/lang/String;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4551
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4552
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetMimeType(Lcom/vdocipher/Manifest$Representation;Ljava/lang/String;)V

    return-object p0
.end method

.method public setMimeTypeBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4571
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4572
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetMimeTypeBytes(Lcom/vdocipher/Manifest$Representation;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setSar(Lcom/vdocipher/Manifest$AspectRatio$Builder;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4813
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4814
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$AspectRatio$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$AspectRatio;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetSar(Lcom/vdocipher/Manifest$Representation;Lcom/vdocipher/Manifest$AspectRatio;)V

    return-object p0
.end method

.method public setSar(Lcom/vdocipher/Manifest$AspectRatio;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4804
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4805
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetSar(Lcom/vdocipher/Manifest$Representation;Lcom/vdocipher/Manifest$AspectRatio;)V

    return-object p0
.end method

.method public setSegmentBase(ILcom/vdocipher/Manifest$SegmentBase$Builder;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 4

    .line 4896
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4897
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    .line 4898
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$SegmentBase$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$SegmentBase;

    .line 4897
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetSegmentBase(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$SegmentBase;)V

    return-object p0
.end method

.method public setSegmentBase(ILcom/vdocipher/Manifest$SegmentBase;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 4

    .line 4887
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4888
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetSegmentBase(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$SegmentBase;)V

    return-object p0
.end method

.method public setSegmentTemplate(ILcom/vdocipher/Manifest$SegmentTemplate$Builder;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 4

    .line 4998
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4999
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    .line 5000
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$SegmentTemplate;

    .line 4999
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetSegmentTemplate(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$SegmentTemplate;)V

    return-object p0
.end method

.method public setSegmentTemplate(ILcom/vdocipher/Manifest$SegmentTemplate;)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 4

    .line 4989
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4990
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetSegmentTemplate(Lcom/vdocipher/Manifest$Representation;ILcom/vdocipher/Manifest$SegmentTemplate;)V

    return-object p0
.end method

.method public setWidth(I)Lcom/vdocipher/Manifest$Representation$Builder;
    .registers 3

    .line 4736
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Representation$Builder;->copyOnWrite()V

    .line 4737
    iget-object v0, p0, Lcom/vdocipher/Manifest$Representation$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Representation;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Representation;->-$$Nest$msetWidth(Lcom/vdocipher/Manifest$Representation;I)V

    return-object p0
.end method
