# classes14.dex

.class public final Lcom/vdocipher/Manifest$Initialization;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$InitializationOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Initialization"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$Initialization$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/Manifest$Initialization;",
        "Lcom/vdocipher/Manifest$Initialization$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$InitializationOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

.field public static final END_FIELD_NUMBER:I = 0x2

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$Initialization;",
            ">;"
        }
    .end annotation
.end field

.field public static final START_FIELD_NUMBER:I = 0x1


# instance fields
.field private end_:I

.field private start_:I


# direct methods
.method static bridge synthetic -$$Nest$mclearEnd(Lcom/vdocipher/Manifest$Initialization;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Initialization;->clearEnd()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearStart(Lcom/vdocipher/Manifest$Initialization;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Initialization;->clearStart()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnd(Lcom/vdocipher/Manifest$Initialization;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Initialization;->setEnd(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetStart(Lcom/vdocipher/Manifest$Initialization;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$Initialization;->setStart(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$Initialization;
    .registers 1

    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 1913
    new-instance v0, Lcom/vdocipher/Manifest$Initialization;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$Initialization;-><init>()V

    .line 1916
    sput-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    .line 1917
    const-class v1, Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 1649
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    return-void
.end method

.method private clearEnd()V
    .registers 2

    const/4 v0, 0x0

    .line 1700
    iput v0, p0, Lcom/vdocipher/Manifest$Initialization;->end_:I

    return-void
.end method

.method private clearStart()V
    .registers 2

    const/4 v0, 0x0

    .line 1674
    iput v0, p0, Lcom/vdocipher/Manifest$Initialization;->start_:I

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/Manifest$Initialization;
    .registers 1

    .line 1922
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/Manifest$Initialization$Builder;
    .registers 1

    .line 1780
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Initialization;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/Manifest$Initialization$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/Manifest$Initialization;)Lcom/vdocipher/Manifest$Initialization$Builder;
    .registers 2

    .line 1783
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-virtual {v0, p0}, Lcom/vdocipher/Manifest$Initialization;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Initialization$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$Initialization;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1756
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0, p0}, Lcom/vdocipher/Manifest$Initialization;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Initialization;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Initialization;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1763
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/Manifest$Initialization;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Initialization;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$Initialization;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1719
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Initialization;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Initialization;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1726
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Initialization;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/Manifest$Initialization;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1768
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Initialization;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Initialization;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1775
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Initialization;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$Initialization;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1743
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Initialization;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Initialization;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1750
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Initialization;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/Manifest$Initialization;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1706
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Initialization;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Initialization;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1713
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Initialization;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/Manifest$Initialization;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1731
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Initialization;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$Initialization;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 1738
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$Initialization;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$Initialization;",
            ">;"
        }
    .end annotation

    .line 1928
    sget-object v0, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Initialization;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setEnd(I)V
    .registers 2

    .line 1693
    iput p1, p0, Lcom/vdocipher/Manifest$Initialization;->end_:I

    return-void
.end method

.method private setStart(I)V
    .registers 2

    .line 1667
    iput p1, p0, Lcom/vdocipher/Manifest$Initialization;->start_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1863
    sget-object p2, Lcom/vdocipher/Manifest$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_54

    .line 1906
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 1900
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 1885
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/Manifest$Initialization;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 1887
    const-class p2, Lcom/vdocipher/Manifest$Initialization;

    monitor-enter p2

    .line 1888
    :try_start_20
    sget-object p1, Lcom/vdocipher/Manifest$Initialization;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 1890
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 1893
    sput-object p1, Lcom/vdocipher/Manifest$Initialization;->PARSER:Lcom/google/protobuf/Parser;

    .line 1895
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 1882
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    return-object p1

    .line 1871
    :pswitch_36  #0x3
    const-string/jumbo p1, "start_"

    const-string p2, "end_"

    filled-new-array {p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    .line 1875
    const-string p2, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u000b\u0002\u000b"

    .line 1878
    sget-object p3, Lcom/vdocipher/Manifest$Initialization;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$Initialization;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/Manifest$Initialization;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 1868
    :pswitch_48  #0x2
    new-instance p1, Lcom/vdocipher/Manifest$Initialization$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/Manifest$Initialization$Builder;-><init>(Lcom/vdocipher/Manifest-IA;)V

    return-object p1

    .line 1865
    :pswitch_4e  #0x1
    new-instance p1, Lcom/vdocipher/Manifest$Initialization;

    invoke-direct {p1}, Lcom/vdocipher/Manifest$Initialization;-><init>()V

    return-object p1

    :pswitch_data_54
    .packed-switch 0x1
        :pswitch_4e  #00000001
        :pswitch_48  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getEnd()I
    .registers 2

    .line 1685
    iget v0, p0, Lcom/vdocipher/Manifest$Initialization;->end_:I

    return v0
.end method

.method public getStart()I
    .registers 2

    .line 1659
    iget v0, p0, Lcom/vdocipher/Manifest$Initialization;->start_:I

    return v0
.end method
