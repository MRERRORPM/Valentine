# classes14.dex

.class public final Lcom/vdocipher/aegis/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/R$anim;,
        Lcom/vdocipher/aegis/R$animator;,
        Lcom/vdocipher/aegis/R$array;,
        Lcom/vdocipher/aegis/R$attr;,
        Lcom/vdocipher/aegis/R$bool;,
        Lcom/vdocipher/aegis/R$color;,
        Lcom/vdocipher/aegis/R$dimen;,
        Lcom/vdocipher/aegis/R$drawable;,
        Lcom/vdocipher/aegis/R$font;,
        Lcom/vdocipher/aegis/R$id;,
        Lcom/vdocipher/aegis/R$integer;,
        Lcom/vdocipher/aegis/R$interpolator;,
        Lcom/vdocipher/aegis/R$layout;,
        Lcom/vdocipher/aegis/R$menu;,
        Lcom/vdocipher/aegis/R$plurals;,
        Lcom/vdocipher/aegis/R$raw;,
        Lcom/vdocipher/aegis/R$string;,
        Lcom/vdocipher/aegis/R$style;,
        Lcom/vdocipher/aegis/R$styleable;,
        Lcom/vdocipher/aegis/R$xml;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
