# classes14.dex

.class public final Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static a:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    :try_start_0
    const-string/jumbo v0, "vdomain"

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    const/4 v0, 0x1

    .line 2
    sput-boolean v0, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->a:Z
    :try_end_9
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_9} :catch_a

    return-void

    :catch_a
    move-exception v0

    .line 4
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "AppAnalytics"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private a(Landroid/content/Context;)I
    .registers 6

    .line 1
    sget-boolean v0, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->a:Z

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    .line 2
    :cond_6
    invoke-static {}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->r()I

    move-result v0

    .line 4
    invoke-virtual {p0}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->h()Z

    move-result v2

    and-int/lit8 v3, v0, 0x1

    if-eqz v3, :cond_13

    const/4 v1, 0x1

    :cond_13
    and-int/lit8 v3, v0, 0x2

    if-eqz v3, :cond_19

    or-int/lit8 v1, v1, 0x2

    :cond_19
    if-eqz v2, :cond_1d

    or-int/lit8 v1, v1, 0x4

    :cond_1d
    and-int/lit8 v2, v0, 0x8

    if-eqz v2, :cond_23

    or-int/lit8 v1, v1, 0x8

    :cond_23
    and-int/lit8 v2, v0, 0x10

    if-eqz v2, :cond_29

    or-int/lit8 v1, v1, 0x10

    :cond_29
    and-int/lit8 v2, v0, 0x20

    if-eqz v2, :cond_2f

    or-int/lit8 v1, v1, 0x20

    :cond_2f
    and-int/lit8 v2, v0, 0x40

    if-eqz v2, :cond_35

    or-int/lit8 v1, v1, 0x40

    :cond_35
    and-int/lit16 v0, v0, 0x80

    if-eqz v0, :cond_3b

    or-int/lit16 v1, v1, 0x80

    .line 13
    :cond_3b
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->c(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_43

    or-int/lit16 v1, v1, 0x100

    .line 14
    :cond_43
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->b(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_4b

    or-int/lit16 v1, v1, 0x200

    .line 15
    :cond_4b
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->e(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_54

    or-int/lit16 p1, v1, 0x400

    return p1

    :cond_54
    return v1
.end method

.method private static native a()Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method

.method private a(Landroid/content/Context;Ljava/util/List;)Z
    .registers 6

    .line 16
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    .line 18
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    const/4 v0, 0x0

    move v1, v0

    :catch_a
    :goto_a
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1b

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 21
    :try_start_16
    invoke-virtual {p1, v2, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_19
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_16 .. :try_end_19} :catch_a

    const/4 v1, 0x1

    goto :goto_a

    :cond_1b
    return v1
.end method

.method private static native b()Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method

.method private b(Landroid/content/Context;)Z
    .registers 5

    .line 1
    invoke-static {}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->b()Ljava/util/ArrayList;

    move-result-object v0

    .line 2
    new-instance v1, Ljava/util/ArrayList;

    sget-object v2, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    if-eqz v0, :cond_16

    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_16

    .line 4
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 7
    :cond_16
    invoke-direct {p0, p1, v1}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->a(Landroid/content/Context;Ljava/util/List;)Z

    move-result p1

    return p1
.end method

.method private static native c()Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method

.method private c(Landroid/content/Context;)Z
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->d(Landroid/content/Context;)Z

    move-result p1

    if-nez p1, :cond_15

    invoke-direct {p0}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->j()Z

    move-result p1

    if-eqz p1, :cond_13

    invoke-direct {p0}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->g()Z

    move-result p1

    if-nez p1, :cond_13

    goto :goto_15

    :cond_13
    const/4 p1, 0x0

    return p1

    :cond_15
    :goto_15
    const/4 p1, 0x1

    return p1
.end method

.method private static native d()Z
.end method

.method private d(Landroid/content/Context;)Z
    .registers 5

    .line 1
    invoke-static {}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->c()Ljava/util/ArrayList;

    move-result-object v0

    .line 4
    new-instance v1, Ljava/util/ArrayList;

    sget-object v2, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    if-eqz v0, :cond_16

    .line 5
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_16

    .line 6
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 8
    :cond_16
    invoke-direct {p0, p1, v1}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->a(Landroid/content/Context;Ljava/util/List;)Z

    move-result p1

    return p1
.end method

.method private static native e()Z
.end method

.method private e(Landroid/content/Context;)Z
    .registers 5

    .line 1
    invoke-static {}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->a()Ljava/util/ArrayList;

    move-result-object v0

    .line 2
    new-instance v1, Ljava/util/ArrayList;

    sget-object v2, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    if-eqz v0, :cond_16

    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_16

    .line 4
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 7
    :cond_16
    invoke-direct {p0, p1, v1}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->a(Landroid/content/Context;Ljava/util/List;)Z

    move-result p1

    return p1
.end method

.method private static native f()Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method

.method private g()Z
    .registers 2

    .line 1
    :try_start_0
    invoke-static {}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->t()Ljava/lang/String;
    :try_end_3
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_3} :catch_5

    const/4 v0, 0x1

    return v0

    :catch_5
    const/4 v0, 0x0

    return v0
.end method

.method private i()[Ljava/lang/String;
    .registers 4

    const/4 v0, 0x0

    .line 1
    :try_start_1
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v1

    const-string v2, "mount"

    invoke-virtual {v1, v2}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    if-nez v1, :cond_12

    return-object v0

    .line 3
    :cond_12
    new-instance v2, Ljava/util/Scanner;

    invoke-direct {v2, v1}, Ljava/util/Scanner;-><init>(Ljava/io/InputStream;)V

    const-string v1, "\\A"

    invoke-virtual {v2, v1}, Ljava/util/Scanner;->useDelimiter(Ljava/lang/String;)Ljava/util/Scanner;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Scanner;->next()Ljava/lang/String;

    move-result-object v1

    .line 4
    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0
    :try_end_27
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_27} :catch_27
    .catch Ljava/util/NoSuchElementException; {:try_start_1 .. :try_end_27} :catch_27

    :catch_27
    return-object v0
.end method

.method private j()Z
    .registers 2

    .line 1
    sget-boolean v0, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->a:Z

    return v0
.end method

.method private static native r()I
.end method

.method private static native t()Ljava/lang/String;
.end method


# virtual methods
.method public f(Landroid/content/Context;)Ljava/lang/String;
    .registers 7

    .line 1
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->a(Landroid/content/Context;)I

    move-result p1

    .line 3
    invoke-static {}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->d()Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz p1, :cond_e

    move v3, v2

    goto :goto_f

    :cond_e
    move v3, v1

    .line 5
    :goto_f
    invoke-static {}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->e()Z

    move-result v4

    shl-int/2addr v3, v2

    or-int/2addr v0, v3

    shl-int/lit8 v3, v4, 0x3

    or-int/2addr v0, v3

    shl-int/lit8 p1, p1, 0x3

    or-int/2addr p1, v0

    shr-int/lit8 v0, p1, 0x8

    and-int/lit16 v0, v0, 0xff

    int-to-byte v0, v0

    and-int/lit16 p1, p1, 0xff

    int-to-byte p1, p1

    const/4 v3, 0x2

    .line 17
    new-array v4, v3, [B

    aput-byte v0, v4, v1

    aput-byte p1, v4, v2

    .line 20
    invoke-static {v4, v3}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public h()Z
    .registers 16

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->i()[Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    .line 9
    :cond_8
    array-length v2, v0

    move v3, v1

    move v4, v3

    :goto_b
    if-ge v3, v2, :cond_63

    aget-object v5, v0, v3

    .line 11
    const-string v6, " "

    invoke-virtual {v5, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    .line 13
    array-length v6, v5

    const/4 v7, 0x6

    if-ge v6, v7, :cond_1a

    goto :goto_60

    :cond_1a
    const/4 v6, 0x2

    .line 22
    aget-object v6, v5, v6

    const/4 v7, 0x5

    .line 23
    aget-object v5, v5, v7

    .line 29
    invoke-static {}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->f()Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v8

    move v9, v1

    :cond_29
    :goto_29
    if-ge v9, v8, :cond_60

    invoke-virtual {v7, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    add-int/lit8 v9, v9, 0x1

    check-cast v10, Ljava/lang/String;

    .line 30
    invoke-virtual {v6, v10}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_29

    .line 31
    const-string v10, "("

    const-string v11, ""

    invoke-virtual {v5, v10, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v5

    .line 32
    const-string v10, ")"

    invoke-virtual {v5, v10, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v5

    .line 34
    const-string v10, ","

    invoke-virtual {v5, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v10

    array-length v11, v10

    move v12, v1

    :goto_4f
    if-ge v12, v11, :cond_29

    aget-object v13, v10, v12

    .line 36
    const-string v14, "rw"

    invoke-virtual {v13, v14}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v13

    if-eqz v13, :cond_5d

    const/4 v4, 0x1

    goto :goto_29

    :cond_5d
    add-int/lit8 v12, v12, 0x1

    goto :goto_4f

    :cond_60
    :goto_60
    add-int/lit8 v3, v3, 0x1

    goto :goto_b

    :cond_63
    return v4
.end method
