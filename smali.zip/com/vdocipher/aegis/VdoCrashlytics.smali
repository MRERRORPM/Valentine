# classes14.dex

.class public final Lcom/vdocipher/aegis/VdoCrashlytics;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/VdoCrashlytics$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0000\u0018\u0000 \u00062\u00020\u0001:\u0001\u0006B\u0011\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005¨\u0006\u0007"
    }
    d2 = {
        "Lcom/vdocipher/aegis/VdoCrashlytics;",
        "",
        "context",
        "Landroid/content/Context;",
        "<init>",
        "(Landroid/content/Context;)V",
        "Companion",
        "core_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final Companion:Lcom/vdocipher/aegis/VdoCrashlytics$Companion;

.field private static final PERIODIC_FLEX:J = 0xfL

.field private static final PERIODIC_INTERVAL:J = 0x78L

.field private static final TAG:Ljava/lang/String; = "VdoCrashlytics"

.field private static vdoCrashlytics:Lcom/vdocipher/aegis/VdoCrashlytics;


# direct methods
.method public static synthetic $r8$lambda$3A0SbY8D8Jio-BZVK9aSxfr54Tk(Landroid/content/Context;Ljava/lang/Thread$UncaughtExceptionHandler;Ljava/lang/Thread;Ljava/lang/Throwable;)V
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/vdocipher/aegis/VdoCrashlytics;->_init_$lambda$0(Landroid/content/Context;Ljava/lang/Thread$UncaughtExceptionHandler;Ljava/lang/Thread;Ljava/lang/Throwable;)V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/vdocipher/aegis/VdoCrashlytics$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/vdocipher/aegis/VdoCrashlytics$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/vdocipher/aegis/VdoCrashlytics;->Companion:Lcom/vdocipher/aegis/VdoCrashlytics$Companion;

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .registers 4

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 36
    invoke-static {}, Ljava/lang/Thread;->getDefaultUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;

    move-result-object v0

    .line 37
    new-instance v1, Lcom/vdocipher/aegis/VdoCrashlytics$$ExternalSyntheticLambda0;

    invoke-direct {v1, p1, v0}, Lcom/vdocipher/aegis/VdoCrashlytics$$ExternalSyntheticLambda0;-><init>(Landroid/content/Context;Ljava/lang/Thread$UncaughtExceptionHandler;)V

    invoke-static {v1}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/VdoCrashlytics;-><init>(Landroid/content/Context;)V

    return-void
.end method

.method private static final _init_$lambda$0(Landroid/content/Context;Ljava/lang/Thread$UncaughtExceptionHandler;Ljava/lang/Thread;Ljava/lang/Throwable;)V
    .registers 9

    const-string v0, "paramThread"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "paramThrowable"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-static {p3}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "getStackTraceString(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    const-string v1, "com.vdocipher.aegis"

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v0, v1, v2, v3, v4}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_25

    .line 3
    invoke-static {p0}, Lcom/vdocipher/aegis/core/k/c;->b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object p0

    .line 4
    invoke-virtual {p0, p3, v4, v2}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/Throwable;Ljava/lang/String;Z)V

    :cond_25
    if-eqz p1, :cond_2b

    .line 6
    invoke-interface {p1, p2, p3}, Ljava/lang/Thread$UncaughtExceptionHandler;->uncaughtException(Ljava/lang/Thread;Ljava/lang/Throwable;)V

    return-void

    .line 10
    :cond_2b
    invoke-static {v3}, Ljava/lang/System;->exit(I)V

    new-instance p0, Ljava/lang/RuntimeException;

    const-string p1, "System.exit returned normally, while it was supposed to halt JVM."

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final synthetic access$getVdoCrashlytics$cp()Lcom/vdocipher/aegis/VdoCrashlytics;
    .registers 1

    .line 1
    sget-object v0, Lcom/vdocipher/aegis/VdoCrashlytics;->vdoCrashlytics:Lcom/vdocipher/aegis/VdoCrashlytics;

    return-object v0
.end method

.method public static final synthetic access$setVdoCrashlytics$cp(Lcom/vdocipher/aegis/VdoCrashlytics;)V
    .registers 1

    .line 1
    sput-object p0, Lcom/vdocipher/aegis/VdoCrashlytics;->vdoCrashlytics:Lcom/vdocipher/aegis/VdoCrashlytics;

    return-void
.end method

.method public static final initialize(Landroid/content/Context;)V
    .registers 2
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    sget-object v0, Lcom/vdocipher/aegis/VdoCrashlytics;->Companion:Lcom/vdocipher/aegis/VdoCrashlytics$Companion;

    invoke-virtual {v0, p0}, Lcom/vdocipher/aegis/VdoCrashlytics$Companion;->initialize(Landroid/content/Context;)V

    return-void
.end method
