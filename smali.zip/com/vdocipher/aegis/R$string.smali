# classes14.dex

.class public final Lcom/vdocipher/aegis/R$string;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static CronetProviderClassName:I = 0x7f130000

.field public static abc_action_bar_home_description:I = 0x7f130001

.field public static abc_action_bar_up_description:I = 0x7f130002

.field public static abc_action_menu_overflow_description:I = 0x7f130003

.field public static abc_action_mode_done:I = 0x7f130004

.field public static abc_activity_chooser_view_see_all:I = 0x7f130005

.field public static abc_activitychooserview_choose_application:I = 0x7f130006

.field public static abc_capital_off:I = 0x7f130007

.field public static abc_capital_on:I = 0x7f130008

.field public static abc_menu_alt_shortcut_label:I = 0x7f130009

.field public static abc_menu_ctrl_shortcut_label:I = 0x7f13000a

.field public static abc_menu_delete_shortcut_label:I = 0x7f13000b

.field public static abc_menu_enter_shortcut_label:I = 0x7f13000c

.field public static abc_menu_function_shortcut_label:I = 0x7f13000d

.field public static abc_menu_meta_shortcut_label:I = 0x7f13000e

.field public static abc_menu_shift_shortcut_label:I = 0x7f13000f

.field public static abc_menu_space_shortcut_label:I = 0x7f130010

.field public static abc_menu_sym_shortcut_label:I = 0x7f130011

.field public static abc_prepend_shortcut_label:I = 0x7f130012

.field public static abc_search_hint:I = 0x7f130013

.field public static abc_searchview_description_clear:I = 0x7f130014

.field public static abc_searchview_description_query:I = 0x7f130015

.field public static abc_searchview_description_search:I = 0x7f130016

.field public static abc_searchview_description_submit:I = 0x7f130017

.field public static abc_searchview_description_voice:I = 0x7f130018

.field public static abc_shareactionprovider_share_with:I = 0x7f130019

.field public static abc_shareactionprovider_share_with_application:I = 0x7f13001a

.field public static abc_toolbar_collapse_description:I = 0x7f13001b

.field public static androidx_startup:I = 0x7f130020

.field public static appbar_scrolling_view_behavior:I = 0x7f130022

.field public static bottom_sheet_behavior:I = 0x7f13002a

.field public static bottomsheet_action_collapse:I = 0x7f13002b

.field public static bottomsheet_action_expand:I = 0x7f13002c

.field public static bottomsheet_action_expand_halfway:I = 0x7f13002d

.field public static bottomsheet_drag_handle_content_description:I = 0x7f13002e

.field public static call_notification_answer_action:I = 0x7f13002f

.field public static call_notification_answer_video_action:I = 0x7f130030

.field public static call_notification_decline_action:I = 0x7f130031

.field public static call_notification_hang_up_action:I = 0x7f130032

.field public static call_notification_incoming_text:I = 0x7f130033

.field public static call_notification_ongoing_text:I = 0x7f130034

.field public static call_notification_screening_text:I = 0x7f130035

.field public static cast_ad_label:I = 0x7f130037

.field public static cast_casting_to_device:I = 0x7f130038

.field public static cast_closed_captions:I = 0x7f130039

.field public static cast_closed_captions_unavailable:I = 0x7f13003a

.field public static cast_connecting_to_device:I = 0x7f13003b

.field public static cast_disconnect:I = 0x7f13003c

.field public static cast_dynamic_group_name_format:I = 0x7f13003d

.field public static cast_expanded_controller_ad_image_description:I = 0x7f13003e

.field public static cast_expanded_controller_ad_in_progress:I = 0x7f13003f

.field public static cast_expanded_controller_background_image:I = 0x7f130040

.field public static cast_expanded_controller_live_head_description:I = 0x7f130041

.field public static cast_expanded_controller_live_stream_indicator:I = 0x7f130042

.field public static cast_expanded_controller_loading:I = 0x7f130043

.field public static cast_expanded_controller_skip_ad_label:I = 0x7f130044

.field public static cast_expanded_controller_skip_ad_text:I = 0x7f130045

.field public static cast_forward:I = 0x7f130046

.field public static cast_forward_10:I = 0x7f130047

.field public static cast_forward_30:I = 0x7f130048

.field public static cast_intro_overlay_button_text:I = 0x7f130049

.field public static cast_invalid_stream_duration_text:I = 0x7f13004a

.field public static cast_invalid_stream_position_text:I = 0x7f13004b

.field public static cast_live_label:I = 0x7f13004c

.field public static cast_mute:I = 0x7f13004d

.field public static cast_notification_connected_message:I = 0x7f13004e

.field public static cast_notification_connecting_message:I = 0x7f13004f

.field public static cast_notification_default_channel_name:I = 0x7f130050

.field public static cast_notification_disconnect:I = 0x7f130051

.field public static cast_pause:I = 0x7f130052

.field public static cast_play:I = 0x7f130053

.field public static cast_rewind:I = 0x7f130054

.field public static cast_rewind_10:I = 0x7f130055

.field public static cast_rewind_30:I = 0x7f130056

.field public static cast_seek_bar:I = 0x7f130057

.field public static cast_skip_next:I = 0x7f130058

.field public static cast_skip_prev:I = 0x7f130059

.field public static cast_stop:I = 0x7f13005a

.field public static cast_stop_live_stream:I = 0x7f13005b

.field public static cast_tracks_chooser_dialog_audio:I = 0x7f13005c

.field public static cast_tracks_chooser_dialog_cancel:I = 0x7f13005d

.field public static cast_tracks_chooser_dialog_closed_captions:I = 0x7f13005e

.field public static cast_tracks_chooser_dialog_default_track_name:I = 0x7f13005f

.field public static cast_tracks_chooser_dialog_none:I = 0x7f130060

.field public static cast_tracks_chooser_dialog_ok:I = 0x7f130061

.field public static cast_tracks_chooser_dialog_subtitles:I = 0x7f130062

.field public static cast_unmute:I = 0x7f130063

.field public static character_counter_content_description:I = 0x7f130064

.field public static character_counter_overflowed_content_description:I = 0x7f130065

.field public static character_counter_pattern:I = 0x7f130066

.field public static clear_text_end_icon_content_description:I = 0x7f130068

.field public static common_google_play_services_enable_button:I = 0x7f130070

.field public static common_google_play_services_enable_text:I = 0x7f130071

.field public static common_google_play_services_enable_title:I = 0x7f130072

.field public static common_google_play_services_install_button:I = 0x7f130073

.field public static common_google_play_services_install_text:I = 0x7f130074

.field public static common_google_play_services_install_title:I = 0x7f130075

.field public static common_google_play_services_notification_channel_name:I = 0x7f130076

.field public static common_google_play_services_notification_ticker:I = 0x7f130077

.field public static common_google_play_services_unknown_issue:I = 0x7f130078

.field public static common_google_play_services_unsupported_text:I = 0x7f130079

.field public static common_google_play_services_update_button:I = 0x7f13007a

.field public static common_google_play_services_update_text:I = 0x7f13007b

.field public static common_google_play_services_update_title:I = 0x7f13007c

.field public static common_google_play_services_updating_text:I = 0x7f13007d

.field public static common_google_play_services_wear_update_text:I = 0x7f13007e

.field public static common_open_on_phone:I = 0x7f13007f

.field public static common_signin_button_text:I = 0x7f130080

.field public static common_signin_button_text_long:I = 0x7f130081

.field public static default_notification_channel_name:I = 0x7f13008d

.field public static error_a11y_label:I = 0x7f1300a1

.field public static error_icon_content_description:I = 0x7f1300a2

.field public static error_message_authentication_expired:I = 0x7f1300a3

.field public static error_message_bad_value:I = 0x7f1300a4

.field public static error_message_concurrent_stream_limit:I = 0x7f1300a5

.field public static error_message_content_already_playing:I = 0x7f1300a6

.field public static error_message_disconnected:I = 0x7f1300a7

.field public static error_message_end_of_playlist:I = 0x7f1300a8

.field public static error_message_fallback:I = 0x7f1300a9

.field public static error_message_info_cancelled:I = 0x7f1300aa

.field public static error_message_invalid_state:I = 0x7f1300ab

.field public static error_message_io:I = 0x7f1300ac

.field public static error_message_not_available_in_region:I = 0x7f1300ad

.field public static error_message_not_supported:I = 0x7f1300ae

.field public static error_message_parental_control_restricted:I = 0x7f1300af

.field public static error_message_permission_denied:I = 0x7f1300b0

.field public static error_message_premium_account_required:I = 0x7f1300b1

.field public static error_message_setup_required:I = 0x7f1300b2

.field public static error_message_skip_limit_reached:I = 0x7f1300b3

.field public static exo_controls_cc_disabled_description:I = 0x7f1300b4

.field public static exo_controls_cc_enabled_description:I = 0x7f1300b5

.field public static exo_controls_custom_playback_speed:I = 0x7f1300b6

.field public static exo_controls_fastforward_description:I = 0x7f1300b7

.field public static exo_controls_fullscreen_enter_description:I = 0x7f1300b8

.field public static exo_controls_fullscreen_exit_description:I = 0x7f1300b9

.field public static exo_controls_hide:I = 0x7f1300ba

.field public static exo_controls_next_description:I = 0x7f1300bb

.field public static exo_controls_overflow_hide_description:I = 0x7f1300bc

.field public static exo_controls_overflow_show_description:I = 0x7f1300bd

.field public static exo_controls_pause_description:I = 0x7f1300be

.field public static exo_controls_play_description:I = 0x7f1300bf

.field public static exo_controls_playback_speed:I = 0x7f1300c0

.field public static exo_controls_previous_description:I = 0x7f1300c1

.field public static exo_controls_repeat_all_description:I = 0x7f1300c2

.field public static exo_controls_repeat_off_description:I = 0x7f1300c3

.field public static exo_controls_repeat_one_description:I = 0x7f1300c4

.field public static exo_controls_rewind_description:I = 0x7f1300c5

.field public static exo_controls_seek_bar_description:I = 0x7f1300c6

.field public static exo_controls_settings_description:I = 0x7f1300c7

.field public static exo_controls_show:I = 0x7f1300c8

.field public static exo_controls_shuffle_off_description:I = 0x7f1300c9

.field public static exo_controls_shuffle_on_description:I = 0x7f1300ca

.field public static exo_controls_stop_description:I = 0x7f1300cb

.field public static exo_controls_time_placeholder:I = 0x7f1300cc

.field public static exo_controls_vr_description:I = 0x7f1300cd

.field public static exo_download_completed:I = 0x7f1300ce

.field public static exo_download_description:I = 0x7f1300cf

.field public static exo_download_downloading:I = 0x7f1300d0

.field public static exo_download_failed:I = 0x7f1300d1

.field public static exo_download_notification_channel_name:I = 0x7f1300d2

.field public static exo_download_paused:I = 0x7f1300d3

.field public static exo_download_paused_for_network:I = 0x7f1300d4

.field public static exo_download_paused_for_wifi:I = 0x7f1300d5

.field public static exo_download_removing:I = 0x7f1300d6

.field public static exo_item_list:I = 0x7f1300d7

.field public static exo_track_bitrate:I = 0x7f1300d8

.field public static exo_track_mono:I = 0x7f1300d9

.field public static exo_track_resolution:I = 0x7f1300da

.field public static exo_track_role_alternate:I = 0x7f1300db

.field public static exo_track_role_closed_captions:I = 0x7f1300dc

.field public static exo_track_role_commentary:I = 0x7f1300dd

.field public static exo_track_role_supplementary:I = 0x7f1300de

.field public static exo_track_selection_auto:I = 0x7f1300df

.field public static exo_track_selection_none:I = 0x7f1300e0

.field public static exo_track_selection_title_audio:I = 0x7f1300e1

.field public static exo_track_stereo:I = 0x7f1300e4

.field public static exo_track_surround:I = 0x7f1300e5

.field public static exo_track_surround_5_point_1:I = 0x7f1300e6

.field public static exo_track_surround_7_point_1:I = 0x7f1300e7

.field public static exo_track_unknown:I = 0x7f1300e8

.field public static exo_track_unknown_name:I = 0x7f1300e9

.field public static exposed_dropdown_menu_content_description:I = 0x7f1300ea

.field public static fab_transformation_scrim_behavior:I = 0x7f1300eb

.field public static fab_transformation_sheet_behavior:I = 0x7f1300ec

.field public static hide_bottom_view_on_scroll_behavior:I = 0x7f1300f3

.field public static ic_media_route_learn_more_accessibility:I = 0x7f1300f4

.field public static icon_content_description:I = 0x7f1300f5

.field public static item_view_role_description:I = 0x7f1300fa

.field public static live:I = 0x7f130101

.field public static m3_exceed_max_badge_text_suffix:I = 0x7f130103

.field public static m3_loading_indicator_content_description:I = 0x7f130104

.field public static m3_ref_typeface_brand_medium:I = 0x7f130105

.field public static m3_ref_typeface_brand_regular:I = 0x7f130106

.field public static m3_ref_typeface_plain_medium:I = 0x7f130107

.field public static m3_ref_typeface_plain_regular:I = 0x7f130108

.field public static m3_sys_motion_easing_emphasized:I = 0x7f130109

.field public static m3_sys_motion_easing_emphasized_accelerate:I = 0x7f13010a

.field public static m3_sys_motion_easing_emphasized_decelerate:I = 0x7f13010b

.field public static m3_sys_motion_easing_emphasized_path_data:I = 0x7f13010c

.field public static m3_sys_motion_easing_legacy:I = 0x7f13010d

.field public static m3_sys_motion_easing_legacy_accelerate:I = 0x7f13010e

.field public static m3_sys_motion_easing_legacy_decelerate:I = 0x7f13010f

.field public static m3_sys_motion_easing_linear:I = 0x7f130110

.field public static m3_sys_motion_easing_standard:I = 0x7f130111

.field public static m3_sys_motion_easing_standard_accelerate:I = 0x7f130112

.field public static m3_sys_motion_easing_standard_decelerate:I = 0x7f130113

.field public static material_clock_display_divider:I = 0x7f13014d

.field public static material_clock_toggle_content_description:I = 0x7f13014e

.field public static material_hour_24h_suffix:I = 0x7f13014f

.field public static material_hour_selection:I = 0x7f130150

.field public static material_hour_suffix:I = 0x7f130151

.field public static material_minute_selection:I = 0x7f130152

.field public static material_minute_suffix:I = 0x7f130153

.field public static material_motion_easing_accelerated:I = 0x7f130154

.field public static material_motion_easing_decelerated:I = 0x7f130155

.field public static material_motion_easing_emphasized:I = 0x7f130156

.field public static material_motion_easing_linear:I = 0x7f130157

.field public static material_motion_easing_standard:I = 0x7f130158

.field public static material_slider_range_end:I = 0x7f130159

.field public static material_slider_range_start:I = 0x7f13015a

.field public static material_slider_value:I = 0x7f13015b

.field public static material_timepicker_am:I = 0x7f13015c

.field public static material_timepicker_clock_mode_description:I = 0x7f13015d

.field public static material_timepicker_hour:I = 0x7f13015e

.field public static material_timepicker_minute:I = 0x7f13015f

.field public static material_timepicker_pm:I = 0x7f130160

.field public static material_timepicker_select_time:I = 0x7f130161

.field public static material_timepicker_text_input_mode_description:I = 0x7f130162

.field public static media3_controls_pause_description:I = 0x7f130164

.field public static media3_controls_play_description:I = 0x7f130165

.field public static media3_controls_seek_back_description:I = 0x7f130166

.field public static media3_controls_seek_forward_description:I = 0x7f130167

.field public static media3_controls_seek_to_next_description:I = 0x7f130168

.field public static media3_controls_seek_to_previous_description:I = 0x7f130169

.field public static media_notification_channel_name:I = 0x7f13016a

.field public static mr_button_content_description:I = 0x7f13016f

.field public static mr_cast_button_connected:I = 0x7f130170

.field public static mr_cast_button_connecting:I = 0x7f130171

.field public static mr_cast_button_disconnected:I = 0x7f130172

.field public static mr_cast_dialog_title_view_placeholder:I = 0x7f130173

.field public static mr_chooser_looking_for_devices:I = 0x7f130174

.field public static mr_chooser_searching:I = 0x7f130175

.field public static mr_chooser_title:I = 0x7f130176

.field public static mr_chooser_wifi_learn_more:I = 0x7f130177

.field public static mr_chooser_wifi_warning_description_car:I = 0x7f130178

.field public static mr_chooser_wifi_warning_description_phone:I = 0x7f130179

.field public static mr_chooser_wifi_warning_description_tablet:I = 0x7f13017a

.field public static mr_chooser_wifi_warning_description_tv:I = 0x7f13017b

.field public static mr_chooser_wifi_warning_description_unknown:I = 0x7f13017c

.field public static mr_chooser_wifi_warning_description_watch:I = 0x7f13017d

.field public static mr_chooser_zero_routes_found_title:I = 0x7f13017e

.field public static mr_controller_album_art:I = 0x7f13017f

.field public static mr_controller_casting_screen:I = 0x7f130180

.field public static mr_controller_close_description:I = 0x7f130181

.field public static mr_controller_collapse_group:I = 0x7f130182

.field public static mr_controller_disconnect:I = 0x7f130183

.field public static mr_controller_expand_group:I = 0x7f130184

.field public static mr_controller_no_info_available:I = 0x7f130185

.field public static mr_controller_no_media_selected:I = 0x7f130186

.field public static mr_controller_pause:I = 0x7f130187

.field public static mr_controller_play:I = 0x7f130188

.field public static mr_controller_stop:I = 0x7f130189

.field public static mr_controller_stop_casting:I = 0x7f13018a

.field public static mr_controller_volume_slider:I = 0x7f13018b

.field public static mr_dialog_default_group_name:I = 0x7f13018c

.field public static mr_dialog_groupable_header:I = 0x7f13018d

.field public static mr_dialog_transferable_header:I = 0x7f13018e

.field public static mr_route_name_bluetooth:I = 0x7f13018f

.field public static mr_route_name_speaker:I = 0x7f130190

.field public static mr_route_name_tv:I = 0x7f130191

.field public static mr_route_name_unknown:I = 0x7f130192

.field public static mr_system_route_name:I = 0x7f130193

.field public static mr_user_route_category_name:I = 0x7f130194

.field public static mtrl_badge_numberless_content_description:I = 0x7f130195

.field public static mtrl_button_collapsed_content_description:I = 0x7f130196

.field public static mtrl_button_expanded_content_description:I = 0x7f130197

.field public static mtrl_checkbox_button_icon_path_checked:I = 0x7f130198

.field public static mtrl_checkbox_button_icon_path_group_name:I = 0x7f130199

.field public static mtrl_checkbox_button_icon_path_indeterminate:I = 0x7f13019a

.field public static mtrl_checkbox_button_icon_path_name:I = 0x7f13019b

.field public static mtrl_checkbox_button_path_checked:I = 0x7f13019c

.field public static mtrl_checkbox_button_path_group_name:I = 0x7f13019d

.field public static mtrl_checkbox_button_path_name:I = 0x7f13019e

.field public static mtrl_checkbox_button_path_unchecked:I = 0x7f13019f

.field public static mtrl_checkbox_state_description_checked:I = 0x7f1301a0

.field public static mtrl_checkbox_state_description_indeterminate:I = 0x7f1301a1

.field public static mtrl_checkbox_state_description_unchecked:I = 0x7f1301a2

.field public static mtrl_chip_close_icon_content_description:I = 0x7f1301a3

.field public static mtrl_exceed_max_badge_number_content_description:I = 0x7f1301a4

.field public static mtrl_exceed_max_badge_number_suffix:I = 0x7f1301a5

.field public static mtrl_picker_a11y_next_month:I = 0x7f1301a6

.field public static mtrl_picker_a11y_prev_month:I = 0x7f1301a7

.field public static mtrl_picker_announce_current_range_selection:I = 0x7f1301a8

.field public static mtrl_picker_announce_current_selection:I = 0x7f1301a9

.field public static mtrl_picker_announce_current_selection_none:I = 0x7f1301aa

.field public static mtrl_picker_cancel:I = 0x7f1301ab

.field public static mtrl_picker_confirm:I = 0x7f1301ac

.field public static mtrl_picker_date_header_selected:I = 0x7f1301ad

.field public static mtrl_picker_date_header_title:I = 0x7f1301ae

.field public static mtrl_picker_date_header_unselected:I = 0x7f1301af

.field public static mtrl_picker_day_of_week_column_header:I = 0x7f1301b0

.field public static mtrl_picker_end_date_description:I = 0x7f1301b1

.field public static mtrl_picker_invalid_format:I = 0x7f1301b2

.field public static mtrl_picker_invalid_format_example:I = 0x7f1301b3

.field public static mtrl_picker_invalid_format_use:I = 0x7f1301b4

.field public static mtrl_picker_invalid_range:I = 0x7f1301b5

.field public static mtrl_picker_navigate_to_current_year_description:I = 0x7f1301b6

.field public static mtrl_picker_navigate_to_year_description:I = 0x7f1301b7

.field public static mtrl_picker_out_of_range:I = 0x7f1301b8

.field public static mtrl_picker_range_header_only_end_selected:I = 0x7f1301b9

.field public static mtrl_picker_range_header_only_start_selected:I = 0x7f1301ba

.field public static mtrl_picker_range_header_selected:I = 0x7f1301bb

.field public static mtrl_picker_range_header_title:I = 0x7f1301bc

.field public static mtrl_picker_range_header_unselected:I = 0x7f1301bd

.field public static mtrl_picker_save:I = 0x7f1301be

.field public static mtrl_picker_start_date_description:I = 0x7f1301bf

.field public static mtrl_picker_text_input_date_hint:I = 0x7f1301c0

.field public static mtrl_picker_text_input_date_range_end_hint:I = 0x7f1301c1

.field public static mtrl_picker_text_input_date_range_start_hint:I = 0x7f1301c2

.field public static mtrl_picker_text_input_day_abbr:I = 0x7f1301c3

.field public static mtrl_picker_text_input_month_abbr:I = 0x7f1301c4

.field public static mtrl_picker_text_input_year_abbr:I = 0x7f1301c5

.field public static mtrl_picker_today_description:I = 0x7f1301c6

.field public static mtrl_picker_toggle_to_calendar_input_mode:I = 0x7f1301c7

.field public static mtrl_picker_toggle_to_day_selection:I = 0x7f1301c8

.field public static mtrl_picker_toggle_to_text_input_mode:I = 0x7f1301c9

.field public static mtrl_picker_toggle_to_year_selection:I = 0x7f1301ca

.field public static mtrl_picker_toggled_to_day_selection:I = 0x7f1301cb

.field public static mtrl_picker_toggled_to_year_selection:I = 0x7f1301cc

.field public static mtrl_switch_thumb_group_name:I = 0x7f1301cd

.field public static mtrl_switch_thumb_path_checked:I = 0x7f1301ce

.field public static mtrl_switch_thumb_path_morphing:I = 0x7f1301cf

.field public static mtrl_switch_thumb_path_name:I = 0x7f1301d0

.field public static mtrl_switch_thumb_path_pressed:I = 0x7f1301d1

.field public static mtrl_switch_thumb_path_unchecked:I = 0x7f1301d2

.field public static mtrl_switch_track_decoration_path:I = 0x7f1301d3

.field public static mtrl_switch_track_path:I = 0x7f1301d4

.field public static mtrl_timepicker_cancel:I = 0x7f1301d5

.field public static mtrl_timepicker_confirm:I = 0x7f1301d6

.field public static nav_rail_collapsed_a11y_label:I = 0x7f1301d7

.field public static nav_rail_expanded_a11y_label:I = 0x7f1301d8

.field public static password_toggle_content_description:I = 0x7f1301f6

.field public static path_password_eye:I = 0x7f1301f7

.field public static path_password_eye_mask_strike_through:I = 0x7f1301f8

.field public static path_password_eye_mask_visible:I = 0x7f1301f9

.field public static path_password_strike_through:I = 0x7f1301fa

.field public static search_menu_title:I = 0x7f130207

.field public static searchbar_scrolling_view_behavior:I = 0x7f130208

.field public static searchview_clear_text_content_description:I = 0x7f130209

.field public static searchview_navigation_content_description:I = 0x7f13020a

.field public static side_sheet_accessibility_pane_title:I = 0x7f13020c

.field public static side_sheet_behavior:I = 0x7f13020d

.field public static status_bar_notification_info_overflow:I = 0x7f130212

.field public static vdo_about_player:I = 0x7f13021a

.field public static vdo_attest_key:I = 0x7f13021b

.field public static vdo_audio_tracks:I = 0x7f13021c

.field public static vdo_available_tracks:I = 0x7f13021d

.field public static vdo_cancel:I = 0x7f13021e

.field public static vdo_caption_not_selected:I = 0x7f13021f

.field public static vdo_caption_search:I = 0x7f130220

.field public static vdo_caption_search_dialog_title:I = 0x7f130221

.field public static vdo_captions:I = 0x7f130222

.field public static vdo_cast_notification_target_activity:I = 0x7f130223

.field public static vdo_chapters:I = 0x7f130224

.field public static vdo_clear_offline_videos:I = 0x7f130225

.field public static vdo_clear_storage:I = 0x7f130226

.field public static vdo_connect_with:I = 0x7f130227

.field public static vdo_contiune:I = 0x7f130228

.field public static vdo_delete_all_saved_videos:I = 0x7f130229

.field public static vdo_delete_videos_unused_from_last_7_days:I = 0x7f13022a

.field public static vdo_delete_videos_unused_from_last_one_month:I = 0x7f13022b

.field public static vdo_discard:I = 0x7f13022c

.field public static vdo_download:I = 0x7f13022d

.field public static vdo_download_permission_required:I = 0x7f13022e

.field public static vdo_enter_your_feedback:I = 0x7f13022f

.field public static vdo_feedback:I = 0x7f130230

.field public static vdo_feedback_about_player:I = 0x7f130231

.field public static vdo_invalid_file_url:I = 0x7f130232

.field public static vdo_loading:I = 0x7f130233

.field public static vdo_manage_your_saved_video_files:I = 0x7f130234

.field public static vdo_network_error:I = 0x7f130235

.field public static vdo_nothing:I = 0x7f130236

.field public static vdo_now_playing_on:I = 0x7f130237

.field public static vdo_playback_detail_error_msg:I = 0x7f130238

.field public static vdo_playback_error_message:I = 0x7f130239

.field public static vdo_player:I = 0x7f13023a

.field public static vdo_primary_color_msg_long:I = 0x7f13023b

.field public static vdo_primary_color_msg_short:I = 0x7f13023c

.field public static vdo_replay:I = 0x7f13023d

.field public static vdo_report_audio_quality_poor:I = 0x7f13023e

.field public static vdo_report_audio_video_out_of_sync:I = 0x7f13023f

.field public static vdo_report_does_not_start_playing:I = 0x7f130240

.field public static vdo_report_got_an_error_message:I = 0x7f130241

.field public static vdo_report_other:I = 0x7f130242

.field public static vdo_report_video_frame_dropping:I = 0x7f130243

.field public static vdo_save_offline:I = 0x7f130244

.field public static vdo_saved_file_s:I = 0x7f130245

.field public static vdo_secure_video_vdocipher:I = 0x7f130246

.field public static vdo_select_an_audio_and_video_track:I = 0x7f130247

.field public static vdo_select_any_one_to_download:I = 0x7f130248

.field public static vdo_select_any_one_track_to_download:I = 0x7f130249

.field public static vdo_submit:I = 0x7f13024a

.field public static vdo_type_here:I = 0x7f13024b

.field public static vdo_unable_to_parse_caption_file:I = 0x7f13024c

.field public static vdo_used_space:I = 0x7f13024d

.field public static vdo_video:I = 0x7f13024e

.field public static vdo_video_quality:I = 0x7f13024f

.field public static vdo_video_speed:I = 0x7f130250

.field public static vdo_videos:I = 0x7f130251

.field public static vdo_waiting_for_video:I = 0x7f130252


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
