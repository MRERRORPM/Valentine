# classes14.dex

.class public final Lcom/vdocipher/aegis/core/m/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vdocipher/aegis/core/f/f$b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/core/m/e$b;
    }
.end annotation


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Lcom/vdocipher/aegis/player/VdoInitParams;

.field private final c:Lcom/vdocipher/aegis/player/PlaybackState;

.field private final d:Lcom/vdocipher/aegis/core/k/c;

.field private final e:Lcom/vdocipher/aegis/core/m/e$b;

.field private final f:Lcom/vdocipher/aegis/core/f/f;

.field private g:Landroidx/media3/exoplayer/offline/Download;

.field private h:Z

.field private i:Ljava/lang/Object;

.field private j:Z

.field private k:Lcom/vdocipher/aegis/core/d/k;

.field private l:Ljava/lang/String;

.field private m:Ljava/lang/String;

.field private n:Lcom/vdocipher/aegis/core/f/g;

.field final o:Z

.field private p:Ljava/lang/String;

.field private q:I

.field private final r:Ljava/lang/String;

.field s:Lcom/vdocipher/aegis/core/m/f;

.field t:Landroid/os/Handler;

.field private final u:Landroid/content/BroadcastReceiver;


# direct methods
.method public static synthetic $r8$lambda$6yPzt3Qu6B81V9L9gC2pTMK-Tqk(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/m/e;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$75SqwC_1YfmvXfI6CgxhBjPbr7c(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/Exception;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/e;->b(Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$ObxeMxD4y2lB-xDlqMGFqopeMSc(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/m/e;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$U5t6zYNcdV1yOpV-jA_AcJtDE48(Lcom/vdocipher/aegis/core/m/e;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/e;->b()V

    return-void
.end method

.method public static synthetic $r8$lambda$dGnSBqBb2b3wEyC0cC6gfCGQTg8(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/e;->c(Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$hc9rV3Z9decJxSju-krW_N5v4Ng(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/e;->d(Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$kL8fQRcgt2tLj9iXcZphP12xqWY(Lcom/vdocipher/aegis/core/m/e;Lcom/vdocipher/aegis/core/m/h;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/m/h;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/player/PlaybackState;ZLcom/vdocipher/aegis/core/k/c;Lcom/vdocipher/aegis/core/m/e$b;)V
    .registers 10

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->g:Landroidx/media3/exoplayer/offline/Download;

    const/4 v1, 0x0

    .line 3
    iput-boolean v1, p0, Lcom/vdocipher/aegis/core/m/e;->h:Z

    .line 6
    iput-boolean v1, p0, Lcom/vdocipher/aegis/core/m/e;->j:Z

    .line 10
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->n:Lcom/vdocipher/aegis/core/f/g;

    .line 17
    iput v1, p0, Lcom/vdocipher/aegis/core/m/e;->q:I

    .line 20
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->t:Landroid/os/Handler;

    .line 23
    new-instance v0, Lcom/vdocipher/aegis/core/m/e$a;

    invoke-direct {v0, p0}, Lcom/vdocipher/aegis/core/m/e$a;-><init>(Lcom/vdocipher/aegis/core/m/e;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->u:Landroid/content/BroadcastReceiver;

    .line 45
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->a:Landroid/content/Context;

    .line 46
    iput-object p3, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    .line 47
    iput-boolean p5, p0, Lcom/vdocipher/aegis/core/m/e;->o:Z

    .line 48
    iput-object p4, p0, Lcom/vdocipher/aegis/core/m/e;->c:Lcom/vdocipher/aegis/player/PlaybackState;

    .line 49
    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->r:Ljava/lang/String;

    .line 50
    iput-object p6, p0, Lcom/vdocipher/aegis/core/m/e;->d:Lcom/vdocipher/aegis/core/k/c;

    .line 51
    iput-object p7, p0, Lcom/vdocipher/aegis/core/m/e;->e:Lcom/vdocipher/aegis/core/m/e$b;

    .line 52
    new-instance p2, Lcom/vdocipher/aegis/core/f/f;

    invoke-direct {p2, p1}, Lcom/vdocipher/aegis/core/f/f;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->f:Lcom/vdocipher/aegis/core/f/f;

    .line 53
    invoke-static {p1}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object p1

    new-instance p2, Landroid/content/IntentFilter;

    const-string/jumbo p3, "vdo-action-retry-playback"

    invoke-direct {p2, p3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0, p2}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V

    return-void
.end method

.method private declared-synchronized a(Ljava/lang/String;Landroid/content/Context;)Landroid/util/Pair;
    .registers 8

    monitor-enter p0

    if-nez p1, :cond_c

    .line 11
    :try_start_3
    new-instance p1, Landroid/util/Pair;

    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-direct {p1, p2, p2}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_a
    .catchall {:try_start_3 .. :try_end_a} :catchall_7f

    monitor-exit p0

    return-object p1

    .line 13
    :cond_c
    :try_start_c
    invoke-static {p2}, Lcom/vdocipher/aegis/core/j/b;->k(Landroid/content/Context;)Lcom/vdocipher/aegis/core/j/a;

    move-result-object v0
    :try_end_10
    .catchall {:try_start_c .. :try_end_10} :catchall_7f

    const/4 v1, 0x0

    .line 15
    :try_start_11
    invoke-virtual {v0, p1}, Lcom/vdocipher/aegis/core/j/a;->a(Ljava/lang/String;)Landroidx/media3/exoplayer/offline/Download;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->g:Landroidx/media3/exoplayer/offline/Download;

    if-nez p1, :cond_22

    .line 16
    new-instance p1, Landroid/util/Pair;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-direct {p1, v0, v0}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_20
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_20} :catch_64
    .catchall {:try_start_11 .. :try_end_20} :catchall_7f

    monitor-exit p0

    return-object p1

    .line 17
    :cond_22
    :try_start_22
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/m/e;->a(Landroidx/media3/exoplayer/offline/Download;)Z

    move-result p1

    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/e;->h:Z

    if-nez p1, :cond_59

    .line 19
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->g:Landroidx/media3/exoplayer/offline/Download;

    invoke-static {p1}, Lcom/vdocipher/aegis/offline/DownloadStatus;->getDownloadStatus(Landroidx/media3/exoplayer/offline/Download;)Lcom/vdocipher/aegis/offline/DownloadStatus;

    move-result-object p1

    invoke-virtual {p1, p2}, Lcom/vdocipher/aegis/offline/DownloadStatus;->isExpired(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_4c

    .line 22
    new-instance v0, Lcom/vdocipher/aegis/core/m/d;

    const-string v2, "DRM KEYS EXPIRED"

    const/4 v3, -0x1

    invoke-direct {v0, v2, v3, v1, v1}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 23
    new-instance v2, Lcom/vdocipher/aegis/core/m/p;

    const/16 v3, 0x182b

    invoke-static {v3}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v3, v4, v0}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    invoke-direct {p0, v2, v1}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/m/p;Ljava/lang/String;)V

    .line 25
    :cond_4c
    new-instance v0, Landroid/util/Pair;

    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-direct {v0, v2, p1}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_57
    .catch Ljava/lang/Exception; {:try_start_22 .. :try_end_57} :catch_64
    .catchall {:try_start_22 .. :try_end_57} :catchall_7f

    monitor-exit p0

    return-object v0

    .line 27
    :cond_59
    :try_start_59
    new-instance p1, Landroid/util/Pair;

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-direct {p1, v0, v2}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_62
    .catch Ljava/lang/Exception; {:try_start_59 .. :try_end_62} :catch_64
    .catchall {:try_start_59 .. :try_end_62} :catchall_7f

    monitor-exit p0

    return-object p1

    :catch_64
    move-exception p1

    .line 29
    :try_start_65
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "LoadSpecPreparer"

    invoke-static {v2, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 30
    invoke-static {p2}, Lcom/vdocipher/aegis/core/k/c;->b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object p2

    const/4 v0, 0x1

    invoke-virtual {p2, p1, v1, v0}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/Throwable;Ljava/lang/String;Z)V

    .line 31
    new-instance p1, Landroid/util/Pair;

    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-direct {p1, p2, p2}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_7d
    .catchall {:try_start_65 .. :try_end_7d} :catchall_7f

    monitor-exit p0

    return-object p1

    :catchall_7f
    move-exception p1

    :try_start_80
    monitor-exit p0
    :try_end_81
    .catchall {:try_start_80 .. :try_end_81} :catchall_7f

    throw p1
.end method

.method private a([Ljava/lang/String;Ljava/lang/String;)Lcom/vdocipher/aegis/core/m/h;
    .registers 8

    .line 223
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->n:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/g;->q()[Ljava/lang/String;

    move-result-object v0

    .line 224
    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->a([Ljava/lang/String;[Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 225
    invoke-static {p1}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "LoadSpecPreparer"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 228
    array-length v0, p1

    const/4 v1, 0x0

    :goto_15
    const/4 v2, 0x0

    if-ge v1, v0, :cond_57

    aget-object v3, p1, v1

    .line 229
    const-string v4, "dash"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_37

    .line 233
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/e;->n:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v2}, Lcom/vdocipher/aegis/core/f/g;->s()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_34

    .line 235
    invoke-static {}, Lcom/vdocipher/aegis/core/t/d;->d()Z

    move-result v2

    if-eqz v2, :cond_54

    .line 236
    :cond_34
    sget-object p1, Lcom/vdocipher/aegis/core/m/h;->b:Lcom/vdocipher/aegis/core/m/h;

    return-object p1

    .line 241
    :cond_37
    const-string v4, "hlse"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_49

    .line 243
    invoke-static {p2}, Lcom/vdocipher/aegis/core/t/d;->i(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_46

    return-object v2

    :cond_46
    sget-object p1, Lcom/vdocipher/aegis/core/m/h;->c:Lcom/vdocipher/aegis/core/m/h;

    return-object p1

    .line 244
    :cond_49
    const-string v2, "h6"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_54

    .line 245
    sget-object p1, Lcom/vdocipher/aegis/core/m/h;->d:Lcom/vdocipher/aegis/core/m/h;

    return-object p1

    :cond_54
    add-int/lit8 v1, v1, 0x1

    goto :goto_15

    :cond_57
    return-object v2
.end method

.method private static a(Lcom/vdocipher/aegis/core/k/c;Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 246
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/k/c;->l(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 247
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/k/c;->n(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    if-eqz v0, :cond_27

    if-eqz p0, :cond_27

    .line 251
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    .line 252
    const-string v1, "ext_manf"

    invoke-virtual {p1, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 253
    const-string p0, "ext_kt"

    const-string v1, "ksid"

    invoke-virtual {p1, p0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 254
    const-string p0, "ext_k"

    invoke-virtual {p1, p0, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 256
    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 257
    :cond_27
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Invalid entry"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private static a(Lcom/vdocipher/aegis/player/VdoInitParams;)Ljava/lang/String;
    .registers 2

    .line 258
    iget-boolean v0, p0, Lcom/vdocipher/aegis/player/VdoInitParams;->offlinePlayback:Z

    if-nez v0, :cond_12

    invoke-static {p0}, Lcom/vdocipher/aegis/core/t/d;->a(Lcom/vdocipher/aegis/player/VdoInitParams;)Z

    move-result v0

    if-eqz v0, :cond_b

    goto :goto_12

    .line 261
    :cond_b
    iget-object p0, p0, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    invoke-static {p0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 262
    :cond_12
    :goto_12
    iget-object p0, p0, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    return-object p0
.end method

.method private a(ILjava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V
    .registers 9

    const/16 v0, 0x190

    const/16 v1, 0x1f4

    const/4 v2, 0x0

    if-lt p1, v0, :cond_27

    if-ge p1, v1, :cond_27

    .line 178
    invoke-static {p2}, Lcom/vdocipher/aegis/core/t/d;->k(Ljava/lang/String;)Landroid/util/Pair;

    move-result-object v0

    const/16 v1, 0x194

    if-ne p1, v1, :cond_14

    const/16 v1, 0x140f

    goto :goto_16

    :cond_14
    const/16 v1, 0x1402

    .line 186
    :goto_16
    iget-object v3, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    if-eqz v3, :cond_20

    .line 187
    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v1

    .line 189
    :cond_20
    iget-object v0, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    if-eqz v0, :cond_39

    .line 190
    check-cast v0, Ljava/lang/String;

    goto :goto_3a

    :cond_27
    if-lt p1, v1, :cond_30

    const/16 v0, 0x258

    if-ge p1, v0, :cond_30

    const/16 v1, 0x1403

    goto :goto_39

    .line 194
    :cond_30
    instance-of v0, p3, Ljava/io/IOException;

    if-eqz v0, :cond_37

    const/16 v1, 0x1404

    goto :goto_39

    :cond_37
    const/16 v1, 0x1400

    :cond_39
    :goto_39
    move-object v0, v2

    .line 199
    :goto_3a
    new-instance v3, Lcom/vdocipher/aegis/core/m/d;

    if-eqz p3, :cond_47

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p3

    goto :goto_49

    :cond_47
    const-string p3, "MetaFetchFailure"

    :goto_49
    invoke-direct {v3, p3, p1, p4, p2}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    if-eqz v0, :cond_54

    .line 202
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_58

    .line 203
    :cond_54
    invoke-static {v1}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v0

    .line 205
    :cond_58
    new-instance p1, Lcom/vdocipher/aegis/core/m/p;

    invoke-direct {p1, v1, v0, v3}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    invoke-direct {p0, p1, v2}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/m/p;Ljava/lang/String;)V

    return-void
.end method

.method private static a(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;Lcom/vdocipher/aegis/core/f/g;Lcom/vdocipher/aegis/player/VdoInitParams;)V
    .registers 8

    if-eqz p0, :cond_2d

    .line 263
    invoke-static {p0, p1}, Lcom/vdocipher/aegis/core/m/c;->c(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    .line 267
    iget-boolean p1, p3, Lcom/vdocipher/aegis/player/VdoInitParams;->offlinePlayback:Z

    if-eqz p1, :cond_c

    .line 268
    iget-object p1, p3, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    goto :goto_12

    .line 270
    :cond_c
    iget-object p1, p3, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 273
    :goto_12
    invoke-virtual {p2}, Lcom/vdocipher/aegis/core/f/g;->q()[Ljava/lang/String;

    move-result-object p3

    .line 274
    invoke-virtual {p2}, Lcom/vdocipher/aegis/core/f/g;->e()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-lez v2, :cond_25

    const-wide/16 v2, 0x3e8

    .line 275
    div-long/2addr v0, v2

    long-to-int v0, v0

    goto :goto_26

    :cond_25
    const/4 v0, 0x0

    .line 276
    :goto_26
    invoke-virtual {p2}, Lcom/vdocipher/aegis/core/f/g;->r()Ljava/lang/String;

    move-result-object p2

    invoke-static {p0, p1, p2, v0, p3}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;Ljava/lang/String;I[Ljava/lang/String;)V

    :cond_2d
    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/m/e;Lcom/vdocipher/aegis/core/m/p;Ljava/lang/String;)V
    .registers 3

    .line 4
    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/m/p;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    .line 2
    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/m/e;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 3
    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/m/e;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private synthetic a(Lcom/vdocipher/aegis/core/m/h;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    .line 168
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/e;->j:Z

    if-nez v0, :cond_7

    .line 169
    invoke-virtual {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/m/e;->b(Lcom/vdocipher/aegis/core/m/h;Ljava/lang/String;Ljava/lang/String;)V

    :cond_7
    return-void
.end method

.method private a(Lcom/vdocipher/aegis/core/m/p;Ljava/lang/String;)V
    .registers 5

    const-string p2, "LoadSpecPreparer"

    .line 215
    :try_start_2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->k:Lcom/vdocipher/aegis/core/d/k;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/e;->a:Landroid/content/Context;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/t/d;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, p2, v1, p1}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/m/p;)V
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_d} :catch_e

    goto :goto_16

    :catch_e
    move-exception v0

    .line 217
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p2, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :goto_16
    if-eqz p1, :cond_32

    .line 219
    iget-object p2, p1, Lcom/vdocipher/aegis/core/m/p;->c:Lcom/vdocipher/aegis/core/m/d;

    if-eqz p2, :cond_32

    iget-boolean v0, p2, Lcom/vdocipher/aegis/core/m/d;->e:Z

    if-nez v0, :cond_32

    .line 220
    new-instance v0, Lcom/vdocipher/aegis/media/ErrorDescription;

    iget v1, p1, Lcom/vdocipher/aegis/core/m/p;->a:I

    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/p;->b:Ljava/lang/String;

    iget p2, p2, Lcom/vdocipher/aegis/core/m/d;->b:I

    invoke-direct {v0, v1, p1, p2}, Lcom/vdocipher/aegis/media/ErrorDescription;-><init>(ILjava/lang/String;I)V

    .line 222
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->e:Lcom/vdocipher/aegis/core/m/e$b;

    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->i:Ljava/lang/Object;

    invoke-interface {p1, p2, v0}, Lcom/vdocipher/aegis/core/m/e$b;->a(Ljava/lang/Object;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    :cond_32
    return-void
.end method

.method private a(Ljava/lang/Exception;)V
    .registers 7

    if-nez p1, :cond_5

    const/16 v0, 0x1006

    goto :goto_e

    .line 170
    :cond_5
    instance-of v0, p1, Lorg/json/JSONException;

    if-eqz v0, :cond_c

    const/16 v0, 0xc1d

    goto :goto_e

    :cond_c
    const/16 v0, 0x1405

    .line 175
    :goto_e
    new-instance v1, Lcom/vdocipher/aegis/core/m/d;

    if-eqz p1, :cond_1b

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v2

    goto :goto_1d

    :cond_1b
    const-string v2, "NoOfflineMeta"

    :goto_1d
    const/4 v3, 0x0

    if-eqz p1, :cond_25

    .line 176
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    goto :goto_26

    :cond_25
    move-object p1, v3

    :goto_26
    const/4 v4, -0x1

    invoke-direct {v1, v2, v4, v3, p1}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 177
    new-instance p1, Lcom/vdocipher/aegis/core/m/p;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p1, v0, v2, v1}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    invoke-direct {p0, p1, v3}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/m/p;Ljava/lang/String;)V

    return-void
.end method

.method private a(Ljava/lang/Exception;Ljava/lang/String;)V
    .registers 8

    .line 206
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0xc1e

    if-eqz v0, :cond_e

    .line 208
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_12

    :cond_e
    invoke-static {v1}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v0

    .line 209
    :cond_12
    new-instance v2, Lcom/vdocipher/aegis/core/m/d;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p1

    const/4 v3, -0x1

    const/4 v4, 0x0

    invoke-direct {v2, p1, v3, v4, v0}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 210
    new-instance p1, Lcom/vdocipher/aegis/core/m/p;

    invoke-direct {p1, v1, v0, v2}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/m/p;Ljava/lang/String;)V

    return-void
.end method

.method private a(Ljava/lang/String;)V
    .registers 6

    .line 211
    const-string v0, "LoadSpecPreparer"

    const-string/jumbo v1, "tech empty"

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 213
    new-instance v0, Lcom/vdocipher/aegis/core/m/d;

    const/4 v1, -0x1

    const/4 v2, 0x0

    const-string v3, "EmptyTech"

    invoke-direct {v0, v3, v1, v2, v2}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 214
    new-instance v1, Lcom/vdocipher/aegis/core/m/p;

    const/16 v2, 0x4c7

    invoke-static {v2}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v2, v3, v0}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    invoke-direct {p0, v1, p1}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/m/p;Ljava/lang/String;)V

    return-void
.end method

.method private synthetic a(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 167
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/e;->j:Z

    if-nez v0, :cond_7

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/m/e;->c(Ljava/lang/String;Ljava/lang/String;)V

    :cond_7
    return-void
.end method

.method private a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 8

    .line 131
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/t/d;->a(Lcom/vdocipher/aegis/player/VdoInitParams;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_16

    .line 132
    const-string/jumbo p1, "{\n  \n  \"audioOnly\": false,\n  \"vdocipherBranding\": true,\n  \"enableReportBug\": true,\n  \"aspectRatio\": 1,\n  \"playerConfig\": {\n    \"options\": {\n      \"collapseInSettings\": [\n        \"chapters\"\n      ],\n      \"confirmBeforeAutoResume\": false,\n      \"enableAirPlay\": true,\n      \"enableAutoResumeLocal\": true,\n      \"enableCaptionSearch\": true,\n      \"enableChromecast\": false,\n      \"enableChapters\": true,\n      \"enableDoubleTapSkip\": true,\n      \"enableKeyboardShortcuts\": true,\n      \"enableLockControls\": true,\n      \"enablePiP\": false,\n      \"enableChromecast\": false,\n      \"enableReportBug\": true,\n      \"enableSaveOffline\": false,\n      \"hideControlsOnPause\": true,\n      \"playbackSpeedOptions\": [\n        0.25,\n        0.5,\n        0.75,\n        1,\n        1.25,\n        1.5,\n        1.75,\n        2\n      ],\n      \"primaryColor\": \"#FF0000\",\n      \"showBackward\": true,\n      \"showCaptionsControl\": true,\n      \"showForward\": true,\n      \"showFullScreen\": true,\n      \"showPlayPauseBtn\": true,\n      \"showProgressBar\": true,\n      \"showQualityControl\": true,\n      \"showReplayAtEnd\": true,\n      \"showScrubbingPreview\": false,\n      \"showSpeedControl\": true,\n      \"showTimeText\": true,\n      \"showVolume\": true,\n      \"skipDuration\": 10,\n      \"conserveVolumeAcrossSession\": true,\n      \"conserveSpeedAcrossSession\": true,\n      \"conserveQualityAcrossSession\": true,\n      \"conserveSelectedCaptionLanguage\": true,\n      \"initialPlayButtonShape\": \"circle\",\n      \"initialDurationPosition\": \"none\"\n    }\n  }\n}"

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->m:Ljava/lang/String;

    .line 133
    iget-boolean p2, p0, Lcom/vdocipher/aegis/core/m/e;->j:Z

    if-nez p2, :cond_e0

    .line 135
    invoke-direct {p0, p1, v1}, Lcom/vdocipher/aegis/core/m/e;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 137
    :cond_16
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->s:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result v0

    if-eqz v0, :cond_26

    .line 138
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object p1, p1, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/e;->e(Ljava/lang/String;)V

    return-void

    .line 141
    :cond_26
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/k/c;->b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object v0

    .line 142
    invoke-virtual {v0, p1}, Lcom/vdocipher/aegis/core/k/c;->o(Ljava/lang/String;)Lcom/vdocipher/aegis/core/p/c;

    move-result-object v2

    if-eqz v2, :cond_48

    .line 144
    invoke-virtual {v2}, Lcom/vdocipher/aegis/core/p/c;->b()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->m:Ljava/lang/String;

    .line 145
    iget-boolean p2, p0, Lcom/vdocipher/aegis/core/m/e;->j:Z

    if-nez p2, :cond_e0

    .line 147
    iget-boolean p2, p0, Lcom/vdocipher/aegis/core/m/e;->o:Z

    if-eqz p2, :cond_44

    invoke-virtual {v2}, Lcom/vdocipher/aegis/core/p/c;->a()Ljava/lang/String;

    move-result-object v1

    :cond_44
    invoke-direct {p0, p1, v1}, Lcom/vdocipher/aegis/core/m/e;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 150
    :cond_48
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "https://dev.vdocipher.com"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->l:Ljava/lang/String;

    if-eqz p2, :cond_7b

    .line 151
    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_7b

    .line 152
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/e;->l:Ljava/lang/String;

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p3, "/player/"

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->l:Ljava/lang/String;

    .line 154
    :cond_7b
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object p1, p1, Lcom/vdocipher/aegis/player/VdoInitParams;->token:Ljava/lang/String;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->i(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_a2

    .line 155
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->l:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "?token="

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object p2, p2, Lcom/vdocipher/aegis/player/VdoInitParams;->token:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->l:Ljava/lang/String;

    goto :goto_be

    .line 157
    :cond_a2
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->l:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "?otp="

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object p2, p2, Lcom/vdocipher/aegis/player/VdoInitParams;->token:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->l:Ljava/lang/String;

    .line 159
    :goto_be
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->l:Ljava/lang/String;

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object p1

    .line 160
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object p2, p2, Lcom/vdocipher/aegis/player/VdoInitParams;->languageCode:Ljava/lang/String;

    invoke-virtual {v0, p1, p2}, Lcom/vdocipher/aegis/core/k/c;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_e1

    .line 161
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_d9

    goto :goto_e1

    .line 164
    :cond_d9
    iget-boolean p2, p0, Lcom/vdocipher/aegis/core/m/e;->j:Z

    if-nez p2, :cond_e0

    .line 165
    invoke-direct {p0, p1, v1}, Lcom/vdocipher/aegis/core/m/e;->c(Ljava/lang/String;Ljava/lang/String;)V

    :cond_e0
    return-void

    .line 166
    :cond_e1
    :goto_e1
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->f:Lcom/vdocipher/aegis/core/f/f;

    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->l:Ljava/lang/String;

    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v0, p3, Lcom/vdocipher/aegis/player/VdoInitParams;->languageCode:Ljava/lang/String;

    invoke-virtual {p1, p2, v0, p3, p0}, Lcom/vdocipher/aegis/core/f/f;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;Lcom/vdocipher/aegis/core/f/f$b;)V

    return-void
.end method

.method private a()Z
    .registers 4

    .line 32
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->p:Ljava/lang/String;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    .line 35
    :cond_6
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/b;->k(Landroid/content/Context;)Lcom/vdocipher/aegis/core/j/a;

    move-result-object v0

    .line 37
    :try_start_c
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/e;->p:Ljava/lang/String;

    invoke-virtual {v0, v2}, Lcom/vdocipher/aegis/core/j/a;->a(Ljava/lang/String;)Landroidx/media3/exoplayer/offline/Download;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->g:Landroidx/media3/exoplayer/offline/Download;
    :try_end_14
    .catch Ljava/io/IOException; {:try_start_c .. :try_end_14} :catch_19

    if-eqz v0, :cond_18

    const/4 v0, 0x1

    return v0

    :cond_18
    return v1

    :catch_19
    move-exception v0

    .line 40
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "LoadSpecPreparer"

    invoke-static {v2, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return v1
.end method

.method private static a(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)Z
    .registers 7

    .line 126
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getHash()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz p0, :cond_1c

    .line 128
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getHash()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getHash()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1c

    move v3, v1

    goto :goto_1d

    :cond_1c
    move v3, v2

    :goto_1d
    if-nez p0, :cond_2a

    .line 130
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getHash()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result p0

    if-nez p0, :cond_2a

    return v1

    :cond_2a
    if-nez v0, :cond_2f

    if-eqz v3, :cond_2f

    return v1

    :cond_2f
    return v2
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/m/e;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcom/vdocipher/aegis/core/m/e;->j:Z

    return p0
.end method

.method static synthetic b(Lcom/vdocipher/aegis/core/m/e;)I
    .registers 1

    .line 1
    iget p0, p0, Lcom/vdocipher/aegis/core/m/e;->q:I

    return p0
.end method

.method private synthetic b()V
    .registers 3

    .line 2
    :try_start_0
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/e;->o:Z

    if-nez v0, :cond_1a

    .line 3
    invoke-static {}, Lcom/vdocipher/aegis/core/t/e;->a()Lcom/vdocipher/aegis/core/t/e;

    move-result-object v0

    .line 4
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/e;->k:Lcom/vdocipher/aegis/core/d/k;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/t/e;->b()Lorg/json/JSONObject;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/m/c;->b(Lcom/vdocipher/aegis/core/d/k;Lorg/json/JSONObject;)V

    .line 5
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->k:Lcom/vdocipher/aegis/core/d/k;

    invoke-static {}, Lcom/vdocipher/aegis/core/t/d;->c()Lorg/json/JSONArray;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/d/k;Lorg/json/JSONArray;)V
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_1a} :catch_1b

    :cond_1a
    return-void

    :catch_1b
    move-exception v0

    .line 9
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "LoadSpecPreparer"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private synthetic b(Ljava/lang/Exception;)V
    .registers 3

    .line 10
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/e;->j:Z

    if-nez v0, :cond_7

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/e;->a(Ljava/lang/Exception;)V

    :cond_7
    return-void
.end method

.method private b(Ljava/lang/Exception;Ljava/lang/String;)V
    .registers 7

    .line 111
    new-instance v0, Lcom/vdocipher/aegis/core/m/d;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v2, -0x1

    const/4 v3, 0x0

    invoke-direct {v0, v1, v2, v3, p1}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 112
    new-instance p1, Lcom/vdocipher/aegis/core/m/p;

    const/16 v1, 0x17d6

    invoke-static {v1}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p1, v1, v2, v0}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/m/p;Ljava/lang/String;)V

    return-void
.end method

.method private b(Ljava/lang/String;)V
    .registers 6

    .line 107
    const-string v0, "LoadSpecPreparer"

    const-string v1, "not supported"

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 109
    new-instance v0, Lcom/vdocipher/aegis/core/m/d;

    const/4 v1, -0x1

    const/4 v2, 0x0

    const-string v3, "UnsupportedTech"

    invoke-direct {v0, v3, v1, v2, v2}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 110
    new-instance v1, Lcom/vdocipher/aegis/core/m/p;

    const/16 v2, 0x4c4

    invoke-static {v2}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v2, v3, v0}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    invoke-direct {p0, v1, p1}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/m/p;Ljava/lang/String;)V

    return-void
.end method

.method private synthetic b(Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    .line 11
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/t/d;->a(Lcom/vdocipher/aegis/player/VdoInitParams;)Z

    move-result v0

    if-eqz v0, :cond_b

    .line 12
    sget-object v0, Lcom/vdocipher/aegis/core/m/h;->f:Lcom/vdocipher/aegis/core/m/h;

    goto :goto_2d

    .line 13
    :cond_b
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->s:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result v0

    if-eqz v0, :cond_16

    .line 14
    sget-object v0, Lcom/vdocipher/aegis/core/m/h;->b:Lcom/vdocipher/aegis/core/m/h;

    goto :goto_2d

    .line 17
    :cond_16
    :try_start_16
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->n:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/g;->q()[Ljava/lang/String;

    move-result-object v0

    .line 18
    array-length v0, v0

    if-nez v0, :cond_23

    .line 19
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/e;->a(Ljava/lang/String;)V

    return-void

    .line 22
    :cond_23
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v1, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->techOverride:[Ljava/lang/String;

    iget-object v0, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->token:Ljava/lang/String;

    invoke-direct {p0, v1, v0}, Lcom/vdocipher/aegis/core/m/e;->a([Ljava/lang/String;Ljava/lang/String;)Lcom/vdocipher/aegis/core/m/h;

    move-result-object v0
    :try_end_2d
    .catch Ljava/lang/Exception; {:try_start_16 .. :try_end_2d} :catch_3e

    :goto_2d
    if-nez v0, :cond_33

    .line 31
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/e;->b(Ljava/lang/String;)V

    return-void

    .line 35
    :cond_33
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/e;->t:Landroid/os/Handler;

    new-instance v2, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda6;

    invoke-direct {v2, p0, v0, p1, p2}, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda6;-><init>(Lcom/vdocipher/aegis/core/m/e;Lcom/vdocipher/aegis/core/m/h;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :catch_3e
    move-exception p2

    .line 36
    invoke-static {p2}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "LoadSpecPreparer"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 37
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/t/d;->a(Lcom/vdocipher/aegis/player/VdoInitParams;)Z

    move-result v0

    if-nez v0, :cond_53

    .line 38
    invoke-direct {p0, p2, p1}, Lcom/vdocipher/aegis/core/m/e;->a(Ljava/lang/Exception;Ljava/lang/String;)V

    :cond_53
    return-void
.end method

.method static synthetic c(Lcom/vdocipher/aegis/core/m/e;)I
    .registers 3

    .line 1
    iget v0, p0, Lcom/vdocipher/aegis/core/m/e;->q:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Lcom/vdocipher/aegis/core/m/e;->q:I

    return v0
.end method

.method private c()Ljava/lang/String;
    .registers 6

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->g:Landroidx/media3/exoplayer/offline/Download;

    const/4 v1, 0x0

    if-eqz v0, :cond_18

    .line 3
    new-instance v0, Lorg/json/JSONObject;

    new-instance v2, Ljava/lang/String;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/e;->g:Landroidx/media3/exoplayer/offline/Download;

    iget-object v3, v3, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    iget-object v3, v3, Landroidx/media3/exoplayer/offline/DownloadRequest;->data:[B

    sget-object v4, Lcom/google/common/base/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v2, v3, v4}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v0, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    goto :goto_19

    :cond_18
    move-object v0, v1

    :goto_19
    if-eqz v0, :cond_22

    .line 7
    const-string v1, "annotationCode"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_22
    return-object v1
.end method

.method private synthetic c(Ljava/lang/String;)V
    .registers 9

    const-string v0, "LoadSpecPreparer"

    const-string v1, "got : "

    .line 8
    new-instance v2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x0

    .line 13
    :try_start_e
    iget-object v4, p0, Lcom/vdocipher/aegis/core/m/e;->g:Landroidx/media3/exoplayer/offline/Download;

    if-nez v4, :cond_1f

    .line 14
    iget-object v4, p0, Lcom/vdocipher/aegis/core/m/e;->d:Lcom/vdocipher/aegis/core/k/c;

    invoke-virtual {v4, p1}, Lcom/vdocipher/aegis/core/k/c;->p(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_18} :catch_3f

    .line 15
    :try_start_18
    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/e;->d:Lcom/vdocipher/aegis/core/k/c;

    invoke-virtual {v5, p1}, Lcom/vdocipher/aegis/core/k/c;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_1e
    .catch Ljava/lang/Exception; {:try_start_18 .. :try_end_1e} :catch_3a

    goto :goto_27

    .line 17
    :cond_1f
    :try_start_1f
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/e;->d()Ljava/lang/String;

    move-result-object v4
    :try_end_23
    .catch Ljava/lang/Exception; {:try_start_1f .. :try_end_23} :catch_3f

    .line 18
    :try_start_23
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/e;->c()Ljava/lang/String;

    move-result-object p1
    :try_end_27
    .catch Ljava/lang/Exception; {:try_start_23 .. :try_end_27} :catch_3a

    .line 20
    :goto_27
    :try_start_27
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_36
    .catch Ljava/lang/Exception; {:try_start_27 .. :try_end_36} :catch_37

    goto :goto_4a

    :catch_37
    move-exception v1

    move-object v3, v1

    goto :goto_43

    :catch_3a
    move-exception p1

    move-object v6, v3

    move-object v3, p1

    move-object p1, v6

    goto :goto_43

    :catch_3f
    move-exception p1

    move-object v4, v3

    move-object v3, p1

    move-object p1, v4

    .line 22
    :goto_43
    invoke-static {v3}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :goto_4a
    if-eqz v4, :cond_55

    .line 29
    new-instance v0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0, v4, p1}, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda1;-><init>(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_5d

    .line 35
    :cond_55
    new-instance p1, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda2;

    invoke-direct {p1, p0, v3}, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda2;-><init>(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/Exception;)V

    invoke-virtual {v2, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_5d
    return-void
.end method

.method private c(Ljava/lang/String;Ljava/lang/String;)V
    .registers 8

    const-string v0, "LoadSpecPreparer"

    .line 36
    :try_start_2
    new-instance v1, Lcom/vdocipher/aegis/core/f/g;

    invoke-direct {v1, p1}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/e;->n:Lcom/vdocipher/aegis/core/f/g;

    .line 37
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/f/g;->j()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    move-result-object v1

    .line 39
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/e;->a:Landroid/content/Context;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/t/c;->a(Landroid/content/Context;)Lcom/vdocipher/aegis/core/t/c;

    move-result-object v2

    invoke-virtual {v1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getHash()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/vdocipher/aegis/core/t/c;->a(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    move-result-object v2

    .line 42
    invoke-static {v2, v1}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)Z

    move-result v1

    if-eqz v1, :cond_32

    .line 45
    new-instance v1, Lcom/vdocipher/aegis/core/f/e;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/e;->a:Landroid/content/Context;

    invoke-direct {v1, v2}, Lcom/vdocipher/aegis/core/f/e;-><init>(Landroid/content/Context;)V

    .line 46
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/e;->n:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v2}, Lcom/vdocipher/aegis/core/f/g;->j()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/vdocipher/aegis/core/f/e;->a(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V

    goto :goto_47

    .line 48
    :cond_32
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/e;->a:Landroid/content/Context;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/z/b;->a(Landroid/content/Context;)Lcom/vdocipher/aegis/core/z/b;

    move-result-object v1

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/e;->a:Landroid/content/Context;

    if-eqz v2, :cond_41

    invoke-virtual {v2}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getHash()Ljava/lang/String;

    move-result-object v2

    goto :goto_43

    :cond_41
    const-string v2, ""

    :goto_43
    const/4 v4, 0x0

    invoke-virtual {v1, v3, v4, v2}, Lcom/vdocipher/aegis/core/z/b;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_47
    .catch Lcom/vdocipher/aegis/core/f/d; {:try_start_2 .. :try_end_47} :catch_9e

    .line 58
    :goto_47
    :try_start_47
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/e;->k:Lcom/vdocipher/aegis/core/d/k;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/e;->n:Lcom/vdocipher/aegis/core/f/g;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-static {v1, p1, v2, v3}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;Lcom/vdocipher/aegis/core/f/g;Lcom/vdocipher/aegis/player/VdoInitParams;)V
    :try_end_50
    .catch Ljava/lang/Exception; {:try_start_47 .. :try_end_50} :catch_51

    goto :goto_59

    :catch_51
    move-exception v1

    .line 60
    invoke-static {v1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 64
    :goto_59
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->k:Lcom/vdocipher/aegis/core/d/k;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/e;->n:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/f/g;->m()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/m/c;->j(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    .line 67
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->t:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0, p1}, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda3;-><init>(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 69
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/k/c;->b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v1, v1, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/e;->k:Lcom/vdocipher/aegis/core/d/k;

    iget-object v2, v2, Lcom/vdocipher/aegis/core/d/k;->e:Ljava/lang/String;

    invoke-virtual {v0, v1, v2, p1, p2}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 70
    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "bgThread"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    .line 71
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 72
    new-instance v1, Landroid/os/Handler;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 73
    new-instance v2, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda4;

    invoke-direct {v2, p0, p1, p2}, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda4;-><init>(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 107
    invoke-virtual {v0}, Landroid/os/HandlerThread;->quitSafely()Z

    return-void

    :catch_9e
    move-exception p1

    .line 108
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private d()Ljava/lang/String;
    .registers 6

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->g:Landroidx/media3/exoplayer/offline/Download;

    const/4 v1, 0x0

    if-eqz v0, :cond_18

    .line 3
    new-instance v0, Lorg/json/JSONObject;

    new-instance v2, Ljava/lang/String;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/e;->g:Landroidx/media3/exoplayer/offline/Download;

    iget-object v3, v3, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    iget-object v3, v3, Landroidx/media3/exoplayer/offline/DownloadRequest;->data:[B

    sget-object v4, Lcom/google/common/base/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v2, v3, v4}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v0, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    goto :goto_19

    :cond_18
    move-object v0, v1

    :goto_19
    if-eqz v0, :cond_22

    .line 7
    const-string v2, "dlspec"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_23

    :cond_22
    move-object v0, v1

    :goto_23
    if-eqz v0, :cond_31

    .line 10
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 11
    const-string v0, "dss.meta"

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_31
    return-object v1
.end method

.method static synthetic d(Lcom/vdocipher/aegis/core/m/e;)Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/e;->m:Ljava/lang/String;

    return-object p0
.end method

.method private synthetic d(Ljava/lang/String;)V
    .registers 3

    .line 12
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->e:Lcom/vdocipher/aegis/core/m/e$b;

    invoke-interface {v0, p1}, Lcom/vdocipher/aegis/core/m/e$b;->a(Ljava/lang/String;)V

    return-void
.end method

.method private e()Ljava/lang/String;
    .registers 5

    .line 42
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/e;->h:Z

    if-eqz v0, :cond_e

    .line 43
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 46
    :cond_e
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->g:Landroidx/media3/exoplayer/offline/Download;

    iget-object v0, v0, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    iget-object v0, v0, Landroidx/media3/exoplayer/offline/DownloadRequest;->keySetId:[B

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_38

    .line 53
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    .line 54
    const-string v2, "ext_manf"

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 55
    const-string v2, "ext_kt"

    const-string v3, "ksid"

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 56
    const-string v2, "ext_k"

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 58
    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 59
    :cond_38
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Invalid entry"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static synthetic e(Lcom/vdocipher/aegis/core/m/e;)Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/e;->p:Ljava/lang/String;

    return-object p0
.end method

.method private e(Ljava/lang/String;)V
    .registers 5

    .line 2
    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "LoadSpecPreparer"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    .line 3
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 4
    new-instance v1, Landroid/os/Handler;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 7
    new-instance v2, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda5;

    invoke-direct {v2, p0, p1}, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda5;-><init>(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 41
    invoke-virtual {v0}, Landroid/os/HandlerThread;->quitSafely()Z

    return-void
.end method

.method static synthetic f(Lcom/vdocipher/aegis/core/m/e;)Lcom/vdocipher/aegis/player/VdoInitParams;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    return-object p0
.end method


# virtual methods
.method public a(Landroid/content/Context;Ljava/lang/Object;)V
    .registers 12

    .line 41
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/e;->j:Z

    if-nez v0, :cond_10f

    .line 43
    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->i:Ljava/lang/Object;

    .line 46
    :try_start_6
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-static {p2}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/player/VdoInitParams;)Ljava/lang/String;

    move-result-object p2

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->p:Ljava/lang/String;
    :try_end_e
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_6 .. :try_end_e} :catch_e8
    .catch Lorg/json/JSONException; {:try_start_6 .. :try_end_e} :catch_e6
    .catch Ljava/lang/IllegalArgumentException; {:try_start_6 .. :try_end_e} :catch_e3

    .line 59
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-boolean v0, p2, Lcom/vdocipher/aegis/player/VdoInitParams;->offlinePlayback:Z

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_1d

    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/e;->h:Z

    if-eqz v0, :cond_1b

    goto :goto_1d

    :cond_1b
    move v0, v1

    goto :goto_1e

    :cond_1d
    :goto_1d
    move v0, v2

    .line 62
    :goto_1e
    iget-boolean v3, p0, Lcom/vdocipher/aegis/core/m/e;->h:Z

    if-nez v3, :cond_31

    iget-object v3, p2, Lcom/vdocipher/aegis/player/VdoInitParams;->otp:Ljava/lang/String;

    if-eqz v3, :cond_31

    iget-object p2, p2, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    if-eqz p2, :cond_31

    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/e;->a()Z

    move-result p2

    if-nez p2, :cond_31

    move v1, v2

    :cond_31
    if-nez v0, :cond_37

    .line 64
    iget-boolean p2, p0, Lcom/vdocipher/aegis/core/m/e;->h:Z

    if-eqz p2, :cond_3e

    :cond_37
    if-nez v1, :cond_3e

    .line 65
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->p:Ljava/lang/String;

    invoke-direct {p0, p2, p1}, Lcom/vdocipher/aegis/core/m/e;->a(Ljava/lang/String;Landroid/content/Context;)Landroid/util/Pair;

    .line 68
    :cond_3e
    new-instance p2, Lcom/vdocipher/aegis/core/m/f;

    invoke-direct {p2}, Lcom/vdocipher/aegis/core/m/f;-><init>()V

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->s:Lcom/vdocipher/aegis/core/m/f;

    .line 69
    invoke-virtual {p2, v0}, Lcom/vdocipher/aegis/core/m/f;->a(Z)V

    .line 70
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->s:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {p2, v1}, Lcom/vdocipher/aegis/core/m/f;->b(Z)V

    .line 71
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->s:Lcom/vdocipher/aegis/core/m/f;

    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/e;->h:Z

    invoke-virtual {p2, v0}, Lcom/vdocipher/aegis/core/m/f;->c(Z)V

    .line 72
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->s:Lcom/vdocipher/aegis/core/m/f;

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->p:Ljava/lang/String;

    invoke-virtual {p2, v0}, Lcom/vdocipher/aegis/core/m/f;->a(Ljava/lang/String;)V

    .line 75
    invoke-static {}, Lcom/vdocipher/aegis/core/d/i;->a()Lcom/vdocipher/aegis/core/d/i;

    move-result-object p2

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->p:Ljava/lang/String;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/e;->s:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result v1

    invoke-virtual {p2, v0, v1}, Lcom/vdocipher/aegis/core/d/i;->a(Ljava/lang/String;Z)Lcom/vdocipher/aegis/core/d/k;

    move-result-object p2

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->k:Lcom/vdocipher/aegis/core/d/k;

    .line 77
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-boolean v8, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->disableAnalytics:Z

    if-nez p2, :cond_8f

    .line 80
    invoke-static {}, Lcom/vdocipher/aegis/core/d/i;->a()Lcom/vdocipher/aegis/core/d/i;

    move-result-object v1

    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v3, p2, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    iget-object v4, p2, Lcom/vdocipher/aegis/player/VdoInitParams;->otp:Ljava/lang/String;

    iget-object v5, p2, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    iget-object v6, p2, Lcom/vdocipher/aegis/player/VdoInitParams;->customPlayerId:Ljava/lang/String;

    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->s:Lcom/vdocipher/aegis/core/m/f;

    .line 81
    invoke-virtual {p2}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result v7

    move-object v2, p1

    .line 82
    invoke-virtual/range {v1 .. v8}, Lcom/vdocipher/aegis/core/d/i;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZ)Lcom/vdocipher/aegis/core/d/k;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->k:Lcom/vdocipher/aegis/core/d/k;

    goto :goto_90

    :cond_8f
    move-object v2, p1

    .line 87
    :goto_90
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-boolean p1, p1, Lcom/vdocipher/aegis/player/VdoInitParams;->offlinePlayback:Z

    if-nez p1, :cond_9a

    iget-boolean p1, p0, Lcom/vdocipher/aegis/core/m/e;->h:Z

    if-eqz p1, :cond_b5

    .line 88
    :cond_9a
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->p:Ljava/lang/String;

    invoke-direct {p0, p1, v2}, Lcom/vdocipher/aegis/core/m/e;->a(Ljava/lang/String;Landroid/content/Context;)Landroid/util/Pair;

    move-result-object p1

    .line 89
    iget-object p2, p1, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    .line 90
    iget-object p1, p1, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p2, :cond_b5

    if-eqz p1, :cond_b5

    goto :goto_e2

    .line 99
    :cond_b5
    new-instance p1, Landroid/os/HandlerThread;

    const-string p2, "LoadSpecPreparer-cdm"

    invoke-direct {p1, p2}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    .line 100
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    .line 101
    new-instance p2, Landroid/os/Handler;

    invoke-virtual {p1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p2, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 103
    new-instance v0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0}, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/core/m/e;)V

    invoke-virtual {p2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 117
    invoke-virtual {p1}, Landroid/os/HandlerThread;->quitSafely()Z

    .line 119
    iget-boolean p1, p0, Lcom/vdocipher/aegis/core/m/e;->j:Z

    if-nez p1, :cond_e2

    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->p:Ljava/lang/String;

    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object p2, p2, Lcom/vdocipher/aegis/player/VdoInitParams;->customPlayerId:Ljava/lang/String;

    const-string v0, "/api/meta/o/"

    invoke-direct {p0, p1, p2, v0}, Lcom/vdocipher/aegis/core/m/e;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_e2
    :goto_e2
    return-void

    :catch_e3
    move-exception v0

    :goto_e4
    move-object p1, v0

    goto :goto_ea

    :catch_e6
    move-exception v0

    goto :goto_e4

    :catch_e8
    move-exception v0

    goto :goto_e4

    .line 120
    :goto_ea
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p2

    const-string v0, "LoadSpecPreparer"

    invoke-static {v0, p2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 122
    new-instance p2, Lcom/vdocipher/aegis/core/m/d;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const-string v0, "InvalidPI"

    const/4 v1, -0x1

    const/4 v2, 0x0

    invoke-direct {p2, v0, v1, v2, p1}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 124
    new-instance p1, Lcom/vdocipher/aegis/core/m/p;

    const/16 v0, 0x1005

    invoke-static {v0}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p1, v0, v1, p2}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    invoke-direct {p0, p1, v2}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/m/p;Ljava/lang/String;)V

    return-void

    .line 125
    :cond_10f
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    throw p1
.end method

.method public a(Landroidx/media3/exoplayer/offline/Download;)Z
    .registers 5

    .line 5
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    new-instance v1, Ljava/lang/String;

    iget-object p1, p1, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    iget-object p1, p1, Landroidx/media3/exoplayer/offline/DownloadRequest;->data:[B

    sget-object v2, Lcom/google/common/base/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v1, p1, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_10
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_10} :catch_11

    goto :goto_1c

    :catch_11
    move-exception p1

    .line 7
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "LoadSpecPreparer"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x0

    :goto_1c
    const/4 p1, 0x0

    if-eqz v0, :cond_25

    .line 10
    const-string v1, "saved_offline"

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result p1

    :cond_25
    return p1
.end method

.method b(Lcom/vdocipher/aegis/core/m/h;Ljava/lang/String;Ljava/lang/String;)V
    .registers 27

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    .line 39
    iget-boolean v0, v1, Lcom/vdocipher/aegis/core/m/e;->o:Z

    const-string v3, "LoadSpecPreparer"

    if-nez v0, :cond_1c

    .line 41
    :try_start_a
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/e;->k:Lcom/vdocipher/aegis/core/d/k;

    invoke-virtual {v2}, Lcom/vdocipher/aegis/core/m/h;->b()Ljava/lang/String;

    move-result-object v4

    invoke-static {v0, v4}, Lcom/vdocipher/aegis/core/m/c;->e(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_13} :catch_14

    goto :goto_1c

    :catch_14
    move-exception v0

    .line 43
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 51
    :cond_1c
    :goto_1c
    :try_start_1c
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/e;->n:Lcom/vdocipher/aegis/core/f/g;

    iget-object v5, v1, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v6, v5, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    iget-object v5, v5, Lcom/vdocipher/aegis/player/VdoInitParams;->configMap:Ljava/util/HashMap;

    invoke-virtual {v0, v6, v5}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/lang/String;Ljava/util/HashMap;)Lcom/vdocipher/aegis/media/PlayerOption;

    move-result-object v5
    :try_end_28
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_28} :catch_33

    .line 52
    :try_start_28
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/e;->n:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/g;->i()Ljava/lang/String;

    move-result-object v0
    :try_end_2e
    .catch Ljava/lang/Exception; {:try_start_28 .. :try_end_2e} :catch_31

    move-object/from16 v21, v0

    goto :goto_3e

    :catch_31
    move-exception v0

    goto :goto_35

    :catch_33
    move-exception v0

    const/4 v5, 0x0

    .line 54
    :goto_35
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v21, 0x0

    .line 63
    :goto_3e
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-boolean v0, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->autoplay:Z

    .line 65
    iget-object v6, v1, Lcom/vdocipher/aegis/core/m/e;->c:Lcom/vdocipher/aegis/player/PlaybackState;

    if-eqz v6, :cond_59

    .line 66
    iget-wide v7, v6, Lcom/vdocipher/aegis/player/PlaybackState;->playbackTimeMs:J

    long-to-int v0, v7

    .line 67
    iget-object v5, v6, Lcom/vdocipher/aegis/player/PlaybackState;->captionsOverride:Ljava/lang/String;

    .line 68
    iget-object v7, v6, Lcom/vdocipher/aegis/player/PlaybackState;->nonAdaptiveSelectedTracks:[Lcom/vdocipher/aegis/media/Track;

    .line 69
    iget v8, v6, Lcom/vdocipher/aegis/player/PlaybackState;->playbackSpeed:F

    .line 70
    iget-boolean v6, v6, Lcom/vdocipher/aegis/player/PlaybackState;->wasPlaying:Z

    move v9, v0

    move-object v10, v5

    move/from16 v18, v6

    move-object v11, v7

    move/from16 v17, v8

    goto :goto_bc

    :cond_59
    const/4 v6, 0x0

    const/high16 v8, 0x3f800000  # 1.0f

    if-eqz v5, :cond_b5

    .line 74
    invoke-virtual {v5}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object v5

    invoke-static {v5}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/vdocipher/aegis/core/f/i;

    invoke-virtual {v5}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object v5

    if-eqz v5, :cond_b5

    .line 75
    sget-object v7, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v5}, Lcom/vdocipher/aegis/core/f/h;->e()Ljava/lang/Boolean;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_b5

    .line 76
    invoke-static {}, Lcom/vdocipher/aegis/core/r/a;->a()Lcom/vdocipher/aegis/core/r/a;

    move-result-object v7

    iget-object v9, v1, Lcom/vdocipher/aegis/core/m/e;->a:Landroid/content/Context;

    invoke-virtual {v7, v9}, Lcom/vdocipher/aegis/core/r/a;->b(Landroid/content/Context;)F

    move-result v7

    .line 77
    invoke-virtual {v5}, Lcom/vdocipher/aegis/core/f/h;->l()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v9

    const-wide v10, 0x408ff80000000000L  # 1023.0

    move v12, v6

    :goto_92
    if-ge v12, v9, :cond_b5

    invoke-virtual {v5, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    add-int/lit8 v12, v12, 0x1

    check-cast v13, Ljava/lang/Double;

    invoke-virtual {v13}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v13

    move-object/from16 v16, v5

    float-to-double v4, v7

    sub-double v4, v13, v4

    .line 78
    invoke-static {v4, v5}, Ljava/lang/Math;->abs(D)D

    move-result-wide v17

    cmpg-double v17, v17, v10

    if-gez v17, :cond_b2

    double-to-float v8, v13

    .line 80
    invoke-static {v4, v5}, Ljava/lang/Math;->abs(D)D

    move-result-wide v10

    :cond_b2
    move-object/from16 v5, v16

    goto :goto_92

    :cond_b5
    move/from16 v18, v0

    move v9, v6

    move/from16 v17, v8

    const/4 v10, 0x0

    const/4 v11, 0x0

    .line 86
    :goto_bc
    sget-object v0, Lcom/vdocipher/aegis/core/m/h;->b:Lcom/vdocipher/aegis/core/m/h;

    if-ne v0, v2, :cond_f2

    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/e;->s:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result v0

    if-eqz v0, :cond_f2

    .line 89
    :try_start_c8
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/e;->g:Landroidx/media3/exoplayer/offline/Download;

    if-nez v0, :cond_d7

    .line 90
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/e;->d:Lcom/vdocipher/aegis/core/k/c;

    iget-object v4, v1, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v4, v4, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    invoke-static {v0, v4}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/k/c;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_db

    .line 92
    :cond_d7
    invoke-direct {v1}, Lcom/vdocipher/aegis/core/m/e;->e()Ljava/lang/String;

    move-result-object v0
    :try_end_db
    .catch Lorg/json/JSONException; {:try_start_c8 .. :try_end_db} :catch_e4
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_c8 .. :try_end_db} :catch_e2
    .catch Ljava/lang/IllegalStateException; {:try_start_c8 .. :try_end_db} :catch_e0

    :goto_db
    move-object v4, v0

    move-object/from16 v8, p2

    move-object v14, v4

    goto :goto_f5

    :catch_e0
    move-exception v0

    goto :goto_e5

    :catch_e2
    move-exception v0

    goto :goto_e5

    :catch_e4
    move-exception v0

    .line 94
    :goto_e5
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    move-object/from16 v8, p2

    .line 95
    invoke-direct {v1, v0, v8}, Lcom/vdocipher/aegis/core/m/e;->b(Ljava/lang/Exception;Ljava/lang/String;)V

    return-void

    :cond_f2
    move-object/from16 v8, p2

    const/4 v14, 0x0

    .line 100
    :goto_f5
    new-instance v6, Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v7, v1, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v15, v1, Lcom/vdocipher/aegis/core/m/e;->g:Landroidx/media3/exoplayer/offline/Download;

    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/e;->s:Lcom/vdocipher/aegis/core/m/f;

    iget-boolean v3, v1, Lcom/vdocipher/aegis/core/m/e;->o:Z

    iget-object v4, v1, Lcom/vdocipher/aegis/core/m/e;->r:Ljava/lang/String;

    sget-object v5, Lcom/vdocipher/aegis/core/m/h;->f:Lcom/vdocipher/aegis/core/m/h;

    .line 103
    invoke-virtual {v5, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v22

    const/4 v12, 0x0

    move-object/from16 v13, p3

    move-object/from16 v16, v0

    move/from16 v19, v3

    move-object/from16 v20, v4

    invoke-direct/range {v6 .. v22}, Lcom/vdocipher/aegis/core/m/y$a;-><init>(Lcom/vdocipher/aegis/player/VdoInitParams;Ljava/lang/String;ILjava/lang/String;[Lcom/vdocipher/aegis/media/Track;Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;Ljava/lang/String;Landroidx/media3/exoplayer/offline/Download;Lcom/vdocipher/aegis/core/m/f;FZZLjava/lang/String;Ljava/lang/String;Z)V

    .line 106
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/e;->e:Lcom/vdocipher/aegis/core/m/e$b;

    iget-object v3, v1, Lcom/vdocipher/aegis/core/m/e;->i:Ljava/lang/Object;

    iget-object v4, v1, Lcom/vdocipher/aegis/core/m/e;->k:Lcom/vdocipher/aegis/core/d/k;

    invoke-interface {v0, v3, v6, v2, v4}, Lcom/vdocipher/aegis/core/m/e$b;->a(Ljava/lang/Object;Lcom/vdocipher/aegis/core/m/y$a;Lcom/vdocipher/aegis/core/m/h;Lcom/vdocipher/aegis/core/d/k;)V

    return-void
.end method

.method public f()V
    .registers 3

    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/m/e;->j:Z

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->a:Landroid/content/Context;

    invoke-static {v0}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/e;->u:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v1}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->f:Lcom/vdocipher/aegis/core/f/f;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/f;->c()V

    .line 5
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e;->t:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    return-void
.end method

.method public onMetaNotReceived(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;Ljava/lang/String;)V
    .registers 7

    .line 1
    new-instance p1, Ljava/lang/StringBuilder;

    const-string p6, "not received "

    invoke-direct {p1, p6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    if-eqz p4, :cond_e

    invoke-virtual {p4}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p6

    goto :goto_10

    :cond_e
    const-string p6, ""

    :goto_10
    invoke-virtual {p1, p6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p6, "LoadSpecPreparer"

    invoke-static {p6, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 2
    iget-boolean p1, p0, Lcom/vdocipher/aegis/core/m/e;->j:Z

    if-nez p1, :cond_23

    invoke-direct {p0, p2, p3, p4, p5}, Lcom/vdocipher/aegis/core/m/e;->a(ILjava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    :cond_23
    return-void
.end method

.method public onMetaReceived(Ljava/lang/Object;ILjava/lang/String;JLjava/lang/String;Ljava/lang/String;)V
    .registers 8

    .line 1
    const-string p1, "LoadSpecPreparer"

    const-string p2, "received"

    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 2
    iput-object p3, p0, Lcom/vdocipher/aegis/core/m/e;->m:Ljava/lang/String;

    .line 3
    iput-object p6, p0, Lcom/vdocipher/aegis/core/m/e;->l:Ljava/lang/String;

    .line 6
    const-string p1, "/api/meta/o/"

    invoke-virtual {p6, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_4f

    .line 9
    :try_start_13
    new-instance p1, Lcom/vdocipher/aegis/core/f/g;

    invoke-direct {p1, p3}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    .line 10
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->n()Ljava/lang/String;

    move-result-object p2

    if-eqz p2, :cond_29

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->n()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_29

    goto :goto_4f

    .line 12
    :cond_29
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->l()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_4f

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->k()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1
    :try_end_3b
    .catch Lcom/vdocipher/aegis/core/f/d; {:try_start_13 .. :try_end_3b} :catch_3e

    if-nez p1, :cond_3e

    goto :goto_4f

    .line 19
    :catch_3e
    :cond_3e
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->k:Lcom/vdocipher/aegis/core/d/k;

    invoke-static {p1, p3}, Lcom/vdocipher/aegis/core/m/c;->d(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    .line 20
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->p:Ljava/lang/String;

    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->b:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object p2, p2, Lcom/vdocipher/aegis/player/VdoInitParams;->customPlayerId:Ljava/lang/String;

    const-string p3, "/api/meta/"

    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/m/e;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 26
    :cond_4f
    :goto_4f
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e;->k:Lcom/vdocipher/aegis/core/d/k;

    invoke-static {p1, p4, p5}, Lcom/vdocipher/aegis/core/m/c;->b(Lcom/vdocipher/aegis/core/d/k;J)V

    .line 28
    iget-boolean p1, p0, Lcom/vdocipher/aegis/core/m/e;->j:Z

    if-nez p1, :cond_5c

    const/4 p1, 0x0

    .line 29
    invoke-direct {p0, p3, p1}, Lcom/vdocipher/aegis/core/m/e;->c(Ljava/lang/String;Ljava/lang/String;)V

    :cond_5c
    return-void
.end method

.method public onMetaUrlFailed(Ljava/lang/Object;ILjava/lang/String;ZLjava/lang/String;)V
    .registers 7

    .line 1
    :try_start_0
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    .line 2
    const-string v0, "metaUrl"

    invoke-virtual {p1, v0, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 3
    const-string/jumbo p3, "statusCode"

    invoke-virtual {p1, p3, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 4
    const-string p2, "isCronetEnabled"

    invoke-virtual {p1, p2, p4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 5
    const-string/jumbo p2, "stackTrace"

    invoke-virtual {p1, p2, p5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 6
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e;->k:Lcom/vdocipher/aegis/core/d/k;

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/d/k;Lorg/json/JSONObject;)V
    :try_end_20
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_20} :catch_20

    :catch_20
    return-void
.end method
