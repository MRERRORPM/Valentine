# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/m/e;

.field public final synthetic f$1:Lcom/vdocipher/aegis/core/m/h;

.field public final synthetic f$2:Ljava/lang/String;

.field public final synthetic f$3:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/m/e;Lcom/vdocipher/aegis/core/m/h;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda6;->f$0:Lcom/vdocipher/aegis/core/m/e;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda6;->f$1:Lcom/vdocipher/aegis/core/m/h;

    iput-object p3, p0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda6;->f$2:Ljava/lang/String;

    iput-object p4, p0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda6;->f$3:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda6;->f$0:Lcom/vdocipher/aegis/core/m/e;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda6;->f$1:Lcom/vdocipher/aegis/core/m/h;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda6;->f$2:Ljava/lang/String;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda6;->f$3:Ljava/lang/String;

    invoke-static {v0, v1, v2, v3}, Lcom/vdocipher/aegis/core/m/e;->$r8$lambda$kL8fQRcgt2tLj9iXcZphP12xqWY(Lcom/vdocipher/aegis/core/m/e;Lcom/vdocipher/aegis/core/m/h;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
