# classes14.dex

.class Lcom/vdocipher/aegis/core/m/q$b;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/m/q;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/m/q;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method

.method private a(Ljava/lang/Exception;)I
    .registers 3

    .line 1
    instance-of v0, p1, Landroidx/media3/exoplayer/drm/UnsupportedDrmException;

    if-eqz v0, :cond_11

    .line 2
    check-cast p1, Landroidx/media3/exoplayer/drm/UnsupportedDrmException;

    iget p1, p1, Landroidx/media3/exoplayer/drm/UnsupportedDrmException;->reason:I

    const/4 v0, 0x1

    if-ne p1, v0, :cond_e

    const/16 p1, 0x4e3

    return p1

    :cond_e
    const/16 p1, 0x1807

    return p1

    :cond_11
    const/16 p1, 0x17d5

    return p1
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 9

    const-string v0, "VdoExo"

    if-eqz p2, :cond_121

    .line 1
    const-string/jumbo v1, "vdo_playback_exception"

    invoke-virtual {p2, v1}, Landroid/content/Intent;->getSerializableExtra(Ljava/lang/String;)Ljava/io/Serializable;

    move-result-object v1

    check-cast v1, Landroidx/media3/exoplayer/ExoPlaybackException;

    .line 2
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-virtual {v2, v1}, Lcom/vdocipher/aegis/core/m/q;->a(Landroidx/media3/common/PlaybackException;)Lcom/vdocipher/aegis/core/m/p;

    move-result-object v1

    .line 5
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/m/q;->j(Lcom/vdocipher/aegis/core/m/q;)Z

    move-result v2

    if-eqz v2, :cond_23

    iget v2, v1, Lcom/vdocipher/aegis/core/m/p;->a:I

    const/16 v3, 0x17e9

    if-ne v2, v3, :cond_23

    goto/16 :goto_121

    .line 9
    :cond_23
    iget v2, v1, Lcom/vdocipher/aegis/core/m/p;->a:I

    const/16 v3, 0x7f4

    if-eq v2, v3, :cond_f2

    const/16 v3, 0x7f7

    if-ne v2, v3, :cond_2f

    goto/16 :goto_f2

    .line 21
    :cond_2f
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 23
    :try_start_34
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object p2, p2, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {p2}, Lcom/vdocipher/aegis/core/f/g;->g()Ljava/util/ArrayList;

    move-result-object p1
    :try_end_3c
    .catch Ljava/lang/Exception; {:try_start_34 .. :try_end_3c} :catch_3d

    goto :goto_45

    :catch_3d
    move-exception p2

    .line 25
    invoke-static {p2}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p2

    invoke-static {v0, p2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 28
    :goto_45
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {p2}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/core/m/q;)J

    move-result-wide v2

    const-wide/16 v4, 0x0

    cmp-long p2, v2, v4

    if-nez p2, :cond_a7

    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {p2}, Lcom/vdocipher/aegis/core/m/q;->i(Lcom/vdocipher/aegis/core/m/q;)Z

    move-result p2

    if-nez p2, :cond_a7

    iget p2, v1, Lcom/vdocipher/aegis/core/m/p;->a:I

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_a7

    .line 31
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v2, p2, Lcom/vdocipher/aegis/core/m/q;->p:Lcom/vdocipher/aegis/core/z/d$b;

    sget-object v3, Lcom/vdocipher/aegis/core/z/d$b;->a:Lcom/vdocipher/aegis/core/z/d$b;

    if-ne v2, v3, :cond_a7

    .line 32
    invoke-static {p2, v1}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/core/m/q;Lcom/vdocipher/aegis/core/m/p;)V

    .line 34
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    sget-object p2, Lcom/vdocipher/aegis/core/z/d$b;->b:Lcom/vdocipher/aegis/core/z/d$b;

    iput-object p2, p1, Lcom/vdocipher/aegis/core/m/q;->p:Lcom/vdocipher/aegis/core/z/d$b;

    .line 37
    :try_start_76
    invoke-static {p1}, Lcom/vdocipher/aegis/core/m/q;->k(Lcom/vdocipher/aegis/core/m/q;)V
    :try_end_79
    .catch Ljava/lang/Exception; {:try_start_76 .. :try_end_79} :catch_7b

    goto/16 :goto_121

    :catch_7b
    move-exception p1

    .line 39
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p2

    .line 40
    invoke-static {v0, p2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 41
    new-instance v0, Lcom/vdocipher/aegis/core/m/d;

    const/4 v1, -0x1

    const/4 v2, 0x0

    const-string v3, "retryfail"

    invoke-direct {v0, v3, v1, v2, p2}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 42
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q$b;->a(Ljava/lang/Exception;)I

    move-result p1

    .line 43
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object p2, p2, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/m/p;

    .line 44
    invoke-static {p1}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, p1, v2, v0}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    const/4 p1, 0x1

    .line 45
    invoke-virtual {p2, p1, v1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    .line 47
    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    goto/16 :goto_121

    .line 54
    :cond_a7
    new-instance p2, Ljava/util/ArrayList;

    sget-object v0, Lcom/vdocipher/aegis/media/ErrorCodes;->RETRYABLE_ERROR_CODES:[Ljava/lang/Integer;

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-direct {p2, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 55
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/core/m/q;)J

    move-result-wide v2

    cmp-long v0, v2, v4

    if-nez v0, :cond_bf

    .line 56
    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->removeAll(Ljava/util/Collection;)Z

    .line 58
    :cond_bf
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/m/q;->l(Lcom/vdocipher/aegis/core/m/q;)Z

    move-result p1

    if-eqz p1, :cond_e4

    iget p1, v1, Lcom/vdocipher/aegis/core/m/p;->a:I

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_e4

    .line 59
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    const/4 p2, 0x0

    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/m/q;->d(Lcom/vdocipher/aegis/core/m/q;Z)Z

    .line 60
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {p1, v1}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/core/m/q;Lcom/vdocipher/aegis/core/m/p;)V

    .line 61
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/m/q;->retry()V

    goto :goto_121

    .line 63
    :cond_e4
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    const/16 p2, 0x6c

    invoke-virtual {p1, p2, v1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    goto :goto_121

    .line 64
    :cond_f2
    :goto_f2
    new-instance v0, Landroid/content/Intent;

    const-string/jumbo v2, "vdo-action-retry-playback"

    invoke-direct {v0, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 65
    sget-object v2, Lcom/vdocipher/aegis/core/z/d;->a:Lcom/vdocipher/aegis/core/z/d;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/q$b;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v3, v3, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v3, v3, Lcom/vdocipher/aegis/core/m/y$a;->b:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lcom/vdocipher/aegis/core/z/d;->e(Ljava/lang/String;)Z

    move-result v2

    const-string v3, "retry-meta-end-point"

    if-eqz v2, :cond_110

    .line 66
    const-string v2, "/api/meta/"

    invoke-virtual {p2, v3, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    goto :goto_115

    .line 68
    :cond_110
    const-string v2, "/api/meta/o/"

    invoke-virtual {p2, v3, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 70
    :goto_115
    const-string p2, "error"

    invoke-virtual {v0, p2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 71
    invoke-static {p1}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z

    :cond_121
    :goto_121
    return-void
.end method
