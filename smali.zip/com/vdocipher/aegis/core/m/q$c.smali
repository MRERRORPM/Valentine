# classes14.dex

.class Lcom/vdocipher/aegis/core/m/q$c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private a:J

.field private b:J

.field final synthetic c:Lcom/vdocipher/aegis/core/m/q;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/m/q;)V
    .registers 4

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q$c;->c:Lcom/vdocipher/aegis/core/m/q;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-wide/16 v0, 0x0

    .line 2
    iput-wide v0, p0, Lcom/vdocipher/aegis/core/m/q$c;->a:J

    .line 3
    iput-wide v0, p0, Lcom/vdocipher/aegis/core/m/q$c;->b:J

    return-void
.end method


# virtual methods
.method public run()V
    .registers 7

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$c;->c:Lcom/vdocipher/aegis/core/m/q;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/q;->getCurrentTime()J

    move-result-wide v0

    .line 2
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q$c;->c:Lcom/vdocipher/aegis/core/m/q;

    invoke-virtual {v2}, Lcom/vdocipher/aegis/core/m/q;->getBufferedTime()J

    move-result-wide v2

    .line 3
    iget-wide v4, p0, Lcom/vdocipher/aegis/core/m/q$c;->a:J

    cmp-long v4, v0, v4

    if-eqz v4, :cond_2c

    .line 4
    iget-object v4, p0, Lcom/vdocipher/aegis/core/m/q$c;->c:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v4}, Lcom/vdocipher/aegis/core/m/q;->m(Lcom/vdocipher/aegis/core/m/q;)Ljava/util/concurrent/CopyOnWriteArraySet;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1c
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_2c

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 5
    invoke-interface {v5, v0, v1}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onProgress(J)V

    goto :goto_1c

    .line 8
    :cond_2c
    iget-wide v4, p0, Lcom/vdocipher/aegis/core/m/q$c;->b:J

    cmp-long v4, v2, v4

    if-eqz v4, :cond_4c

    .line 9
    iget-object v4, p0, Lcom/vdocipher/aegis/core/m/q$c;->c:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v4}, Lcom/vdocipher/aegis/core/m/q;->m(Lcom/vdocipher/aegis/core/m/q;)Ljava/util/concurrent/CopyOnWriteArraySet;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_3c
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_4c

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 10
    invoke-interface {v5, v2, v3}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onBufferUpdate(J)V

    goto :goto_3c

    .line 13
    :cond_4c
    iput-wide v0, p0, Lcom/vdocipher/aegis/core/m/q$c;->a:J

    .line 14
    iput-wide v2, p0, Lcom/vdocipher/aegis/core/m/q$c;->b:J

    .line 15
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$c;->c:Lcom/vdocipher/aegis/core/m/q;

    iget-object v1, v0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/q;->n(Lcom/vdocipher/aegis/core/m/q;)Ljava/lang/Runnable;

    move-result-object v0

    const-wide/16 v2, 0x1f4

    invoke-virtual {v1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
