# classes14.dex

.class Lcom/vdocipher/aegis/core/m/a0$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/a0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/m/a0;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/m/a0;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/a0$a;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    const-wide/16 v0, 0x3a98

    .line 1
    :try_start_2
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/a0$a;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/m/a0;->a(Lcom/vdocipher/aegis/core/m/a0;)Lcom/vdocipher/aegis/core/d/k;

    move-result-object v2

    if-eqz v2, :cond_19

    .line 2
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/a0$a;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/m/a0;->a(Lcom/vdocipher/aegis/core/m/a0;)Lcom/vdocipher/aegis/core/d/k;

    move-result-object v2

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/a0$a;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/a0;->b(Lcom/vdocipher/aegis/core/m/a0;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;)V
    :try_end_19
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_19} :catch_27
    .catchall {:try_start_2 .. :try_end_19} :catchall_25

    .line 7
    :cond_19
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/a0$a;->a:Lcom/vdocipher/aegis/core/m/a0;

    iget-object v3, v2, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/m/a0;->i(Lcom/vdocipher/aegis/core/m/a0;)Ljava/lang/Runnable;

    move-result-object v2

    invoke-virtual {v3, v2, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :catchall_25
    move-exception v2

    goto :goto_3d

    :catch_27
    move-exception v2

    .line 8
    :try_start_28
    const-string v3, "VdoServiceSM"

    invoke-static {v2}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_31
    .catchall {:try_start_28 .. :try_end_31} :catchall_25

    .line 10
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/a0$a;->a:Lcom/vdocipher/aegis/core/m/a0;

    iget-object v3, v2, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/m/a0;->i(Lcom/vdocipher/aegis/core/m/a0;)Ljava/lang/Runnable;

    move-result-object v2

    invoke-virtual {v3, v2, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :goto_3d
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/a0$a;->a:Lcom/vdocipher/aegis/core/m/a0;

    iget-object v4, v3, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/a0;->i(Lcom/vdocipher/aegis/core/m/a0;)Ljava/lang/Runnable;

    move-result-object v3

    invoke-virtual {v4, v3, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 11
    throw v2
.end method
