# classes14.dex

.class public final Lcom/vdocipher/aegis/core/m/n;
.super Lcom/vdocipher/aegis/core/m/q;
.source "SourceFile"


# static fields
.field private static final U:Ljava/net/CookieManager;


# instance fields
.field private Q:Ljava/lang/String;

.field private R:Ljava/lang/String;

.field private S:Landroidx/media3/exoplayer/offline/DownloadRequest;

.field private T:[B


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Ljava/net/CookieManager;

    invoke-direct {v0}, Ljava/net/CookieManager;-><init>()V

    sput-object v0, Lcom/vdocipher/aegis/core/m/n;->U:Ljava/net/CookieManager;

    .line 2
    sget-object v1, Ljava/net/CookiePolicy;->ACCEPT_ORIGINAL_SERVER:Ljava/net/CookiePolicy;

    invoke-virtual {v0, v1}, Ljava/net/CookieManager;->setCookiePolicy(Ljava/net/CookiePolicy;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/media3/common/Player;Landroid/view/SurfaceView;Lcom/vdocipher/aegis/core/d/k;)V
    .registers 5

    .line 1
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/vdocipher/aegis/core/m/q;-><init>(Landroid/content/Context;Landroidx/media3/common/Player;Landroid/view/SurfaceView;Lcom/vdocipher/aegis/core/d/k;)V

    return-void
.end method

.method private static a(Landroid/media/MediaCodec$CryptoException;)I
    .registers 2

    .line 356
    invoke-virtual {p0}, Landroid/media/MediaCodec$CryptoException;->getErrorCode()I

    move-result p0

    const/4 v0, 0x1

    if-eq p0, v0, :cond_22

    const/4 v0, 0x2

    if-eq p0, v0, :cond_1f

    const/4 v0, 0x3

    if-eq p0, v0, :cond_1c

    const/4 v0, 0x4

    if-eq p0, v0, :cond_19

    const/4 v0, 0x5

    if-eq p0, v0, :cond_16

    const/16 p0, 0x1834

    return p0

    :cond_16
    const/16 p0, 0x1832

    return p0

    :cond_19
    const/16 p0, 0x1831

    return p0

    :cond_1c
    const/16 p0, 0x1830

    return p0

    :cond_1f
    const/16 p0, 0x182f

    return p0

    :cond_22
    const/16 p0, 0x182e

    return p0
.end method

.method private a(Ljava/lang/Exception;)I
    .registers 4

    .line 164
    instance-of v0, p1, Landroidx/media3/datasource/FileDataSource$FileDataSourceException;

    const/16 v1, 0x1429

    if-eqz v0, :cond_12

    :goto_6
    if-eqz p1, :cond_1f

    .line 167
    instance-of v0, p1, Ljava/io/FileNotFoundException;

    if-eqz v0, :cond_d

    return v1

    .line 170
    :cond_d
    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    goto :goto_6

    .line 172
    :cond_12
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const-string v0, "PlaceholderDataSource cannot be opened"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1f

    return v1

    :cond_1f
    const/16 p1, 0x1428

    return p1
.end method

.method private static a(Landroidx/media3/exoplayer/drm/DrmSession$DrmSessionException;)Landroid/util/Pair;
    .registers 11

    .line 269
    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/16 v0, 0x4e2

    if-nez p0, :cond_d

    .line 271
    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 272
    :cond_d
    instance-of v1, p0, Landroid/media/NotProvisionedException;

    if-eqz v1, :cond_18

    const/16 p0, 0x4e5

    .line 273
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 274
    :cond_18
    instance-of v1, p0, Landroid/media/ResourceBusyException;

    if-eqz v1, :cond_23

    const/16 p0, 0x1811

    .line 275
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 276
    :cond_23
    instance-of v1, p0, Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;

    if-eqz v1, :cond_104

    .line 277
    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    .line 278
    instance-of v1, p0, Landroidx/media3/exoplayer/drm/KeysExpiredException;

    if-eqz v1, :cond_36

    const/16 p0, 0x182b

    .line 279
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 280
    :cond_36
    instance-of v1, p0, Lcom/vdocipher/aegis/core/m/u$c;

    if-eqz v1, :cond_ff

    .line 281
    move-object v0, p0

    check-cast v0, Lcom/vdocipher/aegis/core/m/u$c;

    iget-object v1, v0, Lcom/vdocipher/aegis/core/m/u$c;->a:Lcom/vdocipher/aegis/core/m/u$a;

    .line 282
    sget-object v2, Lcom/vdocipher/aegis/core/m/u$a;->b:Lcom/vdocipher/aegis/core/m/u$a;

    if-ne v1, v2, :cond_45

    const/4 v1, 0x1

    goto :goto_46

    :cond_45
    const/4 v1, 0x0

    .line 283
    :goto_46
    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    .line 284
    instance-of v2, p0, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    const/16 v3, 0x1420

    const/16 v4, 0x1823

    const/16 v5, 0x7d5

    const/16 v6, 0x1822

    const/16 v7, 0x258

    const/16 v8, 0x190

    const/16 v9, 0x1f4

    if-eqz v2, :cond_90

    .line 285
    check-cast p0, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    iget p0, p0, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;->responseCode:I

    if-lt p0, v8, :cond_70

    if-ge p0, v9, :cond_70

    if-eqz v1, :cond_6b

    .line 287
    invoke-static {v5}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 288
    :cond_6b
    invoke-static {v6}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    :cond_70
    if-lt p0, v9, :cond_80

    if-ge p0, v7, :cond_80

    if-eqz v1, :cond_7b

    .line 290
    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 291
    :cond_7b
    invoke-static {v4}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    :cond_80
    if-eqz v1, :cond_89

    const/16 p0, 0x1421

    .line 293
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    :cond_89
    const/16 p0, 0x1835

    .line 294
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 296
    :cond_90
    instance-of v2, p0, Ljavax/net/ssl/SSLHandshakeException;

    if-eqz v2, :cond_aa

    .line 297
    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    .line 298
    instance-of p0, p0, Ljava/security/cert/CertificateException;

    if-eqz p0, :cond_a3

    const/16 p0, 0x1422

    .line 299
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    :cond_a3
    const/16 p0, 0x1424

    .line 301
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 303
    :cond_aa
    instance-of p0, p0, Ljava/io/IOException;

    if-eqz p0, :cond_be

    if-eqz v1, :cond_b7

    const/16 p0, 0x141f

    .line 304
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    :cond_b7
    const/16 p0, 0x1836

    .line 305
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 310
    :cond_be
    iget p0, v0, Lcom/vdocipher/aegis/core/m/u$c;->b:I

    if-lez p0, :cond_cd

    .line 311
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/u$c;->c:Ljava/lang/String;

    invoke-static {p0, v0}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 312
    :cond_cd
    iget p0, v0, Lcom/vdocipher/aegis/core/m/u$c;->d:I

    if-lt p0, v8, :cond_df

    if-ge p0, v9, :cond_df

    if-eqz v1, :cond_da

    .line 313
    invoke-static {v5}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 314
    :cond_da
    invoke-static {v6}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    :cond_df
    if-lt p0, v9, :cond_ef

    if-ge p0, v7, :cond_ef

    if-eqz v1, :cond_ea

    .line 316
    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 317
    :cond_ea
    invoke-static {v4}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    :cond_ef
    if-eqz v1, :cond_f8

    const/16 p0, 0x141e

    .line 319
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    :cond_f8
    const/16 p0, 0x1821

    .line 320
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 323
    :cond_ff
    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 325
    :cond_104
    instance-of v1, p0, Landroid/media/MediaCryptoException;

    if-eqz v1, :cond_10f

    const/16 p0, 0x1813

    .line 326
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 327
    :cond_10f
    instance-of v1, p0, Landroid/media/DeniedByServerException;

    if-eqz v1, :cond_11a

    const/16 p0, 0x1814

    .line 328
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 329
    :cond_11a
    instance-of v1, p0, Landroid/media/MediaDrm$MediaDrmStateException;

    if-eqz v1, :cond_17e

    .line 330
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_133

    .line 331
    const-string v0, "Failed to get provision request"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_133

    const/16 p0, 0x1820

    .line 332
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    :cond_133
    if-eqz p0, :cond_144

    .line 333
    const-string v0, "Failed to handle provision response"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_144

    const/16 p0, 0x1825

    .line 334
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    :cond_144
    if-eqz p0, :cond_155

    .line 335
    const-string v0, "Failed to get key request"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_155

    const/16 p0, 0x1816

    .line 336
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    :cond_155
    if-eqz p0, :cond_166

    .line 337
    const-string v0, "Failed to handle key response"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_166

    const/16 p0, 0x181c

    .line 338
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    :cond_166
    if-eqz p0, :cond_177

    .line 339
    const-string v0, "Failed to restore keys"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_177

    const/16 p0, 0x182a

    .line 340
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    :cond_177
    const/16 p0, 0x180c

    .line 342
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 344
    :cond_17e
    instance-of v1, p0, Landroid/media/MediaDrmResetException;

    if-eqz v1, :cond_189

    const/16 p0, 0x180d

    .line 345
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 346
    :cond_189
    instance-of v1, p0, Ljava/lang/IllegalStateException;

    if-eqz v1, :cond_1a7

    .line 347
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_1a0

    .line 349
    const-string v1, "Media does not support uuid"

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_1a0

    .line 350
    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    :cond_1a0
    const/16 p0, 0x180b

    .line 352
    invoke-static {p0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    .line 355
    :cond_1a7
    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/n;->b(I)Landroid/util/Pair;

    move-result-object p0

    return-object p0
.end method

.method private a(Ljava/lang/String;Lcom/vdocipher/aegis/core/z/d$b;)Landroidx/media3/common/MediaItem$DrmConfiguration;
    .registers 5

    .line 173
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result v0

    if-eqz v0, :cond_1d

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->e()Z

    move-result v0

    if-nez v0, :cond_1d

    .line 174
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/n;->T:[B

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/n;->R:Ljava/lang/String;

    invoke-direct {p0, p1, v0, p2}, Lcom/vdocipher/aegis/core/m/n;->a([BLjava/lang/String;Lcom/vdocipher/aegis/core/z/d$b;)Landroidx/media3/common/MediaItem$DrmConfiguration;

    move-result-object p1

    return-object p1

    .line 176
    :cond_1d
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/n;->R:Ljava/lang/String;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    invoke-direct {p0, p1, v0, v1, p2}, Lcom/vdocipher/aegis/core/m/n;->a(Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/m/y$a;Lcom/vdocipher/aegis/core/z/d$b;)Landroidx/media3/common/MediaItem$DrmConfiguration;

    move-result-object p1

    return-object p1
.end method

.method private a(Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/m/y$a;Lcom/vdocipher/aegis/core/z/d$b;)Landroidx/media3/common/MediaItem$DrmConfiguration;
    .registers 11

    .line 177
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/t/d;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 181
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/n;->n()Ljava/lang/String;

    move-result-object v1

    .line 183
    sget-object v2, Lcom/vdocipher/aegis/core/z/d$b;->b:Lcom/vdocipher/aegis/core/z/d$b;

    if-eq p4, v2, :cond_1b

    iget-object p4, p3, Lcom/vdocipher/aegis/core/m/y$a;->b:Ljava/lang/String;

    if-eqz p4, :cond_19

    invoke-static {p4}, Lcom/vdocipher/aegis/core/t/d;->h(Ljava/lang/String;)Z

    move-result p4

    if-eqz p4, :cond_19

    goto :goto_1b

    :cond_19
    const/4 p4, 0x0

    goto :goto_1c

    :cond_1b
    :goto_1b
    const/4 p4, 0x1

    :goto_1c
    if-eqz p3, :cond_2f

    .line 189
    :try_start_1e
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v2}, Lcom/vdocipher/aegis/core/f/g;->h()Ljava/lang/String;

    move-result-object v2
    :try_end_24
    .catch Ljava/lang/Exception; {:try_start_1e .. :try_end_24} :catch_25

    goto :goto_30

    :catch_25
    move-exception v2

    .line 192
    invoke-static {v2}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "VdoDash"

    invoke-static {v3, v2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2f
    const/4 v2, 0x0

    .line 195
    :goto_30
    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    if-eqz v0, :cond_3c

    .line 197
    const-string v4, "packageName"

    invoke-interface {v3, v4, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 198
    :cond_3c
    const-string/jumbo v0, "wrapped"

    invoke-interface {v3, v0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 199
    iget-object v0, p3, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v0, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->otp:Ljava/lang/String;

    if-eqz v0, :cond_4d

    .line 200
    const-string v4, "otp"

    invoke-interface {v3, v4, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 201
    :cond_4d
    iget-object v0, p3, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v0, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    if-eqz v0, :cond_58

    .line 202
    const-string v4, "playbackInfo"

    invoke-interface {v3, v4, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 203
    :cond_58
    iget-object v0, p3, Lcom/vdocipher/aegis/core/m/y$a;->n:Ljava/lang/String;

    if-eqz v0, :cond_61

    .line 204
    const-string v4, "playerViewId"

    invoke-interface {v3, v4, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 205
    :cond_61
    iget-object v0, p3, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v0, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    if-eqz v0, :cond_6d

    .line 206
    const-string/jumbo v4, "videoId"

    invoke-interface {v3, v4, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 207
    :cond_6d
    iget-object v0, p3, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v0, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->languageCode:Ljava/lang/String;

    if-eqz v0, :cond_78

    .line 208
    const-string v4, "languageCode"

    invoke-interface {v3, v4, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 210
    :cond_78
    const-string/jumbo v0, "true"

    const-string v4, "false"

    if-eqz p4, :cond_81

    move-object p4, v0

    goto :goto_82

    :cond_81
    move-object p4, v4

    :goto_82
    const-string v5, "l3EnforcementValue"

    invoke-interface {v3, v5, p4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 212
    iget-object p3, p3, Lcom/vdocipher/aegis/core/m/y$a;->o:Ljava/lang/String;

    if-eqz p3, :cond_90

    .line 213
    const-string p4, "integrityCloudId"

    invoke-interface {v3, p4, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 215
    :cond_90
    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    if-eqz p3, :cond_a1

    .line 216
    invoke-virtual {p3}, Lcom/vdocipher/aegis/core/f/g;->f()Z

    move-result p3

    if-eqz p3, :cond_9b

    goto :goto_9c

    :cond_9b
    move-object v0, v4

    :goto_9c
    const-string p3, "enforceHardwareAttestation"

    invoke-interface {v3, p3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_a1
    if-eqz v1, :cond_a8

    .line 219
    const-string p3, "href"

    invoke-interface {v3, p3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_a8
    if-eqz p1, :cond_b0

    .line 221
    const-string/jumbo p3, "userAgent"

    invoke-interface {v3, p3, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_b0
    if-eqz v2, :cond_b7

    .line 223
    const-string p1, "fallbackLicenseServerArray"

    invoke-interface {v3, p1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 224
    :cond_b7
    sget-object p1, Landroidx/media3/common/C;->WIDEVINE_UUID:Ljava/util/UUID;

    .line 226
    new-instance p3, Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;

    invoke-direct {p3, p1}, Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;-><init>(Ljava/util/UUID;)V

    .line 228
    invoke-virtual {p3, p2}, Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;->setLicenseUri(Ljava/lang/String;)Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;

    move-result-object p1

    .line 229
    invoke-virtual {p1, v3}, Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;->setLicenseRequestHeaders(Ljava/util/Map;)Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;

    move-result-object p1

    .line 230
    invoke-virtual {p1}, Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;->build()Landroidx/media3/common/MediaItem$DrmConfiguration;

    move-result-object p1

    return-object p1
.end method

.method private a([BLjava/lang/String;Lcom/vdocipher/aegis/core/z/d$b;)Landroidx/media3/common/MediaItem$DrmConfiguration;
    .registers 10

    .line 231
    sget-object v0, Landroidx/media3/common/C;->WIDEVINE_UUID:Ljava/util/UUID;

    .line 233
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/t/d;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    .line 236
    sget-object v2, Lcom/vdocipher/aegis/core/z/d$b;->b:Lcom/vdocipher/aegis/core/z/d$b;

    if-eq p3, v2, :cond_1b

    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object p3, p3, Lcom/vdocipher/aegis/core/m/y$a;->b:Ljava/lang/String;

    if-eqz p3, :cond_19

    invoke-static {p3}, Lcom/vdocipher/aegis/core/t/d;->h(Ljava/lang/String;)Z

    move-result p3

    if-eqz p3, :cond_19

    goto :goto_1b

    :cond_19
    const/4 p3, 0x0

    goto :goto_1c

    :cond_1b
    :goto_1b
    const/4 p3, 0x1

    .line 238
    :goto_1c
    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    if-eqz v1, :cond_28

    .line 240
    const-string v3, "packageName"

    invoke-interface {v2, v3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 241
    :cond_28
    const-string v1, "failOnKeyRequestWithExpiry"

    invoke-interface {v2, v1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 242
    const-string/jumbo v1, "wrapped"

    invoke-interface {v2, v1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 243
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v1, v1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v1, v1, Lcom/vdocipher/aegis/player/VdoInitParams;->otp:Ljava/lang/String;

    if-eqz v1, :cond_40

    .line 244
    const-string v3, "otp"

    invoke-interface {v2, v3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 245
    :cond_40
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v1, v1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v1, v1, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    if-eqz v1, :cond_4d

    .line 246
    const-string v3, "playbackInfo"

    invoke-interface {v2, v3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 247
    :cond_4d
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v1, v1, Lcom/vdocipher/aegis/core/m/y$a;->n:Ljava/lang/String;

    if-eqz v1, :cond_58

    .line 248
    const-string v3, "playerViewId"

    invoke-interface {v2, v3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 249
    :cond_58
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v1, v1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v1, v1, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    if-eqz v1, :cond_66

    .line 250
    const-string/jumbo v3, "videoId"

    invoke-interface {v2, v3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 251
    :cond_66
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v1, v1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v1, v1, Lcom/vdocipher/aegis/player/VdoInitParams;->languageCode:Ljava/lang/String;

    if-eqz v1, :cond_73

    .line 252
    const-string v3, "languageCode"

    invoke-interface {v2, v3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 253
    :cond_73
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    const-string/jumbo v3, "true"

    const-string v4, "false"

    if-eqz v1, :cond_8a

    .line 254
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/f/g;->f()Z

    move-result v1

    if-eqz v1, :cond_84

    move-object v1, v3

    goto :goto_85

    :cond_84
    move-object v1, v4

    :goto_85
    const-string v5, "enforceHardwareAttestation"

    invoke-interface {v2, v5, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_8a
    if-eqz p3, :cond_8d

    goto :goto_8e

    :cond_8d
    move-object v3, v4

    .line 257
    :goto_8e
    const-string p3, "l3EnforcementValue"

    invoke-interface {v2, p3, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 258
    const-string/jumbo p3, "userAgent"

    const-string v1, "VdoDash"

    invoke-interface {v2, p3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 259
    const-string p3, "offlinePlayback"

    invoke-interface {v2, p3, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 261
    new-instance p3, Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;

    invoke-direct {p3, v0}, Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;-><init>(Ljava/util/UUID;)V

    .line 262
    invoke-virtual {p3, p2}, Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;->setLicenseUri(Ljava/lang/String;)Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;

    move-result-object p2

    .line 263
    invoke-virtual {p2, v2}, Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;->setLicenseRequestHeaders(Ljava/util/Map;)Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;

    move-result-object p2

    .line 264
    invoke-virtual {p2, p1}, Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;->setKeySetId([B)Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;

    move-result-object p1

    .line 265
    invoke-virtual {p1}, Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;->build()Landroidx/media3/common/MediaItem$DrmConfiguration;

    move-result-object p1

    return-object p1
.end method

.method private a(Lcom/vdocipher/aegis/core/f/g;)V
    .registers 4

    .line 266
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->r()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->G:Ljava/lang/String;

    .line 267
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->c()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->H:Ljava/lang/String;

    .line 268
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->e()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/vdocipher/aegis/core/m/q;->I:J

    return-void
.end method

.method private static b(I)Landroid/util/Pair;
    .registers 2

    .line 97
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {p0}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object p0

    return-object p0
.end method

.method private static d(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    .line 1
    const-string v0, "/wv"

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    if-gez v0, :cond_9

    return-object p0

    :cond_9
    const/4 v1, 0x0

    .line 3
    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private n()Ljava/lang/String;
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    const-string v1, "VdoZenPlayerSharedPreference"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 2
    const-string v1, "href"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private o()V
    .registers 2

    .line 1
    invoke-static {}, Ljava/net/CookieHandler;->getDefault()Ljava/net/CookieHandler;

    move-result-object v0

    if-nez v0, :cond_b

    .line 2
    sget-object v0, Lcom/vdocipher/aegis/core/m/n;->U:Ljava/net/CookieManager;

    invoke-static {v0}, Ljava/net/CookieHandler;->setDefault(Ljava/net/CookieHandler;)V

    :cond_b
    return-void
.end method


# virtual methods
.method protected a(Landroid/os/Handler;Ljava/lang/String;Lcom/vdocipher/aegis/core/z/d$b;)Landroidx/media3/common/MediaItem;
    .registers 11

    .line 2
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result p1

    if-eqz p1, :cond_16

    .line 3
    new-instance p1, Ljava/io/File;

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/n;->Q:Ljava/lang/String;

    invoke-direct {p1, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object p1

    goto :goto_1c

    .line 4
    :cond_16
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/n;->Q:Ljava/lang/String;

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    .line 6
    :goto_1c
    invoke-direct {p0, p2, p3}, Lcom/vdocipher/aegis/core/m/n;->a(Ljava/lang/String;Lcom/vdocipher/aegis/core/z/d$b;)Landroidx/media3/common/MediaItem$DrmConfiguration;

    move-result-object p2

    .line 9
    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object p3, p3, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {p3}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result p3

    if-eqz p3, :cond_94

    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object p3, p3, Lcom/vdocipher/aegis/core/m/y$a;->k:Landroidx/media3/exoplayer/offline/Download;

    if-eqz p3, :cond_94

    .line 10
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/n;->S:Landroidx/media3/exoplayer/offline/DownloadRequest;

    invoke-virtual {p1}, Landroidx/media3/exoplayer/offline/DownloadRequest;->toMediaItem()Landroidx/media3/common/MediaItem;

    move-result-object p1

    .line 11
    invoke-virtual {p1}, Landroidx/media3/common/MediaItem;->buildUpon()Landroidx/media3/common/MediaItem$Builder;

    move-result-object p1

    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object p3, p3, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object p3, p3, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    .line 12
    invoke-virtual {p1, p3}, Landroidx/media3/common/MediaItem$Builder;->setMediaId(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p1

    .line 13
    invoke-virtual {p1, p2}, Landroidx/media3/common/MediaItem$Builder;->setDrmConfiguration(Landroidx/media3/common/MediaItem$DrmConfiguration;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p1

    .line 14
    invoke-virtual {p1}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    move-result-object p1

    .line 15
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/n;->S:Landroidx/media3/exoplayer/offline/DownloadRequest;

    invoke-static {p2}, Lcom/vdocipher/aegis/core/j/b;->a(Landroidx/media3/exoplayer/offline/DownloadRequest;)Ljava/util/List;

    move-result-object p2

    .line 18
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_56
    :goto_56
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_d1

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Landroid/util/Pair;

    .line 19
    iget-object v0, p3, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v0, Lcom/vdocipher/aegis/media/Caption;

    .line 21
    new-instance v1, Lcom/vdocipher/aegis/media/Caption;

    iget-object v2, p3, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/media/Caption;->getLang()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, Lcom/vdocipher/aegis/media/Caption;->getLabel()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0}, Lcom/vdocipher/aegis/media/Caption;->isDefault()Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v0}, Lcom/vdocipher/aegis/media/Caption;->getCaptionName()Ljava/lang/String;

    move-result-object v6

    invoke-direct/range {v1 .. v6}, Lcom/vdocipher/aegis/media/Caption;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)V

    .line 24
    new-instance v0, Ljava/io/File;

    iget-object p3, p3, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast p3, Ljava/lang/String;

    invoke-direct {v0, p3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 25
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result p3

    if-eqz p3, :cond_56

    .line 26
    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_56

    .line 33
    :cond_94
    :try_start_94
    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->F:Ljava/lang/String;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v1, v1, Lcom/vdocipher/aegis/core/m/y$a;->b:Ljava/lang/String;

    invoke-static {p3, v0, v1}, Lcom/vdocipher/aegis/core/t/b;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p3

    if-eqz p3, :cond_a4

    move-object p1, p3

    goto :goto_ae

    .line 38
    :cond_a4
    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {p3}, Lcom/vdocipher/aegis/core/f/g;->k()Ljava/lang/String;

    move-result-object p3

    invoke-static {p3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1
    :try_end_ae
    .catch Ljava/lang/Exception; {:try_start_94 .. :try_end_ae} :catch_ae

    .line 44
    :catch_ae
    :goto_ae
    new-instance p3, Landroidx/media3/common/MediaItem$Builder;

    invoke-direct {p3}, Landroidx/media3/common/MediaItem$Builder;-><init>()V

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    .line 45
    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->a()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p3, v0}, Landroidx/media3/common/MediaItem$Builder;->setMediaId(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p3

    .line 46
    invoke-virtual {p3, p1}, Landroidx/media3/common/MediaItem$Builder;->setUri(Landroid/net/Uri;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p1

    .line 47
    const-string p3, "application/dash+xml"

    invoke-virtual {p1, p3}, Landroidx/media3/common/MediaItem$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p1

    .line 48
    invoke-virtual {p1, p2}, Landroidx/media3/common/MediaItem$Builder;->setDrmConfiguration(Landroidx/media3/common/MediaItem$DrmConfiguration;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p1

    .line 49
    invoke-virtual {p1}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    move-result-object p1

    .line 52
    :cond_d1
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_da

    return-object p1

    .line 56
    :cond_da
    :try_start_da
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    .line 57
    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_e6
    if-ge v1, v0, :cond_11c

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    add-int/lit8 v1, v1, 0x1

    check-cast v2, Lcom/vdocipher/aegis/media/Caption;

    .line 58
    invoke-virtual {v2}, Lcom/vdocipher/aegis/media/Caption;->getUrl()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    .line 59
    new-instance v4, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    invoke-direct {v4, v3}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;-><init>(Landroid/net/Uri;)V

    const-string/jumbo v3, "text/vtt"

    invoke-virtual {v4, v3}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    move-result-object v3

    .line 60
    invoke-virtual {v2}, Lcom/vdocipher/aegis/media/Caption;->getLang()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->setLanguage(Ljava/lang/String;)Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    move-result-object v3

    .line 61
    invoke-virtual {v2}, Lcom/vdocipher/aegis/media/Caption;->getLabel()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->setLabel(Ljava/lang/String;)Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->build()Landroidx/media3/common/MediaItem$SubtitleConfiguration;

    move-result-object v2

    .line 63
    invoke-interface {p2, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_e6

    .line 66
    :cond_11c
    invoke-virtual {p1}, Landroidx/media3/common/MediaItem;->buildUpon()Landroidx/media3/common/MediaItem$Builder;

    move-result-object p3

    invoke-virtual {p3, p2}, Landroidx/media3/common/MediaItem$Builder;->setSubtitleConfigurations(Ljava/util/List;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p2

    invoke-virtual {p2}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    move-result-object p1
    :try_end_128
    .catch Ljava/lang/Exception; {:try_start_da .. :try_end_128} :catch_129

    return-object p1

    :catch_129
    move-exception v0

    move-object p2, v0

    .line 69
    invoke-static {p2}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p2

    const-string p3, "VdoDash"

    invoke-static {p3, p2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-object p1
.end method

.method protected a(Landroidx/media3/common/PlaybackException;)Lcom/vdocipher/aegis/core/m/p;
    .registers 14

    .line 70
    check-cast p1, Landroidx/media3/exoplayer/ExoPlaybackException;

    .line 71
    iget v0, p1, Landroidx/media3/exoplayer/ExoPlaybackException;->type:I

    const/4 v1, 0x1

    if-nez v0, :cond_c

    const-string/jumbo v2, "source"

    :goto_a
    move-object v4, v2

    goto :goto_15

    :cond_c
    if-ne v0, v1, :cond_11

    .line 72
    const-string v2, "renderer"

    goto :goto_a

    :cond_11
    const-string/jumbo v2, "unexpected"

    goto :goto_a

    :goto_15
    const/4 v2, 0x0

    const/4 v3, -0x1

    if-nez v0, :cond_b8

    .line 82
    invoke-virtual {p1}, Landroidx/media3/exoplayer/ExoPlaybackException;->getSourceException()Ljava/io/IOException;

    move-result-object v0

    .line 85
    instance-of v1, v0, Landroidx/media3/exoplayer/drm/DrmSession$DrmSessionException;

    if-eqz v1, :cond_3b

    .line 86
    move-object v1, v0

    check-cast v1, Landroidx/media3/exoplayer/drm/DrmSession$DrmSessionException;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/m/n;->a(Landroidx/media3/exoplayer/drm/DrmSession$DrmSessionException;)Landroid/util/Pair;

    move-result-object v1

    .line 87
    iget-object v5, v1, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    .line 88
    iget-object v1, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    :goto_34
    move-object v6, v2

    move-object v8, v6

    move-object v9, v8

    move v10, v5

    :goto_38
    move v5, v3

    goto/16 :goto_106

    .line 89
    :cond_3b
    instance-of v1, v0, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;

    if-eqz v1, :cond_9f

    .line 92
    :try_start_3f
    move-object v1, v0

    check-cast v1, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;

    iget-object v1, v1, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;->dataSpec:Landroidx/media3/datasource/DataSpec;

    iget-object v1, v1, Landroidx/media3/datasource/DataSpec;->uri:Landroid/net/Uri;

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_4a
    .catch Ljava/lang/NullPointerException; {:try_start_3f .. :try_end_4a} :catch_4b

    goto :goto_4c

    :catch_4b
    move-object v1, v2

    .line 96
    :goto_4c
    instance-of v5, v0, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    if-eqz v5, :cond_55

    .line 97
    move-object v3, v0

    check-cast v3, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    iget v3, v3, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;->responseCode:I

    :cond_55
    const/16 v6, 0x258

    const/16 v7, 0x190

    const/16 v8, 0x1f4

    if-eqz v1, :cond_79

    .line 101
    const-string v9, "mpd"

    invoke-virtual {v1, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_79

    if-lt v3, v7, :cond_6d

    if-ge v3, v8, :cond_6d

    const/16 v5, 0x140c

    goto/16 :goto_fd

    :cond_6d
    if-lt v3, v8, :cond_75

    if-ge v3, v6, :cond_75

    const/16 v5, 0x140d

    goto/16 :goto_fd

    :cond_75
    const/16 v5, 0x140a

    goto/16 :goto_fd

    :cond_79
    if-lt v3, v7, :cond_80

    if-ge v3, v8, :cond_80

    const/16 v6, 0x13f8

    goto :goto_89

    :cond_80
    if-lt v3, v8, :cond_87

    if-ge v3, v6, :cond_87

    const/16 v6, 0x13f9

    goto :goto_89

    :cond_87
    const/16 v6, 0x13fa

    :goto_89
    if-eqz v5, :cond_9b

    .line 120
    move-object v5, v0

    check-cast v5, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    invoke-static {v5}, Lcom/vdocipher/aegis/core/t/d;->a(Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;)Ljava/lang/String;

    move-result-object v7

    .line 121
    invoke-static {v5}, Lcom/vdocipher/aegis/core/t/d;->b(Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;)Ljava/lang/String;

    move-result-object v5

    move v11, v6

    move-object v6, v5

    move v5, v11

    goto/16 :goto_ff

    :cond_9b
    move-object v7, v2

    move v5, v6

    move-object v6, v7

    goto :goto_ff

    .line 124
    :cond_9f
    instance-of v1, v0, Landroidx/media3/common/ParserException;

    if-eqz v1, :cond_a6

    const/16 v5, 0x17f2

    goto :goto_fc

    .line 128
    :cond_a6
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v1, v1, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result v1

    if-eqz v1, :cond_b5

    .line 129
    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/m/n;->a(Ljava/lang/Exception;)I

    move-result v5

    goto :goto_fc

    :cond_b5
    const/16 v5, 0x13f6

    goto :goto_fc

    :cond_b8
    if-ne v0, v1, :cond_ed

    .line 136
    invoke-virtual {p1}, Landroidx/media3/exoplayer/ExoPlaybackException;->getRendererException()Ljava/lang/Exception;

    move-result-object v0

    .line 137
    instance-of v1, v0, Landroidx/media3/exoplayer/drm/DrmSession$DrmSessionException;

    if-eqz v1, :cond_d7

    .line 138
    move-object v1, v0

    check-cast v1, Landroidx/media3/exoplayer/drm/DrmSession$DrmSessionException;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/m/n;->a(Landroidx/media3/exoplayer/drm/DrmSession$DrmSessionException;)Landroid/util/Pair;

    move-result-object v1

    .line 139
    iget-object v5, v1, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    .line 140
    iget-object v1, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    goto/16 :goto_34

    .line 141
    :cond_d7
    instance-of v1, v0, Landroid/media/MediaCodec$CryptoException;

    if-eqz v1, :cond_e3

    .line 142
    move-object v1, v0

    check-cast v1, Landroid/media/MediaCodec$CryptoException;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/m/n;->a(Landroid/media/MediaCodec$CryptoException;)I

    move-result v5

    goto :goto_fc

    .line 143
    :cond_e3
    instance-of v1, v0, Landroidx/media3/exoplayer/mediacodec/MediaCodecRenderer$DecoderInitializationException;

    if-eqz v1, :cond_ea

    const/16 v5, 0x17ea

    goto :goto_fc

    :cond_ea
    const/16 v5, 0x17e8

    goto :goto_fc

    .line 149
    :cond_ed
    invoke-virtual {p1}, Landroidx/media3/exoplayer/ExoPlaybackException;->getUnexpectedException()Ljava/lang/RuntimeException;

    move-result-object v0

    .line 150
    invoke-virtual {p0, v0}, Lcom/vdocipher/aegis/core/m/q;->a(Ljava/lang/Throwable;)Z

    move-result v1

    if-eqz v1, :cond_fa

    const/16 v5, 0x17e9

    goto :goto_fc

    :cond_fa
    const/16 v5, 0x17d5

    :goto_fc
    move-object v1, v2

    :goto_fd
    move-object v6, v2

    move-object v7, v6

    :goto_ff
    move v10, v5

    move-object v9, v6

    move-object v8, v7

    move-object v6, v1

    move-object v1, v2

    goto/16 :goto_38

    .line 154
    :goto_106
    new-instance v3, Lcom/vdocipher/aegis/core/m/d;

    if-eqz v0, :cond_10e

    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v2

    :cond_10e
    move-object v7, v2

    invoke-direct/range {v3 .. v9}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 155
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "epError: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Lcom/vdocipher/aegis/core/m/d;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "--"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "VdoDash"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/16 p1, 0x7f4

    if-eq v10, p1, :cond_13d

    const/16 p1, 0x7f7

    if-ne v10, p1, :cond_146

    .line 159
    :cond_13d
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/q/c;->a(Landroid/content/Context;)Lcom/vdocipher/aegis/core/q/c;

    move-result-object p1

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/q/c;->a()V

    :cond_146
    if-eqz v1, :cond_149

    goto :goto_14d

    .line 162
    :cond_149
    invoke-static {v10}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v1

    .line 163
    :goto_14d
    new-instance p1, Lcom/vdocipher/aegis/core/m/p;

    invoke-direct {p1, v10, v1, v3}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    return-object p1
.end method

.method public a()V
    .registers 1

    .line 1
    invoke-super {p0}, Lcom/vdocipher/aegis/core/m/q;->a()V

    return-void
.end method

.method protected b(Lcom/vdocipher/aegis/core/m/y$a;)V
    .registers 16

    const-string v1, "VdoDash"

    const/4 v2, 0x0

    const/4 v3, -0x1

    const/4 v4, 0x1

    .line 1
    :try_start_5
    new-instance v0, Lcom/vdocipher/aegis/core/f/g;

    iget-object v5, p1, Lcom/vdocipher/aegis/core/m/y$a;->b:Ljava/lang/String;

    invoke-direct {v0, v5}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    .line 2
    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/m/n;->a(Lcom/vdocipher/aegis/core/f/g;)V
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_11} :catch_187

    .line 6
    :try_start_11
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 7
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->d()Z

    move-result v0

    if-eqz v0, :cond_2e

    .line 8
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {v0, v5}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/util/ArrayList;)Ljava/util/ArrayList;
    :try_end_25
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_25} :catch_26

    goto :goto_2e

    :catch_26
    move-exception v0

    .line 10
    :try_start_27
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 14
    :cond_2e
    :goto_2e
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->d()Z

    move-result v0

    if-eqz v0, :cond_3e

    .line 15
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/g;->k()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/n;->Q:Ljava/lang/String;

    .line 17
    :cond_3e
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/g;->s()Ljava/lang/String;

    move-result-object v0
    :try_end_44
    .catch Ljava/lang/Exception; {:try_start_27 .. :try_end_44} :catch_187

    .line 27
    iget-object v5, p1, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v5}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result v5

    const-string v6, ""

    const/16 v7, 0x1005

    if-eqz v5, :cond_d4

    .line 30
    :try_start_50
    iget-object v5, p1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v5, v5, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    iput-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->F:Ljava/lang/String;

    .line 32
    iget-object v5, p1, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v5}, Lcom/vdocipher/aegis/core/m/f;->e()Z

    move-result v5

    if-eqz v5, :cond_62

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/n;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_62
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/n;->R:Ljava/lang/String;

    .line 34
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->e()Z

    move-result v0

    if-eqz v0, :cond_6e

    move-object v0, v6

    goto :goto_7b

    :cond_6e
    new-instance v0, Lorg/json/JSONObject;

    iget-object v5, p1, Lcom/vdocipher/aegis/core/m/y$a;->h:Ljava/lang/String;

    invoke-direct {v0, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v5, "ext_manf"

    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_7b
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/n;->Q:Ljava/lang/String;

    .line 36
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/y$a;->k:Landroidx/media3/exoplayer/offline/Download;

    if-eqz v0, :cond_85

    iget-object v0, v0, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/n;->S:Landroidx/media3/exoplayer/offline/DownloadRequest;

    .line 38
    :cond_85
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->e()Z

    move-result v0

    if-nez v0, :cond_e4

    .line 39
    new-instance v0, Lorg/json/JSONObject;

    iget-object v5, p1, Lcom/vdocipher/aegis/core/m/y$a;->h:Ljava/lang/String;

    invoke-direct {v0, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v5, "ext_k"

    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    invoke-static {v0, v5}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/n;->T:[B
    :try_end_a1
    .catch Lorg/json/JSONException; {:try_start_50 .. :try_end_a1} :catch_a7
    .catch Ljava/lang/IllegalArgumentException; {:try_start_50 .. :try_end_a1} :catch_a5
    .catch Ljava/lang/NullPointerException; {:try_start_50 .. :try_end_a1} :catch_a2

    goto :goto_e4

    :catch_a2
    move-exception v0

    :goto_a3
    move-object p1, v0

    goto :goto_a9

    :catch_a5
    move-exception v0

    goto :goto_a3

    :catch_a7
    move-exception v0

    goto :goto_a3

    .line 43
    :goto_a9
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 45
    invoke-static {v7}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v0

    .line 46
    new-instance v1, Lcom/vdocipher/aegis/core/m/d;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, v5, v3, v2, p1}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 47
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    new-instance v2, Lcom/vdocipher/aegis/core/m/p;

    invoke-direct {v2, v7, v0, v1}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    invoke-virtual {p1, v4, v2}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void

    .line 52
    :cond_d4
    :try_start_d4
    iget-object v5, p1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v5, v5, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    invoke-static {v5}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->F:Ljava/lang/String;

    .line 53
    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/n;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/n;->R:Ljava/lang/String;
    :try_end_e4
    .catch Lorg/json/JSONException; {:try_start_d4 .. :try_end_e4} :catch_15a
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_d4 .. :try_end_e4} :catch_158
    .catch Ljava/lang/IllegalArgumentException; {:try_start_d4 .. :try_end_e4} :catch_155

    .line 63
    :cond_e4
    :goto_e4
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "["

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/n;->Q:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/n;->R:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "]"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 69
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result v0

    const/4 v2, 0x2

    if-eqz v0, :cond_111

    move v8, v2

    goto :goto_112

    :cond_111
    move v8, v4

    .line 70
    :goto_112
    new-instance v7, Lcom/vdocipher/aegis/media/MediaInfo;

    iget-object v9, p0, Lcom/vdocipher/aegis/core/m/q;->F:Ljava/lang/String;

    iget-object v10, p0, Lcom/vdocipher/aegis/core/m/q;->G:Ljava/lang/String;

    iget-object v11, p0, Lcom/vdocipher/aegis/core/m/q;->H:Ljava/lang/String;

    iget-wide v12, p0, Lcom/vdocipher/aegis/core/m/q;->I:J

    invoke-direct/range {v7 .. v13}, Lcom/vdocipher/aegis/media/MediaInfo;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    iput-object v7, p0, Lcom/vdocipher/aegis/core/m/q;->C:Lcom/vdocipher/aegis/media/MediaInfo;

    .line 73
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/n;->o()V

    .line 77
    :try_start_124
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/y$a;->k:Landroidx/media3/exoplayer/offline/Download;

    if-eqz v0, :cond_12c

    .line 78
    invoke-static {v0}, Lcom/vdocipher/aegis/offline/DownloadStatus;->getOfflineScrubbingPreviewUrl(Landroidx/media3/exoplayer/offline/Download;)Ljava/lang/String;

    move-result-object v6

    .line 80
    :cond_12c
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v3, p1, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    iget-object p1, p1, Lcom/vdocipher/aegis/player/VdoInitParams;->configMap:Ljava/util/HashMap;

    invoke-virtual {v0, v3, p1, v6}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/lang/String;Ljava/util/HashMap;Ljava/lang/String;)Lcom/vdocipher/aegis/media/PlayerOption;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->c:Lcom/vdocipher/aegis/media/PlayerOption;
    :try_end_13a
    .catch Ljava/lang/Exception; {:try_start_124 .. :try_end_13a} :catch_13b

    goto :goto_14b

    :catch_13b
    move-exception v0

    move-object p1, v0

    .line 82
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 83
    new-instance p1, Lcom/vdocipher/aegis/media/PlayerOption;

    invoke-direct {p1}, Lcom/vdocipher/aegis/media/PlayerOption;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->c:Lcom/vdocipher/aegis/media/PlayerOption;

    .line 86
    :goto_14b
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    invoke-virtual {p1, v2}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void

    :catch_155
    move-exception v0

    :goto_156
    move-object p1, v0

    goto :goto_15c

    :catch_158
    move-exception v0

    goto :goto_156

    :catch_15a
    move-exception v0

    goto :goto_156

    .line 87
    :goto_15c
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 89
    invoke-static {v7}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v0

    .line 90
    new-instance v1, Lcom/vdocipher/aegis/core/m/d;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, v5, v3, v2, p1}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 91
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    new-instance v2, Lcom/vdocipher/aegis/core/m/p;

    invoke-direct {v2, v7, v0, v1}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    invoke-virtual {p1, v4, v2}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void

    :catch_187
    move-exception v0

    move-object p1, v0

    .line 92
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0xc1c

    .line 94
    invoke-static {v0}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v1

    .line 95
    new-instance v5, Lcom/vdocipher/aegis/core/m/d;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v5, v6, v3, v2, p1}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 96
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    new-instance v2, Lcom/vdocipher/aegis/core/m/p;

    invoke-direct {v2, v0, v1, v5}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    invoke-virtual {p1, v4, v2}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void
.end method

.method public getPlayerOptions()Lcom/vdocipher/aegis/media/PlayerOption;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->c:Lcom/vdocipher/aegis/media/PlayerOption;

    return-object v0
.end method

.method protected j()V
    .registers 9

    const-string v0, "VdoDash"

    const-string v1, "lic rem "

    const-wide/16 v2, -0x1

    .line 1
    :try_start_6
    iget-object v4, p0, Lcom/vdocipher/aegis/core/m/n;->R:Ljava/lang/String;

    new-instance v5, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    invoke-direct {v5}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;-><init>()V

    .line 2
    invoke-virtual {v5, v0}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;->setUserAgent(Ljava/lang/String;)Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    move-result-object v5

    new-instance v6, Landroidx/media3/exoplayer/drm/DrmSessionEventListener$EventDispatcher;

    invoke-direct {v6}, Landroidx/media3/exoplayer/drm/DrmSessionEventListener$EventDispatcher;-><init>()V

    .line 3
    invoke-static {v4, v5, v6}, Landroidx/media3/exoplayer/drm/OfflineLicenseHelper;->newWidevineInstance(Ljava/lang/String;Landroidx/media3/datasource/DataSource$Factory;Landroidx/media3/exoplayer/drm/DrmSessionEventListener$EventDispatcher;)Landroidx/media3/exoplayer/drm/OfflineLicenseHelper;

    move-result-object v4

    .line 5
    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/n;->T:[B

    invoke-virtual {v4, v5}, Landroidx/media3/exoplayer/drm/OfflineLicenseHelper;->getLicenseDurationRemainingSec([B)Landroid/util/Pair;

    move-result-object v5

    .line 6
    iget-object v6, v5, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v6, Ljava/lang/Long;

    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    move-result-wide v6
    :try_end_28
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_28} :catch_4f

    .line 7
    :try_start_28
    iget-object v5, v5, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v5, Ljava/lang/Long;

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    .line 8
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", playback "

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 9
    invoke-virtual {v4}, Landroidx/media3/exoplayer/drm/OfflineLicenseHelper;->release()V
    :try_end_4a
    .catch Ljava/lang/Exception; {:try_start_28 .. :try_end_4a} :catch_4b

    goto :goto_5a

    :catch_4b
    move-exception v1

    move-wide v4, v2

    move-wide v2, v6

    goto :goto_51

    :catch_4f
    move-exception v1

    move-wide v4, v2

    .line 11
    :goto_51
    invoke-static {v1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    move-wide v6, v2

    move-wide v2, v4

    .line 14
    :goto_5a
    :try_start_5a
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    invoke-static {v1, v6, v7, v2, v3}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/d/k;JJ)V
    :try_end_5f
    .catch Ljava/lang/Exception; {:try_start_5a .. :try_end_5f} :catch_60

    goto :goto_68

    :catch_60
    move-exception v1

    .line 16
    invoke-static {v1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :goto_68
    return-void
.end method

.method public stop()V
    .registers 2

    .line 1
    invoke-super {p0}, Lcom/vdocipher/aegis/core/m/q;->stop()V

    const/4 v0, 0x0

    .line 3
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/n;->Q:Ljava/lang/String;

    .line 4
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/n;->R:Ljava/lang/String;

    .line 5
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/n;->T:[B

    .line 6
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/n;->S:Landroidx/media3/exoplayer/offline/DownloadRequest;

    return-void
.end method
