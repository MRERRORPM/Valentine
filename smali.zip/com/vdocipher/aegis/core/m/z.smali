# classes14.dex

.class public abstract Lcom/vdocipher/aegis/core/m/z;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final VDO_PLAYING_PLAYBACK_MODE:Ljava/lang/String; = "VDO_PLAYING_PLAYBACK_MODE"

.field public static final VDO_PREFERENCES_FILE_NAME:Ljava/lang/String; = "com_vdocipher_aegis_setting"

.field public static final VDO_REQUESTED_PLAYBACK_MODE:Ljava/lang/String; = "VDO_REQUESTED_PLAYBACK_MODE"


# instance fields
.field protected a:Lcom/vdocipher/aegis/player/VdoPlayerSetting$VdoPlaybackMode;

.field protected b:Ljava/lang/String;

.field protected c:I


# direct methods
.method public constructor <init>(Lcom/vdocipher/aegis/player/VdoPlayerSetting$Builder;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iget-object v0, p1, Lcom/vdocipher/aegis/player/VdoPlayerSetting$Builder;->vdoPlaybackMode:Lcom/vdocipher/aegis/player/VdoPlayerSetting$VdoPlaybackMode;

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/z;->a:Lcom/vdocipher/aegis/player/VdoPlayerSetting$VdoPlaybackMode;

    .line 3
    iget-object v0, p1, Lcom/vdocipher/aegis/player/VdoPlayerSetting$Builder;->downloadLocation:Ljava/lang/String;

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/z;->b:Ljava/lang/String;

    .line 4
    iget p1, p1, Lcom/vdocipher/aegis/player/VdoPlayerSetting$Builder;->maxBufferMs:I

    iput p1, p0, Lcom/vdocipher/aegis/core/m/z;->c:I

    return-void
.end method

.method public static getVdoPlayingPlaybackMode(Landroid/content/Context;)Ljava/lang/String;
    .registers 3

    .line 1
    const-string v0, "com_vdocipher_aegis_setting"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    .line 2
    sget-object v0, Lcom/vdocipher/aegis/player/VdoPlayerSetting$VdoPlaybackMode;->DEFAULT:Lcom/vdocipher/aegis/player/VdoPlayerSetting$VdoPlaybackMode;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "VDO_PLAYING_PLAYBACK_MODE"

    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static getVdoRequestedPlaybackMode(Landroid/content/Context;)Ljava/lang/String;
    .registers 3

    .line 1
    const-string v0, "com_vdocipher_aegis_setting"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    .line 2
    sget-object v0, Lcom/vdocipher/aegis/player/VdoPlayerSetting$VdoPlaybackMode;->DEFAULT:Lcom/vdocipher/aegis/player/VdoPlayerSetting$VdoPlaybackMode;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "VDO_REQUESTED_PLAYBACK_MODE"

    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static setVdoPlayingPlaybackMode(Landroid/content/Context;Ljava/lang/String;)V
    .registers 4

    .line 1
    const-string v0, "com_vdocipher_aegis_setting"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    .line 2
    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "VDO_PLAYING_PLAYBACK_MODE"

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method


# virtual methods
.method protected a(Landroid/content/Context;)V
    .registers 5

    .line 1
    const-string v0, "com_vdocipher_aegis_setting"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    .line 2
    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/z;->b:Ljava/lang/String;

    const-string v2, "VDO_DOWNLOAD_LOCATION"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 3
    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/z;->a:Lcom/vdocipher/aegis/player/VdoPlayerSetting$VdoPlaybackMode;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "VDO_REQUESTED_PLAYBACK_MODE"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 4
    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    iget v0, p0, Lcom/vdocipher/aegis/core/m/z;->c:I

    const-string v1, "BUFFERING_GOAL_MS"

    invoke-interface {p1, v1, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method
