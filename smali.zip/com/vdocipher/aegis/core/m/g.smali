# classes14.dex

.class public Lcom/vdocipher/aegis/core/m/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vdocipher/aegis/player/VdoPlayer;
.implements Lcom/vdocipher/aegis/core/m/e$b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/core/m/g$c;,
        Lcom/vdocipher/aegis/core/m/g$b;
    }
.end annotation


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Landroid/os/Handler;

.field private final c:Landroid/os/Handler;

.field private d:Lcom/vdocipher/aegis/player/VdoPlayerView$Callback;

.field private final e:Ljava/util/concurrent/CopyOnWriteArraySet;

.field private final f:Ljava/lang/ref/WeakReference;

.field private final g:Ljava/lang/ref/WeakReference;

.field private final h:Ljava/lang/ref/WeakReference;

.field private i:Lcom/vdocipher/aegis/player/internal/util/AutoResumeCallback;

.field private j:Lcom/vdocipher/aegis/core/m/b0;

.field private k:Lcom/vdocipher/aegis/core/m/g$c;

.field private final l:Lcom/vdocipher/aegis/core/b/a;

.field private m:Lcom/vdocipher/aegis/core/m/g$b;

.field private n:Z

.field private final o:Landroidx/media3/common/Player;

.field private p:Ljava/lang/String;

.field private q:Ljava/lang/String;

.field private r:Landroid/widget/TextView;

.field private s:Lcom/vdocipher/aegis/core/m/y$b;

.field private t:Landroidx/lifecycle/MutableLiveData;


# direct methods
.method public static synthetic $r8$lambda$AKAlgos5Ya9Q1wUsrTTjbZrOO7A(Lcom/vdocipher/aegis/core/m/g;Lcom/vdocipher/aegis/core/m/g$b;Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/m/g;->a(Lcom/vdocipher/aegis/core/m/g$b;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    return-void
.end method

.method public static synthetic $r8$lambda$SmZarAoGJ7vPqtnLvoS4PT9Ykw8(Lcom/vdocipher/aegis/core/m/g;Lcom/vdocipher/aegis/core/m/g$b;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/g;->b(Lcom/vdocipher/aegis/core/m/g$b;)V

    return-void
.end method

.method public static synthetic $r8$lambda$vgEvdxRlnvaqAcffyJl-UcpI68I(Lcom/vdocipher/aegis/core/m/g;Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/g;->a(Lcom/vdocipher/aegis/media/ErrorDescription;)V

    return-void
.end method

.method public static synthetic $r8$lambda$y9XO5isIDm4C-urcx8HuA-SYCaA(Lcom/vdocipher/aegis/core/m/g;Lcom/vdocipher/aegis/core/m/b0;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/g;->a(Lcom/vdocipher/aegis/core/m/b0;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/media3/common/Player;Lcom/vdocipher/aegis/core/m/b0;Ljava/lang/ref/WeakReference;Ljava/lang/ref/WeakReference;Ljava/lang/ref/WeakReference;Lcom/vdocipher/aegis/core/m/y$b;)V
    .registers 10

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    sget-object v0, Lcom/vdocipher/aegis/core/m/g$c;->a:Lcom/vdocipher/aegis/core/m/g$c;

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->k:Lcom/vdocipher/aegis/core/m/g$c;

    const/4 v0, 0x0

    .line 9
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->p:Ljava/lang/String;

    .line 13
    new-instance v1, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v1}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->t:Landroidx/lifecycle/MutableLiveData;

    .line 19
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->a:Landroid/content/Context;

    .line 20
    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/g;->o:Landroidx/media3/common/Player;

    .line 21
    iput-object p4, p0, Lcom/vdocipher/aegis/core/m/g;->f:Ljava/lang/ref/WeakReference;

    .line 22
    iput-object p5, p0, Lcom/vdocipher/aegis/core/m/g;->g:Ljava/lang/ref/WeakReference;

    .line 23
    iput-object p6, p0, Lcom/vdocipher/aegis/core/m/g;->h:Ljava/lang/ref/WeakReference;

    .line 24
    iput-object p7, p0, Lcom/vdocipher/aegis/core/m/g;->s:Lcom/vdocipher/aegis/core/m/y$b;

    .line 25
    invoke-static {p1}, Lcom/vdocipher/aegis/core/b/a;->a(Landroid/content/Context;)Lcom/vdocipher/aegis/core/b/a;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    .line 26
    new-instance p1, Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-direct {p1}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->e:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 27
    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p4

    invoke-direct {p1, p4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->b:Landroid/os/Handler;

    .line 28
    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p4

    invoke-direct {p1, p4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->c:Landroid/os/Handler;

    .line 31
    :try_start_40
    sget-object p1, Lcom/vdocipher/aegis/core/m/g$c;->b:Lcom/vdocipher/aegis/core/m/g$c;

    invoke-static {p3, v0}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object p4

    invoke-direct {p0, p1, p4}, Lcom/vdocipher/aegis/core/m/g;->a(Lcom/vdocipher/aegis/core/m/g$c;Landroid/util/Pair;)V
    :try_end_49
    .catch Ljava/lang/Exception; {:try_start_40 .. :try_end_49} :catch_4a

    goto :goto_54

    :catch_4a
    move-exception p1

    .line 33
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p4, "PDelegate"

    invoke-static {p4, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 35
    :goto_54
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->i:Lcom/vdocipher/aegis/player/internal/util/AutoResumeCallback;

    .line 37
    invoke-interface {p2}, Landroidx/media3/common/Player;->getPlaybackState()I

    move-result p1

    const/4 p2, 0x1

    if-ne p1, p2, :cond_69

    .line 40
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->c:Landroid/os/Handler;

    new-instance p2, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda1;

    invoke-direct {p2, p0, p3}, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda1;-><init>(Lcom/vdocipher/aegis/core/m/g;Lcom/vdocipher/aegis/core/m/b0;)V

    const-wide/16 p3, 0x1388

    invoke-virtual {p1, p2, p3, p4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_69
    return-void
.end method

.method private a(Landroid/util/Pair;)V
    .registers 9

    .line 86
    sget-object v0, Lcom/vdocipher/aegis/core/m/g$a;->a:[I

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->k:Lcom/vdocipher/aegis/core/m/g$c;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x2

    if-eq v0, v1, :cond_43

    const/4 p1, 0x3

    const/4 v1, 0x0

    if-eq v0, p1, :cond_1f

    const/4 p1, 0x4

    if-eq v0, p1, :cond_15

    goto :goto_45

    .line 115
    :cond_15
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz p1, :cond_1c

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/m/g$b;->a()V

    .line 116
    :cond_1c
    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    return-void

    .line 117
    :cond_1f
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->o:Landroidx/media3/common/Player;

    invoke-interface {p1}, Landroidx/media3/common/Player;->getAvailableCommands()Landroidx/media3/common/Player$Commands;

    move-result-object p1

    const/16 v0, 0x1b

    invoke-virtual {p1, v0}, Landroidx/media3/common/Player$Commands;->contains(I)Z

    move-result p1

    if-eqz p1, :cond_32

    .line 118
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->o:Landroidx/media3/common/Player;

    invoke-interface {p1}, Landroidx/media3/common/Player;->clearVideoSurface()V

    .line 121
    :cond_32
    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->j:Lcom/vdocipher/aegis/core/m/b0;

    .line 123
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->b:Landroid/os/Handler;

    invoke-virtual {p1, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 124
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz p1, :cond_40

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/m/g$b;->a()V

    .line 125
    :cond_40
    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    return-void

    :cond_43
    if-nez p1, :cond_47

    :cond_45
    :goto_45
    move-object v6, p0

    goto :goto_65

    .line 126
    :cond_47
    iget-object v0, p1, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v0, Lcom/vdocipher/aegis/core/m/b0;

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->j:Lcom/vdocipher/aegis/core/m/b0;

    .line 127
    iget-object p1, p1, Landroid/util/Pair;->second:Ljava/lang/Object;

    move-object v4, p1

    check-cast v4, Lcom/vdocipher/aegis/player/PlaybackState;

    if-eqz v4, :cond_45

    .line 129
    new-instance v0, Lcom/vdocipher/aegis/core/m/g$b;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->q:Ljava/lang/String;

    iget-object v2, v4, Lcom/vdocipher/aegis/player/PlaybackState;->initParams:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/g;->o:Landroidx/media3/common/Player;

    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/g;->a:Landroid/content/Context;

    move-object v6, p0

    invoke-direct/range {v0 .. v6}, Lcom/vdocipher/aegis/core/m/g$b;-><init>(Ljava/lang/String;Lcom/vdocipher/aegis/player/VdoInitParams;Landroidx/media3/common/Player;Lcom/vdocipher/aegis/player/PlaybackState;Landroid/content/Context;Lcom/vdocipher/aegis/core/m/e$b;)V

    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/m/g;->c(Lcom/vdocipher/aegis/core/m/g$b;)V

    :goto_65
    return-void
.end method

.method private synthetic a(Lcom/vdocipher/aegis/core/m/b0;)V
    .registers 6

    .line 1
    new-instance v0, Landroid/widget/TextView;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->r:Landroid/widget/TextView;

    .line 2
    sget-object v0, Lcom/vdocipher/aegis/core/z/d;->a:Lcom/vdocipher/aegis/core/z/d;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    sget v2, Lcom/vdocipher/aegis/R$string;->vdo_waiting_for_video:I

    const-string v3, "VDO_WAITING_FOR_VIDEO"

    invoke-virtual {v0, v1, v3, v2}, Lcom/vdocipher/aegis/core/z/d;->a(Landroid/content/Context;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    .line 3
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->r:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->r:Landroid/widget/TextView;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 5
    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v1, -0x2

    const/16 v2, 0x11

    invoke-direct {v0, v1, v1, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .line 8
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->r:Landroid/widget/TextView;

    invoke-virtual {p1, v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private a(Lcom/vdocipher/aegis/core/m/g$b;)V
    .registers 7

    .line 133
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->j:Lcom/vdocipher/aegis/core/m/b0;

    if-nez v0, :cond_5

    return-void

    .line 134
    :cond_5
    sget-object v0, Lcom/vdocipher/aegis/core/m/h;->b:Lcom/vdocipher/aegis/core/m/h;

    iget-object v1, p1, Lcom/vdocipher/aegis/core/m/g$b;->e:Lcom/vdocipher/aegis/core/m/h;

    if-ne v0, v1, :cond_1d

    .line 135
    new-instance v0, Lcom/vdocipher/aegis/core/m/n;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->a:Landroid/content/Context;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/g;->o:Landroidx/media3/common/Player;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/g;->j:Lcom/vdocipher/aegis/core/m/b0;

    iget-object v3, v3, Lcom/vdocipher/aegis/core/m/b0;->a:Landroid/view/SurfaceView;

    iget-object v4, p1, Lcom/vdocipher/aegis/core/m/g$b;->g:Lcom/vdocipher/aegis/core/d/k;

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/vdocipher/aegis/core/m/n;-><init>(Landroid/content/Context;Landroidx/media3/common/Player;Landroid/view/SurfaceView;Lcom/vdocipher/aegis/core/d/k;)V

    iput-object v0, p1, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    goto :goto_5a

    .line 137
    :cond_1d
    sget-object v0, Lcom/vdocipher/aegis/core/m/h;->c:Lcom/vdocipher/aegis/core/m/h;

    if-ne v0, v1, :cond_33

    .line 138
    new-instance v0, Lcom/vdocipher/aegis/core/m/t;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->a:Landroid/content/Context;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/g;->o:Landroidx/media3/common/Player;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/g;->j:Lcom/vdocipher/aegis/core/m/b0;

    iget-object v3, v3, Lcom/vdocipher/aegis/core/m/b0;->a:Landroid/view/SurfaceView;

    iget-object v4, p1, Lcom/vdocipher/aegis/core/m/g$b;->g:Lcom/vdocipher/aegis/core/d/k;

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/vdocipher/aegis/core/m/t;-><init>(Landroid/content/Context;Landroidx/media3/common/Player;Landroid/view/SurfaceView;Lcom/vdocipher/aegis/core/d/k;)V

    iput-object v0, p1, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    goto :goto_5a

    .line 140
    :cond_33
    sget-object v0, Lcom/vdocipher/aegis/core/m/h;->d:Lcom/vdocipher/aegis/core/m/h;

    if-ne v0, v1, :cond_49

    .line 141
    new-instance v0, Lcom/vdocipher/aegis/core/m/x;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->a:Landroid/content/Context;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/g;->o:Landroidx/media3/common/Player;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/g;->j:Lcom/vdocipher/aegis/core/m/b0;

    iget-object v3, v3, Lcom/vdocipher/aegis/core/m/b0;->a:Landroid/view/SurfaceView;

    iget-object v4, p1, Lcom/vdocipher/aegis/core/m/g$b;->g:Lcom/vdocipher/aegis/core/d/k;

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/vdocipher/aegis/core/m/x;-><init>(Landroid/content/Context;Landroidx/media3/common/Player;Landroid/view/SurfaceView;Lcom/vdocipher/aegis/core/d/k;)V

    iput-object v0, p1, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    goto :goto_5a

    .line 144
    :cond_49
    new-instance v0, Lcom/vdocipher/aegis/core/m/s;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->a:Landroid/content/Context;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/g;->o:Landroidx/media3/common/Player;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/g;->j:Lcom/vdocipher/aegis/core/m/b0;

    iget-object v3, v3, Lcom/vdocipher/aegis/core/m/b0;->a:Landroid/view/SurfaceView;

    iget-object v4, p1, Lcom/vdocipher/aegis/core/m/g$b;->g:Lcom/vdocipher/aegis/core/d/k;

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/vdocipher/aegis/core/m/s;-><init>(Landroid/content/Context;Landroidx/media3/common/Player;Landroid/view/SurfaceView;Lcom/vdocipher/aegis/core/d/k;)V

    iput-object v0, p1, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    .line 148
    :goto_5a
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->g:Ljava/lang/ref/WeakReference;

    invoke-interface {v0, v1}, Lcom/vdocipher/aegis/core/m/y;->a(Ljava/lang/ref/WeakReference;)V

    .line 149
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->f:Ljava/lang/ref/WeakReference;

    invoke-interface {v0, v1}, Lcom/vdocipher/aegis/core/m/y;->b(Ljava/lang/ref/WeakReference;)V

    .line 150
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->h:Ljava/lang/ref/WeakReference;

    invoke-interface {v0, v1}, Lcom/vdocipher/aegis/core/m/y;->c(Ljava/lang/ref/WeakReference;)V

    .line 151
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/m/g;->a(Lcom/vdocipher/aegis/player/VdoPlayer;)V

    .line 153
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    iget-object v1, p1, Lcom/vdocipher/aegis/core/m/g$b;->d:Lcom/vdocipher/aegis/core/m/y$a;

    invoke-interface {v0, v1}, Lcom/vdocipher/aegis/core/m/y;->a(Lcom/vdocipher/aegis/core/m/y$a;)V

    .line 154
    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->i:Lcom/vdocipher/aegis/player/internal/util/AutoResumeCallback;

    invoke-interface {p1, v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->setAutoResumeCallback(Lcom/vdocipher/aegis/player/internal/util/AutoResumeCallback;)V

    return-void
.end method

.method private synthetic a(Lcom/vdocipher/aegis/core/m/g$b;Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 6

    .line 130
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->e:Ljava/util/concurrent/CopyOnWriteArraySet;

    if-nez v0, :cond_5

    goto :goto_1b

    .line 131
    :cond_5
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_9
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 132
    iget-object v2, p1, Lcom/vdocipher/aegis/core/m/g$b;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-interface {v1, v2, p2}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onLoadError(Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    goto :goto_9

    :cond_1b
    :goto_1b
    return-void
.end method

.method private a(Lcom/vdocipher/aegis/core/m/g$c;Landroid/util/Pair;)V
    .registers 7

    .line 60
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->k:Lcom/vdocipher/aegis/core/m/g$c;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " -> "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 61
    sget-object v1, Lcom/vdocipher/aegis/core/m/g$a;->a:[I

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/g;->k:Lcom/vdocipher/aegis/core/m/g$c;

    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aget v1, v1, v2

    const/4 v2, 0x2

    const-string v3, "Transition not allowed: "

    if-eq v1, v2, :cond_43

    const/4 v2, 0x3

    if-eq v1, v2, :cond_43

    const/4 v2, 0x4

    if-eq v1, v2, :cond_2c

    goto :goto_47

    .line 72
    :cond_2c
    sget-object v1, Lcom/vdocipher/aegis/core/m/g$c;->d:Lcom/vdocipher/aegis/core/m/g$c;

    if-ne p1, v1, :cond_31

    goto :goto_47

    .line 73
    :cond_31
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 74
    :cond_43
    sget-object v1, Lcom/vdocipher/aegis/core/m/g$c;->a:Lcom/vdocipher/aegis/core/m/g$c;

    if-eq p1, v1, :cond_60

    .line 81
    :goto_47
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->k:Lcom/vdocipher/aegis/core/m/g$c;

    .line 83
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v1, "Transition "

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "PDelegate"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 84
    invoke-direct {p0, p2}, Lcom/vdocipher/aegis/core/m/g;->a(Landroid/util/Pair;)V

    return-void

    .line 85
    :cond_60
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private synthetic a(Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 5

    .line 31
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->e:Ljava/util/concurrent/CopyOnWriteArraySet;

    if-nez v0, :cond_5

    goto :goto_22

    .line 32
    :cond_5
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-nez v1, :cond_a

    goto :goto_22

    .line 33
    :cond_a
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_22

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 34
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    iget-object v2, v2, Lcom/vdocipher/aegis/core/m/g$b;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-interface {v1, v2, p1}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onLoadError(Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    goto :goto_e

    :cond_22
    :goto_22
    return-void
.end method

.method private a(Lcom/vdocipher/aegis/player/VdoPlayer;)V
    .registers 4

    .line 155
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->e:Ljava/util/concurrent/CopyOnWriteArraySet;

    if-nez v0, :cond_5

    goto :goto_19

    .line 156
    :cond_5
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_9
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_19

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 157
    invoke-interface {p1, v1}, Lcom/vdocipher/aegis/player/VdoPlayer;->addPlaybackEventListener(Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;)V

    goto :goto_9

    :cond_19
    :goto_19
    return-void
.end method

.method private synthetic b(Lcom/vdocipher/aegis/core/m/g$b;)V
    .registers 5

    .line 14
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->e:Ljava/util/concurrent/CopyOnWriteArraySet;

    if-eqz v0, :cond_21

    iget-object v1, p1, Lcom/vdocipher/aegis/core/m/g$b;->c:Lcom/vdocipher/aegis/core/m/e;

    iget-boolean v1, v1, Lcom/vdocipher/aegis/core/m/e;->o:Z

    if-eqz v1, :cond_b

    goto :goto_21

    .line 16
    :cond_b
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_21

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 17
    iget-object v2, p1, Lcom/vdocipher/aegis/core/m/g$b;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-interface {v1, v2}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onLoading(Lcom/vdocipher/aegis/player/VdoInitParams;)V

    goto :goto_f

    :cond_21
    :goto_21
    return-void
.end method

.method private c(Lcom/vdocipher/aegis/core/m/g$b;)V
    .registers 6

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->j:Lcom/vdocipher/aegis/core/m/b0;

    if-eqz v0, :cond_7

    .line 3
    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/b0;->a()V

    .line 7
    :cond_7
    :try_start_7
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/g$b;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-boolean v0, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->skipMedia3VersionCheck:Z

    if-nez v0, :cond_10

    .line 8
    invoke-static {}, Lcom/vdocipher/aegis/core/t/d;->a()V
    :try_end_10
    .catch Ljava/lang/RuntimeException; {:try_start_7 .. :try_end_10} :catch_37

    .line 25
    :cond_10
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->k:Lcom/vdocipher/aegis/core/m/g$c;

    sget-object v1, Lcom/vdocipher/aegis/core/m/g$c;->d:Lcom/vdocipher/aegis/core/m/g$c;

    if-eq v0, v1, :cond_2f

    .line 34
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_29

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v1, p1, Lcom/vdocipher/aegis/core/m/g$b;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-virtual {v0, v1}, Lcom/vdocipher/aegis/player/VdoInitParams;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_29

    .line 35
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/g$b;->a()V

    .line 38
    :cond_29
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    .line 39
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/g;->d(Lcom/vdocipher/aegis/core/m/g$b;)V

    return-void

    .line 41
    :cond_2f
    const-string p1, "PDelegate"

    const-string v0, "released, cannot load"

    invoke-static {p1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :catch_37
    move-exception v0

    .line 42
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_40

    move-object v1, v0

    goto :goto_42

    .line 43
    :cond_40
    const-string v1, "ExoPlayer not found"

    :goto_42
    const-string v2, "VdoPlayer"

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/16 v1, 0x4b3

    if-eqz v0, :cond_4c

    goto :goto_50

    .line 45
    :cond_4c
    invoke-static {v1}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v0

    .line 46
    :goto_50
    new-instance v2, Lcom/vdocipher/aegis/media/ErrorDescription;

    const/4 v3, -0x1

    invoke-direct {v2, v1, v0, v3}, Lcom/vdocipher/aegis/media/ErrorDescription;-><init>(ILjava/lang/String;I)V

    .line 47
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->b:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, p1, v2}, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda2;-><init>(Lcom/vdocipher/aegis/core/m/g;Lcom/vdocipher/aegis/core/m/g$b;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private d(Lcom/vdocipher/aegis/core/m/g$b;)V
    .registers 5

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->k:Lcom/vdocipher/aegis/core/m/g$c;

    sget-object v1, Lcom/vdocipher/aegis/core/m/g$c;->b:Lcom/vdocipher/aegis/core/m/g$c;

    const-string v2, "PDelegate"

    if-eq v0, v1, :cond_e

    .line 3
    const-string p1, "abort handle"

    invoke-static {v2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 16
    :cond_e
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->b:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p1}, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/core/m/g;Lcom/vdocipher/aegis/core/m/g$b;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 25
    :try_start_18
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/g$b;->c:Lcom/vdocipher/aegis/core/m/e;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->a:Landroid/content/Context;

    invoke-virtual {v0, v1, p1}, Lcom/vdocipher/aegis/core/m/e;->a(Landroid/content/Context;Ljava/lang/Object;)V
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_18 .. :try_end_1f} :catch_20

    return-void

    :catch_20
    move-exception p1

    .line 27
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;Lcom/vdocipher/aegis/core/m/y$a;Lcom/vdocipher/aegis/core/m/h;Lcom/vdocipher/aegis/core/d/k;)V
    .registers 7

    .line 17
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 18
    const-string v0, "PDelegate"

    const-string v1, "prepared"

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 19
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->k:Lcom/vdocipher/aegis/core/m/g$c;

    sget-object v1, Lcom/vdocipher/aegis/core/m/g$c;->b:Lcom/vdocipher/aegis/core/m/g$c;

    if-ne v0, v1, :cond_41

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_41

    if-ne v0, p1, :cond_41

    .line 20
    iput-object p2, v0, Lcom/vdocipher/aegis/core/m/g$b;->d:Lcom/vdocipher/aegis/core/m/y$a;

    .line 21
    iput-object p3, v0, Lcom/vdocipher/aegis/core/m/g$b;->e:Lcom/vdocipher/aegis/core/m/h;

    .line 22
    iput-object p4, v0, Lcom/vdocipher/aegis/core/m/g$b;->g:Lcom/vdocipher/aegis/core/d/k;

    .line 23
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->t:Landroidx/lifecycle/MutableLiveData;

    invoke-virtual {p1, p4}, Landroidx/lifecycle/MutableLiveData;->setValue(Ljava/lang/Object;)V

    .line 24
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/g;->a(Lcom/vdocipher/aegis/core/m/g$b;)V

    .line 25
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->o:Landroidx/media3/common/Player;

    invoke-interface {p1}, Landroidx/media3/common/Player;->getPlaybackState()I

    move-result p1

    const/4 p2, 0x3

    if-eq p1, p2, :cond_3a

    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->o:Landroidx/media3/common/Player;

    invoke-interface {p1}, Landroidx/media3/common/Player;->getPlaybackState()I

    move-result p1

    const/4 p2, 0x2

    if-ne p1, p2, :cond_41

    :cond_3a
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->d:Lcom/vdocipher/aegis/player/VdoPlayerView$Callback;

    if-eqz p1, :cond_41

    .line 26
    invoke-interface {p1}, Lcom/vdocipher/aegis/player/VdoPlayerView$Callback;->onPrepared()V

    :cond_41
    return-void
.end method

.method public a(Ljava/lang/Object;Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 5

    .line 27
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 28
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "not prepared "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2}, Lcom/vdocipher/aegis/media/ErrorDescription;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "PDelegate"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 29
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->k:Lcom/vdocipher/aegis/core/m/g$c;

    sget-object v1, Lcom/vdocipher/aegis/core/m/g$c;->b:Lcom/vdocipher/aegis/core/m/g$c;

    if-ne v0, v1, :cond_32

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_32

    if-ne v0, p1, :cond_32

    .line 30
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->b:Landroid/os/Handler;

    new-instance v0, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda3;

    invoke-direct {v0, p0, p2}, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda3;-><init>(Lcom/vdocipher/aegis/core/m/g;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_32
    return-void
.end method

.method public a(Ljava/lang/String;)V
    .registers 9

    .line 35
    :try_start_0
    new-instance v0, Lcom/vdocipher/aegis/core/f/g;

    invoke-direct {v0, p1}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    .line 36
    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 37
    const-string v1, ""

    .line 38
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v2, :cond_19

    .line 39
    iget-object p1, v2, Lcom/vdocipher/aegis/core/m/g$b;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v1, p1, Lcom/vdocipher/aegis/player/VdoInitParams;->configMap:Ljava/util/HashMap;

    .line 40
    iget-object p1, p1, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    move-object v6, v1

    move-object v1, p1

    move-object p1, v6

    .line 45
    :cond_19
    new-instance v2, Lcom/vdocipher/aegis/media/Posters;

    invoke-direct {v2}, Lcom/vdocipher/aegis/media/Posters;-><init>()V

    .line 46
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    iget-object v3, v3, Lcom/vdocipher/aegis/core/m/g$b;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v3, v3, Lcom/vdocipher/aegis/player/VdoInitParams;->vdoMediaMetadata:Lcom/vdocipher/aegis/player/VdoMediaMetadata;

    const/4 v4, 0x0

    if-eqz v3, :cond_43

    .line 47
    invoke-virtual {v3}, Lcom/vdocipher/aegis/player/VdoMediaMetadata;->getPoster()Landroid/net/Uri;

    move-result-object v5

    if-eqz v5, :cond_43

    .line 48
    invoke-virtual {v3}, Lcom/vdocipher/aegis/player/VdoMediaMetadata;->getPoster()Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v3}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v2, v3, v5}, Lcom/vdocipher/aegis/media/Posters;->copy(Ljava/lang/String;Ljava/lang/Integer;)Lcom/vdocipher/aegis/media/Posters;

    move-result-object v2

    .line 49
    invoke-virtual {v0, v1, p1, v4, v2}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/lang/String;Ljava/util/HashMap;Ljava/lang/String;Lcom/vdocipher/aegis/media/Posters;)Lcom/vdocipher/aegis/media/PlayerOption;

    move-result-object p1

    goto :goto_47

    .line 52
    :cond_43
    invoke-virtual {v0, v1, p1, v4}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/lang/String;Ljava/util/HashMap;Ljava/lang/String;)Lcom/vdocipher/aegis/media/PlayerOption;

    move-result-object p1

    .line 54
    :goto_47
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->e:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_4d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_5d

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 55
    invoke-interface {v1, p1}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onMetaDataLoaded(Lcom/vdocipher/aegis/media/PlayerOption;)V

    goto :goto_4d

    .line 57
    :cond_5d
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->s:Lcom/vdocipher/aegis/core/m/y$b;

    invoke-interface {v0, p1}, Lcom/vdocipher/aegis/core/m/y$b;->a(Lcom/vdocipher/aegis/media/PlayerOption;)V
    :try_end_62
    .catch Lcom/vdocipher/aegis/core/f/d; {:try_start_0 .. :try_end_62} :catch_63

    return-void

    :catch_63
    move-exception p1

    .line 59
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "PDelegate"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public a(Ljava/lang/String;Lcom/vdocipher/aegis/player/VdoPlayerView$Callback;)V
    .registers 10

    .line 9
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->q:Ljava/lang/String;

    .line 10
    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/g;->d:Lcom/vdocipher/aegis/player/VdoPlayerView$Callback;

    .line 12
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/g;->o:Landroidx/media3/common/Player;

    invoke-interface {p2}, Landroidx/media3/common/Player;->getCurrentMediaItem()Landroidx/media3/common/MediaItem;

    move-result-object p2

    if-eqz p2, :cond_22

    .line 14
    invoke-static {p2}, Lcom/vdocipher/aegis/core/z/d;->a(Landroidx/media3/common/MediaItem;)Lcom/vdocipher/aegis/player/VdoInitParams;

    move-result-object v2

    if-eqz v2, :cond_22

    .line 16
    new-instance v0, Lcom/vdocipher/aegis/core/m/g$b;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/g;->o:Landroidx/media3/common/Player;

    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/g;->a:Landroid/content/Context;

    const/4 v4, 0x0

    move-object v6, p0

    move-object v1, p1

    invoke-direct/range {v0 .. v6}, Lcom/vdocipher/aegis/core/m/g$b;-><init>(Ljava/lang/String;Lcom/vdocipher/aegis/player/VdoInitParams;Landroidx/media3/common/Player;Lcom/vdocipher/aegis/player/PlaybackState;Landroid/content/Context;Lcom/vdocipher/aegis/core/m/e$b;)V

    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/m/g;->c(Lcom/vdocipher/aegis/core/m/g$b;)V

    return-void

    :cond_22
    move-object v6, p0

    return-void
.end method

.method public addPlaybackEventListener(Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    if-eqz p1, :cond_19

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->e:Ljava/util/concurrent/CopyOnWriteArraySet;

    if-eqz v0, :cond_19

    .line 3
    invoke-virtual {v0, p1}, Ljava/util/concurrent/CopyOnWriteArraySet;->add(Ljava/lang/Object;)Z

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_19

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_19

    .line 5
    invoke-interface {v0, p1}, Lcom/vdocipher/aegis/player/VdoPlayer;->addPlaybackEventListener(Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;)V

    :cond_19
    return-void
.end method

.method public b()Lcom/vdocipher/aegis/player/PlaybackState;
    .registers 13

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    const/4 v1, 0x0

    if-eqz v0, :cond_26

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_26

    .line 5
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->getCurrentTime()J

    move-result-wide v2

    .line 7
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->isAdaptive()Z

    move-result v0

    if-nez v0, :cond_28

    .line 8
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->getSelectedTracks()[Lcom/vdocipher/aegis/media/Track;

    move-result-object v0

    move-object v9, v0

    goto :goto_29

    :cond_26
    const-wide/16 v2, 0x0

    :cond_28
    move-object v9, v1

    :goto_29
    move-wide v6, v2

    .line 11
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_40

    .line 12
    new-instance v4, Lcom/vdocipher/aegis/player/PlaybackState;

    iget-object v5, v0, Lcom/vdocipher/aegis/core/m/g$b;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v8, p0, Lcom/vdocipher/aegis/core/m/g;->p:Ljava/lang/String;

    .line 13
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/m/g;->getPlaybackSpeed()F

    move-result v10

    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/m/g;->getPlayWhenReady()Z

    move-result v11

    invoke-direct/range {v4 .. v11}, Lcom/vdocipher/aegis/player/PlaybackState;-><init>(Lcom/vdocipher/aegis/player/VdoInitParams;JLjava/lang/String;[Lcom/vdocipher/aegis/media/Track;FZ)V

    return-object v4

    :cond_40
    return-object v1
.end method

.method public c()Z
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->k:Lcom/vdocipher/aegis/core/m/g$c;

    sget-object v1, Lcom/vdocipher/aegis/core/m/g$c;->c:Lcom/vdocipher/aegis/core/m/g$c;

    if-ne v0, v1, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public d()Z
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->k:Lcom/vdocipher/aegis/core/m/g$c;

    sget-object v1, Lcom/vdocipher/aegis/core/m/g$c;->d:Lcom/vdocipher/aegis/core/m/g$c;

    if-ne v0, v1, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public e()V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->e:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->clear()V

    .line 4
    :try_start_a
    sget-object v0, Lcom/vdocipher/aegis/core/m/g$c;->c:Lcom/vdocipher/aegis/core/m/g$c;

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lcom/vdocipher/aegis/core/m/g;->a(Lcom/vdocipher/aegis/core/m/g$c;Landroid/util/Pair;)V
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_10} :catch_11

    return-void

    :catch_11
    move-exception v0

    .line 6
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "PDelegate"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public getAvailableTracks()[Lcom/vdocipher/aegis/media/Track;
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    const/4 v1, 0x0

    if-nez v0, :cond_d

    new-array v0, v1, [Lcom/vdocipher/aegis/media/Track;

    return-object v0

    .line 3
    :cond_d
    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-nez v0, :cond_14

    new-array v0, v1, [Lcom/vdocipher/aegis/media/Track;

    return-object v0

    .line 4
    :cond_14
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->getAvailableTracks()[Lcom/vdocipher/aegis/media/Track;

    move-result-object v0

    return-object v0
.end method

.method public getBufferedTime()J
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    const-wide/16 v1, 0x0

    if-nez v0, :cond_c

    return-wide v1

    .line 3
    :cond_c
    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-nez v0, :cond_11

    return-wide v1

    .line 4
    :cond_11
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->getBufferedTime()J

    move-result-wide v0

    return-wide v0
.end method

.method public getCurrentLiveOffset()J
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_12

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_12

    .line 3
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->getCurrentLiveOffset()J

    move-result-wide v0

    return-wide v0

    :cond_12
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public getCurrentMedia()Lcom/vdocipher/aegis/media/MediaInfo;
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    const/4 v1, 0x0

    if-nez v0, :cond_b

    return-object v1

    .line 3
    :cond_b
    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-nez v0, :cond_10

    return-object v1

    .line 4
    :cond_10
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->getCurrentMedia()Lcom/vdocipher/aegis/media/MediaInfo;

    move-result-object v0

    return-object v0
.end method

.method public getCurrentMediaItemIndex()I
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_12

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_12

    .line 3
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->getCurrentMediaItemIndex()I

    move-result v0

    return v0

    :cond_12
    const/4 v0, 0x0

    return v0
.end method

.method public getCurrentTime()J
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    const-wide/16 v1, 0x0

    if-nez v0, :cond_c

    return-wide v1

    .line 3
    :cond_c
    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-nez v0, :cond_11

    return-wide v1

    .line 4
    :cond_11
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->getCurrentTime()J

    move-result-wide v0

    return-wide v0
.end method

.method public getCurrentTimeline()Lcom/vdocipher/aegis/player/VdoTimeLine;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_12

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_12

    .line 3
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->getCurrentTimeline()Lcom/vdocipher/aegis/player/VdoTimeLine;

    move-result-object v0

    return-object v0

    .line 5
    :cond_12
    sget-object v0, Lcom/vdocipher/aegis/player/VdoTimeLine;->EMPTY:Lcom/vdocipher/aegis/player/VdoTimeLine;

    return-object v0
.end method

.method public getDuration()J
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    const-wide/16 v1, 0x0

    if-nez v0, :cond_c

    return-wide v1

    .line 3
    :cond_c
    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-nez v0, :cond_11

    return-wide v1

    .line 4
    :cond_11
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->getDuration()J

    move-result-wide v0

    return-wide v0
.end method

.method public getPlayWhenReady()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-nez v0, :cond_c

    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/g;->n:Z

    return v0

    .line 3
    :cond_c
    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-nez v0, :cond_13

    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/g;->n:Z

    return v0

    .line 4
    :cond_13
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->getPlayWhenReady()Z

    move-result v0

    return v0
.end method

.method public getPlaybackProperty(Ljava/lang/String;)Ljava/lang/Object;
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    const/4 v1, 0x0

    if-nez v0, :cond_b

    return-object v1

    .line 3
    :cond_b
    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-nez v0, :cond_10

    return-object v1

    .line 4
    :cond_10
    invoke-interface {v0, p1}, Lcom/vdocipher/aegis/player/VdoPlayer;->getPlaybackProperty(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public getPlaybackSpeed()F
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    const/high16 v1, 0x3f800000  # 1.0f

    if-nez v0, :cond_c

    return v1

    .line 3
    :cond_c
    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-nez v0, :cond_11

    return v1

    .line 4
    :cond_11
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->getPlaybackSpeed()F

    move-result v0

    return v0
.end method

.method public getPlaybackState()I
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    const/4 v1, 0x1

    if-nez v0, :cond_b

    return v1

    .line 3
    :cond_b
    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-nez v0, :cond_10

    return v1

    .line 4
    :cond_10
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->getPlaybackState()I

    move-result v0

    return v0
.end method

.method public getPlayerOptions()Lcom/vdocipher/aegis/media/PlayerOption;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-nez v0, :cond_f

    new-instance v0, Lcom/vdocipher/aegis/media/PlayerOption;

    invoke-direct {v0}, Lcom/vdocipher/aegis/media/PlayerOption;-><init>()V

    return-object v0

    .line 3
    :cond_f
    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-nez v0, :cond_19

    new-instance v0, Lcom/vdocipher/aegis/media/PlayerOption;

    invoke-direct {v0}, Lcom/vdocipher/aegis/media/PlayerOption;-><init>()V

    return-object v0

    .line 4
    :cond_19
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->getPlayerOptions()Lcom/vdocipher/aegis/media/PlayerOption;

    move-result-object v0

    return-object v0
.end method

.method public getSelectedTracks()[Lcom/vdocipher/aegis/media/Track;
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    const/4 v1, 0x0

    if-nez v0, :cond_d

    new-array v0, v1, [Lcom/vdocipher/aegis/media/Track;

    return-object v0

    .line 3
    :cond_d
    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-nez v0, :cond_14

    new-array v0, v1, [Lcom/vdocipher/aegis/media/Track;

    return-object v0

    .line 4
    :cond_14
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->getSelectedTracks()[Lcom/vdocipher/aegis/media/Track;

    move-result-object v0

    return-object v0
.end method

.method public isAdaptive()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_15

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_15

    .line 3
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->isAdaptive()Z

    move-result v0

    if-eqz v0, :cond_15

    const/4 v0, 0x1

    return v0

    :cond_15
    const/4 v0, 0x0

    return v0
.end method

.method public isCurrentMediaItemLive()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_12

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_12

    .line 3
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->isCurrentMediaItemLive()Z

    move-result v0

    return v0

    :cond_12
    const/4 v0, 0x0

    return v0
.end method

.method public isCurrentMediaItemSeekable()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_12

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_12

    .line 3
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->isCurrentMediaItemSeekable()Z

    move-result v0

    return v0

    :cond_12
    const/4 v0, 0x0

    return v0
.end method

.method public isCurrentWindowDynamic()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_12

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_12

    .line 3
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->isCurrentWindowDynamic()Z

    move-result v0

    return v0

    :cond_12
    const/4 v0, 0x0

    return v0
.end method

.method public isSpeedControlSupported()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_15

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_15

    .line 3
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->isSpeedControlSupported()Z

    move-result v0

    if-eqz v0, :cond_15

    const/4 v0, 0x1

    return v0

    :cond_15
    const/4 v0, 0x0

    return v0
.end method

.method public load(Lcom/vdocipher/aegis/player/VdoInitParams;)V
    .registers 11

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_d

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-virtual {v0, p1}, Lcom/vdocipher/aegis/player/VdoInitParams;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_d

    return-void

    .line 5
    :cond_d
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 6
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->c:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 10
    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->d:Lcom/vdocipher/aegis/player/VdoPlayerView$Callback;

    .line 11
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->j:Lcom/vdocipher/aegis/core/m/b0;

    if-eqz v0, :cond_21

    .line 12
    invoke-virtual {v0, p1}, Lcom/vdocipher/aegis/core/m/b0;->a(Lcom/vdocipher/aegis/player/VdoInitParams;)V

    .line 14
    :cond_21
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->r:Landroid/widget/TextView;

    if-eqz v0, :cond_33

    const/16 v1, 0x8

    .line 15
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 16
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->j:Lcom/vdocipher/aegis/core/m/b0;

    if-eqz v0, :cond_33

    .line 17
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g;->r:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 19
    :cond_33
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->k:Lcom/vdocipher/aegis/core/m/g$c;

    sget-object v1, Lcom/vdocipher/aegis/core/m/g$c;->b:Lcom/vdocipher/aegis/core/m/g$c;

    if-ne v0, v1, :cond_4b

    .line 20
    new-instance v2, Lcom/vdocipher/aegis/core/m/g$b;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/g;->q:Ljava/lang/String;

    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/g;->o:Landroidx/media3/common/Player;

    iget-object v7, p0, Lcom/vdocipher/aegis/core/m/g;->a:Landroid/content/Context;

    const/4 v6, 0x0

    move-object v8, p0

    move-object v4, p1

    invoke-direct/range {v2 .. v8}, Lcom/vdocipher/aegis/core/m/g$b;-><init>(Ljava/lang/String;Lcom/vdocipher/aegis/player/VdoInitParams;Landroidx/media3/common/Player;Lcom/vdocipher/aegis/player/PlaybackState;Landroid/content/Context;Lcom/vdocipher/aegis/core/m/e$b;)V

    invoke-direct {p0, v2}, Lcom/vdocipher/aegis/core/m/g;->c(Lcom/vdocipher/aegis/core/m/g$b;)V

    return-void

    :cond_4b
    move-object v8, p0

    .line 21
    sget-object p1, Lcom/vdocipher/aegis/core/m/g$c;->c:Lcom/vdocipher/aegis/core/m/g$c;

    const-string v1, "PDelegate"

    if-ne v0, p1, :cond_58

    .line 22
    const-string p1, "Cannot load, player not ready"

    invoke-static {v1, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 23
    :cond_58
    sget-object p1, Lcom/vdocipher/aegis/core/m/g$c;->d:Lcom/vdocipher/aegis/core/m/g$c;

    if-ne v0, p1, :cond_62

    .line 24
    const-string p1, "released, cannot load"

    invoke-static {v1, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 26
    :cond_62
    const-string p1, "Error loading"

    invoke-static {v1, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public release()V
    .registers 3

    .line 1
    :try_start_0
    sget-object v0, Lcom/vdocipher/aegis/core/m/g$c;->d:Lcom/vdocipher/aegis/core/m/g$c;

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lcom/vdocipher/aegis/core/m/g;->a(Lcom/vdocipher/aegis/core/m/g$c;Landroid/util/Pair;)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_6} :catch_7

    return-void

    :catch_7
    move-exception v0

    .line 3
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "PDelegate"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public removePlaybackEventListener(Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    if-eqz p1, :cond_19

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->e:Ljava/util/concurrent/CopyOnWriteArraySet;

    if-eqz v0, :cond_19

    .line 3
    invoke-virtual {v0, p1}, Ljava/util/concurrent/CopyOnWriteArraySet;->remove(Ljava/lang/Object;)Z

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_19

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_19

    .line 5
    invoke-interface {v0, p1}, Lcom/vdocipher/aegis/player/VdoPlayer;->removePlaybackEventListener(Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;)V

    :cond_19
    return-void
.end method

.method public retry()V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_11

    iget-object v1, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v1, :cond_11

    .line 3
    invoke-interface {v1}, Lcom/vdocipher/aegis/player/VdoPlayer;->retry()V

    return-void

    :cond_11
    if-eqz v0, :cond_18

    .line 5
    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-virtual {p0, v0}, Lcom/vdocipher/aegis/core/m/g;->load(Lcom/vdocipher/aegis/player/VdoInitParams;)V

    :cond_18
    return-void
.end method

.method public searchInSelectedSubtitle(Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_10

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_10

    .line 3
    invoke-interface {v0, p1, p2}, Lcom/vdocipher/aegis/player/VdoPlayer;->searchInSelectedSubtitle(Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V

    :cond_10
    return-void
.end method

.method public seekTo(J)V
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_10

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_10

    .line 3
    invoke-interface {v0, p1, p2}, Lcom/vdocipher/aegis/player/VdoPlayer;->seekTo(J)V

    .line 6
    :cond_10
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->c:Landroid/os/Handler;

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 7
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->r:Landroid/widget/TextView;

    if-eqz p1, :cond_2a

    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/g;->j:Lcom/vdocipher/aegis/core/m/b0;

    if-eqz p2, :cond_2a

    const/16 p2, 0x8

    .line 8
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    .line 9
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->j:Lcom/vdocipher/aegis/core/m/b0;

    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/g;->r:Landroid/widget/TextView;

    invoke-virtual {p1, p2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_2a
    return-void
.end method

.method public seekToDefaultPosition()V
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_10

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_10

    .line 3
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->seekToDefaultPosition()V

    :cond_10
    return-void
.end method

.method public setAutoResumeCallback(Lcom/vdocipher/aegis/player/internal/util/AutoResumeCallback;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/g;->i:Lcom/vdocipher/aegis/player/internal/util/AutoResumeCallback;

    return-void
.end method

.method public setPlayWhenReady(Z)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/g;->n:Z

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_12

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_12

    .line 4
    invoke-interface {v0, p1}, Lcom/vdocipher/aegis/player/VdoPlayer;->setPlayWhenReady(Z)V

    :cond_12
    return-void
.end method

.method public setPlaybackSpeed(F)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_10

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_10

    .line 3
    invoke-interface {v0, p1}, Lcom/vdocipher/aegis/player/VdoPlayer;->setPlaybackSpeed(F)V

    :cond_10
    return-void
.end method

.method public setSelectedTracks([Lcom/vdocipher/aegis/media/Track;)V
    .registers 7

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->l:Lcom/vdocipher/aegis/core/b/a;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 3
    array-length v0, p1

    const/4 v1, 0x0

    :goto_7
    if-ge v1, v0, :cond_1f

    aget-object v2, p1, v1

    .line 4
    iget v3, v2, Lcom/vdocipher/aegis/media/Track;->type:I

    const/4 v4, 0x3

    if-ne v3, v4, :cond_1c

    .line 5
    sget-object v0, Lcom/vdocipher/aegis/media/Track;->DISABLE_CAPTIONS:Lcom/vdocipher/aegis/media/Track;

    if-ne v2, v0, :cond_17

    .line 6
    const-string v0, "none"

    goto :goto_19

    :cond_17
    iget-object v0, v2, Lcom/vdocipher/aegis/media/Track;->language:Ljava/lang/String;

    :goto_19
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->p:Ljava/lang/String;

    goto :goto_1f

    :cond_1c
    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    .line 11
    :cond_1f
    :goto_1f
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_2a

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_2a

    .line 12
    invoke-interface {v0, p1}, Lcom/vdocipher/aegis/player/VdoPlayer;->setSelectedTracks([Lcom/vdocipher/aegis/media/Track;)V

    :cond_2a
    return-void
.end method

.method public stop()V
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/g$b;->a()V

    :cond_7
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/g;->m:Lcom/vdocipher/aegis/core/m/g$b;

    return-void
.end method
