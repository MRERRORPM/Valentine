# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/m/r$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroidx/media3/exoplayer/upstream/CmcdConfiguration$Factory;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/m/r;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/m/r;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/r$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/m/r;

    return-void
.end method


# virtual methods
.method public final createCmcdConfiguration(Landroidx/media3/common/MediaItem;)Landroidx/media3/exoplayer/upstream/CmcdConfiguration;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/r$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/m/r;

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/m/r;->$r8$lambda$Sn7ugSpL1AvHoGy-AUxQXMRDVeI(Lcom/vdocipher/aegis/core/m/r;Landroidx/media3/common/MediaItem;)Landroidx/media3/exoplayer/upstream/CmcdConfiguration;

    move-result-object p1

    return-object p1
.end method
