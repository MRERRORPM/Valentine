# classes14.dex

.class public Lcom/vdocipher/aegis/core/m/y$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/y;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final a:Lcom/vdocipher/aegis/player/VdoInitParams;

.field public final b:Ljava/lang/String;

.field public final c:I

.field public final d:Ljava/lang/String;

.field public final e:[Lcom/vdocipher/aegis/media/Track;

.field public final f:Lcom/vdocipher/aegis/core/d/k;

.field public final g:Ljava/lang/String;

.field public final h:Ljava/lang/String;

.field public final i:F

.field public final j:Z

.field public final k:Landroidx/media3/exoplayer/offline/Download;

.field public final l:Lcom/vdocipher/aegis/core/m/f;

.field public final m:Z

.field public final n:Ljava/lang/String;

.field public final o:Ljava/lang/String;

.field public final p:Z


# direct methods
.method public constructor <init>(Lcom/vdocipher/aegis/player/VdoInitParams;Ljava/lang/String;ILjava/lang/String;[Lcom/vdocipher/aegis/media/Track;Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;Ljava/lang/String;Landroidx/media3/exoplayer/offline/Download;Lcom/vdocipher/aegis/core/m/f;FZZLjava/lang/String;Ljava/lang/String;Z)V
    .registers 17

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/y$a;->b:Ljava/lang/String;

    .line 4
    iput p3, p0, Lcom/vdocipher/aegis/core/m/y$a;->c:I

    .line 5
    iput-object p4, p0, Lcom/vdocipher/aegis/core/m/y$a;->d:Ljava/lang/String;

    .line 6
    iput-object p5, p0, Lcom/vdocipher/aegis/core/m/y$a;->e:[Lcom/vdocipher/aegis/media/Track;

    .line 7
    iput-object p6, p0, Lcom/vdocipher/aegis/core/m/y$a;->f:Lcom/vdocipher/aegis/core/d/k;

    .line 8
    iput-object p7, p0, Lcom/vdocipher/aegis/core/m/y$a;->g:Ljava/lang/String;

    .line 9
    iput-boolean p13, p0, Lcom/vdocipher/aegis/core/m/y$a;->m:Z

    .line 10
    iput-object p8, p0, Lcom/vdocipher/aegis/core/m/y$a;->h:Ljava/lang/String;

    .line 11
    iput-object p9, p0, Lcom/vdocipher/aegis/core/m/y$a;->k:Landroidx/media3/exoplayer/offline/Download;

    .line 12
    iput-object p10, p0, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    .line 13
    iput p11, p0, Lcom/vdocipher/aegis/core/m/y$a;->i:F

    .line 14
    iput-boolean p12, p0, Lcom/vdocipher/aegis/core/m/y$a;->j:Z

    .line 15
    iput-object p14, p0, Lcom/vdocipher/aegis/core/m/y$a;->n:Ljava/lang/String;

    .line 16
    iput-object p15, p0, Lcom/vdocipher/aegis/core/m/y$a;->o:Ljava/lang/String;

    move/from16 p1, p16

    .line 17
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/y$a;->p:Z

    return-void
.end method
