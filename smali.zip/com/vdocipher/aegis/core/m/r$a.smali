# classes14.dex

.class Lcom/vdocipher/aegis/core/m/r$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/media3/exoplayer/upstream/CmcdConfiguration$RequestConfig;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/vdocipher/aegis/core/m/r;-><init>(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/m/r;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/m/r;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/r$a;->a:Lcom/vdocipher/aegis/core/m/r;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getRequestedMaximumThroughputKbps(I)I
    .registers 2

    return p1
.end method
