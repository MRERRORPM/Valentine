# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/m/q;

.field public final synthetic f$1:[Lcom/vdocipher/aegis/core/v/b;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/m/q;[Lcom/vdocipher/aegis/core/v/b;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/m/q;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda0;->f$1:[Lcom/vdocipher/aegis/core/v/b;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/m/q;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda0;->f$1:[Lcom/vdocipher/aegis/core/v/b;

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/m/q;->$r8$lambda$9NOD53T80jrb_rQOfIG9nfVxtUg(Lcom/vdocipher/aegis/core/m/q;[Lcom/vdocipher/aegis/core/v/b;)V

    return-void
.end method
