# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/m/q;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;

.field public final synthetic f$3:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/m/q;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/lang/String;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda5;->f$0:Lcom/vdocipher/aegis/core/m/q;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda5;->f$1:Ljava/lang/String;

    iput-object p3, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda5;->f$2:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;

    iput-object p4, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda5;->f$3:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda5;->f$0:Lcom/vdocipher/aegis/core/m/q;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda5;->f$1:Ljava/lang/String;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda5;->f$2:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda5;->f$3:Ljava/lang/String;

    invoke-static {v0, v1, v2, v3}, Lcom/vdocipher/aegis/core/m/q;->$r8$lambda$z5WH-chhhiPLsqLNYeZwth6AauU(Lcom/vdocipher/aegis/core/m/q;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/lang/String;)V

    return-void
.end method
