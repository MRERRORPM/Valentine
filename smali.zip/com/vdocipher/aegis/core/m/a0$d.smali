# classes14.dex

.class Lcom/vdocipher/aegis/core/m/a0$d;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/a0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/m/a0;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/m/a0;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/a0$d;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 5

    if-eqz p2, :cond_35

    .line 1
    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p1

    if-eqz p1, :cond_35

    .line 2
    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p1

    const-string v0, "is_adaptive_playback"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_1e

    .line 3
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/a0$d;->a:Lcom/vdocipher/aegis/core/m/a0;

    const/4 v1, 0x0

    invoke-virtual {p2, v0, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v0

    invoke-static {p1, v0}, Lcom/vdocipher/aegis/core/m/a0;->a(Lcom/vdocipher/aegis/core/m/a0;Z)Z

    .line 5
    :cond_1e
    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p1

    const-string v0, "available_bitrate_set"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_35

    .line 6
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/a0$d;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getSerializableExtra(Ljava/lang/String;)Ljava/io/Serializable;

    move-result-object p2

    check-cast p2, Ljava/util/Set;

    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/m/a0;->a(Lcom/vdocipher/aegis/core/m/a0;Ljava/util/Set;)Ljava/util/Set;

    :cond_35
    return-void
.end method
