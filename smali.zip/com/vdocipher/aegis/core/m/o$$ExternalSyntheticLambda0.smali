# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/m/o$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroidx/media3/exoplayer/drm/ExoMediaDrm$Provider;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/m/o;

.field public final synthetic f$1:[B


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/m/o;[B)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/o$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/m/o;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/o$$ExternalSyntheticLambda0;->f$1:[B

    return-void
.end method


# virtual methods
.method public final acquireExoMediaDrm(Ljava/util/UUID;)Landroidx/media3/exoplayer/drm/ExoMediaDrm;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/o$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/m/o;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/o$$ExternalSyntheticLambda0;->f$1:[B

    invoke-static {v0, v1, p1}, Lcom/vdocipher/aegis/core/m/o;->$r8$lambda$XkDojTsjEm6AXDwBryCzZQxFwns(Lcom/vdocipher/aegis/core/m/o;[BLjava/util/UUID;)Landroidx/media3/exoplayer/drm/ExoMediaDrm;

    move-result-object p1

    return-object p1
.end method
