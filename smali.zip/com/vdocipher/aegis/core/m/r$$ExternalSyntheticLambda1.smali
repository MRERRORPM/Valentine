# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/m/r$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/m/r;

.field public final synthetic f$1:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/m/r;Landroid/content/Context;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/r$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/core/m/r;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/r$$ExternalSyntheticLambda1;->f$1:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/r$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/core/m/r;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/r$$ExternalSyntheticLambda1;->f$1:Landroid/content/Context;

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/m/r;->$r8$lambda$oV585mKhGckYu4Hh2z01brDdxhs(Lcom/vdocipher/aegis/core/m/r;Landroid/content/Context;)V

    return-void
.end method
