# classes14.dex

.class Lcom/vdocipher/aegis/core/m/a0$c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/a0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/m/a0;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/m/a0;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 8

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/a0;->j(Lcom/vdocipher/aegis/core/m/a0;)Landroidx/media3/exoplayer/ExoPlayer;

    move-result-object v0

    invoke-interface {v0}, Landroidx/media3/exoplayer/ExoPlayer;->getCurrentPosition()J

    move-result-wide v0

    .line 2
    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v2, v0, v1}, Ljava/util/concurrent/TimeUnit;->toSeconds(J)J

    move-result-wide v0

    long-to-int v0, v0

    int-to-long v1, v0

    .line 4
    :try_start_12
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/a0;->n(Lcom/vdocipher/aegis/core/m/a0;)J

    move-result-wide v3

    const-wide/16 v5, 0x1

    add-long/2addr v3, v5

    cmp-long v3, v1, v3

    if-nez v3, :cond_64

    .line 5
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/a0;->p(Lcom/vdocipher/aegis/core/m/a0;)J

    .line 6
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/a0;->q(Lcom/vdocipher/aegis/core/m/a0;)[I

    move-result-object v3

    array-length v3, v3

    if-ge v0, v3, :cond_64

    .line 8
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/a0;->q(Lcom/vdocipher/aegis/core/m/a0;)[I

    move-result-object v3

    aget v3, v3, v0

    const/4 v4, 0x1

    if-nez v3, :cond_46

    .line 9
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/a0;->q(Lcom/vdocipher/aegis/core/m/a0;)[I

    move-result-object v3

    aput v4, v3, v0

    .line 10
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/a0;->d(Lcom/vdocipher/aegis/core/m/a0;)J

    goto :goto_51

    .line 12
    :cond_46
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/a0;->q(Lcom/vdocipher/aegis/core/m/a0;)[I

    move-result-object v3

    aget v5, v3, v0

    add-int/2addr v5, v4

    aput v5, v3, v0

    :goto_51
    if-lez v0, :cond_64

    .line 15
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/a0;->a(Lcom/vdocipher/aegis/core/m/a0;)Lcom/vdocipher/aegis/core/d/k;

    move-result-object v3

    if-eqz v3, :cond_64

    .line 16
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/a0;->a(Lcom/vdocipher/aegis/core/m/a0;)Lcom/vdocipher/aegis/core/d/k;

    move-result-object v3

    invoke-virtual {v3, v0}, Lcom/vdocipher/aegis/core/d/k;->a(I)V
    :try_end_64
    .catch Ljava/lang/RuntimeException; {:try_start_12 .. :try_end_64} :catch_6c
    .catchall {:try_start_12 .. :try_end_64} :catchall_6a

    .line 24
    :cond_64
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v0, v1, v2}, Lcom/vdocipher/aegis/core/m/a0;->a(Lcom/vdocipher/aegis/core/m/a0;J)J

    goto :goto_7b

    :catchall_6a
    move-exception v0

    goto :goto_b5

    :catch_6c
    move-exception v0

    .line 25
    :try_start_6d
    const-string v3, "VdoServiceSM"

    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_76
    .catchall {:try_start_6d .. :try_end_76} :catchall_6a

    .line 27
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v0, v1, v2}, Lcom/vdocipher/aegis/core/m/a0;->a(Lcom/vdocipher/aegis/core/m/a0;J)J

    .line 29
    :goto_7b
    new-instance v0, Landroid/content/Intent;

    const-string v1, "action_vdo_tc_tp"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 30
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/m/a0;->o(Lcom/vdocipher/aegis/core/m/a0;)J

    move-result-wide v1

    const-string/jumbo v3, "vdo_total_played"

    invoke-virtual {v0, v3, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 31
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/m/a0;->c(Lcom/vdocipher/aegis/core/m/a0;)J

    move-result-wide v1

    const-string/jumbo v3, "vdo_total_covered"

    invoke-virtual {v0, v3, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 32
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/m/a0;->e(Lcom/vdocipher/aegis/core/m/a0;)Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z

    .line 33
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    iget-object v1, v0, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/a0;->f(Lcom/vdocipher/aegis/core/m/a0;)Ljava/lang/Runnable;

    move-result-object v0

    const-wide/16 v2, 0x1f4

    invoke-virtual {v1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    .line 34
    :goto_b5
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/a0$c;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v3, v1, v2}, Lcom/vdocipher/aegis/core/m/a0;->a(Lcom/vdocipher/aegis/core/m/a0;J)J

    .line 35
    throw v0
.end method
