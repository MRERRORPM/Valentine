# classes14.dex

.class Lcom/vdocipher/aegis/core/m/q$d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/media3/common/Player$Listener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/m/q;


# direct methods
.method public static synthetic $r8$lambda$O-V0QHenJ9pOCQw21z9ZUKvgK78(Lcom/vdocipher/aegis/core/m/q$d;Landroidx/media3/common/PlaybackParameters;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q$d;->a(Landroidx/media3/common/PlaybackParameters;)V

    return-void
.end method

.method public static synthetic $r8$lambda$aTauW5Qfi5oXrQKN3dVCGPAQPbw(Lcom/vdocipher/aegis/core/m/q$d;[Lcom/vdocipher/aegis/media/Track;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q$d;->a([Lcom/vdocipher/aegis/media/Track;)V

    return-void
.end method

.method constructor <init>(Lcom/vdocipher/aegis/core/m/q;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private synthetic a(Landroidx/media3/common/PlaybackParameters;)V
    .registers 4

    .line 8
    iget p1, p1, Landroidx/media3/common/PlaybackParameters;->speed:F

    .line 9
    invoke-static {}, Lcom/vdocipher/aegis/core/r/a;->a()Lcom/vdocipher/aegis/core/r/a;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v1, v1, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-virtual {v0, v1}, Lcom/vdocipher/aegis/core/r/a;->b(Landroid/content/Context;)F

    move-result v0

    cmpl-float v0, p1, v0

    if-eqz v0, :cond_19

    .line 11
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    const-string v1, "rateChange"

    invoke-virtual {v0, v1}, Lcom/vdocipher/aegis/core/m/q;->c(Ljava/lang/String;)V

    .line 13
    :cond_19
    invoke-static {}, Lcom/vdocipher/aegis/core/r/a;->a()Lcom/vdocipher/aegis/core/r/a;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v1, v1, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-virtual {v0, v1, p1}, Lcom/vdocipher/aegis/core/r/a;->a(Landroid/content/Context;F)V

    return-void
.end method

.method private synthetic a([Lcom/vdocipher/aegis/media/Track;)V
    .registers 7

    .line 1
    array-length v0, p1

    const/4 v1, 0x0

    :goto_2
    if-ge v1, v0, :cond_38

    aget-object v2, p1, v1

    .line 2
    iget v3, v2, Lcom/vdocipher/aegis/media/Track;->type:I

    const/4 v4, 0x3

    if-ne v3, v4, :cond_35

    .line 3
    invoke-static {}, Lcom/vdocipher/aegis/core/r/a;->a()Lcom/vdocipher/aegis/core/r/a;

    move-result-object v3

    iget-object v4, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v4, v4, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-virtual {v3, v4}, Lcom/vdocipher/aegis/core/r/a;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_28

    .line 4
    iget-object v4, v2, Lcom/vdocipher/aegis/media/Track;->language:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_28

    .line 5
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    const-string v4, "captionLanguageChange"

    invoke-virtual {v3, v4}, Lcom/vdocipher/aegis/core/m/q;->c(Ljava/lang/String;)V

    .line 7
    :cond_28
    invoke-static {}, Lcom/vdocipher/aegis/core/r/a;->a()Lcom/vdocipher/aegis/core/r/a;

    move-result-object v3

    iget-object v4, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v4, v4, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    iget-object v2, v2, Lcom/vdocipher/aegis/media/Track;->language:Ljava/lang/String;

    invoke-virtual {v3, v4, v2}, Lcom/vdocipher/aegis/core/r/a;->a(Landroid/content/Context;Ljava/lang/String;)V

    :cond_35
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_38
    return-void
.end method


# virtual methods
.method public onCues(Landroidx/media3/common/text/CueGroup;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/q;->h(Lcom/vdocipher/aegis/core/m/q;)Ljava/lang/ref/WeakReference;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/media3/exoplayer/text/TextOutput;

    if-eqz v0, :cond_11

    .line 3
    invoke-interface {v0, p1}, Landroidx/media3/exoplayer/text/TextOutput;->onCues(Landroidx/media3/common/text/CueGroup;)V

    :cond_11
    return-void
.end method

.method public onIsLoadingChanged(Z)V
    .registers 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "loading "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "VdoExo"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public onPlayWhenReadyChanged(ZI)V
    .registers 5

    .line 1
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v0, p2, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    .line 2
    invoke-static {p2}, Lcom/vdocipher/aegis/core/m/q;->e(Lcom/vdocipher/aegis/core/m/q;)Landroidx/media3/common/Player;

    move-result-object p2

    invoke-interface {p2}, Landroidx/media3/common/Player;->getPlaybackState()I

    move-result p2

    const/16 v1, 0x69

    .line 3
    invoke-virtual {v0, v1, p1, p2}, Landroid/os/Handler;->obtainMessage(III)Landroid/os/Message;

    move-result-object p1

    .line 5
    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void
.end method

.method public onPlaybackParametersChanged(Landroidx/media3/common/PlaybackParameters;)V
    .registers 5

    .line 1
    const-string v0, "VdoExo"

    const-string v1, "params changed"

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    iget v1, p1, Landroidx/media3/common/PlaybackParameters;->speed:F

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    const/16 v2, 0x6b

    invoke-virtual {v0, v2, v1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    .line 3
    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 6
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/vdocipher/aegis/core/m/q$d$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p1}, Lcom/vdocipher/aegis/core/m/q$d$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/core/m/q$d;Landroidx/media3/common/PlaybackParameters;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 14
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public onPlaybackStateChanged(I)V
    .registers 8

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "state changed: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/m/q;->e(Lcom/vdocipher/aegis/core/m/q;)Landroidx/media3/common/Player;

    move-result-object v1

    invoke-interface {v1}, Landroidx/media3/common/Player;->getPlayWhenReady()Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->a(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "VdoExo"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x3

    if-ne p1, v0, :cond_3c

    .line 4
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/m/q;->e(Lcom/vdocipher/aegis/core/m/q;)Landroidx/media3/common/Player;

    move-result-object v2

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/q;->f(Lcom/vdocipher/aegis/core/m/q;)Landroid/view/SurfaceView;

    move-result-object v3

    invoke-interface {v2, v3}, Landroidx/media3/common/Player;->setVideoSurfaceView(Landroid/view/SurfaceView;)V

    .line 7
    :cond_3c
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/m/q;->g(Lcom/vdocipher/aegis/core/m/q;)I

    move-result v2

    .line 8
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v3, p1}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/core/m/q;I)I

    const/4 v3, 0x1

    if-eq p1, v3, :cond_8a

    const/16 v1, 0x66

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eq p1, v5, :cond_7c

    if-eq p1, v0, :cond_64

    const/4 v0, 0x4

    if-eq p1, v0, :cond_56

    goto :goto_a0

    .line 29
    :cond_56
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    const/16 v1, 0x6a

    invoke-virtual {v0, v1}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    goto :goto_a0

    .line 30
    :cond_64
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v0, v3}, Lcom/vdocipher/aegis/core/m/q;->d(Lcom/vdocipher/aegis/core/m/q;Z)Z

    .line 31
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v0, v3}, Lcom/vdocipher/aegis/core/m/q;->b(Lcom/vdocipher/aegis/core/m/q;Z)V

    if-ne v2, v5, :cond_a0

    .line 33
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    invoke-virtual {v0, v1, v4, v4}, Landroid/os/Handler;->obtainMessage(III)Landroid/os/Message;

    move-result-object v0

    .line 34
    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    goto :goto_a0

    :cond_7c
    if-eq v2, v5, :cond_a0

    .line 40
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    invoke-virtual {v0, v1, v3, v4}, Landroid/os/Handler;->obtainMessage(III)Landroid/os/Message;

    move-result-object v0

    .line 41
    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    goto :goto_a0

    .line 50
    :cond_8a
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "unexpected state : "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->a(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 54
    :cond_a0
    :goto_a0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v1, v0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    .line 55
    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/q;->e(Lcom/vdocipher/aegis/core/m/q;)Landroidx/media3/common/Player;

    move-result-object v0

    invoke-interface {v0}, Landroidx/media3/common/Player;->getPlayWhenReady()Z

    move-result v0

    const/16 v2, 0x69

    .line 56
    invoke-virtual {v1, v2, v0, p1}, Landroid/os/Handler;->obtainMessage(III)Landroid/os/Message;

    move-result-object p1

    .line 58
    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void
.end method

.method public onPlayerError(Landroidx/media3/common/PlaybackException;)V
    .registers 2

    return-void
.end method

.method public onTimelineChanged(Landroidx/media3/common/Timeline;I)V
    .registers 4

    .line 1
    invoke-super {p0, p1, p2}, Landroidx/media3/common/Player$Listener;->onTimelineChanged(Landroidx/media3/common/Timeline;I)V

    .line 2
    new-instance v0, Lcom/vdocipher/aegis/core/m/m;

    invoke-direct {v0, p1}, Lcom/vdocipher/aegis/core/m/m;-><init>(Landroidx/media3/common/Timeline;)V

    .line 3
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-static {v0, p2}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object p2

    const/16 v0, 0x6d

    invoke-virtual {p1, v0, p2}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    .line 4
    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void
.end method

.method public onTracksChanged(Landroidx/media3/common/Tracks;)V
    .registers 7

    const-string p1, "VdoExo"

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/q;->b(Lcom/vdocipher/aegis/core/m/q;)[Lcom/vdocipher/aegis/media/Track;

    move-result-object v0

    .line 2
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/m/q;->c(Lcom/vdocipher/aegis/core/m/q;)[Lcom/vdocipher/aegis/media/Track;

    move-result-object v1

    .line 4
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v2, v2, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    invoke-static {v0, v1}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v0

    const/16 v3, 0x68

    invoke-virtual {v2, v3, v0}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 8
    :try_start_1f
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/d/k;[Lcom/vdocipher/aegis/media/Track;)V
    :try_end_26
    .catch Lorg/json/JSONException; {:try_start_1f .. :try_end_26} :catch_27

    goto :goto_2f

    :catch_27
    move-exception v0

    .line 10
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 13
    :goto_2f
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    if-eqz v0, :cond_42

    .line 14
    new-instance v0, Ljava/lang/Thread;

    new-instance v2, Lcom/vdocipher/aegis/core/m/q$d$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0, v1}, Lcom/vdocipher/aegis/core/m/q$d$$ExternalSyntheticLambda1;-><init>(Lcom/vdocipher/aegis/core/m/q$d;[Lcom/vdocipher/aegis/media/Track;)V

    invoke-direct {v0, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 24
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 28
    :cond_42
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->d()Z

    move-result v0

    if-eqz v0, :cond_7c

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/q;->u:[Lcom/vdocipher/aegis/media/Track;

    if-eqz v0, :cond_7c

    array-length v0, v0

    if-lez v0, :cond_7c

    .line 30
    const-string v0, "restore selections"

    invoke-static {p1, v0}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 31
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/q;->u:[Lcom/vdocipher/aegis/media/Track;

    array-length v1, v0

    const/4 v2, 0x0

    :goto_62
    if-ge v2, v1, :cond_77

    aget-object v3, v0, v2

    .line 33
    :try_start_66
    iget-object v4, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v4, v3}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/core/m/q;Lcom/vdocipher/aegis/media/Track;)V
    :try_end_6b
    .catch Ljava/lang/NullPointerException; {:try_start_66 .. :try_end_6b} :catch_6c

    goto :goto_74

    :catch_6c
    move-exception v3

    .line 35
    invoke-static {v3}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v3

    invoke-static {p1, v3}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :goto_74
    add-int/lit8 v2, v2, 0x1

    goto :goto_62

    .line 38
    :cond_77
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    const/4 v0, 0x0

    iput-object v0, p1, Lcom/vdocipher/aegis/core/m/q;->u:[Lcom/vdocipher/aegis/media/Track;

    .line 41
    :cond_7c
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/m/q;->d(Lcom/vdocipher/aegis/core/m/q;)Z

    move-result v0

    invoke-static {p1, v0}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/core/m/q;Z)V

    return-void
.end method

.method public onVideoSizeChanged(Landroidx/media3/common/VideoSize;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/core/m/q;Landroidx/media3/common/VideoSize;)V

    return-void
.end method
