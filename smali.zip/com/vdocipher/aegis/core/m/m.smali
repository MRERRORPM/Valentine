# classes14.dex

.class Lcom/vdocipher/aegis/core/m/m;
.super Lcom/vdocipher/aegis/player/VdoTimeLine;
.source "SourceFile"


# instance fields
.field private a:Landroidx/media3/common/Timeline;


# direct methods
.method constructor <init>(Landroidx/media3/common/Timeline;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/player/VdoTimeLine;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/m;->a:Landroidx/media3/common/Timeline;

    return-void
.end method


# virtual methods
.method public getWindow(I)Lcom/vdocipher/aegis/player/VdoTimeLine$VdoWindow;
    .registers 4

    const-wide/16 v0, 0x0

    .line 6
    invoke-virtual {p0, p1, v0, v1}, Lcom/vdocipher/aegis/core/m/m;->getWindow(IJ)Lcom/vdocipher/aegis/player/VdoTimeLine$VdoWindow;

    move-result-object p1

    return-object p1
.end method

.method public getWindow(IJ)Lcom/vdocipher/aegis/player/VdoTimeLine$VdoWindow;
    .registers 22

    move-object/from16 v0, p0

    .line 1
    iget-object v1, v0, Lcom/vdocipher/aegis/core/m/m;->a:Landroidx/media3/common/Timeline;

    new-instance v2, Landroidx/media3/common/Timeline$Window;

    invoke-direct {v2}, Landroidx/media3/common/Timeline$Window;-><init>()V

    move/from16 v3, p1

    move-wide/from16 v4, p2

    invoke-virtual {v1, v3, v2, v4, v5}, Landroidx/media3/common/Timeline;->getWindow(ILandroidx/media3/common/Timeline$Window;J)Landroidx/media3/common/Timeline$Window;

    move-result-object v1

    .line 2
    new-instance v2, Lcom/vdocipher/aegis/player/VdoTimeLine$VdoWindow;

    invoke-direct {v2}, Lcom/vdocipher/aegis/player/VdoTimeLine$VdoWindow;-><init>()V

    .line 3
    iget-object v3, v1, Landroidx/media3/common/Timeline$Window;->uid:Ljava/lang/Object;

    iget-wide v4, v1, Landroidx/media3/common/Timeline$Window;->presentationStartTimeMs:J

    iget-wide v6, v1, Landroidx/media3/common/Timeline$Window;->windowStartTimeMs:J

    invoke-virtual {v1}, Landroidx/media3/common/Timeline$Window;->getCurrentUnixTimeMs()J

    move-result-wide v8

    iget-boolean v10, v1, Landroidx/media3/common/Timeline$Window;->isSeekable:Z

    iget-boolean v11, v1, Landroidx/media3/common/Timeline$Window;->isDynamic:Z

    .line 4
    invoke-virtual {v1}, Landroidx/media3/common/Timeline$Window;->getDefaultPositionMs()J

    move-result-wide v12

    invoke-virtual {v1}, Landroidx/media3/common/Timeline$Window;->getDurationMs()J

    move-result-wide v14

    invoke-virtual {v1}, Landroidx/media3/common/Timeline$Window;->getDurationUs()J

    move-result-wide v16

    .line 5
    invoke-virtual/range {v2 .. v17}, Lcom/vdocipher/aegis/player/VdoTimeLine$VdoWindow;->set(Ljava/lang/Object;JJJZZJJJ)Lcom/vdocipher/aegis/player/VdoTimeLine$VdoWindow;

    return-object v2
.end method

.method public getWindowCount()I
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/m;->a:Landroidx/media3/common/Timeline;

    invoke-virtual {v0}, Landroidx/media3/common/Timeline;->getWindowCount()I

    move-result v0

    return v0
.end method
