# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/m/t$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/m/t;

.field public final synthetic f$1:Lcom/vdocipher/aegis/core/m/y$a;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/m/t;Lcom/vdocipher/aegis/core/m/y$a;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/t$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/core/m/t;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/t$$ExternalSyntheticLambda1;->f$1:Lcom/vdocipher/aegis/core/m/y$a;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/t$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/core/m/t;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/t$$ExternalSyntheticLambda1;->f$1:Lcom/vdocipher/aegis/core/m/y$a;

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/m/t;->$r8$lambda$ezsSzI0MEqW8L9iEod6kw8JamUc(Lcom/vdocipher/aegis/core/m/t;Lcom/vdocipher/aegis/core/m/y$a;)V

    return-void
.end method
