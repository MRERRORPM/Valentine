# classes14.dex

.class public Lcom/vdocipher/aegis/core/m/u;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/media3/exoplayer/drm/MediaDrmCallback;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/core/m/u$d;,
        Lcom/vdocipher/aegis/core/m/u$c;,
        Lcom/vdocipher/aegis/core/m/u$a;,
        Lcom/vdocipher/aegis/core/m/u$b;
    }
.end annotation


# instance fields
.field private final a:Z

.field private final b:Z

.field private final c:Ljava/lang/String;

.field private final d:Ljava/util/ArrayList;

.field private final e:Ljava/lang/String;

.field private final f:Ljava/lang/String;

.field private final g:Ljava/lang/String;

.field private final h:Ljava/lang/String;

.field private final i:Landroid/content/Context;

.field private final j:Lcom/vdocipher/aegis/core/q/b;

.field private final k:Lcom/vdocipher/aegis/core/m/u$d;

.field private final l:Landroidx/media3/exoplayer/drm/MediaDrmCallback;

.field private m:Ljava/lang/String;

.field private final n:Ljava/lang/String;

.field private final o:Lcom/vdocipher/aegis/core/p/a;

.field private final p:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/q/b;Ljava/lang/String;Ljava/util/ArrayList;Landroidx/media3/exoplayer/drm/MediaDrmCallback;Lcom/vdocipher/aegis/core/m/u$d;Lcom/vdocipher/aegis/core/p/a;Ljava/lang/String;)V
    .registers 17

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/u;->m:Ljava/lang/String;

    if-eqz p4, :cond_17

    .line 23
    invoke-static {p9}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_f

    goto :goto_17

    .line 24
    :cond_f
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "invalid wrapped params"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 27
    :cond_17
    :goto_17
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/u;->i:Landroid/content/Context;

    .line 28
    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/u;->e:Ljava/lang/String;

    .line 29
    iput-boolean p3, p0, Lcom/vdocipher/aegis/core/m/u;->a:Z

    .line 30
    iput-object p9, p0, Lcom/vdocipher/aegis/core/m/u;->c:Ljava/lang/String;

    .line 31
    iput-object p10, p0, Lcom/vdocipher/aegis/core/m/u;->d:Ljava/util/ArrayList;

    .line 32
    iput-boolean p4, p0, Lcom/vdocipher/aegis/core/m/u;->b:Z

    .line 33
    iput-object p5, p0, Lcom/vdocipher/aegis/core/m/u;->f:Ljava/lang/String;

    .line 34
    iput-object p6, p0, Lcom/vdocipher/aegis/core/m/u;->h:Ljava/lang/String;

    .line 35
    iput-object p7, p0, Lcom/vdocipher/aegis/core/m/u;->g:Ljava/lang/String;

    .line 36
    iput-object p8, p0, Lcom/vdocipher/aegis/core/m/u;->j:Lcom/vdocipher/aegis/core/q/b;

    .line 37
    iput-object p11, p0, Lcom/vdocipher/aegis/core/m/u;->l:Landroidx/media3/exoplayer/drm/MediaDrmCallback;

    .line 38
    iput-object p12, p0, Lcom/vdocipher/aegis/core/m/u;->k:Lcom/vdocipher/aegis/core/m/u$d;

    .line 39
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/u;->n:Ljava/lang/String;

    .line 40
    iput-object p13, p0, Lcom/vdocipher/aegis/core/m/u;->o:Lcom/vdocipher/aegis/core/p/a;

    move-object/from16 p1, p14

    .line 41
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/u;->p:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/q/b;Ljava/lang/String;Ljava/util/ArrayList;Landroidx/media3/exoplayer/drm/MediaDrmCallback;Lcom/vdocipher/aegis/core/m/u$d;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/p/a;Ljava/lang/String;)V
    .registers 18

    .line 42
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 43
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/u;->m:Ljava/lang/String;

    if-eqz p4, :cond_17

    .line 90
    invoke-static {p9}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_f

    goto :goto_17

    .line 91
    :cond_f
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "invalid wrapped params"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 93
    :cond_17
    :goto_17
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/u;->i:Landroid/content/Context;

    .line 94
    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/u;->e:Ljava/lang/String;

    .line 95
    iput-boolean p3, p0, Lcom/vdocipher/aegis/core/m/u;->a:Z

    .line 96
    iput-object p9, p0, Lcom/vdocipher/aegis/core/m/u;->c:Ljava/lang/String;

    .line 97
    iput-object p10, p0, Lcom/vdocipher/aegis/core/m/u;->d:Ljava/util/ArrayList;

    .line 98
    iput-boolean p4, p0, Lcom/vdocipher/aegis/core/m/u;->b:Z

    .line 99
    iput-object p5, p0, Lcom/vdocipher/aegis/core/m/u;->f:Ljava/lang/String;

    .line 100
    iput-object p6, p0, Lcom/vdocipher/aegis/core/m/u;->h:Ljava/lang/String;

    .line 101
    iput-object p7, p0, Lcom/vdocipher/aegis/core/m/u;->g:Ljava/lang/String;

    .line 102
    iput-object p8, p0, Lcom/vdocipher/aegis/core/m/u;->j:Lcom/vdocipher/aegis/core/q/b;

    .line 103
    iput-object p11, p0, Lcom/vdocipher/aegis/core/m/u;->l:Landroidx/media3/exoplayer/drm/MediaDrmCallback;

    .line 104
    iput-object p12, p0, Lcom/vdocipher/aegis/core/m/u;->k:Lcom/vdocipher/aegis/core/m/u$d;

    .line 105
    iput-object p13, p0, Lcom/vdocipher/aegis/core/m/u;->m:Ljava/lang/String;

    .line 106
    iput-object p14, p0, Lcom/vdocipher/aegis/core/m/u;->n:Ljava/lang/String;

    move-object/from16 p1, p15

    .line 107
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/u;->o:Lcom/vdocipher/aegis/core/p/a;

    move-object/from16 p1, p16

    .line 108
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/u;->p:Ljava/lang/String;

    return-void
.end method

.method private static a(Ljava/lang/Throwable;)Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;
    .registers 8

    .line 42
    new-instance v0, Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;

    new-instance v1, Landroidx/media3/datasource/DataSpec$Builder;

    invoke-direct {v1}, Landroidx/media3/datasource/DataSpec$Builder;-><init>()V

    sget-object v2, Landroid/net/Uri;->EMPTY:Landroid/net/Uri;

    .line 43
    invoke-virtual {v1, v2}, Landroidx/media3/datasource/DataSpec$Builder;->setUri(Landroid/net/Uri;)Landroidx/media3/datasource/DataSpec$Builder;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/media3/datasource/DataSpec$Builder;->build()Landroidx/media3/datasource/DataSpec;

    move-result-object v1

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    const-wide/16 v4, 0x0

    move-object v6, p0

    invoke-direct/range {v0 .. v6}, Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;-><init>(Landroidx/media3/datasource/DataSpec;Landroid/net/Uri;Ljava/util/Map;JLjava/lang/Throwable;)V

    return-object v0
.end method


# virtual methods
.method protected a(Ljava/lang/String;Ljava/lang/String;)Lcom/vdocipher/aegis/core/i/a;
    .registers 20

    move-object/from16 v1, p0

    const-string v0, "message"

    const-string v2, "code"

    .line 1
    iget-object v3, v1, Lcom/vdocipher/aegis/core/m/u;->d:Ljava/util/ArrayList;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/util/List;)Ljava/util/List;

    move-result-object v3

    .line 3
    new-instance v5, Ljava/net/URL;

    move-object/from16 v4, p1

    invoke-direct {v5, v4}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 4
    invoke-virtual {v5}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_2e

    invoke-virtual {v5}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v4

    const-string v6, ".vdocipher.com"

    invoke-virtual {v4, v6}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_26

    goto :goto_2e

    .line 5
    :cond_26
    new-instance v0, Ljava/io/IOException;

    const-string v2, "Invalid key request"

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 8
    :cond_2e
    :goto_2e
    new-instance v4, Lcom/vdocipher/aegis/core/g/b;

    iget-object v6, v1, Lcom/vdocipher/aegis/core/m/u;->i:Landroid/content/Context;

    iget-object v7, v1, Lcom/vdocipher/aegis/core/m/u;->p:Ljava/lang/String;

    const/4 v10, 0x0

    invoke-direct {v4, v6, v3, v10, v7}, Lcom/vdocipher/aegis/core/g/b;-><init>(Landroid/content/Context;Ljava/util/List;Lcom/vdocipher/aegis/core/g/c;Ljava/lang/String;)V

    .line 9
    sget-object v6, Lcom/vdocipher/aegis/core/g/a;->b:Lcom/vdocipher/aegis/core/g/a;

    new-instance v3, Lokhttp3/Headers$Builder;

    invoke-direct {v3}, Lokhttp3/Headers$Builder;-><init>()V

    invoke-virtual {v3}, Lokhttp3/Headers$Builder;->build()Lokhttp3/Headers;

    move-result-object v7

    const/4 v9, 0x1

    move-object/from16 v8, p2

    invoke-virtual/range {v4 .. v9}, Lcom/vdocipher/aegis/core/g/b;->a(Ljava/net/URL;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/Headers;Ljava/lang/String;Z)Lcom/vdocipher/aegis/core/i/a;

    move-result-object v3

    .line 15
    invoke-virtual {v3}, Lcom/vdocipher/aegis/core/i/a;->f()Z

    move-result v4

    if-eqz v4, :cond_51

    return-object v3

    .line 17
    :cond_51
    invoke-virtual {v3}, Lcom/vdocipher/aegis/core/i/a;->b()I

    move-result v4

    const/16 v5, 0x193

    const/4 v6, -0x1

    if-ne v4, v5, :cond_bb

    invoke-virtual {v3}, Lcom/vdocipher/aegis/core/i/a;->c()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_bb

    .line 19
    :try_start_60
    new-instance v4, Lorg/json/JSONObject;

    invoke-virtual {v3}, Lcom/vdocipher/aegis/core/i/a;->c()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 20
    invoke-virtual {v4, v2}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_73

    invoke-virtual {v4, v2}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v6

    .line 21
    :cond_73
    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_7f

    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_7d
    .catch Lorg/json/JSONException; {:try_start_60 .. :try_end_7d} :catch_b3
    .catch Ljava/lang/NullPointerException; {:try_start_60 .. :try_end_7d} :catch_b0

    move-object v2, v0

    goto :goto_80

    :cond_7f
    move-object v2, v10

    .line 24
    :goto_80
    :try_start_80
    invoke-static {}, Lcom/vdocipher/aegis/core/z/b;->b()Lcom/vdocipher/aegis/core/z/b;

    move-result-object v0

    .line 25
    new-instance v4, Ljava/util/HashMap;

    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    if-eqz v0, :cond_92

    .line 27
    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/z/b;->a()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v4, v0}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    .line 29
    :cond_92
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v4, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b6

    .line 31
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v4, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/aegis/core/f/b;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/b;->a()Ljava/lang/String;

    move-result-object v0
    :try_end_aa
    .catch Lorg/json/JSONException; {:try_start_80 .. :try_end_aa} :catch_ae
    .catch Ljava/lang/NullPointerException; {:try_start_80 .. :try_end_aa} :catch_ac

    move-object v14, v0

    goto :goto_b7

    :catch_ac
    move-exception v0

    goto :goto_b5

    :catch_ae
    move-exception v0

    goto :goto_b5

    :catch_b0
    move-exception v0

    move-object v2, v10

    goto :goto_b5

    :catch_b3
    move-exception v0

    move-object v2, v10

    :goto_b5
    move-object v10, v0

    :cond_b6
    move-object v14, v2

    :goto_b7
    move v13, v6

    move-object/from16 v16, v10

    goto :goto_c3

    .line 38
    :cond_bb
    invoke-virtual {v3}, Lcom/vdocipher/aegis/core/i/a;->d()Ljava/lang/Exception;

    move-result-object v0

    move-object/from16 v16, v0

    move v13, v6

    move-object v14, v10

    .line 41
    :goto_c3
    new-instance v11, Lcom/vdocipher/aegis/core/m/u$c;

    sget-object v12, Lcom/vdocipher/aegis/core/m/u$a;->b:Lcom/vdocipher/aegis/core/m/u$a;

    invoke-virtual {v3}, Lcom/vdocipher/aegis/core/i/a;->b()I

    move-result v15

    invoke-direct/range {v11 .. v16}, Lcom/vdocipher/aegis/core/m/u$c;-><init>(Lcom/vdocipher/aegis/core/m/u$a;ILjava/lang/String;ILjava/lang/Throwable;)V

    throw v11
.end method

.method public executeKeyRequest(Ljava/util/UUID;Landroidx/media3/exoplayer/drm/ExoMediaDrm$KeyRequest;)[B
    .registers 14

    .line 1
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/u;->a:Z

    if-nez v0, :cond_e8

    .line 6
    :try_start_4
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/u;->b:Z

    if-nez v0, :cond_f

    .line 7
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/u;->l:Landroidx/media3/exoplayer/drm/MediaDrmCallback;

    invoke-interface {v0, p1, p2}, Landroidx/media3/exoplayer/drm/MediaDrmCallback;->executeKeyRequest(Ljava/util/UUID;Landroidx/media3/exoplayer/drm/ExoMediaDrm$KeyRequest;)[B

    move-result-object p1

    return-object p1

    .line 10
    :cond_f
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    .line 12
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/u;->j:Lcom/vdocipher/aegis/core/q/b;

    const/4 v1, 0x0

    if-eqz v0, :cond_38

    .line 13
    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/q/b;->b()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_38

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/u;->j:Lcom/vdocipher/aegis/core/q/b;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/q/b;->b()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_38

    .line 14
    new-instance v0, Lcom/vdocipher/aegis/core/q/d;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/u;->j:Lcom/vdocipher/aegis/core/q/b;

    invoke-direct {v0, v2}, Lcom/vdocipher/aegis/core/q/d;-><init>(Lcom/vdocipher/aegis/core/q/b;)V

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/q/d;->b()Lcom/vdocipher/aegis/core/q/a;

    move-result-object v0
    :try_end_36
    .catch Lcom/vdocipher/aegis/core/m/u$c; {:try_start_4 .. :try_end_36} :catch_e1
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_36} :catch_c6
    .catch Lorg/json/JSONException; {:try_start_4 .. :try_end_36} :catch_c3

    move-object v7, v0

    goto :goto_39

    :cond_38
    move-object v7, v1

    .line 19
    :goto_39
    :try_start_39
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/u;->j:Lcom/vdocipher/aegis/core/q/b;

    if-eqz v0, :cond_56

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/q/b;->d()Z

    move-result v0

    if-eqz v0, :cond_56

    .line 20
    new-instance v0, Lcom/vdocipher/aegis/core/o/a;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/u;->f:Ljava/lang/String;

    invoke-direct {v0, v2}, Lcom/vdocipher/aegis/core/o/a;-><init>(Ljava/lang/String;)V
    :try_end_4a
    .catchall {:try_start_39 .. :try_end_4a} :catchall_4c

    move-object v10, v0

    goto :goto_57

    :catchall_4c
    move-exception v0

    .line 22
    :try_start_4d
    const-string v2, "VdoDrmCallback"

    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_56
    move-object v10, v1

    .line 24
    :goto_57
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/u;->e:Ljava/lang/String;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/u;->f:Ljava/lang/String;

    iget-object v4, p0, Lcom/vdocipher/aegis/core/m/u;->h:Ljava/lang/String;

    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/u;->g:Ljava/lang/String;

    iget-object v6, p0, Lcom/vdocipher/aegis/core/m/u;->m:Ljava/lang/String;

    invoke-virtual {p2}, Landroidx/media3/exoplayer/drm/ExoMediaDrm$KeyRequest;->getData()[B

    move-result-object v8

    iget-object v9, p0, Lcom/vdocipher/aegis/core/m/u;->o:Lcom/vdocipher/aegis/core/p/a;

    invoke-static/range {v2 .. v10}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/q/a;[BLcom/vdocipher/aegis/core/p/a;Lcom/vdocipher/aegis/core/o/a;)Ljava/lang/String;

    move-result-object p2

    .line 25
    const-string/jumbo v0, "token"

    invoke-virtual {p1, v0, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 26
    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    .line 27
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/u;->h:Ljava/lang/String;

    invoke-static {p2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 30
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    .line 33
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/u;->c:Ljava/lang/String;

    invoke-virtual {p0, p2, p1}, Lcom/vdocipher/aegis/core/m/u;->a(Ljava/lang/String;Ljava/lang/String;)Lcom/vdocipher/aegis/core/i/a;

    move-result-object p1

    .line 35
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/i/a;->a()Ljava/lang/String;

    move-result-object p2

    .line 38
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/i/a;->e()Lokhttp3/Headers;

    move-result-object v0

    if-eqz v0, :cond_9a

    .line 39
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/i/a;->e()Lokhttp3/Headers;

    move-result-object p1

    const-string/jumbo v0, "vdo-version"

    invoke-virtual {p1, v0}, Lokhttp3/Headers;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :cond_9a
    move-object v9, v1

    .line 43
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    sub-long v7, v0, v2

    if-eqz v10, :cond_a7

    .line 47
    invoke-static {p2, v10}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Lcom/vdocipher/aegis/core/o/a;)Ljava/lang/String;

    move-result-object p2

    :cond_a7
    move-object v6, p2

    .line 50
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/u;->k:Lcom/vdocipher/aegis/core/m/u$d;

    if-eqz v2, :cond_b2

    .line 51
    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/u;->n:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-interface/range {v2 .. v9}, Lcom/vdocipher/aegis/core/m/u$d;->a(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V

    .line 55
    :cond_b2
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1, v6}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 56
    const-string p2, "license"

    invoke-virtual {p1, p2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x2

    .line 57
    invoke-static {p1, p2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p1
    :try_end_c2
    .catch Lcom/vdocipher/aegis/core/m/u$c; {:try_start_4d .. :try_end_c2} :catch_e1
    .catch Ljava/io/IOException; {:try_start_4d .. :try_end_c2} :catch_c6
    .catch Lorg/json/JSONException; {:try_start_4d .. :try_end_c2} :catch_c3

    return-object p1

    :catch_c3
    move-exception v0

    :goto_c4
    move-object p1, v0

    goto :goto_c8

    :catch_c6
    move-exception v0

    goto :goto_c4

    .line 63
    :goto_c8
    instance-of p2, p1, Ljavax/net/ssl/SSLHandshakeException;

    if-eqz p2, :cond_d5

    .line 64
    new-instance p2, Lcom/vdocipher/aegis/core/m/u$c;

    sget-object v0, Lcom/vdocipher/aegis/core/m/u$a;->b:Lcom/vdocipher/aegis/core/m/u$a;

    const/4 v1, 0x0

    invoke-direct {p2, v0, p1, v1}, Lcom/vdocipher/aegis/core/m/u$c;-><init>(Lcom/vdocipher/aegis/core/m/u$a;Ljava/lang/Throwable;Z)V

    goto :goto_dc

    .line 66
    :cond_d5
    new-instance p2, Lcom/vdocipher/aegis/core/m/u$c;

    sget-object v0, Lcom/vdocipher/aegis/core/m/u$a;->b:Lcom/vdocipher/aegis/core/m/u$a;

    invoke-direct {p2, v0, p1}, Lcom/vdocipher/aegis/core/m/u$c;-><init>(Lcom/vdocipher/aegis/core/m/u$a;Ljava/lang/Throwable;)V

    .line 68
    :goto_dc
    invoke-static {p2}, Lcom/vdocipher/aegis/core/m/u;->a(Ljava/lang/Throwable;)Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;

    move-result-object p1

    throw p1

    :catch_e1
    move-exception v0

    move-object p1, v0

    .line 69
    invoke-static {p1}, Lcom/vdocipher/aegis/core/m/u;->a(Ljava/lang/Throwable;)Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;

    move-result-object p1

    throw p1

    .line 70
    :cond_e8
    new-instance p1, Landroidx/media3/exoplayer/drm/KeysExpiredException;

    invoke-direct {p1}, Landroidx/media3/exoplayer/drm/KeysExpiredException;-><init>()V

    invoke-static {p1}, Lcom/vdocipher/aegis/core/m/u;->a(Ljava/lang/Throwable;)Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;

    move-result-object p1

    throw p1
.end method

.method public executeProvisionRequest(Ljava/util/UUID;Landroidx/media3/exoplayer/drm/ExoMediaDrm$ProvisionRequest;)[B
    .registers 10

    .line 1
    :try_start_0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/u;->l:Landroidx/media3/exoplayer/drm/MediaDrmCallback;

    invoke-interface {v0, p1, p2}, Landroidx/media3/exoplayer/drm/MediaDrmCallback;->executeProvisionRequest(Ljava/util/UUID;Landroidx/media3/exoplayer/drm/ExoMediaDrm$ProvisionRequest;)[B

    move-result-object p1
    :try_end_6
    .catch Landroidx/media3/exoplayer/drm/MediaDrmCallbackException; {:try_start_0 .. :try_end_6} :catch_15
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_6} :catch_7

    return-object p1

    :catch_7
    move-exception v0

    move-object p1, v0

    .line 11
    new-instance p2, Lcom/vdocipher/aegis/core/m/u$c;

    sget-object v0, Lcom/vdocipher/aegis/core/m/u$a;->a:Lcom/vdocipher/aegis/core/m/u$a;

    invoke-direct {p2, v0, p1}, Lcom/vdocipher/aegis/core/m/u$c;-><init>(Lcom/vdocipher/aegis/core/m/u$a;Ljava/lang/Throwable;)V

    .line 12
    invoke-static {p2}, Lcom/vdocipher/aegis/core/m/u;->a(Ljava/lang/Throwable;)Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;

    move-result-object p1

    throw p1

    :catch_15
    move-exception v0

    move-object p1, v0

    .line 13
    new-instance v6, Lcom/vdocipher/aegis/core/m/u$c;

    sget-object p2, Lcom/vdocipher/aegis/core/m/u$a;->a:Lcom/vdocipher/aegis/core/m/u$a;

    invoke-direct {v6, p2, p1}, Lcom/vdocipher/aegis/core/m/u$c;-><init>(Lcom/vdocipher/aegis/core/m/u$a;Ljava/lang/Throwable;)V

    .line 14
    new-instance v0, Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;

    iget-object v1, p1, Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;->dataSpec:Landroidx/media3/datasource/DataSpec;

    iget-object v2, p1, Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;->uriAfterRedirects:Landroid/net/Uri;

    iget-object v3, p1, Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;->responseHeaders:Ljava/util/Map;

    iget-wide v4, p1, Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;->bytesLoaded:J

    invoke-direct/range {v0 .. v6}, Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;-><init>(Landroidx/media3/datasource/DataSpec;Landroid/net/Uri;Ljava/util/Map;JLjava/lang/Throwable;)V

    throw v0
.end method
