# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/m/g;

.field public final synthetic f$1:Lcom/vdocipher/aegis/core/m/b0;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/m/g;Lcom/vdocipher/aegis/core/m/b0;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/core/m/g;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda1;->f$1:Lcom/vdocipher/aegis/core/m/b0;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/core/m/g;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda1;->f$1:Lcom/vdocipher/aegis/core/m/b0;

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/m/g;->$r8$lambda$y9XO5isIDm4C-urcx8HuA-SYCaA(Lcom/vdocipher/aegis/core/m/g;Lcom/vdocipher/aegis/core/m/b0;)V

    return-void
.end method
