# classes14.dex

.class final Lcom/vdocipher/aegis/core/m/k;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private A:F

.field private B:F

.field private C:I

.field private D:I

.field private E:I

.field private F:I

.field private G:Landroid/text/StaticLayout;

.field private H:I

.field private I:I

.field private J:I

.field private K:Landroid/graphics/Rect;

.field private final a:Landroid/graphics/RectF;

.field private final b:F

.field private final c:F

.field private final d:F

.field private final e:F

.field private final f:F

.field private final g:F

.field private final h:Landroid/text/TextPaint;

.field private final i:Landroid/graphics/Paint;

.field private j:Ljava/lang/CharSequence;

.field private k:Landroid/text/Layout$Alignment;

.field private l:Landroid/graphics/Bitmap;

.field private m:F

.field private n:I

.field private o:I

.field private p:F

.field private q:I

.field private r:F

.field private s:F

.field private t:Z

.field private u:Z

.field private v:I

.field private w:I

.field private x:I

.field private y:I

.field private z:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/k;->a:Landroid/graphics/RectF;

    const v0, 0x1010217

    const v1, 0x1010218

    .line 53
    filled-new-array {v0, v1}, [I

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    .line 54
    invoke-virtual {p1, v1, v0, v2, v2}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object v0

    .line 55
    invoke-virtual {v0, v2, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v1

    int-to-float v1, v1

    iput v1, p0, Lcom/vdocipher/aegis/core/m/k;->g:F

    const/high16 v1, 0x3f800000  # 1.0f

    const/4 v2, 0x1

    .line 56
    invoke-virtual {v0, v2, v1}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v1

    iput v1, p0, Lcom/vdocipher/aegis/core/m/k;->f:F

    .line 57
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    .line 59
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    .line 60
    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    .line 61
    iget p1, p1, Landroid/util/DisplayMetrics;->densityDpi:I

    int-to-float p1, p1

    const/high16 v0, 0x40000000  # 2.0f

    mul-float/2addr p1, v0

    const/high16 v0, 0x43200000  # 160.0f

    div-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    int-to-float p1, p1

    .line 62
    iput p1, p0, Lcom/vdocipher/aegis/core/m/k;->b:F

    .line 63
    iput p1, p0, Lcom/vdocipher/aegis/core/m/k;->c:F

    .line 64
    iput p1, p0, Lcom/vdocipher/aegis/core/m/k;->d:F

    .line 65
    iput p1, p0, Lcom/vdocipher/aegis/core/m/k;->e:F

    .line 67
    new-instance p1, Landroid/text/TextPaint;

    invoke-direct {p1}, Landroid/text/TextPaint;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    .line 68
    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 69
    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setSubpixelText(Z)V

    .line 71
    new-instance p1, Landroid/graphics/Paint;

    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/k;->i:Landroid/graphics/Paint;

    .line 72
    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 73
    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    return-void
.end method

.method private a()V
    .registers 9

    .line 71
    iget v0, p0, Lcom/vdocipher/aegis/core/m/k;->E:I

    iget v1, p0, Lcom/vdocipher/aegis/core/m/k;->C:I

    sub-int/2addr v0, v1

    .line 72
    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->F:I

    iget v3, p0, Lcom/vdocipher/aegis/core/m/k;->D:I

    sub-int/2addr v2, v3

    int-to-float v1, v1

    int-to-float v0, v0

    .line 73
    iget v4, p0, Lcom/vdocipher/aegis/core/m/k;->p:F

    mul-float/2addr v4, v0

    add-float/2addr v1, v4

    int-to-float v3, v3

    int-to-float v2, v2

    .line 74
    iget v4, p0, Lcom/vdocipher/aegis/core/m/k;->m:F

    mul-float/2addr v4, v2

    add-float/2addr v3, v4

    .line 75
    iget v4, p0, Lcom/vdocipher/aegis/core/m/k;->r:F

    mul-float/2addr v0, v4

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    .line 76
    iget v4, p0, Lcom/vdocipher/aegis/core/m/k;->s:F

    const v5, -0x800001

    cmpl-float v5, v4, v5

    if-eqz v5, :cond_2c

    mul-float/2addr v2, v4

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    goto :goto_41

    :cond_2c
    int-to-float v2, v0

    .line 77
    iget-object v4, p0, Lcom/vdocipher/aegis/core/m/k;->l:Landroid/graphics/Bitmap;

    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v4

    int-to-float v4, v4

    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/k;->l:Landroid/graphics/Bitmap;

    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v5

    int-to-float v5, v5

    div-float/2addr v4, v5

    mul-float/2addr v2, v4

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    .line 78
    :goto_41
    iget v4, p0, Lcom/vdocipher/aegis/core/m/k;->o:I

    const/high16 v5, 0x40000000  # 2.0f

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-ne v4, v7, :cond_4c

    int-to-float v4, v0

    :goto_4a
    sub-float/2addr v1, v4

    goto :goto_51

    :cond_4c
    if-ne v4, v6, :cond_51

    int-to-float v4, v0

    div-float/2addr v4, v5

    goto :goto_4a

    :cond_51
    :goto_51
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    .line 80
    iget v4, p0, Lcom/vdocipher/aegis/core/m/k;->q:I

    if-ne v4, v7, :cond_5c

    int-to-float v4, v2

    :goto_5a
    sub-float/2addr v3, v4

    goto :goto_61

    :cond_5c
    if-ne v4, v6, :cond_61

    int-to-float v4, v2

    div-float/2addr v4, v5

    goto :goto_5a

    :cond_61
    :goto_61
    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    .line 82
    new-instance v4, Landroid/graphics/Rect;

    add-int/2addr v0, v1

    add-int/2addr v2, v3

    invoke-direct {v4, v1, v3, v0, v2}, Landroid/graphics/Rect;-><init>(IIII)V

    iput-object v4, p0, Lcom/vdocipher/aegis/core/m/k;->K:Landroid/graphics/Rect;

    return-void
.end method

.method private a(Landroid/graphics/Canvas;)V
    .registers 5

    .line 86
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/k;->l:Landroid/graphics/Bitmap;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/k;->K:Landroid/graphics/Rect;

    const/4 v2, 0x0

    invoke-virtual {p1, v0, v2, v1, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    return-void
.end method

.method private a(Landroid/graphics/Canvas;Z)V
    .registers 3

    if-eqz p2, :cond_6

    .line 83
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/k;->b(Landroid/graphics/Canvas;)V

    return-void

    .line 85
    :cond_6
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/k;->a(Landroid/graphics/Canvas;)V

    return-void
.end method

.method private static a(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    .registers 2

    if-eq p0, p1, :cond_d

    if-eqz p0, :cond_b

    .line 87
    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_b

    goto :goto_d

    :cond_b
    const/4 p0, 0x0

    return p0

    :cond_d
    :goto_d
    const/4 p0, 0x1

    return p0
.end method

.method private b()V
    .registers 22

    move-object/from16 v0, p0

    .line 1
    iget v1, v0, Lcom/vdocipher/aegis/core/m/k;->E:I

    iget v2, v0, Lcom/vdocipher/aegis/core/m/k;->C:I

    sub-int/2addr v1, v2

    .line 2
    iget v2, v0, Lcom/vdocipher/aegis/core/m/k;->F:I

    iget v3, v0, Lcom/vdocipher/aegis/core/m/k;->D:I

    sub-int/2addr v2, v3

    .line 4
    iget-object v3, v0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    iget v4, v0, Lcom/vdocipher/aegis/core/m/k;->A:F

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 5
    iget v3, v0, Lcom/vdocipher/aegis/core/m/k;->A:F

    const/high16 v4, 0x3e000000  # 0.125f

    mul-float/2addr v3, v4

    const/high16 v4, 0x3f000000  # 0.5f

    add-float/2addr v3, v4

    float-to-int v3, v3

    mul-int/lit8 v4, v3, 0x2

    sub-int v5, v1, v4

    .line 8
    iget v6, v0, Lcom/vdocipher/aegis/core/m/k;->r:F

    const v7, -0x800001

    cmpl-float v8, v6, v7

    if-eqz v8, :cond_2c

    int-to-float v5, v5

    mul-float/2addr v5, v6

    float-to-int v5, v5

    :cond_2c
    move v11, v5

    const-string v5, "SP"

    if-gtz v11, :cond_37

    .line 13
    const-string v1, "insufficient space"

    invoke-static {v5, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 19
    :cond_37
    iget-boolean v6, v0, Lcom/vdocipher/aegis/core/m/k;->u:Z

    const/4 v8, 0x0

    if-eqz v6, :cond_43

    iget-boolean v6, v0, Lcom/vdocipher/aegis/core/m/k;->t:Z

    if-eqz v6, :cond_43

    .line 20
    iget-object v6, v0, Lcom/vdocipher/aegis/core/m/k;->j:Ljava/lang/CharSequence;

    goto :goto_4d

    .line 21
    :cond_43
    iget-boolean v6, v0, Lcom/vdocipher/aegis/core/m/k;->t:Z

    if-nez v6, :cond_4f

    .line 22
    iget-object v6, v0, Lcom/vdocipher/aegis/core/m/k;->j:Ljava/lang/CharSequence;

    invoke-interface {v6}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v6

    :cond_4d
    :goto_4d
    move-object v9, v6

    goto :goto_82

    .line 24
    :cond_4f
    new-instance v6, Landroid/text/SpannableStringBuilder;

    iget-object v9, v0, Lcom/vdocipher/aegis/core/m/k;->j:Ljava/lang/CharSequence;

    invoke-direct {v6, v9}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    .line 25
    invoke-virtual {v6}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v9

    .line 26
    const-class v10, Landroid/text/style/AbsoluteSizeSpan;

    invoke-virtual {v6, v8, v9, v10}, Landroid/text/SpannableStringBuilder;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object v10

    check-cast v10, [Landroid/text/style/AbsoluteSizeSpan;

    .line 27
    const-class v12, Landroid/text/style/RelativeSizeSpan;

    invoke-virtual {v6, v8, v9, v12}, Landroid/text/SpannableStringBuilder;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object v9

    check-cast v9, [Landroid/text/style/RelativeSizeSpan;

    .line 28
    array-length v12, v10

    move v13, v8

    :goto_6c
    if-ge v13, v12, :cond_76

    aget-object v14, v10, v13

    .line 29
    invoke-virtual {v6, v14}, Landroid/text/SpannableStringBuilder;->removeSpan(Ljava/lang/Object;)V

    add-int/lit8 v13, v13, 0x1

    goto :goto_6c

    .line 31
    :cond_76
    array-length v10, v9

    move v12, v8

    :goto_78
    if-ge v12, v10, :cond_4d

    aget-object v13, v9, v12

    .line 32
    invoke-virtual {v6, v13}, Landroid/text/SpannableStringBuilder;->removeSpan(Ljava/lang/Object;)V

    add-int/lit8 v12, v12, 0x1

    goto :goto_78

    .line 37
    :goto_82
    iget-object v6, v0, Lcom/vdocipher/aegis/core/m/k;->k:Landroid/text/Layout$Alignment;

    if-nez v6, :cond_88

    sget-object v6, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    :cond_88
    move-object/from16 v17, v6

    move v6, v8

    .line 38
    new-instance v8, Landroid/text/StaticLayout;

    iget-object v10, v0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    iget v13, v0, Lcom/vdocipher/aegis/core/m/k;->f:F

    iget v14, v0, Lcom/vdocipher/aegis/core/m/k;->g:F

    const/4 v15, 0x1

    move-object/from16 v12, v17

    invoke-direct/range {v8 .. v15}, Landroid/text/StaticLayout;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;ILandroid/text/Layout$Alignment;FFZ)V

    iput-object v8, v0, Lcom/vdocipher/aegis/core/m/k;->G:Landroid/text/StaticLayout;

    .line 40
    invoke-virtual {v8}, Landroid/text/Layout;->getHeight()I

    move-result v8

    .line 42
    iget-object v10, v0, Lcom/vdocipher/aegis/core/m/k;->G:Landroid/text/StaticLayout;

    invoke-virtual {v10}, Landroid/text/StaticLayout;->getLineCount()I

    move-result v10

    move v12, v6

    move v13, v12

    :goto_a7
    if-ge v12, v10, :cond_bc

    .line 44
    iget-object v14, v0, Lcom/vdocipher/aegis/core/m/k;->G:Landroid/text/StaticLayout;

    invoke-virtual {v14, v12}, Landroid/text/Layout;->getLineWidth(I)F

    move-result v14

    float-to-double v14, v14

    invoke-static {v14, v15}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v14

    double-to-int v14, v14

    invoke-static {v14, v13}, Ljava/lang/Math;->max(II)I

    move-result v13

    add-int/lit8 v12, v12, 0x1

    goto :goto_a7

    .line 46
    :cond_bc
    iget v10, v0, Lcom/vdocipher/aegis/core/m/k;->r:F

    cmpl-float v10, v10, v7

    if-eqz v10, :cond_c5

    if-ge v13, v11, :cond_c5

    goto :goto_c6

    :cond_c5
    move v11, v13

    :goto_c6
    add-int/2addr v11, v4

    .line 53
    iget v4, v0, Lcom/vdocipher/aegis/core/m/k;->p:F

    cmpl-float v10, v4, v7

    const/4 v12, 0x1

    const/4 v13, 0x2

    if-eqz v10, :cond_f0

    int-to-float v1, v1

    mul-float/2addr v1, v4

    .line 54
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    iget v4, v0, Lcom/vdocipher/aegis/core/m/k;->C:I

    add-int/2addr v1, v4

    .line 55
    iget v10, v0, Lcom/vdocipher/aegis/core/m/k;->q:I

    if-ne v10, v13, :cond_de

    sub-int/2addr v1, v11

    goto :goto_e4

    :cond_de
    if-ne v10, v12, :cond_e4

    mul-int/lit8 v1, v1, 0x2

    sub-int/2addr v1, v11

    .line 56
    div-int/2addr v1, v13

    .line 58
    :cond_e4
    :goto_e4
    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    move-result v1

    add-int/2addr v11, v1

    .line 59
    iget v4, v0, Lcom/vdocipher/aegis/core/m/k;->E:I

    invoke-static {v11, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    goto :goto_f4

    :cond_f0
    sub-int/2addr v1, v11

    .line 61
    div-int/2addr v1, v13

    add-int v4, v1, v11

    :goto_f4
    sub-int v16, v4, v1

    if-gtz v16, :cond_fe

    .line 68
    const-string v1, "invalid horizontal positioning"

    invoke-static {v5, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 73
    :cond_fe
    iget v4, v0, Lcom/vdocipher/aegis/core/m/k;->m:F

    cmpl-float v5, v4, v7

    if-eqz v5, :cond_156

    .line 75
    iget v5, v0, Lcom/vdocipher/aegis/core/m/k;->n:I

    if-nez v5, :cond_112

    int-to-float v2, v2

    mul-float/2addr v2, v4

    .line 76
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    iget v4, v0, Lcom/vdocipher/aegis/core/m/k;->D:I

    :goto_110
    add-int/2addr v2, v4

    goto :goto_13b

    .line 79
    :cond_112
    iget-object v2, v0, Lcom/vdocipher/aegis/core/m/k;->G:Landroid/text/StaticLayout;

    invoke-virtual {v2, v6}, Landroid/text/Layout;->getLineBottom(I)I

    move-result v2

    iget-object v4, v0, Lcom/vdocipher/aegis/core/m/k;->G:Landroid/text/StaticLayout;

    invoke-virtual {v4, v6}, Landroid/text/StaticLayout;->getLineTop(I)I

    move-result v4

    sub-int/2addr v2, v4

    .line 80
    iget v4, v0, Lcom/vdocipher/aegis/core/m/k;->m:F

    const/4 v5, 0x0

    cmpl-float v5, v4, v5

    if-ltz v5, :cond_12f

    int-to-float v2, v2

    mul-float/2addr v4, v2

    .line 81
    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v2

    iget v4, v0, Lcom/vdocipher/aegis/core/m/k;->D:I

    goto :goto_110

    :cond_12f
    const/high16 v5, 0x3f800000  # 1.0f

    add-float/2addr v4, v5

    int-to-float v2, v2

    mul-float/2addr v4, v2

    .line 83
    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v2

    iget v4, v0, Lcom/vdocipher/aegis/core/m/k;->F:I

    goto :goto_110

    .line 86
    :goto_13b
    iget v4, v0, Lcom/vdocipher/aegis/core/m/k;->o:I

    if-ne v4, v13, :cond_141

    sub-int/2addr v2, v8

    goto :goto_147

    :cond_141
    if-ne v4, v12, :cond_147

    mul-int/lit8 v2, v2, 0x2

    sub-int/2addr v2, v8

    .line 87
    div-int/2addr v2, v13

    :cond_147
    :goto_147
    add-int v4, v2, v8

    .line 89
    iget v5, v0, Lcom/vdocipher/aegis/core/m/k;->F:I

    if-le v4, v5, :cond_150

    sub-int v2, v5, v8

    goto :goto_160

    .line 91
    :cond_150
    iget v4, v0, Lcom/vdocipher/aegis/core/m/k;->D:I

    if-ge v2, v4, :cond_160

    move v2, v4

    goto :goto_160

    .line 95
    :cond_156
    iget v4, v0, Lcom/vdocipher/aegis/core/m/k;->F:I

    sub-int/2addr v4, v8

    int-to-float v2, v2

    iget v5, v0, Lcom/vdocipher/aegis/core/m/k;->B:F

    mul-float/2addr v2, v5

    float-to-int v2, v2

    sub-int v2, v4, v2

    .line 99
    :cond_160
    :goto_160
    new-instance v13, Landroid/text/StaticLayout;

    iget-object v15, v0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    iget v4, v0, Lcom/vdocipher/aegis/core/m/k;->f:F

    iget v5, v0, Lcom/vdocipher/aegis/core/m/k;->g:F

    const/16 v20, 0x1

    move/from16 v18, v4

    move/from16 v19, v5

    move-object v14, v9

    invoke-direct/range {v13 .. v20}, Landroid/text/StaticLayout;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;ILandroid/text/Layout$Alignment;FFZ)V

    iput-object v13, v0, Lcom/vdocipher/aegis/core/m/k;->G:Landroid/text/StaticLayout;

    .line 101
    iput v1, v0, Lcom/vdocipher/aegis/core/m/k;->H:I

    .line 102
    iput v2, v0, Lcom/vdocipher/aegis/core/m/k;->I:I

    .line 103
    iput v3, v0, Lcom/vdocipher/aegis/core/m/k;->J:I

    return-void
.end method

.method private b(Landroid/graphics/Canvas;)V
    .registers 11

    .line 104
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/k;->G:Landroid/text/StaticLayout;

    if-nez v0, :cond_5

    return-void

    .line 110
    :cond_5
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v1

    .line 111
    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->H:I

    int-to-float v2, v2

    iget v3, p0, Lcom/vdocipher/aegis/core/m/k;->I:I

    int-to-float v3, v3

    invoke-virtual {p1, v2, v3}, Landroid/graphics/Canvas;->translate(FF)V

    .line 113
    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->x:I

    invoke-static {v2}, Landroid/graphics/Color;->alpha(I)I

    move-result v2

    if-lez v2, :cond_3c

    .line 114
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/k;->i:Landroid/graphics/Paint;

    iget v3, p0, Lcom/vdocipher/aegis/core/m/k;->x:I

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 115
    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->J:I

    neg-int v2, v2

    int-to-float v4, v2

    invoke-virtual {v0}, Landroid/text/Layout;->getWidth()I

    move-result v2

    int-to-float v2, v2

    iget v3, p0, Lcom/vdocipher/aegis/core/m/k;->J:I

    int-to-float v3, v3

    add-float v6, v2, v3

    invoke-virtual {v0}, Landroid/text/Layout;->getHeight()I

    move-result v2

    int-to-float v7, v2

    iget-object v8, p0, Lcom/vdocipher/aegis/core/m/k;->i:Landroid/graphics/Paint;

    const/4 v5, 0x0

    move-object v3, p1

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    goto :goto_3d

    :cond_3c
    move-object v3, p1

    .line 119
    :goto_3d
    iget p1, p0, Lcom/vdocipher/aegis/core/m/k;->w:I

    invoke-static {p1}, Landroid/graphics/Color;->alpha(I)I

    move-result p1

    const/4 v2, 0x0

    if-lez p1, :cond_8b

    .line 120
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/k;->i:Landroid/graphics/Paint;

    iget v4, p0, Lcom/vdocipher/aegis/core/m/k;->w:I

    invoke-virtual {p1, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 121
    invoke-virtual {v0, v2}, Landroid/text/StaticLayout;->getLineTop(I)I

    move-result p1

    int-to-float p1, p1

    .line 122
    invoke-virtual {v0}, Landroid/text/StaticLayout;->getLineCount()I

    move-result v4

    move v5, v2

    :goto_57
    if-ge v5, v4, :cond_8b

    .line 124
    iget-object v6, p0, Lcom/vdocipher/aegis/core/m/k;->a:Landroid/graphics/RectF;

    invoke-virtual {v0, v5}, Landroid/text/Layout;->getLineLeft(I)F

    move-result v7

    iget v8, p0, Lcom/vdocipher/aegis/core/m/k;->J:I

    int-to-float v8, v8

    sub-float/2addr v7, v8

    iput v7, v6, Landroid/graphics/RectF;->left:F

    .line 125
    iget-object v6, p0, Lcom/vdocipher/aegis/core/m/k;->a:Landroid/graphics/RectF;

    invoke-virtual {v0, v5}, Landroid/text/Layout;->getLineRight(I)F

    move-result v7

    iget v8, p0, Lcom/vdocipher/aegis/core/m/k;->J:I

    int-to-float v8, v8

    add-float/2addr v7, v8

    iput v7, v6, Landroid/graphics/RectF;->right:F

    .line 126
    iget-object v6, p0, Lcom/vdocipher/aegis/core/m/k;->a:Landroid/graphics/RectF;

    iput p1, v6, Landroid/graphics/RectF;->top:F

    .line 127
    invoke-virtual {v0, v5}, Landroid/text/Layout;->getLineBottom(I)I

    move-result p1

    int-to-float p1, p1

    iput p1, v6, Landroid/graphics/RectF;->bottom:F

    .line 128
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/k;->a:Landroid/graphics/RectF;

    iget v6, p1, Landroid/graphics/RectF;->bottom:F

    .line 129
    iget v7, p0, Lcom/vdocipher/aegis/core/m/k;->b:F

    iget-object v8, p0, Lcom/vdocipher/aegis/core/m/k;->i:Landroid/graphics/Paint;

    invoke-virtual {v3, p1, v7, v7, v8}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    add-int/lit8 v5, v5, 0x1

    move p1, v6

    goto :goto_57

    .line 133
    :cond_8b
    iget p1, p0, Lcom/vdocipher/aegis/core/m/k;->z:I

    const/4 v4, 0x1

    if-ne p1, v4, :cond_b0

    .line 134
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    sget-object v4, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {p1, v4}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 135
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    iget v4, p0, Lcom/vdocipher/aegis/core/m/k;->c:F

    invoke-virtual {p1, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 136
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    iget v4, p0, Lcom/vdocipher/aegis/core/m/k;->y:I

    invoke-virtual {p1, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 137
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    sget-object v4, Landroid/graphics/Paint$Style;->FILL_AND_STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 138
    invoke-virtual {v0, v3}, Landroid/text/Layout;->draw(Landroid/graphics/Canvas;)V

    goto :goto_f9

    :cond_b0
    const/4 v5, 0x2

    if-ne p1, v5, :cond_bf

    .line 140
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    iget v4, p0, Lcom/vdocipher/aegis/core/m/k;->d:F

    iget v5, p0, Lcom/vdocipher/aegis/core/m/k;->e:F

    iget v6, p0, Lcom/vdocipher/aegis/core/m/k;->y:I

    invoke-virtual {p1, v4, v5, v5, v6}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    goto :goto_f9

    :cond_bf
    const/4 v5, 0x3

    if-eq p1, v5, :cond_c5

    const/4 v6, 0x4

    if-ne p1, v6, :cond_f9

    :cond_c5
    if-ne p1, v5, :cond_c8

    goto :goto_c9

    :cond_c8
    move v4, v2

    :goto_c9
    const/4 p1, -0x1

    if-eqz v4, :cond_ce

    move v5, p1

    goto :goto_d0

    .line 144
    :cond_ce
    iget v5, p0, Lcom/vdocipher/aegis/core/m/k;->y:I

    :goto_d0
    if-eqz v4, :cond_d4

    .line 145
    iget p1, p0, Lcom/vdocipher/aegis/core/m/k;->y:I

    .line 146
    :cond_d4
    iget v4, p0, Lcom/vdocipher/aegis/core/m/k;->d:F

    const/high16 v6, 0x40000000  # 2.0f

    div-float/2addr v4, v6

    .line 147
    iget-object v6, p0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    iget v7, p0, Lcom/vdocipher/aegis/core/m/k;->v:I

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setColor(I)V

    .line 148
    iget-object v6, p0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    sget-object v7, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 149
    iget-object v6, p0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    iget v7, p0, Lcom/vdocipher/aegis/core/m/k;->d:F

    neg-float v8, v4

    invoke-virtual {v6, v7, v8, v8, v5}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    .line 150
    invoke-virtual {v0, v3}, Landroid/text/Layout;->draw(Landroid/graphics/Canvas;)V

    .line 151
    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    iget v6, p0, Lcom/vdocipher/aegis/core/m/k;->d:F

    invoke-virtual {v5, v6, v4, v4, p1}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    .line 154
    :cond_f9
    :goto_f9
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    iget v4, p0, Lcom/vdocipher/aegis/core/m/k;->v:I

    invoke-virtual {p1, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 155
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 156
    invoke-virtual {v0, v3}, Landroid/text/Layout;->draw(Landroid/graphics/Canvas;)V

    .line 157
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, v0, v0, v2}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    .line 159
    invoke-virtual {v3, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    return-void
.end method


# virtual methods
.method public a(Landroidx/media3/common/text/Cue;ZZLandroidx/media3/ui/CaptionStyleCompat;FFLandroid/graphics/Canvas;IIII)V
    .registers 16

    .line 1
    iget-object v0, p1, Landroidx/media3/common/text/Cue;->bitmap:Landroid/graphics/Bitmap;

    if-nez v0, :cond_6

    const/4 v0, 0x1

    goto :goto_7

    :cond_6
    const/4 v0, 0x0

    :goto_7
    if-eqz v0, :cond_1e

    .line 4
    iget-object v1, p1, Landroidx/media3/common/text/Cue;->text:Ljava/lang/CharSequence;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_12

    return-void

    .line 8
    :cond_12
    iget-boolean v1, p1, Landroidx/media3/common/text/Cue;->windowColorSet:Z

    if-eqz v1, :cond_1b

    if-eqz p2, :cond_1b

    .line 9
    iget v1, p1, Landroidx/media3/common/text/Cue;->windowColor:I

    goto :goto_20

    :cond_1b
    iget v1, p4, Landroidx/media3/ui/CaptionStyleCompat;->windowColor:I

    goto :goto_20

    :cond_1e
    const/high16 v1, -0x1000000

    .line 11
    :goto_20
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/k;->j:Ljava/lang/CharSequence;

    iget-object v3, p1, Landroidx/media3/common/text/Cue;->text:Ljava/lang/CharSequence;

    invoke-static {v2, v3}, Lcom/vdocipher/aegis/core/m/k;->a(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_d6

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/k;->k:Landroid/text/Layout$Alignment;

    iget-object v3, p1, Landroidx/media3/common/text/Cue;->textAlignment:Landroid/text/Layout$Alignment;

    .line 12
    invoke-static {v2, v3}, Landroidx/media3/common/util/Util;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_d6

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/k;->l:Landroid/graphics/Bitmap;

    iget-object v3, p1, Landroidx/media3/common/text/Cue;->bitmap:Landroid/graphics/Bitmap;

    if-ne v2, v3, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->m:F

    iget v3, p1, Landroidx/media3/common/text/Cue;->line:F

    cmpl-float v2, v2, v3

    if-nez v2, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->n:I

    iget v3, p1, Landroidx/media3/common/text/Cue;->lineType:I

    if-ne v2, v3, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->o:I

    .line 16
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iget v3, p1, Landroidx/media3/common/text/Cue;->lineAnchor:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Landroidx/media3/common/util/Util;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->p:F

    iget v3, p1, Landroidx/media3/common/text/Cue;->position:F

    cmpl-float v2, v2, v3

    if-nez v2, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->q:I

    .line 18
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iget v3, p1, Landroidx/media3/common/text/Cue;->positionAnchor:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Landroidx/media3/common/util/Util;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->r:F

    iget v3, p1, Landroidx/media3/common/text/Cue;->size:F

    cmpl-float v2, v2, v3

    if-nez v2, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->s:F

    iget v3, p1, Landroidx/media3/common/text/Cue;->bitmapHeight:F

    cmpl-float v2, v2, v3

    if-nez v2, :cond_d6

    iget-boolean v2, p0, Lcom/vdocipher/aegis/core/m/k;->t:Z

    if-ne v2, p2, :cond_d6

    iget-boolean v2, p0, Lcom/vdocipher/aegis/core/m/k;->u:Z

    if-ne v2, p3, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->v:I

    iget v3, p4, Landroidx/media3/ui/CaptionStyleCompat;->foregroundColor:I

    if-ne v2, v3, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->w:I

    iget v3, p4, Landroidx/media3/ui/CaptionStyleCompat;->backgroundColor:I

    if-ne v2, v3, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->x:I

    if-ne v2, v1, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->z:I

    iget v3, p4, Landroidx/media3/ui/CaptionStyleCompat;->edgeType:I

    if-ne v2, v3, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->y:I

    iget v3, p4, Landroidx/media3/ui/CaptionStyleCompat;->edgeColor:I

    if-ne v2, v3, :cond_d6

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    .line 28
    invoke-virtual {v2}, Landroid/graphics/Paint;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v2

    iget-object v3, p4, Landroidx/media3/ui/CaptionStyleCompat;->typeface:Landroid/graphics/Typeface;

    invoke-static {v2, v3}, Landroidx/media3/common/util/Util;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->A:F

    cmpl-float v2, v2, p5

    if-nez v2, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->B:F

    cmpl-float v2, v2, p6

    if-nez v2, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->C:I

    if-ne v2, p8, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->D:I

    if-ne v2, p9, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->E:I

    if-ne v2, p10, :cond_d6

    iget v2, p0, Lcom/vdocipher/aegis/core/m/k;->F:I

    if-ne v2, p11, :cond_d6

    .line 36
    invoke-direct {p0, p7, v0}, Lcom/vdocipher/aegis/core/m/k;->a(Landroid/graphics/Canvas;Z)V

    return-void

    .line 40
    :cond_d6
    iget-object v2, p1, Landroidx/media3/common/text/Cue;->text:Ljava/lang/CharSequence;

    iput-object v2, p0, Lcom/vdocipher/aegis/core/m/k;->j:Ljava/lang/CharSequence;

    .line 41
    iget-object v2, p1, Landroidx/media3/common/text/Cue;->textAlignment:Landroid/text/Layout$Alignment;

    iput-object v2, p0, Lcom/vdocipher/aegis/core/m/k;->k:Landroid/text/Layout$Alignment;

    .line 42
    iget-object v2, p1, Landroidx/media3/common/text/Cue;->bitmap:Landroid/graphics/Bitmap;

    iput-object v2, p0, Lcom/vdocipher/aegis/core/m/k;->l:Landroid/graphics/Bitmap;

    .line 43
    iget v2, p1, Landroidx/media3/common/text/Cue;->line:F

    iput v2, p0, Lcom/vdocipher/aegis/core/m/k;->m:F

    .line 44
    iget v2, p1, Landroidx/media3/common/text/Cue;->lineType:I

    iput v2, p0, Lcom/vdocipher/aegis/core/m/k;->n:I

    .line 45
    iget v2, p1, Landroidx/media3/common/text/Cue;->lineAnchor:I

    iput v2, p0, Lcom/vdocipher/aegis/core/m/k;->o:I

    .line 46
    iget v2, p1, Landroidx/media3/common/text/Cue;->position:F

    iput v2, p0, Lcom/vdocipher/aegis/core/m/k;->p:F

    .line 47
    iget v2, p1, Landroidx/media3/common/text/Cue;->positionAnchor:I

    iput v2, p0, Lcom/vdocipher/aegis/core/m/k;->q:I

    .line 48
    iget v2, p1, Landroidx/media3/common/text/Cue;->size:F

    iput v2, p0, Lcom/vdocipher/aegis/core/m/k;->r:F

    .line 49
    iget p1, p1, Landroidx/media3/common/text/Cue;->bitmapHeight:F

    iput p1, p0, Lcom/vdocipher/aegis/core/m/k;->s:F

    .line 50
    iput-boolean p2, p0, Lcom/vdocipher/aegis/core/m/k;->t:Z

    .line 51
    iput-boolean p3, p0, Lcom/vdocipher/aegis/core/m/k;->u:Z

    .line 52
    iget p1, p4, Landroidx/media3/ui/CaptionStyleCompat;->foregroundColor:I

    iput p1, p0, Lcom/vdocipher/aegis/core/m/k;->v:I

    .line 53
    iget p1, p4, Landroidx/media3/ui/CaptionStyleCompat;->backgroundColor:I

    iput p1, p0, Lcom/vdocipher/aegis/core/m/k;->w:I

    .line 54
    iput v1, p0, Lcom/vdocipher/aegis/core/m/k;->x:I

    .line 55
    iget p1, p4, Landroidx/media3/ui/CaptionStyleCompat;->edgeType:I

    iput p1, p0, Lcom/vdocipher/aegis/core/m/k;->z:I

    .line 56
    iget p1, p4, Landroidx/media3/ui/CaptionStyleCompat;->edgeColor:I

    iput p1, p0, Lcom/vdocipher/aegis/core/m/k;->y:I

    .line 57
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/k;->h:Landroid/text/TextPaint;

    iget-object p2, p4, Landroidx/media3/ui/CaptionStyleCompat;->typeface:Landroid/graphics/Typeface;

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 58
    iput p5, p0, Lcom/vdocipher/aegis/core/m/k;->A:F

    .line 59
    iput p6, p0, Lcom/vdocipher/aegis/core/m/k;->B:F

    .line 60
    iput p8, p0, Lcom/vdocipher/aegis/core/m/k;->C:I

    .line 61
    iput p9, p0, Lcom/vdocipher/aegis/core/m/k;->D:I

    .line 62
    iput p10, p0, Lcom/vdocipher/aegis/core/m/k;->E:I

    .line 63
    iput p11, p0, Lcom/vdocipher/aegis/core/m/k;->F:I

    if-eqz v0, :cond_12d

    .line 66
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/k;->b()V

    goto :goto_130

    .line 68
    :cond_12d
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/k;->a()V

    .line 70
    :goto_130
    invoke-direct {p0, p7, v0}, Lcom/vdocipher/aegis/core/m/k;->a(Landroid/graphics/Canvas;Z)V

    return-void
.end method
