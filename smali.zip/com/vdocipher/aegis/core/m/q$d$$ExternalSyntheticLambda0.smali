# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/m/q$d$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/m/q$d;

.field public final synthetic f$1:Landroidx/media3/common/PlaybackParameters;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/m/q$d;Landroidx/media3/common/PlaybackParameters;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q$d$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/m/q$d;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/q$d$$ExternalSyntheticLambda0;->f$1:Landroidx/media3/common/PlaybackParameters;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$d$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/m/q$d;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q$d$$ExternalSyntheticLambda0;->f$1:Landroidx/media3/common/PlaybackParameters;

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/m/q$d;->$r8$lambda$O-V0QHenJ9pOCQw21z9ZUKvgK78(Lcom/vdocipher/aegis/core/m/q$d;Landroidx/media3/common/PlaybackParameters;)V

    return-void
.end method
