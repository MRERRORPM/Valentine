# classes14.dex

.class Lcom/vdocipher/aegis/core/m/q$a;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/m/q;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/m/q;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q$a;->a:Lcom/vdocipher/aegis/core/m/q;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 8

    if-eqz p2, :cond_3d

    .line 1
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    .line 3
    const-string v0, "action_vdo_tc_tp"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_29

    .line 5
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q$a;->a:Lcom/vdocipher/aegis/core/m/q;

    const-string/jumbo v0, "vdo_total_played"

    const-wide/16 v1, 0x0

    invoke-virtual {p2, v0, v1, v2}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v3

    invoke-static {p1, v3, v4}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/core/m/q;J)J

    .line 6
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q$a;->a:Lcom/vdocipher/aegis/core/m/q;

    const-string/jumbo v0, "vdo_total_covered"

    invoke-virtual {p2, v0, v1, v2}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    invoke-static {p1, v0, v1}, Lcom/vdocipher/aegis/core/m/q;->b(Lcom/vdocipher/aegis/core/m/q;J)J

    return-void

    .line 8
    :cond_29
    const-string v0, "enf_blocked_action"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_3d

    .line 10
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q$a;->a:Lcom/vdocipher/aegis/core/m/q;

    const-string v0, "enf_blocked"

    const/4 v1, 0x0

    invoke-virtual {p2, v0, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p2

    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/m/q;->c(Lcom/vdocipher/aegis/core/m/q;Z)Z

    :cond_3d
    return-void
.end method
