# classes14.dex

.class final enum Lcom/vdocipher/aegis/core/m/g$c;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x401a
    name = "c"
.end annotation


# static fields
.field public static final enum a:Lcom/vdocipher/aegis/core/m/g$c;

.field public static final enum b:Lcom/vdocipher/aegis/core/m/g$c;

.field public static final enum c:Lcom/vdocipher/aegis/core/m/g$c;

.field public static final enum d:Lcom/vdocipher/aegis/core/m/g$c;

.field private static final synthetic e:[Lcom/vdocipher/aegis/core/m/g$c;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lcom/vdocipher/aegis/core/m/g$c;

    const-string v1, "CREATED"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/vdocipher/aegis/core/m/g$c;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/vdocipher/aegis/core/m/g$c;->a:Lcom/vdocipher/aegis/core/m/g$c;

    .line 2
    new-instance v0, Lcom/vdocipher/aegis/core/m/g$c;

    const-string v1, "UNPACKED"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lcom/vdocipher/aegis/core/m/g$c;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/vdocipher/aegis/core/m/g$c;->b:Lcom/vdocipher/aegis/core/m/g$c;

    .line 3
    new-instance v0, Lcom/vdocipher/aegis/core/m/g$c;

    const-string v1, "PACKED"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lcom/vdocipher/aegis/core/m/g$c;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/vdocipher/aegis/core/m/g$c;->c:Lcom/vdocipher/aegis/core/m/g$c;

    .line 4
    new-instance v0, Lcom/vdocipher/aegis/core/m/g$c;

    const-string v1, "RELEASED"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Lcom/vdocipher/aegis/core/m/g$c;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/vdocipher/aegis/core/m/g$c;->d:Lcom/vdocipher/aegis/core/m/g$c;

    .line 5
    invoke-static {}, Lcom/vdocipher/aegis/core/m/g$c;->a()[Lcom/vdocipher/aegis/core/m/g$c;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/aegis/core/m/g$c;->e:[Lcom/vdocipher/aegis/core/m/g$c;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method private static synthetic a()[Lcom/vdocipher/aegis/core/m/g$c;
    .registers 4

    .line 1
    sget-object v0, Lcom/vdocipher/aegis/core/m/g$c;->a:Lcom/vdocipher/aegis/core/m/g$c;

    sget-object v1, Lcom/vdocipher/aegis/core/m/g$c;->b:Lcom/vdocipher/aegis/core/m/g$c;

    sget-object v2, Lcom/vdocipher/aegis/core/m/g$c;->c:Lcom/vdocipher/aegis/core/m/g$c;

    sget-object v3, Lcom/vdocipher/aegis/core/m/g$c;->d:Lcom/vdocipher/aegis/core/m/g$c;

    filled-new-array {v0, v1, v2, v3}, [Lcom/vdocipher/aegis/core/m/g$c;

    move-result-object v0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/aegis/core/m/g$c;
    .registers 2

    .line 1
    const-class v0, Lcom/vdocipher/aegis/core/m/g$c;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/aegis/core/m/g$c;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/aegis/core/m/g$c;
    .registers 1

    .line 1
    sget-object v0, Lcom/vdocipher/aegis/core/m/g$c;->e:[Lcom/vdocipher/aegis/core/m/g$c;

    invoke-virtual {v0}, [Lcom/vdocipher/aegis/core/m/g$c;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/aegis/core/m/g$c;

    return-object v0
.end method
