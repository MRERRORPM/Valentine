# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/m/o$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lcom/vdocipher/aegis/core/m/u$d;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/m/o;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/m/o;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/o$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/core/m/o;

    return-void
.end method


# virtual methods
.method public final a(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V
    .registers 16

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/o$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/core/m/o;

    move v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-wide v5, p5

    move-object v7, p7

    invoke-static/range {v0 .. v7}, Lcom/vdocipher/aegis/core/m/o;->$r8$lambda$7qyZSvEiwrF8Z3_yruZLGuJB900(Lcom/vdocipher/aegis/core/m/o;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V

    return-void
.end method
