# classes14.dex

.class public final Lcom/vdocipher/aegis/core/m/s;
.super Lcom/vdocipher/aegis/core/m/q;
.source "SourceFile"


# static fields
.field private static final S:Ljava/net/CookieManager;


# instance fields
.field private Q:Landroid/net/Uri;

.field private R:Landroid/net/Uri;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Ljava/net/CookieManager;

    invoke-direct {v0}, Ljava/net/CookieManager;-><init>()V

    sput-object v0, Lcom/vdocipher/aegis/core/m/s;->S:Ljava/net/CookieManager;

    .line 2
    sget-object v1, Ljava/net/CookiePolicy;->ACCEPT_ORIGINAL_SERVER:Ljava/net/CookiePolicy;

    invoke-virtual {v0, v1}, Ljava/net/CookieManager;->setCookiePolicy(Ljava/net/CookiePolicy;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/media3/common/Player;Landroid/view/SurfaceView;Lcom/vdocipher/aegis/core/d/k;)V
    .registers 5

    .line 1
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/vdocipher/aegis/core/m/q;-><init>(Landroid/content/Context;Landroidx/media3/common/Player;Landroid/view/SurfaceView;Lcom/vdocipher/aegis/core/d/k;)V

    return-void
.end method

.method private static a(Landroid/media/MediaCodec$CryptoException;)I
    .registers 2

    .line 92
    invoke-virtual {p0}, Landroid/media/MediaCodec$CryptoException;->getErrorCode()I

    move-result p0

    const/4 v0, 0x1

    if-eq p0, v0, :cond_22

    const/4 v0, 0x2

    if-eq p0, v0, :cond_1f

    const/4 v0, 0x3

    if-eq p0, v0, :cond_1c

    const/4 v0, 0x4

    if-eq p0, v0, :cond_19

    const/4 v0, 0x5

    if-eq p0, v0, :cond_16

    const/16 p0, 0x1834

    return p0

    :cond_16
    const/16 p0, 0x1832

    return p0

    :cond_19
    const/16 p0, 0x1831

    return p0

    :cond_1c
    const/16 p0, 0x1830

    return p0

    :cond_1f
    const/16 p0, 0x182f

    return p0

    :cond_22
    const/16 p0, 0x182e

    return p0
.end method

.method private n()V
    .registers 2

    .line 1
    invoke-static {}, Ljava/net/CookieHandler;->getDefault()Ljava/net/CookieHandler;

    move-result-object v0

    if-nez v0, :cond_b

    .line 2
    sget-object v0, Lcom/vdocipher/aegis/core/m/s;->S:Ljava/net/CookieManager;

    invoke-static {v0}, Ljava/net/CookieHandler;->setDefault(Ljava/net/CookieHandler;)V

    :cond_b
    return-void
.end method


# virtual methods
.method protected a(Landroid/os/Handler;Ljava/lang/String;Lcom/vdocipher/aegis/core/z/d$b;)Landroidx/media3/common/MediaItem;
    .registers 4

    .line 2
    new-instance p1, Landroidx/media3/common/MediaItem$Builder;

    invoke-direct {p1}, Landroidx/media3/common/MediaItem$Builder;-><init>()V

    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/s;->Q:Landroid/net/Uri;

    .line 3
    invoke-virtual {p1, p2}, Landroidx/media3/common/MediaItem$Builder;->setUri(Landroid/net/Uri;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p1

    .line 4
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/s;->R:Landroid/net/Uri;

    if-eqz p2, :cond_21

    .line 7
    new-instance p2, Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;

    sget-object p3, Landroidx/media3/common/C;->WIDEVINE_UUID:Ljava/util/UUID;

    invoke-direct {p2, p3}, Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;-><init>(Ljava/util/UUID;)V

    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/s;->R:Landroid/net/Uri;

    .line 8
    invoke-virtual {p2, p3}, Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;->setLicenseUri(Landroid/net/Uri;)Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;

    move-result-object p2

    .line 9
    invoke-virtual {p2}, Landroidx/media3/common/MediaItem$DrmConfiguration$Builder;->build()Landroidx/media3/common/MediaItem$DrmConfiguration;

    move-result-object p2

    goto :goto_22

    :cond_21
    const/4 p2, 0x0

    .line 10
    :goto_22
    invoke-virtual {p1, p2}, Landroidx/media3/common/MediaItem$Builder;->setDrmConfiguration(Landroidx/media3/common/MediaItem$DrmConfiguration;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p1

    .line 15
    invoke-virtual {p1}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    move-result-object p1

    return-object p1
.end method

.method protected a(Landroidx/media3/common/PlaybackException;)Lcom/vdocipher/aegis/core/m/p;
    .registers 10

    .line 16
    check-cast p1, Landroidx/media3/exoplayer/ExoPlaybackException;

    .line 17
    iget v0, p1, Landroidx/media3/exoplayer/ExoPlaybackException;->type:I

    const/4 v1, 0x1

    if-nez v0, :cond_b

    const-string/jumbo v2, "source"

    goto :goto_13

    :cond_b
    if-ne v0, v1, :cond_10

    .line 18
    const-string v2, "renderer"

    goto :goto_13

    :cond_10
    const-string/jumbo v2, "unexpected"

    :goto_13
    const/4 v3, -0x1

    const/4 v4, 0x0

    if-nez v0, :cond_7b

    .line 26
    invoke-virtual {p1}, Landroidx/media3/exoplayer/ExoPlaybackException;->getSourceException()Ljava/io/IOException;

    move-result-object v0

    .line 28
    instance-of v1, v0, Landroidx/media3/exoplayer/drm/DrmSession$DrmSessionException;

    if-eqz v1, :cond_23

    const/16 v1, 0x1423

    goto/16 :goto_a6

    .line 30
    :cond_23
    instance-of v1, v0, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;

    if-eqz v1, :cond_6a

    .line 33
    :try_start_27
    move-object v1, v0

    check-cast v1, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;

    iget-object v1, v1, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;->dataSpec:Landroidx/media3/datasource/DataSpec;

    iget-object v1, v1, Landroidx/media3/datasource/DataSpec;->uri:Landroid/net/Uri;

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v4
    :try_end_32
    .catch Ljava/lang/NullPointerException; {:try_start_27 .. :try_end_32} :catch_32

    .line 37
    :catch_32
    instance-of v1, v0, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    if-eqz v1, :cond_3b

    .line 38
    move-object v1, v0

    check-cast v1, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    iget v3, v1, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;->responseCode:I

    :cond_3b
    const/16 v1, 0x258

    const/16 v5, 0x190

    const/16 v6, 0x1f4

    if-eqz v4, :cond_59

    .line 42
    const-string v7, "m3u8"

    invoke-virtual {v4, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_59

    if-lt v3, v5, :cond_52

    if-ge v3, v6, :cond_52

    const/16 v1, 0x140c

    goto :goto_a6

    :cond_52
    if-lt v3, v6, :cond_75

    if-ge v3, v1, :cond_75

    const/16 v1, 0x140d

    goto :goto_a6

    :cond_59
    if-lt v3, v5, :cond_60

    if-ge v3, v6, :cond_60

    const/16 v1, 0x13f8

    goto :goto_a6

    :cond_60
    if-lt v3, v6, :cond_67

    if-ge v3, v1, :cond_67

    const/16 v1, 0x13f9

    goto :goto_a6

    :cond_67
    const/16 v1, 0x13fa

    goto :goto_a6

    .line 61
    :cond_6a
    instance-of v1, v0, Landroidx/media3/common/ParserException;

    if-eqz v1, :cond_71

    const/16 v1, 0x17f2

    goto :goto_a6

    .line 64
    :cond_71
    instance-of v1, v0, Landroidx/media3/datasource/FileDataSource$FileDataSourceException;

    if-eqz v1, :cond_78

    :cond_75
    const/16 v1, 0x142a

    goto :goto_a6

    :cond_78
    const/16 v1, 0x13f6

    goto :goto_a6

    :cond_7b
    if-ne v0, v1, :cond_97

    .line 73
    invoke-virtual {p1}, Landroidx/media3/exoplayer/ExoPlaybackException;->getRendererException()Ljava/lang/Exception;

    move-result-object v0

    .line 74
    instance-of v1, v0, Landroid/media/MediaCodec$CryptoException;

    if-eqz v1, :cond_8d

    .line 75
    move-object v1, v0

    check-cast v1, Landroid/media/MediaCodec$CryptoException;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/m/s;->a(Landroid/media/MediaCodec$CryptoException;)I

    move-result v1

    goto :goto_a6

    .line 76
    :cond_8d
    instance-of v1, v0, Landroidx/media3/exoplayer/mediacodec/MediaCodecRenderer$DecoderInitializationException;

    if-eqz v1, :cond_94

    const/16 v1, 0x17ea

    goto :goto_a6

    :cond_94
    const/16 v1, 0x17e8

    goto :goto_a6

    .line 82
    :cond_97
    invoke-virtual {p1}, Landroidx/media3/exoplayer/ExoPlaybackException;->getUnexpectedException()Ljava/lang/RuntimeException;

    move-result-object v0

    .line 83
    invoke-virtual {p0, v0}, Lcom/vdocipher/aegis/core/m/q;->a(Ljava/lang/Throwable;)Z

    move-result v1

    if-eqz v1, :cond_a4

    const/16 v1, 0x17e9

    goto :goto_a6

    :cond_a4
    const/16 v1, 0x17d5

    .line 87
    :goto_a6
    new-instance v5, Lcom/vdocipher/aegis/core/m/d;

    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v5, v2, v3, v4, v0}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 88
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "epError: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5}, Lcom/vdocipher/aegis/core/m/d;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "--"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "VdoExternalPlayer"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 90
    invoke-static {v1}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object p1

    .line 91
    new-instance v0, Lcom/vdocipher/aegis/core/m/p;

    invoke-direct {v0, v1, p1, v5}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    return-object v0
.end method

.method public a()V
    .registers 1

    .line 1
    invoke-super {p0}, Lcom/vdocipher/aegis/core/m/q;->a()V

    return-void
.end method

.method protected b(Lcom/vdocipher/aegis/core/m/y$a;)V
    .registers 8

    const-string v0, "VdoExternalPlayer"

    .line 1
    :try_start_2
    iget-object v1, p1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v1, v1, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaUrl:Ljava/lang/String;

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/s;->Q:Landroid/net/Uri;

    .line 2
    iget-object v1, p1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v1, v1, Lcom/vdocipher/aegis/player/VdoInitParams;->licenseUrl:Ljava/lang/String;

    if-eqz v1, :cond_18

    .line 3
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/s;->R:Landroid/net/Uri;
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_18} :catch_49

    .line 14
    :cond_18
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/s;->n()V

    .line 17
    :try_start_1b
    new-instance v1, Lcom/vdocipher/aegis/core/f/g;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/m/y$a;->b:Ljava/lang/String;

    invoke-direct {v1, v2}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    .line 18
    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v2, p1, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    iget-object p1, p1, Lcom/vdocipher/aegis/player/VdoInitParams;->configMap:Ljava/util/HashMap;

    invoke-virtual {v1, v2, p1}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/lang/String;Ljava/util/HashMap;)Lcom/vdocipher/aegis/media/PlayerOption;

    move-result-object p1

    .line 19
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->c:Lcom/vdocipher/aegis/media/PlayerOption;
    :try_end_2e
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_2e} :catch_2f

    goto :goto_3e

    :catch_2f
    move-exception p1

    .line 21
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 22
    new-instance p1, Lcom/vdocipher/aegis/media/PlayerOption;

    invoke-direct {p1}, Lcom/vdocipher/aegis/media/PlayerOption;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->c:Lcom/vdocipher/aegis/media/PlayerOption;

    .line 25
    :goto_3e
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    const/4 v0, 0x2

    invoke-virtual {p1, v0}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void

    :catch_49
    move-exception p1

    .line 26
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x1005

    .line 28
    invoke-static {v0}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v1

    .line 29
    new-instance v2, Lcom/vdocipher/aegis/core/m/d;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v4, -0x1

    const/4 v5, 0x0

    invoke-direct {v2, v3, v4, v5, p1}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 30
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    new-instance v3, Lcom/vdocipher/aegis/core/m/p;

    invoke-direct {v3, v0, v1, v2}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    const/4 v0, 0x1

    invoke-virtual {p1, v0, v3}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void
.end method

.method public getPlayerOptions()Lcom/vdocipher/aegis/media/PlayerOption;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->c:Lcom/vdocipher/aegis/media/PlayerOption;

    return-object v0
.end method

.method protected j()V
    .registers 1

    return-void
.end method

.method public stop()V
    .registers 1

    .line 1
    invoke-super {p0}, Lcom/vdocipher/aegis/core/m/q;->stop()V

    return-void
.end method
