# classes14.dex

.class public interface abstract Lcom/vdocipher/aegis/core/m/u$d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V
.end method
