# classes14.dex

.class Lcom/vdocipher/aegis/core/m/a0$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/a0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/m/a0;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/m/a0;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/a0$b;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0$b;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/a0;->j(Lcom/vdocipher/aegis/core/m/a0;)Landroidx/media3/exoplayer/ExoPlayer;

    move-result-object v0

    if-nez v0, :cond_9

    goto :goto_1e

    .line 3
    :cond_9
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0$b;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/a0;->k(Lcom/vdocipher/aegis/core/m/a0;)Landroidx/media3/common/MediaItem;

    move-result-object v0

    if-nez v0, :cond_12

    goto :goto_1e

    .line 7
    :cond_12
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0$b;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/a0;->k(Lcom/vdocipher/aegis/core/m/a0;)Landroidx/media3/common/MediaItem;

    move-result-object v0

    invoke-static {v0}, Lcom/vdocipher/aegis/core/t/d;->a(Landroidx/media3/common/MediaItem;)Lcom/vdocipher/aegis/core/p/b;

    move-result-object v0

    if-nez v0, :cond_1f

    :goto_1e
    return-void

    .line 9
    :cond_1f
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0$b;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/m/a0;->j(Lcom/vdocipher/aegis/core/m/a0;)Landroidx/media3/exoplayer/ExoPlayer;

    move-result-object v1

    invoke-interface {v1}, Landroidx/media3/exoplayer/ExoPlayer;->getCurrentPosition()J

    move-result-wide v1

    .line 10
    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/p/b;->b()Lcom/vdocipher/aegis/player/VdoInitParams;

    move-result-object v3

    iget-boolean v3, v3, Lcom/vdocipher/aegis/player/VdoInitParams;->clipped:Z

    if-eqz v3, :cond_42

    .line 11
    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/p/b;->b()Lcom/vdocipher/aegis/player/VdoInitParams;

    move-result-object v1

    iget-wide v1, v1, Lcom/vdocipher/aegis/player/VdoInitParams;->startTimeMs:J

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/a0$b;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/a0;->j(Lcom/vdocipher/aegis/core/m/a0;)Landroidx/media3/exoplayer/ExoPlayer;

    move-result-object v3

    invoke-interface {v3}, Landroidx/media3/exoplayer/ExoPlayer;->getCurrentPosition()J

    move-result-wide v3

    add-long/2addr v1, v3

    .line 13
    :cond_42
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/a0$b;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/a0;->j(Lcom/vdocipher/aegis/core/m/a0;)Landroidx/media3/exoplayer/ExoPlayer;

    move-result-object v3

    invoke-interface {v3}, Landroidx/media3/exoplayer/ExoPlayer;->getDuration()J

    move-result-wide v3

    invoke-static {v1, v2, v3, v4}, Lcom/vdocipher/aegis/core/t/d;->a(JJ)Z

    move-result v3

    if-eqz v3, :cond_71

    .line 14
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/a0$b;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/m/a0;->l(Lcom/vdocipher/aegis/core/m/a0;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object v3

    iget-object v4, p0, Lcom/vdocipher/aegis/core/m/a0$b;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v4}, Lcom/vdocipher/aegis/core/m/a0;->k(Lcom/vdocipher/aegis/core/m/a0;)Landroidx/media3/common/MediaItem;

    move-result-object v4

    iget-object v4, v4, Landroidx/media3/common/MediaItem;->mediaId:Ljava/lang/String;

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "%s"

    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v4, v1}, Lcom/vdocipher/aegis/core/k/c;->f(Ljava/lang/String;Ljava/lang/String;)Z

    .line 15
    :cond_71
    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/p/b;->c()Z

    move-result v1

    if-eqz v1, :cond_85

    .line 16
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0$b;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/m/a0;->l(Lcom/vdocipher/aegis/core/m/a0;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object v1

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/p/b;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    invoke-virtual {v1, v0, v2}, Lcom/vdocipher/aegis/core/k/c;->b(Ljava/lang/String;Z)Z

    .line 18
    :cond_85
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0$b;->a:Lcom/vdocipher/aegis/core/m/a0;

    iget-object v1, v0, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/a0;->m(Lcom/vdocipher/aegis/core/m/a0;)Ljava/lang/Runnable;

    move-result-object v0

    const-wide/16 v2, 0x1388

    invoke-virtual {v1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
