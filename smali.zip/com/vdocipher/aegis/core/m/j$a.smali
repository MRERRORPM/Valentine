# classes14.dex

.class Lcom/vdocipher/aegis/core/m/j$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/os/Parcel;)Lcom/vdocipher/aegis/core/m/j;
    .registers 3

    .line 1
    new-instance v0, Lcom/vdocipher/aegis/core/m/j;

    invoke-direct {v0, p1}, Lcom/vdocipher/aegis/core/m/j;-><init>(Landroid/os/Parcel;)V

    return-object v0
.end method

.method public a(I)[Lcom/vdocipher/aegis/core/m/j;
    .registers 2

    .line 2
    new-array p1, p1, [Lcom/vdocipher/aegis/core/m/j;

    return-object p1
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/m/j$a;->a(Landroid/os/Parcel;)Lcom/vdocipher/aegis/core/m/j;

    move-result-object p1

    return-object p1
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/m/j$a;->a(I)[Lcom/vdocipher/aegis/core/m/j;

    move-result-object p1

    return-object p1
.end method
