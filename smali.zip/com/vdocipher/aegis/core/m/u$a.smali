# classes14.dex

.class final enum Lcom/vdocipher/aegis/core/m/u$a;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4018
    name = "a"
.end annotation


# static fields
.field public static final enum a:Lcom/vdocipher/aegis/core/m/u$a;

.field public static final enum b:Lcom/vdocipher/aegis/core/m/u$a;

.field private static final synthetic c:[Lcom/vdocipher/aegis/core/m/u$a;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lcom/vdocipher/aegis/core/m/u$a;

    const-string v1, "PROVISION"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/vdocipher/aegis/core/m/u$a;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/vdocipher/aegis/core/m/u$a;->a:Lcom/vdocipher/aegis/core/m/u$a;

    .line 2
    new-instance v0, Lcom/vdocipher/aegis/core/m/u$a;

    const-string v1, "KEY"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lcom/vdocipher/aegis/core/m/u$a;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/vdocipher/aegis/core/m/u$a;->b:Lcom/vdocipher/aegis/core/m/u$a;

    .line 3
    invoke-static {}, Lcom/vdocipher/aegis/core/m/u$a;->a()[Lcom/vdocipher/aegis/core/m/u$a;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/aegis/core/m/u$a;->c:[Lcom/vdocipher/aegis/core/m/u$a;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method private static synthetic a()[Lcom/vdocipher/aegis/core/m/u$a;
    .registers 2

    .line 1
    sget-object v0, Lcom/vdocipher/aegis/core/m/u$a;->a:Lcom/vdocipher/aegis/core/m/u$a;

    sget-object v1, Lcom/vdocipher/aegis/core/m/u$a;->b:Lcom/vdocipher/aegis/core/m/u$a;

    filled-new-array {v0, v1}, [Lcom/vdocipher/aegis/core/m/u$a;

    move-result-object v0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/aegis/core/m/u$a;
    .registers 2

    .line 1
    const-class v0, Lcom/vdocipher/aegis/core/m/u$a;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/aegis/core/m/u$a;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/aegis/core/m/u$a;
    .registers 1

    .line 1
    sget-object v0, Lcom/vdocipher/aegis/core/m/u$a;->c:[Lcom/vdocipher/aegis/core/m/u$a;

    invoke-virtual {v0}, [Lcom/vdocipher/aegis/core/m/u$a;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/aegis/core/m/u$a;

    return-object v0
.end method
