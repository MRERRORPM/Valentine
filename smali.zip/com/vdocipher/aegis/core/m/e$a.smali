# classes14.dex

.class Lcom/vdocipher/aegis/core/m/e$a;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/m/e;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/m/e;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/e$a;->a:Lcom/vdocipher/aegis/core/m/e;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 5

    .line 1
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e$a;->a:Lcom/vdocipher/aegis/core/m/e;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/m/e;)Z

    move-result p1

    if-eqz p1, :cond_9

    return-void

    .line 3
    :cond_9
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e$a;->a:Lcom/vdocipher/aegis/core/m/e;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/m/e;->b(Lcom/vdocipher/aegis/core/m/e;)I

    move-result p1

    const/4 v0, 0x0

    if-nez p1, :cond_3d

    .line 4
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e$a;->a:Lcom/vdocipher/aegis/core/m/e;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/m/e;->c(Lcom/vdocipher/aegis/core/m/e;)I

    .line 5
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e$a;->a:Lcom/vdocipher/aegis/core/m/e;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/m/e;->d(Lcom/vdocipher/aegis/core/m/e;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_29

    .line 6
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e$a;->a:Lcom/vdocipher/aegis/core/m/e;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/m/e;->d(Lcom/vdocipher/aegis/core/m/e;)Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2, v0}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 8
    :cond_29
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/e$a;->a:Lcom/vdocipher/aegis/core/m/e;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/m/e;->e(Lcom/vdocipher/aegis/core/m/e;)Ljava/lang/String;

    move-result-object p2

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e$a;->a:Lcom/vdocipher/aegis/core/m/e;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/e;->f(Lcom/vdocipher/aegis/core/m/e;)Lcom/vdocipher/aegis/player/VdoInitParams;

    move-result-object v0

    iget-object v0, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->customPlayerId:Ljava/lang/String;

    const-string v1, "/api/meta/o/"

    invoke-static {p1, p2, v0, v1}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 11
    :cond_3d
    const-string p1, "error"

    invoke-virtual {p2, p1}, Landroid/content/Intent;->getSerializableExtra(Ljava/lang/String;)Ljava/io/Serializable;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/aegis/core/m/p;

    .line 12
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/e$a;->a:Lcom/vdocipher/aegis/core/m/e;

    invoke-static {p2, p1, v0}, Lcom/vdocipher/aegis/core/m/e;->a(Lcom/vdocipher/aegis/core/m/e;Lcom/vdocipher/aegis/core/m/p;Ljava/lang/String;)V

    return-void
.end method
