# classes14.dex

.class public Lcom/vdocipher/aegis/core/m/r;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static h:Lcom/vdocipher/aegis/core/m/r;

.field private static final i:Ljava/util/Set;


# instance fields
.field private a:Lcom/vdocipher/aegis/core/m/a0;

.field private b:Landroidx/media3/exoplayer/ExoPlayer;

.field private c:I

.field private d:Ljava/lang/String;

.field private e:Lcom/vdocipher/aegis/core/k/c;

.field private f:Z

.field g:Landroidx/media3/exoplayer/upstream/CmcdConfiguration$Factory;


# direct methods
.method public static synthetic $r8$lambda$Sn7ugSpL1AvHoGy-AUxQXMRDVeI(Lcom/vdocipher/aegis/core/m/r;Landroidx/media3/common/MediaItem;)Landroidx/media3/exoplayer/upstream/CmcdConfiguration;
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/r;->a(Landroidx/media3/common/MediaItem;)Landroidx/media3/exoplayer/upstream/CmcdConfiguration;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$oV585mKhGckYu4Hh2z01brDdxhs(Lcom/vdocipher/aegis/core/m/r;Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/r;->b(Landroid/content/Context;)V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    sput-object v0, Lcom/vdocipher/aegis/core/m/r;->i:Ljava/util/Set;

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .registers 10

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/m/r;->f:Z

    .line 6
    new-instance v1, Lcom/vdocipher/aegis/core/m/r$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lcom/vdocipher/aegis/core/m/r$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/core/m/r;)V

    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/r;->g:Landroidx/media3/exoplayer/upstream/CmcdConfiguration$Factory;

    .line 19
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/r;->b:Landroidx/media3/exoplayer/ExoPlayer;

    if-nez v1, :cond_a4

    .line 21
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/r;->c(Landroid/content/Context;)V

    .line 23
    new-instance v1, Landroidx/media3/exoplayer/analytics/PlaybackStatsListener;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/r;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-direct {v1, v0, v2}, Landroidx/media3/exoplayer/analytics/PlaybackStatsListener;-><init>(ZLandroidx/media3/exoplayer/analytics/PlaybackStatsListener$Callback;)V

    .line 25
    new-instance v2, Landroidx/media3/exoplayer/DefaultRenderersFactory;

    invoke-direct {v2, p1}, Landroidx/media3/exoplayer/DefaultRenderersFactory;-><init>(Landroid/content/Context;)V

    .line 26
    invoke-virtual {v2}, Landroidx/media3/exoplayer/DefaultRenderersFactory;->forceEnableMediaCodecAsynchronousQueueing()Landroidx/media3/exoplayer/DefaultRenderersFactory;

    move-result-object v2

    const/4 v3, 0x1

    .line 27
    invoke-virtual {v2, v3}, Landroidx/media3/exoplayer/DefaultRenderersFactory;->setEnableDecoderFallback(Z)Landroidx/media3/exoplayer/DefaultRenderersFactory;

    move-result-object v2

    .line 28
    invoke-virtual {v2, v0}, Landroidx/media3/exoplayer/DefaultRenderersFactory;->setExtensionRendererMode(I)Landroidx/media3/exoplayer/DefaultRenderersFactory;

    move-result-object v0

    .line 30
    new-instance v2, Landroidx/media3/exoplayer/trackselection/AdaptiveTrackSelection$Factory;

    invoke-direct {v2}, Landroidx/media3/exoplayer/trackselection/AdaptiveTrackSelection$Factory;-><init>()V

    .line 32
    new-instance v3, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;

    invoke-direct {v3}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;-><init>()V

    iget v4, p0, Lcom/vdocipher/aegis/core/m/r;->c:I

    const/16 v5, 0x3e8

    const/16 v6, 0x7d0

    const v7, 0xc350

    .line 33
    invoke-virtual {v3, v7, v4, v5, v6}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;->setBufferDurationsMs(IIII)Landroidx/media3/exoplayer/DefaultLoadControl$Builder;

    move-result-object v3

    .line 37
    invoke-virtual {v3}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;->build()Landroidx/media3/exoplayer/DefaultLoadControl;

    move-result-object v3

    .line 39
    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/b;->e(Landroid/content/Context;)Landroidx/media3/datasource/DataSource$Factory;

    move-result-object v4

    .line 41
    new-instance v5, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;

    invoke-direct {v5, p1}, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;-><init>(Landroid/content/Context;)V

    .line 43
    invoke-virtual {v5, v4}, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->setDataSourceFactory(Landroidx/media3/datasource/DataSource$Factory;)Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;

    move-result-object v4

    new-instance v5, Lcom/vdocipher/aegis/core/m/o;

    invoke-direct {v5, p1}, Lcom/vdocipher/aegis/core/m/o;-><init>(Landroid/content/Context;)V

    .line 44
    invoke-virtual {v4, v5}, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->setDrmSessionManagerProvider(Landroidx/media3/exoplayer/drm/DrmSessionManagerProvider;)Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;

    move-result-object v4

    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/r;->g:Landroidx/media3/exoplayer/upstream/CmcdConfiguration$Factory;

    .line 45
    invoke-virtual {v4, v5}, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->setCmcdConfigurationFactory(Landroidx/media3/exoplayer/upstream/CmcdConfiguration$Factory;)Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;

    move-result-object v4

    new-instance v5, Lcom/vdocipher/aegis/core/m/v;

    invoke-direct {v5}, Lcom/vdocipher/aegis/core/m/v;-><init>()V

    .line 46
    invoke-virtual {v4, v5}, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->setLoadErrorHandlingPolicy(Landroidx/media3/exoplayer/upstream/LoadErrorHandlingPolicy;)Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;

    move-result-object v4

    .line 48
    new-instance v5, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector;

    invoke-direct {v5, p1, v2}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector;-><init>(Landroid/content/Context;Landroidx/media3/exoplayer/trackselection/ExoTrackSelection$Factory;)V

    .line 50
    new-instance v2, Landroidx/media3/exoplayer/ExoPlayer$Builder;

    invoke-direct {v2, p1, v0}, Landroidx/media3/exoplayer/ExoPlayer$Builder;-><init>(Landroid/content/Context;Landroidx/media3/exoplayer/RenderersFactory;)V

    .line 51
    invoke-virtual {v2, v4}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setMediaSourceFactory(Landroidx/media3/exoplayer/source/MediaSource$Factory;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    move-result-object v0

    .line 52
    invoke-virtual {v0, v5}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setTrackSelector(Landroidx/media3/exoplayer/trackselection/TrackSelector;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    move-result-object v0

    .line 53
    invoke-virtual {v0, v3}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setLoadControl(Landroidx/media3/exoplayer/LoadControl;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    move-result-object v0

    .line 54
    invoke-virtual {v0}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->build()Landroidx/media3/exoplayer/ExoPlayer;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/r;->b:Landroidx/media3/exoplayer/ExoPlayer;

    .line 56
    invoke-static {p1}, Lcom/vdocipher/aegis/core/k/c;->b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/r;->e:Lcom/vdocipher/aegis/core/k/c;

    .line 58
    new-instance v2, Lcom/vdocipher/aegis/core/m/a0;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/r;->b:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-direct {v2, p1, v3, v0, v1}, Lcom/vdocipher/aegis/core/m/a0;-><init>(Landroid/content/Context;Landroidx/media3/exoplayer/ExoPlayer;Lcom/vdocipher/aegis/core/k/c;Landroidx/media3/exoplayer/analytics/PlaybackStatsListener;)V

    iput-object v2, p0, Lcom/vdocipher/aegis/core/m/r;->a:Lcom/vdocipher/aegis/core/m/a0;

    .line 59
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/r;->b:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {p1, v2}, Landroidx/media3/exoplayer/ExoPlayer;->addListener(Landroidx/media3/common/Player$Listener;)V

    .line 60
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/r;->b:Landroidx/media3/exoplayer/ExoPlayer;

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/r;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-interface {p1, v0}, Landroidx/media3/exoplayer/ExoPlayer;->addAnalyticsListener(Landroidx/media3/exoplayer/analytics/AnalyticsListener;)V

    :cond_a4
    return-void
.end method

.method private synthetic a(Landroidx/media3/common/MediaItem;)Landroidx/media3/exoplayer/upstream/CmcdConfiguration;
    .registers 6

    .line 1
    new-instance v0, Lcom/vdocipher/aegis/core/m/r$a;

    invoke-direct {v0, p0}, Lcom/vdocipher/aegis/core/m/r$a;-><init>(Lcom/vdocipher/aegis/core/m/r;)V

    .line 7
    invoke-static {}, Lcom/vdocipher/aegis/core/d/c;->a()Ljava/lang/String;

    move-result-object v1

    .line 8
    iget-object p1, p1, Landroidx/media3/common/MediaItem;->mediaId:Ljava/lang/String;

    .line 9
    new-instance v2, Landroidx/media3/exoplayer/upstream/CmcdConfiguration;

    const/4 v3, 0x0

    invoke-direct {v2, v1, p1, v0, v3}, Landroidx/media3/exoplayer/upstream/CmcdConfiguration;-><init>(Ljava/lang/String;Ljava/lang/String;Landroidx/media3/exoplayer/upstream/CmcdConfiguration$RequestConfig;I)V

    return-object v2
.end method

.method public static declared-synchronized a()Lcom/vdocipher/aegis/core/m/r;
    .registers 2

    const-class v0, Lcom/vdocipher/aegis/core/m/r;

    monitor-enter v0

    .line 15
    :try_start_3
    sget-object v1, Lcom/vdocipher/aegis/core/m/r;->h:Lcom/vdocipher/aegis/core/m/r;
    :try_end_5
    .catchall {:try_start_3 .. :try_end_5} :catchall_7

    monitor-exit v0

    return-object v1

    :catchall_7
    move-exception v1

    :try_start_8
    monitor-exit v0
    :try_end_9
    .catchall {:try_start_8 .. :try_end_9} :catchall_7

    throw v1
.end method

.method public static declared-synchronized a(Landroid/content/Context;Ljava/lang/String;)Lcom/vdocipher/aegis/core/m/r;
    .registers 4

    const-class v0, Lcom/vdocipher/aegis/core/m/r;

    monitor-enter v0

    .line 10
    :try_start_3
    sget-object v1, Lcom/vdocipher/aegis/core/m/r;->h:Lcom/vdocipher/aegis/core/m/r;

    if-nez v1, :cond_e

    .line 11
    new-instance v1, Lcom/vdocipher/aegis/core/m/r;

    invoke-direct {v1, p0}, Lcom/vdocipher/aegis/core/m/r;-><init>(Landroid/content/Context;)V

    sput-object v1, Lcom/vdocipher/aegis/core/m/r;->h:Lcom/vdocipher/aegis/core/m/r;

    .line 13
    :cond_e
    sget-object p0, Lcom/vdocipher/aegis/core/m/r;->i:Ljava/util/Set;

    invoke-interface {p0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 14
    sget-object p0, Lcom/vdocipher/aegis/core/m/r;->h:Lcom/vdocipher/aegis/core/m/r;
    :try_end_15
    .catchall {:try_start_3 .. :try_end_15} :catchall_17

    monitor-exit v0

    return-object p0

    :catchall_17
    move-exception p0

    :try_start_18
    monitor-exit v0
    :try_end_19
    .catchall {:try_start_18 .. :try_end_19} :catchall_17

    throw p0
.end method

.method private a(Landroid/content/Context;)V
    .registers 4

    .line 16
    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "ClrDataHandler"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    .line 17
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 18
    new-instance v1, Landroid/os/Handler;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/Looper;

    invoke-direct {v1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 19
    new-instance v0, Lcom/vdocipher/aegis/core/m/r$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0, p1}, Lcom/vdocipher/aegis/core/m/r$$ExternalSyntheticLambda1;-><init>(Lcom/vdocipher/aegis/core/m/r;Landroid/content/Context;)V

    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private synthetic b(Landroid/content/Context;)V
    .registers 2

    .line 2
    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/b;->a(Landroid/content/Context;)V

    .line 3
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/r;->e:Lcom/vdocipher/aegis/core/k/c;

    if-eqz p1, :cond_d

    .line 4
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/k/c;->b()V

    const/4 p1, 0x0

    .line 5
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/r;->e:Lcom/vdocipher/aegis/core/k/c;

    :cond_d
    return-void
.end method

.method private c(Landroid/content/Context;)V
    .registers 4

    .line 1
    const-string v0, "com_vdocipher_aegis_setting"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 2
    invoke-static {p1}, Lcom/vdocipher/aegis/core/m/z;->getVdoPlayingPlaybackMode(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/r;->d:Ljava/lang/String;

    .line 3
    const-string p1, "BUFFERING_GOAL_MS"

    const v1, 0xc350

    invoke-interface {v0, p1, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p1

    iput p1, p0, Lcom/vdocipher/aegis/core/m/r;->c:I

    return-void
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;)V
    .registers 4

    .line 5
    invoke-static {}, Lcom/vdocipher/aegis/core/m/r;->a()Lcom/vdocipher/aegis/core/m/r;

    move-result-object v0

    if-eqz v0, :cond_d

    .line 6
    iget-boolean v1, v0, Lcom/vdocipher/aegis/core/m/r;->f:Z

    if-nez v1, :cond_d

    .line 7
    invoke-virtual {v0, p0, p1}, Lcom/vdocipher/aegis/core/m/r;->b(Landroid/content/Context;Ljava/lang/String;)V

    :cond_d
    return-void
.end method


# virtual methods
.method public b()Landroidx/media3/exoplayer/ExoPlayer;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/r;->b:Landroidx/media3/exoplayer/ExoPlayer;

    return-object v0
.end method

.method public b(Landroid/content/Context;Ljava/lang/String;)V
    .registers 4

    .line 6
    sget-object v0, Lcom/vdocipher/aegis/core/m/r;->i:Ljava/util/Set;

    invoke-interface {v0, p2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 7
    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_2b

    .line 8
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/r;->a:Lcom/vdocipher/aegis/core/m/a0;

    if-eqz p2, :cond_17

    .line 9
    invoke-virtual {p2}, Lcom/vdocipher/aegis/core/m/a0;->a()V

    .line 10
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/r;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-virtual {p2}, Lcom/vdocipher/aegis/core/m/a0;->release()V

    .line 12
    :cond_17
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/r;->a(Landroid/content/Context;)V

    .line 13
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/r;->b:Landroidx/media3/exoplayer/ExoPlayer;

    if-eqz p1, :cond_21

    .line 14
    invoke-interface {p1}, Landroidx/media3/exoplayer/ExoPlayer;->release()V

    :cond_21
    const/4 p1, 0x0

    .line 15
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/r;->b:Landroidx/media3/exoplayer/ExoPlayer;

    .line 16
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/r;->a:Lcom/vdocipher/aegis/core/m/a0;

    .line 17
    sput-object p1, Lcom/vdocipher/aegis/core/m/r;->h:Lcom/vdocipher/aegis/core/m/r;

    const/4 p1, 0x1

    .line 18
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/r;->f:Z

    :cond_2b
    return-void
.end method

.method public c()Ljava/lang/String;
    .registers 2

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/r;->d:Ljava/lang/String;

    return-object v0
.end method

.method public d()Lcom/vdocipher/aegis/core/m/a0;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/r;->a:Lcom/vdocipher/aegis/core/m/a0;

    return-object v0
.end method
