# classes14.dex

.class public final Lcom/vdocipher/aegis/core/m/a;
.super Landroid/widget/FrameLayout;
.source "SourceFile"


# instance fields
.field private a:F

.field private b:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lcom/vdocipher/aegis/core/m/a;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    .line 2
    invoke-direct {p0, p1, p2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 p1, 0x0

    .line 3
    iput p1, p0, Lcom/vdocipher/aegis/core/m/a;->b:I

    return-void
.end method


# virtual methods
.method public getResizeMode()I
    .registers 2

    .line 1
    iget v0, p0, Lcom/vdocipher/aegis/core/m/a;->b:I

    return v0
.end method

.method protected onMeasure(II)V
    .registers 11

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->toString(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "MeasureSpec: "

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " x "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->toString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 3
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "provided: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "ARFL"

    invoke-static {v2, v0}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    .line 7
    iget p1, p0, Lcom/vdocipher/aegis/core/m/a;->b:I

    const/4 p2, 0x3

    if-eq p1, p2, :cond_bc

    iget p1, p0, Lcom/vdocipher/aegis/core/m/a;->a:F

    const/4 p2, 0x0

    cmpg-float p1, p1, p2

    if-gtz p1, :cond_4c

    goto/16 :goto_bc

    .line 12
    :cond_4c
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p1

    .line 13
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v0

    int-to-float v3, p1

    int-to-float v4, v0

    div-float v5, v3, v4

    .line 15
    iget v6, p0, Lcom/vdocipher/aegis/core/m/a;->a:F

    div-float/2addr v6, v5

    const/high16 v5, 0x3f800000  # 1.0f

    sub-float/2addr v6, v5

    .line 16
    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    move-result v5

    const v7, 0x3c23d70a  # 0.01f

    cmpg-float v5, v5, v7

    if-gtz v5, :cond_70

    .line 18
    const-string/jumbo p1, "skip measure"

    invoke-static {v2, p1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 22
    :cond_70
    iget v5, p0, Lcom/vdocipher/aegis/core/m/a;->b:I

    const/4 v7, 0x1

    if-eq v5, v7, :cond_94

    const/4 v7, 0x2

    if-eq v5, v7, :cond_8f

    const/4 v7, 0x4

    if-eq v5, v7, :cond_85

    cmpl-float p2, v6, p2

    if-lez p2, :cond_82

    .line 38
    iget p2, p0, Lcom/vdocipher/aegis/core/m/a;->a:F

    goto :goto_96

    .line 40
    :cond_82
    iget p1, p0, Lcom/vdocipher/aegis/core/m/a;->a:F

    goto :goto_91

    :cond_85
    cmpl-float p2, v6, p2

    if-lez p2, :cond_8c

    .line 41
    iget p1, p0, Lcom/vdocipher/aegis/core/m/a;->a:F

    goto :goto_91

    .line 43
    :cond_8c
    iget p2, p0, Lcom/vdocipher/aegis/core/m/a;->a:F

    goto :goto_96

    .line 44
    :cond_8f
    iget p1, p0, Lcom/vdocipher/aegis/core/m/a;->a:F

    :goto_91
    mul-float/2addr v4, p1

    float-to-int p1, v4

    goto :goto_98

    .line 45
    :cond_94
    iget p2, p0, Lcom/vdocipher/aegis/core/m/a;->a:F

    :goto_96
    div-float/2addr v3, p2

    float-to-int v0, v3

    .line 65
    :goto_98
    new-instance p2, Ljava/lang/StringBuilder;

    const-string v3, "final "

    invoke-direct {p2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {v2, p2}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/high16 p2, 0x40000000  # 2.0f

    .line 66
    invoke-static {p1, p2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    .line 67
    invoke-static {v0, p2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    .line 68
    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    :cond_bc
    :goto_bc
    return-void
.end method

.method public setAspectRatio(F)V
    .registers 3

    .line 1
    iget v0, p0, Lcom/vdocipher/aegis/core/m/a;->a:F

    cmpl-float v0, v0, p1

    if-eqz v0, :cond_b

    .line 2
    iput p1, p0, Lcom/vdocipher/aegis/core/m/a;->a:F

    .line 3
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_b
    return-void
.end method

.method public setResizeMode(I)V
    .registers 3

    .line 1
    iget v0, p0, Lcom/vdocipher/aegis/core/m/a;->b:I

    if-eq v0, p1, :cond_9

    .line 2
    iput p1, p0, Lcom/vdocipher/aegis/core/m/a;->b:I

    .line 3
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_9
    return-void
.end method
