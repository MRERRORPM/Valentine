# classes14.dex

.class public Lcom/vdocipher/aegis/core/m/w;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/media3/session/MediaLibraryService$MediaLibrarySession$Callback;


# instance fields
.field private final a:Lcom/vdocipher/aegis/core/m/a0;

.field b:Landroidx/media3/session/SessionCommand;

.field c:Landroidx/media3/session/CommandButton;

.field d:Landroidx/media3/session/CommandButton;

.field private final e:Ljava/util/List;


# direct methods
.method public constructor <init>(Lcom/vdocipher/aegis/core/m/a0;)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Landroidx/media3/session/SessionCommand;

    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const-string v2, "VDO_COMMAND_STOP"

    invoke-direct {v0, v2, v1}, Landroidx/media3/session/SessionCommand;-><init>(Ljava/lang/String;Landroid/os/Bundle;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/w;->b:Landroidx/media3/session/SessionCommand;

    .line 3
    new-instance v0, Landroidx/media3/session/CommandButton$Builder;

    invoke-direct {v0}, Landroidx/media3/session/CommandButton$Builder;-><init>()V

    .line 4
    const-string v1, "Stop"

    invoke-virtual {v0, v1}, Landroidx/media3/session/CommandButton$Builder;->setDisplayName(Ljava/lang/CharSequence;)Landroidx/media3/session/CommandButton$Builder;

    move-result-object v0

    const/4 v2, 0x1

    .line 5
    invoke-virtual {v0, v2}, Landroidx/media3/session/CommandButton$Builder;->setEnabled(Z)Landroidx/media3/session/CommandButton$Builder;

    move-result-object v0

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/w;->b:Landroidx/media3/session/SessionCommand;

    .line 6
    invoke-virtual {v0, v3}, Landroidx/media3/session/CommandButton$Builder;->setSessionCommand(Landroidx/media3/session/SessionCommand;)Landroidx/media3/session/CommandButton$Builder;

    move-result-object v0

    sget v3, Lcom/vdocipher/aegis/R$drawable;->vdo_media3_notification_stop:I

    .line 7
    invoke-virtual {v0, v3}, Landroidx/media3/session/CommandButton$Builder;->setIconResId(I)Landroidx/media3/session/CommandButton$Builder;

    move-result-object v0

    .line 8
    invoke-virtual {v0}, Landroidx/media3/session/CommandButton$Builder;->build()Landroidx/media3/session/CommandButton;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/w;->c:Landroidx/media3/session/CommandButton;

    .line 10
    new-instance v0, Landroidx/media3/session/CommandButton$Builder;

    invoke-direct {v0}, Landroidx/media3/session/CommandButton$Builder;-><init>()V

    .line 11
    invoke-virtual {v0, v1}, Landroidx/media3/session/CommandButton$Builder;->setDisplayName(Ljava/lang/CharSequence;)Landroidx/media3/session/CommandButton$Builder;

    move-result-object v0

    const/4 v1, 0x0

    .line 12
    invoke-virtual {v0, v1}, Landroidx/media3/session/CommandButton$Builder;->setEnabled(Z)Landroidx/media3/session/CommandButton$Builder;

    move-result-object v0

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/w;->b:Landroidx/media3/session/SessionCommand;

    .line 13
    invoke-virtual {v0, v3}, Landroidx/media3/session/CommandButton$Builder;->setSessionCommand(Landroidx/media3/session/SessionCommand;)Landroidx/media3/session/CommandButton$Builder;

    move-result-object v0

    sget v3, Lcom/vdocipher/aegis/R$drawable;->vdo_media3_notification_stop:I

    .line 14
    invoke-virtual {v0, v3}, Landroidx/media3/session/CommandButton$Builder;->setIconResId(I)Landroidx/media3/session/CommandButton$Builder;

    move-result-object v0

    .line 15
    invoke-virtual {v0}, Landroidx/media3/session/CommandButton$Builder;->build()Landroidx/media3/session/CommandButton;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/w;->d:Landroidx/media3/session/CommandButton;

    .line 21
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/w;->c:Landroidx/media3/session/CommandButton;

    const/4 v4, 0x2

    new-array v4, v4, [Landroidx/media3/session/CommandButton;

    aput-object v3, v4, v1

    aput-object v0, v4, v2

    invoke-static {v4}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/w;->e:Ljava/util/List;

    .line 22
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/w;->a:Lcom/vdocipher/aegis/core/m/a0;

    return-void
.end method


# virtual methods
.method public onConnect(Landroidx/media3/session/MediaSession;Landroidx/media3/session/MediaSession$ControllerInfo;)Landroidx/media3/session/MediaSession$ConnectionResult;
    .registers 5

    .line 1
    invoke-super {p0, p1, p2}, Landroidx/media3/session/MediaLibraryService$MediaLibrarySession$Callback;->onConnect(Landroidx/media3/session/MediaSession;Landroidx/media3/session/MediaSession$ControllerInfo;)Landroidx/media3/session/MediaSession$ConnectionResult;

    move-result-object p2

    .line 3
    iget-object v0, p2, Landroidx/media3/session/MediaSession$ConnectionResult;->availableSessionCommands:Landroidx/media3/session/SessionCommands;

    invoke-virtual {v0}, Landroidx/media3/session/SessionCommands;->buildUpon()Landroidx/media3/session/SessionCommands$Builder;

    move-result-object v0

    .line 4
    invoke-virtual {p1}, Landroidx/media3/session/MediaSession;->getPlayer()Landroidx/media3/common/Player;

    move-result-object p1

    invoke-interface {p1}, Landroidx/media3/common/Player;->getPlaybackState()I

    move-result p1

    const/4 v1, 0x1

    if-eq p1, v1, :cond_19

    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/w;->e:Ljava/util/List;

    const/4 v1, 0x0

    goto :goto_1b

    :cond_19
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/w;->e:Ljava/util/List;

    :goto_1b
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/media3/session/CommandButton;

    .line 5
    iget-object p1, p1, Landroidx/media3/session/CommandButton;->sessionCommand:Landroidx/media3/session/SessionCommand;

    if-eqz p1, :cond_28

    .line 6
    invoke-virtual {v0, p1}, Landroidx/media3/session/SessionCommands$Builder;->add(Landroidx/media3/session/SessionCommand;)Landroidx/media3/session/SessionCommands$Builder;

    .line 9
    :cond_28
    invoke-virtual {v0}, Landroidx/media3/session/SessionCommands$Builder;->build()Landroidx/media3/session/SessionCommands;

    move-result-object p1

    iget-object p2, p2, Landroidx/media3/session/MediaSession$ConnectionResult;->availablePlayerCommands:Landroidx/media3/common/Player$Commands;

    invoke-static {p1, p2}, Landroidx/media3/session/MediaSession$ConnectionResult;->accept(Landroidx/media3/session/SessionCommands;Landroidx/media3/common/Player$Commands;)Landroidx/media3/session/MediaSession$ConnectionResult;

    move-result-object p1

    return-object p1
.end method

.method public onCustomCommand(Landroidx/media3/session/MediaSession;Landroidx/media3/session/MediaSession$ControllerInfo;Landroidx/media3/session/SessionCommand;Landroid/os/Bundle;)Lcom/google/common/util/concurrent/ListenableFuture;
    .registers 5

    .line 1
    iget-object p2, p3, Landroidx/media3/session/SessionCommand;->customAction:Ljava/lang/String;

    const-string p3, "VDO_COMMAND_STOP"

    invoke-virtual {p3, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_2e

    .line 2
    invoke-virtual {p1}, Landroidx/media3/session/MediaSession;->getPlayer()Landroidx/media3/common/Player;

    move-result-object p2

    invoke-interface {p2}, Landroidx/media3/common/Player;->getPlaybackState()I

    move-result p2

    const/4 p3, 0x1

    if-eq p2, p3, :cond_2e

    .line 3
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/w;->a:Lcom/vdocipher/aegis/core/m/a0;

    if-eqz p2, :cond_1c

    .line 4
    invoke-virtual {p2}, Lcom/vdocipher/aegis/core/m/a0;->a()V

    .line 5
    :cond_1c
    invoke-virtual {p1}, Landroidx/media3/session/MediaSession;->getPlayer()Landroidx/media3/common/Player;

    move-result-object p1

    invoke-interface {p1}, Landroidx/media3/common/Player;->stop()V

    .line 6
    new-instance p1, Landroidx/media3/session/SessionResult;

    const/4 p2, 0x0

    invoke-direct {p1, p2}, Landroidx/media3/session/SessionResult;-><init>(I)V

    invoke-static {p1}, Lcom/google/common/util/concurrent/Futures;->immediateFuture(Ljava/lang/Object;)Lcom/google/common/util/concurrent/ListenableFuture;

    move-result-object p1

    return-object p1

    .line 9
    :cond_2e
    new-instance p1, Landroidx/media3/session/SessionResult;

    const/4 p2, -0x6

    invoke-direct {p1, p2}, Landroidx/media3/session/SessionResult;-><init>(I)V

    invoke-static {p1}, Lcom/google/common/util/concurrent/Futures;->immediateFuture(Ljava/lang/Object;)Lcom/google/common/util/concurrent/ListenableFuture;

    move-result-object p1

    return-object p1
.end method

.method public onDisconnected(Landroidx/media3/session/MediaSession;Landroidx/media3/session/MediaSession$ControllerInfo;)V
    .registers 3

    .line 1
    invoke-super {p0, p1, p2}, Landroidx/media3/session/MediaLibraryService$MediaLibrarySession$Callback;->onDisconnected(Landroidx/media3/session/MediaSession;Landroidx/media3/session/MediaSession$ControllerInfo;)V

    return-void
.end method

.method public onPostConnect(Landroidx/media3/session/MediaSession;Landroidx/media3/session/MediaSession$ControllerInfo;)V
    .registers 5

    .line 1
    invoke-virtual {p1}, Landroidx/media3/session/MediaSession;->getPlayer()Landroidx/media3/common/Player;

    move-result-object v0

    invoke-interface {v0}, Landroidx/media3/common/Player;->getPlaybackState()I

    move-result v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_f

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/w;->e:Ljava/util/List;

    const/4 v1, 0x0

    goto :goto_11

    :cond_f
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/w;->e:Ljava/util/List;

    :goto_11
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/media3/session/CommandButton;

    .line 2
    invoke-virtual {p2}, Landroidx/media3/session/MediaSession$ControllerInfo;->getControllerVersion()I

    move-result v1

    if-eqz v1, :cond_24

    .line 3
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-virtual {p1, p2, v0}, Landroidx/media3/session/MediaSession;->setCustomLayout(Landroidx/media3/session/MediaSession$ControllerInfo;Ljava/util/List;)Lcom/google/common/util/concurrent/ListenableFuture;

    :cond_24
    return-void
.end method
