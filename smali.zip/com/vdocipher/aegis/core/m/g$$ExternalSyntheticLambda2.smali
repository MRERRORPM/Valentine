# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/m/g;

.field public final synthetic f$1:Lcom/vdocipher/aegis/core/m/g$b;

.field public final synthetic f$2:Lcom/vdocipher/aegis/media/ErrorDescription;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/m/g;Lcom/vdocipher/aegis/core/m/g$b;Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/m/g;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda2;->f$1:Lcom/vdocipher/aegis/core/m/g$b;

    iput-object p3, p0, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda2;->f$2:Lcom/vdocipher/aegis/media/ErrorDescription;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/m/g;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda2;->f$1:Lcom/vdocipher/aegis/core/m/g$b;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/g$$ExternalSyntheticLambda2;->f$2:Lcom/vdocipher/aegis/media/ErrorDescription;

    invoke-static {v0, v1, v2}, Lcom/vdocipher/aegis/core/m/g;->$r8$lambda$AKAlgos5Ya9Q1wUsrTTjbZrOO7A(Lcom/vdocipher/aegis/core/m/g;Lcom/vdocipher/aegis/core/m/g$b;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    return-void
.end method
