# classes14.dex

.class public final Lcom/vdocipher/aegis/core/m/u$b;
.super Landroidx/media3/exoplayer/upstream/DefaultLoadErrorHandlingPolicy;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Landroidx/media3/exoplayer/upstream/DefaultLoadErrorHandlingPolicy;-><init>()V

    return-void
.end method


# virtual methods
.method public getRetryDelayMsFor(Landroidx/media3/exoplayer/upstream/LoadErrorHandlingPolicy$LoadErrorInfo;)J
    .registers 4

    .line 1
    iget-object v0, p1, Landroidx/media3/exoplayer/upstream/LoadErrorHandlingPolicy$LoadErrorInfo;->exception:Ljava/io/IOException;

    .line 2
    instance-of v1, v0, Lcom/vdocipher/aegis/core/m/u$c;

    if-eqz v1, :cond_12

    .line 3
    check-cast v0, Lcom/vdocipher/aegis/core/m/u$c;

    iget-boolean v0, v0, Lcom/vdocipher/aegis/core/m/u$c;->e:Z

    if-nez v0, :cond_12

    const-wide v0, -0x7fffffffffffffffL  # -4.9E-324

    return-wide v0

    .line 7
    :cond_12
    invoke-super {p0, p1}, Landroidx/media3/exoplayer/upstream/DefaultLoadErrorHandlingPolicy;->getRetryDelayMsFor(Landroidx/media3/exoplayer/upstream/LoadErrorHandlingPolicy$LoadErrorInfo;)J

    move-result-wide v0

    return-wide v0
.end method
