# classes14.dex

.class public Lcom/vdocipher/aegis/core/m/a0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/media3/common/Player$Listener;
.implements Landroidx/media3/exoplayer/analytics/AnalyticsListener;
.implements Landroidx/media3/exoplayer/analytics/PlaybackStatsListener$Callback;
.implements Landroid/os/Handler$Callback;


# instance fields
.field final a:Landroid/os/Handler;

.field private b:Lcom/vdocipher/aegis/core/d/k;

.field private c:Landroid/content/Context;

.field private final d:Landroidx/media3/exoplayer/ExoPlayer;

.field private e:Landroidx/media3/common/MediaItem;

.field private final f:Landroidx/media3/exoplayer/analytics/PlaybackStatsListener;

.field private g:J

.field private h:J

.field private i:J

.field private j:Z

.field private k:Ljava/util/Set;

.field private l:[I

.field private m:Z

.field private n:Z

.field o:I

.field private final p:Lcom/vdocipher/aegis/core/k/c;

.field private q:Ljava/lang/Runnable;

.field private r:Ljava/lang/Runnable;

.field private s:Ljava/lang/Runnable;

.field private final t:Landroid/content/BroadcastReceiver;

.field private final u:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/media3/exoplayer/ExoPlayer;Lcom/vdocipher/aegis/core/k/c;Landroidx/media3/exoplayer/analytics/PlaybackStatsListener;)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    .line 5
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->e:Landroidx/media3/common/MediaItem;

    const-wide/16 v0, 0x0

    .line 8
    iput-wide v0, p0, Lcom/vdocipher/aegis/core/m/a0;->g:J

    .line 9
    iput-wide v0, p0, Lcom/vdocipher/aegis/core/m/a0;->h:J

    .line 10
    iput-wide v0, p0, Lcom/vdocipher/aegis/core/m/a0;->i:J

    const/4 v0, 0x0

    .line 13
    new-array v1, v0, [I

    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->l:[I

    .line 17
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/m/a0;->m:Z

    .line 18
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/m/a0;->n:Z

    const/4 v0, -0x1

    .line 19
    iput v0, p0, Lcom/vdocipher/aegis/core/m/a0;->o:I

    .line 25
    new-instance v0, Lcom/vdocipher/aegis/core/m/a0$a;

    invoke-direct {v0, p0}, Lcom/vdocipher/aegis/core/m/a0$a;-><init>(Lcom/vdocipher/aegis/core/m/a0;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->q:Ljava/lang/Runnable;

    .line 40
    new-instance v0, Lcom/vdocipher/aegis/core/m/a0$b;

    invoke-direct {v0, p0}, Lcom/vdocipher/aegis/core/m/a0$b;-><init>(Lcom/vdocipher/aegis/core/m/a0;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->r:Ljava/lang/Runnable;

    .line 66
    new-instance v0, Lcom/vdocipher/aegis/core/m/a0$c;

    invoke-direct {v0, p0}, Lcom/vdocipher/aegis/core/m/a0$c;-><init>(Lcom/vdocipher/aegis/core/m/a0;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->s:Ljava/lang/Runnable;

    .line 103
    new-instance v0, Lcom/vdocipher/aegis/core/m/a0$d;

    invoke-direct {v0, p0}, Lcom/vdocipher/aegis/core/m/a0$d;-><init>(Lcom/vdocipher/aegis/core/m/a0;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->t:Landroid/content/BroadcastReceiver;

    .line 119
    new-instance v1, Lcom/vdocipher/aegis/core/m/a0$e;

    invoke-direct {v1, p0}, Lcom/vdocipher/aegis/core/m/a0$e;-><init>(Lcom/vdocipher/aegis/core/m/a0;)V

    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->u:Ljava/lang/Runnable;

    .line 134
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/a0;->c:Landroid/content/Context;

    .line 135
    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/a0;->d:Landroidx/media3/exoplayer/ExoPlayer;

    .line 136
    iput-object p4, p0, Lcom/vdocipher/aegis/core/m/a0;->f:Landroidx/media3/exoplayer/analytics/PlaybackStatsListener;

    .line 137
    iput-object p3, p0, Lcom/vdocipher/aegis/core/m/a0;->p:Lcom/vdocipher/aegis/core/k/c;

    if-eqz p2, :cond_4c

    .line 139
    invoke-interface {p2, p4}, Landroidx/media3/exoplayer/ExoPlayer;->addAnalyticsListener(Landroidx/media3/exoplayer/analytics/AnalyticsListener;)V

    .line 141
    :cond_4c
    new-instance p2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p3

    invoke-direct {p2, p3, p0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    .line 144
    new-instance p2, Landroid/content/IntentFilter;

    const-string p3, "action_playback_data"

    invoke-direct {p2, p3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    .line 145
    invoke-static {p1}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object p1

    invoke-virtual {p1, v0, p2}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/m/a0;J)J
    .registers 3

    .line 4
    iput-wide p1, p0, Lcom/vdocipher/aegis/core/m/a0;->i:J

    return-wide p1
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/m/a0;)Lcom/vdocipher/aegis/core/d/k;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    return-object p0
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/m/a0;Ljava/util/Set;)Ljava/util/Set;
    .registers 2

    .line 3
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/a0;->k:Ljava/util/Set;

    return-object p1
.end method

.method private a(Landroidx/media3/common/MediaItem;)V
    .registers 4

    if-eqz p1, :cond_1c

    .line 5
    iget-object v0, p1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    if-eqz v0, :cond_1c

    .line 6
    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->a(Landroidx/media3/common/MediaItem;)Lcom/vdocipher/aegis/core/p/b;

    move-result-object p1

    if-eqz p1, :cond_1c

    .line 9
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/p/b;->c()Z

    move-result v0

    if-eqz v0, :cond_1c

    .line 10
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->p:Lcom/vdocipher/aegis/core/k/c;

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/p/b;->a()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Lcom/vdocipher/aegis/core/k/c;->b(Ljava/lang/String;Z)Z

    :cond_1c
    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/m/a0;Z)Z
    .registers 2

    .line 2
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/a0;->j:Z

    return p1
.end method

.method static synthetic b(Lcom/vdocipher/aegis/core/m/a0;)Ljava/lang/String;
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/a0;->d()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private b()V
    .registers 5

    .line 15
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->r:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 16
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->r:Ljava/lang/Runnable;

    const-wide/16 v2, 0x1388

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method static synthetic c(Lcom/vdocipher/aegis/core/m/a0;)J
    .registers 3

    .line 1
    iget-wide v0, p0, Lcom/vdocipher/aegis/core/m/a0;->h:J

    return-wide v0
.end method

.method private c()V
    .registers 5

    .line 2
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/a0;->m:Z

    if-eqz v0, :cond_5

    return-void

    .line 6
    :cond_5
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->d:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {v0}, Landroidx/media3/exoplayer/ExoPlayer;->getDuration()J

    move-result-wide v0

    const-wide v2, -0x7fffffffffffffffL  # -4.9E-324

    cmp-long v0, v0, v2

    if-eqz v0, :cond_17

    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/m/a0;->m:Z

    .line 9
    :cond_17
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/a0;->g()V

    .line 10
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/a0;->f()V

    .line 11
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/a0;->b()V

    .line 12
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->u:Ljava/lang/Runnable;

    const-wide/32 v2, 0x493e0

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method static synthetic d(Lcom/vdocipher/aegis/core/m/a0;)J
    .registers 5

    .line 1
    iget-wide v0, p0, Lcom/vdocipher/aegis/core/m/a0;->h:J

    const-wide/16 v2, 0x1

    add-long/2addr v2, v0

    iput-wide v2, p0, Lcom/vdocipher/aegis/core/m/a0;->h:J

    return-wide v0
.end method

.method private d()Ljava/lang/String;
    .registers 24

    move-object/from16 v0, p0

    .line 2
    iget-object v1, v0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    .line 3
    iget-object v2, v0, Lcom/vdocipher/aegis/core/m/a0;->d:Landroidx/media3/exoplayer/ExoPlayer;

    const-wide/16 v3, 0x0

    if-nez v2, :cond_c

    move-wide v5, v3

    goto :goto_17

    .line 4
    :cond_c
    invoke-interface {v2}, Landroidx/media3/exoplayer/ExoPlayer;->getBufferedPosition()J

    move-result-wide v5

    iget-object v2, v0, Lcom/vdocipher/aegis/core/m/a0;->d:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {v2}, Landroidx/media3/exoplayer/ExoPlayer;->getCurrentPosition()J

    move-result-wide v7

    sub-long/2addr v5, v7

    :goto_17
    cmp-long v2, v5, v3

    if-lez v2, :cond_1c

    move-wide v3, v5

    :cond_1c
    const/4 v2, 0x0

    if-nez v1, :cond_21

    move v5, v2

    goto :goto_26

    .line 8
    :cond_21
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/d/k;->b()I

    move-result v1

    move v5, v1

    .line 9
    :goto_26
    iget-object v1, v0, Lcom/vdocipher/aegis/core/m/a0;->d:Landroidx/media3/exoplayer/ExoPlayer;

    const-wide/16 v6, 0x3e8

    if-nez v1, :cond_2e

    move v1, v2

    goto :goto_34

    :cond_2e
    invoke-interface {v1}, Landroidx/media3/exoplayer/ExoPlayer;->getCurrentPosition()J

    move-result-wide v8

    div-long/2addr v8, v6

    long-to-int v1, v8

    :goto_34
    div-long/2addr v3, v6

    long-to-int v7, v3

    .line 11
    iget-object v3, v0, Lcom/vdocipher/aegis/core/m/a0;->d:Landroidx/media3/exoplayer/ExoPlayer;

    if-nez v3, :cond_3c

    const/4 v3, 0x3

    goto :goto_4c

    :cond_3c
    iget-boolean v4, v0, Lcom/vdocipher/aegis/core/m/a0;->n:Z

    invoke-interface {v3}, Landroidx/media3/exoplayer/ExoPlayer;->getPlaybackState()I

    move-result v3

    iget-object v6, v0, Lcom/vdocipher/aegis/core/m/a0;->d:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {v6}, Landroidx/media3/exoplayer/ExoPlayer;->getPlayWhenReady()Z

    move-result v6

    invoke-static {v4, v3, v6}, Lcom/vdocipher/aegis/core/m/c;->a(ZIZ)I

    move-result v3

    :goto_4c
    move v8, v3

    iget-wide v3, v0, Lcom/vdocipher/aegis/core/m/a0;->g:J

    long-to-int v9, v3

    iget-wide v3, v0, Lcom/vdocipher/aegis/core/m/a0;->h:J

    long-to-int v10, v3

    iget-object v3, v0, Lcom/vdocipher/aegis/core/m/a0;->d:Landroidx/media3/exoplayer/ExoPlayer;

    if-eqz v3, :cond_61

    .line 15
    invoke-interface {v3}, Landroidx/media3/exoplayer/ExoPlayer;->getPlaybackState()I

    move-result v3

    const/4 v4, 0x2

    if-ne v3, v4, :cond_61

    const/4 v3, 0x1

    move v13, v3

    goto :goto_62

    :cond_61
    move v13, v2

    :goto_62
    iget-boolean v3, v0, Lcom/vdocipher/aegis/core/m/a0;->j:Z

    iget-object v4, v0, Lcom/vdocipher/aegis/core/m/a0;->k:Ljava/util/Set;

    iget-object v6, v0, Lcom/vdocipher/aegis/core/m/a0;->d:Landroidx/media3/exoplayer/ExoPlayer;

    .line 22
    invoke-interface {v6}, Landroidx/media3/exoplayer/ExoPlayer;->getVideoFormat()Landroidx/media3/common/Format;

    move-result-object v6

    invoke-static {v3, v4, v6}, Lcom/vdocipher/aegis/core/t/d;->a(ZLjava/util/Set;Landroidx/media3/common/Format;)Ljava/lang/String;

    move-result-object v20

    .line 23
    iget-object v3, v0, Lcom/vdocipher/aegis/core/m/a0;->d:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {v3}, Landroidx/media3/exoplayer/ExoPlayer;->getVideoFormat()Landroidx/media3/common/Format;

    move-result-object v3

    if-eqz v3, :cond_80

    iget-object v2, v0, Lcom/vdocipher/aegis/core/m/a0;->d:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {v2}, Landroidx/media3/exoplayer/ExoPlayer;->getVideoFormat()Landroidx/media3/common/Format;

    move-result-object v2

    iget v2, v2, Landroidx/media3/common/Format;->bitrate:I

    :cond_80
    move/from16 v21, v2

    iget-object v2, v0, Lcom/vdocipher/aegis/core/m/a0;->d:Landroidx/media3/exoplayer/ExoPlayer;

    .line 24
    invoke-interface {v2}, Landroidx/media3/exoplayer/ExoPlayer;->getCurrentTracks()Landroidx/media3/common/Tracks;

    move-result-object v2

    invoke-static {v2}, Lcom/vdocipher/aegis/core/t/d;->a(Landroidx/media3/common/Tracks;)Ljava/lang/String;

    move-result-object v22

    const-wide/high16 v11, 0x3ff0000000000000L  # 1.0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x1

    const/16 v18, 0x1

    const/16 v19, 0x1

    move v6, v1

    .line 25
    invoke-static/range {v5 .. v22}, Lcom/vdocipher/aegis/core/d/k;->a(IIIIIIDZZIIZZZLjava/lang/String;ILjava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    .line 45
    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method static synthetic e(Lcom/vdocipher/aegis/core/m/a0;)Landroid/content/Context;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/a0;->c:Landroid/content/Context;

    return-object p0
.end method

.method static synthetic f(Lcom/vdocipher/aegis/core/m/a0;)Ljava/lang/Runnable;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/a0;->s:Ljava/lang/Runnable;

    return-object p0
.end method

.method private f()V
    .registers 3

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->q:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->q:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method static synthetic g(Lcom/vdocipher/aegis/core/m/a0;)Landroidx/media3/exoplayer/analytics/PlaybackStatsListener;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/a0;->f:Landroidx/media3/exoplayer/analytics/PlaybackStatsListener;

    return-object p0
.end method

.method private g()V
    .registers 9

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->d:Landroidx/media3/exoplayer/ExoPlayer;

    invoke-interface {v0}, Landroidx/media3/exoplayer/ExoPlayer;->getDuration()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    const/4 v5, 0x0

    if-lez v4, :cond_1c

    const-wide/32 v6, 0xa4cb80

    cmp-long v4, v0, v6

    if-gez v4, :cond_1c

    .line 5
    sget-object v4, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v4, v0, v1}, Ljava/util/concurrent/TimeUnit;->toSeconds(J)J

    move-result-wide v0

    long-to-int v0, v0

    goto :goto_1d

    :cond_1c
    move v0, v5

    .line 6
    :goto_1d
    new-array v0, v0, [I

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->l:[I

    .line 7
    invoke-static {v0, v5}, Ljava/util/Arrays;->fill([II)V

    .line 8
    iput-wide v2, p0, Lcom/vdocipher/aegis/core/m/a0;->i:J

    .line 9
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->s:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 10
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->s:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method static synthetic h(Lcom/vdocipher/aegis/core/m/a0;)Ljava/lang/Runnable;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/a0;->u:Ljava/lang/Runnable;

    return-object p0
.end method

.method static synthetic i(Lcom/vdocipher/aegis/core/m/a0;)Ljava/lang/Runnable;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/a0;->q:Ljava/lang/Runnable;

    return-object p0
.end method

.method static synthetic j(Lcom/vdocipher/aegis/core/m/a0;)Landroidx/media3/exoplayer/ExoPlayer;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/a0;->d:Landroidx/media3/exoplayer/ExoPlayer;

    return-object p0
.end method

.method static synthetic k(Lcom/vdocipher/aegis/core/m/a0;)Landroidx/media3/common/MediaItem;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/a0;->e:Landroidx/media3/common/MediaItem;

    return-object p0
.end method

.method static synthetic l(Lcom/vdocipher/aegis/core/m/a0;)Lcom/vdocipher/aegis/core/k/c;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/a0;->p:Lcom/vdocipher/aegis/core/k/c;

    return-object p0
.end method

.method static synthetic m(Lcom/vdocipher/aegis/core/m/a0;)Ljava/lang/Runnable;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/a0;->r:Ljava/lang/Runnable;

    return-object p0
.end method

.method static synthetic n(Lcom/vdocipher/aegis/core/m/a0;)J
    .registers 3

    .line 1
    iget-wide v0, p0, Lcom/vdocipher/aegis/core/m/a0;->i:J

    return-wide v0
.end method

.method static synthetic o(Lcom/vdocipher/aegis/core/m/a0;)J
    .registers 3

    .line 1
    iget-wide v0, p0, Lcom/vdocipher/aegis/core/m/a0;->g:J

    return-wide v0
.end method

.method static synthetic p(Lcom/vdocipher/aegis/core/m/a0;)J
    .registers 5

    .line 1
    iget-wide v0, p0, Lcom/vdocipher/aegis/core/m/a0;->g:J

    const-wide/16 v2, 0x1

    add-long/2addr v2, v0

    iput-wide v2, p0, Lcom/vdocipher/aegis/core/m/a0;->g:J

    return-wide v0
.end method

.method static synthetic q(Lcom/vdocipher/aegis/core/m/a0;)[I
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/a0;->l:[I

    return-object p0
.end method


# virtual methods
.method public a()V
    .registers 3

    .line 11
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->c:Landroid/content/Context;

    invoke-static {v0}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->t:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v1}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 13
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->u:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 14
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    if-eqz v0, :cond_25

    .line 15
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/m/a0;->e()V

    .line 16
    invoke-static {}, Lcom/vdocipher/aegis/core/d/i;->a()Lcom/vdocipher/aegis/core/d/i;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    invoke-virtual {v0, v1}, Lcom/vdocipher/aegis/core/d/i;->a(Lcom/vdocipher/aegis/core/d/k;)V

    const/4 v0, 0x0

    .line 17
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    .line 19
    :cond_25
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->e:Landroidx/media3/common/MediaItem;

    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/m/a0;->a(Landroidx/media3/common/MediaItem;)V

    .line 20
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->s:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 21
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->q:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 22
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->r:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    return-void
.end method

.method b(Landroidx/media3/common/MediaItem;)V
    .registers 5

    if-eqz p1, :cond_35

    .line 2
    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->a(Landroidx/media3/common/MediaItem;)Lcom/vdocipher/aegis/core/p/b;

    move-result-object v0

    .line 3
    invoke-static {}, Lcom/vdocipher/aegis/core/d/i;->a()Lcom/vdocipher/aegis/core/d/i;

    move-result-object v1

    iget-object v2, p1, Landroidx/media3/common/MediaItem;->mediaId:Ljava/lang/String;

    if-eqz v0, :cond_16

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/p/b;->c()Z

    move-result v0

    if-eqz v0, :cond_16

    const/4 v0, 0x1

    goto :goto_17

    :cond_16
    const/4 v0, 0x0

    :goto_17
    invoke-virtual {v1, v2, v0}, Lcom/vdocipher/aegis/core/d/i;->a(Ljava/lang/String;Z)Lcom/vdocipher/aegis/core/d/k;

    move-result-object v0

    .line 4
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    if-eq v1, v0, :cond_35

    .line 7
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->e:Landroidx/media3/common/MediaItem;

    invoke-direct {p0, v1}, Lcom/vdocipher/aegis/core/m/a0;->a(Landroidx/media3/common/MediaItem;)V

    .line 10
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    if-eqz v1, :cond_31

    .line 11
    invoke-static {}, Lcom/vdocipher/aegis/core/d/i;->a()Lcom/vdocipher/aegis/core/d/i;

    move-result-object v1

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    invoke-virtual {v1, v2}, Lcom/vdocipher/aegis/core/d/i;->a(Lcom/vdocipher/aegis/core/d/k;)V

    .line 13
    :cond_31
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    .line 14
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/a0;->e:Landroidx/media3/common/MediaItem;

    :cond_35
    return-void
.end method

.method public e()V
    .registers 3

    .line 2
    :try_start_0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    if-eqz v0, :cond_20

    .line 4
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->f:Landroidx/media3/exoplayer/analytics/PlaybackStatsListener;

    if-eqz v1, :cond_f

    .line 5
    invoke-virtual {v1}, Landroidx/media3/exoplayer/analytics/PlaybackStatsListener;->getPlaybackStats()Landroidx/media3/exoplayer/analytics/PlaybackStats;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/d/k;Landroidx/media3/exoplayer/analytics/PlaybackStats;)V

    .line 7
    :cond_f
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    const-string/jumbo v1, "stop"

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/m/c;->b(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    .line 10
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/a0;->d()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;)V
    :try_end_20
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_20} :catch_21

    :cond_20
    return-void

    :catch_21
    move-exception v0

    .line 13
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "VdoServiceSM"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public handleMessage(Landroid/os/Message;)Z
    .registers 2

    const/4 p1, 0x0

    return p1
.end method

.method public onAudioDecoderInitialized(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Ljava/lang/String;JJ)V
    .registers 7

    .line 1
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    if-nez p1, :cond_5

    return-void

    .line 3
    :cond_5
    :try_start_5
    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    .line 4
    const-string p1, "acdc"

    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_d} :catch_e

    return-void

    :catch_e
    move-exception p1

    .line 6
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "VdoServiceSM"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public onDrmKeysLoaded(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;)V
    .registers 3

    .line 1
    invoke-super {p0, p1}, Landroidx/media3/exoplayer/analytics/AnalyticsListener;->onDrmKeysLoaded(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;)V

    .line 2
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    if-nez p1, :cond_8

    return-void

    .line 3
    :cond_8
    const-string v0, "Key Loaded"

    invoke-static {p1, v0}, Lcom/vdocipher/aegis/core/m/c;->h(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    return-void
.end method

.method public onDrmKeysRemoved(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;)V
    .registers 3

    .line 1
    invoke-super {p0, p1}, Landroidx/media3/exoplayer/analytics/AnalyticsListener;->onDrmKeysRemoved(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;)V

    .line 2
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    if-nez p1, :cond_8

    return-void

    .line 3
    :cond_8
    const-string v0, "Keys Removed"

    invoke-static {p1, v0}, Lcom/vdocipher/aegis/core/m/c;->h(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    return-void
.end method

.method public onDrmKeysRestored(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;)V
    .registers 3

    .line 1
    invoke-super {p0, p1}, Landroidx/media3/exoplayer/analytics/AnalyticsListener;->onDrmKeysRestored(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;)V

    .line 2
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    if-nez p1, :cond_8

    return-void

    .line 3
    :cond_8
    const-string v0, "Key Restored"

    invoke-static {p1, v0}, Lcom/vdocipher/aegis/core/m/c;->h(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    return-void
.end method

.method public onDrmSessionAcquired(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;I)V
    .registers 3

    .line 1
    invoke-super {p0, p1, p2}, Landroidx/media3/exoplayer/analytics/AnalyticsListener;->onDrmSessionAcquired(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;I)V

    .line 2
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    if-nez p1, :cond_8

    return-void

    .line 3
    :cond_8
    const-string p2, "Session Acquired"

    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/m/c;->h(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    return-void
.end method

.method public onDrmSessionManagerError(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Ljava/lang/Exception;)V
    .registers 3

    .line 1
    invoke-super {p0, p1, p2}, Landroidx/media3/exoplayer/analytics/AnalyticsListener;->onDrmSessionManagerError(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Ljava/lang/Exception;)V

    .line 2
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    if-nez p1, :cond_8

    return-void

    .line 3
    :cond_8
    const-string p2, "Session Manager Error"

    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/m/c;->h(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    return-void
.end method

.method public onDrmSessionReleased(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;)V
    .registers 3

    .line 1
    invoke-super {p0, p1}, Landroidx/media3/exoplayer/analytics/AnalyticsListener;->onDrmSessionReleased(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;)V

    .line 2
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    if-nez p1, :cond_8

    return-void

    .line 3
    :cond_8
    const-string v0, "Session Released"

    invoke-static {p1, v0}, Lcom/vdocipher/aegis/core/m/c;->h(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    return-void
.end method

.method public onIsPlayingChanged(Z)V
    .registers 3

    .line 1
    invoke-super {p0, p1}, Landroidx/media3/common/Player$Listener;->onIsPlayingChanged(Z)V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    if-eqz p1, :cond_a

    const-string p1, "play"

    goto :goto_c

    :cond_a
    const-string p1, "pause"

    :goto_c
    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/m/c;->b(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    return-void
.end method

.method public onLoadCanceled(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Landroidx/media3/exoplayer/source/LoadEventInfo;Landroidx/media3/exoplayer/source/MediaLoadData;)V
    .registers 4

    return-void
.end method

.method public onLoadCompleted(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Landroidx/media3/exoplayer/source/LoadEventInfo;Landroidx/media3/exoplayer/source/MediaLoadData;)V
    .registers 4

    .line 1
    invoke-super {p0, p1, p2, p3}, Landroidx/media3/exoplayer/analytics/AnalyticsListener;->onLoadCompleted(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Landroidx/media3/exoplayer/source/LoadEventInfo;Landroidx/media3/exoplayer/source/MediaLoadData;)V

    return-void
.end method

.method public onLoadError(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Landroidx/media3/exoplayer/source/LoadEventInfo;Landroidx/media3/exoplayer/source/MediaLoadData;Ljava/io/IOException;Z)V
    .registers 6

    return-void
.end method

.method public onLoadStarted(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Landroidx/media3/exoplayer/source/LoadEventInfo;Landroidx/media3/exoplayer/source/MediaLoadData;)V
    .registers 4

    .line 1
    invoke-super {p0, p1, p2, p3}, Landroidx/media3/exoplayer/analytics/AnalyticsListener;->onLoadStarted(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Landroidx/media3/exoplayer/source/LoadEventInfo;Landroidx/media3/exoplayer/source/MediaLoadData;)V

    return-void
.end method

.method public onMediaItemTransition(Landroidx/media3/common/MediaItem;I)V
    .registers 4

    .line 1
    invoke-super {p0, p1, p2}, Landroidx/media3/common/Player$Listener;->onMediaItemTransition(Landroidx/media3/common/MediaItem;I)V

    const/4 p2, 0x0

    .line 4
    iput-boolean p2, p0, Lcom/vdocipher/aegis/core/m/a0;->m:Z

    .line 7
    iput-boolean p2, p0, Lcom/vdocipher/aegis/core/m/a0;->n:Z

    .line 14
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/a0;->e:Landroidx/media3/common/MediaItem;

    if-eqz p2, :cond_1d

    iget-object p2, p2, Landroidx/media3/common/MediaItem;->mediaId:Ljava/lang/String;

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_1d

    .line 15
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/a0;->p:Lcom/vdocipher/aegis/core/k/c;

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->e:Landroidx/media3/common/MediaItem;

    iget-object v0, v0, Landroidx/media3/common/MediaItem;->mediaId:Ljava/lang/String;

    invoke-virtual {p2, v0}, Lcom/vdocipher/aegis/core/k/c;->d(Ljava/lang/String;)V

    :cond_1d
    if-nez p1, :cond_22

    .line 21
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/m/a0;->e()V

    .line 25
    :cond_22
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/m/a0;->b(Landroidx/media3/common/MediaItem;)V

    return-void
.end method

.method public onMediaMetadataChanged(Landroidx/media3/common/MediaMetadata;)V
    .registers 2

    .line 1
    invoke-super {p0, p1}, Landroidx/media3/common/Player$Listener;->onMediaMetadataChanged(Landroidx/media3/common/MediaMetadata;)V

    return-void
.end method

.method public onPlaybackStateChanged(I)V
    .registers 6

    .line 1
    invoke-super {p0, p1}, Landroidx/media3/common/Player$Listener;->onPlaybackStateChanged(I)V

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-ne p1, v1, :cond_11

    .line 2
    iget v2, p0, Lcom/vdocipher/aegis/core/m/a0;->o:I

    const/4 v3, -0x1

    if-eq v2, v3, :cond_11

    .line 4
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/m/a0;->m:Z

    .line 6
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/m/a0;->n:Z

    goto :goto_25

    :cond_11
    const/4 v2, 0x4

    if-ne p1, v2, :cond_1d

    .line 8
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    const-string/jumbo v3, "videoEnded"

    invoke-static {v2, v3}, Lcom/vdocipher/aegis/core/m/c;->b(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    goto :goto_25

    :cond_1d
    const/4 v2, 0x3

    if-ne p1, v2, :cond_25

    .line 10
    iput-boolean v1, p0, Lcom/vdocipher/aegis/core/m/a0;->n:Z

    .line 11
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/a0;->c()V

    .line 14
    :cond_25
    :goto_25
    iget v2, p0, Lcom/vdocipher/aegis/core/m/a0;->o:I

    const/4 v3, 0x2

    if-eq v2, v3, :cond_31

    if-ne p1, v3, :cond_31

    .line 15
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    invoke-static {v2, v1}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/d/k;Z)V

    .line 17
    :cond_31
    iget v1, p0, Lcom/vdocipher/aegis/core/m/a0;->o:I

    if-ne v1, v3, :cond_3c

    if-eq p1, v3, :cond_3c

    .line 18
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/d/k;Z)V

    .line 20
    :cond_3c
    iput p1, p0, Lcom/vdocipher/aegis/core/m/a0;->o:I

    return-void
.end method

.method public onPlaybackStatsReady(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Landroidx/media3/exoplayer/analytics/PlaybackStats;)V
    .registers 3

    return-void
.end method

.method public onPlayerError(Landroidx/media3/common/PlaybackException;)V
    .registers 4

    .line 1
    invoke-super {p0, p1}, Landroidx/media3/common/Player$Listener;->onPlayerError(Landroidx/media3/common/PlaybackException;)V

    .line 2
    new-instance v0, Landroid/content/Intent;

    const-string v1, "action_vdo_playback_exception"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 3
    const-string/jumbo v1, "vdo_playback_exception"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 4
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/a0;->c:Landroid/content/Context;

    invoke-static {p1}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z

    return-void
.end method

.method public onVideoDecoderInitialized(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Ljava/lang/String;JJ)V
    .registers 7

    .line 1
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    if-nez p1, :cond_5

    return-void

    .line 3
    :cond_5
    :try_start_5
    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/m/c;->g(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    .line 4
    const-string/jumbo p1, "vcdc"

    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_e} :catch_f

    return-void

    :catch_f
    move-exception p1

    .line 6
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "VdoServiceSM"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public onVideoSizeChanged(Landroidx/media3/common/VideoSize;)V
    .registers 6

    .line 1
    invoke-super {p0, p1}, Landroidx/media3/common/Player$Listener;->onVideoSizeChanged(Landroidx/media3/common/VideoSize;)V

    .line 2
    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    iget v1, p1, Landroidx/media3/common/VideoSize;->width:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget v2, p1, Landroidx/media3/common/VideoSize;->height:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iget v3, p1, Landroidx/media3/common/VideoSize;->pixelWidthHeightRatio:F

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    filled-new-array {v1, v2, v3}, [Ljava/lang/Object;

    move-result-object v1

    const-string/jumbo v2, "size: %d x %d (pr %f)"

    invoke-static {v0, v2, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "VdoServiceSM"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 4
    :try_start_27
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->b:Lcom/vdocipher/aegis/core/d/k;

    iget v2, p1, Landroidx/media3/common/VideoSize;->width:I

    iget v3, p1, Landroidx/media3/common/VideoSize;->height:I

    iget p1, p1, Landroidx/media3/common/VideoSize;->pixelWidthHeightRatio:F

    invoke-static {v0, v2, v3, p1}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/d/k;IIF)V
    :try_end_32
    .catch Ljava/lang/Exception; {:try_start_27 .. :try_end_32} :catch_33

    return-void

    :catch_33
    move-exception p1

    .line 6
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public release()V
    .registers 2

    const/4 v0, 0x0

    .line 1
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->s:Ljava/lang/Runnable;

    .line 2
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->q:Ljava/lang/Runnable;

    .line 3
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->r:Ljava/lang/Runnable;

    .line 4
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/a0;->c:Landroid/content/Context;

    return-void
.end method
