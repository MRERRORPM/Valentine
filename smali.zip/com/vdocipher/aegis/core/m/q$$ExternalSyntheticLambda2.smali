# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/m/q;

.field public final synthetic f$1:J


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/m/q;J)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/m/q;

    iput-wide p2, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda2;->f$1:J

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/m/q;

    iget-wide v1, p0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda2;->f$1:J

    invoke-static {v0, v1, v2}, Lcom/vdocipher/aegis/core/m/q;->$r8$lambda$S_x_mSPAl3a6QqRAGdUF4qEn2Kg(Lcom/vdocipher/aegis/core/m/q;J)V

    return-void
.end method
