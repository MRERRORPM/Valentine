# classes14.dex

.class abstract Lcom/vdocipher/aegis/core/m/c;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method static a(ZIZ)I
    .registers 3

    if-nez p0, :cond_4

    const/4 p0, -0x1

    return p0

    :cond_4
    const/4 p0, 0x4

    if-ne p1, p0, :cond_9

    const/4 p0, 0x3

    return p0

    :cond_9
    if-eqz p2, :cond_d

    const/4 p0, 0x1

    return p0

    :cond_d
    const/4 p0, 0x2

    return p0
.end method

.method private static a(Lcom/vdocipher/aegis/core/m/p;)Lorg/json/JSONObject;
    .registers 4

    .line 69
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 70
    const-string v1, "hasError"

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 71
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/p;->b:Ljava/lang/String;

    const-string v2, "message"

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 72
    iget p0, p0, Lcom/vdocipher/aegis/core/m/p;->a:I

    const-string/jumbo v1, "vdo"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    return-object v0
.end method

.method static a(Lcom/vdocipher/aegis/core/d/k;IIF)V
    .registers 6

    if-eqz p0, :cond_22

    .line 3
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 4
    const-string/jumbo v1, "w"

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 5
    const-string p1, "h"

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    float-to-double p1, p3

    .line 6
    const-string p3, "pr"

    invoke-virtual {v0, p3, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    .line 8
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo p2, "vsize"

    invoke-virtual {p0, p2, p1}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_22
    return-void
.end method

.method static a(Lcom/vdocipher/aegis/core/d/k;J)V
    .registers 3

    if-eqz p0, :cond_5

    .line 16
    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/core/d/k;->a(J)V

    :cond_5
    return-void
.end method

.method static a(Lcom/vdocipher/aegis/core/d/k;JJ)V
    .registers 7

    if-eqz p0, :cond_1a

    .line 17
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 18
    const-string v1, "license"

    invoke-virtual {v0, v1, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 19
    const-string p1, "playback"

    invoke-virtual {v0, p1, p3, p4}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 20
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "licenseDuration"

    invoke-virtual {p0, p2, p1}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1a
    return-void
.end method

.method static a(Lcom/vdocipher/aegis/core/d/k;Landroidx/media3/exoplayer/analytics/PlaybackStats;)V
    .registers 8

    if-eqz p0, :cond_82

    .line 24
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 25
    sget-object v1, Lcom/vdocipher/aegis/core/z/d;->a:Lcom/vdocipher/aegis/core/z/d;

    invoke-virtual {p1}, Landroidx/media3/exoplayer/analytics/PlaybackStats;->getDroppedFramesRate()F

    move-result v2

    float-to-double v2, v2

    invoke-virtual {v1, v2, v3}, Lcom/vdocipher/aegis/core/z/d;->a(D)D

    move-result-wide v2

    const-string v4, "droppedFramesRate"

    invoke-virtual {v0, v4, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    .line 26
    iget-wide v2, p1, Landroidx/media3/exoplayer/analytics/PlaybackStats;->totalAudioUnderruns:J

    const-string v4, "audioUnderrunRate"

    invoke-virtual {v0, v4, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 27
    iget v2, p1, Landroidx/media3/exoplayer/analytics/PlaybackStats;->totalRebufferCount:I

    const-string v3, "rebufferCount"

    invoke-virtual {v0, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 28
    invoke-virtual {p1}, Landroidx/media3/exoplayer/analytics/PlaybackStats;->getRebufferRate()F

    move-result v2

    float-to-double v2, v2

    invoke-virtual {v1, v2, v3}, Lcom/vdocipher/aegis/core/z/d;->a(D)D

    move-result-wide v2

    const-string v4, "rebufferRate"

    invoke-virtual {v0, v4, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    .line 29
    invoke-virtual {p1}, Landroidx/media3/exoplayer/analytics/PlaybackStats;->getRebufferTimeRatio()F

    move-result v2

    float-to-double v2, v2

    invoke-virtual {v1, v2, v3}, Lcom/vdocipher/aegis/core/z/d;->a(D)D

    move-result-wide v1

    const-string v3, "rebufferTimeRatio"

    invoke-virtual {v0, v3, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    .line 31
    iget-wide v1, p1, Landroidx/media3/exoplayer/analytics/PlaybackStats;->maxRebufferTimeMs:J

    const-wide v3, -0x7fffffffffffffffL  # -4.9E-324

    cmp-long v5, v1, v3

    if-eqz v5, :cond_51

    .line 32
    const-string v5, "maxRebufferTime"

    invoke-virtual {v0, v5, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 34
    :cond_51
    invoke-virtual {p1}, Landroidx/media3/exoplayer/analytics/PlaybackStats;->getMeanBandwidth()I

    move-result v1

    const/4 v2, -0x1

    if-eq v1, v2, :cond_63

    .line 35
    invoke-virtual {p1}, Landroidx/media3/exoplayer/analytics/PlaybackStats;->getMeanBandwidth()I

    move-result v1

    div-int/lit16 v1, v1, 0x3e8

    const-string v2, "meanBandwidth"

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 37
    :cond_63
    iget-wide v1, p1, Landroidx/media3/exoplayer/analytics/PlaybackStats;->totalValidJoinTimeMs:J

    cmp-long v5, v1, v3

    if-eqz v5, :cond_6e

    .line 38
    const-string v5, "joinTime"

    invoke-virtual {v0, v5, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 40
    :cond_6e
    invoke-virtual {p1}, Landroidx/media3/exoplayer/analytics/PlaybackStats;->getMeanSeekTimeMs()J

    move-result-wide v1

    cmp-long v1, v1, v3

    if-eqz v1, :cond_7f

    .line 41
    invoke-virtual {p1}, Landroidx/media3/exoplayer/analytics/PlaybackStats;->getMeanSeekTimeMs()J

    move-result-wide v1

    const-string p1, "meanSeekTime"

    invoke-virtual {v0, p1, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 43
    :cond_7f
    invoke-virtual {p0, v0}, Lcom/vdocipher/aegis/core/d/k;->a(Lorg/json/JSONObject;)V

    :cond_82
    return-void
.end method

.method static a(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V
    .registers 4

    if-eqz p0, :cond_15

    .line 21
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 22
    const-string v1, "cdc"

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 23
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "acdc"

    invoke-virtual {p0, v0, p1}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_15
    return-void
.end method

.method static a(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;Ljava/lang/String;I[Ljava/lang/String;)V
    .registers 5

    if-eqz p0, :cond_5

    .line 2
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;I[Ljava/lang/String;)V

    :cond_5
    return-void
.end method

.method static a(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/m/p;)V
    .registers 7

    if-eqz p0, :cond_65

    .line 56
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 57
    iget-object v1, p3, Lcom/vdocipher/aegis/core/m/p;->c:Lcom/vdocipher/aegis/core/m/d;

    iget-object v1, v1, Lcom/vdocipher/aegis/core/m/d;->a:Ljava/lang/String;

    const-string v2, "name"

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 58
    iget v1, p3, Lcom/vdocipher/aegis/core/m/p;->a:I

    const-string v2, "errorCode"

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 59
    const-string v1, "errorClass"

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 60
    const-string p1, "network"

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 61
    iget-object p1, p3, Lcom/vdocipher/aegis/core/m/p;->c:Lcom/vdocipher/aegis/core/m/d;

    iget p1, p1, Lcom/vdocipher/aegis/core/m/d;->b:I

    const-string/jumbo p2, "statusCode"

    invoke-virtual {v0, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 62
    iget-object p1, p3, Lcom/vdocipher/aegis/core/m/p;->c:Lcom/vdocipher/aegis/core/m/d;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/d;->c:Ljava/lang/String;

    const-string/jumbo p2, "url"

    invoke-virtual {v0, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 63
    iget-object p1, p3, Lcom/vdocipher/aegis/core/m/p;->c:Lcom/vdocipher/aegis/core/m/d;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/d;->d:Ljava/lang/String;

    const/16 p2, 0x3e8

    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    const-string p2, "response"

    invoke-virtual {v0, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 65
    iget-object p1, p3, Lcom/vdocipher/aegis/core/m/p;->c:Lcom/vdocipher/aegis/core/m/d;

    iget-boolean p1, p1, Lcom/vdocipher/aegis/core/m/d;->e:Z

    if-eqz p1, :cond_58

    .line 66
    invoke-static {p3}, Lcom/vdocipher/aegis/core/m/c;->b(Lcom/vdocipher/aegis/core/m/p;)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    const-string p3, "mutedError"

    invoke-virtual {p0, p1, p3, p2}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 68
    :cond_58
    invoke-static {p3}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/m/p;)Lorg/json/JSONObject;

    move-result-object p1

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    const-string p3, "loadError"

    invoke-virtual {p0, p1, p3, p2}, Lcom/vdocipher/aegis/core/d/k;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    :cond_65
    return-void
.end method

.method static a(Lcom/vdocipher/aegis/core/d/k;Lorg/json/JSONArray;)V
    .registers 2

    if-eqz p0, :cond_5

    .line 15
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/d/k;->a(Lorg/json/JSONArray;)V

    :cond_5
    return-void
.end method

.method static a(Lcom/vdocipher/aegis/core/d/k;Lorg/json/JSONObject;)V
    .registers 3

    if-eqz p0, :cond_b

    .line 73
    :try_start_2
    const-string v0, "metaFailed"

    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, v0, p1}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_b} :catch_b

    :catch_b
    :cond_b
    return-void
.end method

.method static a(Lcom/vdocipher/aegis/core/d/k;Z)V
    .registers 2

    if-eqz p0, :cond_c

    if-eqz p1, :cond_7

    .line 9
    const-string p1, "bufferStart"

    goto :goto_9

    :cond_7
    const-string p1, "bufferStop"

    .line 10
    :goto_9
    invoke-static {p0, p1}, Lcom/vdocipher/aegis/core/m/c;->b(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    :cond_c
    return-void
.end method

.method static a(Lcom/vdocipher/aegis/core/d/k;ZI)V
    .registers 5

    if-eqz p0, :cond_1b

    .line 11
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 12
    const-string/jumbo v1, "target"

    invoke-virtual {v0, v1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    if-eqz p1, :cond_12

    .line 13
    const-string p1, "seekStart"

    goto :goto_14

    :cond_12
    const-string p1, "seekComplete"

    .line 14
    :goto_14
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1b
    return-void
.end method

.method static a(Lcom/vdocipher/aegis/core/d/k;[Lcom/vdocipher/aegis/media/Track;)V
    .registers 9

    if-eqz p0, :cond_4e

    .line 44
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    .line 45
    array-length v1, p1

    const/4 v2, 0x0

    :goto_9
    if-ge v2, v1, :cond_44

    aget-object v3, p1, v2

    .line 46
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    .line 47
    iget v5, v3, Lcom/vdocipher/aegis/media/Track;->type:I

    const-string/jumbo v6, "type"

    invoke-virtual {v4, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 48
    iget-object v5, v3, Lcom/vdocipher/aegis/media/Track;->codec:Ljava/lang/String;

    const-string v6, "codec"

    invoke-virtual {v4, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 49
    iget v5, v3, Lcom/vdocipher/aegis/media/Track;->height:I

    const-string v6, "height"

    invoke-virtual {v4, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 50
    iget v5, v3, Lcom/vdocipher/aegis/media/Track;->width:I

    const-string/jumbo v6, "width"

    invoke-virtual {v4, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 51
    iget-object v5, v3, Lcom/vdocipher/aegis/media/Track;->mimeType:Ljava/lang/String;

    const-string v6, "mimeType"

    invoke-virtual {v4, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 52
    iget v3, v3, Lcom/vdocipher/aegis/media/Track;->bitrate:I

    const-string v5, "bitrate"

    invoke-virtual {v4, v5, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 53
    invoke-virtual {v0, v4}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v2, v2, 0x1

    goto :goto_9

    .line 55
    :cond_44
    invoke-virtual {v0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v0, "trackChange"

    invoke-virtual {p0, v0, p1}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_4e
    return-void
.end method

.method private static b(Lcom/vdocipher/aegis/core/m/p;)Ljava/lang/Integer;
    .registers 1

    .line 22
    iget p0, p0, Lcom/vdocipher/aegis/core/m/p;->a:I

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0
.end method

.method static b(Lcom/vdocipher/aegis/core/d/k;J)V
    .registers 3

    if-eqz p0, :cond_5

    .line 6
    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/core/d/k;->b(J)V

    :cond_5
    return-void
.end method

.method static b(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V
    .registers 3

    if-eqz p0, :cond_6

    const/4 v0, 0x0

    .line 21
    invoke-virtual {p0, p1, v0}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_6
    return-void
.end method

.method static b(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/m/p;)V
    .registers 7

    if-eqz p0, :cond_65

    .line 7
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 8
    iget-object v1, p3, Lcom/vdocipher/aegis/core/m/p;->c:Lcom/vdocipher/aegis/core/m/d;

    iget-object v1, v1, Lcom/vdocipher/aegis/core/m/d;->a:Ljava/lang/String;

    const-string v2, "name"

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 9
    iget v1, p3, Lcom/vdocipher/aegis/core/m/p;->a:I

    const-string v2, "errorCode"

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 10
    const-string v1, "errorClass"

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 11
    const-string p1, "network"

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 12
    iget-object p1, p3, Lcom/vdocipher/aegis/core/m/p;->c:Lcom/vdocipher/aegis/core/m/d;

    iget p1, p1, Lcom/vdocipher/aegis/core/m/d;->b:I

    const-string/jumbo p2, "statusCode"

    invoke-virtual {v0, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 13
    iget-object p1, p3, Lcom/vdocipher/aegis/core/m/p;->c:Lcom/vdocipher/aegis/core/m/d;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/d;->c:Ljava/lang/String;

    const-string/jumbo p2, "url"

    invoke-virtual {v0, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 14
    iget-object p1, p3, Lcom/vdocipher/aegis/core/m/p;->c:Lcom/vdocipher/aegis/core/m/d;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/d;->d:Ljava/lang/String;

    const/16 p2, 0x3e8

    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    const-string p2, "response"

    invoke-virtual {v0, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 16
    iget-object p1, p3, Lcom/vdocipher/aegis/core/m/p;->c:Lcom/vdocipher/aegis/core/m/d;

    iget-boolean p1, p1, Lcom/vdocipher/aegis/core/m/d;->e:Z

    if-eqz p1, :cond_58

    .line 17
    invoke-static {p3}, Lcom/vdocipher/aegis/core/m/c;->b(Lcom/vdocipher/aegis/core/m/p;)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    const-string p3, "mutedError"

    invoke-virtual {p0, p1, p3, p2}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 20
    :cond_58
    invoke-static {p3}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/m/p;)Lorg/json/JSONObject;

    move-result-object p1

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    const-string p3, "error"

    invoke-virtual {p0, p1, p3, p2}, Lcom/vdocipher/aegis/core/d/k;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    :cond_65
    return-void
.end method

.method static b(Lcom/vdocipher/aegis/core/d/k;Lorg/json/JSONObject;)V
    .registers 2

    if-eqz p0, :cond_5

    .line 5
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/d/k;->b(Lorg/json/JSONObject;)V

    :cond_5
    return-void
.end method

.method static b(Lcom/vdocipher/aegis/core/d/k;Z)V
    .registers 4

    .line 1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 2
    const-string v1, "newSession"

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 4
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "loaded"

    invoke-virtual {p0, v0, p1}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static c(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V
    .registers 3

    if-eqz p0, :cond_7

    .line 1
    const-string v0, "gotMeta"

    invoke-virtual {p0, v0, p1}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_7
    return-void
.end method

.method static d(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V
    .registers 3

    if-eqz p0, :cond_7

    .line 1
    const-string v0, "invalidMeta"

    invoke-virtual {p0, v0, p1}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_7
    return-void
.end method

.method static e(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V
    .registers 2

    if-eqz p0, :cond_5

    .line 1
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/d/k;->f(Ljava/lang/String;)V

    :cond_5
    return-void
.end method

.method static f(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V
    .registers 9

    const-string/jumbo v0, "userId"

    const-string/jumbo v1, "tags"

    if-eqz p0, :cond_46

    .line 1
    :try_start_8
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 2
    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_19

    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_1a

    :cond_19
    move-object v0, v4

    .line 4
    :goto_1a
    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_25

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v2

    goto :goto_26

    :cond_25
    move-object v2, v4

    :goto_26
    const/4 v3, 0x0

    if-eqz v2, :cond_2e

    .line 5
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v5

    goto :goto_2f

    :cond_2e
    move v5, v3

    :goto_2f
    if-lez v5, :cond_33

    .line 6
    new-array v4, v5, [Ljava/lang/String;

    :cond_33
    if-eqz v4, :cond_40

    :goto_35
    if-ge v3, v5, :cond_40

    .line 9
    invoke-virtual {v2, v3}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_35

    .line 14
    :cond_40
    invoke-virtual {p0, v0, v4}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;[Ljava/lang/String;)V
    :try_end_43
    .catch Lorg/json/JSONException; {:try_start_8 .. :try_end_43} :catch_43

    .line 20
    :catch_43
    invoke-virtual {p0, v1, p1}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_46
    return-void
.end method

.method static g(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V
    .registers 4

    if-eqz p0, :cond_16

    .line 1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 2
    const-string v1, "cdc"

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 3
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v0, "vcdc"

    invoke-virtual {p0, v0, p1}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_16
    return-void
.end method

.method static h(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V
    .registers 4

    if-eqz p0, :cond_15

    .line 1
    :try_start_2
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 2
    const-string v1, "State"

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 3
    const-string p1, "DrmSession"

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, p1, v0}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_15} :catch_15

    :catch_15
    :cond_15
    return-void
.end method

.method static i(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V
    .registers 2

    if-eqz p0, :cond_5

    .line 1
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/d/k;->c(Ljava/lang/String;)V

    :cond_5
    return-void
.end method

.method static j(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V
    .registers 2

    if-eqz p0, :cond_5

    .line 1
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/d/k;->d(Ljava/lang/String;)V

    :cond_5
    return-void
.end method
