# classes14.dex

.class public Lcom/vdocipher/aegis/core/m/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private a:Z

.field private b:Z

.field private c:Z

.field private d:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .registers 2

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/f;->d:Ljava/lang/String;

    return-object v0
.end method

.method public a(Ljava/lang/String;)V
    .registers 2

    .line 3
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/f;->d:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/f;->b:Z

    return-void
.end method

.method public b(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/f;->a:Z

    return-void
.end method

.method public b()Z
    .registers 2

    .line 2
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/f;->a:Z

    return v0
.end method

.method public c(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/f;->c:Z

    return-void
.end method

.method public c()Z
    .registers 2

    .line 2
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/f;->b:Z

    if-nez v0, :cond_8

    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/f;->c:Z

    if-eqz v0, :cond_e

    :cond_8
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/f;->a:Z

    if-nez v0, :cond_e

    const/4 v0, 0x1

    return v0

    :cond_e
    const/4 v0, 0x0

    return v0
.end method

.method public d()Z
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method

.method public e()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/f;->c:Z

    return v0
.end method
