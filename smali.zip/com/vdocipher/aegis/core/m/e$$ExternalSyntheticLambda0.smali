# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/m/e;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/m/e;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/m/e;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/m/e;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/e;->$r8$lambda$U5t6zYNcdV1yOpV-jA_AcJtDE48(Lcom/vdocipher/aegis/core/m/e;)V

    return-void
.end method
