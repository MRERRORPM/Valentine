# classes14.dex

.class final enum Lcom/vdocipher/aegis/core/m/h;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum b:Lcom/vdocipher/aegis/core/m/h;

.field public static final enum c:Lcom/vdocipher/aegis/core/m/h;

.field public static final enum d:Lcom/vdocipher/aegis/core/m/h;

.field public static final enum e:Lcom/vdocipher/aegis/core/m/h;

.field public static final enum f:Lcom/vdocipher/aegis/core/m/h;

.field private static final synthetic g:[Lcom/vdocipher/aegis/core/m/h;


# instance fields
.field private final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lcom/vdocipher/aegis/core/m/h;

    const/4 v1, 0x0

    const-string v2, "dash"

    const-string v3, "DASH"

    invoke-direct {v0, v3, v1, v2}, Lcom/vdocipher/aegis/core/m/h;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lcom/vdocipher/aegis/core/m/h;->b:Lcom/vdocipher/aegis/core/m/h;

    .line 2
    new-instance v0, Lcom/vdocipher/aegis/core/m/h;

    const/4 v1, 0x1

    const-string v2, "hlse"

    const-string v3, "HLSE"

    invoke-direct {v0, v3, v1, v2}, Lcom/vdocipher/aegis/core/m/h;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lcom/vdocipher/aegis/core/m/h;->c:Lcom/vdocipher/aegis/core/m/h;

    .line 3
    new-instance v0, Lcom/vdocipher/aegis/core/m/h;

    const/4 v1, 0x2

    const-string v2, "h6"

    const-string v3, "H6"

    invoke-direct {v0, v3, v1, v2}, Lcom/vdocipher/aegis/core/m/h;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lcom/vdocipher/aegis/core/m/h;->d:Lcom/vdocipher/aegis/core/m/h;

    .line 4
    new-instance v0, Lcom/vdocipher/aegis/core/m/h;

    const/4 v1, 0x3

    const-string v2, "live-01"

    const-string v3, "LIVE01"

    invoke-direct {v0, v3, v1, v2}, Lcom/vdocipher/aegis/core/m/h;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lcom/vdocipher/aegis/core/m/h;->e:Lcom/vdocipher/aegis/core/m/h;

    .line 5
    new-instance v0, Lcom/vdocipher/aegis/core/m/h;

    const/4 v1, 0x4

    const-string/jumbo v2, "url"

    const-string v3, "OPEN_URL"

    invoke-direct {v0, v3, v1, v2}, Lcom/vdocipher/aegis/core/m/h;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lcom/vdocipher/aegis/core/m/h;->f:Lcom/vdocipher/aegis/core/m/h;

    .line 6
    invoke-static {}, Lcom/vdocipher/aegis/core/m/h;->a()[Lcom/vdocipher/aegis/core/m/h;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/aegis/core/m/h;->g:[Lcom/vdocipher/aegis/core/m/h;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .registers 4

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    iput-object p3, p0, Lcom/vdocipher/aegis/core/m/h;->a:Ljava/lang/String;

    return-void
.end method

.method private static synthetic a()[Lcom/vdocipher/aegis/core/m/h;
    .registers 5

    .line 1
    sget-object v0, Lcom/vdocipher/aegis/core/m/h;->b:Lcom/vdocipher/aegis/core/m/h;

    sget-object v1, Lcom/vdocipher/aegis/core/m/h;->c:Lcom/vdocipher/aegis/core/m/h;

    sget-object v2, Lcom/vdocipher/aegis/core/m/h;->d:Lcom/vdocipher/aegis/core/m/h;

    sget-object v3, Lcom/vdocipher/aegis/core/m/h;->e:Lcom/vdocipher/aegis/core/m/h;

    sget-object v4, Lcom/vdocipher/aegis/core/m/h;->f:Lcom/vdocipher/aegis/core/m/h;

    filled-new-array {v0, v1, v2, v3, v4}, [Lcom/vdocipher/aegis/core/m/h;

    move-result-object v0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/aegis/core/m/h;
    .registers 2

    .line 1
    const-class v0, Lcom/vdocipher/aegis/core/m/h;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/aegis/core/m/h;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/aegis/core/m/h;
    .registers 1

    .line 1
    sget-object v0, Lcom/vdocipher/aegis/core/m/h;->g:[Lcom/vdocipher/aegis/core/m/h;

    invoke-virtual {v0}, [Lcom/vdocipher/aegis/core/m/h;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/aegis/core/m/h;

    return-object v0
.end method


# virtual methods
.method b()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/h;->a:Ljava/lang/String;

    return-object v0
.end method
