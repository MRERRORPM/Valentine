# classes14.dex

.class Lcom/vdocipher/aegis/core/m/a0$e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/a0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/m/a0;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/m/a0;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/a0$e;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    .line 1
    :try_start_0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0$e;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/a0;->a(Lcom/vdocipher/aegis/core/m/a0;)Lcom/vdocipher/aegis/core/d/k;

    move-result-object v0

    if-eqz v0, :cond_2e

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0$e;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/a0;->g(Lcom/vdocipher/aegis/core/m/a0;)Landroidx/media3/exoplayer/analytics/PlaybackStatsListener;

    move-result-object v0

    if-eqz v0, :cond_2e

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0$e;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/a0;->a(Lcom/vdocipher/aegis/core/m/a0;)Lcom/vdocipher/aegis/core/d/k;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/a0$e;->a:Lcom/vdocipher/aegis/core/m/a0;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/m/a0;->g(Lcom/vdocipher/aegis/core/m/a0;)Landroidx/media3/exoplayer/analytics/PlaybackStatsListener;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/media3/exoplayer/analytics/PlaybackStatsListener;->getPlaybackStats()Landroidx/media3/exoplayer/analytics/PlaybackStats;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/d/k;Landroidx/media3/exoplayer/analytics/PlaybackStats;)V
    :try_end_23
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_23} :catch_24

    goto :goto_2e

    :catch_24
    move-exception v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const-string v1, "VdoServiceSM"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    :cond_2e
    :goto_2e
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/a0$e;->a:Lcom/vdocipher/aegis/core/m/a0;

    iget-object v1, v0, Lcom/vdocipher/aegis/core/m/a0;->a:Landroid/os/Handler;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/a0;->h(Lcom/vdocipher/aegis/core/m/a0;)Ljava/lang/Runnable;

    move-result-object v0

    const-wide/32 v2, 0x493e0

    invoke-virtual {v1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
