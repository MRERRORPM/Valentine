# classes14.dex

.class public Lcom/vdocipher/aegis/core/m/u$c;
.super Ljava/io/IOException;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field public final a:Lcom/vdocipher/aegis/core/m/u$a;

.field public final b:I

.field public final c:Ljava/lang/String;

.field public final d:I

.field public final e:Z


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/m/u$a;ILjava/lang/String;ILjava/lang/Throwable;)V
    .registers 6

    .line 3
    invoke-direct {p0, p5}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    .line 4
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/u$c;->a:Lcom/vdocipher/aegis/core/m/u$a;

    .line 5
    iput p2, p0, Lcom/vdocipher/aegis/core/m/u$c;->b:I

    .line 6
    iput-object p3, p0, Lcom/vdocipher/aegis/core/m/u$c;->c:Ljava/lang/String;

    .line 7
    iput p4, p0, Lcom/vdocipher/aegis/core/m/u$c;->d:I

    if-gtz p2, :cond_f

    const/4 p1, 0x1

    goto :goto_10

    :cond_f
    const/4 p1, 0x0

    .line 8
    :goto_10
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/u$c;->e:Z

    return-void
.end method

.method constructor <init>(Lcom/vdocipher/aegis/core/m/u$a;ILjava/lang/String;ILjava/lang/Throwable;Ljava/lang/Boolean;)V
    .registers 7

    .line 9
    invoke-direct {p0, p5}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    .line 10
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/u$c;->a:Lcom/vdocipher/aegis/core/m/u$a;

    .line 11
    iput p2, p0, Lcom/vdocipher/aegis/core/m/u$c;->b:I

    .line 12
    iput-object p3, p0, Lcom/vdocipher/aegis/core/m/u$c;->c:Ljava/lang/String;

    .line 13
    iput p4, p0, Lcom/vdocipher/aegis/core/m/u$c;->d:I

    .line 14
    invoke-virtual {p6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/u$c;->e:Z

    return-void
.end method

.method constructor <init>(Lcom/vdocipher/aegis/core/m/u$a;Ljava/lang/Throwable;)V
    .registers 9

    const/4 v3, 0x0

    const/4 v4, -0x1

    const/4 v2, -0x1

    move-object v0, p0

    move-object v1, p1

    move-object v5, p2

    .line 1
    invoke-direct/range {v0 .. v5}, Lcom/vdocipher/aegis/core/m/u$c;-><init>(Lcom/vdocipher/aegis/core/m/u$a;ILjava/lang/String;ILjava/lang/Throwable;)V

    return-void
.end method

.method constructor <init>(Lcom/vdocipher/aegis/core/m/u$a;Ljava/lang/Throwable;Z)V
    .registers 11

    .line 2
    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    const/4 v3, 0x0

    const/4 v4, -0x1

    const/4 v2, -0x1

    move-object v0, p0

    move-object v1, p1

    move-object v5, p2

    invoke-direct/range {v0 .. v6}, Lcom/vdocipher/aegis/core/m/u$c;-><init>(Lcom/vdocipher/aegis/core/m/u$a;ILjava/lang/String;ILjava/lang/Throwable;Ljava/lang/Boolean;)V

    return-void
.end method
