# classes14.dex

.class interface abstract Lcom/vdocipher/aegis/core/m/e$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/Object;Lcom/vdocipher/aegis/core/m/y$a;Lcom/vdocipher/aegis/core/m/h;Lcom/vdocipher/aegis/core/d/k;)V
.end method

.method public abstract a(Ljava/lang/Object;Lcom/vdocipher/aegis/media/ErrorDescription;)V
.end method

.method public abstract a(Ljava/lang/String;)V
.end method
