# classes14.dex

.class public final Lcom/vdocipher/aegis/core/m/b0;
.super Landroid/widget/FrameLayout;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/core/m/b0$a;
    }
.end annotation


# instance fields
.field public a:Landroid/view/SurfaceView;

.field private b:Lcom/vdocipher/aegis/core/m/b0$a;

.field c:Landroid/view/SurfaceHolder;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, p2, v0}, Lcom/vdocipher/aegis/core/m/b0;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    .line 2
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    if-nez p2, :cond_f

    const p2, -0xff0100

    .line 5
    invoke-virtual {p0, p2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 9
    :cond_f
    new-instance p2, Landroid/view/SurfaceView;

    invoke-direct {p2, p1}, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/b0;->a:Landroid/view/SurfaceView;

    const/4 p1, 0x1

    .line 10
    const/4 p1, 0x0

    invoke-virtual {p2, p1}, Landroid/view/SurfaceView;->setSecure(Z)V

    .line 15
    new-instance p1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 p2, -0x1

    invoke-direct {p1, p2, p2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 18
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/b0;->a:Landroid/view/SurfaceView;

    invoke-virtual {p0, p2, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 20
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/b0;->a:Landroid/view/SurfaceView;

    invoke-virtual {p1}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/b0;->c:Landroid/view/SurfaceHolder;

    return-void
.end method


# virtual methods
.method public a()V
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/b0;->b:Lcom/vdocipher/aegis/core/m/b0$a;

    if-eqz v0, :cond_7

    .line 2
    invoke-interface {v0}, Lcom/vdocipher/aegis/core/m/b0$a;->a()V

    :cond_7
    return-void
.end method

.method public a(Lcom/vdocipher/aegis/player/VdoInitParams;)V
    .registers 3

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/b0;->b:Lcom/vdocipher/aegis/core/m/b0$a;

    if-eqz v0, :cond_7

    .line 4
    invoke-interface {v0, p1}, Lcom/vdocipher/aegis/core/m/b0$a;->a(Lcom/vdocipher/aegis/player/VdoInitParams;)V

    :cond_7
    return-void
.end method

.method public setShutterCallback(Lcom/vdocipher/aegis/core/m/b0$a;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/b0;->b:Lcom/vdocipher/aegis/core/m/b0$a;

    return-void
.end method

.method public setSurfCallback(Landroid/view/SurfaceHolder$Callback;)V
    .registers 3

    if-eqz p1, :cond_7

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/b0;->c:Landroid/view/SurfaceHolder;

    invoke-interface {v0, p1}, Landroid/view/SurfaceHolder;->addCallback(Landroid/view/SurfaceHolder$Callback;)V

    :cond_7
    return-void
.end method
