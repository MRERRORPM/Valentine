# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/m/e;

.field public final synthetic f$1:Ljava/lang/Exception;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/Exception;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/m/e;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda2;->f$1:Ljava/lang/Exception;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/m/e;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/e$$ExternalSyntheticLambda2;->f$1:Ljava/lang/Exception;

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/m/e;->$r8$lambda$75SqwC_1YfmvXfI6CgxhBjPbr7c(Lcom/vdocipher/aegis/core/m/e;Ljava/lang/Exception;)V

    return-void
.end method
