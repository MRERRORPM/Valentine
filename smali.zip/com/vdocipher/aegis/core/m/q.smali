# classes14.dex

.class public abstract Lcom/vdocipher/aegis/core/m/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vdocipher/aegis/core/m/y;
.implements Landroid/os/Handler$Callback;
.implements Lcom/vdocipher/aegis/core/n/b$a;


# instance fields
.field volatile A:Z

.field private B:Z

.field C:Lcom/vdocipher/aegis/media/MediaInfo;

.field private D:J

.field private E:J

.field F:Ljava/lang/String;

.field G:Ljava/lang/String;

.field H:Ljava/lang/String;

.field I:J

.field private final J:Landroid/os/HandlerThread;

.field private K:Landroid/os/Handler;

.field private L:Z

.field private final M:Landroid/content/BroadcastReceiver;

.field private final N:Landroid/content/BroadcastReceiver;

.field private O:Ljava/lang/Runnable;

.field private P:Landroidx/media3/common/Player$Listener;

.field private a:Z

.field protected b:Landroid/content/Context;

.field c:Lcom/vdocipher/aegis/media/PlayerOption;

.field private d:Landroid/view/SurfaceView;

.field e:Landroid/os/Handler;

.field private f:Lcom/vdocipher/aegis/core/n/b;

.field final g:Lcom/vdocipher/aegis/core/d/k;

.field private final h:Ljava/util/concurrent/CopyOnWriteArraySet;

.field i:Ljava/lang/ref/WeakReference;

.field private j:Ljava/lang/ref/WeakReference;

.field private k:Ljava/lang/ref/WeakReference;

.field private final l:Lcom/vdocipher/aegis/core/k/c;

.field private m:Lcom/vdocipher/aegis/player/internal/util/AutoResumeCallback;

.field private final n:Landroidx/media3/common/Player;

.field private o:Landroidx/media3/common/TrackSelectionParameters;

.field protected p:Lcom/vdocipher/aegis/core/z/d$b;

.field private final q:Ljava/lang/Object;

.field private r:Z

.field s:Lcom/vdocipher/aegis/core/m/y$a;

.field t:Lcom/vdocipher/aegis/core/f/g;

.field u:[Lcom/vdocipher/aegis/media/Track;

.field final v:Ljava/util/ArrayList;

.field private final w:Ljava/util/concurrent/ConcurrentHashMap;

.field private volatile x:I

.field private volatile y:Z

.field private volatile z:Z


# direct methods
.method public static synthetic $r8$lambda$9NOD53T80jrb_rQOfIG9nfVxtUg(Lcom/vdocipher/aegis/core/m/q;[Lcom/vdocipher/aegis/core/v/b;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->a([Lcom/vdocipher/aegis/core/v/b;)V

    return-void
.end method

.method public static synthetic $r8$lambda$S_x_mSPAl3a6QqRAGdUF4qEn2Kg(Lcom/vdocipher/aegis/core/m/q;J)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/m/q;->a(J)V

    return-void
.end method

.method public static synthetic $r8$lambda$XM-4bVoaiwdqpJhhKPHEQqqLWGE(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/util/List;)V
    .registers 2

    invoke-static {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/util/List;)V

    return-void
.end method

.method public static synthetic $r8$lambda$da3g1SfpURy8XqNSjAfSpj5GHPE(Ljava/lang/Exception;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V
    .registers 2

    invoke-static {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->a(Ljava/lang/Exception;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V

    return-void
.end method

.method public static synthetic $r8$lambda$z5WH-chhhiPLsqLNYeZwth6AauU(Lcom/vdocipher/aegis/core/m/q;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/m/q;->a(Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/lang/String;)V

    return-void
.end method

.method constructor <init>(Landroid/content/Context;Landroidx/media3/common/Player;Landroid/view/SurfaceView;Lcom/vdocipher/aegis/core/d/k;)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/m/q;->a:Z

    .line 22
    sget-object v1, Lcom/vdocipher/aegis/core/z/d$b;->a:Lcom/vdocipher/aegis/core/z/d$b;

    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->p:Lcom/vdocipher/aegis/core/z/d$b;

    .line 23
    new-instance v1, Ljava/lang/Object;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->q:Ljava/lang/Object;

    const/4 v1, 0x0

    .line 25
    iput-boolean v1, p0, Lcom/vdocipher/aegis/core/m/q;->r:Z

    .line 48
    new-instance v2, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v2}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->w:Ljava/util/concurrent/ConcurrentHashMap;

    .line 51
    iput v0, p0, Lcom/vdocipher/aegis/core/m/q;->x:I

    .line 52
    iput-boolean v1, p0, Lcom/vdocipher/aegis/core/m/q;->y:Z

    .line 53
    iput-boolean v1, p0, Lcom/vdocipher/aegis/core/m/q;->z:Z

    .line 54
    iput-boolean v1, p0, Lcom/vdocipher/aegis/core/m/q;->A:Z

    .line 55
    iput-boolean v1, p0, Lcom/vdocipher/aegis/core/m/q;->B:Z

    const-wide/16 v2, 0x0

    .line 57
    iput-wide v2, p0, Lcom/vdocipher/aegis/core/m/q;->D:J

    .line 58
    iput-wide v2, p0, Lcom/vdocipher/aegis/core/m/q;->E:J

    .line 68
    iput-boolean v1, p0, Lcom/vdocipher/aegis/core/m/q;->L:Z

    .line 73
    new-instance v0, Lcom/vdocipher/aegis/core/m/q$a;

    invoke-direct {v0, p0}, Lcom/vdocipher/aegis/core/m/q$a;-><init>(Lcom/vdocipher/aegis/core/m/q;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->M:Landroid/content/BroadcastReceiver;

    .line 96
    new-instance v1, Lcom/vdocipher/aegis/core/m/q$b;

    invoke-direct {v1, p0}, Lcom/vdocipher/aegis/core/m/q$b;-><init>(Lcom/vdocipher/aegis/core/m/q;)V

    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->N:Landroid/content/BroadcastReceiver;

    .line 179
    new-instance v2, Lcom/vdocipher/aegis/core/m/q$c;

    invoke-direct {v2, p0}, Lcom/vdocipher/aegis/core/m/q$c;-><init>(Lcom/vdocipher/aegis/core/m/q;)V

    iput-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->O:Ljava/lang/Runnable;

    .line 689
    new-instance v2, Lcom/vdocipher/aegis/core/m/q$d;

    invoke-direct {v2, p0}, Lcom/vdocipher/aegis/core/m/q$d;-><init>(Lcom/vdocipher/aegis/core/m/q;)V

    iput-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->P:Landroidx/media3/common/Player$Listener;

    .line 690
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    .line 691
    iput-object p3, p0, Lcom/vdocipher/aegis/core/m/q;->d:Landroid/view/SurfaceView;

    .line 692
    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    .line 693
    new-instance p2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p3

    invoke-direct {p2, p3, p0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    .line 695
    new-instance p2, Landroid/os/HandlerThread;

    const-string p3, "VdoExo"

    invoke-direct {p2, p3}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/q;->J:Landroid/os/HandlerThread;

    .line 696
    invoke-virtual {p2}, Ljava/lang/Thread;->start()V

    .line 697
    new-instance p3, Landroid/os/Handler;

    invoke-virtual {p2}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object p2

    invoke-direct {p3, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p3, p0, Lcom/vdocipher/aegis/core/m/q;->K:Landroid/os/Handler;

    .line 699
    new-instance p2, Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-direct {p2}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>()V

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/q;->h:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 700
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    .line 702
    iput-object p4, p0, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    .line 703
    invoke-static {p1}, Lcom/vdocipher/aegis/core/k/c;->b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object p2

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/q;->l:Lcom/vdocipher/aegis/core/k/c;

    .line 706
    new-instance p2, Landroid/content/IntentFilter;

    const-string p3, "action_vdo_playback_exception"

    invoke-direct {p2, p3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    .line 707
    invoke-static {p1}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object p3

    invoke-virtual {p3, v1, p2}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V

    .line 709
    new-instance p2, Landroid/content/IntentFilter;

    invoke-direct {p2}, Landroid/content/IntentFilter;-><init>()V

    .line 710
    const-string p3, "action_vdo_tc_tp"

    invoke-virtual {p2, p3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 711
    const-string p3, "enf_blocked_action"

    invoke-virtual {p2, p3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 714
    invoke-static {p1}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object p1

    invoke-virtual {p1, v0, p2}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V

    return-void
.end method

.method private a(I)I
    .registers 9

    .line 295
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->e()[Lcom/vdocipher/aegis/media/Track;

    move-result-object v0

    .line 298
    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_7
    if-ge v2, v1, :cond_18

    aget-object v4, v0, v2

    .line 299
    iget v5, v4, Lcom/vdocipher/aegis/media/Track;->type:I

    const/4 v6, 0x2

    if-ne v5, v6, :cond_15

    iget v4, v4, Lcom/vdocipher/aegis/media/Track;->bitrate:I

    if-ge v3, v4, :cond_15

    move v3, v4

    :cond_15
    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    :cond_18
    if-ne p1, v3, :cond_1e

    const p1, 0xf4240

    return p1

    :cond_1e
    const p1, 0xc350

    return p1
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/m/q;I)I
    .registers 2

    .line 5
    iput p1, p0, Lcom/vdocipher/aegis/core/m/q;->x:I

    return p1
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/m/q;)J
    .registers 3

    .line 1
    iget-wide v0, p0, Lcom/vdocipher/aegis/core/m/q;->D:J

    return-wide v0
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/m/q;J)J
    .registers 3

    .line 2
    iput-wide p1, p0, Lcom/vdocipher/aegis/core/m/q;->D:J

    return-wide p1
.end method

.method private a(Ljava/lang/String;)Ljava/lang/Object;
    .registers 4

    .line 300
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v0, "totalPlayed"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1e

    const-string/jumbo v0, "totalCovered"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_17

    const/4 p1, 0x0

    return-object p1

    .line 304
    :cond_17
    iget-wide v0, p0, Lcom/vdocipher/aegis/core/m/q;->E:J

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    return-object p1

    .line 305
    :cond_1e
    iget-wide v0, p0, Lcom/vdocipher/aegis/core/m/q;->D:J

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    return-object p1
.end method

.method private a(F)V
    .registers 4

    .line 70
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->h:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 71
    invoke-interface {v1, p1}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onPlaybackSpeedChanged(F)V

    goto :goto_6

    :cond_16
    return-void
.end method

.method private synthetic a(J)V
    .registers 7

    .line 48
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->q:Ljava/lang/Object;

    monitor-enter v0

    .line 49
    :try_start_3
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    if-nez v1, :cond_9

    monitor-exit v0

    return-void

    .line 52
    :cond_9
    iget-object v1, v1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-boolean v2, v1, Lcom/vdocipher/aegis/player/VdoInitParams;->clipped:Z

    if-eqz v2, :cond_12

    .line 53
    iget-wide v1, v1, Lcom/vdocipher/aegis/player/VdoInitParams;->startTimeMs:J

    add-long/2addr p1, v1

    .line 55
    :cond_12
    iget-wide v1, p0, Lcom/vdocipher/aegis/core/m/q;->I:J

    invoke-static {p1, p2, v1, v2}, Lcom/vdocipher/aegis/core/t/d;->a(JJ)Z

    move-result v1

    if-eqz v1, :cond_33

    .line 56
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->l:Lcom/vdocipher/aegis/core/k/c;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v2, v2, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v2, v2, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    const-string v3, "%s"

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {v3, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, v2, p1}, Lcom/vdocipher/aegis/core/k/c;->f(Ljava/lang/String;Ljava/lang/String;)Z

    .line 57
    :cond_33
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    if-eqz p1, :cond_4b

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result p1

    if-eqz p1, :cond_4b

    .line 58
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->l:Lcom/vdocipher/aegis/core/k/c;

    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object p2, p2, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object p2, p2, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    const/4 v1, 0x0

    invoke-virtual {p1, p2, v1}, Lcom/vdocipher/aegis/core/k/c;->b(Ljava/lang/String;Z)Z

    .line 60
    :cond_4b
    monitor-exit v0

    return-void

    :catchall_4d
    move-exception p1

    monitor-exit v0
    :try_end_4f
    .catchall {:try_start_3 .. :try_end_4f} :catchall_4d

    throw p1
.end method

.method private a(Landroidx/media3/common/VideoSize;)V
    .registers 5

    .line 61
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->j:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/aegis/core/m/y$d;

    .line 62
    sget-object v1, Landroidx/media3/common/VideoSize;->UNKNOWN:Landroidx/media3/common/VideoSize;

    if-eq p1, v1, :cond_1b

    iget v1, p1, Landroidx/media3/common/VideoSize;->width:I

    if-lez v1, :cond_1b

    iget v2, p1, Landroidx/media3/common/VideoSize;->height:I

    if-lez v2, :cond_1b

    if-eqz v0, :cond_1b

    .line 63
    iget p1, p1, Landroidx/media3/common/VideoSize;->pixelWidthHeightRatio:F

    invoke-interface {v0, v1, v2, p1}, Lcom/vdocipher/aegis/core/m/y$d;->a(IIF)V

    :cond_1b
    return-void
.end method

.method private a(Lcom/vdocipher/aegis/core/m/j;)V
    .registers 20

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    const-string v3, "resume to "

    .line 97
    iget-object v4, v1, Lcom/vdocipher/aegis/core/m/q;->q:Ljava/lang/Object;

    monitor-enter v4

    .line 99
    :try_start_9
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    if-nez v0, :cond_f

    monitor-exit v4

    return-void

    .line 101
    :cond_f
    sget-object v5, Lcom/vdocipher/aegis/core/m/i;->e:Lcom/vdocipher/aegis/core/m/i;
    :try_end_11
    .catchall {:try_start_9 .. :try_end_11} :catchall_174

    .line 107
    :try_start_11
    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v6, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    if-nez v6, :cond_1a

    iget-object v0, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    goto :goto_1e

    :cond_1a
    invoke-static {v6}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_1e
    iput-object v0, v1, Lcom/vdocipher/aegis/core/m/q;->F:Ljava/lang/String;
    :try_end_20
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_11 .. :try_end_20} :catch_23
    .catch Lorg/json/JSONException; {:try_start_11 .. :try_end_20} :catch_21
    .catchall {:try_start_11 .. :try_end_20} :catchall_174

    goto :goto_2d

    :catch_21
    move-exception v0

    goto :goto_24

    :catch_23
    move-exception v0

    .line 109
    :goto_24
    :try_start_24
    const-string v6, "VdoExo"

    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v6, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 113
    :goto_2d
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/q;->l:Lcom/vdocipher/aegis/core/k/c;

    iget-object v6, v1, Lcom/vdocipher/aegis/core/m/q;->F:Ljava/lang/String;

    invoke-virtual {v0, v6}, Lcom/vdocipher/aegis/core/k/c;->q(Ljava/lang/String;)Landroid/util/Pair;

    move-result-object v0
    :try_end_35
    .catchall {:try_start_24 .. :try_end_35} :catchall_174

    const/4 v6, 0x0

    const-wide/16 v7, 0x0

    if-eqz v0, :cond_68

    .line 118
    :try_start_3a
    iget-object v9, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v9, Ljava/lang/String;

    .line 119
    iget-object v0, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v0, Ljava/util/Date;

    .line 120
    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9

    .line 121
    sget-object v5, Lcom/vdocipher/aegis/core/m/i;->d:Lcom/vdocipher/aegis/core/m/i;

    .line 123
    iget-boolean v10, v2, Lcom/vdocipher/aegis/core/m/j;->c:Z

    if-eqz v10, :cond_83

    .line 124
    iget-wide v10, v2, Lcom/vdocipher/aegis/core/m/j;->a:J

    .line 125
    iget-wide v12, v2, Lcom/vdocipher/aegis/core/m/j;->b:J

    .line 127
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v14

    invoke-virtual {v0}, Ljava/util/Date;->getTime()J

    move-result-wide v16

    sub-long v14, v14, v16

    cmp-long v0, v12, v7

    if-eqz v0, :cond_83

    cmp-long v0, v12, v14

    if-gez v0, :cond_83

    long-to-int v9, v10

    .line 130
    sget-object v5, Lcom/vdocipher/aegis/core/m/i;->c:Lcom/vdocipher/aegis/core/m/i;
    :try_end_65
    .catch Ljava/lang/Exception; {:try_start_3a .. :try_end_65} :catch_66
    .catchall {:try_start_3a .. :try_end_65} :catchall_174

    goto :goto_83

    :catch_66
    const/4 v9, -0x1

    goto :goto_83

    .line 137
    :cond_68
    :try_start_68
    iget-boolean v0, v2, Lcom/vdocipher/aegis/core/m/j;->c:Z

    if-eqz v0, :cond_74

    .line 138
    iget-wide v9, v2, Lcom/vdocipher/aegis/core/m/j;->a:J

    long-to-int v0, v9

    .line 139
    sget-object v2, Lcom/vdocipher/aegis/core/m/i;->c:Lcom/vdocipher/aegis/core/m/i;

    move v9, v0

    move-object v5, v2

    goto :goto_78

    .line 142
    :cond_74
    sget-object v0, Lcom/vdocipher/aegis/core/m/i;->e:Lcom/vdocipher/aegis/core/m/i;

    move-object v5, v0

    move v9, v6

    .line 145
    :goto_78
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/q;->l:Lcom/vdocipher/aegis/core/k/c;

    iget-object v2, v1, Lcom/vdocipher/aegis/core/m/q;->F:Ljava/lang/String;

    invoke-static {v9}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v2, v10}, Lcom/vdocipher/aegis/core/k/c;->b(Ljava/lang/String;Ljava/lang/String;)Z

    .line 151
    :cond_83
    :goto_83
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v2, v0, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget v10, v2, Lcom/vdocipher/aegis/player/VdoInitParams;->resumeTimeMs:I

    int-to-long v10, v10

    .line 152
    iget-boolean v12, v2, Lcom/vdocipher/aegis/player/VdoInitParams;->clipped:Z

    if-nez v12, :cond_9c

    .line 153
    iget-wide v12, v2, Lcom/vdocipher/aegis/player/VdoInitParams;->startTimeMs:J

    cmp-long v14, v10, v12

    if-ltz v14, :cond_9a

    iget-wide v14, v2, Lcom/vdocipher/aegis/player/VdoInitParams;->endTimeMs:J

    cmp-long v2, v10, v14

    if-lez v2, :cond_b4

    :cond_9a
    move-wide v10, v12

    goto :goto_b4

    .line 155
    :cond_9c
    iget-wide v12, v2, Lcom/vdocipher/aegis/player/VdoInitParams;->startTimeMs:J

    cmp-long v14, v12, v7

    if-ltz v14, :cond_b4

    iget-wide v14, v2, Lcom/vdocipher/aegis/player/VdoInitParams;->endTimeMs:J

    cmp-long v2, v14, v7

    if-lez v2, :cond_b4

    cmp-long v2, v14, v12

    if-lez v2, :cond_b4

    const-wide/32 v12, 0x7fffffff

    cmp-long v2, v14, v12

    if-gez v2, :cond_b4

    move v9, v6

    .line 160
    :cond_b4
    :goto_b4
    iget v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->c:I

    invoke-static {v0, v6}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 162
    iget-object v2, v1, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v2, v2, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-boolean v2, v2, Lcom/vdocipher/aegis/player/VdoInitParams;->isAutoResumeEnabled:Z

    const/4 v12, 0x1

    if-nez v2, :cond_ea

    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-interface {v1}, Lcom/vdocipher/aegis/player/VdoPlayer;->getPlayerOptions()Lcom/vdocipher/aegis/media/PlayerOption;

    move-result-object v13

    invoke-virtual {v13}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object v13

    invoke-static {v13}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lcom/vdocipher/aegis/core/f/i;

    invoke-virtual {v13}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object v13

    invoke-static {v13}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lcom/vdocipher/aegis/core/f/h;

    invoke-virtual {v13}, Lcom/vdocipher/aegis/core/f/h;->f()Ljava/lang/Boolean;

    move-result-object v13

    invoke-virtual {v2, v13}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_e8

    goto :goto_ea

    :cond_e8
    move v2, v6

    goto :goto_eb

    :cond_ea
    :goto_ea
    move v2, v12

    :goto_eb
    if-lez v0, :cond_fb

    int-to-long v10, v0

    .line 170
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->c:I

    if-nez v0, :cond_f8

    .line 171
    sget-object v0, Lcom/vdocipher/aegis/core/m/i;->b:Lcom/vdocipher/aegis/core/m/i;

    :goto_f6
    move-object v5, v0

    goto :goto_101

    .line 173
    :cond_f8
    sget-object v0, Lcom/vdocipher/aegis/core/m/i;->e:Lcom/vdocipher/aegis/core/m/i;

    goto :goto_f6

    :cond_fb
    cmp-long v0, v10, v7

    if-ltz v0, :cond_103

    .line 178
    sget-object v5, Lcom/vdocipher/aegis/core/m/i;->b:Lcom/vdocipher/aegis/core/m/i;

    :goto_101
    move v12, v6

    goto :goto_109

    :cond_103
    if-eqz v2, :cond_107

    int-to-long v10, v9

    goto :goto_109

    :cond_107
    move v12, v6

    move-wide v10, v7

    .line 185
    :goto_109
    const-string v0, "VdoExo"

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 189
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-boolean v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->p:Z

    if-nez v0, :cond_130

    iget-wide v13, v1, Lcom/vdocipher/aegis/core/m/q;->I:J

    sub-long/2addr v13, v10

    const-wide/16 v15, 0x1388

    cmp-long v0, v13, v15

    if-lez v0, :cond_12a

    goto :goto_130

    .line 192
    :cond_12a
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0, v7, v8}, Landroidx/media3/common/Player;->seekTo(J)V

    goto :goto_135

    .line 193
    :cond_130
    :goto_130
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0, v10, v11}, Landroidx/media3/common/Player;->seekTo(J)V

    :goto_135
    if-eqz v2, :cond_158

    if-eqz v12, :cond_158

    const-wide/16 v2, 0x7d0

    cmp-long v0, v10, v2

    if-lez v0, :cond_14e

    .line 200
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/q;->m:Lcom/vdocipher/aegis/player/internal/util/AutoResumeCallback;

    if-eqz v0, :cond_14e

    .line 201
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0, v6}, Landroidx/media3/common/Player;->setPlayWhenReady(Z)V

    .line 202
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/q;->m:Lcom/vdocipher/aegis/player/internal/util/AutoResumeCallback;

    invoke-interface {v0, v10, v11}, Lcom/vdocipher/aegis/player/internal/util/AutoResumeCallback;->autoResumeVideo(J)V

    goto :goto_161

    .line 204
    :cond_14e
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    iget-object v2, v1, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-boolean v2, v2, Lcom/vdocipher/aegis/core/m/y$a;->j:Z

    invoke-interface {v0, v2}, Landroidx/media3/common/Player;->setPlayWhenReady(Z)V

    goto :goto_161

    .line 207
    :cond_158
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    iget-object v2, v1, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-boolean v2, v2, Lcom/vdocipher/aegis/core/m/y$a;->j:Z

    invoke-interface {v0, v2}, Landroidx/media3/common/Player;->setPlayWhenReady(Z)V

    .line 209
    :goto_161
    sget-object v0, Lcom/vdocipher/aegis/core/m/i;->e:Lcom/vdocipher/aegis/core/m/i;

    if-eq v5, v0, :cond_172

    cmp-long v0, v10, v7

    if-eqz v0, :cond_172

    .line 210
    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    invoke-virtual {v5}, Lcom/vdocipher/aegis/core/m/i;->b()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/vdocipher/aegis/core/d/k;->e(Ljava/lang/String;)V

    .line 212
    :cond_172
    monitor-exit v4

    return-void

    :catchall_174
    move-exception v0

    monitor-exit v4
    :try_end_176
    .catchall {:try_start_68 .. :try_end_176} :catchall_174

    throw v0
.end method

.method private a(Lcom/vdocipher/aegis/core/m/p;)V
    .registers 9

    const-string v0, "VdoExo"

    .line 72
    :try_start_2
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    if-eqz v1, :cond_18

    .line 73
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/t/d;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v0, v2, p1}, Lcom/vdocipher/aegis/core/m/c;->b(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/m/p;)V
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_f} :catch_10

    goto :goto_18

    :catch_10
    move-exception v1

    .line 75
    invoke-static {v1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 78
    :cond_18
    :goto_18
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/z/b;->a(Landroid/content/Context;)Lcom/vdocipher/aegis/core/z/b;

    move-result-object v0

    .line 79
    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/z/b;->a()Ljava/util/Map;

    move-result-object v0

    .line 82
    iget v1, p1, Lcom/vdocipher/aegis/core/m/p;->a:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3f

    .line 83
    iget v1, p1, Lcom/vdocipher/aegis/core/m/p;->a:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/aegis/core/f/b;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/b;->a()Ljava/lang/String;

    move-result-object v0

    goto :goto_41

    .line 85
    :cond_3f
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/p;->b:Ljava/lang/String;

    .line 88
    :goto_41
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->h:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_47
    :goto_47
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_68

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 89
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    if-eqz v3, :cond_47

    .line 90
    iget-object v3, v3, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    new-instance v4, Lcom/vdocipher/aegis/media/ErrorDescription;

    iget v5, p1, Lcom/vdocipher/aegis/core/m/p;->a:I

    iget-object v6, p1, Lcom/vdocipher/aegis/core/m/p;->c:Lcom/vdocipher/aegis/core/m/d;

    iget v6, v6, Lcom/vdocipher/aegis/core/m/d;->b:I

    invoke-direct {v4, v5, v0, v6}, Lcom/vdocipher/aegis/media/ErrorDescription;-><init>(ILjava/lang/String;I)V

    invoke-interface {v2, v3, v4}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onError(Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    goto :goto_47

    :cond_68
    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/m/q;Landroidx/media3/common/VideoSize;)V
    .registers 2

    .line 7
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->a(Landroidx/media3/common/VideoSize;)V

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/m/q;Lcom/vdocipher/aegis/core/m/p;)V
    .registers 2

    .line 6
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->c(Lcom/vdocipher/aegis/core/m/p;)V

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/m/q;Lcom/vdocipher/aegis/media/Track;)V
    .registers 2

    .line 3
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/media/Track;)V

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/m/q;Z)V
    .registers 2

    .line 4
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->b(Z)V

    return-void
.end method

.method private a(Lcom/vdocipher/aegis/media/Track;)V
    .registers 11

    .line 223
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    if-eqz v0, :cond_f8

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    if-nez v0, :cond_a

    goto/16 :goto_f8

    .line 227
    :cond_a
    sget-object v1, Lcom/vdocipher/aegis/media/Track;->DISABLE_CAPTIONS:Lcom/vdocipher/aegis/media/Track;

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-ne p1, v1, :cond_24

    .line 229
    invoke-virtual {v0}, Landroidx/media3/common/TrackSelectionParameters;->buildUpon()Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object p1

    invoke-virtual {p1, v3, v2}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setTrackTypeDisabled(IZ)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/media3/common/TrackSelectionParameters$Builder;->build()Landroidx/media3/common/TrackSelectionParameters;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    .line 230
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0, p1}, Landroidx/media3/common/Player;->setTrackSelectionParameters(Landroidx/media3/common/TrackSelectionParameters;)V

    return-void

    .line 233
    :cond_24
    sget-object v1, Lcom/vdocipher/aegis/media/Track;->SET_ADAPTIVE:Lcom/vdocipher/aegis/media/Track;

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-ne p1, v1, :cond_46

    .line 236
    invoke-virtual {v0}, Landroidx/media3/common/TrackSelectionParameters;->buildUpon()Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object p1

    invoke-virtual {p1, v5}, Landroidx/media3/common/TrackSelectionParameters$Builder;->clearOverridesOfType(I)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object p1

    .line 237
    invoke-virtual {p1, v4}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setForceHighestSupportedBitrate(Z)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object p1

    .line 238
    invoke-virtual {p1, v4}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setForceLowestBitrate(Z)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/media3/common/TrackSelectionParameters$Builder;->build()Landroidx/media3/common/TrackSelectionParameters;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    .line 240
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0, p1}, Landroidx/media3/common/Player;->setTrackSelectionParameters(Landroidx/media3/common/TrackSelectionParameters;)V

    return-void

    .line 244
    :cond_46
    iget v0, p1, Lcom/vdocipher/aegis/media/Track;->id:I

    invoke-static {v0}, Lcom/vdocipher/aegis/core/t/d;->c(I)I

    move-result v0

    .line 245
    iget v1, p1, Lcom/vdocipher/aegis/media/Track;->id:I

    invoke-static {v1}, Lcom/vdocipher/aegis/core/t/d;->d(I)I

    move-result v1

    if-ltz v0, :cond_df

    if-gez v1, :cond_58

    goto/16 :goto_df

    .line 255
    :cond_58
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0}, Landroidx/media3/common/Player;->getCurrentTracks()Landroidx/media3/common/Tracks;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/media3/common/Tracks;->getGroups()Lcom/google/common/collect/ImmutableList;

    move-result-object v0

    .line 259
    iget v6, p1, Lcom/vdocipher/aegis/media/Track;->type:I

    const/4 v7, -0x1

    if-ne v6, v5, :cond_69

    move v2, v5

    goto :goto_71

    :cond_69
    if-ne v6, v2, :cond_6c

    goto :goto_71

    :cond_6c
    if-ne v6, v3, :cond_70

    move v2, v3

    goto :goto_71

    :cond_70
    move v2, v7

    .line 267
    :goto_71
    invoke-virtual {v0}, Lcom/google/common/collect/ImmutableList;->iterator()Lcom/google/common/collect/UnmodifiableIterator;

    move-result-object v0

    :cond_75
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_98

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/media3/common/Tracks$Group;

    .line 268
    invoke-virtual {v3}, Landroidx/media3/common/Tracks$Group;->getMediaTrackGroup()Landroidx/media3/common/TrackGroup;

    move-result-object v6

    iget v6, v6, Landroidx/media3/common/TrackGroup;->type:I

    if-ne v6, v2, :cond_75

    invoke-virtual {v3}, Landroidx/media3/common/Tracks$Group;->getMediaTrackGroup()Landroidx/media3/common/TrackGroup;

    move-result-object v6

    iget-object v6, v6, Landroidx/media3/common/TrackGroup;->id:Ljava/lang/String;

    iget-object v8, p1, Lcom/vdocipher/aegis/media/Track;->groupId:Ljava/lang/String;

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_75

    goto :goto_99

    :cond_98
    const/4 v3, 0x0

    :goto_99
    if-nez v3, :cond_9c

    goto :goto_f8

    :cond_9c
    if-eq v2, v7, :cond_f8

    .line 279
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    invoke-virtual {p1}, Landroidx/media3/common/TrackSelectionParameters;->buildUpon()Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object p1

    .line 280
    invoke-virtual {p1, v2}, Landroidx/media3/common/TrackSelectionParameters$Builder;->clearOverridesOfType(I)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object p1

    .line 281
    invoke-virtual {p1, v2, v4}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setTrackTypeDisabled(IZ)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object p1

    new-instance v0, Landroidx/media3/common/TrackSelectionOverride;

    .line 283
    invoke-virtual {v3}, Landroidx/media3/common/Tracks$Group;->getMediaTrackGroup()Landroidx/media3/common/TrackGroup;

    move-result-object v4

    invoke-direct {v0, v4, v1}, Landroidx/media3/common/TrackSelectionOverride;-><init>(Landroidx/media3/common/TrackGroup;I)V

    .line 284
    invoke-virtual {p1, v0}, Landroidx/media3/common/TrackSelectionParameters$Builder;->addOverride(Landroidx/media3/common/TrackSelectionOverride;)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object p1

    .line 287
    invoke-virtual {p1}, Landroidx/media3/common/TrackSelectionParameters$Builder;->build()Landroidx/media3/common/TrackSelectionParameters;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    .line 288
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0, p1}, Landroidx/media3/common/Player;->setTrackSelectionParameters(Landroidx/media3/common/TrackSelectionParameters;)V

    if-ne v2, v5, :cond_f8

    .line 290
    invoke-virtual {v3}, Landroidx/media3/common/Tracks$Group;->getMediaTrackGroup()Landroidx/media3/common/TrackGroup;

    move-result-object p1

    invoke-virtual {p1, v1}, Landroidx/media3/common/TrackGroup;->getFormat(I)Landroidx/media3/common/Format;

    move-result-object p1

    iget p1, p1, Landroidx/media3/common/Format;->bitrate:I

    .line 291
    invoke-static {}, Lcom/vdocipher/aegis/core/r/a;->a()Lcom/vdocipher/aegis/core/r/a;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->a(I)I

    move-result v2

    add-int/2addr p1, v2

    invoke-virtual {v0, v1, p1}, Lcom/vdocipher/aegis/core/r/a;->a(Landroid/content/Context;I)V

    return-void

    .line 292
    :cond_df
    :goto_df
    sget-object p1, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 293
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    .line 294
    const-string v1, "bad index + [%d, %d]"

    invoke-static {p1, v1, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "VdoExo"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_f8
    :goto_f8
    return-void
.end method

.method private a(Lcom/vdocipher/aegis/media/Track;Ljava/lang/String;)V
    .registers 6

    .line 457
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 458
    const-string/jumbo v1, "type"

    iget v2, p1, Lcom/vdocipher/aegis/media/Track;->type:I

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 459
    const-string v1, "codec"

    iget-object v2, p1, Lcom/vdocipher/aegis/media/Track;->codec:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 460
    const-string v1, "height"

    iget v2, p1, Lcom/vdocipher/aegis/media/Track;->height:I

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 461
    const-string/jumbo v1, "width"

    iget p1, p1, Lcom/vdocipher/aegis/media/Track;->width:I

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 462
    const-string/jumbo p1, "supported"

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 463
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Lcom/vdocipher/aegis/core/d/k;->g(Ljava/lang/String;)V
    :try_end_32
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_32} :catch_33

    return-void

    :catch_33
    move-exception p1

    .line 465
    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Error while adding track to JSONArray: "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "VdoExo"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private a(Lcom/vdocipher/aegis/player/VdoTimeLine;I)V
    .registers 5

    .line 64
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->h:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 65
    invoke-interface {v1, p1, p2}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onTimelineChanged(Lcom/vdocipher/aegis/player/VdoTimeLine;I)V

    goto :goto_6

    :cond_16
    return-void
.end method

.method private static synthetic a(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/util/List;)V
    .registers 2

    .line 453
    invoke-interface {p0, p1}, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;->onResult(Ljava/util/List;)V

    return-void
.end method

.method private static synthetic a(Ljava/lang/Exception;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V
    .registers 3

    .line 447
    instance-of v0, p0, Ljava/net/UnknownHostException;

    if-eqz v0, :cond_a

    .line 448
    sget-object p0, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;->NETWORK_ERROR:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;

    invoke-interface {p1, p0}, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;->onError(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;)V

    return-void

    .line 449
    :cond_a
    instance-of p0, p0, Ljava/net/MalformedURLException;

    if-eqz p0, :cond_14

    .line 450
    sget-object p0, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;->INVALID_FILE_URL:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;

    invoke-interface {p1, p0}, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;->onError(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;)V

    return-void

    .line 452
    :cond_14
    sget-object p0, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;->UNABLE_TO_PARSE_CAPTION_FILE:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;

    invoke-interface {p1, p0}, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;->onError(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;)V

    return-void
.end method

.method private synthetic a(Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/lang/String;)V
    .registers 10

    const-string v0, "file://"

    .line 370
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 374
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->w:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v2, p1}, Ljava/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_7a

    .line 378
    :try_start_f
    const-string v2, "https://"

    invoke-virtual {p1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_31

    const-string v2, "http://"

    invoke-virtual {p1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_31

    .line 379
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 380
    new-instance v2, Ljava/net/URL;

    invoke-direct {v2, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    goto :goto_36

    .line 382
    :cond_31
    new-instance v2, Ljava/net/URL;

    invoke-direct {v2, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 383
    :goto_36
    invoke-virtual {v2}, Ljava/net/URL;->openStream()Ljava/io/InputStream;

    move-result-object v0

    .line 384
    new-instance v2, Lcom/vdocipher/aegis/player/internal/subtitle/a;

    invoke-direct {v2}, Lcom/vdocipher/aegis/player/internal/subtitle/a;-><init>()V

    .line 385
    invoke-virtual {v2, v0}, Lcom/vdocipher/aegis/player/internal/subtitle/a;->a(Ljava/io/InputStream;)Lcom/vdocipher/aegis/core/s/a;

    move-result-object v0
    :try_end_43
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_43} :catch_50

    .line 402
    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/s/a;->a()Ljava/util/List;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 405
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->w:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v2, p1, v0}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_95

    :catch_50
    move-exception p1

    .line 406
    new-instance p3, Ljava/lang/StringBuilder;

    const-string v0, "Subtitle parser failed with msg:"

    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const-string v0, "VdoExo"

    invoke-static {v0, p3}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 408
    new-instance p3, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p3, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda3;

    invoke-direct {v0, p1, p2}, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda3;-><init>(Ljava/lang/Exception;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V

    invoke-virtual {p3, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 429
    :cond_7a
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->w:Ljava/util/concurrent/ConcurrentHashMap;

    if-eqz v0, :cond_95

    invoke-virtual {v0, p1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_95

    .line 430
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->w:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/aegis/core/s/a;

    if-eqz p1, :cond_95

    .line 432
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/s/a;->a()Ljava/util/List;

    move-result-object p1

    invoke-interface {v1, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 438
    :cond_95
    :goto_95
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 439
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x0

    :cond_9f
    :goto_9f
    if-ge v2, v0, :cond_ca

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    add-int/lit8 v2, v2, 0x1

    check-cast v3, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleCue;

    .line 440
    invoke-virtual {v3}, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleCue;->getText()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_9f

    invoke-virtual {v3}, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleCue;->getText()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_9f

    .line 441
    new-instance v4, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleCue;

    invoke-direct {v4, v3}, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleCue;-><init>(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleCue;)V

    invoke-interface {p1, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_9f

    .line 446
    :cond_ca
    new-instance p3, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p3, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v0, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda4;

    invoke-direct {v0, p2, p1}, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda4;-><init>(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/util/List;)V

    invoke-virtual {p3, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private a(Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V
    .registers 6

    .line 306
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0, p1, p3, p2}, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda5;-><init>(Lcom/vdocipher/aegis/core/m/q;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/lang/String;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 369
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private a(Ljava/util/Set;)V
    .registers 4

    .line 454
    new-instance v0, Landroid/content/Intent;

    const-string v1, "action_playback_data"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 455
    check-cast p1, Ljava/io/Serializable;

    const-string v1, "available_bitrate_set"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 456
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-static {p1}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z

    return-void
.end method

.method private a(Z)V
    .registers 3

    .line 91
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/q;->y:Z

    if-nez v0, :cond_d

    const/4 v0, 0x1

    .line 92
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/m/q;->y:Z

    .line 94
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->d(Z)V

    .line 96
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->m()V

    :cond_d
    return-void
.end method

.method private a(ZI)V
    .registers 5

    .line 66
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->h:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 67
    invoke-interface {v1, p1, p2}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onPlayerStateChanged(ZI)V

    goto :goto_6

    :cond_16
    return-void
.end method

.method private synthetic a([Lcom/vdocipher/aegis/core/v/b;)V
    .registers 3

    .line 213
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->i:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/aegis/core/m/y$c;

    if-eqz v0, :cond_d

    .line 215
    invoke-interface {v0, p1}, Lcom/vdocipher/aegis/core/m/y$c;->a([Lcom/vdocipher/aegis/core/v/b;)V

    :cond_d
    return-void
.end method

.method private a([Lcom/vdocipher/aegis/media/Track;[Lcom/vdocipher/aegis/media/Track;)V
    .registers 5

    .line 68
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->h:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 69
    invoke-interface {v1, p1, p2}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onTracksChanged([Lcom/vdocipher/aegis/media/Track;[Lcom/vdocipher/aegis/media/Track;)V

    goto :goto_6

    :cond_16
    return-void
.end method

.method static synthetic b(Lcom/vdocipher/aegis/core/m/q;J)J
    .registers 3

    .line 2
    iput-wide p1, p0, Lcom/vdocipher/aegis/core/m/q;->E:J

    return-wide p1
.end method

.method private b()V
    .registers 3

    .line 13
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->P:Landroidx/media3/common/Player$Listener;

    invoke-interface {v0, v1}, Landroidx/media3/common/Player;->addListener(Landroidx/media3/common/Player$Listener;)V

    .line 15
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0}, Landroidx/media3/common/Player;->getPlaybackState()I

    move-result v0

    const/4 v1, 0x3

    if-ne v0, v1, :cond_20

    .line 16
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0}, Landroidx/media3/common/Player;->getVideoSize()Landroidx/media3/common/VideoSize;

    move-result-object v0

    .line 17
    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/m/q;->a(Landroidx/media3/common/VideoSize;)V

    .line 18
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->d:Landroid/view/SurfaceView;

    invoke-interface {v0, v1}, Landroidx/media3/common/Player;->setVideoSurfaceView(Landroid/view/SurfaceView;)V

    :cond_20
    return-void
.end method

.method private b(Lcom/vdocipher/aegis/core/m/p;)V
    .registers 9

    const-string v0, "VdoExo"

    .line 5
    :try_start_2
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    if-eqz v1, :cond_1a

    .line 6
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/t/d;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v0, v2, p1}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/m/p;)V
    :try_end_f
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_f} :catch_12
    .catch Ljava/lang/NullPointerException; {:try_start_2 .. :try_end_f} :catch_10

    goto :goto_1a

    :catch_10
    move-exception v1

    goto :goto_13

    :catch_12
    move-exception v1

    .line 8
    :goto_13
    invoke-static {v1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 10
    :cond_1a
    :goto_1a
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->h:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_20
    :goto_20
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_43

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 11
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    if-eqz v2, :cond_20

    .line 12
    iget-object v2, v2, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    new-instance v3, Lcom/vdocipher/aegis/media/ErrorDescription;

    iget v4, p1, Lcom/vdocipher/aegis/core/m/p;->a:I

    iget-object v5, p1, Lcom/vdocipher/aegis/core/m/p;->b:Ljava/lang/String;

    iget-object v6, p1, Lcom/vdocipher/aegis/core/m/p;->c:Lcom/vdocipher/aegis/core/m/d;

    iget v6, v6, Lcom/vdocipher/aegis/core/m/d;->b:I

    invoke-direct {v3, v4, v5, v6}, Lcom/vdocipher/aegis/media/ErrorDescription;-><init>(ILjava/lang/String;I)V

    invoke-interface {v1, v2, v3}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onLoadError(Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    goto :goto_20

    :cond_43
    return-void
.end method

.method static synthetic b(Lcom/vdocipher/aegis/core/m/q;Z)V
    .registers 2

    .line 3
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->a(Z)V

    return-void
.end method

.method private b(Z)V
    .registers 4

    .line 25
    new-instance v0, Landroid/content/Intent;

    const-string v1, "action_playback_data"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 26
    const-string v1, "is_adaptive_playback"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 27
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-static {p1}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z

    return-void
.end method

.method private b([Lcom/vdocipher/aegis/media/Track;[Lcom/vdocipher/aegis/media/Track;)V
    .registers 8

    .line 28
    :try_start_0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    if-eqz v0, :cond_21

    .line 31
    array-length v0, p1

    const/4 v1, 0x0

    move v2, v1

    :goto_7
    if-ge v2, v0, :cond_14

    aget-object v3, p1, v2

    .line 32
    const-string/jumbo v4, "yes"

    invoke-direct {p0, v3, v4}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/media/Track;Ljava/lang/String;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    .line 35
    :cond_14
    array-length p1, p2

    :goto_15
    if-ge v1, p1, :cond_21

    aget-object v0, p2, v1

    .line 36
    const-string v2, "no"

    invoke-direct {p0, v0, v2}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/media/Track;Ljava/lang/String;)V
    :try_end_1e
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_1e} :catch_22

    add-int/lit8 v1, v1, 0x1

    goto :goto_15

    :cond_21
    return-void

    :catch_22
    move-exception p1

    .line 41
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "VdoExo"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic b(Lcom/vdocipher/aegis/core/m/q;)[Lcom/vdocipher/aegis/media/Track;
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->e()[Lcom/vdocipher/aegis/media/Track;

    move-result-object p0

    return-object p0
.end method

.method private c()V
    .registers 17

    move-object/from16 v0, p0

    .line 23
    new-instance v1, Landroidx/collection/ArraySet;

    invoke-direct {v1}, Landroidx/collection/ArraySet;-><init>()V

    .line 25
    iget-object v2, v0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    if-nez v2, :cond_c

    return-void

    .line 29
    :cond_c
    iget-object v2, v0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v2, v2, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    if-eqz v2, :cond_34

    iget-wide v3, v2, Lcom/vdocipher/aegis/player/VdoInitParams;->startTimeMs:J

    const-wide/16 v5, 0x0

    cmp-long v3, v3, v5

    if-lez v3, :cond_34

    iget-wide v3, v2, Lcom/vdocipher/aegis/player/VdoInitParams;->endTimeMs:J

    cmp-long v3, v3, v5

    if-lez v3, :cond_34

    .line 30
    iget-boolean v2, v2, Lcom/vdocipher/aegis/player/VdoInitParams;->clipped:Z

    const/4 v3, 0x0

    if-eqz v2, :cond_2d

    .line 31
    iget-object v2, v0, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    const-string v4, "clippingWithoutMarker"

    invoke-virtual {v2, v4, v3}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_34

    .line 33
    :cond_2d
    iget-object v2, v0, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    const-string v4, "clippingWithMarker"

    invoke-virtual {v2, v4, v3}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 37
    :cond_34
    :goto_34
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 39
    new-instance v3, Ljava/util/HashSet;

    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    .line 45
    iget-object v4, v0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v4}, Landroidx/media3/common/Player;->getCurrentTracks()Landroidx/media3/common/Tracks;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/media3/common/Tracks;->getGroups()Lcom/google/common/collect/ImmutableList;

    move-result-object v4

    invoke-virtual {v4}, Lcom/google/common/collect/ImmutableList;->iterator()Lcom/google/common/collect/UnmodifiableIterator;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v7, 0x0

    :goto_4e
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_a5

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroidx/media3/common/Tracks$Group;

    .line 46
    invoke-virtual {v8}, Landroidx/media3/common/Tracks$Group;->getMediaTrackGroup()Landroidx/media3/common/TrackGroup;

    move-result-object v9

    .line 47
    invoke-virtual {v8}, Landroidx/media3/common/Tracks$Group;->getType()I

    move-result v10

    const/4 v11, 0x2

    if-ne v10, v11, :cond_a2

    .line 51
    iget-object v11, v9, Landroidx/media3/common/TrackGroup;->id:Ljava/lang/String;

    const/4 v12, 0x0

    .line 53
    :goto_68
    iget v13, v9, Landroidx/media3/common/TrackGroup;->length:I

    if-ge v12, v13, :cond_a2

    const/4 v13, 0x1

    .line 55
    invoke-virtual {v8, v12, v13}, Landroidx/media3/common/Tracks$Group;->isTrackSupported(IZ)Z

    move-result v13

    if-eqz v13, :cond_9f

    .line 56
    invoke-virtual {v9, v12}, Landroidx/media3/common/TrackGroup;->getFormat(I)Landroidx/media3/common/Format;

    move-result-object v13

    .line 58
    iget v14, v13, Landroidx/media3/common/Format;->bitrate:I

    if-gtz v14, :cond_7c

    goto :goto_9f

    .line 62
    :cond_7c
    invoke-static {v7, v11, v12, v10, v13}, Lcom/vdocipher/aegis/core/t/d;->a(ILjava/lang/String;IILandroidx/media3/common/Format;)Lcom/vdocipher/aegis/media/Track;

    move-result-object v14

    .line 64
    iget v15, v13, Landroidx/media3/common/Format;->bitrate:I

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    invoke-interface {v3, v15}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 65
    sget-object v15, Lcom/vdocipher/aegis/core/z/d;->a:Lcom/vdocipher/aegis/core/z/d;

    iget-object v5, v0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-virtual {v15, v5, v13}, Lcom/vdocipher/aegis/core/z/d;->a(Landroid/content/Context;Landroidx/media3/common/Format;)Z

    move-result v5

    if-nez v5, :cond_97

    .line 66
    invoke-virtual {v1, v14}, Landroidx/collection/ArraySet;->add(Ljava/lang/Object;)Z

    goto :goto_9f

    .line 70
    :cond_97
    iget v5, v14, Lcom/vdocipher/aegis/media/Track;->bitrate:I

    if-ge v6, v5, :cond_9c

    move v6, v5

    .line 74
    :cond_9c
    invoke-interface {v2, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_9f
    :goto_9f
    add-int/lit8 v12, v12, 0x1

    goto :goto_68

    :cond_a2
    add-int/lit8 v7, v7, 0x1

    goto :goto_4e

    :cond_a5
    if-eqz v6, :cond_bc

    .line 83
    iget-object v4, v0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    invoke-virtual {v4}, Landroidx/media3/common/TrackSelectionParameters;->buildUpon()Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v4

    .line 84
    invoke-virtual {v4, v6}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setMaxVideoBitrate(I)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/media3/common/TrackSelectionParameters$Builder;->build()Landroidx/media3/common/TrackSelectionParameters;

    move-result-object v4

    iput-object v4, v0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    .line 85
    iget-object v5, v0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v5, v4}, Landroidx/media3/common/Player;->setTrackSelectionParameters(Landroidx/media3/common/TrackSelectionParameters;)V

    :cond_bc
    const/4 v4, 0x0

    .line 88
    new-array v5, v4, [Lcom/vdocipher/aegis/media/Track;

    invoke-interface {v2, v5}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Lcom/vdocipher/aegis/media/Track;

    new-array v4, v4, [Lcom/vdocipher/aegis/media/Track;

    invoke-virtual {v1, v4}, Landroidx/collection/ArraySet;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Lcom/vdocipher/aegis/media/Track;

    invoke-direct {v0, v2, v1}, Lcom/vdocipher/aegis/core/m/q;->b([Lcom/vdocipher/aegis/media/Track;[Lcom/vdocipher/aegis/media/Track;)V

    .line 90
    invoke-direct {v0, v3}, Lcom/vdocipher/aegis/core/m/q;->a(Ljava/util/Set;)V

    return-void
.end method

.method private c(Lcom/vdocipher/aegis/core/m/p;)V
    .registers 10

    const-string v1, "VdoExo"

    .line 4
    :try_start_2
    new-instance v2, Lcom/vdocipher/aegis/core/m/d;

    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/p;->c:Lcom/vdocipher/aegis/core/m/d;

    iget-object v3, v0, Lcom/vdocipher/aegis/core/m/d;->a:Ljava/lang/String;

    iget v4, v0, Lcom/vdocipher/aegis/core/m/d;->b:I

    iget-object v5, v0, Lcom/vdocipher/aegis/core/m/d;->c:Ljava/lang/String;

    iget-object v6, v0, Lcom/vdocipher/aegis/core/m/d;->d:Ljava/lang/String;

    const/4 v7, 0x1

    invoke-direct/range {v2 .. v7}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Z)V

    .line 5
    new-instance v0, Lcom/vdocipher/aegis/core/m/p;

    iget v3, p1, Lcom/vdocipher/aegis/core/m/p;->a:I

    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/p;->b:Ljava/lang/String;

    invoke-direct {v0, v3, p1, v2}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    .line 6
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    if-eqz p1, :cond_28

    .line 7
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/t/d;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v1, v2, v0}, Lcom/vdocipher/aegis/core/m/c;->b(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/m/p;)V
    :try_end_28
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_28} :catch_29

    :cond_28
    return-void

    :catch_29
    move-exception v0

    move-object p1, v0

    .line 9
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private c(Z)V
    .registers 5

    .line 10
    :try_start_0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    if-eqz v0, :cond_12

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/m/c;->b(Lcom/vdocipher/aegis/core/d/k;Z)V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_7} :catch_8

    goto :goto_12

    :catch_8
    move-exception v0

    .line 12
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "VdoExo"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 14
    :cond_12
    :goto_12
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->h:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_18
    :goto_18
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2e

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 15
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    if-eqz v2, :cond_18

    .line 16
    iget-object v2, v2, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-interface {v1, v2}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onLoaded(Lcom/vdocipher/aegis/player/VdoInitParams;)V

    goto :goto_18

    :cond_2e
    if-eqz p1, :cond_33

    .line 22
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->c()V

    :cond_33
    return-void
.end method

.method static synthetic c(Lcom/vdocipher/aegis/core/m/q;Z)Z
    .registers 2

    .line 2
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/q;->r:Z

    return p1
.end method

.method static synthetic c(Lcom/vdocipher/aegis/core/m/q;)[Lcom/vdocipher/aegis/media/Track;
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->g()[Lcom/vdocipher/aegis/media/Track;

    move-result-object p0

    return-object p0
.end method

.method private d()V
    .registers 9

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    if-nez v0, :cond_5

    return-void

    .line 7
    :cond_5
    iget-boolean v1, v0, Lcom/vdocipher/aegis/core/m/y$a;->p:Z

    const/4 v2, 0x0

    if-nez v1, :cond_27

    .line 9
    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result v0

    if-eqz v0, :cond_15

    .line 10
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/m/q;->j()V

    .line 12
    :cond_15
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result v0

    if-eqz v0, :cond_21

    move-object v0, v2

    goto :goto_25

    :cond_21
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->e:[Lcom/vdocipher/aegis/media/Track;

    :goto_25
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->u:[Lcom/vdocipher/aegis/media/Track;

    .line 15
    :cond_27
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->a(Landroid/content/Context;Ljava/util/List;)Lcom/vdocipher/aegis/media/Caption;

    move-result-object v0

    .line 16
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v3, v1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v3, v3, Lcom/vdocipher/aegis/player/VdoInitParams;->preferredCaptionsLanguage:Ljava/lang/String;

    .line 17
    iget-object v1, v1, Lcom/vdocipher/aegis/core/m/y$a;->d:Ljava/lang/String;

    .line 19
    invoke-static {}, Lcom/vdocipher/aegis/core/r/a;->a()Lcom/vdocipher/aegis/core/r/a;

    move-result-object v4

    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-virtual {v4, v5}, Lcom/vdocipher/aegis/core/r/a;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    .line 20
    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-static {v4, v5}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/util/List;)Z

    move-result v5

    .line 21
    iget-object v6, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-boolean v6, v6, Lcom/vdocipher/aegis/core/m/y$a;->p:Z

    if-nez v6, :cond_79

    iget-object v6, p0, Lcom/vdocipher/aegis/core/m/q;->c:Lcom/vdocipher/aegis/media/PlayerOption;

    invoke-virtual {v6}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object v6

    invoke-virtual {v6}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object v6

    invoke-virtual {v6}, Lcom/vdocipher/aegis/core/f/h;->d()Ljava/lang/Boolean;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v6

    if-eqz v6, :cond_79

    if-eqz v5, :cond_79

    .line 23
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    invoke-virtual {v0}, Landroidx/media3/common/TrackSelectionParameters;->buildUpon()Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v0

    .line 24
    invoke-virtual {v0, v4}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setPreferredTextLanguage(Ljava/lang/String;)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v0

    .line 25
    invoke-virtual {v0}, Landroidx/media3/common/TrackSelectionParameters$Builder;->build()Landroidx/media3/common/TrackSelectionParameters;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    .line 26
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v1, v0}, Landroidx/media3/common/Player;->setTrackSelectionParameters(Landroidx/media3/common/TrackSelectionParameters;)V

    goto :goto_d2

    :cond_79
    if-eqz v1, :cond_91

    .line 30
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    invoke-virtual {v0}, Landroidx/media3/common/TrackSelectionParameters;->buildUpon()Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v0

    .line 31
    invoke-virtual {v0, v1}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setPreferredTextLanguage(Ljava/lang/String;)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v0

    .line 32
    invoke-virtual {v0}, Landroidx/media3/common/TrackSelectionParameters$Builder;->build()Landroidx/media3/common/TrackSelectionParameters;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    .line 33
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v1, v0}, Landroidx/media3/common/Player;->setTrackSelectionParameters(Landroidx/media3/common/TrackSelectionParameters;)V

    goto :goto_d2

    .line 35
    :cond_91
    invoke-static {v3}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_ad

    .line 37
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    invoke-virtual {v0}, Landroidx/media3/common/TrackSelectionParameters;->buildUpon()Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v0

    .line 38
    invoke-virtual {v0, v3}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setPreferredTextLanguage(Ljava/lang/String;)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v0

    .line 39
    invoke-virtual {v0}, Landroidx/media3/common/TrackSelectionParameters$Builder;->build()Landroidx/media3/common/TrackSelectionParameters;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    .line 40
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v1, v0}, Landroidx/media3/common/Player;->setTrackSelectionParameters(Landroidx/media3/common/TrackSelectionParameters;)V

    goto :goto_d2

    :cond_ad
    if-eqz v0, :cond_d2

    .line 42
    invoke-virtual {v0}, Lcom/vdocipher/aegis/media/Caption;->getLang()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_d2

    .line 44
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    invoke-virtual {v1}, Landroidx/media3/common/TrackSelectionParameters;->buildUpon()Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v1

    .line 45
    invoke-virtual {v0}, Lcom/vdocipher/aegis/media/Caption;->getLang()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setPreferredTextLanguage(Ljava/lang/String;)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v0

    .line 46
    invoke-virtual {v0}, Landroidx/media3/common/TrackSelectionParameters$Builder;->build()Landroidx/media3/common/TrackSelectionParameters;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    .line 47
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v1, v0}, Landroidx/media3/common/Player;->setTrackSelectionParameters(Landroidx/media3/common/TrackSelectionParameters;)V

    .line 51
    :cond_d2
    :goto_d2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-boolean v1, v0, Lcom/vdocipher/aegis/core/m/y$a;->p:Z

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v1, :cond_1a0

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->d()Z

    move-result v0

    if-eqz v0, :cond_1a0

    .line 53
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget v0, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->maxVideoBitrateKbps:I

    .line 55
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->c:Lcom/vdocipher/aegis/media/PlayerOption;

    invoke-virtual {v5}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object v5

    invoke-virtual {v5}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object v5

    invoke-virtual {v5}, Lcom/vdocipher/aegis/core/f/h;->c()Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_121

    .line 56
    invoke-static {}, Lcom/vdocipher/aegis/core/r/a;->a()Lcom/vdocipher/aegis/core/r/a;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-virtual {v0, v1}, Lcom/vdocipher/aegis/core/r/a;->c(Landroid/content/Context;)I

    move-result v0

    if-lez v0, :cond_172

    .line 58
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    invoke-virtual {v1}, Landroidx/media3/common/TrackSelectionParameters;->buildUpon()Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v1

    .line 59
    invoke-virtual {v1, v0}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setMaxVideoBitrate(I)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/media3/common/TrackSelectionParameters$Builder;->build()Landroidx/media3/common/TrackSelectionParameters;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    .line 61
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v1, v0}, Landroidx/media3/common/Player;->setTrackSelectionParameters(Landroidx/media3/common/TrackSelectionParameters;)V

    move v0, v3

    goto :goto_173

    :cond_121
    if-lez v0, :cond_140

    const v1, 0x7fffffff

    if-ge v0, v1, :cond_140

    .line 65
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    invoke-virtual {v1}, Landroidx/media3/common/TrackSelectionParameters;->buildUpon()Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v1

    mul-int/lit16 v0, v0, 0x3e8

    .line 66
    invoke-virtual {v1, v0}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setMaxVideoBitrate(I)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/media3/common/TrackSelectionParameters$Builder;->build()Landroidx/media3/common/TrackSelectionParameters;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    .line 68
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v1, v0}, Landroidx/media3/common/Player;->setTrackSelectionParameters(Landroidx/media3/common/TrackSelectionParameters;)V

    goto :goto_172

    .line 71
    :cond_140
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/g;->d()I

    move-result v0

    .line 72
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v5, "dbkbps "

    invoke-direct {v1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v5, "VdoExo"

    invoke-static {v5, v1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    if-lez v0, :cond_172

    .line 74
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    invoke-virtual {v1}, Landroidx/media3/common/TrackSelectionParameters;->buildUpon()Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v1

    mul-int/lit16 v0, v0, 0x3e8

    .line 75
    invoke-virtual {v1, v0}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setMaxVideoBitrate(I)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/media3/common/TrackSelectionParameters$Builder;->build()Landroidx/media3/common/TrackSelectionParameters;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    .line 76
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v1, v0}, Landroidx/media3/common/Player;->setTrackSelectionParameters(Landroidx/media3/common/TrackSelectionParameters;)V

    :cond_172
    :goto_172
    move v0, v4

    .line 80
    :goto_173
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    invoke-virtual {v1}, Landroidx/media3/common/TrackSelectionParameters;->buildUpon()Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v1

    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v5, v5, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-boolean v5, v5, Lcom/vdocipher/aegis/player/VdoInitParams;->forceLowestBitrate:Z

    .line 81
    invoke-virtual {v1, v5}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setForceLowestBitrate(Z)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v1

    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v5, v5, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-boolean v5, v5, Lcom/vdocipher/aegis/player/VdoInitParams;->forceHighestSupportedBitrate:Z

    if-nez v5, :cond_190

    if-eqz v0, :cond_18e

    goto :goto_190

    :cond_18e
    move v0, v4

    goto :goto_191

    :cond_190
    :goto_190
    move v0, v3

    .line 82
    :goto_191
    invoke-virtual {v1, v0}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setForceHighestSupportedBitrate(Z)Landroidx/media3/common/TrackSelectionParameters$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/media3/common/TrackSelectionParameters$Builder;->build()Landroidx/media3/common/TrackSelectionParameters;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    .line 83
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v1, v0}, Landroidx/media3/common/Player;->setTrackSelectionParameters(Landroidx/media3/common/TrackSelectionParameters;)V

    .line 88
    :cond_1a0
    invoke-static {}, Lcom/vdocipher/aegis/core/t/d;->b()Ljava/lang/String;

    move-result-object v0

    .line 90
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v5

    invoke-direct {v1, v5}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 92
    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->p:Lcom/vdocipher/aegis/core/z/d$b;

    invoke-virtual {p0, v1, v0, v5}, Lcom/vdocipher/aegis/core/m/q;->a(Landroid/os/Handler;Ljava/lang/String;Lcom/vdocipher/aegis/core/z/d$b;)Landroidx/media3/common/MediaItem;

    move-result-object v0

    .line 94
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 95
    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-boolean v6, v5, Lcom/vdocipher/aegis/core/m/y$a;->p:Z

    if-nez v6, :cond_1c9

    .line 96
    iget-object v5, v5, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v5}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result v5

    const-string v6, "isOffline"

    invoke-virtual {v1, v6, v5}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 98
    :cond_1c9
    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v5, v5, Lcom/vdocipher/aegis/core/m/y$a;->b:Ljava/lang/String;

    const-string v6, "metaData"

    invoke-virtual {v1, v6, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 99
    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v5, v5, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v5, v5, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    const-string v6, "mediaId"

    invoke-virtual {v1, v6, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 100
    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v5, v5, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-static {v5}, Lcom/vdocipher/aegis/core/z/d;->a(Lcom/vdocipher/aegis/player/VdoInitParams;)Ljava/lang/String;

    move-result-object v5

    const-string/jumbo v6, "vdoInitParams"

    invoke-virtual {v1, v6, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 101
    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->c:Lcom/vdocipher/aegis/media/PlayerOption;

    invoke-virtual {v5}, Lcom/vdocipher/aegis/media/PlayerOption;->getAudioOnly()Z

    move-result v5

    const-string v6, "isAudio"

    invoke-virtual {v1, v6, v5}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 105
    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v5, v5, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v5, v5, Lcom/vdocipher/aegis/player/VdoInitParams;->vdoMediaMetadata:Lcom/vdocipher/aegis/player/VdoMediaMetadata;

    if-eqz v5, :cond_203

    .line 107
    invoke-virtual {v5}, Lcom/vdocipher/aegis/player/VdoMediaMetadata;->getTitle()Ljava/lang/String;

    move-result-object v6

    goto :goto_209

    :cond_203
    iget-object v6, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v6}, Lcom/vdocipher/aegis/core/f/g;->r()Ljava/lang/String;

    move-result-object v6

    :goto_209
    if-eqz v5, :cond_210

    .line 108
    invoke-virtual {v5}, Lcom/vdocipher/aegis/player/VdoMediaMetadata;->getDescription()Ljava/lang/String;

    move-result-object v7

    goto :goto_216

    :cond_210
    iget-object v7, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v7}, Lcom/vdocipher/aegis/core/f/g;->c()Ljava/lang/String;

    move-result-object v7

    :goto_216
    if-eqz v5, :cond_21d

    .line 109
    invoke-virtual {v5}, Lcom/vdocipher/aegis/player/VdoMediaMetadata;->getPoster()Landroid/net/Uri;

    move-result-object v2

    goto :goto_232

    .line 110
    :cond_21d
    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v5}, Lcom/vdocipher/aegis/core/f/g;->o()[Ljava/lang/String;

    move-result-object v5

    array-length v5, v5

    if-lt v5, v3, :cond_232

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v2}, Lcom/vdocipher/aegis/core/f/g;->o()[Ljava/lang/String;

    move-result-object v2

    aget-object v2, v2, v4

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    .line 111
    :cond_232
    :goto_232
    new-instance v3, Landroidx/media3/common/MediaMetadata$Builder;

    invoke-direct {v3}, Landroidx/media3/common/MediaMetadata$Builder;-><init>()V

    .line 112
    invoke-virtual {v3, v2}, Landroidx/media3/common/MediaMetadata$Builder;->setArtworkUri(Landroid/net/Uri;)Landroidx/media3/common/MediaMetadata$Builder;

    move-result-object v2

    .line 113
    invoke-virtual {v2, v6}, Landroidx/media3/common/MediaMetadata$Builder;->setTitle(Ljava/lang/CharSequence;)Landroidx/media3/common/MediaMetadata$Builder;

    move-result-object v2

    .line 114
    invoke-virtual {v2, v6}, Landroidx/media3/common/MediaMetadata$Builder;->setDisplayTitle(Ljava/lang/CharSequence;)Landroidx/media3/common/MediaMetadata$Builder;

    move-result-object v2

    .line 115
    invoke-virtual {v2, v7}, Landroidx/media3/common/MediaMetadata$Builder;->setDescription(Ljava/lang/CharSequence;)Landroidx/media3/common/MediaMetadata$Builder;

    move-result-object v2

    .line 116
    invoke-virtual {v2, v1}, Landroidx/media3/common/MediaMetadata$Builder;->setExtras(Landroid/os/Bundle;)Landroidx/media3/common/MediaMetadata$Builder;

    move-result-object v1

    .line 117
    invoke-virtual {v1}, Landroidx/media3/common/MediaMetadata$Builder;->build()Landroidx/media3/common/MediaMetadata;

    move-result-object v1

    .line 119
    invoke-virtual {v0}, Landroidx/media3/common/MediaItem;->buildUpon()Landroidx/media3/common/MediaItem$Builder;

    move-result-object v0

    .line 120
    invoke-virtual {v0, v1}, Landroidx/media3/common/MediaItem$Builder;->setMediaMetadata(Landroidx/media3/common/MediaMetadata;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object v0

    .line 121
    invoke-virtual {v0}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    move-result-object v0

    .line 125
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v1, v1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-wide v2, v1, Lcom/vdocipher/aegis/player/VdoInitParams;->startTimeMs:J

    iget-wide v4, p0, Lcom/vdocipher/aegis/core/m/q;->I:J

    cmp-long v4, v2, v4

    if-gez v4, :cond_2ac

    const-wide/16 v4, 0x0

    cmp-long v6, v2, v4

    if-gtz v6, :cond_273

    iget-wide v6, v1, Lcom/vdocipher/aegis/player/VdoInitParams;->endTimeMs:J

    cmp-long v1, v6, v4

    if-lez v1, :cond_2ac

    .line 126
    :cond_273
    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v1

    .line 127
    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v3, v3, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-wide v6, v3, Lcom/vdocipher/aegis/player/VdoInitParams;->endTimeMs:J

    cmp-long v4, v6, v4

    if-lez v4, :cond_289

    const-wide/32 v4, 0x7fffffff

    cmp-long v4, v6, v4

    if-gez v4, :cond_289

    goto :goto_28b

    :cond_289
    const-wide/high16 v6, -0x8000000000000000L

    .line 130
    :goto_28b
    iget-boolean v3, v3, Lcom/vdocipher/aegis/player/VdoInitParams;->clipped:Z

    if-eqz v3, :cond_2ac

    .line 131
    invoke-virtual {v0}, Landroidx/media3/common/MediaItem;->buildUpon()Landroidx/media3/common/MediaItem$Builder;

    move-result-object v0

    new-instance v3, Landroidx/media3/common/MediaItem$ClippingConfiguration$Builder;

    invoke-direct {v3}, Landroidx/media3/common/MediaItem$ClippingConfiguration$Builder;-><init>()V

    .line 132
    invoke-virtual {v3, v1, v2}, Landroidx/media3/common/MediaItem$ClippingConfiguration$Builder;->setStartPositionMs(J)Landroidx/media3/common/MediaItem$ClippingConfiguration$Builder;

    move-result-object v1

    .line 133
    invoke-virtual {v1, v6, v7}, Landroidx/media3/common/MediaItem$ClippingConfiguration$Builder;->setEndPositionMs(J)Landroidx/media3/common/MediaItem$ClippingConfiguration$Builder;

    move-result-object v1

    .line 134
    invoke-virtual {v1}, Landroidx/media3/common/MediaItem$ClippingConfiguration$Builder;->build()Landroidx/media3/common/MediaItem$ClippingConfiguration;

    move-result-object v1

    .line 135
    invoke-virtual {v0, v1}, Landroidx/media3/common/MediaItem$Builder;->setClippingConfiguration(Landroidx/media3/common/MediaItem$ClippingConfiguration;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object v0

    .line 138
    invoke-virtual {v0}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    move-result-object v0

    .line 142
    :cond_2ac
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget v2, v2, Lcom/vdocipher/aegis/core/m/y$a;->i:F

    invoke-interface {v1, v2}, Landroidx/media3/common/Player;->setPlaybackSpeed(F)V

    .line 143
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object v2, v2, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-boolean v2, v2, Lcom/vdocipher/aegis/player/VdoInitParams;->autoplay:Z

    invoke-interface {v1, v2}, Landroidx/media3/common/Player;->setPlayWhenReady(Z)V

    .line 144
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v1, v0}, Landroidx/media3/common/Player;->setMediaItem(Landroidx/media3/common/MediaItem;)V

    .line 145
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0}, Landroidx/media3/common/Player;->prepare()V

    .line 147
    new-instance v0, Lcom/vdocipher/aegis/core/m/j;

    invoke-direct {v0}, Lcom/vdocipher/aegis/core/m/j;-><init>()V

    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/core/m/j;)V

    return-void
.end method

.method private d(Z)V
    .registers 4

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/16 v1, 0x65

    invoke-virtual {v0, v1, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void
.end method

.method static synthetic d(Lcom/vdocipher/aegis/core/m/q;)Z
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->h()Z

    move-result p0

    return p0
.end method

.method static synthetic d(Lcom/vdocipher/aegis/core/m/q;Z)Z
    .registers 2

    .line 2
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/q;->a:Z

    return p1
.end method

.method static synthetic e(Lcom/vdocipher/aegis/core/m/q;)Landroidx/media3/common/Player;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    return-object p0
.end method

.method private e()[Lcom/vdocipher/aegis/media/Track;
    .registers 14

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    const/4 v1, 0x0

    if-nez v0, :cond_8

    .line 3
    new-array v0, v1, [Lcom/vdocipher/aegis/media/Track;

    return-object v0

    .line 6
    :cond_8
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 9
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v2}, Landroidx/media3/common/Player;->getCurrentTracks()Landroidx/media3/common/Tracks;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/media3/common/Tracks;->getGroups()Lcom/google/common/collect/ImmutableList;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/common/collect/ImmutableList;->iterator()Lcom/google/common/collect/UnmodifiableIterator;

    move-result-object v2

    move v3, v1

    :goto_1c
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_6c

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/media3/common/Tracks$Group;

    .line 10
    invoke-virtual {v4}, Landroidx/media3/common/Tracks$Group;->getMediaTrackGroup()Landroidx/media3/common/TrackGroup;

    move-result-object v5

    .line 11
    invoke-virtual {v4}, Landroidx/media3/common/Tracks$Group;->getType()I

    move-result v6

    .line 13
    iget-object v7, v5, Landroidx/media3/common/TrackGroup;->id:Ljava/lang/String;

    move v8, v1

    .line 15
    :goto_33
    iget v9, v5, Landroidx/media3/common/TrackGroup;->length:I

    if-ge v8, v9, :cond_69

    const/4 v9, 0x1

    .line 17
    invoke-virtual {v4, v8, v9}, Landroidx/media3/common/Tracks$Group;->isTrackSupported(IZ)Z

    move-result v9

    if-eqz v9, :cond_66

    .line 18
    invoke-virtual {v5, v8}, Landroidx/media3/common/TrackGroup;->getFormat(I)Landroidx/media3/common/Format;

    move-result-object v9

    const/4 v10, 0x3

    if-ne v6, v10, :cond_4a

    .line 21
    iget-object v10, v9, Landroidx/media3/common/Format;->label:Ljava/lang/String;

    if-nez v10, :cond_4a

    goto :goto_66

    :cond_4a
    const/4 v10, 0x2

    if-ne v6, v10, :cond_52

    .line 24
    iget v11, v9, Landroidx/media3/common/Format;->bitrate:I

    if-gtz v11, :cond_52

    goto :goto_66

    .line 28
    :cond_52
    invoke-static {v3, v7, v8, v6, v9}, Lcom/vdocipher/aegis/core/t/d;->a(ILjava/lang/String;IILandroidx/media3/common/Format;)Lcom/vdocipher/aegis/media/Track;

    move-result-object v11

    if-ne v6, v10, :cond_63

    .line 32
    sget-object v10, Lcom/vdocipher/aegis/core/z/d;->a:Lcom/vdocipher/aegis/core/z/d;

    iget-object v12, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-virtual {v10, v12, v9}, Lcom/vdocipher/aegis/core/z/d;->a(Landroid/content/Context;Landroidx/media3/common/Format;)Z

    move-result v9

    if-nez v9, :cond_63

    goto :goto_66

    .line 36
    :cond_63
    invoke-interface {v0, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_66
    :goto_66
    add-int/lit8 v8, v8, 0x1

    goto :goto_33

    :cond_69
    add-int/lit8 v3, v3, 0x1

    goto :goto_1c

    .line 42
    :cond_6c
    new-array v1, v1, [Lcom/vdocipher/aegis/media/Track;

    invoke-interface {v0, v1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/aegis/media/Track;

    return-object v0
.end method

.method private f()I
    .registers 9

    .line 2
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/m/q;->getAvailableTracks()[Lcom/vdocipher/aegis/media/Track;

    move-result-object v0

    .line 3
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    array-length v2, v0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " tracks available"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "VdoExo"

    invoke-static {v2, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 4
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 5
    array-length v2, v0

    const/4 v3, 0x0

    move v4, v3

    :goto_23
    const/4 v5, 0x3

    if-ge v4, v2, :cond_32

    aget-object v6, v0, v4

    .line 6
    iget v7, v6, Lcom/vdocipher/aegis/media/Track;->type:I

    if-ne v7, v5, :cond_2f

    .line 7
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2f
    add-int/lit8 v4, v4, 0x1

    goto :goto_23

    .line 12
    :cond_32
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/m/q;->getSelectedTracks()[Lcom/vdocipher/aegis/media/Track;

    move-result-object v0

    .line 14
    array-length v2, v0

    move v4, v3

    :goto_38
    if-ge v4, v2, :cond_44

    aget-object v6, v0, v4

    .line 15
    iget v7, v6, Lcom/vdocipher/aegis/media/Track;->type:I

    if-ne v7, v5, :cond_41

    goto :goto_45

    :cond_41
    add-int/lit8 v4, v4, 0x1

    goto :goto_38

    :cond_44
    const/4 v6, 0x0

    :goto_45
    if-eqz v6, :cond_5d

    .line 24
    :goto_47
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v3, v0, :cond_5d

    .line 25
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/aegis/media/Track;

    invoke-virtual {v0, v6}, Lcom/vdocipher/aegis/media/Track;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5a

    return v3

    :cond_5a
    add-int/lit8 v3, v3, 0x1

    goto :goto_47

    :cond_5d
    const/4 v0, -0x1

    return v0
.end method

.method static synthetic f(Lcom/vdocipher/aegis/core/m/q;)Landroid/view/SurfaceView;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/q;->d:Landroid/view/SurfaceView;

    return-object p0
.end method

.method static synthetic g(Lcom/vdocipher/aegis/core/m/q;)I
    .registers 1

    .line 1
    iget p0, p0, Lcom/vdocipher/aegis/core/m/q;->x:I

    return p0
.end method

.method private g()[Lcom/vdocipher/aegis/media/Track;
    .registers 11

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    const/4 v1, 0x0

    if-nez v0, :cond_8

    .line 3
    new-array v0, v1, [Lcom/vdocipher/aegis/media/Track;

    return-object v0

    .line 6
    :cond_8
    invoke-interface {v0}, Landroidx/media3/common/Player;->getCurrentTracks()Landroidx/media3/common/Tracks;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/media3/common/Tracks;->getGroups()Lcom/google/common/collect/ImmutableList;

    move-result-object v0

    .line 9
    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 12
    invoke-virtual {v0}, Lcom/google/common/collect/ImmutableList;->iterator()Lcom/google/common/collect/UnmodifiableIterator;

    move-result-object v0

    move v3, v1

    :goto_1a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_36

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/media3/common/Tracks$Group;

    .line 13
    invoke-virtual {v4}, Landroidx/media3/common/Tracks$Group;->isSelected()Z

    move-result v5

    if-eqz v5, :cond_33

    .line 14
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v2, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_33
    add-int/lit8 v3, v3, 0x1

    goto :goto_1a

    .line 19
    :cond_36
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 21
    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_43
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_9f

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map$Entry;

    .line 22
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/media3/common/Tracks$Group;

    invoke-virtual {v4}, Landroidx/media3/common/Tracks$Group;->getMediaTrackGroup()Landroidx/media3/common/TrackGroup;

    move-result-object v4

    .line 23
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/media3/common/Tracks$Group;

    invoke-virtual {v5}, Landroidx/media3/common/Tracks$Group;->getType()I

    move-result v5

    .line 25
    iget-object v6, v4, Landroidx/media3/common/TrackGroup;->id:Ljava/lang/String;

    move v7, v1

    .line 27
    :goto_66
    iget v8, v4, Landroidx/media3/common/TrackGroup;->length:I

    if-ge v7, v8, :cond_43

    .line 29
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroidx/media3/common/Tracks$Group;

    invoke-virtual {v8, v7}, Landroidx/media3/common/Tracks$Group;->isTrackSelected(I)Z

    move-result v8

    if-nez v8, :cond_77

    goto :goto_9c

    .line 32
    :cond_77
    invoke-virtual {v4, v7}, Landroidx/media3/common/TrackGroup;->getFormat(I)Landroidx/media3/common/Format;

    move-result-object v8

    const/4 v9, 0x3

    if-ne v5, v9, :cond_83

    .line 35
    iget-object v9, v8, Landroidx/media3/common/Format;->label:Ljava/lang/String;

    if-nez v9, :cond_83

    goto :goto_9c

    :cond_83
    const/4 v9, 0x2

    if-ne v5, v9, :cond_8b

    .line 38
    iget v9, v8, Landroidx/media3/common/Format;->bitrate:I

    if-gtz v9, :cond_8b

    goto :goto_9c

    .line 41
    :cond_8b
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Integer;

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    invoke-static {v9, v6, v7, v5, v8}, Lcom/vdocipher/aegis/core/t/d;->a(ILjava/lang/String;IILandroidx/media3/common/Format;)Lcom/vdocipher/aegis/media/Track;

    move-result-object v8

    .line 42
    invoke-interface {v0, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_9c
    add-int/lit8 v7, v7, 0x1

    goto :goto_66

    .line 46
    :cond_9f
    new-array v1, v1, [Lcom/vdocipher/aegis/media/Track;

    invoke-interface {v0, v1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/aegis/media/Track;

    return-object v0
.end method

.method static synthetic h(Lcom/vdocipher/aegis/core/m/q;)Ljava/lang/ref/WeakReference;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/q;->k:Ljava/lang/ref/WeakReference;

    return-object p0
.end method

.method private h()Z
    .registers 8

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    .line 6
    :cond_6
    iget-boolean v2, v0, Landroidx/media3/common/TrackSelectionParameters;->forceHighestSupportedBitrate:Z

    if-nez v2, :cond_37

    iget-boolean v0, v0, Landroidx/media3/common/TrackSelectionParameters;->forceLowestBitrate:Z

    if-eqz v0, :cond_f

    goto :goto_37

    .line 8
    :cond_f
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    if-eqz v0, :cond_1e

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    if-eqz v0, :cond_1e

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/f;->c()Z

    move-result v0

    if-eqz v0, :cond_1e

    return v1

    .line 16
    :cond_1e
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/m/q;->getSelectedTracks()[Lcom/vdocipher/aegis/media/Track;

    move-result-object v0

    .line 17
    array-length v2, v0

    move v3, v1

    move v4, v3

    :goto_25
    if-ge v3, v2, :cond_33

    aget-object v5, v0, v3

    .line 18
    iget v5, v5, Lcom/vdocipher/aegis/media/Track;->type:I

    const/4 v6, 0x2

    if-ne v5, v6, :cond_30

    add-int/lit8 v4, v4, 0x1

    :cond_30
    add-int/lit8 v3, v3, 0x1

    goto :goto_25

    :cond_33
    const/4 v0, 0x1

    if-le v4, v0, :cond_37

    return v0

    :cond_37
    :goto_37
    return v1
.end method

.method private i()V
    .registers 2

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    if-nez v0, :cond_5

    goto :goto_28

    .line 5
    :cond_5
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->l()V

    .line 8
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-boolean v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->m:Z

    if-nez v0, :cond_1b

    .line 9
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0}, Landroidx/media3/common/Player;->clearVideoSurface()V

    .line 10
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0}, Landroidx/media3/common/Player;->clearMediaItems()V

    .line 11
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->d()V

    .line 14
    :cond_1b
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->b()V

    .line 16
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-boolean v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->m:Z

    if-eqz v0, :cond_28

    const/4 v0, 0x0

    .line 22
    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/m/q;->a(Z)V

    :cond_28
    :goto_28
    return-void
.end method

.method static synthetic i(Lcom/vdocipher/aegis/core/m/q;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcom/vdocipher/aegis/core/m/q;->r:Z

    return p0
.end method

.method static synthetic j(Lcom/vdocipher/aegis/core/m/q;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcom/vdocipher/aegis/core/m/q;->B:Z

    return p0
.end method

.method private k()V
    .registers 4

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->h:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_6
    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1c

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 3
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    if-eqz v2, :cond_6

    .line 4
    iget-object v2, v2, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-interface {v1, v2}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onMediaEnded(Lcom/vdocipher/aegis/player/VdoInitParams;)V

    goto :goto_6

    :cond_1c
    return-void
.end method

.method static synthetic k(Lcom/vdocipher/aegis/core/m/q;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->d()V

    return-void
.end method

.method private l()V
    .registers 2

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0}, Landroidx/media3/common/Player;->getTrackSelectionParameters()Landroidx/media3/common/TrackSelectionParameters;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->o:Landroidx/media3/common/TrackSelectionParameters;

    return-void
.end method

.method static synthetic l(Lcom/vdocipher/aegis/core/m/q;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcom/vdocipher/aegis/core/m/q;->a:Z

    return p0
.end method

.method static synthetic m(Lcom/vdocipher/aegis/core/m/q;)Ljava/util/concurrent/CopyOnWriteArraySet;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/q;->h:Ljava/util/concurrent/CopyOnWriteArraySet;

    return-object p0
.end method

.method private m()V
    .registers 3

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->O:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->O:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method static synthetic n(Lcom/vdocipher/aegis/core/m/q;)Ljava/lang/Runnable;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/m/q;->O:Ljava/lang/Runnable;

    return-object p0
.end method


# virtual methods
.method protected abstract a(Landroid/os/Handler;Ljava/lang/String;Lcom/vdocipher/aegis/core/z/d$b;)Landroidx/media3/common/MediaItem;
.end method

.method protected abstract a(Landroidx/media3/common/PlaybackException;)Lcom/vdocipher/aegis/core/m/p;
.end method

.method public a()V
    .registers 3

    const/4 v0, 0x0

    .line 31
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    .line 32
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->h:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArraySet;->clear()V

    .line 33
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 34
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->i:Ljava/lang/ref/WeakReference;

    .line 35
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->d:Landroid/view/SurfaceView;

    .line 36
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->j:Ljava/lang/ref/WeakReference;

    .line 37
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->k:Ljava/lang/ref/WeakReference;

    .line 38
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->P:Landroidx/media3/common/Player$Listener;

    .line 41
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 42
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->O:Ljava/lang/Runnable;

    .line 43
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    .line 44
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->K:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 45
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->J:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->quitSafely()Z

    .line 46
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->K:Landroid/os/Handler;

    return-void
.end method

.method public a(Lcom/vdocipher/aegis/core/m/y$a;)V
    .registers 4

    const/4 v0, 0x0

    .line 8
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/m/q;->A:Z

    .line 9
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    .line 11
    :try_start_5
    new-instance v0, Lcom/vdocipher/aegis/core/f/g;

    iget-object v1, p1, Lcom/vdocipher/aegis/core/m/y$a;->b:Ljava/lang/String;

    invoke-direct {v0, v1}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_e} :catch_44

    .line 16
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->f:Lcom/vdocipher/aegis/core/n/b;

    if-eqz v0, :cond_15

    .line 17
    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/n/b;->a()V

    .line 19
    :cond_15
    iget-object v0, p1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-boolean v0, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->allowAdbDebugging:Z

    if-nez v0, :cond_41

    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/t/d;->c(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_41

    .line 20
    new-instance v0, Lcom/vdocipher/aegis/core/n/b;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-direct {v0, v1}, Lcom/vdocipher/aegis/core/n/b;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->f:Lcom/vdocipher/aegis/core/n/b;

    .line 22
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/n/a;->a(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_38

    .line 23
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/m/q;->onAdbEnabled()V

    goto :goto_3b

    .line 25
    :cond_38
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->b(Lcom/vdocipher/aegis/core/m/y$a;)V

    .line 28
    :goto_3b
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->f:Lcom/vdocipher/aegis/core/n/b;

    invoke-virtual {p1, p0}, Lcom/vdocipher/aegis/core/n/b;->a(Lcom/vdocipher/aegis/core/n/b$a;)V

    return-void

    .line 30
    :cond_41
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->b(Lcom/vdocipher/aegis/core/m/y$a;)V

    :catch_44
    return-void
.end method

.method public a(Ljava/lang/ref/WeakReference;)V
    .registers 2

    .line 47
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->j:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method a(Ljava/lang/Throwable;)Z
    .registers 4

    :goto_0
    if-eqz p1, :cond_1f

    .line 216
    instance-of v0, p1, Ljava/lang/IllegalStateException;

    if-nez v0, :cond_a

    instance-of v0, p1, Ljava/lang/IllegalArgumentException;

    if-eqz v0, :cond_1a

    .line 217
    :cond_a
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1a

    .line 218
    const-string v1, "setSurface"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1a

    const/4 p1, 0x1

    return p1

    .line 222
    :cond_1a
    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    goto :goto_0

    :cond_1f
    const/4 p1, 0x0

    return p1
.end method

.method public addPlaybackEventListener(Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;)V
    .registers 3

    if-eqz p1, :cond_7

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->h:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/CopyOnWriteArraySet;->add(Ljava/lang/Object;)Z

    :cond_7
    return-void
.end method

.method protected abstract b(Lcom/vdocipher/aegis/core/m/y$a;)V
.end method

.method b(Ljava/lang/String;)V
    .registers 4

    .line 19
    new-instance v0, Ljava/lang/String;

    const/4 v1, 0x2

    invoke-static {p1, v1}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p1

    const-string v1, "UTF-8"

    invoke-direct {v0, p1, v1}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    .line 20
    invoke-static {v0}, Lcom/vdocipher/aegis/core/t/d;->j(Ljava/lang/String;)[Lcom/vdocipher/aegis/core/v/b;

    move-result-object p1

    .line 21
    array-length v0, p1

    if-nez v0, :cond_14

    return-void

    .line 24
    :cond_14
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p1}, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/core/m/q;[Lcom/vdocipher/aegis/core/v/b;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public b(Ljava/lang/ref/WeakReference;)V
    .registers 2

    .line 4
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->k:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method c(Ljava/lang/String;)V
    .registers 4

    .line 91
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    if-eqz v0, :cond_9

    .line 92
    const-string v1, ""

    invoke-virtual {v0, p1, v1}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_9
    return-void
.end method

.method public c(Ljava/lang/ref/WeakReference;)V
    .registers 2

    .line 3
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->i:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method public getAvailableTracks()[Lcom/vdocipher/aegis/media/Track;
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->e()[Lcom/vdocipher/aegis/media/Track;

    move-result-object v0

    return-object v0
.end method

.method public getBufferedTime()J
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    if-eqz v0, :cond_9

    .line 2
    invoke-interface {v0}, Landroidx/media3/common/Player;->getBufferedPosition()J

    move-result-wide v0

    return-wide v0

    :cond_9
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public getCurrentLiveOffset()J
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0}, Landroidx/media3/common/Player;->getCurrentLiveOffset()J

    move-result-wide v0

    return-wide v0
.end method

.method public getCurrentMedia()Lcom/vdocipher/aegis/media/MediaInfo;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->C:Lcom/vdocipher/aegis/media/MediaInfo;

    return-object v0
.end method

.method public getCurrentMediaItemIndex()I
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0}, Landroidx/media3/common/Player;->getCurrentMediaItemIndex()I

    move-result v0

    return v0
.end method

.method public getCurrentTime()J
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    if-eqz v0, :cond_9

    .line 2
    invoke-interface {v0}, Landroidx/media3/common/Player;->getCurrentPosition()J

    move-result-wide v0

    return-wide v0

    :cond_9
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public getCurrentTimeline()Lcom/vdocipher/aegis/player/VdoTimeLine;
    .registers 3

    .line 1
    new-instance v0, Lcom/vdocipher/aegis/core/m/m;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v1}, Landroidx/media3/common/Player;->getCurrentTimeline()Landroidx/media3/common/Timeline;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/vdocipher/aegis/core/m/m;-><init>(Landroidx/media3/common/Timeline;)V

    return-object v0
.end method

.method public getDuration()J
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    if-eqz v0, :cond_9

    .line 2
    invoke-interface {v0}, Landroidx/media3/common/Player;->getDuration()J

    move-result-wide v0

    return-wide v0

    :cond_9
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public getPlayWhenReady()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    if-eqz v0, :cond_9

    invoke-interface {v0}, Landroidx/media3/common/Player;->getPlayWhenReady()Z

    move-result v0

    return v0

    .line 2
    :cond_9
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    if-eqz v0, :cond_15

    iget-object v0, v0, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-boolean v0, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->autoplay:Z

    if-eqz v0, :cond_15

    const/4 v0, 0x1

    return v0

    :cond_15
    const/4 v0, 0x0

    return v0
.end method

.method public getPlaybackProperty(Ljava/lang/String;)Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->a(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public getPlaybackSpeed()F
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    if-eqz v0, :cond_b

    invoke-interface {v0}, Landroidx/media3/common/Player;->getPlaybackParameters()Landroidx/media3/common/PlaybackParameters;

    move-result-object v0

    iget v0, v0, Landroidx/media3/common/PlaybackParameters;->speed:F

    return v0

    :cond_b
    const/high16 v0, 0x3f800000  # 1.0f

    return v0
.end method

.method public getPlaybackState()I
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    const/4 v1, 0x1

    if-eqz v0, :cond_14

    .line 2
    invoke-interface {v0}, Landroidx/media3/common/Player;->getPlaybackState()I

    move-result v0

    const/4 v2, 0x2

    if-eq v0, v2, :cond_13

    const/4 v2, 0x3

    if-eq v0, v2, :cond_13

    const/4 v2, 0x4

    if-eq v0, v2, :cond_13

    return v1

    :cond_13
    return v2

    :cond_14
    return v1
.end method

.method public getSelectedTracks()[Lcom/vdocipher/aegis/media/Track;
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->g()[Lcom/vdocipher/aegis/media/Track;

    move-result-object v0

    return-object v0
.end method

.method public handleMessage(Landroid/os/Message;)Z
    .registers 8

    .line 1
    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_100

    const/4 v2, 0x2

    const-string v3, "VdoExo"

    if-eq v0, v2, :cond_b3

    const/4 v2, 0x0

    packed-switch v0, :pswitch_data_114

    return v2

    .line 90
    :pswitch_f  #0x6d
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast p1, Landroid/util/Pair;

    .line 91
    iget-object v0, p1, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v0, Lcom/vdocipher/aegis/player/VdoTimeLine;

    iget-object p1, p1, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-direct {p0, v0, p1}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/player/VdoTimeLine;I)V

    return v1

    .line 92
    :pswitch_23  #0x6c
    const-string v0, "exo error"

    invoke-static {v3, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 93
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/q;->z:Z

    if-nez v0, :cond_38

    .line 94
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    invoke-virtual {v0, v1, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    goto :goto_45

    .line 97
    :cond_38
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/16 v2, 0x67

    invoke-virtual {v0, v2, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    :goto_45
    return v1

    .line 98
    :pswitch_46  #0x6b
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->a(F)V

    return v1

    .line 102
    :pswitch_52  #0x6a
    iget-boolean p1, p0, Lcom/vdocipher/aegis/core/m/q;->A:Z

    if-eqz p1, :cond_57

    return v1

    .line 103
    :cond_57
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->k()V

    return v1

    .line 104
    :pswitch_5b  #0x69
    iget v0, p1, Landroid/os/Message;->arg1:I

    if-eqz v0, :cond_60

    move v2, v1

    :cond_60
    iget p1, p1, Landroid/os/Message;->arg2:I

    invoke-direct {p0, v2, p1}, Lcom/vdocipher/aegis/core/m/q;->a(ZI)V

    return v1

    .line 109
    :pswitch_66  #0x68
    :try_start_66
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast p1, Landroid/util/Pair;

    .line 110
    iget-object v0, p1, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v0, [Lcom/vdocipher/aegis/media/Track;

    iget-object p1, p1, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast p1, [Lcom/vdocipher/aegis/media/Track;

    invoke-direct {p0, v0, p1}, Lcom/vdocipher/aegis/core/m/q;->a([Lcom/vdocipher/aegis/media/Track;[Lcom/vdocipher/aegis/media/Track;)V
    :try_end_75
    .catch Ljava/lang/ClassCastException; {:try_start_66 .. :try_end_75} :catch_76

    goto :goto_7e

    :catch_76
    move-exception p1

    .line 112
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v3, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :goto_7e
    return v1

    .line 141
    :pswitch_7f  #0x67
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/q;->A:Z

    if-eqz v0, :cond_84

    return v1

    .line 142
    :cond_84
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast p1, Lcom/vdocipher/aegis/core/m/p;

    .line 143
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/core/m/p;)V

    :pswitch_8b  #0x66
    return v1

    .line 144
    :pswitch_8c  #0x65
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/q;->A:Z

    if-eqz v0, :cond_91

    return v1

    .line 145
    :cond_91
    iput-boolean v1, p0, Lcom/vdocipher/aegis/core/m/q;->z:Z

    .line 146
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    .line 147
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->c(Z)V

    .line 151
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/y$a;->g:Ljava/lang/String;

    if-eqz p1, :cond_b2

    .line 153
    :try_start_a4
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->b(Ljava/lang/String;)V
    :try_end_a7
    .catch Lorg/json/JSONException; {:try_start_a4 .. :try_end_a7} :catch_aa
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_a4 .. :try_end_a7} :catch_a8

    goto :goto_b2

    :catch_a8
    move-exception p1

    goto :goto_ab

    :catch_aa
    move-exception p1

    .line 155
    :goto_ab
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v3, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_b2
    :goto_b2
    return v1

    .line 156
    :cond_b3
    iget-boolean p1, p0, Lcom/vdocipher/aegis/core/m/q;->A:Z

    if-nez p1, :cond_f9

    iget-boolean p1, p0, Lcom/vdocipher/aegis/core/m/q;->B:Z

    if-eqz p1, :cond_bc

    goto :goto_f9

    .line 161
    :cond_bc
    :try_start_bc
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->i()V
    :try_end_bf
    .catch Ljava/lang/Exception; {:try_start_bc .. :try_end_bf} :catch_c2
    .catch Ljava/lang/NoClassDefFoundError; {:try_start_bc .. :try_end_bf} :catch_c0

    goto :goto_f8

    :catch_c0
    move-exception p1

    goto :goto_c3

    :catch_c2
    move-exception p1

    .line 163
    :goto_c3
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    .line 164
    invoke-static {v3, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 165
    new-instance v2, Lcom/vdocipher/aegis/core/m/d;

    const/4 v3, -0x1

    const/4 v4, 0x0

    const-string/jumbo v5, "startFail"

    invoke-direct {v2, v5, v3, v4, v0}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 167
    instance-of v0, p1, Landroidx/media3/exoplayer/drm/UnsupportedDrmException;

    if-eqz v0, :cond_e4

    .line 168
    check-cast p1, Landroidx/media3/exoplayer/drm/UnsupportedDrmException;

    iget p1, p1, Landroidx/media3/exoplayer/drm/UnsupportedDrmException;->reason:I

    if-ne p1, v1, :cond_e1

    const/16 p1, 0x4e3

    goto :goto_e6

    :cond_e1
    const/16 p1, 0x1807

    goto :goto_e6

    :cond_e4
    const/16 p1, 0x17d5

    .line 174
    :goto_e6
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    new-instance v3, Lcom/vdocipher/aegis/core/m/p;

    .line 175
    invoke-static {p1}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, p1, v4, v2}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    .line 176
    invoke-virtual {v0, v1, v3}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    .line 178
    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    :goto_f8
    return v1

    .line 179
    :cond_f9
    :goto_f9
    const-string/jumbo p1, "stopped or released, skip start"

    invoke-static {v3, p1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    return v1

    .line 221
    :cond_100
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/q;->A:Z

    if-eqz v0, :cond_105

    return v1

    .line 222
    :cond_105
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/q;->z:Z

    if-nez v0, :cond_112

    .line 223
    iput-boolean v1, p0, Lcom/vdocipher/aegis/core/m/q;->z:Z

    .line 224
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast p1, Lcom/vdocipher/aegis/core/m/p;

    .line 225
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/q;->b(Lcom/vdocipher/aegis/core/m/p;)V

    :cond_112
    return v1

    nop

    :pswitch_data_114
    .packed-switch 0x65
        :pswitch_8c  #00000065
        :pswitch_8b  #00000066
        :pswitch_7f  #00000067
        :pswitch_66  #00000068
        :pswitch_5b  #00000069
        :pswitch_52  #0000006a
        :pswitch_46  #0000006b
        :pswitch_23  #0000006c
        :pswitch_f  #0000006d
    .end packed-switch
.end method

.method public isAdaptive()Z
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->h()Z

    move-result v0

    return v0
.end method

.method public isCurrentMediaItemLive()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0}, Landroidx/media3/common/Player;->isCurrentMediaItemLive()Z

    move-result v0

    return v0
.end method

.method public isCurrentMediaItemSeekable()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0}, Landroidx/media3/common/Player;->isCurrentMediaItemSeekable()Z

    move-result v0

    return v0
.end method

.method public isCurrentWindowDynamic()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0}, Landroidx/media3/common/Player;->isCurrentMediaItemDynamic()Z

    move-result v0

    return v0
.end method

.method public isSpeedControlSupported()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method protected abstract j()V
.end method

.method public load(Lcom/vdocipher/aegis/player/VdoInitParams;)V
    .registers 2

    return-void
.end method

.method public onAdbEnabled()V
    .registers 5

    .line 1
    new-instance v0, Lcom/vdocipher/aegis/core/m/d;

    const/4 v1, -0x1

    const/4 v2, 0x0

    const-string v3, "adb"

    invoke-direct {v0, v3, v1, v2, v2}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 3
    new-instance v1, Lcom/vdocipher/aegis/core/m/p;

    const/16 v2, 0x4b2

    .line 5
    invoke-static {v2}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v2, v3, v0}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    .line 7
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    const/16 v2, 0x67

    invoke-virtual {v0, v2, v1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 10
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda1;-><init>(Lcom/vdocipher/aegis/core/m/q;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public release()V
    .registers 2

    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/m/q;->B:Z

    return-void
.end method

.method public removePlaybackEventListener(Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;)V
    .registers 3

    if-eqz p1, :cond_7

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->h:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/CopyOnWriteArraySet;->remove(Ljava/lang/Object;)Z

    :cond_7
    return-void
.end method

.method public retry()V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    if-eqz v0, :cond_d

    .line 2
    invoke-interface {v0}, Landroidx/media3/common/Player;->prepare()V

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    const/4 v1, 0x1

    invoke-interface {v0, v1}, Landroidx/media3/common/Player;->setPlayWhenReady(Z)V

    :cond_d
    return-void
.end method

.method public searchInSelectedSubtitle(Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/q;->f()I

    move-result v0

    if-gez v0, :cond_c

    .line 3
    sget-object p1, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;->CAPTION_NOT_SELECTED:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;

    invoke-interface {p2, p1}, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;->onError(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;)V

    return-void

    .line 6
    :cond_c
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_23

    .line 7
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/aegis/media/Caption;

    .line 8
    invoke-virtual {v0}, Lcom/vdocipher/aegis/media/Caption;->getUrl()Ljava/lang/String;

    move-result-object v0

    .line 9
    invoke-direct {p0, v0, p1, p2}, Lcom/vdocipher/aegis/core/m/q;->a(Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V

    :cond_23
    return-void
.end method

.method public seekTo(J)V
    .registers 6

    .line 1
    :try_start_0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    if-eqz v0, :cond_16

    long-to-int v1, p1

    .line 2
    div-int/lit16 v1, v1, 0x3e8

    const/4 v2, 0x1

    invoke-static {v0, v2, v1}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/d/k;ZI)V
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_b} :catch_c

    goto :goto_16

    :catch_c
    move-exception v0

    .line 4
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "VdoExo"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 6
    :cond_16
    :goto_16
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    if-eqz v0, :cond_3a

    .line 7
    invoke-interface {v0, p1, p2}, Landroidx/media3/common/Player;->seekTo(J)V

    .line 8
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object p1, p1, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_2a

    goto :goto_3a

    .line 10
    :cond_2a
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {p1}, Landroidx/media3/common/Player;->getCurrentPosition()J

    move-result-wide p1

    .line 11
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->K:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, p1, p2}, Lcom/vdocipher/aegis/core/m/q$$ExternalSyntheticLambda2;-><init>(Lcom/vdocipher/aegis/core/m/q;J)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_3a
    :goto_3a
    return-void
.end method

.method public seekToDefaultPosition()V
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0}, Landroidx/media3/common/Player;->seekToDefaultPosition()V

    return-void
.end method

.method public setAutoResumeCallback(Lcom/vdocipher/aegis/player/internal/util/AutoResumeCallback;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->m:Lcom/vdocipher/aegis/player/internal/util/AutoResumeCallback;

    return-void
.end method

.method public setPlayWhenReady(Z)V
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    if-nez v0, :cond_5

    return-void

    .line 5
    :cond_5
    instance-of v1, v0, Landroidx/media3/session/MediaController;

    if-eqz v1, :cond_1d

    .line 6
    check-cast v0, Landroidx/media3/session/MediaController;

    .line 7
    invoke-virtual {v0}, Landroidx/media3/session/MediaController;->isConnected()Z

    move-result v1

    if-eqz v1, :cond_1d

    invoke-virtual {v0}, Landroidx/media3/session/MediaController;->getPlaybackState()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1d

    .line 8
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0}, Landroidx/media3/common/Player;->prepare()V

    .line 12
    :cond_1d
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {v0, p1}, Landroidx/media3/common/Player;->setPlayWhenReady(Z)V

    return-void
.end method

.method public setPlaybackSpeed(F)V
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    if-eqz v0, :cond_18

    const/4 v0, 0x0

    cmpl-float v0, p1, v0

    if-lez v0, :cond_11

    .line 2
    new-instance v0, Landroidx/media3/common/PlaybackParameters;

    const/high16 v1, 0x3f800000  # 1.0f

    invoke-direct {v0, p1, v1}, Landroidx/media3/common/PlaybackParameters;-><init>(FF)V

    goto :goto_13

    .line 3
    :cond_11
    sget-object v0, Landroidx/media3/common/PlaybackParameters;->DEFAULT:Landroidx/media3/common/PlaybackParameters;

    .line 4
    :goto_13
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    invoke-interface {p1, v0}, Landroidx/media3/common/Player;->setPlaybackParameters(Landroidx/media3/common/PlaybackParameters;)V

    :cond_18
    return-void
.end method

.method public setSelectedTracks([Lcom/vdocipher/aegis/media/Track;)V
    .registers 8

    if-eqz p1, :cond_4a

    .line 1
    array-length v0, p1

    if-nez v0, :cond_6

    goto :goto_4a

    .line 4
    :cond_6
    array-length v0, p1

    const/4 v1, 0x0

    move v2, v1

    :goto_9
    if-ge v2, v0, :cond_34

    aget-object v3, p1, v2

    .line 5
    iget v4, v3, Lcom/vdocipher/aegis/media/Track;->type:I

    const/4 v5, 0x3

    if-ne v4, v5, :cond_31

    .line 6
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    if-eqz v0, :cond_34

    .line 7
    sget-object v2, Lcom/vdocipher/aegis/media/Track;->DISABLE_CAPTIONS:Lcom/vdocipher/aegis/media/Track;

    const-string v4, ""

    if-ne v3, v2, :cond_24

    .line 8
    const-string v2, "captionVisibilityFalse"

    invoke-virtual {v0, v2, v4}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 9
    iput-boolean v1, p0, Lcom/vdocipher/aegis/core/m/q;->L:Z

    goto :goto_34

    .line 11
    :cond_24
    iget-boolean v2, p0, Lcom/vdocipher/aegis/core/m/q;->L:Z

    if-nez v2, :cond_34

    .line 12
    const-string v2, "captionVisibilityTrue"

    invoke-virtual {v0, v2, v4}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x1

    .line 13
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/m/q;->L:Z

    goto :goto_34

    :cond_31
    add-int/lit8 v2, v2, 0x1

    goto :goto_9

    .line 21
    :cond_34
    :goto_34
    array-length v0, p1

    :goto_35
    if-ge v1, v0, :cond_4a

    aget-object v2, p1, v1

    .line 23
    :try_start_39
    invoke-direct {p0, v2}, Lcom/vdocipher/aegis/core/m/q;->a(Lcom/vdocipher/aegis/media/Track;)V
    :try_end_3c
    .catch Ljava/lang/NullPointerException; {:try_start_39 .. :try_end_3c} :catch_3d

    goto :goto_47

    :catch_3d
    move-exception v2

    .line 25
    invoke-static {v2}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "VdoExo"

    invoke-static {v3, v2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :goto_47
    add-int/lit8 v1, v1, 0x1

    goto :goto_35

    :cond_4a
    :goto_4a
    return-void
.end method

.method public stop()V
    .registers 5

    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/m/q;->A:Z

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    const/4 v1, 0x0

    if-eqz v0, :cond_f

    instance-of v0, v0, Landroidx/media3/exoplayer/ExoPlayer;

    if-eqz v0, :cond_f

    .line 5
    invoke-virtual {p0, v1}, Lcom/vdocipher/aegis/core/m/q;->setPlayWhenReady(Z)V

    .line 7
    :cond_f
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->f:Lcom/vdocipher/aegis/core/n/b;

    if-eqz v0, :cond_16

    .line 8
    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/n/b;->a()V

    .line 10
    :cond_16
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->n:Landroidx/media3/common/Player;

    if-eqz v0, :cond_1f

    .line 11
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->P:Landroidx/media3/common/Player$Listener;

    invoke-interface {v0, v2}, Landroidx/media3/common/Player;->removeListener(Landroidx/media3/common/Player$Listener;)V

    .line 15
    :cond_1f
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-static {v0}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object v0

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->N:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v2}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 16
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-static {v0}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object v0

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->M:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v2}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    const/4 v0, 0x0

    .line 18
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    .line 19
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->F:Ljava/lang/String;

    .line 20
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->G:Ljava/lang/String;

    .line 21
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->H:Ljava/lang/String;

    const-wide/16 v2, 0x0

    .line 22
    iput-wide v2, p0, Lcom/vdocipher/aegis/core/m/q;->I:J

    .line 23
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->C:Lcom/vdocipher/aegis/media/MediaInfo;

    .line 24
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 25
    iput-wide v2, p0, Lcom/vdocipher/aegis/core/m/q;->D:J

    .line 26
    iput-wide v2, p0, Lcom/vdocipher/aegis/core/m/q;->E:J

    .line 28
    iput-boolean v1, p0, Lcom/vdocipher/aegis/core/m/q;->y:Z

    .line 29
    iput-boolean v1, p0, Lcom/vdocipher/aegis/core/m/q;->z:Z

    return-void
.end method
