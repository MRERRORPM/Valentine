# classes14.dex

.class public final Lcom/vdocipher/aegis/core/m/t;
.super Lcom/vdocipher/aegis/core/m/q;
.source "SourceFile"


# static fields
.field private static final U:Ljava/net/CookieManager;


# instance fields
.field private Q:Ljava/lang/String;

.field private final R:Landroid/os/HandlerThread;

.field private final S:Landroid/os/Handler;

.field private T:Ljava/lang/String;


# direct methods
.method public static synthetic $r8$lambda$IjJSn839KGj0RsTh_wOLW0ACb6Q(Lcom/vdocipher/aegis/core/m/t;[Lcom/vdocipher/aegis/core/v/b;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/t;->b([Lcom/vdocipher/aegis/core/v/b;)V

    return-void
.end method

.method public static synthetic $r8$lambda$ezsSzI0MEqW8L9iEod6kw8JamUc(Lcom/vdocipher/aegis/core/m/t;Lcom/vdocipher/aegis/core/m/y$a;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/t;->c(Lcom/vdocipher/aegis/core/m/y$a;)V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Ljava/net/CookieManager;

    invoke-direct {v0}, Ljava/net/CookieManager;-><init>()V

    sput-object v0, Lcom/vdocipher/aegis/core/m/t;->U:Ljava/net/CookieManager;

    .line 2
    sget-object v1, Ljava/net/CookiePolicy;->ACCEPT_ORIGINAL_SERVER:Ljava/net/CookiePolicy;

    invoke-virtual {v0, v1}, Ljava/net/CookieManager;->setCookiePolicy(Ljava/net/CookiePolicy;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/media3/common/Player;Landroid/view/SurfaceView;Lcom/vdocipher/aegis/core/d/k;)V
    .registers 5

    .line 1
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/vdocipher/aegis/core/m/q;-><init>(Landroid/content/Context;Landroidx/media3/common/Player;Landroid/view/SurfaceView;Lcom/vdocipher/aegis/core/d/k;)V

    .line 2
    new-instance p1, Landroid/os/HandlerThread;

    const-string p2, "VdoHls:NetworkThread"

    invoke-direct {p1, p2}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/t;->R:Landroid/os/HandlerThread;

    .line 3
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    .line 4
    new-instance p2, Landroid/os/Handler;

    invoke-virtual {p1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object p1

    invoke-direct {p2, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/t;->S:Landroid/os/Handler;

    return-void
.end method

.method private a(Ljava/util/Map;)V
    .registers 6

    if-nez p1, :cond_3

    goto :goto_35

    .line 96
    :cond_3
    invoke-static {}, Ljava/net/CookieHandler;->getDefault()Ljava/net/CookieHandler;

    move-result-object v0

    check-cast v0, Ljava/net/CookieManager;

    .line 98
    const-string v1, "Set-Cookie"

    invoke-interface {p1, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/List;

    .line 100
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_15
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_35

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 101
    invoke-static {v1}, Ljava/net/HttpCookie;->parse(Ljava/lang/String;)Ljava/util/List;

    move-result-object v1

    const/4 v2, 0x0

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/net/HttpCookie;

    .line 102
    invoke-virtual {v0}, Ljava/net/CookieManager;->getCookieStore()Ljava/net/CookieStore;

    move-result-object v2

    const/4 v3, 0x0

    invoke-interface {v2, v3, v1}, Ljava/net/CookieStore;->add(Ljava/net/URI;Ljava/net/HttpCookie;)V

    goto :goto_15

    :cond_35
    :goto_35
    return-void
.end method

.method private synthetic b([Lcom/vdocipher/aegis/core/v/b;)V
    .registers 3

    .line 24
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->i:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/aegis/core/m/y$c;

    if-eqz v0, :cond_d

    .line 26
    invoke-interface {v0, p1}, Lcom/vdocipher/aegis/core/m/y$c;->a([Lcom/vdocipher/aegis/core/v/b;)V

    :cond_d
    return-void
.end method

.method private synthetic c(Lcom/vdocipher/aegis/core/m/y$a;)V
    .registers 9

    const-string v0, "VdoHls"

    const-string v1, "meta data error: "

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, -0x1

    .line 1
    :try_start_7
    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object p1, p1, Lcom/vdocipher/aegis/player/VdoInitParams;->token:Ljava/lang/String;

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/t;->e(Ljava/lang/String;)V
    :try_end_e
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_e} :catch_43
    .catch Lorg/json/JSONException; {:try_start_7 .. :try_end_e} :catch_f

    return-void

    :catch_f
    move-exception p1

    .line 11
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0xc1c

    .line 13
    invoke-static {v0}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v1

    .line 14
    new-instance v5, Lcom/vdocipher/aegis/core/m/d;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const-string v6, "JSONException"

    invoke-direct {v5, v6, v4, v3, p1}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 15
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    new-instance v3, Lcom/vdocipher/aegis/core/m/p;

    invoke-direct {v3, v0, v1, v5}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    invoke-virtual {p1, v2, v3}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    goto :goto_76

    :catch_43
    move-exception p1

    .line 16
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x1404

    .line 18
    invoke-static {v0}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v1

    .line 19
    new-instance v5, Lcom/vdocipher/aegis/core/m/d;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const-string v6, "IOException"

    invoke-direct {v5, v6, v4, v3, p1}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 20
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    new-instance v3, Lcom/vdocipher/aegis/core/m/p;

    invoke-direct {v3, v0, v1, v5}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    invoke-virtual {p1, v2, v3}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    :goto_76
    return-void
.end method

.method private static d(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    .line 1
    :try_start_0
    new-instance v0, Ljava/lang/String;

    const/4 v1, 0x0

    invoke-static {p0, v1}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/String;-><init>([B)V

    .line 2
    new-instance p0, Lorg/json/JSONObject;

    invoke-direct {p0, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v0, "message"

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_15} :catch_16

    return-object p0

    :catch_16
    const/4 p0, 0x0

    return-object p0
.end method

.method private e(Ljava/lang/String;)V
    .registers 14

    .line 1
    const-string v0, "annotations"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "https://d1z78r8i505acl.cloudfront.net/a/?p=hls&o="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 3
    new-instance v1, Ljava/net/URL;

    invoke-direct {v1, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 5
    new-instance v2, Lcom/vdocipher/aegis/core/g/b;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/m/q;->b:Landroid/content/Context;

    invoke-direct {v2, v3}, Lcom/vdocipher/aegis/core/g/b;-><init>(Landroid/content/Context;)V

    .line 6
    invoke-virtual {v2, v1}, Lcom/vdocipher/aegis/core/g/b;->a(Ljava/net/URL;)Lcom/vdocipher/aegis/core/i/a;

    move-result-object v1

    .line 7
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/i/a;->b()I

    move-result v2

    .line 9
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/i/a;->f()Z

    move-result v3

    const-string v4, "VdoHls"

    if-eqz v3, :cond_de

    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/i/a;->b()I

    move-result v3

    const/16 v5, 0xc8

    if-ne v3, v5, :cond_de

    .line 10
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/i/a;->a()Ljava/lang/String;

    move-result-object p1

    .line 11
    new-instance v2, Ljava/lang/String;

    const/4 v3, 0x0

    invoke-static {p1, v3}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p1

    invoke-direct {v2, p1}, Ljava/lang/String;-><init>([B)V

    .line 12
    const-string p1, "response_decoded"

    invoke-static {p1, v2}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 13
    iput-object v2, p0, Lcom/vdocipher/aegis/core/m/t;->T:Ljava/lang/String;

    .line 15
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 16
    const-string/jumbo v2, "url"

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 17
    const-string/jumbo v3, "targetUrl"

    invoke-static {v3, v2}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 18
    iput-object v2, p0, Lcom/vdocipher/aegis/core/m/t;->Q:Ljava/lang/String;

    .line 20
    const-string v2, "id"

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->F:Ljava/lang/String;

    .line 21
    const-string/jumbo v2, "title"

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->G:Ljava/lang/String;

    .line 23
    const-string v2, "description"

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_7b

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_7d

    :cond_7b
    const-string v2, "NA"

    :goto_7d
    iput-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->H:Ljava/lang/String;

    .line 24
    const-string v2, "duration"

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    mul-int/lit16 v2, v2, 0x3e8

    int-to-long v10, v2

    iput-wide v10, p0, Lcom/vdocipher/aegis/core/m/q;->I:J

    .line 26
    new-instance v5, Lcom/vdocipher/aegis/media/MediaInfo;

    iget-object v7, p0, Lcom/vdocipher/aegis/core/m/q;->F:Ljava/lang/String;

    iget-object v8, p0, Lcom/vdocipher/aegis/core/m/q;->G:Ljava/lang/String;

    iget-object v9, p0, Lcom/vdocipher/aegis/core/m/q;->H:Ljava/lang/String;

    const/4 v6, 0x1

    invoke-direct/range {v5 .. v11}, Lcom/vdocipher/aegis/media/MediaInfo;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    iput-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->C:Lcom/vdocipher/aegis/media/MediaInfo;

    .line 30
    :try_start_9c
    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_b3

    .line 31
    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/t;->g(Ljava/lang/String;)V
    :try_end_a9
    .catch Ljava/lang/Exception; {:try_start_9c .. :try_end_a9} :catch_aa

    goto :goto_b3

    :catch_aa
    move-exception v0

    move-object p1, v0

    .line 34
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v4, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 38
    :cond_b3
    :goto_b3
    :try_start_b3
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/t;->T:Ljava/lang/String;

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/t;->f(Ljava/lang/String;)V
    :try_end_b8
    .catch Ljava/lang/Exception; {:try_start_b3 .. :try_end_b8} :catch_b9

    goto :goto_c2

    :catch_b9
    move-exception v0

    move-object p1, v0

    .line 40
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v4, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 43
    :goto_c2
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/i/a;->e()Lokhttp3/Headers;

    move-result-object p1

    if-eqz p1, :cond_d3

    .line 44
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/i/a;->e()Lokhttp3/Headers;

    move-result-object p1

    invoke-virtual {p1}, Lokhttp3/Headers;->toMultimap()Ljava/util/Map;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/t;->a(Ljava/util/Map;)V

    .line 47
    :cond_d3
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    const/4 v0, 0x2

    invoke-virtual {p1, v0}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void

    .line 51
    :cond_de
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "meta call failed: "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 55
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/i/a;->c()Ljava/lang/String;

    move-result-object v0

    const-string v3, "metaError"

    if-eqz v0, :cond_106

    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/i/a;->c()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_106

    .line 56
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/i/a;->c()Ljava/lang/String;

    move-result-object v0

    goto :goto_107

    :cond_106
    move-object v0, v3

    :goto_107
    const/16 v1, 0x190

    const/16 v4, 0x1f4

    if-lt v2, v1, :cond_116

    if-ge v2, v4, :cond_116

    .line 65
    invoke-static {v0}, Lcom/vdocipher/aegis/core/m/t;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/16 v4, 0x1402

    goto :goto_122

    :cond_116
    const/4 v1, 0x0

    if-lt v2, v4, :cond_120

    const/16 v4, 0x258

    if-ge v2, v4, :cond_120

    const/16 v4, 0x1403

    goto :goto_122

    :cond_120
    const/16 v4, 0x1400

    :goto_122
    if-nez v1, :cond_128

    .line 72
    invoke-static {v4}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v1

    .line 75
    :cond_128
    new-instance v5, Lcom/vdocipher/aegis/core/m/d;

    invoke-direct {v5, v3, v2, p1, v0}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 76
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    new-instance v0, Lcom/vdocipher/aegis/core/m/p;

    invoke-direct {v0, v4, v1, v5}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    const/4 v1, 0x1

    invoke-virtual {p1, v1, v0}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void
.end method

.method private f(Ljava/lang/String;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->g:Lcom/vdocipher/aegis/core/d/k;

    if-eqz v0, :cond_9

    .line 3
    const-string v1, "hlsMeta"

    invoke-virtual {v0, v1, p1}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_9
    return-void
.end method

.method private g(Ljava/lang/String;)V
    .registers 4

    .line 1
    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->j(Ljava/lang/String;)[Lcom/vdocipher/aegis/core/v/b;

    move-result-object p1

    .line 2
    array-length v0, p1

    if-nez v0, :cond_8

    return-void

    .line 5
    :cond_8
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/m/t$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p1}, Lcom/vdocipher/aegis/core/m/t$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/core/m/t;[Lcom/vdocipher/aegis/core/v/b;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private n()V
    .registers 2

    .line 1
    invoke-static {}, Ljava/net/CookieHandler;->getDefault()Ljava/net/CookieHandler;

    move-result-object v0

    if-nez v0, :cond_b

    .line 2
    sget-object v0, Lcom/vdocipher/aegis/core/m/t;->U:Ljava/net/CookieManager;

    invoke-static {v0}, Ljava/net/CookieHandler;->setDefault(Ljava/net/CookieHandler;)V

    :cond_b
    return-void
.end method


# virtual methods
.method protected a(Landroid/os/Handler;Ljava/lang/String;Lcom/vdocipher/aegis/core/z/d$b;)Landroidx/media3/common/MediaItem;
    .registers 9

    .line 4
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/t;->Q:Ljava/lang/String;

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    .line 6
    new-instance p2, Landroidx/media3/common/MediaItem$Builder;

    invoke-direct {p2}, Landroidx/media3/common/MediaItem$Builder;-><init>()V

    .line 7
    invoke-virtual {p2, p1}, Landroidx/media3/common/MediaItem$Builder;->setUri(Landroid/net/Uri;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p1

    .line 8
    const-string p2, "application/x-mpegURL"

    invoke-virtual {p1, p2}, Landroidx/media3/common/MediaItem$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p1

    .line 9
    invoke-virtual {p1}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    move-result-object p1

    .line 11
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_22

    return-object p1

    .line 15
    :cond_22
    :try_start_22
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    .line 16
    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_2e
    if-ge v1, v0, :cond_64

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    add-int/lit8 v1, v1, 0x1

    check-cast v2, Lcom/vdocipher/aegis/media/Caption;

    .line 17
    invoke-virtual {v2}, Lcom/vdocipher/aegis/media/Caption;->getUrl()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    .line 18
    new-instance v4, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    invoke-direct {v4, v3}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;-><init>(Landroid/net/Uri;)V

    const-string/jumbo v3, "text/vtt"

    invoke-virtual {v4, v3}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    move-result-object v3

    .line 19
    invoke-virtual {v2}, Lcom/vdocipher/aegis/media/Caption;->getLang()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->setLanguage(Ljava/lang/String;)Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    move-result-object v3

    .line 20
    invoke-virtual {v2}, Lcom/vdocipher/aegis/media/Caption;->getLabel()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->setLabel(Ljava/lang/String;)Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->build()Landroidx/media3/common/MediaItem$SubtitleConfiguration;

    move-result-object v2

    .line 22
    invoke-interface {p2, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2e

    .line 25
    :cond_64
    invoke-virtual {p1}, Landroidx/media3/common/MediaItem;->buildUpon()Landroidx/media3/common/MediaItem$Builder;

    move-result-object p3

    invoke-virtual {p3, p2}, Landroidx/media3/common/MediaItem$Builder;->setSubtitleConfigurations(Ljava/util/List;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p2

    invoke-virtual {p2}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    move-result-object p1
    :try_end_70
    .catch Ljava/lang/Exception; {:try_start_22 .. :try_end_70} :catch_71

    return-object p1

    :catch_71
    move-exception p2

    .line 28
    invoke-static {p2}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p2

    const-string p3, "VdoHls"

    invoke-static {p3, p2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-object p1
.end method

.method protected a(Landroidx/media3/common/PlaybackException;)Lcom/vdocipher/aegis/core/m/p;
    .registers 11

    .line 29
    check-cast p1, Landroidx/media3/exoplayer/ExoPlaybackException;

    .line 31
    iget v0, p1, Landroidx/media3/exoplayer/ExoPlaybackException;->type:I

    const/4 v1, 0x1

    if-nez v0, :cond_b

    const-string/jumbo v2, "source"

    goto :goto_13

    :cond_b
    if-ne v0, v1, :cond_10

    .line 32
    const-string v2, "renderer"

    goto :goto_13

    :cond_10
    const-string/jumbo v2, "unexpected"

    :goto_13
    const/4 v3, 0x0

    const/4 v4, -0x1

    if-nez v0, :cond_71

    .line 39
    invoke-virtual {p1}, Landroidx/media3/exoplayer/ExoPlaybackException;->getSourceException()Ljava/io/IOException;

    move-result-object v0

    .line 41
    instance-of v1, v0, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;

    if-eqz v1, :cond_67

    .line 43
    :try_start_1f
    move-object v1, v0

    check-cast v1, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;

    iget-object v1, v1, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;->dataSpec:Landroidx/media3/datasource/DataSpec;

    iget-object v1, v1, Landroidx/media3/datasource/DataSpec;->uri:Landroid/net/Uri;

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_2a
    .catch Ljava/lang/NullPointerException; {:try_start_1f .. :try_end_2a} :catch_2b

    goto :goto_2c

    :catch_2b
    move-object v1, v3

    .line 47
    :goto_2c
    instance-of v5, v0, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    if-eqz v5, :cond_35

    .line 48
    move-object v4, v0

    check-cast v4, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    iget v4, v4, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;->responseCode:I

    :cond_35
    const/16 v5, 0x258

    const/16 v6, 0x190

    const/16 v7, 0x1f4

    if-eqz v1, :cond_56

    .line 52
    const-string v8, "m3u8"

    invoke-virtual {v1, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_56

    if-lt v4, v6, :cond_4c

    if-ge v4, v7, :cond_4c

    const/16 v5, 0x140c

    goto :goto_91

    :cond_4c
    if-lt v4, v7, :cond_53

    if-ge v4, v5, :cond_53

    const/16 v5, 0x140d

    goto :goto_91

    :cond_53
    const/16 v5, 0x140a

    goto :goto_91

    :cond_56
    if-lt v4, v6, :cond_5d

    if-ge v4, v7, :cond_5d

    const/16 v5, 0x13f8

    goto :goto_91

    :cond_5d
    if-lt v4, v7, :cond_64

    if-ge v4, v5, :cond_64

    const/16 v5, 0x13f9

    goto :goto_91

    :cond_64
    const/16 v5, 0x13fa

    goto :goto_91

    .line 71
    :cond_67
    instance-of v1, v0, Landroidx/media3/common/ParserException;

    if-eqz v1, :cond_6e

    const/16 v5, 0x17f2

    goto :goto_90

    :cond_6e
    const/16 v5, 0x13f6

    goto :goto_90

    :cond_71
    if-ne v0, v1, :cond_81

    .line 79
    invoke-virtual {p1}, Landroidx/media3/exoplayer/ExoPlaybackException;->getRendererException()Ljava/lang/Exception;

    move-result-object v0

    .line 80
    instance-of v1, v0, Landroidx/media3/exoplayer/mediacodec/MediaCodecRenderer$DecoderInitializationException;

    if-eqz v1, :cond_7e

    const/16 v5, 0x17ea

    goto :goto_90

    :cond_7e
    const/16 v5, 0x17e8

    goto :goto_90

    .line 86
    :cond_81
    invoke-virtual {p1}, Landroidx/media3/exoplayer/ExoPlaybackException;->getUnexpectedException()Ljava/lang/RuntimeException;

    move-result-object v0

    .line 87
    invoke-virtual {p0, v0}, Lcom/vdocipher/aegis/core/m/q;->a(Ljava/lang/Throwable;)Z

    move-result v1

    if-eqz v1, :cond_8e

    const/16 v5, 0x17e9

    goto :goto_90

    :cond_8e
    const/16 v5, 0x17d5

    :goto_90
    move-object v1, v3

    .line 91
    :goto_91
    new-instance v6, Lcom/vdocipher/aegis/core/m/d;

    if-eqz v0, :cond_99

    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v3

    :cond_99
    invoke-direct {v6, v2, v4, v1, v3}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 92
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "epError: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "--"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "VdoHls"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 94
    invoke-static {v5}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object p1

    .line 95
    new-instance v0, Lcom/vdocipher/aegis/core/m/p;

    invoke-direct {v0, v5, p1, v6}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    return-object v0
.end method

.method public a()V
    .registers 2

    .line 1
    invoke-super {p0}, Lcom/vdocipher/aegis/core/m/q;->a()V

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/t;->R:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->quit()Z

    return-void
.end method

.method protected b(Lcom/vdocipher/aegis/core/m/y$a;)V
    .registers 7

    const-string v0, "VdoHls"

    .line 1
    :try_start_2
    new-instance v1, Lcom/vdocipher/aegis/core/f/g;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/m/y$a;->b:Ljava/lang/String;

    invoke-direct {v1, v2}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    .line 2
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 3
    iget-object v1, p1, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/m/f;->d()Z

    move-result v1

    if-eqz v1, :cond_28

    .line 4
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/util/ArrayList;)Ljava/util/ArrayList;
    :try_end_1f
    .catch Lcom/vdocipher/aegis/core/f/d; {:try_start_2 .. :try_end_1f} :catch_20

    goto :goto_28

    :catch_20
    move-exception v1

    .line 6
    invoke-static {v1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 10
    :cond_28
    :goto_28
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/t;->n()V

    .line 13
    :try_start_2b
    const-string v1, ""

    .line 14
    iget-object v2, p1, Lcom/vdocipher/aegis/core/m/y$a;->k:Landroidx/media3/exoplayer/offline/Download;

    if-eqz v2, :cond_35

    .line 15
    invoke-static {v2}, Lcom/vdocipher/aegis/offline/DownloadStatus;->getOfflineScrubbingPreviewUrl(Landroidx/media3/exoplayer/offline/Download;)Ljava/lang/String;

    move-result-object v1

    .line 17
    :cond_35
    iget-object v2, p0, Lcom/vdocipher/aegis/core/m/q;->t:Lcom/vdocipher/aegis/core/f/g;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v4, v3, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    iget-object v3, v3, Lcom/vdocipher/aegis/player/VdoInitParams;->configMap:Ljava/util/HashMap;

    invoke-virtual {v2, v4, v3, v1}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/lang/String;Ljava/util/HashMap;Ljava/lang/String;)Lcom/vdocipher/aegis/media/PlayerOption;

    move-result-object v1

    iput-object v1, p0, Lcom/vdocipher/aegis/core/m/q;->c:Lcom/vdocipher/aegis/media/PlayerOption;
    :try_end_43
    .catch Ljava/lang/Exception; {:try_start_2b .. :try_end_43} :catch_44

    goto :goto_53

    :catch_44
    move-exception v1

    .line 19
    invoke-static {v1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 20
    new-instance v0, Lcom/vdocipher/aegis/media/PlayerOption;

    invoke-direct {v0}, Lcom/vdocipher/aegis/media/PlayerOption;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->c:Lcom/vdocipher/aegis/media/PlayerOption;

    .line 23
    :goto_53
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/t;->S:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/m/t$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0, p1}, Lcom/vdocipher/aegis/core/m/t$$ExternalSyntheticLambda1;-><init>(Lcom/vdocipher/aegis/core/m/t;Lcom/vdocipher/aegis/core/m/y$a;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public getPlayerOptions()Lcom/vdocipher/aegis/media/PlayerOption;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->c:Lcom/vdocipher/aegis/media/PlayerOption;

    return-object v0
.end method

.method protected j()V
    .registers 1

    return-void
.end method

.method public stop()V
    .registers 2

    .line 1
    invoke-super {p0}, Lcom/vdocipher/aegis/core/m/q;->stop()V

    const/4 v0, 0x0

    .line 3
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/t;->Q:Ljava/lang/String;

    .line 4
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/t;->T:Ljava/lang/String;

    return-void
.end method
