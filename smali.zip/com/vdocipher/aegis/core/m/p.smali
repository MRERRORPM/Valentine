# classes14.dex

.class public final Lcom/vdocipher/aegis/core/m/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public final a:I

.field public final b:Ljava/lang/String;

.field public final c:Lcom/vdocipher/aegis/core/m/d;


# direct methods
.method public constructor <init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p1, p0, Lcom/vdocipher/aegis/core/m/p;->a:I

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/p;->b:Ljava/lang/String;

    .line 4
    iput-object p3, p0, Lcom/vdocipher/aegis/core/m/p;->c:Lcom/vdocipher/aegis/core/m/d;

    return-void
.end method
