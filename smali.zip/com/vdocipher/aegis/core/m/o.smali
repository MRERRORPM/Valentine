# classes14.dex

.class public Lcom/vdocipher/aegis/core/m/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/media3/exoplayer/drm/DrmSessionManagerProvider;


# instance fields
.field private final a:Ljava/lang/Object;

.field private b:Ljava/lang/String;

.field private final c:Lcom/vdocipher/aegis/core/m/u$d;

.field private d:Landroidx/media3/common/MediaItem$DrmConfiguration;

.field private e:Landroidx/media3/exoplayer/drm/DrmSessionManager;

.field private final f:Landroid/content/Context;


# direct methods
.method public static synthetic $r8$lambda$7qyZSvEiwrF8Z3_yruZLGuJB900(Lcom/vdocipher/aegis/core/m/o;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V
    .registers 8

    invoke-direct/range {p0 .. p7}, Lcom/vdocipher/aegis/core/m/o;->a(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$XkDojTsjEm6AXDwBryCzZQxFwns(Lcom/vdocipher/aegis/core/m/o;[BLjava/util/UUID;)Landroidx/media3/exoplayer/drm/ExoMediaDrm;
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/m/o;->a([BLjava/util/UUID;)Landroidx/media3/exoplayer/drm/ExoMediaDrm;

    move-result-object p0

    return-object p0
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Lcom/vdocipher/aegis/core/m/o$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0}, Lcom/vdocipher/aegis/core/m/o$$ExternalSyntheticLambda1;-><init>(Lcom/vdocipher/aegis/core/m/o;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/o;->c:Lcom/vdocipher/aegis/core/m/u$d;

    .line 22
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/o;->f:Landroid/content/Context;

    .line 23
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/o;->a:Ljava/lang/Object;

    .line 24
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/o;->b:Ljava/lang/String;

    if-nez v0, :cond_22

    .line 25
    new-instance v0, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;

    invoke-direct {v0}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;-><init>()V

    invoke-virtual {v0, p1}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->f(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/o;->b:Ljava/lang/String;

    :cond_22
    return-void
.end method

.method private a(Landroidx/media3/common/MediaItem$DrmConfiguration;)Landroidx/media3/exoplayer/drm/DrmSessionManager;
    .registers 27

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    .line 15
    iget-object v0, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    const-string v3, "packageName"

    const/4 v4, 0x0

    invoke-virtual {v0, v3, v4}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Ljava/lang/String;

    .line 16
    iget-object v0, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    const-string v3, "failOnKeyRequestWithExpiry"

    invoke-virtual {v0, v3, v4}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 17
    iget-object v5, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    const-string/jumbo v6, "wrapped"

    invoke-virtual {v5, v6, v4}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 18
    iget-object v8, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    const-string v9, "otp"

    invoke-virtual {v8, v9, v4}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    move-object v10, v8

    check-cast v10, Ljava/lang/String;

    .line 19
    iget-object v8, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    const-string v9, "playbackInfo"

    invoke-virtual {v8, v9, v4}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    .line 20
    iget-object v9, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    const-string/jumbo v11, "videoId"

    invoke-virtual {v9, v11, v4}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    move-object v15, v9

    check-cast v15, Ljava/lang/String;

    .line 21
    iget-object v9, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    const-string v11, "languageCode"

    invoke-virtual {v9, v11, v4}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    move-object/from16 v21, v9

    check-cast v21, Ljava/lang/String;

    .line 22
    iget-object v9, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseUri:Landroid/net/Uri;

    if-eqz v9, :cond_5c

    invoke-virtual {v9}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v9

    move-object v14, v9

    goto :goto_5d

    :cond_5c
    move-object v14, v4

    .line 23
    :goto_5d
    iget-object v9, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    const-string v11, "integrityCloudId"

    invoke-virtual {v9, v11, v4}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    move-object v12, v9

    check-cast v12, Ljava/lang/String;

    .line 24
    iget-object v9, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    const-string v11, "enforceHardwareAttestation"

    const-string v13, "false"

    invoke-virtual {v9, v11, v13}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    .line 25
    iget-object v11, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    move-object/from16 v16, v7

    const-string v7, "appGalleryAppId"

    invoke-virtual {v11, v7, v4}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    .line 26
    iget-object v11, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    move-object/from16 v17, v7

    const-string v7, "fallbackLicenseServerArray"

    invoke-virtual {v11, v7, v4}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    .line 27
    iget-object v11, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    move-object/from16 v18, v7

    const-string v7, "href"

    invoke-virtual {v11, v7, v4}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    .line 28
    iget-object v11, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    move-object/from16 v19, v7

    const-string/jumbo v7, "userAgent"

    invoke-virtual {v11, v7, v4}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    .line 29
    iget-object v11, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    move-object/from16 v20, v8

    const-string v8, "offlinePlayback"

    invoke-virtual {v11, v8, v4}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    move-object/from16 v22, v10

    .line 30
    iget-object v10, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    move-object/from16 v23, v11

    const-string v11, "playerViewId"

    invoke-virtual {v10, v11, v4}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 31
    iget-object v10, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseRequestHeaders:Lcom/google/common/collect/ImmutableMap;

    const-string v11, "l3EnforcementValue"

    invoke-virtual {v10, v11, v13}, Lcom/google/common/collect/ImmutableMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    const-string/jumbo v11, "true"

    const/4 v13, 0x1

    if-eqz v10, :cond_d8

    .line 33
    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_d8

    move/from16 v24, v13

    goto :goto_da

    :cond_d8
    const/16 v24, 0x0

    :goto_da
    if-eqz v9, :cond_e5

    .line 34
    invoke-virtual {v9, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_e5

    move-object v9, v14

    move v14, v13

    goto :goto_e7

    :cond_e5
    move-object v9, v14

    const/4 v14, 0x0

    .line 36
    :goto_e7
    new-instance v10, Lcom/vdocipher/aegis/core/q/b;

    move-object v11, v9

    move-object v9, v10

    iget-object v10, v1, Lcom/vdocipher/aegis/core/m/o;->f:Landroid/content/Context;

    move-object/from16 v2, v22

    move-object/from16 v22, v4

    move-object v4, v11

    move-object v11, v2

    move-object/from16 v13, v17

    move-object/from16 v2, v23

    invoke-direct/range {v9 .. v14}, Lcom/vdocipher/aegis/core/q/b;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    move-object v10, v11

    if-eqz v5, :cond_105

    .line 38
    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_105

    const/4 v13, 0x1

    goto :goto_106

    :cond_105
    const/4 v13, 0x0

    :goto_106
    if-eqz v2, :cond_110

    .line 39
    invoke-virtual {v2, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_110

    const/4 v2, 0x1

    goto :goto_111

    :cond_110
    const/4 v2, 0x0

    :goto_111
    if-eqz v0, :cond_11b

    .line 40
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_11b

    const/4 v8, 0x1

    goto :goto_11c

    :cond_11b
    const/4 v8, 0x0

    .line 41
    :goto_11c
    invoke-virtual/range {p1 .. p1}, Landroidx/media3/common/MediaItem$DrmConfiguration;->getKeySetId()[B

    move-result-object v3

    .line 43
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    if-eqz v18, :cond_136

    .line 46
    :try_start_127
    invoke-static/range {v18 .. v18}, Lcom/vdocipher/aegis/core/t/d;->d(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v5
    :try_end_12b
    .catch Lorg/json/JSONException; {:try_start_127 .. :try_end_12b} :catch_12c

    goto :goto_136

    :catch_12c
    move-exception v0

    .line 48
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v6, "VdoDrmSessionManagerProvider"

    invoke-static {v6, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 52
    :cond_136
    :goto_136
    new-instance v0, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    invoke-direct {v0}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;-><init>()V

    invoke-virtual {v0, v7}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;->setUserAgent(Ljava/lang/String;)Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    move-result-object v0

    .line 53
    new-instance v6, Landroidx/media3/exoplayer/drm/HttpMediaDrmCallback;

    const/4 v7, 0x1

    invoke-direct {v6, v4, v7, v0}, Landroidx/media3/exoplayer/drm/HttpMediaDrmCallback;-><init>(Ljava/lang/String;ZLandroidx/media3/datasource/DataSource$Factory;)V

    move-object v12, v15

    move-object v15, v5

    .line 56
    new-instance v5, Lcom/vdocipher/aegis/core/m/u;

    move-object/from16 v7, v16

    move-object/from16 v16, v6

    iget-object v6, v1, Lcom/vdocipher/aegis/core/m/o;->f:Landroid/content/Context;

    iget-object v0, v1, Lcom/vdocipher/aegis/core/m/o;->c:Lcom/vdocipher/aegis/core/m/u$d;

    new-instance v11, Lcom/vdocipher/aegis/core/p/a;

    iget-object v14, v1, Lcom/vdocipher/aegis/core/m/o;->b:Ljava/lang/String;

    invoke-direct {v11, v14}, Lcom/vdocipher/aegis/core/p/a;-><init>(Ljava/lang/String;)V

    move v14, v13

    move-object v13, v9

    move v9, v14

    move-object/from16 v14, v20

    move-object/from16 v20, v11

    move-object v11, v14

    move-object/from16 v17, v0

    move-object v14, v4

    move-object/from16 v18, v19

    move-object/from16 v19, v22

    invoke-direct/range {v5 .. v21}, Lcom/vdocipher/aegis/core/m/u;-><init>(Landroid/content/Context;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/q/b;Ljava/lang/String;Ljava/util/ArrayList;Landroidx/media3/exoplayer/drm/MediaDrmCallback;Lcom/vdocipher/aegis/core/m/u$d;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/p/a;Ljava/lang/String;)V

    move-object/from16 v0, v16

    .line 59
    const-string/jumbo v4, "vdo-sdk"

    const-string v6, "Aegis/1.29.3"

    invoke-virtual {v0, v4, v6}, Landroidx/media3/exoplayer/drm/HttpMediaDrmCallback;->setKeyRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 61
    new-instance v0, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;

    invoke-direct {v0}, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;-><init>()V

    sget-object v4, Landroidx/media3/common/C;->WIDEVINE_UUID:Ljava/util/UUID;

    if-nez v24, :cond_180

    .line 62
    sget-object v3, Landroidx/media3/exoplayer/drm/FrameworkMediaDrm;->DEFAULT_PROVIDER:Landroidx/media3/exoplayer/drm/ExoMediaDrm$Provider;

    goto :goto_186

    :cond_180
    new-instance v6, Lcom/vdocipher/aegis/core/m/o$$ExternalSyntheticLambda0;

    invoke-direct {v6, v1, v3}, Lcom/vdocipher/aegis/core/m/o$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/core/m/o;[B)V

    move-object v3, v6

    :goto_186
    invoke-virtual {v0, v4, v3}, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;->setUuidAndExoMediaDrmProvider(Ljava/util/UUID;Landroidx/media3/exoplayer/drm/ExoMediaDrm$Provider;)Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;

    move-result-object v0

    if-nez v2, :cond_194

    .line 88
    new-instance v2, Lcom/vdocipher/aegis/core/m/u$b;

    invoke-direct {v2}, Lcom/vdocipher/aegis/core/m/u$b;-><init>()V

    invoke-virtual {v0, v2}, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;->setLoadErrorHandlingPolicy(Landroidx/media3/exoplayer/upstream/LoadErrorHandlingPolicy;)Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;

    .line 91
    :cond_194
    invoke-virtual {v0, v5}, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;->build(Landroidx/media3/exoplayer/drm/MediaDrmCallback;)Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager;

    move-result-object v0

    .line 93
    invoke-virtual/range {p1 .. p1}, Landroidx/media3/common/MediaItem$DrmConfiguration;->getKeySetId()[B

    move-result-object v2

    if-eqz v2, :cond_1a6

    .line 94
    invoke-virtual/range {p1 .. p1}, Landroidx/media3/common/MediaItem$DrmConfiguration;->getKeySetId()[B

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v0, v3, v2}, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager;->setMode(I[B)V

    :cond_1a6
    return-object v0
.end method

.method private synthetic a([BLjava/util/UUID;)Landroidx/media3/exoplayer/drm/ExoMediaDrm;
    .registers 4

    const/4 p2, 0x1

    if-eqz p1, :cond_f

    .line 95
    :try_start_3
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/o;->a([B)Lcom/vdocipher/aegis/core/z/d$b;

    move-result-object p1

    .line 97
    sget-object v0, Lcom/vdocipher/aegis/core/z/d$b;->a:Lcom/vdocipher/aegis/core/z/d$b;

    if-ne p1, v0, :cond_d

    const/4 p2, 0x0

    goto :goto_f

    .line 99
    :cond_d
    sget-object v0, Lcom/vdocipher/aegis/core/z/d$b;->b:Lcom/vdocipher/aegis/core/z/d$b;

    .line 104
    :cond_f
    :goto_f
    sget-object p1, Landroidx/media3/common/C;->WIDEVINE_UUID:Ljava/util/UUID;

    invoke-static {p1}, Landroidx/media3/exoplayer/drm/FrameworkMediaDrm;->newInstance(Ljava/util/UUID;)Landroidx/media3/exoplayer/drm/FrameworkMediaDrm;

    move-result-object p1

    if-eqz p2, :cond_1e

    .line 108
    const-string p2, "securityLevel"

    const-string v0, "L3"

    invoke-virtual {p1, p2, v0}, Landroidx/media3/exoplayer/drm/FrameworkMediaDrm;->setPropertyString(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1e
    .catch Landroidx/media3/exoplayer/drm/UnsupportedDrmException; {:try_start_3 .. :try_end_1e} :catch_1f

    :cond_1e
    return-object p1

    .line 112
    :catch_1f
    new-instance p1, Landroidx/media3/exoplayer/drm/DummyExoMediaDrm;

    invoke-direct {p1}, Landroidx/media3/exoplayer/drm/DummyExoMediaDrm;-><init>()V

    return-object p1
.end method

.method private a(Ljava/lang/String;Z)Lcom/vdocipher/aegis/core/d/k;
    .registers 4

    .line 1
    invoke-static {}, Lcom/vdocipher/aegis/core/d/i;->a()Lcom/vdocipher/aegis/core/d/i;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/vdocipher/aegis/core/d/i;->a(Ljava/lang/String;Z)Lcom/vdocipher/aegis/core/d/k;

    move-result-object p1

    return-object p1
.end method

.method private a([B)Lcom/vdocipher/aegis/core/z/d$b;
    .registers 4

    .line 2
    new-instance v0, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    invoke-direct {v0}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;-><init>()V

    const-string v1, "VdoDrmSessionManagerProvider"

    invoke-virtual {v0, v1}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;->setUserAgent(Ljava/lang/String;)Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    move-result-object v0

    .line 4
    sget-object v1, Lcom/vdocipher/aegis/core/z/d$b;->a:Lcom/vdocipher/aegis/core/z/d$b;

    .line 6
    :try_start_d
    invoke-static {v0, p1, v1}, Lcom/vdocipher/aegis/core/t/d;->a(Landroidx/media3/datasource/HttpDataSource$Factory;[BLcom/vdocipher/aegis/core/z/d$b;)Landroid/util/Pair;
    :try_end_10
    .catch Landroidx/media3/exoplayer/drm/DrmSession$DrmSessionException; {:try_start_d .. :try_end_10} :catch_11

    return-object v1

    .line 9
    :catch_11
    sget-object v1, Lcom/vdocipher/aegis/core/z/d$b;->b:Lcom/vdocipher/aegis/core/z/d$b;

    .line 11
    :try_start_13
    invoke-static {v0, p1, v1}, Lcom/vdocipher/aegis/core/t/d;->a(Landroidx/media3/datasource/HttpDataSource$Factory;[BLcom/vdocipher/aegis/core/z/d$b;)Landroid/util/Pair;
    :try_end_16
    .catch Landroidx/media3/exoplayer/drm/DrmSession$DrmSessionException; {:try_start_13 .. :try_end_16} :catch_17

    goto :goto_19

    .line 14
    :catch_17
    sget-object v1, Lcom/vdocipher/aegis/core/z/d$b;->c:Lcom/vdocipher/aegis/core/z/d$b;

    :goto_19
    return-object v1
.end method

.method private a(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 113
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 117
    const-string p1, "annotationCode"

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_12

    .line 118
    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_12
    const/4 p1, 0x0

    return-object p1
.end method

.method private a(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V
    .registers 13

    const-string v0, "metaData"

    const-string/jumbo v1, "tags"

    const-string v2, "VdoDrmSessionManagerProvider"

    .line 119
    invoke-direct {p0, p2, p1}, Lcom/vdocipher/aegis/core/m/o;->a(Ljava/lang/String;Z)Lcom/vdocipher/aegis/core/d/k;

    move-result-object p1

    .line 122
    :try_start_b
    invoke-direct {p0, p4}, Lcom/vdocipher/aegis/core/m/o;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_f} :catch_10

    goto :goto_19

    :catch_10
    move-exception v3

    .line 124
    invoke-static {v3}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    .line 128
    :goto_19
    iget-object v4, p0, Lcom/vdocipher/aegis/core/m/o;->f:Landroid/content/Context;

    invoke-static {v4}, Lcom/vdocipher/aegis/core/k/c;->b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object v4

    invoke-virtual {v4, p2, v3}, Lcom/vdocipher/aegis/core/k/c;->e(Ljava/lang/String;Ljava/lang/String;)Z

    .line 131
    :try_start_22
    new-instance p2, Lorg/json/JSONObject;

    invoke-direct {p2, p4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 132
    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result p4

    if-eqz p4, :cond_34

    .line 133
    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p4

    invoke-static {p1, p4}, Lcom/vdocipher/aegis/core/m/c;->f(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    .line 136
    :cond_34
    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result p4

    if-eqz p4, :cond_6b

    .line 137
    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 138
    invoke-static {p2}, Lcom/vdocipher/aegis/core/t/d;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 140
    const-string p4, "01"

    const/16 v0, 0x8

    invoke-virtual {p2, p4, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;I)Z

    move-result p2

    if-eqz p2, :cond_6b

    .line 141
    new-instance p2, Landroid/content/Intent;

    const-string p4, "enf_blocked_action"

    invoke-direct {p2, p4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 142
    const-string p4, "enf_blocked"

    const/4 v0, 0x1

    invoke-virtual {p2, p4, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 143
    iget-object p4, p0, Lcom/vdocipher/aegis/core/m/o;->f:Landroid/content/Context;

    invoke-static {p4}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object p4

    invoke-virtual {p4, p2}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z
    :try_end_62
    .catch Ljava/lang/Exception; {:try_start_22 .. :try_end_62} :catch_63

    goto :goto_6b

    :catch_63
    move-exception p2

    .line 148
    invoke-static {p2}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p2

    invoke-static {v2, p2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_6b
    :goto_6b
    if-eqz p3, :cond_95

    .line 151
    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_95

    .line 152
    new-instance p2, Landroid/content/Intent;

    const-string/jumbo p4, "vdo_player_annotation_filter"

    invoke-direct {p2, p4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 153
    const-string/jumbo p4, "vdo_player_view_id"

    invoke-virtual {p2, p4, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    if-eqz v3, :cond_84

    goto :goto_86

    .line 154
    :cond_84
    const-string v3, ""

    :goto_86
    const-string/jumbo p3, "vdo_player_annotation"

    invoke-virtual {p2, p3, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 155
    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/o;->f:Landroid/content/Context;

    invoke-static {p3}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroidx/localbroadcastmanager/content/LocalBroadcastManager;

    move-result-object p3

    invoke-virtual {p3, p2}, Landroidx/localbroadcastmanager/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z

    .line 159
    :cond_95
    invoke-static {p1, p5, p6}, Lcom/vdocipher/aegis/core/m/c;->a(Lcom/vdocipher/aegis/core/d/k;J)V

    if-eqz p7, :cond_a3

    .line 162
    invoke-virtual {p7}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_a3

    .line 163
    invoke-static {p1, p7}, Lcom/vdocipher/aegis/core/m/c;->i(Lcom/vdocipher/aegis/core/d/k;Ljava/lang/String;)V

    :cond_a3
    return-void
.end method


# virtual methods
.method public get(Landroidx/media3/common/MediaItem;)Landroidx/media3/exoplayer/drm/DrmSessionManager;
    .registers 4

    .line 1
    iget-object v0, p1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    invoke-static {v0}, Landroidx/media3/common/util/Assertions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 3
    iget-object p1, p1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    iget-object p1, p1, Landroidx/media3/common/MediaItem$LocalConfiguration;->drmConfiguration:Landroidx/media3/common/MediaItem$DrmConfiguration;

    if-nez p1, :cond_e

    .line 5
    sget-object p1, Landroidx/media3/exoplayer/drm/DrmSessionManager;->DRM_UNSUPPORTED:Landroidx/media3/exoplayer/drm/DrmSessionManager;

    return-object p1

    .line 8
    :cond_e
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/o;->a:Ljava/lang/Object;

    monitor-enter v0

    .line 9
    :try_start_11
    iget-object v1, p0, Lcom/vdocipher/aegis/core/m/o;->d:Landroidx/media3/common/MediaItem$DrmConfiguration;

    invoke-static {p1, v1}, Landroidx/media3/common/util/Util;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_21

    .line 10
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/o;->d:Landroidx/media3/common/MediaItem$DrmConfiguration;

    .line 11
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/m/o;->a(Landroidx/media3/common/MediaItem$DrmConfiguration;)Landroidx/media3/exoplayer/drm/DrmSessionManager;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/o;->e:Landroidx/media3/exoplayer/drm/DrmSessionManager;

    .line 13
    :cond_21
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/o;->e:Landroidx/media3/exoplayer/drm/DrmSessionManager;

    invoke-static {p1}, Landroidx/media3/common/util/Assertions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/media3/exoplayer/drm/DrmSessionManager;

    monitor-exit v0

    return-object p1

    :catchall_2b
    move-exception p1

    .line 14
    monitor-exit v0
    :try_end_2d
    .catchall {:try_start_11 .. :try_end_2d} :catchall_2b

    throw p1
.end method
