# classes14.dex

.class final enum Lcom/vdocipher/aegis/core/m/i;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum b:Lcom/vdocipher/aegis/core/m/i;

.field public static final enum c:Lcom/vdocipher/aegis/core/m/i;

.field public static final enum d:Lcom/vdocipher/aegis/core/m/i;

.field public static final enum e:Lcom/vdocipher/aegis/core/m/i;

.field private static final synthetic f:[Lcom/vdocipher/aegis/core/m/i;


# instance fields
.field private final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lcom/vdocipher/aegis/core/m/i;

    const-string v1, "SDK"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v1}, Lcom/vdocipher/aegis/core/m/i;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lcom/vdocipher/aegis/core/m/i;->b:Lcom/vdocipher/aegis/core/m/i;

    .line 2
    new-instance v0, Lcom/vdocipher/aegis/core/m/i;

    const-string v1, "SERVER"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2, v1}, Lcom/vdocipher/aegis/core/m/i;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lcom/vdocipher/aegis/core/m/i;->c:Lcom/vdocipher/aegis/core/m/i;

    .line 3
    new-instance v0, Lcom/vdocipher/aegis/core/m/i;

    const-string v1, "CLIENT"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2, v1}, Lcom/vdocipher/aegis/core/m/i;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lcom/vdocipher/aegis/core/m/i;->d:Lcom/vdocipher/aegis/core/m/i;

    .line 4
    new-instance v0, Lcom/vdocipher/aegis/core/m/i;

    const-string v1, "NONE"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2, v1}, Lcom/vdocipher/aegis/core/m/i;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lcom/vdocipher/aegis/core/m/i;->e:Lcom/vdocipher/aegis/core/m/i;

    .line 5
    invoke-static {}, Lcom/vdocipher/aegis/core/m/i;->a()[Lcom/vdocipher/aegis/core/m/i;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/aegis/core/m/i;->f:[Lcom/vdocipher/aegis/core/m/i;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .registers 4

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    iput-object p3, p0, Lcom/vdocipher/aegis/core/m/i;->a:Ljava/lang/String;

    return-void
.end method

.method private static synthetic a()[Lcom/vdocipher/aegis/core/m/i;
    .registers 4

    .line 1
    sget-object v0, Lcom/vdocipher/aegis/core/m/i;->b:Lcom/vdocipher/aegis/core/m/i;

    sget-object v1, Lcom/vdocipher/aegis/core/m/i;->c:Lcom/vdocipher/aegis/core/m/i;

    sget-object v2, Lcom/vdocipher/aegis/core/m/i;->d:Lcom/vdocipher/aegis/core/m/i;

    sget-object v3, Lcom/vdocipher/aegis/core/m/i;->e:Lcom/vdocipher/aegis/core/m/i;

    filled-new-array {v0, v1, v2, v3}, [Lcom/vdocipher/aegis/core/m/i;

    move-result-object v0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/aegis/core/m/i;
    .registers 2

    .line 1
    const-class v0, Lcom/vdocipher/aegis/core/m/i;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/aegis/core/m/i;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/aegis/core/m/i;
    .registers 1

    .line 1
    sget-object v0, Lcom/vdocipher/aegis/core/m/i;->f:[Lcom/vdocipher/aegis/core/m/i;

    invoke-virtual {v0}, [Lcom/vdocipher/aegis/core/m/i;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/aegis/core/m/i;

    return-object v0
.end method


# virtual methods
.method b()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/i;->a:Ljava/lang/String;

    return-object v0
.end method
