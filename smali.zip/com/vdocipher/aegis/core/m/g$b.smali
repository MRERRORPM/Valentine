# classes14.dex

.class Lcom/vdocipher/aegis/core/m/g$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/m/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation


# instance fields
.field final a:Lcom/vdocipher/aegis/player/VdoInitParams;

.field final b:Lcom/vdocipher/aegis/player/PlaybackState;

.field final c:Lcom/vdocipher/aegis/core/m/e;

.field d:Lcom/vdocipher/aegis/core/m/y$a;

.field e:Lcom/vdocipher/aegis/core/m/h;

.field f:Lcom/vdocipher/aegis/core/m/y;

.field g:Lcom/vdocipher/aegis/core/d/k;


# direct methods
.method constructor <init>(Ljava/lang/String;Lcom/vdocipher/aegis/player/VdoInitParams;Landroidx/media3/common/Player;Lcom/vdocipher/aegis/player/PlaybackState;Landroid/content/Context;Lcom/vdocipher/aegis/core/m/e$b;)V
    .registers 15

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/g$b;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    .line 3
    iput-object p4, p0, Lcom/vdocipher/aegis/core/m/g$b;->b:Lcom/vdocipher/aegis/player/PlaybackState;

    .line 5
    invoke-static {p3, p2}, Lcom/vdocipher/aegis/core/t/d;->a(Landroidx/media3/common/Player;Lcom/vdocipher/aegis/player/VdoInitParams;)Z

    move-result v5

    .line 7
    new-instance v0, Lcom/vdocipher/aegis/core/m/e;

    .line 13
    invoke-static {p5}, Lcom/vdocipher/aegis/core/k/c;->b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object v6

    move-object v2, p1

    move-object v3, p2

    move-object v4, p4

    move-object v1, p5

    move-object v7, p6

    invoke-direct/range {v0 .. v7}, Lcom/vdocipher/aegis/core/m/e;-><init>(Landroid/content/Context;Ljava/lang/String;Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/player/PlaybackState;ZLcom/vdocipher/aegis/core/k/c;Lcom/vdocipher/aegis/core/m/e$b;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/g$b;->c:Lcom/vdocipher/aegis/core/m/e;

    return-void
.end method


# virtual methods
.method a()V
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g$b;->c:Lcom/vdocipher/aegis/core/m/e;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/m/e;->f()V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    if-eqz v0, :cond_16

    .line 3
    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->stop()V

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    invoke-interface {v0}, Lcom/vdocipher/aegis/player/VdoPlayer;->release()V

    .line 5
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/g$b;->f:Lcom/vdocipher/aegis/core/m/y;

    invoke-interface {v0}, Lcom/vdocipher/aegis/core/m/y;->a()V

    :cond_16
    return-void
.end method
