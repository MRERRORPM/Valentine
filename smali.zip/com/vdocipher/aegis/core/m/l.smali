# classes14.dex

.class public final Lcom/vdocipher/aegis/core/m/l;
.super Landroid/view/View;
.source "SourceFile"

# interfaces
.implements Landroidx/media3/exoplayer/text/TextOutput;


# instance fields
.field private final a:Ljava/util/List;

.field private b:Ljava/util/List;

.field private c:I

.field private d:F

.field private e:Z

.field private f:Z

.field private g:Landroidx/media3/ui/CaptionStyleCompat;

.field private h:F

.field private i:F

.field private j:Ljava/lang/Float;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lcom/vdocipher/aegis/core/m/l;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    .line 2
    invoke-direct {p0, p1, p2}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/high16 p1, 0x3f800000  # 1.0f

    .line 3
    iput p1, p0, Lcom/vdocipher/aegis/core/m/l;->i:F

    const/4 p1, 0x0

    .line 4
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/l;->j:Ljava/lang/Float;

    .line 12
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/l;->a:Ljava/util/List;

    const/4 p1, 0x0

    .line 13
    iput p1, p0, Lcom/vdocipher/aegis/core/m/l;->c:I

    const p1, 0x3d5a511a  # 0.0533f

    .line 14
    iput p1, p0, Lcom/vdocipher/aegis/core/m/l;->d:F

    const/4 p1, 0x1

    .line 15
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/l;->e:Z

    .line 16
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/l;->f:Z

    .line 17
    sget-object p1, Landroidx/media3/ui/CaptionStyleCompat;->DEFAULT:Landroidx/media3/ui/CaptionStyleCompat;

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/l;->g:Landroidx/media3/ui/CaptionStyleCompat;

    const p1, 0x3da3d70a  # 0.08f

    .line 18
    iput p1, p0, Lcom/vdocipher/aegis/core/m/l;->h:F

    return-void
.end method

.method private a(IF)V
    .registers 4

    .line 2
    iget v0, p0, Lcom/vdocipher/aegis/core/m/l;->c:I

    if-ne v0, p1, :cond_b

    iget v0, p0, Lcom/vdocipher/aegis/core/m/l;->d:F

    cmpl-float v0, v0, p2

    if-nez v0, :cond_b

    return-void

    .line 5
    :cond_b
    iput p1, p0, Lcom/vdocipher/aegis/core/m/l;->c:I

    .line 6
    iput p2, p0, Lcom/vdocipher/aegis/core/m/l;->d:F

    .line 8
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method private getCaptionManager()Landroid/view/accessibility/CaptioningManager;
    .registers 3

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "captioning"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/accessibility/CaptioningManager;

    return-object v0
.end method

.method private getUserCaptionFontScaleV19()F
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/l;->getCaptionManager()Landroid/view/accessibility/CaptioningManager;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/accessibility/CaptioningManager;->getFontScale()F

    move-result v0

    return v0
.end method

.method private getUserCaptionStyleV19()Landroidx/media3/ui/CaptionStyleCompat;
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/l;->getCaptionManager()Landroid/view/accessibility/CaptioningManager;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/accessibility/CaptioningManager;->getUserStyle()Landroid/view/accessibility/CaptioningManager$CaptionStyle;

    move-result-object v0

    invoke-static {v0}, Landroidx/media3/ui/CaptionStyleCompat;->createFromCaptionStyle(Landroid/view/accessibility/CaptioningManager$CaptionStyle;)Landroidx/media3/ui/CaptionStyleCompat;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public a(FLjava/lang/Float;)V
    .registers 4

    .line 9
    iget v0, p0, Lcom/vdocipher/aegis/core/m/l;->i:F

    cmpl-float v0, v0, p1

    if-nez v0, :cond_7

    return-void

    .line 12
    :cond_7
    iput p1, p0, Lcom/vdocipher/aegis/core/m/l;->i:F

    .line 13
    iput-object p2, p0, Lcom/vdocipher/aegis/core/m/l;->j:Ljava/lang/Float;

    .line 15
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public a(FZ)V
    .registers 3

    .line 1
    invoke-direct {p0, p2, p1}, Lcom/vdocipher/aegis/core/m/l;->a(IF)V

    return-void
.end method

.method public a()Z
    .registers 2

    .line 16
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/l;->getCaptionManager()Landroid/view/accessibility/CaptioningManager;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/accessibility/CaptioningManager;->isEnabled()Z

    move-result v0

    return v0
.end method

.method public b()V
    .registers 3

    .line 1
    sget v0, Landroidx/media3/common/util/Util;->SDK_INT:I

    const/16 v1, 0x13

    if-lt v0, v1, :cond_11

    invoke-virtual {p0}, Landroid/view/View;->isInEditMode()Z

    move-result v0

    if-nez v0, :cond_11

    .line 2
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/l;->getUserCaptionStyleV19()Landroidx/media3/ui/CaptionStyleCompat;

    move-result-object v0

    goto :goto_13

    :cond_11
    sget-object v0, Landroidx/media3/ui/CaptionStyleCompat;->DEFAULT:Landroidx/media3/ui/CaptionStyleCompat;

    .line 3
    :goto_13
    invoke-virtual {p0, v0}, Lcom/vdocipher/aegis/core/m/l;->setStyle(Landroidx/media3/ui/CaptionStyleCompat;)V

    return-void
.end method

.method public dispatchDraw(Landroid/graphics/Canvas;)V
    .registers 21

    move-object/from16 v0, p0

    .line 1
    iget-object v1, v0, Lcom/vdocipher/aegis/core/m/l;->b:Ljava/util/List;

    const/4 v2, 0x0

    if-nez v1, :cond_9

    move v1, v2

    goto :goto_d

    :cond_9
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    .line 2
    :goto_d
    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result v3

    .line 3
    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    move-result v4

    .line 6
    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v5

    invoke-virtual {v0}, Landroid/view/View;->getPaddingLeft()I

    move-result v6

    add-int v15, v5, v6

    .line 7
    invoke-virtual {v0}, Landroid/view/View;->getPaddingTop()I

    move-result v5

    add-int/2addr v5, v3

    .line 8
    invoke-virtual {v0}, Landroid/view/View;->getRight()I

    move-result v6

    invoke-virtual {v0}, Landroid/view/View;->getPaddingRight()I

    move-result v7

    add-int/2addr v6, v7

    .line 9
    invoke-virtual {v0}, Landroid/view/View;->getPaddingBottom()I

    move-result v7

    sub-int v7, v4, v7

    if-le v7, v5, :cond_8d

    if-gt v6, v15, :cond_38

    goto :goto_8d

    .line 15
    :cond_38
    iget v8, v0, Lcom/vdocipher/aegis/core/m/l;->c:I

    const/4 v9, 0x2

    if-ne v8, v9, :cond_40

    iget v3, v0, Lcom/vdocipher/aegis/core/m/l;->d:F

    goto :goto_4b

    .line 16
    :cond_40
    iget v9, v0, Lcom/vdocipher/aegis/core/m/l;->d:F

    if-nez v8, :cond_47

    sub-int v3, v7, v5

    goto :goto_49

    :cond_47
    sub-int v3, v4, v3

    :goto_49
    int-to-float v3, v3

    mul-float/2addr v3, v9

    .line 18
    :goto_4b
    iget v4, v0, Lcom/vdocipher/aegis/core/m/l;->i:F

    mul-float/2addr v3, v4

    .line 19
    iget-object v4, v0, Lcom/vdocipher/aegis/core/m/l;->j:Ljava/lang/Float;

    if-eqz v4, :cond_5a

    .line 20
    invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->min(FF)F

    move-result v3

    :cond_5a
    move v12, v3

    const/4 v3, 0x0

    cmpg-float v3, v12, v3

    if-gtz v3, :cond_61

    goto :goto_8d

    :cond_61
    :goto_61
    if-ge v2, v1, :cond_8d

    .line 29
    iget-object v3, v0, Lcom/vdocipher/aegis/core/m/l;->a:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/vdocipher/aegis/core/m/k;

    iget-object v4, v0, Lcom/vdocipher/aegis/core/m/l;->b:Ljava/util/List;

    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    move-object v8, v4

    check-cast v8, Landroidx/media3/common/text/Cue;

    iget-boolean v9, v0, Lcom/vdocipher/aegis/core/m/l;->e:Z

    iget-boolean v10, v0, Lcom/vdocipher/aegis/core/m/l;->f:Z

    iget-object v11, v0, Lcom/vdocipher/aegis/core/m/l;->g:Landroidx/media3/ui/CaptionStyleCompat;

    iget v13, v0, Lcom/vdocipher/aegis/core/m/l;->h:F

    move-object/from16 v14, p1

    move/from16 v16, v5

    move/from16 v17, v6

    move/from16 v18, v7

    move-object v7, v3

    invoke-virtual/range {v7 .. v18}, Lcom/vdocipher/aegis/core/m/k;->a(Landroidx/media3/common/text/Cue;ZZLandroidx/media3/ui/CaptionStyleCompat;FFLandroid/graphics/Canvas;IIII)V

    add-int/lit8 v2, v2, 0x1

    move/from16 v7, v18

    goto :goto_61

    :cond_8d
    :goto_8d
    return-void
.end method

.method public onCues(Landroidx/media3/common/text/CueGroup;)V
    .registers 2

    .line 1
    iget-object p1, p1, Landroidx/media3/common/text/CueGroup;->cues:Lcom/google/common/collect/ImmutableList;

    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/m/l;->setCues(Ljava/util/List;)V

    return-void
.end method

.method public setApplyEmbeddedFontSizes(Z)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/l;->f:Z

    if-ne v0, p1, :cond_5

    return-void

    .line 4
    :cond_5
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/l;->f:Z

    .line 6
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public setApplyEmbeddedStyles(Z)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/l;->e:Z

    if-ne v0, p1, :cond_9

    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/m/l;->f:Z

    if-ne v0, p1, :cond_9

    return-void

    .line 5
    :cond_9
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/l;->e:Z

    .line 6
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/m/l;->f:Z

    .line 8
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public setBottomPaddingFraction(F)V
    .registers 3

    .line 1
    iget v0, p0, Lcom/vdocipher/aegis/core/m/l;->h:F

    cmpl-float v0, v0, p1

    if-nez v0, :cond_7

    return-void

    .line 4
    :cond_7
    iput p1, p0, Lcom/vdocipher/aegis/core/m/l;->h:F

    .line 6
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public setCues(Ljava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroidx/media3/common/text/Cue;",
            ">;)V"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/l;->b:Ljava/util/List;

    if-ne v0, p1, :cond_5

    return-void

    .line 4
    :cond_5
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/l;->b:Ljava/util/List;

    if-nez p1, :cond_b

    const/4 p1, 0x0

    goto :goto_f

    .line 6
    :cond_b
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    .line 7
    :goto_f
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/l;->a:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ge v0, p1, :cond_26

    .line 8
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/l;->a:Ljava/util/List;

    new-instance v1, Lcom/vdocipher/aegis/core/m/k;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/vdocipher/aegis/core/m/k;-><init>(Landroid/content/Context;)V

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_f

    .line 11
    :cond_26
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public setFractionalTextSize(F)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-virtual {p0, p1, v0}, Lcom/vdocipher/aegis/core/m/l;->a(FZ)V

    return-void
.end method

.method public setStyle(Landroidx/media3/ui/CaptionStyleCompat;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/l;->g:Landroidx/media3/ui/CaptionStyleCompat;

    if-ne v0, p1, :cond_5

    return-void

    .line 4
    :cond_5
    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/l;->g:Landroidx/media3/ui/CaptionStyleCompat;

    .line 6
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method
