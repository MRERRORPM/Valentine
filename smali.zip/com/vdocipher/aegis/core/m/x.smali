# classes14.dex

.class public final Lcom/vdocipher/aegis/core/m/x;
.super Lcom/vdocipher/aegis/core/m/q;
.source "SourceFile"


# static fields
.field private static final R:Ljava/net/CookieManager;


# instance fields
.field private Q:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Ljava/net/CookieManager;

    invoke-direct {v0}, Ljava/net/CookieManager;-><init>()V

    sput-object v0, Lcom/vdocipher/aegis/core/m/x;->R:Ljava/net/CookieManager;

    .line 2
    sget-object v1, Ljava/net/CookiePolicy;->ACCEPT_ORIGINAL_SERVER:Ljava/net/CookiePolicy;

    invoke-virtual {v0, v1}, Ljava/net/CookieManager;->setCookiePolicy(Ljava/net/CookiePolicy;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/media3/common/Player;Landroid/view/SurfaceView;Lcom/vdocipher/aegis/core/d/k;)V
    .registers 5

    .line 1
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/vdocipher/aegis/core/m/q;-><init>(Landroid/content/Context;Landroidx/media3/common/Player;Landroid/view/SurfaceView;Lcom/vdocipher/aegis/core/d/k;)V

    return-void
.end method

.method private static a(Landroid/media/MediaCodec$CryptoException;)I
    .registers 2

    .line 106
    invoke-virtual {p0}, Landroid/media/MediaCodec$CryptoException;->getErrorCode()I

    move-result p0

    const/4 v0, 0x1

    if-eq p0, v0, :cond_22

    const/4 v0, 0x2

    if-eq p0, v0, :cond_1f

    const/4 v0, 0x3

    if-eq p0, v0, :cond_1c

    const/4 v0, 0x4

    if-eq p0, v0, :cond_19

    const/4 v0, 0x5

    if-eq p0, v0, :cond_16

    const/16 p0, 0x1834

    return p0

    :cond_16
    const/16 p0, 0x1832

    return p0

    :cond_19
    const/16 p0, 0x1831

    return p0

    :cond_1c
    const/16 p0, 0x1830

    return p0

    :cond_1f
    const/16 p0, 0x182f

    return p0

    :cond_22
    const/16 p0, 0x182e

    return p0
.end method

.method private a(Lcom/vdocipher/aegis/core/f/g;)V
    .registers 4

    .line 103
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->r()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->G:Ljava/lang/String;

    .line 104
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->c()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_13

    const-string v0, "NA"

    goto :goto_17

    :cond_13
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->c()Ljava/lang/String;

    move-result-object v0

    :goto_17
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->H:Ljava/lang/String;

    .line 105
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->e()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/vdocipher/aegis/core/m/q;->I:J

    return-void
.end method

.method private n()V
    .registers 2

    .line 1
    invoke-static {}, Ljava/net/CookieHandler;->getDefault()Ljava/net/CookieHandler;

    move-result-object v0

    if-nez v0, :cond_b

    .line 2
    sget-object v0, Lcom/vdocipher/aegis/core/m/x;->R:Ljava/net/CookieManager;

    invoke-static {v0}, Ljava/net/CookieHandler;->setDefault(Ljava/net/CookieHandler;)V

    :cond_b
    return-void
.end method


# virtual methods
.method protected a(Landroid/os/Handler;Ljava/lang/String;Lcom/vdocipher/aegis/core/z/d$b;)Landroidx/media3/common/MediaItem;
    .registers 9

    .line 2
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/x;->Q:Ljava/lang/String;

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    .line 4
    new-instance p2, Landroidx/media3/common/MediaItem$Builder;

    invoke-direct {p2}, Landroidx/media3/common/MediaItem$Builder;-><init>()V

    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/q;->s:Lcom/vdocipher/aegis/core/m/y$a;

    iget-object p3, p3, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    .line 5
    invoke-virtual {p3}, Lcom/vdocipher/aegis/core/m/f;->a()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Landroidx/media3/common/MediaItem$Builder;->setMediaId(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p2

    .line 6
    invoke-virtual {p2, p1}, Landroidx/media3/common/MediaItem$Builder;->setUri(Landroid/net/Uri;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p1

    .line 7
    const-string p2, "application/x-mpegURL"

    invoke-virtual {p1, p2}, Landroidx/media3/common/MediaItem$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p1

    .line 8
    invoke-virtual {p1}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    move-result-object p1

    .line 10
    iget-object p2, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_2e

    return-object p1

    .line 14
    :cond_2e
    :try_start_2e
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    .line 15
    iget-object p3, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_3a
    if-ge v1, v0, :cond_70

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    add-int/lit8 v1, v1, 0x1

    check-cast v2, Lcom/vdocipher/aegis/media/Caption;

    .line 16
    invoke-virtual {v2}, Lcom/vdocipher/aegis/media/Caption;->getUrl()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    .line 17
    new-instance v4, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    invoke-direct {v4, v3}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;-><init>(Landroid/net/Uri;)V

    const-string/jumbo v3, "text/vtt"

    invoke-virtual {v4, v3}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    move-result-object v3

    .line 18
    invoke-virtual {v2}, Lcom/vdocipher/aegis/media/Caption;->getLang()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->setLanguage(Ljava/lang/String;)Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    move-result-object v3

    .line 19
    invoke-virtual {v2}, Lcom/vdocipher/aegis/media/Caption;->getLabel()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->setLabel(Ljava/lang/String;)Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->build()Landroidx/media3/common/MediaItem$SubtitleConfiguration;

    move-result-object v2

    .line 21
    invoke-interface {p2, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_3a

    .line 23
    :cond_70
    invoke-virtual {p1}, Landroidx/media3/common/MediaItem;->buildUpon()Landroidx/media3/common/MediaItem$Builder;

    move-result-object p3

    invoke-virtual {p3, p2}, Landroidx/media3/common/MediaItem$Builder;->setSubtitleConfigurations(Ljava/util/List;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p2

    invoke-virtual {p2}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    move-result-object p1
    :try_end_7c
    .catch Ljava/lang/Exception; {:try_start_2e .. :try_end_7c} :catch_7d

    return-object p1

    :catch_7d
    move-exception p2

    .line 27
    invoke-static {p2}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p2

    const-string p3, "VdoNonSecure"

    invoke-static {p3, p2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-object p1
.end method

.method protected a(Landroidx/media3/common/PlaybackException;)Lcom/vdocipher/aegis/core/m/p;
    .registers 11

    .line 28
    check-cast p1, Landroidx/media3/exoplayer/ExoPlaybackException;

    .line 29
    iget v0, p1, Landroidx/media3/exoplayer/ExoPlaybackException;->type:I

    const/4 v1, 0x1

    if-nez v0, :cond_b

    const-string/jumbo v2, "source"

    goto :goto_13

    :cond_b
    if-ne v0, v1, :cond_10

    .line 30
    const-string v2, "renderer"

    goto :goto_13

    :cond_10
    const-string/jumbo v2, "unexpected"

    :goto_13
    const/4 v3, 0x0

    const/4 v4, -0x1

    if-nez v0, :cond_79

    .line 38
    invoke-virtual {p1}, Landroidx/media3/exoplayer/ExoPlaybackException;->getSourceException()Ljava/io/IOException;

    move-result-object v0

    .line 41
    instance-of v1, v0, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;

    if-eqz v1, :cond_68

    .line 44
    :try_start_1f
    move-object v1, v0

    check-cast v1, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;

    iget-object v1, v1, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;->dataSpec:Landroidx/media3/datasource/DataSpec;

    iget-object v1, v1, Landroidx/media3/datasource/DataSpec;->uri:Landroid/net/Uri;

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_2a
    .catch Ljava/lang/NullPointerException; {:try_start_1f .. :try_end_2a} :catch_2b

    goto :goto_2c

    :catch_2b
    move-object v1, v3

    .line 48
    :goto_2c
    instance-of v5, v0, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    if-eqz v5, :cond_35

    .line 49
    move-object v4, v0

    check-cast v4, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    iget v4, v4, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;->responseCode:I

    :cond_35
    const/16 v5, 0x258

    const/16 v6, 0x190

    const/16 v7, 0x1f4

    if-eqz v1, :cond_57

    .line 53
    const-string v8, "m3u8"

    invoke-virtual {v1, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_57

    if-lt v4, v6, :cond_4d

    if-ge v4, v7, :cond_4d

    const/16 v5, 0x140c

    goto/16 :goto_a5

    :cond_4d
    if-lt v4, v7, :cond_54

    if-ge v4, v5, :cond_54

    const/16 v5, 0x140d

    goto :goto_a5

    :cond_54
    const/16 v5, 0x140a

    goto :goto_a5

    :cond_57
    if-lt v4, v6, :cond_5e

    if-ge v4, v7, :cond_5e

    const/16 v5, 0x13f8

    goto :goto_a5

    :cond_5e
    if-lt v4, v7, :cond_65

    if-ge v4, v5, :cond_65

    const/16 v5, 0x13f9

    goto :goto_a5

    :cond_65
    const/16 v5, 0x13fa

    goto :goto_a5

    .line 72
    :cond_68
    instance-of v1, v0, Landroidx/media3/common/ParserException;

    if-eqz v1, :cond_6f

    const/16 v5, 0x17f2

    goto :goto_a4

    .line 75
    :cond_6f
    instance-of v1, v0, Ljava/io/FileNotFoundException;

    if-eqz v1, :cond_76

    const/16 v5, 0x142a

    goto :goto_a4

    :cond_76
    const/16 v5, 0x13f6

    goto :goto_a4

    :cond_79
    if-ne v0, v1, :cond_95

    .line 84
    invoke-virtual {p1}, Landroidx/media3/exoplayer/ExoPlaybackException;->getRendererException()Ljava/lang/Exception;

    move-result-object v0

    .line 85
    instance-of v1, v0, Landroid/media/MediaCodec$CryptoException;

    if-eqz v1, :cond_8b

    .line 86
    move-object v1, v0

    check-cast v1, Landroid/media/MediaCodec$CryptoException;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/m/x;->a(Landroid/media/MediaCodec$CryptoException;)I

    move-result v5

    goto :goto_a4

    .line 87
    :cond_8b
    instance-of v1, v0, Landroidx/media3/exoplayer/mediacodec/MediaCodecRenderer$DecoderInitializationException;

    if-eqz v1, :cond_92

    const/16 v5, 0x17ea

    goto :goto_a4

    :cond_92
    const/16 v5, 0x17e8

    goto :goto_a4

    .line 93
    :cond_95
    invoke-virtual {p1}, Landroidx/media3/exoplayer/ExoPlaybackException;->getUnexpectedException()Ljava/lang/RuntimeException;

    move-result-object v0

    .line 94
    invoke-virtual {p0, v0}, Lcom/vdocipher/aegis/core/m/q;->a(Ljava/lang/Throwable;)Z

    move-result v1

    if-eqz v1, :cond_a2

    const/16 v5, 0x17e9

    goto :goto_a4

    :cond_a2
    const/16 v5, 0x17d5

    :goto_a4
    move-object v1, v3

    .line 98
    :goto_a5
    new-instance v6, Lcom/vdocipher/aegis/core/m/d;

    if-eqz v0, :cond_ad

    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v3

    :cond_ad
    invoke-direct {v6, v2, v4, v1, v3}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 99
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "epError: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6}, Lcom/vdocipher/aegis/core/m/d;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "--"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "VdoNonSecure"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 101
    invoke-static {v5}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object p1

    .line 102
    new-instance v0, Lcom/vdocipher/aegis/core/m/p;

    invoke-direct {v0, v5, p1, v6}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    return-object v0
.end method

.method public a()V
    .registers 1

    .line 1
    invoke-super {p0}, Lcom/vdocipher/aegis/core/m/q;->a()V

    return-void
.end method

.method protected b(Lcom/vdocipher/aegis/core/m/y$a;)V
    .registers 14

    const-string v1, "VdoNonSecure"

    const/4 v2, 0x0

    const/4 v3, -0x1

    const/4 v4, 0x1

    .line 1
    :try_start_5
    new-instance v0, Lcom/vdocipher/aegis/core/f/g;

    iget-object v5, p1, Lcom/vdocipher/aegis/core/m/y$a;->b:Ljava/lang/String;

    invoke-direct {v0, v5}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    .line 2
    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/m/x;->a(Lcom/vdocipher/aegis/core/f/g;)V

    .line 5
    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->clear()V

    .line 6
    iget-object v5, p1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-boolean v5, v5, Lcom/vdocipher/aegis/player/VdoInitParams;->offlinePlayback:Z

    if-eqz v5, :cond_22

    iget-object v5, p1, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v5}, Lcom/vdocipher/aegis/core/m/f;->b()Z

    move-result v5

    if-eqz v5, :cond_27

    .line 7
    :cond_22
    iget-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->v:Ljava/util/ArrayList;

    invoke-virtual {v0, v5}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/util/ArrayList;)Ljava/util/ArrayList;

    .line 8
    :cond_27
    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/g;->l()Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/vdocipher/aegis/core/m/x;->Q:Ljava/lang/String;
    :try_end_2d
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_2d} :catch_c0

    .line 20
    :try_start_2d
    iget-object v5, p1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v5, v5, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    invoke-static {v5}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->F:Ljava/lang/String;
    :try_end_37
    .catch Lorg/json/JSONException; {:try_start_2d .. :try_end_37} :catch_91
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_2d .. :try_end_37} :catch_8f
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2d .. :try_end_37} :catch_8c

    .line 34
    iget-object v2, p1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-boolean v2, v2, Lcom/vdocipher/aegis/player/VdoInitParams;->offlinePlayback:Z

    const/4 v3, 0x2

    if-eqz v2, :cond_48

    iget-object v2, p1, Lcom/vdocipher/aegis/core/m/y$a;->l:Lcom/vdocipher/aegis/core/m/f;

    invoke-virtual {v2}, Lcom/vdocipher/aegis/core/m/f;->b()Z

    move-result v2

    if-nez v2, :cond_48

    move v6, v3

    goto :goto_49

    :cond_48
    move v6, v4

    .line 35
    :goto_49
    new-instance v5, Lcom/vdocipher/aegis/media/MediaInfo;

    iget-object v7, p0, Lcom/vdocipher/aegis/core/m/q;->F:Ljava/lang/String;

    iget-object v8, p0, Lcom/vdocipher/aegis/core/m/q;->G:Ljava/lang/String;

    iget-object v9, p0, Lcom/vdocipher/aegis/core/m/q;->H:Ljava/lang/String;

    iget-wide v10, p0, Lcom/vdocipher/aegis/core/m/q;->I:J

    invoke-direct/range {v5 .. v11}, Lcom/vdocipher/aegis/media/MediaInfo;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    iput-object v5, p0, Lcom/vdocipher/aegis/core/m/q;->C:Lcom/vdocipher/aegis/media/MediaInfo;

    .line 38
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/m/x;->n()V

    .line 41
    :try_start_5b
    const-string v2, ""

    .line 42
    iget-object v4, p1, Lcom/vdocipher/aegis/core/m/y$a;->k:Landroidx/media3/exoplayer/offline/Download;

    if-eqz v4, :cond_65

    .line 43
    invoke-static {v4}, Lcom/vdocipher/aegis/offline/DownloadStatus;->getOfflineScrubbingPreviewUrl(Landroidx/media3/exoplayer/offline/Download;)Ljava/lang/String;

    move-result-object v2

    .line 45
    :cond_65
    iget-object p1, p1, Lcom/vdocipher/aegis/core/m/y$a;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v4, p1, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    iget-object p1, p1, Lcom/vdocipher/aegis/player/VdoInitParams;->configMap:Ljava/util/HashMap;

    invoke-virtual {v0, v4, p1, v2}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/lang/String;Ljava/util/HashMap;Ljava/lang/String;)Lcom/vdocipher/aegis/media/PlayerOption;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->c:Lcom/vdocipher/aegis/media/PlayerOption;
    :try_end_71
    .catch Ljava/lang/Exception; {:try_start_5b .. :try_end_71} :catch_72

    goto :goto_82

    :catch_72
    move-exception v0

    move-object p1, v0

    .line 47
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 48
    new-instance p1, Lcom/vdocipher/aegis/media/PlayerOption;

    invoke-direct {p1}, Lcom/vdocipher/aegis/media/PlayerOption;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->c:Lcom/vdocipher/aegis/media/PlayerOption;

    .line 51
    :goto_82
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    invoke-virtual {p1, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void

    :catch_8c
    move-exception v0

    :goto_8d
    move-object p1, v0

    goto :goto_93

    :catch_8f
    move-exception v0

    goto :goto_8d

    :catch_91
    move-exception v0

    goto :goto_8d

    .line 52
    :goto_93
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x1005

    .line 54
    invoke-static {v0}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v1

    .line 55
    new-instance v5, Lcom/vdocipher/aegis/core/m/d;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v5, v6, v3, v2, p1}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 56
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    new-instance v2, Lcom/vdocipher/aegis/core/m/p;

    invoke-direct {v2, v0, v1, v5}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    invoke-virtual {p1, v4, v2}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void

    :catch_c0
    move-exception v0

    move-object p1, v0

    .line 57
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0xc1c

    .line 59
    invoke-static {v0}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v1

    .line 60
    new-instance v5, Lcom/vdocipher/aegis/core/m/d;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v5, v6, v3, v2, p1}, Lcom/vdocipher/aegis/core/m/d;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 61
    iget-object p1, p0, Lcom/vdocipher/aegis/core/m/q;->e:Landroid/os/Handler;

    new-instance v2, Lcom/vdocipher/aegis/core/m/p;

    invoke-direct {v2, v0, v1, v5}, Lcom/vdocipher/aegis/core/m/p;-><init>(ILjava/lang/String;Lcom/vdocipher/aegis/core/m/d;)V

    invoke-virtual {p1, v4, v2}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void
.end method

.method public getPlayerOptions()Lcom/vdocipher/aegis/media/PlayerOption;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/m/q;->c:Lcom/vdocipher/aegis/media/PlayerOption;

    return-object v0
.end method

.method protected j()V
    .registers 1

    return-void
.end method

.method public stop()V
    .registers 2

    .line 1
    invoke-super {p0}, Lcom/vdocipher/aegis/core/m/q;->stop()V

    const/4 v0, 0x0

    .line 3
    iput-object v0, p0, Lcom/vdocipher/aegis/core/m/x;->Q:Ljava/lang/String;

    return-void
.end method
