# classes14.dex

.class Lcom/vdocipher/aegis/core/j/a$d$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vdocipher/aegis/core/j/d$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/vdocipher/aegis/core/j/a$d;->doInBackground([Ljava/lang/Void;)Ljava/lang/Void;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/j/a$d;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/j/a$d;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/j/a$d$a;->a:Lcom/vdocipher/aegis/core/j/a$d;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcom/vdocipher/aegis/core/k/f;)V
    .registers 3

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$d$a;->a:Lcom/vdocipher/aegis/core/j/a$d;

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/j/a$d;->a(Lcom/vdocipher/aegis/core/j/a$d;Lcom/vdocipher/aegis/core/k/f;)Lcom/vdocipher/aegis/core/k/f;

    return-void
.end method

.method public a(Lcom/vdocipher/aegis/core/k/g;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$d$a;->a:Lcom/vdocipher/aegis/core/j/a$d;

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/j/a$d;->a(Lcom/vdocipher/aegis/core/j/a$d;Lcom/vdocipher/aegis/core/k/g;)Lcom/vdocipher/aegis/core/k/g;

    return-void
.end method
