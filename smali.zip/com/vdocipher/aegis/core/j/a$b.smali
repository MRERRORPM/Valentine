# classes14.dex

.class public interface abstract Lcom/vdocipher/aegis/core/j/a$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/j/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a(Lcom/vdocipher/aegis/offline/DownloadStatus;)V
.end method

.method public abstract a(Lcom/vdocipher/aegis/offline/DownloadStatus;Ljava/lang/Exception;)V
.end method

.method public abstract a(Ljava/util/Set;)V
.end method

.method public abstract onFailed(Ljava/lang/String;Lcom/vdocipher/aegis/offline/DownloadStatus;)V
.end method
