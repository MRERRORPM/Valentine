# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/j/a$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/j/a;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/j/a;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/j/a$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/j/a;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/a;->$r8$lambda$WZCIR3hZaSTeaPafdO1sRLBTltk(Lcom/vdocipher/aegis/core/j/a;)V

    return-void
.end method
