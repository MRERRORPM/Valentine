# classes14.dex

.class public Lcom/vdocipher/aegis/core/j/d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/core/j/d$a;
    }
.end annotation


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Lcom/vdocipher/aegis/core/k/k;

.field private final c:Lcom/vdocipher/aegis/core/j/d$a;

.field private d:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/vdocipher/aegis/core/k/k;Lcom/vdocipher/aegis/core/j/d$a;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lcom/vdocipher/aegis/core/j/d;->d:I

    .line 11
    iput-object p1, p0, Lcom/vdocipher/aegis/core/j/d;->a:Landroid/content/Context;

    .line 12
    iput-object p2, p0, Lcom/vdocipher/aegis/core/j/d;->b:Lcom/vdocipher/aegis/core/k/k;

    .line 13
    iput-object p3, p0, Lcom/vdocipher/aegis/core/j/d;->c:Lcom/vdocipher/aegis/core/j/d$a;

    return-void
.end method


# virtual methods
.method public a()V
    .registers 5

    const-string v0, "OffLicHlpr"

    .line 1
    :try_start_2
    iget-object v1, p0, Lcom/vdocipher/aegis/core/j/d;->a:Landroid/content/Context;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/j/d;->b:Lcom/vdocipher/aegis/core/k/k;

    invoke-static {v1, v2}, Lcom/vdocipher/aegis/core/k/h;->a(Landroid/content/Context;Lcom/vdocipher/aegis/core/k/k;)Lcom/vdocipher/aegis/core/q/b;

    move-result-object v1

    .line 4
    iget-object v2, p0, Lcom/vdocipher/aegis/core/j/d;->a:Landroid/content/Context;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/j/d;->b:Lcom/vdocipher/aegis/core/k/k;

    invoke-static {v2, v3, v1}, Lcom/vdocipher/aegis/core/k/h;->b(Landroid/content/Context;Lcom/vdocipher/aegis/core/k/k;Lcom/vdocipher/aegis/core/q/b;)Lcom/vdocipher/aegis/core/k/g;

    move-result-object v1

    .line 7
    iget-object v2, p0, Lcom/vdocipher/aegis/core/j/d;->c:Lcom/vdocipher/aegis/core/j/d$a;

    invoke-interface {v2, v1}, Lcom/vdocipher/aegis/core/j/d$a;->a(Lcom/vdocipher/aegis/core/k/g;)V

    .line 8
    const-string v1, "lic done"

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1c
    .catch Lcom/vdocipher/aegis/core/k/f; {:try_start_2 .. :try_end_1c} :catch_26
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_1c} :catch_1d

    return-void

    :catch_1d
    move-exception v1

    .line 18
    invoke-static {v1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_42

    :catch_26
    move-exception v0

    .line 19
    iget v1, p0, Lcom/vdocipher/aegis/core/j/d;->d:I

    if-nez v1, :cond_3d

    iget v2, v0, Lcom/vdocipher/aegis/core/k/f;->a:I

    const/16 v3, 0x7f4

    if-eq v2, v3, :cond_35

    const/16 v3, 0x7f7

    if-ne v2, v3, :cond_3d

    :cond_35
    add-int/lit8 v1, v1, 0x1

    .line 21
    iput v1, p0, Lcom/vdocipher/aegis/core/j/d;->d:I

    .line 22
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/j/d;->a()V

    goto :goto_42

    .line 24
    :cond_3d
    iget-object v1, p0, Lcom/vdocipher/aegis/core/j/d;->c:Lcom/vdocipher/aegis/core/j/d$a;

    invoke-interface {v1, v0}, Lcom/vdocipher/aegis/core/j/d$a;->a(Lcom/vdocipher/aegis/core/k/f;)V

    :goto_42
    return-void
.end method
