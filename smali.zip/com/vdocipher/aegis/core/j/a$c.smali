# classes14.dex

.class final Lcom/vdocipher/aegis/core/j/a$c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/media3/exoplayer/offline/DownloadHelper$Callback;
.implements Lcom/vdocipher/aegis/core/j/c$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/j/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "c"
.end annotation


# instance fields
.field private final a:Landroidx/media3/exoplayer/offline/DownloadHelper;

.field public final b:Lcom/vdocipher/aegis/offline/DownloadRequest;

.field private c:Lcom/vdocipher/aegis/core/j/a$d;

.field private d:Lcom/vdocipher/aegis/core/k/d;

.field e:Lcom/vdocipher/aegis/core/j/c;

.field f:Lcom/vdocipher/aegis/core/k/g;

.field final synthetic g:Lcom/vdocipher/aegis/core/j/a;


# direct methods
.method public constructor <init>(Lcom/vdocipher/aegis/core/j/a;Landroidx/media3/exoplayer/offline/DownloadHelper;Lcom/vdocipher/aegis/offline/DownloadRequest;)V
    .registers 9

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Lcom/vdocipher/aegis/core/j/c;

    invoke-direct {v0}, Lcom/vdocipher/aegis/core/j/c;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/j/a$c;->e:Lcom/vdocipher/aegis/core/j/c;

    .line 7
    iput-object p2, p0, Lcom/vdocipher/aegis/core/j/a$c;->a:Landroidx/media3/exoplayer/offline/DownloadHelper;

    .line 8
    iput-object p3, p0, Lcom/vdocipher/aegis/core/j/a$c;->b:Lcom/vdocipher/aegis/offline/DownloadRequest;

    .line 9
    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object p3

    invoke-virtual {p3}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p3

    .line 10
    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    iget v0, v0, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_76

    .line 12
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const-string v2, "VDO_DOWNLOAD_PERMISSION_REQUIRED"

    const/16 v3, 0x3ef

    const-string v4, "android.permission.FOREGROUND_SERVICE_DATA_SYNC"

    if-lt v0, v1, :cond_48

    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p3, v4, v0}, Landroid/content/pm/PackageManager;->checkPermission(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_48

    .line 13
    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object p1

    sget p2, Lcom/vdocipher/aegis/R$string;->vdo_download_permission_required:I

    invoke-direct {p0, v3, p1, v2, p2}, Lcom/vdocipher/aegis/core/j/a$c;->a(ILandroid/content/Context;Ljava/lang/String;I)V

    return-void

    .line 17
    :cond_48
    :try_start_48
    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x1000

    invoke-virtual {p3, v0, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p3

    .line 18
    iget-object p3, p3, Landroid/content/pm/PackageInfo;->requestedPermissions:[Ljava/lang/String;

    invoke-static {p3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p3

    .line 19
    invoke-interface {p3, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_76

    .line 20
    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object p1

    sget p3, Lcom/vdocipher/aegis/R$string;->vdo_download_permission_required:I

    invoke-direct {p0, v3, p1, v2, p3}, Lcom/vdocipher/aegis/core/j/a$c;->a(ILandroid/content/Context;Ljava/lang/String;I)V
    :try_end_6b
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_48 .. :try_end_6b} :catch_6c

    return-void

    :catch_6c
    move-exception p1

    .line 24
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const-string p3, "DownloadTracker"

    invoke-static {p3, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 28
    :cond_76
    invoke-virtual {p2, p0}, Landroidx/media3/exoplayer/offline/DownloadHelper;->prepare(Landroidx/media3/exoplayer/offline/DownloadHelper$Callback;)V

    .line 29
    iget-object p1, p0, Lcom/vdocipher/aegis/core/j/a$c;->e:Lcom/vdocipher/aegis/core/j/c;

    invoke-virtual {p1, p0}, Lcom/vdocipher/aegis/core/j/c;->a(Lcom/vdocipher/aegis/core/j/c$a;)V

    return-void
.end method

.method private a(Landroidx/media3/exoplayer/offline/DownloadHelper;)Landroidx/media3/common/Format;
    .registers 12

    const/4 v0, 0x0

    move v1, v0

    .line 6
    :goto_2
    invoke-virtual {p1}, Landroidx/media3/exoplayer/offline/DownloadHelper;->getPeriodCount()I

    move-result v2

    if-ge v1, v2, :cond_3a

    .line 7
    invoke-virtual {p1, v1}, Landroidx/media3/exoplayer/offline/DownloadHelper;->getMappedTrackInfo(I)Landroidx/media3/exoplayer/trackselection/MappingTrackSelector$MappedTrackInfo;

    move-result-object v2

    move v3, v0

    .line 9
    :goto_d
    invoke-virtual {v2}, Landroidx/media3/exoplayer/trackselection/MappingTrackSelector$MappedTrackInfo;->getRendererCount()I

    move-result v4

    if-ge v3, v4, :cond_37

    .line 11
    invoke-virtual {v2, v3}, Landroidx/media3/exoplayer/trackselection/MappingTrackSelector$MappedTrackInfo;->getTrackGroups(I)Landroidx/media3/exoplayer/source/TrackGroupArray;

    move-result-object v4

    move v5, v0

    .line 12
    :goto_18
    iget v6, v4, Landroidx/media3/exoplayer/source/TrackGroupArray;->length:I

    if-ge v5, v6, :cond_34

    .line 13
    invoke-virtual {v4, v5}, Landroidx/media3/exoplayer/source/TrackGroupArray;->get(I)Landroidx/media3/common/TrackGroup;

    move-result-object v6

    move v7, v0

    .line 14
    :goto_21
    iget v8, v6, Landroidx/media3/common/TrackGroup;->length:I

    if-ge v7, v8, :cond_31

    .line 15
    invoke-virtual {v6, v7}, Landroidx/media3/common/TrackGroup;->getFormat(I)Landroidx/media3/common/Format;

    move-result-object v8

    .line 16
    iget-object v9, v8, Landroidx/media3/common/Format;->drmInitData:Landroidx/media3/common/DrmInitData;

    if-eqz v9, :cond_2e

    return-object v8

    :cond_2e
    add-int/lit8 v7, v7, 0x1

    goto :goto_21

    :cond_31
    add-int/lit8 v5, v5, 0x1

    goto :goto_18

    :cond_34
    add-int/lit8 v3, v3, 0x1

    goto :goto_d

    :cond_37
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_3a
    const/4 p1, 0x0

    return-object p1
.end method

.method private a(Landroidx/media3/exoplayer/offline/DownloadHelper;Ljava/lang/String;Lorg/json/JSONObject;)Landroidx/media3/exoplayer/offline/DownloadRequest;
    .registers 5

    .line 127
    invoke-virtual {p3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p3

    sget-object v0, Lcom/google/common/base/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p3, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p3

    invoke-virtual {p1, p2, p3}, Landroidx/media3/exoplayer/offline/DownloadHelper;->getDownloadRequest(Ljava/lang/String;[B)Landroidx/media3/exoplayer/offline/DownloadRequest;

    move-result-object p1

    .line 129
    iget-object p2, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {p2}, Lcom/vdocipher/aegis/core/j/a;->f(Lcom/vdocipher/aegis/core/j/a;)Z

    move-result p2

    if-eqz p2, :cond_20

    .line 130
    iget-object p2, p0, Lcom/vdocipher/aegis/core/j/a$c;->f:Lcom/vdocipher/aegis/core/k/g;

    invoke-virtual {p2}, Lcom/vdocipher/aegis/core/k/g;->b()[B

    move-result-object p2

    invoke-virtual {p1, p2}, Landroidx/media3/exoplayer/offline/DownloadRequest;->copyWithKeySetId([B)Landroidx/media3/exoplayer/offline/DownloadRequest;

    move-result-object p1

    :cond_20
    return-object p1
.end method

.method private a(Lcom/vdocipher/aegis/offline/DownloadRequest;)Lcom/vdocipher/aegis/core/k/d;
    .registers 20

    move-object/from16 v0, p1

    .line 99
    iget-object v1, v0, Lcom/vdocipher/aegis/offline/DownloadRequest;->downloadSelections:Lcom/vdocipher/aegis/offline/DownloadSelections;

    iget-object v1, v1, Lcom/vdocipher/aegis/offline/DownloadSelections;->downloadOptions:Lcom/vdocipher/aegis/offline/DownloadOptions;

    check-cast v1, Lcom/vdocipher/aegis/core/k/a;

    .line 101
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 102
    new-instance v3, Lorg/json/JSONArray;

    invoke-direct {v3}, Lorg/json/JSONArray;-><init>()V

    .line 105
    iget-object v4, v0, Lcom/vdocipher/aegis/offline/DownloadRequest;->downloadSelections:Lcom/vdocipher/aegis/offline/DownloadSelections;

    iget-object v4, v4, Lcom/vdocipher/aegis/offline/DownloadSelections;->selectedTrackIndices:[I

    .line 106
    array-length v5, v4

    const/4 v6, 0x0

    move v7, v6

    :goto_19
    if-ge v7, v5, :cond_37

    aget v8, v4, v7

    .line 107
    iget-object v9, v1, Lcom/vdocipher/aegis/offline/DownloadOptions;->availableTracks:[Lcom/vdocipher/aegis/media/Track;

    aget-object v8, v9, v8

    .line 108
    iget v9, v8, Lcom/vdocipher/aegis/media/Track;->type:I

    const/4 v10, 0x1

    if-ne v9, v10, :cond_2c

    .line 109
    iget v8, v8, Lcom/vdocipher/aegis/media/Track;->id:I

    invoke-virtual {v3, v8}, Lorg/json/JSONArray;->put(I)Lorg/json/JSONArray;

    goto :goto_34

    :cond_2c
    const/4 v10, 0x2

    if-ne v9, v10, :cond_34

    .line 111
    iget v8, v8, Lcom/vdocipher/aegis/media/Track;->id:I

    invoke-virtual {v3, v8}, Lorg/json/JSONArray;->put(I)Lorg/json/JSONArray;

    :cond_34
    :goto_34
    add-int/lit8 v7, v7, 0x1

    goto :goto_19

    .line 115
    :cond_37
    const-string/jumbo v4, "tids"

    invoke-virtual {v2, v4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 116
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v0, v0, Lcom/vdocipher/aegis/offline/DownloadRequest;->localStorageFolder:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v0, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v1, Lcom/vdocipher/aegis/offline/DownloadOptions;->mediaId:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    .line 118
    iget-object v15, v1, Lcom/vdocipher/aegis/core/k/a;->g:Ljava/lang/String;

    .line 120
    new-instance v7, Lcom/vdocipher/aegis/core/k/d$b;

    iget-object v8, v1, Lcom/vdocipher/aegis/offline/DownloadOptions;->mediaId:Ljava/lang/String;

    iget-object v11, v1, Lcom/vdocipher/aegis/core/k/a;->a:Ljava/lang/String;

    iget-object v12, v1, Lcom/vdocipher/aegis/core/k/a;->b:Ljava/lang/String;

    iget-object v13, v1, Lcom/vdocipher/aegis/core/k/a;->e:Ljava/lang/String;

    iget-object v14, v1, Lcom/vdocipher/aegis/core/k/a;->f:Ljava/lang/String;

    .line 122
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v16

    iget-object v0, v1, Lcom/vdocipher/aegis/core/k/a;->k:Ljava/lang/String;

    const-string v10, "dash"

    move-object/from16 v17, v0

    invoke-direct/range {v7 .. v17}, Lcom/vdocipher/aegis/core/k/d$b;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 123
    iget-object v0, v1, Lcom/vdocipher/aegis/core/k/a;->c:Ljava/lang/String;

    invoke-virtual {v7, v6, v0}, Lcom/vdocipher/aegis/core/k/d$b;->a(ILjava/lang/String;)Lcom/vdocipher/aegis/core/k/d$b;

    .line 124
    invoke-virtual {v7}, Lcom/vdocipher/aegis/core/k/d$b;->a()Lcom/vdocipher/aegis/core/k/d;

    move-result-object v0

    return-object v0
.end method

.method private a()Ljava/lang/String;
    .registers 3

    .line 52
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/b;->h(Landroid/content/Context;)Ljava/io/File;

    move-result-object v0

    .line 53
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    sget-object v0, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "exoplayer"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private a(Lcom/vdocipher/aegis/media/Caption;)Ljava/lang/String;
    .registers 5

    .line 54
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/b;->h(Landroid/content/Context;)Ljava/io/File;

    move-result-object v0

    .line 55
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    sget-object v0, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "captions"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/Caption;->getUrl()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-virtual {p1}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private a(Lcom/vdocipher/aegis/offline/DownloadRequest;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZLjava/lang/String;)Lorg/json/JSONObject;
    .registers 14

    .line 68
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 69
    iget-object v1, p0, Lcom/vdocipher/aegis/core/j/a$c;->d:Lcom/vdocipher/aegis/core/k/d;

    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/k/d;->a()Ljava/lang/String;

    move-result-object v1

    .line 71
    new-instance v2, Lorg/json/JSONArray;

    invoke-direct {v2}, Lorg/json/JSONArray;-><init>()V

    .line 73
    invoke-interface {p4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p4

    :goto_14
    invoke-interface {p4}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3f

    invoke-interface {p4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/util/Pair;

    .line 74
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    .line 75
    iget-object v5, v3, Landroid/util/Pair;->first:Ljava/lang/Object;

    const-string v6, "caption_path"

    invoke-virtual {v4, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 76
    sget-object v5, Lcom/vdocipher/aegis/media/Caption;->Companion:Lcom/vdocipher/aegis/media/Caption$Companion;

    iget-object v3, v3, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v3, Lcom/vdocipher/aegis/media/Caption;

    invoke-virtual {v5, v3}, Lcom/vdocipher/aegis/media/Caption$Companion;->toJSON(Lcom/vdocipher/aegis/media/Caption;)Lorg/json/JSONObject;

    move-result-object v3

    const-string v5, "caption_info"

    invoke-virtual {v4, v5, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 77
    invoke-virtual {v2, v4}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_14

    .line 81
    :cond_3f
    :try_start_3f
    const-string/jumbo p4, "title"

    iget-object v3, p1, Lcom/vdocipher/aegis/offline/DownloadRequest;->downloadSelections:Lcom/vdocipher/aegis/offline/DownloadSelections;

    iget-object v3, v3, Lcom/vdocipher/aegis/offline/DownloadSelections;->downloadOptions:Lcom/vdocipher/aegis/offline/DownloadOptions;

    iget-object v3, v3, Lcom/vdocipher/aegis/offline/DownloadOptions;->mediaInfo:Lcom/vdocipher/aegis/media/MediaInfo;

    iget-object v3, v3, Lcom/vdocipher/aegis/media/MediaInfo;->title:Ljava/lang/String;

    invoke-virtual {v0, p4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 82
    const-string p4, "displayTitle"

    iget-object v3, p1, Lcom/vdocipher/aegis/offline/DownloadRequest;->notificationTitle:Ljava/lang/String;

    invoke-virtual {v0, p4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 83
    const-string p4, "description"

    iget-object v3, p1, Lcom/vdocipher/aegis/offline/DownloadRequest;->downloadSelections:Lcom/vdocipher/aegis/offline/DownloadSelections;

    iget-object v3, v3, Lcom/vdocipher/aegis/offline/DownloadSelections;->downloadOptions:Lcom/vdocipher/aegis/offline/DownloadOptions;

    iget-object v3, v3, Lcom/vdocipher/aegis/offline/DownloadOptions;->mediaInfo:Lcom/vdocipher/aegis/media/MediaInfo;

    iget-object v3, v3, Lcom/vdocipher/aegis/media/MediaInfo;->description:Ljava/lang/String;

    invoke-virtual {v0, p4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 84
    const-string p4, "displayDescription"

    iget-object p1, p1, Lcom/vdocipher/aegis/offline/DownloadRequest;->notificationDescription:Ljava/lang/String;

    invoke-virtual {v0, p4, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 85
    const-string p1, "posterPath"

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 86
    const-string p1, "dlspec"

    invoke-virtual {v0, p1, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 87
    const-string p1, "localStorageFolder"

    invoke-virtual {v0, p1, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 88
    const-string p1, "saved_offline"

    xor-int/lit8 p2, p5, 0x1

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 89
    const-string p1, "scrub_path"

    invoke-virtual {v0, p1, p6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 90
    const-string p1, "captions"

    invoke-virtual {v0, p1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 91
    iget-object p1, p0, Lcom/vdocipher/aegis/core/j/a$c;->f:Lcom/vdocipher/aegis/core/k/g;

    if-eqz p1, :cond_b0

    .line 92
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/k/g;->c()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_9d

    .line 93
    const-string p1, "securityLevel"

    iget-object p2, p0, Lcom/vdocipher/aegis/core/j/a$c;->f:Lcom/vdocipher/aegis/core/k/g;

    invoke-virtual {p2}, Lcom/vdocipher/aegis/core/k/g;->c()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 94
    :cond_9d
    iget-object p1, p0, Lcom/vdocipher/aegis/core/j/a$c;->f:Lcom/vdocipher/aegis/core/k/g;

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/k/g;->a()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_b0

    .line 95
    const-string p1, "annotationCode"

    iget-object p2, p0, Lcom/vdocipher/aegis/core/j/a$c;->f:Lcom/vdocipher/aegis/core/k/g;

    invoke-virtual {p2}, Lcom/vdocipher/aegis/core/k/g;->a()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_b0
    .catch Lorg/json/JSONException; {:try_start_3f .. :try_end_b0} :catch_b1

    :cond_b0
    return-object v0

    :catch_b1
    move-exception p1

    .line 98
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DownloadTracker"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method private a(IILjava/lang/String;)V
    .registers 28

    move-object/from16 v1, p0

    move/from16 v0, p2

    .line 24
    :try_start_4
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 25
    invoke-static/range {p3 .. p3}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_16

    const-string v3, "message"

    move-object/from16 v4, p3

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_16
    if-lez v0, :cond_1d

    .line 26
    const-string v3, "httpStatus"

    invoke-virtual {v2, v3, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 27
    :cond_1d
    invoke-virtual {v2}, Lorg/json/JSONObject;->length()I

    move-result v0

    if-lez v0, :cond_32

    .line 28
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_27
    .catch Lorg/json/JSONException; {:try_start_4 .. :try_end_27} :catch_28

    goto :goto_33

    :catch_28
    move-exception v0

    .line 31
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "DownloadTracker"

    invoke-static {v2, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_32
    const/4 v0, 0x0

    .line 36
    :goto_33
    iget-object v2, v1, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Lcom/vdocipher/aegis/core/z/b;->a(Landroid/content/Context;)Lcom/vdocipher/aegis/core/z/b;

    move-result-object v2

    invoke-virtual {v2}, Lcom/vdocipher/aegis/core/z/b;->a()Ljava/util/Map;

    move-result-object v2

    .line 37
    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_59

    .line 38
    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/aegis/core/f/b;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/b;->a()Ljava/lang/String;

    move-result-object v0

    :cond_59
    move-object v5, v0

    .line 41
    iget-object v0, v1, Lcom/vdocipher/aegis/core/j/a$c;->b:Lcom/vdocipher/aegis/offline/DownloadRequest;

    iget-object v0, v0, Lcom/vdocipher/aegis/offline/DownloadRequest;->downloadSelections:Lcom/vdocipher/aegis/offline/DownloadSelections;

    iget-object v0, v0, Lcom/vdocipher/aegis/offline/DownloadSelections;->downloadOptions:Lcom/vdocipher/aegis/offline/DownloadOptions;

    iget-object v2, v0, Lcom/vdocipher/aegis/offline/DownloadOptions;->mediaId:Ljava/lang/String;

    .line 42
    iget-object v0, v0, Lcom/vdocipher/aegis/offline/DownloadOptions;->mediaInfo:Lcom/vdocipher/aegis/media/MediaInfo;

    .line 43
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v8

    invoke-direct {v1, v2}, Lcom/vdocipher/aegis/core/j/a$c;->c(Ljava/lang/String;)Z

    move-result v16

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/4 v3, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v10, -0x1

    const-wide/16 v12, 0x0

    move/from16 v4, p1

    move-object v2, v0

    .line 44
    invoke-static/range {v2 .. v16}, Lcom/vdocipher/aegis/offline/DownloadStatus;->createForFailed(Lcom/vdocipher/aegis/media/MediaInfo;Ljava/lang/String;ILjava/lang/String;JJJJILjava/lang/String;Z)Lcom/vdocipher/aegis/offline/DownloadStatus;

    move-result-object v0

    .line 48
    iget-object v2, v1, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/j/a;->b(Lcom/vdocipher/aegis/core/j/a;)Ljava/util/concurrent/CopyOnWriteArraySet;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_86
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_9e

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/vdocipher/aegis/core/j/a$b;

    .line 49
    iget-object v4, v1, Lcom/vdocipher/aegis/core/j/a$c;->b:Lcom/vdocipher/aegis/offline/DownloadRequest;

    iget-object v4, v4, Lcom/vdocipher/aegis/offline/DownloadRequest;->downloadSelections:Lcom/vdocipher/aegis/offline/DownloadSelections;

    iget-object v4, v4, Lcom/vdocipher/aegis/offline/DownloadSelections;->downloadOptions:Lcom/vdocipher/aegis/offline/DownloadOptions;

    iget-object v4, v4, Lcom/vdocipher/aegis/offline/DownloadOptions;->mediaId:Ljava/lang/String;

    invoke-interface {v3, v4, v0}, Lcom/vdocipher/aegis/core/j/a$b;->onFailed(Ljava/lang/String;Lcom/vdocipher/aegis/offline/DownloadStatus;)V

    goto :goto_86

    .line 51
    :cond_9e
    iget-object v2, v1, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/j/a;->e(Lcom/vdocipher/aegis/core/j/a;)Lcom/vdocipher/aegis/core/d/h;

    move-result-object v17

    iget-object v2, v1, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object v18

    iget-object v2, v1, Lcom/vdocipher/aegis/core/j/a$c;->d:Lcom/vdocipher/aegis/core/k/d;

    iget-object v3, v1, Lcom/vdocipher/aegis/core/j/a$c;->b:Lcom/vdocipher/aegis/offline/DownloadRequest;

    invoke-direct {v1}, Lcom/vdocipher/aegis/core/j/a$c;->a()Ljava/lang/String;

    move-result-object v23

    const-string v20, "downloadError"

    move-object/from16 v19, v0

    move-object/from16 v21, v2

    move-object/from16 v22, v3

    invoke-virtual/range {v17 .. v23}, Lcom/vdocipher/aegis/core/d/h;->a(Landroid/content/Context;Lcom/vdocipher/aegis/offline/DownloadStatus;Ljava/lang/String;Lcom/vdocipher/aegis/core/k/d;Lcom/vdocipher/aegis/offline/DownloadRequest;Ljava/lang/String;)V

    return-void
.end method

.method private a(ILandroid/content/Context;Ljava/lang/String;I)V
    .registers 7

    .line 3
    sget-object v0, Lcom/vdocipher/aegis/core/z/d;->a:Lcom/vdocipher/aegis/core/z/d;

    invoke-virtual {v0, p2, p3, p4}, Lcom/vdocipher/aegis/core/z/d;->a(Landroid/content/Context;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p3

    .line 4
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Error : "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const-string v0, "VdoDownloadManager"

    invoke-static {v0, p3}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    invoke-virtual {p2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p2

    invoke-virtual {p2, p4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p2

    const/4 p3, -0x1

    invoke-direct {p0, p1, p3, p2}, Lcom/vdocipher/aegis/core/j/a$c;->a(IILjava/lang/String;)V

    return-void
.end method

.method private a(Landroidx/media3/exoplayer/offline/DownloadHelper;Lcom/vdocipher/aegis/core/k/g;)V
    .registers 3

    .line 17
    iput-object p2, p0, Lcom/vdocipher/aegis/core/j/a$c;->f:Lcom/vdocipher/aegis/core/k/g;

    .line 19
    :try_start_2
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/j/a$c;->b(Landroidx/media3/exoplayer/offline/DownloadHelper;)V
    :try_end_5
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_5} :catch_6

    return-void

    :catch_6
    move-exception p1

    .line 21
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DownloadTracker"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/j/a$c;Landroidx/media3/exoplayer/offline/DownloadHelper;Lcom/vdocipher/aegis/core/k/g;)V
    .registers 3

    .line 2
    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/j/a$c;->a(Landroidx/media3/exoplayer/offline/DownloadHelper;Lcom/vdocipher/aegis/core/k/g;)V

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/j/a$c;Lcom/vdocipher/aegis/core/k/f;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/j/a$c;->a(Lcom/vdocipher/aegis/core/k/f;)V

    return-void
.end method

.method private a(Lcom/vdocipher/aegis/core/k/f;)V
    .registers 4

    .line 22
    const-string v0, "DownloadTracker"

    const-string v1, "Failed to fetch offline DRM license"

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 23
    iget v0, p1, Lcom/vdocipher/aegis/core/k/f;->a:I

    iget v1, p1, Lcom/vdocipher/aegis/core/k/f;->b:I

    iget-object p1, p1, Lcom/vdocipher/aegis/core/k/f;->c:Ljava/lang/String;

    invoke-direct {p0, v0, v1, p1}, Lcom/vdocipher/aegis/core/j/a$c;->a(IILjava/lang/String;)V

    return-void
.end method

.method private a(Landroidx/media3/common/DrmInitData;)Z
    .registers 5

    const/4 v0, 0x0

    if-nez p1, :cond_4

    return v0

    :cond_4
    move v1, v0

    .line 125
    :goto_5
    iget v2, p1, Landroidx/media3/common/DrmInitData;->schemeDataCount:I

    if-ge v1, v2, :cond_18

    .line 126
    invoke-virtual {p1, v1}, Landroidx/media3/common/DrmInitData;->get(I)Landroidx/media3/common/DrmInitData$SchemeData;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/media3/common/DrmInitData$SchemeData;->hasData()Z

    move-result v2

    if-eqz v2, :cond_15

    const/4 p1, 0x1

    return p1

    :cond_15
    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    :cond_18
    return v0
.end method

.method private b(Lcom/vdocipher/aegis/offline/DownloadRequest;)Ljava/lang/String;
    .registers 5

    .line 1
    iget-object p1, p1, Lcom/vdocipher/aegis/offline/DownloadRequest;->downloadSelections:Lcom/vdocipher/aegis/offline/DownloadSelections;

    iget-object p1, p1, Lcom/vdocipher/aegis/offline/DownloadSelections;->downloadOptions:Lcom/vdocipher/aegis/offline/DownloadOptions;

    check-cast p1, Lcom/vdocipher/aegis/core/k/a;

    .line 2
    iget-object v0, p1, Lcom/vdocipher/aegis/core/k/a;->c:Ljava/lang/String;

    if-nez v0, :cond_c

    const/4 p1, 0x0

    return-object p1

    .line 3
    :cond_c
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/b;->h(Landroid/content/Context;)Ljava/io/File;

    move-result-object v0

    .line 4
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    sget-object v0, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "posters"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/k/a;->c:Ljava/lang/String;

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-virtual {p1}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private b(Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    .line 5
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/b;->h(Landroid/content/Context;)Ljava/io/File;

    move-result-object v0

    .line 6
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    sget-object v0, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "scrubs"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-virtual {p1}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private b(Landroidx/media3/exoplayer/offline/DownloadHelper;)V
    .registers 12

    .line 7
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$c;->b:Lcom/vdocipher/aegis/offline/DownloadRequest;

    iget-object v1, v0, Lcom/vdocipher/aegis/offline/DownloadRequest;->downloadSelections:Lcom/vdocipher/aegis/offline/DownloadSelections;

    iget-object v1, v1, Lcom/vdocipher/aegis/offline/DownloadSelections;->downloadOptions:Lcom/vdocipher/aegis/offline/DownloadOptions;

    .line 9
    move-object v2, v1

    check-cast v2, Lcom/vdocipher/aegis/core/k/a;

    .line 11
    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/j/a$c;->b(Lcom/vdocipher/aegis/offline/DownloadRequest;)Ljava/lang/String;

    move-result-object v5

    .line 13
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/j/a$c;->a()Ljava/lang/String;

    move-result-object v6

    .line 15
    iget-object v0, v2, Lcom/vdocipher/aegis/core/k/a;->d:Ljava/lang/String;

    if-eqz v0, :cond_22

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_22

    iget-object v0, v2, Lcom/vdocipher/aegis/core/k/a;->d:Ljava/lang/String;

    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/j/a$c;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_23

    :cond_22
    const/4 v0, 0x0

    :goto_23
    move-object v9, v0

    .line 17
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 19
    iget-object v0, v2, Lcom/vdocipher/aegis/core/k/a;->i:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_2f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_48

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/vdocipher/aegis/media/Caption;

    .line 20
    invoke-direct {p0, v3}, Lcom/vdocipher/aegis/core/j/a$c;->a(Lcom/vdocipher/aegis/media/Caption;)Ljava/lang/String;

    move-result-object v4

    .line 21
    new-instance v8, Landroid/util/Pair;

    invoke-direct {v8, v4, v3}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v7, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2f

    .line 24
    :cond_48
    iget-object v4, p0, Lcom/vdocipher/aegis/core/j/a$c;->b:Lcom/vdocipher/aegis/offline/DownloadRequest;

    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/a;->f(Lcom/vdocipher/aegis/core/j/a;)Z

    move-result v8

    move-object v3, p0

    invoke-direct/range {v3 .. v9}, Lcom/vdocipher/aegis/core/j/a$c;->a(Lcom/vdocipher/aegis/offline/DownloadRequest;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZLjava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    .line 26
    invoke-virtual {p1}, Landroidx/media3/exoplayer/offline/DownloadHelper;->getPeriodCount()I

    move-result v4

    if-nez v4, :cond_68

    .line 27
    const-string v2, "DownloadTracker"

    const-string v4, "No periods found. Downloading entire stream."

    invoke-static {v2, v4}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 28
    iget-object v1, v1, Lcom/vdocipher/aegis/offline/DownloadOptions;->mediaId:Ljava/lang/String;

    invoke-direct {p0, p1, v1, v0}, Lcom/vdocipher/aegis/core/j/a$c;->b(Landroidx/media3/exoplayer/offline/DownloadHelper;Ljava/lang/String;Lorg/json/JSONObject;)V

    return-void

    .line 32
    :cond_68
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/j/a$c;->c(Landroidx/media3/exoplayer/offline/DownloadHelper;)V

    .line 34
    iget-object v4, v1, Lcom/vdocipher/aegis/offline/DownloadOptions;->mediaId:Ljava/lang/String;

    invoke-direct {p0, p1, v4, v0}, Lcom/vdocipher/aegis/core/j/a$c;->b(Landroidx/media3/exoplayer/offline/DownloadHelper;Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 36
    iget-object p1, v2, Lcom/vdocipher/aegis/core/k/a;->c:Ljava/lang/String;

    if-eqz p1, :cond_85

    if-eqz v5, :cond_85

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_85

    .line 37
    iget-object p1, v3, Lcom/vdocipher/aegis/core/j/a$c;->e:Lcom/vdocipher/aegis/core/j/c;

    iget-object v0, v2, Lcom/vdocipher/aegis/core/k/a;->c:Ljava/lang/String;

    iget-object v2, v1, Lcom/vdocipher/aegis/offline/DownloadOptions;->mediaId:Ljava/lang/String;

    invoke-virtual {p1, v0, v5, v2}, Lcom/vdocipher/aegis/core/j/c;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 44
    :cond_85
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/4 v0, 0x0

    :goto_8a
    if-ge v0, p1, :cond_a8

    invoke-virtual {v7, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    add-int/lit8 v0, v0, 0x1

    check-cast v2, Landroid/util/Pair;

    .line 45
    iget-object v4, v3, Lcom/vdocipher/aegis/core/j/a$c;->e:Lcom/vdocipher/aegis/core/j/c;

    iget-object v5, v2, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v5, Lcom/vdocipher/aegis/media/Caption;

    invoke-virtual {v5}, Lcom/vdocipher/aegis/media/Caption;->getUrl()Ljava/lang/String;

    move-result-object v5

    iget-object v2, v2, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    iget-object v6, v1, Lcom/vdocipher/aegis/offline/DownloadOptions;->mediaId:Ljava/lang/String;

    invoke-virtual {v4, v5, v2, v6}, Lcom/vdocipher/aegis/core/j/c;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_8a

    :cond_a8
    return-void
.end method

.method private b(Landroidx/media3/exoplayer/offline/DownloadHelper;Ljava/lang/String;Lorg/json/JSONObject;)V
    .registers 6

    .line 46
    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/j/a$c;->a(Landroidx/media3/exoplayer/offline/DownloadHelper;Ljava/lang/String;Lorg/json/JSONObject;)Landroidx/media3/exoplayer/offline/DownloadRequest;

    move-result-object p2

    .line 48
    :try_start_4
    iget-object p3, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {p3}, Lcom/vdocipher/aegis/core/j/a;->h(Lcom/vdocipher/aegis/core/j/a;)Z

    move-result p3

    .line 49
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    .line 50
    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object v0

    const-class v1, Lcom/vdocipher/aegis/offline/exoplayer/VdoDownloadService;

    .line 51
    invoke-static {v0, v1, p2, p3}, Landroidx/media3/exoplayer/offline/DownloadService;->sendAddDownload(Landroid/content/Context;Ljava/lang/Class;Landroidx/media3/exoplayer/offline/DownloadRequest;Z)V

    .line 53
    invoke-virtual {p1}, Landroidx/media3/exoplayer/offline/DownloadHelper;->release()V
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_18} :catch_19

    return-void

    :catch_19
    move-exception p1

    .line 55
    iget-object p2, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {p2}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object p2

    invoke-static {p2}, Lcom/vdocipher/aegis/core/k/c;->b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object p2

    const/4 p3, 0x0

    const/4 v0, 0x1

    invoke-virtual {p2, p1, p3, v0}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/Throwable;Ljava/lang/String;Z)V

    return-void
.end method

.method private c(Landroidx/media3/exoplayer/offline/DownloadHelper;)V
    .registers 12

    const/4 v0, 0x0

    .line 3
    invoke-virtual {p1, v0}, Landroidx/media3/exoplayer/offline/DownloadHelper;->clearTrackSelections(I)V

    .line 4
    iget-object v1, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/j/a;->g(Lcom/vdocipher/aegis/core/j/a;)Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters;->buildUpon()Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;

    move-result-object v1

    .line 6
    invoke-virtual {p1, v0}, Landroidx/media3/exoplayer/offline/DownloadHelper;->getTracks(I)Landroidx/media3/common/Tracks;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/media3/common/Tracks;->getGroups()Lcom/google/common/collect/ImmutableList;

    move-result-object v2

    .line 8
    iget-object v3, p0, Lcom/vdocipher/aegis/core/j/a$c;->b:Lcom/vdocipher/aegis/offline/DownloadRequest;

    iget-object v3, v3, Lcom/vdocipher/aegis/offline/DownloadRequest;->downloadSelections:Lcom/vdocipher/aegis/offline/DownloadSelections;

    iget-object v3, v3, Lcom/vdocipher/aegis/offline/DownloadSelections;->selectedTrackIndices:[I

    array-length v4, v3

    move v5, v0

    :goto_1e
    if-ge v5, v4, :cond_79

    aget v6, v3, v5

    .line 10
    iget-object v7, p0, Lcom/vdocipher/aegis/core/j/a$c;->b:Lcom/vdocipher/aegis/offline/DownloadRequest;

    iget-object v7, v7, Lcom/vdocipher/aegis/offline/DownloadRequest;->downloadSelections:Lcom/vdocipher/aegis/offline/DownloadSelections;

    iget-object v7, v7, Lcom/vdocipher/aegis/offline/DownloadSelections;->downloadOptions:Lcom/vdocipher/aegis/offline/DownloadOptions;

    iget-object v7, v7, Lcom/vdocipher/aegis/offline/DownloadOptions;->availableTracks:[Lcom/vdocipher/aegis/media/Track;

    aget-object v6, v7, v6

    .line 11
    iget v7, v6, Lcom/vdocipher/aegis/media/Track;->id:I

    invoke-static {v7}, Lcom/vdocipher/aegis/core/t/d;->c(I)I

    move-result v7

    .line 12
    iget v8, v6, Lcom/vdocipher/aegis/media/Track;->id:I

    invoke-static {v8}, Lcom/vdocipher/aegis/core/t/d;->d(I)I

    move-result v8

    if-ltz v7, :cond_5f

    if-gez v8, :cond_3d

    goto :goto_5f

    .line 20
    :cond_3d
    invoke-interface {v2, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroidx/media3/common/Tracks$Group;

    .line 24
    iget v6, v6, Lcom/vdocipher/aegis/media/Track;->type:I

    const/4 v9, 0x2

    if-ne v6, v9, :cond_49

    goto :goto_50

    :cond_49
    const/4 v9, 0x1

    if-ne v6, v9, :cond_4d

    goto :goto_50

    :cond_4d
    const/4 v9, 0x3

    if-ne v6, v9, :cond_5c

    .line 32
    :goto_50
    new-instance v6, Landroidx/media3/common/TrackSelectionOverride;

    invoke-virtual {v7}, Landroidx/media3/common/Tracks$Group;->getMediaTrackGroup()Landroidx/media3/common/TrackGroup;

    move-result-object v7

    invoke-direct {v6, v7, v8}, Landroidx/media3/common/TrackSelectionOverride;-><init>(Landroidx/media3/common/TrackGroup;I)V

    invoke-virtual {v1, v6}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;->addOverride(Landroidx/media3/common/TrackSelectionOverride;)Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;

    :cond_5c
    add-int/lit8 v5, v5, 0x1

    goto :goto_1e

    .line 33
    :cond_5f
    :goto_5f
    sget-object p1, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 34
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    .line 35
    const-string v1, "bad index + [%d, %d]"

    invoke-static {p1, v1, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "DownloadTracker"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 57
    :cond_79
    invoke-virtual {v1}, Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters$Builder;->build()Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Landroidx/media3/exoplayer/offline/DownloadHelper;->addTrackSelection(ILandroidx/media3/common/TrackSelectionParameters;)V

    return-void
.end method

.method private c(Ljava/lang/String;)Z
    .registers 5

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, p1, v1, v2}, Lcom/vdocipher/aegis/core/j/a;->a([Ljava/lang/String;[IZ)Ljava/util/List;

    move-result-object p1

    .line 2
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result p1

    xor-int/2addr p1, v2

    return p1
.end method


# virtual methods
.method public a(Ljava/lang/String;)V
    .registers 6

    .line 56
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/a;->a(Lcom/vdocipher/aegis/core/j/a;)Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_36

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    .line 57
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/media3/exoplayer/offline/Download;

    iget-object v3, v3, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    invoke-virtual {v3}, Landroidx/media3/exoplayer/offline/DownloadRequest;->toMediaItem()Landroidx/media3/common/MediaItem;

    move-result-object v3

    iget-object v3, v3, Landroidx/media3/common/MediaItem;->mediaId:Ljava/lang/String;

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_e

    .line 58
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/media3/exoplayer/offline/Download;

    goto :goto_37

    :cond_36
    move-object p1, v2

    :goto_37
    if-eqz p1, :cond_68

    .line 64
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/a;->b(Lcom/vdocipher/aegis/core/j/a;)Ljava/util/concurrent/CopyOnWriteArraySet;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_43
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_57

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/core/j/a$b;

    .line 65
    invoke-static {p1}, Lcom/vdocipher/aegis/offline/DownloadStatus;->getDownloadStatus(Landroidx/media3/exoplayer/offline/Download;)Lcom/vdocipher/aegis/offline/DownloadStatus;

    move-result-object v3

    invoke-interface {v1, v3, v2}, Lcom/vdocipher/aegis/core/j/a$b;->a(Lcom/vdocipher/aegis/offline/DownloadStatus;Ljava/lang/Exception;)V

    goto :goto_43

    .line 67
    :cond_57
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/a;->e(Lcom/vdocipher/aegis/core/j/a;)Lcom/vdocipher/aegis/core/d/h;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object v1

    const-string v3, "downloadChanged"

    invoke-virtual {v0, v1, p1, v3, v2}, Lcom/vdocipher/aegis/core/d/h;->a(Landroid/content/Context;Landroidx/media3/exoplayer/offline/Download;Ljava/lang/String;Lcom/vdocipher/aegis/offline/DownloadRequest;)V

    :cond_68
    return-void
.end method

.method public onPrepareError(Landroidx/media3/exoplayer/offline/DownloadHelper;Ljava/io/IOException;)V
    .registers 4

    .line 1
    instance-of p1, p2, Landroidx/media3/exoplayer/offline/DownloadHelper$LiveContentUnsupportedException;

    if-eqz p1, :cond_7

    .line 3
    const-string p1, "Downloading live content unsupported"

    goto :goto_9

    :cond_7
    const-string p1, "Failed to start download"

    .line 4
    :goto_9
    const-string p2, "DownloadTracker"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/16 p2, 0x3e9

    const/4 v0, -0x1

    .line 5
    invoke-direct {p0, p2, v0, p1}, Lcom/vdocipher/aegis/core/j/a$c;->a(IILjava/lang/String;)V

    return-void
.end method

.method public onPrepared(Landroidx/media3/exoplayer/offline/DownloadHelper;Z)V
    .registers 7

    .line 1
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/j/a$c;->a(Landroidx/media3/exoplayer/offline/DownloadHelper;)Landroidx/media3/common/Format;

    move-result-object p2

    const-string v0, "DownloadTracker"

    if-nez p2, :cond_15

    .line 4
    :try_start_8
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/j/a$c;->b(Landroidx/media3/exoplayer/offline/DownloadHelper;)V
    :try_end_b
    .catch Lorg/json/JSONException; {:try_start_8 .. :try_end_b} :catch_c

    return-void

    :catch_c
    move-exception p1

    .line 6
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 12
    :cond_15
    sget v1, Landroidx/media3/common/util/Util;->SDK_INT:I

    const/16 v2, 0x12

    if-ge v1, v2, :cond_21

    .line 13
    const-string p1, "Downloading DRM protected content is not supported on API versions below 18"

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    .line 18
    :cond_21
    iget-object p2, p2, Landroidx/media3/common/Format;->drmInitData:Landroidx/media3/common/DrmInitData;

    invoke-direct {p0, p2}, Lcom/vdocipher/aegis/core/j/a$c;->a(Landroidx/media3/common/DrmInitData;)Z

    move-result p2

    if-nez p2, :cond_2f

    .line 19
    const-string p1, "Downloading content where DRM scheme data is not located in the manifest is not supported"

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    .line 26
    :cond_2f
    :try_start_2f
    iget-object p2, p0, Lcom/vdocipher/aegis/core/j/a$c;->b:Lcom/vdocipher/aegis/offline/DownloadRequest;

    invoke-direct {p0, p2}, Lcom/vdocipher/aegis/core/j/a$c;->a(Lcom/vdocipher/aegis/offline/DownloadRequest;)Lcom/vdocipher/aegis/core/k/d;

    move-result-object p2

    iput-object p2, p0, Lcom/vdocipher/aegis/core/j/a$c;->d:Lcom/vdocipher/aegis/core/k/d;
    :try_end_37
    .catch Lorg/json/JSONException; {:try_start_2f .. :try_end_37} :catch_38

    goto :goto_40

    :catch_38
    move-exception p2

    .line 28
    invoke-static {p2}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p2

    invoke-static {v0, p2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 34
    :goto_40
    :try_start_40
    new-instance p2, Lcom/vdocipher/aegis/core/k/e;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/j/a$c;->d:Lcom/vdocipher/aegis/core/k/d;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/j/a$c;->b:Lcom/vdocipher/aegis/offline/DownloadRequest;

    iget-object v3, v2, Lcom/vdocipher/aegis/offline/DownloadRequest;->downloadSelections:Lcom/vdocipher/aegis/offline/DownloadSelections;

    iget-object v3, v3, Lcom/vdocipher/aegis/offline/DownloadSelections;->downloadOptions:Lcom/vdocipher/aegis/offline/DownloadOptions;

    iget-object v3, v3, Lcom/vdocipher/aegis/offline/DownloadOptions;->mediaId:Ljava/lang/String;

    iget-object v2, v2, Lcom/vdocipher/aegis/offline/DownloadRequest;->appGalleryAppId:Ljava/lang/String;

    invoke-direct {p2, v1, v3, v2}, Lcom/vdocipher/aegis/core/k/e;-><init>(Lcom/vdocipher/aegis/core/k/d;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p2}, Lcom/vdocipher/aegis/core/k/e;->c()Lcom/vdocipher/aegis/core/k/k;

    move-result-object p2
    :try_end_55
    .catch Lcom/vdocipher/aegis/core/f/d; {:try_start_40 .. :try_end_55} :catch_82
    .catch Lorg/json/JSONException; {:try_start_40 .. :try_end_55} :catch_80
    .catch Ljava/lang/NullPointerException; {:try_start_40 .. :try_end_55} :catch_7e

    .line 42
    iget-object v1, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/j/a;->f(Lcom/vdocipher/aegis/core/j/a;)Z

    move-result v1

    if-eqz v1, :cond_71

    .line 44
    new-instance v0, Lcom/vdocipher/aegis/core/j/a$d;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/j/a$c;->g:Lcom/vdocipher/aegis/core/j/a;

    .line 46
    invoke-static {v1}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1, p2, p0, p1}, Lcom/vdocipher/aegis/core/j/a$d;-><init>(Landroid/content/Context;Lcom/vdocipher/aegis/core/k/k;Lcom/vdocipher/aegis/core/j/a$c;Landroidx/media3/exoplayer/offline/DownloadHelper;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/j/a$c;->c:Lcom/vdocipher/aegis/core/j/a$d;

    const/4 p1, 0x0

    .line 50
    new-array p1, p1, [Ljava/lang/Void;

    invoke-virtual {v0, p1}, Landroid/os/AsyncTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    goto :goto_7d

    .line 54
    :cond_71
    :try_start_71
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/j/a$c;->b(Landroidx/media3/exoplayer/offline/DownloadHelper;)V
    :try_end_74
    .catch Lorg/json/JSONException; {:try_start_71 .. :try_end_74} :catch_75

    goto :goto_7d

    :catch_75
    move-exception p1

    .line 56
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :goto_7d
    return-void

    :catch_7e
    move-exception p1

    goto :goto_83

    :catch_80
    move-exception p1

    goto :goto_83

    :catch_82
    move-exception p1

    .line 57
    :goto_83
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p2

    invoke-static {v0, p2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 58
    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Invalid spec: "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 p2, 0x3ed

    const/4 v0, -0x1

    invoke-direct {p0, p2, v0, p1}, Lcom/vdocipher/aegis/core/j/a$c;->a(IILjava/lang/String;)V

    return-void
.end method
