# classes14.dex

.class public Lcom/vdocipher/aegis/core/j/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/core/j/a$c;,
        Lcom/vdocipher/aegis/core/j/a$b;,
        Lcom/vdocipher/aegis/core/j/a$d;
    }
.end annotation


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Lcom/vdocipher/aegis/core/z/f$a;

.field private final c:Ljava/util/concurrent/CopyOnWriteArraySet;

.field private final d:Ljava/util/concurrent/ConcurrentHashMap;

.field private final e:Landroidx/media3/exoplayer/offline/DownloadIndex;

.field private final f:Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters;

.field private g:Z

.field private final h:Landroid/os/Handler;

.field private final i:Lcom/vdocipher/aegis/core/d/h;

.field private j:Z

.field private k:Ljava/lang/Class;

.field private l:Lcom/vdocipher/aegis/core/j/a$c;

.field private final m:Landroidx/media3/exoplayer/offline/DownloadManager$Listener;


# direct methods
.method public static synthetic $r8$lambda$K47VWpJk5QffYc8oZfqqKtarvYQ(Lcom/vdocipher/aegis/core/j/a;Landroidx/media3/exoplayer/offline/Download;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/j/a;->a(Landroidx/media3/exoplayer/offline/Download;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$WZCIR3hZaSTeaPafdO1sRLBTltk(Lcom/vdocipher/aegis/core/j/a;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/aegis/core/j/a;->f()V

    return-void
.end method

.method public static synthetic $r8$lambda$XLeua08Op4LlN-Ih2ucodsvUO34(Lcom/vdocipher/aegis/core/j/a;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/aegis/core/j/a;->c()V

    return-void
.end method

.method protected constructor <init>(Landroid/content/Context;Lcom/vdocipher/aegis/core/z/f$a;Landroidx/media3/exoplayer/offline/DownloadManager;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/j/a;->j:Z

    .line 10
    new-instance v0, Lcom/vdocipher/aegis/core/j/a$a;

    invoke-direct {v0, p0}, Lcom/vdocipher/aegis/core/j/a$a;-><init>(Lcom/vdocipher/aegis/core/j/a;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->m:Landroidx/media3/exoplayer/offline/DownloadManager$Listener;

    .line 37
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    iput-object v1, p0, Lcom/vdocipher/aegis/core/j/a;->a:Landroid/content/Context;

    .line 38
    iput-object p2, p0, Lcom/vdocipher/aegis/core/j/a;->b:Lcom/vdocipher/aegis/core/z/f$a;

    .line 39
    new-instance p2, Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-direct {p2}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>()V

    iput-object p2, p0, Lcom/vdocipher/aegis/core/j/a;->c:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 40
    new-instance p2, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {p2}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object p2, p0, Lcom/vdocipher/aegis/core/j/a;->d:Ljava/util/concurrent/ConcurrentHashMap;

    .line 41
    invoke-virtual {p3}, Landroidx/media3/exoplayer/offline/DownloadManager;->getDownloadIndex()Landroidx/media3/exoplayer/offline/DownloadIndex;

    move-result-object p2

    iput-object p2, p0, Lcom/vdocipher/aegis/core/j/a;->e:Landroidx/media3/exoplayer/offline/DownloadIndex;

    .line 42
    invoke-static {p1}, Landroidx/media3/exoplayer/offline/DownloadHelper;->getDefaultTrackSelectorParameters(Landroid/content/Context;)Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/j/a;->f:Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters;

    .line 43
    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p2

    invoke-direct {p1, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/j/a;->h:Landroid/os/Handler;

    .line 44
    invoke-static {}, Lcom/vdocipher/aegis/core/d/h;->a()Lcom/vdocipher/aegis/core/d/h;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/j/a;->i:Lcom/vdocipher/aegis/core/d/h;

    .line 45
    invoke-virtual {p3, v0}, Landroidx/media3/exoplayer/offline/DownloadManager;->addListener(Landroidx/media3/exoplayer/offline/DownloadManager$Listener;)V

    .line 46
    new-instance p1, Lcom/vdocipher/aegis/core/j/a$$ExternalSyntheticLambda2;

    invoke-direct {p1, p0}, Lcom/vdocipher/aegis/core/j/a$$ExternalSyntheticLambda2;-><init>(Lcom/vdocipher/aegis/core/j/a;)V

    invoke-static {p1}, Landroid/os/AsyncTask;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method private static a(Landroid/content/Context;)Landroid/util/Pair;
    .registers 4

    .line 2
    const-string v0, "activity"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/ActivityManager;

    const v0, 0x7fffffff

    .line 3
    invoke-virtual {p0, v0}, Landroid/app/ActivityManager;->getRunningServices(I)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_13
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_47

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/ActivityManager$RunningServiceInfo;

    .line 4
    const-class v1, Lcom/vdocipher/aegis/offline/exoplayer/VdoDownloadService;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    iget-object v2, v0, Landroid/app/ActivityManager$RunningServiceInfo;->service:Landroid/content/ComponentName;

    invoke-virtual {v2}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_13

    .line 6
    iget-boolean p0, v0, Landroid/app/ActivityManager$RunningServiceInfo;->foreground:Z

    if-eqz p0, :cond_3d

    .line 7
    new-instance p0, Landroid/util/Pair;

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-direct {p0, v0, v0}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object p0

    .line 9
    :cond_3d
    new-instance p0, Landroid/util/Pair;

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-direct {p0, v0, v1}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object p0

    .line 13
    :cond_47
    new-instance p0, Landroid/util/Pair;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-direct {p0, v0, v0}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object p0
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/j/a;)Ljava/util/concurrent/ConcurrentHashMap;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/j/a;->d:Ljava/util/concurrent/ConcurrentHashMap;

    return-object p0
.end method

.method private a([I)Ljava/util/concurrent/ConcurrentHashMap;
    .registers 9

    .line 39
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    if-eqz p1, :cond_40

    .line 40
    array-length v1, p1

    if-lez v1, :cond_40

    .line 41
    array-length v1, p1

    const/4 v2, 0x0

    :goto_c
    if-ge v2, v1, :cond_3f

    aget v3, p1, v2

    .line 42
    iget-object v4, p0, Lcom/vdocipher/aegis/core/j/a;->d:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v4}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_1a
    :goto_1a
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_3c

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/Map$Entry;

    .line 43
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/media3/exoplayer/offline/Download;

    .line 44
    invoke-static {v5}, Lcom/vdocipher/aegis/offline/DownloadStatus;->getDownloadStatus(Landroidx/media3/exoplayer/offline/Download;)Lcom/vdocipher/aegis/offline/DownloadStatus;

    move-result-object v6

    .line 45
    iget v6, v6, Lcom/vdocipher/aegis/offline/DownloadStatus;->status:I

    if-ne v6, v3, :cond_1a

    .line 46
    iget-object v6, v5, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    iget-object v6, v6, Landroidx/media3/exoplayer/offline/DownloadRequest;->uri:Landroid/net/Uri;

    invoke-virtual {v0, v6, v5}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1a

    :cond_3c
    add-int/lit8 v2, v2, 0x1

    goto :goto_c

    :cond_3f
    return-object v0

    .line 51
    :cond_40
    iget-object p1, p0, Lcom/vdocipher/aegis/core/j/a;->d:Ljava/util/concurrent/ConcurrentHashMap;

    return-object p1
.end method

.method private synthetic a(Landroidx/media3/exoplayer/offline/Download;Ljava/lang/String;)V
    .registers 4

    .line 91
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->a:Landroid/content/Context;

    iget-object p1, p1, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/j/b;->a(Landroid/content/Context;Landroidx/media3/exoplayer/offline/DownloadRequest;)Landroidx/media3/exoplayer/offline/DownloadManager;

    move-result-object p1

    .line 92
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->m:Landroidx/media3/exoplayer/offline/DownloadManager$Listener;

    invoke-virtual {p1, v0}, Landroidx/media3/exoplayer/offline/DownloadManager;->addListener(Landroidx/media3/exoplayer/offline/DownloadManager$Listener;)V

    .line 93
    invoke-virtual {p1, p2}, Landroidx/media3/exoplayer/offline/DownloadManager;->removeDownload(Ljava/lang/String;)V

    return-void
.end method

.method private a()Z
    .registers 4

    .line 14
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/a;->a(Landroid/content/Context;)Landroid/util/Pair;

    move-result-object v0

    .line 15
    iget-object v1, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    .line 16
    iget-object v0, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 17
    sget-object v2, Lcom/vdocipher/aegis/core/z/d;->a:Lcom/vdocipher/aegis/core/z/d;

    invoke-virtual {v2}, Lcom/vdocipher/aegis/core/z/d;->d()Z

    move-result v2

    if-nez v1, :cond_1f

    return v2

    :cond_1f
    return v0
.end method

.method static synthetic b(Lcom/vdocipher/aegis/core/j/a;)Ljava/util/concurrent/CopyOnWriteArraySet;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/j/a;->c:Ljava/util/concurrent/CopyOnWriteArraySet;

    return-object p0
.end method

.method static synthetic c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/j/a;->a:Landroid/content/Context;

    return-object p0
.end method

.method private c()V
    .registers 5

    .line 2
    :try_start_0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->e:Landroidx/media3/exoplayer/offline/DownloadIndex;

    const/4 v1, 0x0

    new-array v1, v1, [I

    invoke-interface {v0, v1}, Landroidx/media3/exoplayer/offline/DownloadIndex;->getDownloads([I)Landroidx/media3/exoplayer/offline/DownloadCursor;

    move-result-object v0
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_9} :catch_2d

    .line 3
    :goto_9
    :try_start_9
    invoke-interface {v0}, Landroidx/media3/exoplayer/offline/DownloadCursor;->moveToNext()Z

    move-result v1

    if-eqz v1, :cond_1d

    .line 4
    invoke-interface {v0}, Landroidx/media3/exoplayer/offline/DownloadCursor;->getDownload()Landroidx/media3/exoplayer/offline/Download;

    move-result-object v1

    .line 5
    iget-object v2, p0, Lcom/vdocipher/aegis/core/j/a;->d:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v3, v1, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    iget-object v3, v3, Landroidx/media3/exoplayer/offline/DownloadRequest;->uri:Landroid/net/Uri;

    invoke-virtual {v2, v3, v1}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1c
    .catchall {:try_start_9 .. :try_end_1c} :catchall_21

    goto :goto_9

    .line 7
    :cond_1d
    :try_start_1d
    invoke-interface {v0}, Landroidx/media3/exoplayer/offline/DownloadCursor;->close()V
    :try_end_20
    .catch Ljava/io/IOException; {:try_start_1d .. :try_end_20} :catch_2d

    return-void

    :catchall_21
    move-exception v1

    if-eqz v0, :cond_2c

    .line 8
    :try_start_24
    invoke-interface {v0}, Landroidx/media3/exoplayer/offline/DownloadCursor;->close()V
    :try_end_27
    .catchall {:try_start_24 .. :try_end_27} :catchall_28

    goto :goto_2c

    :catchall_28
    move-exception v0

    :try_start_29
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_2c
    :goto_2c
    throw v1
    :try_end_2d
    .catch Ljava/io/IOException; {:try_start_29 .. :try_end_2d} :catch_2d

    :catch_2d
    move-exception v0

    .line 14
    const-string v1, "DownloadTracker"

    const-string v2, "Failed to refresh downloads"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-void
.end method

.method private c(Ljava/lang/String;)V
    .registers 8

    const-string v0, "DownloadTracker"

    .line 15
    iget-object v1, p0, Lcom/vdocipher/aegis/core/j/a;->d:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_c
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_96

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    .line 16
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/media3/exoplayer/offline/Download;

    iget-object v2, v2, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    .line 17
    invoke-virtual {v2}, Landroidx/media3/exoplayer/offline/DownloadRequest;->toMediaItem()Landroidx/media3/common/MediaItem;

    move-result-object v3

    iget-object v3, v3, Landroidx/media3/common/MediaItem;->mediaId:Ljava/lang/String;

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_c

    .line 19
    :try_start_2c
    new-instance v1, Lorg/json/JSONObject;

    new-instance v3, Ljava/lang/String;

    iget-object v4, v2, Landroidx/media3/exoplayer/offline/DownloadRequest;->data:[B

    sget-object v5, Lcom/google/common/base/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v3, v4, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v1, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 20
    new-instance v3, Ljava/io/File;

    const-string v4, "posterPath"

    invoke-virtual {v1, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v3, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    move-result v1

    if-eqz v1, :cond_61

    .line 22
    const-string v1, "Poster for mediaId %s is deleted"

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object v3

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_58
    .catch Lorg/json/JSONException; {:try_start_2c .. :try_end_58} :catch_59

    goto :goto_61

    :catch_59
    move-exception v1

    .line 24
    invoke-static {v1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 26
    :cond_61
    :goto_61
    invoke-static {v2}, Lcom/vdocipher/aegis/core/j/b;->b(Landroidx/media3/exoplayer/offline/DownloadRequest;)Ljava/util/List;

    move-result-object v1

    .line 27
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_69
    :goto_69
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_96

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 28
    new-instance v3, Ljava/io/File;

    invoke-direct {v3, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    move-result v3

    if-eqz v3, :cond_69

    .line 30
    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v2}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object v2

    filled-new-array {v2, p1}, [Ljava/lang/Object;

    move-result-object v2

    const-string v3, "Caption %s for mediaId %s is deleted"

    invoke-static {v3, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_69

    :cond_96
    return-void
.end method

.method static synthetic d(Lcom/vdocipher/aegis/core/j/a;)Lcom/vdocipher/aegis/core/j/a$c;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/j/a;->l:Lcom/vdocipher/aegis/core/j/a$c;

    return-object p0
.end method

.method private d()V
    .registers 2

    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/j/a;->g:Z

    .line 3
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/j/a;->f()V

    return-void
.end method

.method static synthetic e(Lcom/vdocipher/aegis/core/j/a;)Lcom/vdocipher/aegis/core/d/h;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/j/a;->i:Lcom/vdocipher/aegis/core/d/h;

    return-object p0
.end method

.method private e()V
    .registers 3

    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/j/a;->g:Z

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->h:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    return-void
.end method

.method private f()V
    .registers 7

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/b;->i(Landroid/content/Context;)Landroidx/media3/exoplayer/offline/DownloadManager;

    move-result-object v0

    invoke-static {v0}, Landroidx/media3/common/util/Assertions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/media3/exoplayer/offline/DownloadManager;

    invoke-virtual {v0}, Landroidx/media3/exoplayer/offline/DownloadManager;->getCurrentDownloads()Ljava/util/List;

    move-result-object v0

    .line 4
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_14
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_3b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/media3/exoplayer/offline/Download;

    .line 5
    iget-object v3, p0, Lcom/vdocipher/aegis/core/j/a;->c:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v3}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_27
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_14

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/vdocipher/aegis/core/j/a$b;

    .line 6
    invoke-static {v1}, Lcom/vdocipher/aegis/offline/DownloadStatus;->getDownloadStatus(Landroidx/media3/exoplayer/offline/Download;)Lcom/vdocipher/aegis/offline/DownloadStatus;

    move-result-object v5

    invoke-interface {v4, v5, v2}, Lcom/vdocipher/aegis/core/j/a$b;->a(Lcom/vdocipher/aegis/offline/DownloadStatus;Ljava/lang/Exception;)V

    goto :goto_27

    .line 9
    :cond_3b
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/j/a;->g:Z

    if-eqz v0, :cond_50

    .line 10
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->h:Landroid/os/Handler;

    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 11
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->h:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/j/a$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lcom/vdocipher/aegis/core/j/a$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/core/j/a;)V

    const-wide/16 v2, 0x3e8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_50
    return-void
.end method

.method static synthetic f(Lcom/vdocipher/aegis/core/j/a;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcom/vdocipher/aegis/core/j/a;->j:Z

    return p0
.end method

.method static synthetic g(Lcom/vdocipher/aegis/core/j/a;)Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/j/a;->f:Landroidx/media3/exoplayer/trackselection/DefaultTrackSelector$Parameters;

    return-object p0
.end method

.method static synthetic h(Lcom/vdocipher/aegis/core/j/a;)Z
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/j/a;->a()Z

    move-result p0

    return p0
.end method


# virtual methods
.method public a(Ljava/lang/String;)Landroidx/media3/exoplayer/offline/Download;
    .registers 3

    .line 38
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->e:Landroidx/media3/exoplayer/offline/DownloadIndex;

    invoke-interface {v0, p1}, Landroidx/media3/exoplayer/offline/DownloadIndex;->getDownload(Ljava/lang/String;)Landroidx/media3/exoplayer/offline/Download;

    move-result-object p1

    return-object p1
.end method

.method public a([Ljava/lang/String;[I)Ljava/util/List;
    .registers 8

    .line 73
    invoke-direct {p0, p2}, Lcom/vdocipher/aegis/core/j/a;->a([I)Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object p2

    .line 75
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 76
    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    .line 77
    invoke-virtual {p2}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_16
    :goto_16
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_47

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    .line 78
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/media3/exoplayer/offline/Download;

    .line 79
    invoke-static {v2}, Lcom/vdocipher/aegis/offline/DownloadStatus;->getDownloadStatus(Landroidx/media3/exoplayer/offline/Download;)Lcom/vdocipher/aegis/offline/DownloadStatus;

    move-result-object v2

    if-eqz p1, :cond_3c

    .line 81
    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    iget-object v4, v2, Lcom/vdocipher/aegis/offline/DownloadStatus;->mediaInfo:Lcom/vdocipher/aegis/media/MediaInfo;

    iget-object v4, v4, Lcom/vdocipher/aegis/media/MediaInfo;->mediaId:Ljava/lang/String;

    invoke-interface {v3, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_16

    .line 82
    :cond_3c
    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 83
    iget-object v2, v2, Lcom/vdocipher/aegis/offline/DownloadStatus;->mediaInfo:Lcom/vdocipher/aegis/media/MediaInfo;

    iget-object v2, v2, Lcom/vdocipher/aegis/media/MediaInfo;->mediaId:Ljava/lang/String;

    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_16

    .line 88
    :cond_47
    iget-object p1, p0, Lcom/vdocipher/aegis/core/j/a;->c:Ljava/util/concurrent/CopyOnWriteArraySet;

    if-eqz p1, :cond_5f

    .line 89
    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_4f
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_5f

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/aegis/core/j/a$b;

    .line 90
    invoke-interface {p2, v1}, Lcom/vdocipher/aegis/core/j/a$b;->a(Ljava/util/Set;)V

    goto :goto_4f

    :cond_5f
    return-object v0
.end method

.method public a([Ljava/lang/String;[IZ)Ljava/util/List;
    .registers 9

    .line 52
    invoke-direct {p0, p2}, Lcom/vdocipher/aegis/core/j/a;->a([I)Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object p2

    .line 54
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 55
    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    .line 56
    invoke-virtual {p2}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_16
    :goto_16
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4c

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    .line 57
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/media3/exoplayer/offline/Download;

    .line 58
    invoke-static {v2}, Lcom/vdocipher/aegis/offline/DownloadStatus;->getDownloadStatus(Landroidx/media3/exoplayer/offline/Download;)Lcom/vdocipher/aegis/offline/DownloadStatus;

    move-result-object v2

    .line 60
    iget-boolean v3, v2, Lcom/vdocipher/aegis/offline/DownloadStatus;->isSavedOffline:Z

    if-eq v3, p3, :cond_31

    goto :goto_16

    :cond_31
    if-eqz p1, :cond_41

    .line 63
    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    iget-object v4, v2, Lcom/vdocipher/aegis/offline/DownloadStatus;->mediaInfo:Lcom/vdocipher/aegis/media/MediaInfo;

    iget-object v4, v4, Lcom/vdocipher/aegis/media/MediaInfo;->mediaId:Ljava/lang/String;

    invoke-interface {v3, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_16

    .line 64
    :cond_41
    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 65
    iget-object v2, v2, Lcom/vdocipher/aegis/offline/DownloadStatus;->mediaInfo:Lcom/vdocipher/aegis/media/MediaInfo;

    iget-object v2, v2, Lcom/vdocipher/aegis/media/MediaInfo;->mediaId:Ljava/lang/String;

    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_16

    .line 70
    :cond_4c
    iget-object p1, p0, Lcom/vdocipher/aegis/core/j/a;->c:Ljava/util/concurrent/CopyOnWriteArraySet;

    if-eqz p1, :cond_64

    .line 71
    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_54
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_64

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/aegis/core/j/a$b;

    .line 72
    invoke-interface {p2, v1}, Lcom/vdocipher/aegis/core/j/a$b;->a(Ljava/util/Set;)V

    goto :goto_54

    :cond_64
    return-object v0
.end method

.method public a(Landroidx/media3/common/MediaItem;Landroidx/media3/exoplayer/RenderersFactory;Lcom/vdocipher/aegis/offline/DownloadRequest;Z)V
    .registers 7

    .line 23
    iput-boolean p4, p0, Lcom/vdocipher/aegis/core/j/a;->j:Z

    .line 25
    iget-object p4, p0, Lcom/vdocipher/aegis/core/j/a;->d:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v0, p1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    iget-object v0, v0, Landroidx/media3/common/MediaItem$LocalConfiguration;->uri:Landroid/net/Uri;

    invoke-virtual {p4, v0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Landroidx/media3/exoplayer/offline/Download;

    if-eqz p4, :cond_27

    .line 27
    iget v0, p4, Landroidx/media3/exoplayer/offline/Download;->state:I

    const/4 v1, 0x4

    if-eq v0, v1, :cond_27

    .line 29
    :try_start_15
    iget-object p4, p4, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    iget-object p4, p4, Landroidx/media3/exoplayer/offline/DownloadRequest;->id:Ljava/lang/String;

    invoke-virtual {p0, p4}, Lcom/vdocipher/aegis/core/j/a;->b(Ljava/lang/String;)V
    :try_end_1c
    .catch Ljava/io/IOException; {:try_start_15 .. :try_end_1c} :catch_1d

    goto :goto_27

    :catch_1d
    move-exception p4

    .line 31
    invoke-static {p4}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p4

    const-string v0, "DownloadTracker"

    invoke-static {v0, p4}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 35
    :cond_27
    :goto_27
    new-instance p4, Lcom/vdocipher/aegis/core/j/a$c;

    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->a:Landroid/content/Context;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/j/a;->b:Lcom/vdocipher/aegis/core/z/f$a;

    .line 37
    invoke-static {v0, p1, p2, v1}, Landroidx/media3/exoplayer/offline/DownloadHelper;->forMediaItem(Landroid/content/Context;Landroidx/media3/common/MediaItem;Landroidx/media3/exoplayer/RenderersFactory;Landroidx/media3/datasource/DataSource$Factory;)Landroidx/media3/exoplayer/offline/DownloadHelper;

    move-result-object p1

    invoke-direct {p4, p0, p1, p3}, Lcom/vdocipher/aegis/core/j/a$c;-><init>(Lcom/vdocipher/aegis/core/j/a;Landroidx/media3/exoplayer/offline/DownloadHelper;Lcom/vdocipher/aegis/offline/DownloadRequest;)V

    iput-object p4, p0, Lcom/vdocipher/aegis/core/j/a;->l:Lcom/vdocipher/aegis/core/j/a$c;

    return-void
.end method

.method public a(Lcom/vdocipher/aegis/core/j/a$b;)V
    .registers 3

    .line 18
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 19
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->c:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/CopyOnWriteArraySet;->add(Ljava/lang/Object;)Z

    .line 20
    iget-boolean p1, p0, Lcom/vdocipher/aegis/core/j/a;->g:Z

    if-nez p1, :cond_f

    .line 21
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/j/a;->d()V

    :cond_f
    return-void
.end method

.method public a(Ljava/lang/Class;)V
    .registers 2

    .line 22
    iput-object p1, p0, Lcom/vdocipher/aegis/core/j/a;->k:Ljava/lang/Class;

    return-void
.end method

.method public b()Ljava/lang/Class;
    .registers 2

    .line 5
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->k:Ljava/lang/Class;

    return-object v0
.end method

.method public b(Lcom/vdocipher/aegis/core/j/a$b;)V
    .registers 3

    if-eqz p1, :cond_7

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->c:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/CopyOnWriteArraySet;->remove(Ljava/lang/Object;)Z

    .line 3
    :cond_7
    iget-boolean p1, p0, Lcom/vdocipher/aegis/core/j/a;->g:Z

    if-eqz p1, :cond_16

    iget-object p1, p0, Lcom/vdocipher/aegis/core/j/a;->c:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArraySet;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_16

    .line 4
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/j/a;->e()V

    :cond_16
    return-void
.end method

.method public b(Ljava/lang/String;)V
    .registers 5

    .line 6
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/j/a;->c(Ljava/lang/String;)V

    .line 8
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/j/a;->a(Ljava/lang/String;)Landroidx/media3/exoplayer/offline/Download;

    move-result-object v0

    if-nez v0, :cond_a

    return-void

    .line 13
    :cond_a
    invoke-static {v0}, Lcom/vdocipher/aegis/offline/DownloadStatus;->getDownloadStatus(Landroidx/media3/exoplayer/offline/Download;)Lcom/vdocipher/aegis/offline/DownloadStatus;

    move-result-object v1

    .line 15
    iget-object v1, v1, Lcom/vdocipher/aegis/offline/DownloadStatus;->localStorageFolder:Ljava/lang/String;

    if-eqz v1, :cond_2c

    iget-object v2, p0, Lcom/vdocipher/aegis/core/j/a;->a:Landroid/content/Context;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/j/b;->h(Landroid/content/Context;)Ljava/io/File;

    move-result-object v2

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_2c

    .line 17
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/b;->i(Landroid/content/Context;)Landroidx/media3/exoplayer/offline/DownloadManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroidx/media3/exoplayer/offline/DownloadManager;->removeDownload(Ljava/lang/String;)V

    return-void

    .line 22
    :cond_2c
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v2, Lcom/vdocipher/aegis/core/j/a$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0, v0, p1}, Lcom/vdocipher/aegis/core/j/a$$ExternalSyntheticLambda1;-><init>(Lcom/vdocipher/aegis/core/j/a;Landroidx/media3/exoplayer/offline/Download;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public d(Ljava/lang/String;)V
    .registers 6

    .line 4
    :try_start_0
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/j/a;->a()Z

    move-result v0

    .line 5
    iget-object v1, p0, Lcom/vdocipher/aegis/core/j/a;->a:Landroid/content/Context;

    const-class v2, Lcom/vdocipher/aegis/offline/exoplayer/VdoDownloadService;

    const/4 v3, 0x0

    invoke-static {v1, v2, p1, v3, v0}, Landroidx/media3/exoplayer/offline/DownloadService;->sendSetStopReason(Landroid/content/Context;Ljava/lang/Class;Ljava/lang/String;IZ)V
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_c} :catch_d

    return-void

    :catch_d
    move-exception p1

    .line 7
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/k/c;->b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, p1, v1, v2}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/Throwable;Ljava/lang/String;Z)V

    return-void
.end method

.method public e(Ljava/lang/String;)V
    .registers 6

    const/4 v0, 0x1

    .line 4
    :try_start_1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/j/a;->a()Z

    move-result v1

    .line 5
    iget-object v2, p0, Lcom/vdocipher/aegis/core/j/a;->a:Landroid/content/Context;

    const-class v3, Lcom/vdocipher/aegis/offline/exoplayer/VdoDownloadService;

    invoke-static {v2, v3, p1, v0, v1}, Landroidx/media3/exoplayer/offline/DownloadService;->sendSetStopReason(Landroid/content/Context;Ljava/lang/Class;Ljava/lang/String;IZ)V
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_c} :catch_d

    return-void

    :catch_d
    move-exception p1

    .line 7
    iget-object v1, p0, Lcom/vdocipher/aegis/core/j/a;->a:Landroid/content/Context;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/k/c;->b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v1, p1, v2, v0}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/Throwable;Ljava/lang/String;Z)V

    return-void
.end method
