# classes14.dex

.class public Lcom/vdocipher/aegis/core/j/c$b;
.super Landroid/os/AsyncTask;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/j/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "b"
.end annotation


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/lang/String;

.field private final c:Ljava/lang/String;

.field final synthetic d:Lcom/vdocipher/aegis/core/j/c;


# direct methods
.method public constructor <init>(Lcom/vdocipher/aegis/core/j/c;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/j/c$b;->d:Lcom/vdocipher/aegis/core/j/c;

    .line 2
    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/j/c$b;->a:Ljava/lang/String;

    .line 4
    iput-object p3, p0, Lcom/vdocipher/aegis/core/j/c$b;->b:Ljava/lang/String;

    .line 5
    iput-object p4, p0, Lcom/vdocipher/aegis/core/j/c$b;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 1
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/j/c$b;->doInBackground([Ljava/lang/Void;)Ljava/lang/Void;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/Void;
    .registers 11

    .line 2
    const-string p1, ".tmp"

    const-string v0, "FileDownloadHelper"

    const/4 v1, 0x0

    :try_start_5
    new-instance v2, Ljava/net/URL;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/j/c$b;->a:Ljava/lang/String;

    invoke-direct {v2, v3}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_c
    .catch Ljava/net/MalformedURLException; {:try_start_5 .. :try_end_c} :catch_e5

    .line 8
    :try_start_c
    invoke-virtual {v2}, Ljava/net/URL;->openStream()Ljava/io/InputStream;

    move-result-object v2
    :try_end_10
    .catch Ljava/io/IOException; {:try_start_c .. :try_end_10} :catch_ce
    .catch Ljava/lang/SecurityException; {:try_start_c .. :try_end_10} :catch_c7

    .line 10
    :try_start_10
    new-instance v3, Ljava/io/DataInputStream;

    invoke-direct {v3, v2}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_15
    .catchall {:try_start_10 .. :try_end_15} :catchall_bb

    const/16 v4, 0x400

    .line 12
    :try_start_17
    new-array v4, v4, [B

    .line 15
    new-instance v5, Ljava/io/File;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v7, p0, Lcom/vdocipher/aegis/core/j/c$b;->b:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 16
    invoke-virtual {v5}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v6

    invoke-static {v6}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/io/File;

    invoke-virtual {v6}, Ljava/io/File;->exists()Z

    move-result v6

    if-nez v6, :cond_4e

    .line 17
    invoke-virtual {v5}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v6

    invoke-virtual {v6}, Ljava/io/File;->mkdirs()Z

    move-result v6

    if-nez v6, :cond_4e

    .line 19
    const-string v6, "Failed to create parent directories"

    invoke-static {v0, v6}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 21
    :cond_4e
    invoke-virtual {v5}, Ljava/io/File;->createNewFile()Z

    move-result v6

    if-nez v6, :cond_59

    .line 23
    const-string v6, "Failed to create file"

    invoke-static {v0, v6}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 24
    :cond_59
    new-instance v6, Ljava/io/FileOutputStream;

    invoke-direct {v6, v5}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_5e
    .catchall {:try_start_17 .. :try_end_5e} :catchall_b1

    .line 25
    :goto_5e
    :try_start_5e
    invoke-virtual {v3, v4}, Ljava/io/DataInputStream;->read([B)I

    move-result v7

    const/4 v8, 0x0

    if-lez v7, :cond_69

    .line 26
    invoke-virtual {v6, v4, v8, v7}, Ljava/io/FileOutputStream;->write([BII)V
    :try_end_68
    .catchall {:try_start_5e .. :try_end_68} :catchall_a7

    goto :goto_5e

    .line 28
    :cond_69
    :try_start_69
    invoke-virtual {v6}, Ljava/io/FileOutputStream;->close()V

    .line 29
    invoke-virtual {v5}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v4

    .line 30
    invoke-virtual {v4, p1}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result p1

    invoke-virtual {v4, v8, p1}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object p1

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    .line 31
    new-instance v5, Ljava/io/File;

    invoke-direct {v5, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 32
    new-instance v4, Ljava/io/File;

    invoke-direct {v4, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 33
    invoke-virtual {v5, v4}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result p1

    .line 34
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "file renamed: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_9e
    .catchall {:try_start_69 .. :try_end_9e} :catchall_b1

    .line 35
    :try_start_9e
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V
    :try_end_a1
    .catchall {:try_start_9e .. :try_end_a1} :catchall_bb

    if-eqz v2, :cond_e4

    :try_start_a3
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V
    :try_end_a6
    .catch Ljava/io/IOException; {:try_start_a3 .. :try_end_a6} :catch_ce
    .catch Ljava/lang/SecurityException; {:try_start_a3 .. :try_end_a6} :catch_c7

    goto :goto_e4

    :catchall_a7
    move-exception p1

    .line 36
    :try_start_a8
    invoke-virtual {v6}, Ljava/io/FileOutputStream;->close()V
    :try_end_ab
    .catchall {:try_start_a8 .. :try_end_ab} :catchall_ac

    goto :goto_b0

    :catchall_ac
    move-exception v4

    :try_start_ad
    invoke-virtual {p1, v4}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_b0
    throw p1
    :try_end_b1
    .catchall {:try_start_ad .. :try_end_b1} :catchall_b1

    :catchall_b1
    move-exception p1

    .line 37
    :try_start_b2
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V
    :try_end_b5
    .catchall {:try_start_b2 .. :try_end_b5} :catchall_b6

    goto :goto_ba

    :catchall_b6
    move-exception v3

    :try_start_b7
    invoke-virtual {p1, v3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_ba
    throw p1
    :try_end_bb
    .catchall {:try_start_b7 .. :try_end_bb} :catchall_bb

    :catchall_bb
    move-exception p1

    if-eqz v2, :cond_c6

    :try_start_be
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V
    :try_end_c1
    .catchall {:try_start_be .. :try_end_c1} :catchall_c2

    goto :goto_c6

    :catchall_c2
    move-exception v2

    :try_start_c3
    invoke-virtual {p1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_c6
    :goto_c6
    throw p1
    :try_end_c7
    .catch Ljava/io/IOException; {:try_start_c3 .. :try_end_c7} :catch_ce
    .catch Ljava/lang/SecurityException; {:try_start_c3 .. :try_end_c7} :catch_c7

    :catch_c7
    move-exception p1

    .line 67
    const-string v2, "security error"

    invoke-static {v0, v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_e4

    :catch_ce
    move-exception p1

    .line 68
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "io error"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_e4
    :goto_e4
    return-object v1

    :catch_e5
    move-exception p1

    .line 69
    const-string v2, "malformed url error"

    invoke-static {v0, v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-object v1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 2

    .line 1
    check-cast p1, Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/j/c$b;->onPostExecute(Ljava/lang/Void;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/Void;)V
    .registers 3

    .line 2
    invoke-super {p0, p1}, Landroid/os/AsyncTask;->onPostExecute(Ljava/lang/Object;)V

    .line 3
    iget-object p1, p0, Lcom/vdocipher/aegis/core/j/c$b;->d:Lcom/vdocipher/aegis/core/j/c;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/c;->a(Lcom/vdocipher/aegis/core/j/c;)Lcom/vdocipher/aegis/core/j/c$a;

    move-result-object p1

    if-eqz p1, :cond_16

    .line 4
    iget-object p1, p0, Lcom/vdocipher/aegis/core/j/c$b;->d:Lcom/vdocipher/aegis/core/j/c;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/c;->a(Lcom/vdocipher/aegis/core/j/c;)Lcom/vdocipher/aegis/core/j/c$a;

    move-result-object p1

    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/c$b;->c:Ljava/lang/String;

    invoke-interface {p1, v0}, Lcom/vdocipher/aegis/core/j/c$a;->a(Ljava/lang/String;)V

    :cond_16
    return-void
.end method

.method protected onPreExecute()V
    .registers 1

    .line 1
    invoke-super {p0}, Landroid/os/AsyncTask;->onPreExecute()V

    return-void
.end method
