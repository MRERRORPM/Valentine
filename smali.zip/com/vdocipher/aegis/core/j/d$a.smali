# classes14.dex

.class interface abstract Lcom/vdocipher/aegis/core/j/d$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/j/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Lcom/vdocipher/aegis/core/k/f;)V
.end method

.method public abstract a(Lcom/vdocipher/aegis/core/k/g;)V
.end method
