# classes14.dex

.class Lcom/vdocipher/aegis/core/j/a$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/media3/exoplayer/offline/DownloadManager$Listener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/j/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/j/a;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/j/a;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/j/a$a;->a:Lcom/vdocipher/aegis/core/j/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onDownloadChanged(Landroidx/media3/exoplayer/offline/DownloadManager;Landroidx/media3/exoplayer/offline/Download;Ljava/lang/Exception;)V
    .registers 6

    .line 1
    iget-object p1, p0, Lcom/vdocipher/aegis/core/j/a$a;->a:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/a;->a(Lcom/vdocipher/aegis/core/j/a;)Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object p1

    iget-object v0, p2, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    iget-object v0, v0, Landroidx/media3/exoplayer/offline/DownloadRequest;->uri:Landroid/net/Uri;

    invoke-virtual {p1, v0, p2}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    invoke-static {p2}, Lcom/vdocipher/aegis/offline/DownloadStatus;->getDownloadStatus(Landroidx/media3/exoplayer/offline/Download;)Lcom/vdocipher/aegis/offline/DownloadStatus;

    move-result-object p1

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$a;->a:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/a;->b(Lcom/vdocipher/aegis/core/j/a;)Ljava/util/concurrent/CopyOnWriteArraySet;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/core/j/a$b;

    .line 4
    invoke-interface {v1, p1, p3}, Lcom/vdocipher/aegis/core/j/a$b;->a(Lcom/vdocipher/aegis/offline/DownloadStatus;Ljava/lang/Exception;)V

    goto :goto_1b

    .line 6
    :cond_2b
    iget-object p1, p0, Lcom/vdocipher/aegis/core/j/a$a;->a:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/a;->e(Lcom/vdocipher/aegis/core/j/a;)Lcom/vdocipher/aegis/core/d/h;

    move-result-object p1

    iget-object p3, p0, Lcom/vdocipher/aegis/core/j/a$a;->a:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {p3}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object p3

    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$a;->a:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/a;->d(Lcom/vdocipher/aegis/core/j/a;)Lcom/vdocipher/aegis/core/j/a$c;

    move-result-object v0

    if-eqz v0, :cond_48

    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$a;->a:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/a;->d(Lcom/vdocipher/aegis/core/j/a;)Lcom/vdocipher/aegis/core/j/a$c;

    move-result-object v0

    iget-object v0, v0, Lcom/vdocipher/aegis/core/j/a$c;->b:Lcom/vdocipher/aegis/offline/DownloadRequest;

    goto :goto_49

    :cond_48
    const/4 v0, 0x0

    :goto_49
    const-string v1, "downloadChanged"

    invoke-virtual {p1, p3, p2, v1, v0}, Lcom/vdocipher/aegis/core/d/h;->a(Landroid/content/Context;Landroidx/media3/exoplayer/offline/Download;Ljava/lang/String;Lcom/vdocipher/aegis/offline/DownloadRequest;)V

    return-void
.end method

.method public onDownloadRemoved(Landroidx/media3/exoplayer/offline/DownloadManager;Landroidx/media3/exoplayer/offline/Download;)V
    .registers 6

    .line 1
    iget-object p1, p0, Lcom/vdocipher/aegis/core/j/a$a;->a:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/a;->a(Lcom/vdocipher/aegis/core/j/a;)Ljava/util/concurrent/ConcurrentHashMap;

    move-result-object p1

    iget-object v0, p2, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    iget-object v0, v0, Landroidx/media3/exoplayer/offline/DownloadRequest;->uri:Landroid/net/Uri;

    invoke-virtual {p1, v0}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    iget-object p1, p0, Lcom/vdocipher/aegis/core/j/a$a;->a:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/a;->b(Lcom/vdocipher/aegis/core/j/a;)Ljava/util/concurrent/CopyOnWriteArraySet;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_17
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2b

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/aegis/core/j/a$b;

    .line 3
    invoke-static {p2}, Lcom/vdocipher/aegis/offline/DownloadStatus;->getDownloadStatus(Landroidx/media3/exoplayer/offline/Download;)Lcom/vdocipher/aegis/offline/DownloadStatus;

    move-result-object v1

    invoke-interface {v0, v1}, Lcom/vdocipher/aegis/core/j/a$b;->a(Lcom/vdocipher/aegis/offline/DownloadStatus;)V

    goto :goto_17

    .line 6
    :cond_2b
    iget-object p1, p0, Lcom/vdocipher/aegis/core/j/a$a;->a:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/a;->e(Lcom/vdocipher/aegis/core/j/a;)Lcom/vdocipher/aegis/core/d/h;

    move-result-object p1

    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$a;->a:Lcom/vdocipher/aegis/core/j/a;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/j/a;->c(Lcom/vdocipher/aegis/core/j/a;)Landroid/content/Context;

    move-result-object v0

    const-string v1, "downloadRemoved"

    const/4 v2, 0x0

    invoke-virtual {p1, v0, p2, v1, v2}, Lcom/vdocipher/aegis/core/d/h;->a(Landroid/content/Context;Landroidx/media3/exoplayer/offline/Download;Ljava/lang/String;Lcom/vdocipher/aegis/offline/DownloadRequest;)V

    return-void
.end method
