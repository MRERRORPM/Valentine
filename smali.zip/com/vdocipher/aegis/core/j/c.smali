# classes14.dex

.class public Lcom/vdocipher/aegis/core/j/c;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/core/j/c$a;,
        Lcom/vdocipher/aegis/core/j/c$b;
    }
.end annotation


# instance fields
.field private a:Lcom/vdocipher/aegis/core/j/c$a;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/j/c;)Lcom/vdocipher/aegis/core/j/c$a;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/j/c;->a:Lcom/vdocipher/aegis/core/j/c$a;

    return-object p0
.end method


# virtual methods
.method public a(Lcom/vdocipher/aegis/core/j/c$a;)V
    .registers 2

    .line 3
    iput-object p1, p0, Lcom/vdocipher/aegis/core/j/c;->a:Lcom/vdocipher/aegis/core/j/c$a;

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    .line 2
    new-instance v0, Lcom/vdocipher/aegis/core/j/c$b;

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/j/c$b;-><init>(Lcom/vdocipher/aegis/core/j/c;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x0

    new-array p1, p1, [Ljava/lang/Void;

    invoke-virtual {v0, p1}, Landroid/os/AsyncTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method
