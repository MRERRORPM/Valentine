# classes14.dex

.class final Lcom/vdocipher/aegis/core/j/a$d;
.super Landroid/os/AsyncTask;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/j/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "d"
.end annotation


# instance fields
.field private a:Ljava/lang/ref/WeakReference;

.field private final b:Lcom/vdocipher/aegis/core/k/k;

.field private final c:Lcom/vdocipher/aegis/core/j/a$c;

.field private final d:Landroidx/media3/exoplayer/offline/DownloadHelper;

.field private e:Lcom/vdocipher/aegis/core/k/f;

.field private f:Lcom/vdocipher/aegis/core/k/g;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/vdocipher/aegis/core/k/k;Lcom/vdocipher/aegis/core/j/a$c;Landroidx/media3/exoplayer/offline/DownloadHelper;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lcom/vdocipher/aegis/core/j/a$d;->e:Lcom/vdocipher/aegis/core/k/f;

    .line 10
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/j/a$d;->a:Ljava/lang/ref/WeakReference;

    .line 11
    iput-object p2, p0, Lcom/vdocipher/aegis/core/j/a$d;->b:Lcom/vdocipher/aegis/core/k/k;

    .line 12
    iput-object p3, p0, Lcom/vdocipher/aegis/core/j/a$d;->c:Lcom/vdocipher/aegis/core/j/a$c;

    .line 13
    iput-object p4, p0, Lcom/vdocipher/aegis/core/j/a$d;->d:Landroidx/media3/exoplayer/offline/DownloadHelper;

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/j/a$d;Lcom/vdocipher/aegis/core/k/f;)Lcom/vdocipher/aegis/core/k/f;
    .registers 2

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/j/a$d;->e:Lcom/vdocipher/aegis/core/k/f;

    return-object p1
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/j/a$d;Lcom/vdocipher/aegis/core/k/g;)Lcom/vdocipher/aegis/core/k/g;
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/j/a$d;->f:Lcom/vdocipher/aegis/core/k/g;

    return-object p1
.end method

.method private a()V
    .registers 4

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$d;->e:Lcom/vdocipher/aegis/core/k/f;

    if-eqz v0, :cond_a

    .line 4
    iget-object v1, p0, Lcom/vdocipher/aegis/core/j/a$d;->c:Lcom/vdocipher/aegis/core/j/a$c;

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/j/a$c;->a(Lcom/vdocipher/aegis/core/j/a$c;Lcom/vdocipher/aegis/core/k/f;)V

    return-void

    .line 7
    :cond_a
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$d;->f:Lcom/vdocipher/aegis/core/k/g;

    if-eqz v0, :cond_1d

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/k/g;->b()[B

    move-result-object v0

    if-eqz v0, :cond_1d

    .line 8
    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$d;->c:Lcom/vdocipher/aegis/core/j/a$c;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/j/a$d;->d:Landroidx/media3/exoplayer/offline/DownloadHelper;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/j/a$d;->f:Lcom/vdocipher/aegis/core/k/g;

    invoke-static {v0, v1, v2}, Lcom/vdocipher/aegis/core/j/a$c;->a(Lcom/vdocipher/aegis/core/j/a$c;Landroidx/media3/exoplayer/offline/DownloadHelper;Lcom/vdocipher/aegis/core/k/g;)V

    :cond_1d
    const/4 v0, 0x0

    .line 9
    iput-object v0, p0, Lcom/vdocipher/aegis/core/j/a$d;->a:Ljava/lang/ref/WeakReference;

    return-void
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 1
    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/j/a$d;->doInBackground([Ljava/lang/Void;)Ljava/lang/Void;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/Void;
    .registers 5

    .line 2
    new-instance p1, Lcom/vdocipher/aegis/core/j/d;

    iget-object v0, p0, Lcom/vdocipher/aegis/core/j/a$d;->a:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/Context;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/j/a$d;->b:Lcom/vdocipher/aegis/core/k/k;

    new-instance v2, Lcom/vdocipher/aegis/core/j/a$d$a;

    invoke-direct {v2, p0}, Lcom/vdocipher/aegis/core/j/a$d$a;-><init>(Lcom/vdocipher/aegis/core/j/a$d;)V

    invoke-direct {p1, v0, v1, v2}, Lcom/vdocipher/aegis/core/j/d;-><init>(Landroid/content/Context;Lcom/vdocipher/aegis/core/k/k;Lcom/vdocipher/aegis/core/j/d$a;)V

    .line 12
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/j/d;->a()V

    const/4 p1, 0x0

    return-object p1
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 2

    .line 1
    check-cast p1, Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/j/a$d;->onPostExecute(Ljava/lang/Void;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/Void;)V
    .registers 2

    .line 2
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/j/a$d;->a()V

    return-void
.end method
