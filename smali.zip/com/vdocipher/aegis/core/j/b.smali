# classes14.dex

.class public abstract Lcom/vdocipher/aegis/core/j/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static a:Lcom/vdocipher/aegis/core/z/f$a;

.field private static b:Landroidx/media3/database/DatabaseProvider;

.field private static c:Ljava/io/File;

.field private static d:Landroidx/media3/datasource/cache/SimpleCache;

.field private static e:Landroidx/media3/datasource/cache/SimpleCache;

.field private static f:Landroidx/media3/datasource/cache/SimpleCache;

.field private static g:Landroidx/media3/exoplayer/offline/DownloadManager;

.field private static h:Lcom/vdocipher/aegis/core/j/a;

.field private static i:Lcom/vdocipher/aegis/offline/exoplayer/VdoDownloadNotificationHelper;


# direct methods
.method private static a(Landroid/content/Context;Ljava/io/File;)Landroidx/media3/datasource/cache/SimpleCache;
    .registers 6

    .line 9
    new-instance v0, Landroidx/media3/datasource/cache/SimpleCache;

    new-instance v1, Landroidx/media3/datasource/cache/LeastRecentlyUsedCacheEvictor;

    const-wide/32 v2, 0xc800000

    invoke-direct {v1, v2, v3}, Landroidx/media3/datasource/cache/LeastRecentlyUsedCacheEvictor;-><init>(J)V

    .line 10
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->f(Landroid/content/Context;)Landroidx/media3/database/DatabaseProvider;

    move-result-object p0

    invoke-direct {v0, p1, v1, p0}, Landroidx/media3/datasource/cache/SimpleCache;-><init>(Ljava/io/File;Landroidx/media3/datasource/cache/CacheEvictor;Landroidx/media3/database/DatabaseProvider;)V

    return-object v0
.end method

.method private static declared-synchronized a(Landroid/content/Context;Ljava/lang/String;)Landroidx/media3/datasource/cache/SimpleCache;
    .registers 4

    const-class v0, Lcom/vdocipher/aegis/core/j/b;

    monitor-enter v0

    .line 4
    :try_start_3
    sget-object v1, Lcom/vdocipher/aegis/core/j/b;->e:Landroidx/media3/datasource/cache/SimpleCache;

    if-nez v1, :cond_12

    .line 5
    new-instance v1, Ljava/io/File;

    invoke-direct {v1, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 6
    invoke-static {p0, v1}, Lcom/vdocipher/aegis/core/j/b;->b(Landroid/content/Context;Ljava/io/File;)Landroidx/media3/datasource/cache/SimpleCache;

    move-result-object p0

    sput-object p0, Lcom/vdocipher/aegis/core/j/b;->e:Landroidx/media3/datasource/cache/SimpleCache;

    .line 8
    :cond_12
    sget-object p0, Lcom/vdocipher/aegis/core/j/b;->e:Landroidx/media3/datasource/cache/SimpleCache;
    :try_end_14
    .catchall {:try_start_3 .. :try_end_14} :catchall_16

    monitor-exit v0

    return-object p0

    :catchall_16
    move-exception p0

    :try_start_17
    monitor-exit v0
    :try_end_18
    .catchall {:try_start_17 .. :try_end_18} :catchall_16

    throw p0
.end method

.method public static a(Landroid/content/Context;)Landroidx/media3/exoplayer/RenderersFactory;
    .registers 2

    .line 1
    new-instance v0, Landroidx/media3/exoplayer/DefaultRenderersFactory;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    invoke-direct {v0, p0}, Landroidx/media3/exoplayer/DefaultRenderersFactory;-><init>(Landroid/content/Context;)V

    .line 2
    invoke-virtual {v0}, Landroidx/media3/exoplayer/DefaultRenderersFactory;->forceEnableMediaCodecAsynchronousQueueing()Landroidx/media3/exoplayer/DefaultRenderersFactory;

    move-result-object p0

    const/4 v0, 0x0

    .line 3
    invoke-virtual {p0, v0}, Landroidx/media3/exoplayer/DefaultRenderersFactory;->setExtensionRendererMode(I)Landroidx/media3/exoplayer/DefaultRenderersFactory;

    move-result-object p0

    return-object p0
.end method

.method public static declared-synchronized a(Landroid/content/Context;Landroidx/media3/exoplayer/offline/DownloadRequest;)Landroidx/media3/exoplayer/offline/DownloadManager;
    .registers 10

    const-class v1, Lcom/vdocipher/aegis/core/j/b;

    monitor-enter v1

    .line 11
    :try_start_3
    new-instance v0, Lorg/json/JSONObject;

    new-instance v2, Ljava/lang/String;

    iget-object p1, p1, Landroidx/media3/exoplayer/offline/DownloadRequest;->data:[B

    sget-object v3, Lcom/google/common/base/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v2, p1, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v0, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 12
    const-string p1, "localStorageFolder"

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 13
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V
    :try_end_1c
    .catch Lorg/json/JSONException; {:try_start_3 .. :try_end_1c} :catch_20
    .catchall {:try_start_3 .. :try_end_1c} :catchall_1d

    goto :goto_36

    :catchall_1d
    move-exception v0

    move-object p0, v0

    goto :goto_4f

    :catch_20
    move-exception v0

    move-object p1, v0

    .line 15
    :try_start_22
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "DownloadUtil"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 16
    new-instance v0, Ljava/io/File;

    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->h(Landroid/content/Context;)Ljava/io/File;

    move-result-object p1

    const-string v2, "exoplayer"

    invoke-direct {v0, p1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 19
    :goto_36
    invoke-static {p0, v0}, Lcom/vdocipher/aegis/core/j/b;->b(Landroid/content/Context;Ljava/io/File;)Landroidx/media3/datasource/cache/SimpleCache;

    move-result-object v5

    .line 20
    new-instance v2, Landroidx/media3/exoplayer/offline/DownloadManager;

    .line 22
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->f(Landroid/content/Context;)Landroidx/media3/database/DatabaseProvider;

    move-result-object v4

    .line 24
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->n(Landroid/content/Context;)Lcom/vdocipher/aegis/core/z/f$a;

    move-result-object v6

    const/4 p1, 0x6

    .line 25
    invoke-static {p1}, Ljava/util/concurrent/Executors;->newFixedThreadPool(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v7

    move-object v3, p0

    invoke-direct/range {v2 .. v7}, Landroidx/media3/exoplayer/offline/DownloadManager;-><init>(Landroid/content/Context;Landroidx/media3/database/DatabaseProvider;Landroidx/media3/datasource/cache/Cache;Landroidx/media3/datasource/DataSource$Factory;Ljava/util/concurrent/Executor;)V
    :try_end_4d
    .catchall {:try_start_22 .. :try_end_4d} :catchall_1d

    monitor-exit v1

    return-object v2

    :goto_4f
    :try_start_4f
    monitor-exit v1
    :try_end_50
    .catchall {:try_start_4f .. :try_end_50} :catchall_1d

    throw p0
.end method

.method public static a(Landroidx/media3/exoplayer/offline/DownloadRequest;)Ljava/util/List;
    .registers 7

    .line 26
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 29
    :try_start_5
    new-instance v1, Lorg/json/JSONObject;

    new-instance v2, Ljava/lang/String;

    iget-object p0, p0, Landroidx/media3/exoplayer/offline/DownloadRequest;->data:[B

    sget-object v3, Lcom/google/common/base/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v2, p0, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v1, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 30
    const-string p0, "captions"

    invoke-virtual {v1, p0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p0

    const/4 v1, 0x0

    .line 32
    :goto_1a
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v1, v2, :cond_41

    .line 33
    invoke-virtual {p0, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    .line 34
    const-string v3, "caption_path"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 35
    sget-object v4, Lcom/vdocipher/aegis/media/Caption;->Companion:Lcom/vdocipher/aegis/media/Caption$Companion;

    const-string v5, "caption_info"

    invoke-virtual {v2, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-virtual {v4, v2}, Lcom/vdocipher/aegis/media/Caption$Companion;->fromJSON(Lorg/json/JSONObject;)Lcom/vdocipher/aegis/media/Caption;

    move-result-object v2

    .line 36
    new-instance v4, Landroid/util/Pair;

    invoke-direct {v4, v3, v2}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_3e
    .catch Lorg/json/JSONException; {:try_start_5 .. :try_end_3e} :catch_42

    add-int/lit8 v1, v1, 0x1

    goto :goto_1a

    :cond_41
    return-object v0

    :catch_42
    move-exception p0

    .line 40
    invoke-static {p0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p0

    const-string v1, "DownloadUtil"

    invoke-static {v1, p0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method private static b(Landroid/content/Context;Ljava/io/File;)Landroidx/media3/datasource/cache/SimpleCache;
    .registers 4

    .line 57
    new-instance v0, Landroidx/media3/datasource/cache/SimpleCache;

    new-instance v1, Landroidx/media3/datasource/cache/NoOpCacheEvictor;

    invoke-direct {v1}, Landroidx/media3/datasource/cache/NoOpCacheEvictor;-><init>()V

    .line 58
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->f(Landroid/content/Context;)Landroidx/media3/database/DatabaseProvider;

    move-result-object p0

    invoke-direct {v0, p1, v1, p0}, Landroidx/media3/datasource/cache/SimpleCache;-><init>(Ljava/io/File;Landroidx/media3/datasource/cache/CacheEvictor;Landroidx/media3/database/DatabaseProvider;)V

    return-object v0
.end method

.method private static b(Landroid/content/Context;)Ljava/lang/String;
    .registers 10

    .line 1
    const-string/jumbo v0, "vdo_download"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 2
    const-string v2, ""

    const-string v3, "secondaryDownloadPath"

    invoke-interface {v0, v3, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 5
    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_1b

    return-object v2

    .line 9
    :cond_1b
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->i(Landroid/content/Context;)Landroidx/media3/exoplayer/offline/DownloadManager;

    move-result-object v2

    .line 12
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->h(Landroid/content/Context;)Ljava/io/File;

    move-result-object p0

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object p0, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "exoplayer"

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    .line 16
    :try_start_3e
    invoke-virtual {v2}, Landroidx/media3/exoplayer/offline/DownloadManager;->getDownloadIndex()Landroidx/media3/exoplayer/offline/DownloadIndex;

    move-result-object v2

    new-array v5, v1, [I

    invoke-interface {v2, v5}, Landroidx/media3/exoplayer/offline/DownloadIndex;->getDownloads([I)Landroidx/media3/exoplayer/offline/DownloadCursor;

    move-result-object v2
    :try_end_48
    .catch Ljava/io/IOException; {:try_start_3e .. :try_end_48} :catch_87

    .line 17
    :catch_48
    :goto_48
    :try_start_48
    invoke-interface {v2}, Landroidx/media3/exoplayer/offline/DownloadCursor;->moveToNext()Z

    move-result v5

    if-eqz v5, :cond_77

    const/4 v5, 0x5

    if-le v1, v5, :cond_52

    goto :goto_77

    .line 19
    :cond_52
    invoke-interface {v2}, Landroidx/media3/exoplayer/offline/DownloadCursor;->getDownload()Landroidx/media3/exoplayer/offline/Download;

    move-result-object v5
    :try_end_56
    .catchall {:try_start_48 .. :try_end_56} :catchall_7b

    .line 21
    :try_start_56
    new-instance v6, Lorg/json/JSONObject;

    new-instance v7, Ljava/lang/String;

    iget-object v5, v5, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    iget-object v5, v5, Landroidx/media3/exoplayer/offline/DownloadRequest;->data:[B

    sget-object v8, Lcom/google/common/base/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v7, v5, v8}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v6, v7}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 22
    const-string v5, "localStorageFolder"

    invoke-virtual {v6, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 24
    invoke-virtual {v5, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6
    :try_end_70
    .catch Lorg/json/JSONException; {:try_start_56 .. :try_end_70} :catch_48
    .catchall {:try_start_56 .. :try_end_70} :catchall_7b

    if-nez v6, :cond_74

    move-object v4, v5

    goto :goto_77

    :cond_74
    add-int/lit8 v1, v1, 0x1

    goto :goto_48

    .line 32
    :cond_77
    :goto_77
    :try_start_77
    invoke-interface {v2}, Landroidx/media3/exoplayer/offline/DownloadCursor;->close()V
    :try_end_7a
    .catch Ljava/io/IOException; {:try_start_77 .. :try_end_7a} :catch_87

    goto :goto_87

    :catchall_7b
    move-exception p0

    if-eqz v2, :cond_86

    .line 33
    :try_start_7e
    invoke-interface {v2}, Landroidx/media3/exoplayer/offline/DownloadCursor;->close()V
    :try_end_81
    .catchall {:try_start_7e .. :try_end_81} :catchall_82

    goto :goto_86

    :catchall_82
    move-exception v1

    :try_start_83
    invoke-virtual {p0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_86
    :goto_86
    throw p0
    :try_end_87
    .catch Ljava/io/IOException; {:try_start_83 .. :try_end_87} :catch_87

    :catch_87
    :goto_87
    if-eqz v4, :cond_8f

    .line 52
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_91

    .line 53
    :cond_8f
    const-string v4, "none"

    .line 56
    :cond_91
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0, v3, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-object v4
.end method

.method public static b(Landroidx/media3/exoplayer/offline/DownloadRequest;)Ljava/util/List;
    .registers 5

    .line 59
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 62
    :try_start_5
    new-instance v1, Lorg/json/JSONObject;

    new-instance v2, Ljava/lang/String;

    iget-object p0, p0, Landroidx/media3/exoplayer/offline/DownloadRequest;->data:[B

    sget-object v3, Lcom/google/common/base/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v2, p0, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v1, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 63
    const-string p0, "captions"

    invoke-virtual {v1, p0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p0

    const/4 v1, 0x0

    .line 64
    :goto_1a
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v1, v2, :cond_30

    .line 65
    invoke-virtual {p0, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    .line 66
    const-string v3, "caption_path"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 67
    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_2d
    .catch Lorg/json/JSONException; {:try_start_5 .. :try_end_2d} :catch_31

    add-int/lit8 v1, v1, 0x1

    goto :goto_1a

    :cond_30
    return-object v0

    :catch_31
    move-exception p0

    .line 71
    invoke-static {p0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p0

    const-string v1, "DownloadUtil"

    invoke-static {v1, p0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public static declared-synchronized c(Landroid/content/Context;)V
    .registers 5

    const-class v0, Lcom/vdocipher/aegis/core/j/b;

    monitor-enter v0

    .line 1
    :try_start_3
    sget-object v1, Lcom/vdocipher/aegis/core/j/b;->f:Landroidx/media3/datasource/cache/SimpleCache;

    if-eqz v1, :cond_1b

    .line 2
    new-instance v1, Ljava/io/File;

    .line 3
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->h(Landroid/content/Context;)Ljava/io/File;

    move-result-object v2

    const-string v3, "cache"

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 4
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->f(Landroid/content/Context;)Landroidx/media3/database/DatabaseProvider;

    move-result-object p0

    invoke-static {v1, p0}, Landroidx/media3/datasource/cache/SimpleCache;->delete(Ljava/io/File;Landroidx/media3/database/DatabaseProvider;)V
    :try_end_19
    .catchall {:try_start_3 .. :try_end_19} :catchall_1d

    monitor-exit v0

    return-void

    :cond_1b
    monitor-exit v0

    return-void

    :catchall_1d
    move-exception p0

    :try_start_1e
    monitor-exit v0
    :try_end_1f
    .catchall {:try_start_1e .. :try_end_1f} :catchall_1d

    throw p0
.end method

.method private static declared-synchronized d(Landroid/content/Context;)V
    .registers 9

    const-class v1, Lcom/vdocipher/aegis/core/j/b;

    monitor-enter v1

    .line 1
    :try_start_3
    sget-object v0, Lcom/vdocipher/aegis/core/j/b;->g:Landroidx/media3/exoplayer/offline/DownloadManager;

    if-nez v0, :cond_2f

    .line 2
    new-instance v2, Landroidx/media3/exoplayer/offline/DownloadManager;

    .line 5
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->f(Landroid/content/Context;)Landroidx/media3/database/DatabaseProvider;

    move-result-object v4

    .line 6
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->g(Landroid/content/Context;)Landroidx/media3/datasource/cache/SimpleCache;

    move-result-object v5

    .line 7
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->n(Landroid/content/Context;)Lcom/vdocipher/aegis/core/z/f$a;

    move-result-object v6

    const/4 v0, 0x6

    .line 8
    invoke-static {v0}, Ljava/util/concurrent/Executors;->newFixedThreadPool(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v7

    move-object v3, p0

    invoke-direct/range {v2 .. v7}, Landroidx/media3/exoplayer/offline/DownloadManager;-><init>(Landroid/content/Context;Landroidx/media3/database/DatabaseProvider;Landroidx/media3/datasource/cache/Cache;Landroidx/media3/datasource/DataSource$Factory;Ljava/util/concurrent/Executor;)V

    sput-object v2, Lcom/vdocipher/aegis/core/j/b;->g:Landroidx/media3/exoplayer/offline/DownloadManager;

    .line 9
    new-instance p0, Lcom/vdocipher/aegis/core/j/a;

    .line 10
    invoke-static {v3}, Lcom/vdocipher/aegis/core/j/b;->n(Landroid/content/Context;)Lcom/vdocipher/aegis/core/z/f$a;

    move-result-object v0

    sget-object v2, Lcom/vdocipher/aegis/core/j/b;->g:Landroidx/media3/exoplayer/offline/DownloadManager;

    invoke-direct {p0, v3, v0, v2}, Lcom/vdocipher/aegis/core/j/a;-><init>(Landroid/content/Context;Lcom/vdocipher/aegis/core/z/f$a;Landroidx/media3/exoplayer/offline/DownloadManager;)V

    sput-object p0, Lcom/vdocipher/aegis/core/j/b;->h:Lcom/vdocipher/aegis/core/j/a;
    :try_end_2d
    .catchall {:try_start_3 .. :try_end_2d} :catchall_31

    monitor-exit v1

    return-void

    :cond_2f
    monitor-exit v1

    return-void

    :catchall_31
    move-exception v0

    move-object p0, v0

    :try_start_33
    monitor-exit v1
    :try_end_34
    .catchall {:try_start_33 .. :try_end_34} :catchall_31

    throw p0
.end method

.method public static declared-synchronized e(Landroid/content/Context;)Landroidx/media3/datasource/DataSource$Factory;
    .registers 7

    const-class v0, Lcom/vdocipher/aegis/core/j/b;

    monitor-enter v0

    .line 1
    :try_start_3
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    .line 3
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    .line 5
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_1c

    const-string v2, "none"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_1c

    .line 6
    invoke-static {p0, v1}, Lcom/vdocipher/aegis/core/j/b;->a(Landroid/content/Context;Ljava/lang/String;)Landroidx/media3/datasource/cache/SimpleCache;

    .line 9
    :cond_1c
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->g(Landroid/content/Context;)Landroidx/media3/datasource/cache/SimpleCache;

    move-result-object v1

    .line 10
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->m(Landroid/content/Context;)Landroidx/media3/datasource/cache/SimpleCache;

    move-result-object v2

    .line 12
    new-instance v3, Lcom/vdocipher/aegis/core/z/e;

    invoke-direct {v3, p0}, Lcom/vdocipher/aegis/core/z/e;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3}, Lcom/vdocipher/aegis/core/z/e;->a()Lorg/chromium/net/CronetEngine;

    move-result-object p0

    .line 14
    invoke-static {}, Lcom/vdocipher/aegis/core/t/d;->b()Ljava/lang/String;

    move-result-object v3

    .line 16
    new-instance v4, Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    invoke-direct {v4}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;-><init>()V

    .line 17
    invoke-virtual {v4, v2}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setCache(Landroidx/media3/datasource/cache/Cache;)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object v2

    const/4 v4, 0x0

    .line 18
    invoke-virtual {v2, v4}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setCacheWriteDataSinkFactory(Landroidx/media3/datasource/DataSink$Factory;)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object v2

    new-instance v5, Lcom/vdocipher/aegis/core/z/f$a;

    invoke-direct {v5, p0}, Lcom/vdocipher/aegis/core/z/f$a;-><init>(Lorg/chromium/net/CronetEngine;)V

    .line 19
    invoke-virtual {v5, v3}, Lcom/vdocipher/aegis/core/z/f$a;->a(Ljava/lang/String;)Lcom/vdocipher/aegis/core/z/f$a;

    move-result-object p0

    invoke-virtual {v2, p0}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setUpstreamDataSourceFactory(Landroidx/media3/datasource/DataSource$Factory;)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object p0

    const/4 v2, 0x2

    .line 20
    invoke-virtual {p0, v2}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setFlags(I)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object p0

    .line 22
    new-instance v3, Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    invoke-direct {v3}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;-><init>()V

    .line 23
    invoke-virtual {v3, v1}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setCache(Landroidx/media3/datasource/cache/Cache;)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object v1

    .line 24
    invoke-virtual {v1, v4}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setCacheWriteDataSinkFactory(Landroidx/media3/datasource/DataSink$Factory;)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object v1

    .line 25
    invoke-virtual {v1, p0}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setUpstreamDataSourceFactory(Landroidx/media3/datasource/DataSource$Factory;)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object p0

    .line 26
    invoke-virtual {p0, v2}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setFlags(I)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object p0

    .line 29
    sget-object v1, Lcom/vdocipher/aegis/core/j/b;->e:Landroidx/media3/datasource/cache/SimpleCache;

    if-eqz v1, :cond_83

    .line 32
    new-instance v1, Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    invoke-direct {v1}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;-><init>()V

    sget-object v3, Lcom/vdocipher/aegis/core/j/b;->e:Landroidx/media3/datasource/cache/SimpleCache;

    .line 33
    invoke-virtual {v1, v3}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setCache(Landroidx/media3/datasource/cache/Cache;)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object v1

    .line 34
    invoke-virtual {v1, v4}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setCacheWriteDataSinkFactory(Landroidx/media3/datasource/DataSink$Factory;)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object v1

    .line 35
    invoke-virtual {v1, p0}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setUpstreamDataSourceFactory(Landroidx/media3/datasource/DataSource$Factory;)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object p0

    .line 36
    invoke-virtual {p0, v2}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setFlags(I)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object p0
    :try_end_81
    .catchall {:try_start_3 .. :try_end_81} :catchall_85

    monitor-exit v0

    return-object p0

    :cond_83
    monitor-exit v0

    return-object p0

    :catchall_85
    move-exception p0

    :try_start_86
    monitor-exit v0
    :try_end_87
    .catchall {:try_start_86 .. :try_end_87} :catchall_85

    throw p0
.end method

.method private static declared-synchronized f(Landroid/content/Context;)Landroidx/media3/database/DatabaseProvider;
    .registers 3

    const-class v0, Lcom/vdocipher/aegis/core/j/b;

    monitor-enter v0

    .line 1
    :try_start_3
    sget-object v1, Lcom/vdocipher/aegis/core/j/b;->b:Landroidx/media3/database/DatabaseProvider;

    if-nez v1, :cond_e

    .line 2
    new-instance v1, Landroidx/media3/database/StandaloneDatabaseProvider;

    invoke-direct {v1, p0}, Landroidx/media3/database/StandaloneDatabaseProvider;-><init>(Landroid/content/Context;)V

    sput-object v1, Lcom/vdocipher/aegis/core/j/b;->b:Landroidx/media3/database/DatabaseProvider;

    .line 4
    :cond_e
    sget-object p0, Lcom/vdocipher/aegis/core/j/b;->b:Landroidx/media3/database/DatabaseProvider;
    :try_end_10
    .catchall {:try_start_3 .. :try_end_10} :catchall_12

    monitor-exit v0

    return-object p0

    :catchall_12
    move-exception p0

    :try_start_13
    monitor-exit v0
    :try_end_14
    .catchall {:try_start_13 .. :try_end_14} :catchall_12

    throw p0
.end method

.method private static declared-synchronized g(Landroid/content/Context;)Landroidx/media3/datasource/cache/SimpleCache;
    .registers 5

    const-class v0, Lcom/vdocipher/aegis/core/j/b;

    monitor-enter v0

    .line 1
    :try_start_3
    sget-object v1, Lcom/vdocipher/aegis/core/j/b;->d:Landroidx/media3/datasource/cache/SimpleCache;

    if-nez v1, :cond_18

    .line 2
    new-instance v1, Ljava/io/File;

    .line 3
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->h(Landroid/content/Context;)Ljava/io/File;

    move-result-object v2

    const-string v3, "exoplayer"

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 4
    invoke-static {p0, v1}, Lcom/vdocipher/aegis/core/j/b;->b(Landroid/content/Context;Ljava/io/File;)Landroidx/media3/datasource/cache/SimpleCache;

    move-result-object p0

    sput-object p0, Lcom/vdocipher/aegis/core/j/b;->d:Landroidx/media3/datasource/cache/SimpleCache;

    .line 6
    :cond_18
    sget-object p0, Lcom/vdocipher/aegis/core/j/b;->d:Landroidx/media3/datasource/cache/SimpleCache;
    :try_end_1a
    .catchall {:try_start_3 .. :try_end_1a} :catchall_1c

    monitor-exit v0

    return-object p0

    :catchall_1c
    move-exception p0

    :try_start_1d
    monitor-exit v0
    :try_end_1e
    .catchall {:try_start_1d .. :try_end_1e} :catchall_1c

    throw p0
.end method

.method public static declared-synchronized h(Landroid/content/Context;)Ljava/io/File;
    .registers 4

    const-class v0, Lcom/vdocipher/aegis/core/j/b;

    monitor-enter v0

    .line 1
    :try_start_3
    sget-object v1, Lcom/vdocipher/aegis/core/j/b;->c:Ljava/io/File;

    if-nez v1, :cond_38

    const/4 v1, 0x0

    .line 3
    invoke-virtual {p0, v1}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    if-eqz v1, :cond_13

    .line 5
    invoke-virtual {v1}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object p0

    goto :goto_1b

    .line 7
    :cond_13
    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object p0

    invoke-virtual {p0}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object p0

    .line 9
    :goto_1b
    new-instance v1, Ljava/io/File;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object p0, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "offlineVdos"

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v1, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    sput-object v1, Lcom/vdocipher/aegis/core/j/b;->c:Ljava/io/File;

    .line 11
    :cond_38
    sget-object p0, Lcom/vdocipher/aegis/core/j/b;->c:Ljava/io/File;
    :try_end_3a
    .catchall {:try_start_3 .. :try_end_3a} :catchall_3c

    monitor-exit v0

    return-object p0

    :catchall_3c
    move-exception p0

    :try_start_3d
    monitor-exit v0
    :try_end_3e
    .catchall {:try_start_3d .. :try_end_3e} :catchall_3c

    throw p0
.end method

.method public static declared-synchronized i(Landroid/content/Context;)Landroidx/media3/exoplayer/offline/DownloadManager;
    .registers 2

    const-class v0, Lcom/vdocipher/aegis/core/j/b;

    monitor-enter v0

    .line 1
    :try_start_3
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->d(Landroid/content/Context;)V

    .line 2
    sget-object p0, Lcom/vdocipher/aegis/core/j/b;->g:Landroidx/media3/exoplayer/offline/DownloadManager;
    :try_end_8
    .catchall {:try_start_3 .. :try_end_8} :catchall_a

    monitor-exit v0

    return-object p0

    :catchall_a
    move-exception p0

    :try_start_b
    monitor-exit v0
    :try_end_c
    .catchall {:try_start_b .. :try_end_c} :catchall_a

    throw p0
.end method

.method public static declared-synchronized j(Landroid/content/Context;)Lcom/vdocipher/aegis/offline/exoplayer/VdoDownloadNotificationHelper;
    .registers 5

    const-class v0, Lcom/vdocipher/aegis/core/j/b;

    monitor-enter v0

    .line 1
    :try_start_3
    sget-object v1, Lcom/vdocipher/aegis/core/j/b;->i:Lcom/vdocipher/aegis/offline/exoplayer/VdoDownloadNotificationHelper;

    if-nez v1, :cond_47

    .line 2
    sget-object v1, Lcom/vdocipher/aegis/core/j/b;->h:Lcom/vdocipher/aegis/core/j/a;

    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/j/a;->b()Ljava/lang/Class;

    move-result-object v1
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_4b

    if-eqz v1, :cond_3a

    .line 6
    :try_start_f
    const-class v2, Landroid/content/Context;

    const-class v3, Ljava/lang/String;

    filled-new-array {v2, v3}, [Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v1

    .line 7
    const-string v2, "download_channel"

    filled-new-array {p0, v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    .line 8
    check-cast v1, Lcom/vdocipher/aegis/offline/exoplayer/VdoDownloadNotificationHelper;

    sput-object v1, Lcom/vdocipher/aegis/core/j/b;->i:Lcom/vdocipher/aegis/offline/exoplayer/VdoDownloadNotificationHelper;
    :try_end_29
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_f .. :try_end_29} :catch_30
    .catch Ljava/lang/NoSuchMethodException; {:try_start_f .. :try_end_29} :catch_2e
    .catch Ljava/lang/IllegalAccessException; {:try_start_f .. :try_end_29} :catch_2c
    .catch Ljava/lang/InstantiationException; {:try_start_f .. :try_end_29} :catch_2a
    .catchall {:try_start_f .. :try_end_29} :catchall_4b

    goto :goto_3a

    :catch_2a
    move-exception v1

    goto :goto_31

    :catch_2c
    move-exception v1

    goto :goto_31

    :catch_2e
    move-exception v1

    goto :goto_31

    :catch_30
    move-exception v1

    .line 11
    :goto_31
    :try_start_31
    invoke-static {v1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "DownloadUtil"

    invoke-static {v2, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 16
    :cond_3a
    :goto_3a
    sget-object v1, Lcom/vdocipher/aegis/core/j/b;->i:Lcom/vdocipher/aegis/offline/exoplayer/VdoDownloadNotificationHelper;

    if-nez v1, :cond_47

    .line 17
    new-instance v1, Lcom/vdocipher/aegis/offline/exoplayer/VdoDownloadNotificationHelper;

    const-string v2, "download_channel"

    invoke-direct {v1, p0, v2}, Lcom/vdocipher/aegis/offline/exoplayer/VdoDownloadNotificationHelper;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    sput-object v1, Lcom/vdocipher/aegis/core/j/b;->i:Lcom/vdocipher/aegis/offline/exoplayer/VdoDownloadNotificationHelper;

    .line 20
    :cond_47
    sget-object p0, Lcom/vdocipher/aegis/core/j/b;->i:Lcom/vdocipher/aegis/offline/exoplayer/VdoDownloadNotificationHelper;
    :try_end_49
    .catchall {:try_start_31 .. :try_end_49} :catchall_4b

    monitor-exit v0

    return-object p0

    :catchall_4b
    move-exception p0

    :try_start_4c
    monitor-exit v0
    :try_end_4d
    .catchall {:try_start_4c .. :try_end_4d} :catchall_4b

    throw p0
.end method

.method public static declared-synchronized k(Landroid/content/Context;)Lcom/vdocipher/aegis/core/j/a;
    .registers 2

    const-class v0, Lcom/vdocipher/aegis/core/j/b;

    monitor-enter v0

    .line 1
    :try_start_3
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->d(Landroid/content/Context;)V

    .line 2
    sget-object p0, Lcom/vdocipher/aegis/core/j/b;->h:Lcom/vdocipher/aegis/core/j/a;
    :try_end_8
    .catchall {:try_start_3 .. :try_end_8} :catchall_a

    monitor-exit v0

    return-object p0

    :catchall_a
    move-exception p0

    :try_start_b
    monitor-exit v0
    :try_end_c
    .catchall {:try_start_b .. :try_end_c} :catchall_a

    throw p0
.end method

.method public static declared-synchronized l(Landroid/content/Context;)Landroidx/media3/datasource/cache/CacheDataSource$Factory;
    .registers 6

    const-class v0, Lcom/vdocipher/aegis/core/j/b;

    monitor-enter v0

    .line 1
    :try_start_3
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    .line 3
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->m(Landroid/content/Context;)Landroidx/media3/datasource/cache/SimpleCache;

    move-result-object v1

    .line 5
    invoke-static {}, Lcom/vdocipher/aegis/core/t/d;->b()Ljava/lang/String;

    move-result-object v2

    .line 7
    new-instance v3, Lcom/vdocipher/aegis/core/z/e;

    invoke-direct {v3, p0}, Lcom/vdocipher/aegis/core/z/e;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3}, Lcom/vdocipher/aegis/core/z/e;->a()Lorg/chromium/net/CronetEngine;

    move-result-object p0

    .line 9
    new-instance v3, Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    invoke-direct {v3}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;-><init>()V

    .line 10
    invoke-virtual {v3, v1}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setCache(Landroidx/media3/datasource/cache/Cache;)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object v3

    new-instance v4, Landroidx/media3/datasource/cache/CacheDataSink$Factory;

    invoke-direct {v4}, Landroidx/media3/datasource/cache/CacheDataSink$Factory;-><init>()V

    .line 11
    invoke-virtual {v4, v1}, Landroidx/media3/datasource/cache/CacheDataSink$Factory;->setCache(Landroidx/media3/datasource/cache/Cache;)Landroidx/media3/datasource/cache/CacheDataSink$Factory;

    move-result-object v1

    const/16 v4, 0x5000

    invoke-virtual {v1, v4}, Landroidx/media3/datasource/cache/CacheDataSink$Factory;->setBufferSize(I)Landroidx/media3/datasource/cache/CacheDataSink$Factory;

    move-result-object v1

    invoke-virtual {v3, v1}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setCacheWriteDataSinkFactory(Landroidx/media3/datasource/DataSink$Factory;)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object v1

    new-instance v3, Lcom/vdocipher/aegis/core/z/f$a;

    invoke-direct {v3, p0}, Lcom/vdocipher/aegis/core/z/f$a;-><init>(Lorg/chromium/net/CronetEngine;)V

    .line 12
    invoke-virtual {v3, v2}, Lcom/vdocipher/aegis/core/z/f$a;->a(Ljava/lang/String;)Lcom/vdocipher/aegis/core/z/f$a;

    move-result-object p0

    invoke-virtual {v1, p0}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setUpstreamDataSourceFactory(Landroidx/media3/datasource/DataSource$Factory;)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object p0

    const/4 v1, 0x2

    .line 13
    invoke-virtual {p0, v1}, Landroidx/media3/datasource/cache/CacheDataSource$Factory;->setFlags(I)Landroidx/media3/datasource/cache/CacheDataSource$Factory;

    move-result-object p0
    :try_end_46
    .catchall {:try_start_3 .. :try_end_46} :catchall_48

    monitor-exit v0

    return-object p0

    :catchall_48
    move-exception p0

    :try_start_49
    monitor-exit v0
    :try_end_4a
    .catchall {:try_start_49 .. :try_end_4a} :catchall_48

    throw p0
.end method

.method public static declared-synchronized m(Landroid/content/Context;)Landroidx/media3/datasource/cache/SimpleCache;
    .registers 5

    const-class v0, Lcom/vdocipher/aegis/core/j/b;

    monitor-enter v0

    .line 1
    :try_start_3
    sget-object v1, Lcom/vdocipher/aegis/core/j/b;->f:Landroidx/media3/datasource/cache/SimpleCache;

    if-nez v1, :cond_18

    .line 2
    new-instance v1, Ljava/io/File;

    .line 3
    invoke-static {p0}, Lcom/vdocipher/aegis/core/j/b;->h(Landroid/content/Context;)Ljava/io/File;

    move-result-object v2

    const-string v3, "cache"

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 4
    invoke-static {p0, v1}, Lcom/vdocipher/aegis/core/j/b;->a(Landroid/content/Context;Ljava/io/File;)Landroidx/media3/datasource/cache/SimpleCache;

    move-result-object p0

    sput-object p0, Lcom/vdocipher/aegis/core/j/b;->f:Landroidx/media3/datasource/cache/SimpleCache;

    .line 6
    :cond_18
    sget-object p0, Lcom/vdocipher/aegis/core/j/b;->f:Landroidx/media3/datasource/cache/SimpleCache;
    :try_end_1a
    .catchall {:try_start_3 .. :try_end_1a} :catchall_1c

    monitor-exit v0

    return-object p0

    :catchall_1c
    move-exception p0

    :try_start_1d
    monitor-exit v0
    :try_end_1e
    .catchall {:try_start_1d .. :try_end_1e} :catchall_1c

    throw p0
.end method

.method public static declared-synchronized n(Landroid/content/Context;)Lcom/vdocipher/aegis/core/z/f$a;
    .registers 4

    const-class v0, Lcom/vdocipher/aegis/core/j/b;

    monitor-enter v0

    .line 1
    :try_start_3
    sget-object v1, Lcom/vdocipher/aegis/core/j/b;->a:Lcom/vdocipher/aegis/core/z/f$a;

    if-nez v1, :cond_2c

    .line 2
    new-instance v1, Ljava/net/CookieManager;

    invoke-direct {v1}, Ljava/net/CookieManager;-><init>()V

    .line 3
    sget-object v2, Ljava/net/CookiePolicy;->ACCEPT_ORIGINAL_SERVER:Ljava/net/CookiePolicy;

    invoke-virtual {v1, v2}, Ljava/net/CookieManager;->setCookiePolicy(Ljava/net/CookiePolicy;)V

    .line 4
    invoke-static {v1}, Ljava/net/CookieHandler;->setDefault(Ljava/net/CookieHandler;)V

    .line 5
    new-instance v1, Lcom/vdocipher/aegis/core/z/e;

    invoke-direct {v1, p0}, Lcom/vdocipher/aegis/core/z/e;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/z/e;->a()Lorg/chromium/net/CronetEngine;

    move-result-object p0

    .line 6
    invoke-static {}, Lcom/vdocipher/aegis/core/t/d;->b()Ljava/lang/String;

    move-result-object v1

    .line 7
    new-instance v2, Lcom/vdocipher/aegis/core/z/f$a;

    invoke-direct {v2, p0}, Lcom/vdocipher/aegis/core/z/f$a;-><init>(Lorg/chromium/net/CronetEngine;)V

    invoke-virtual {v2, v1}, Lcom/vdocipher/aegis/core/z/f$a;->a(Ljava/lang/String;)Lcom/vdocipher/aegis/core/z/f$a;

    move-result-object p0

    sput-object p0, Lcom/vdocipher/aegis/core/j/b;->a:Lcom/vdocipher/aegis/core/z/f$a;

    .line 9
    :cond_2c
    sget-object p0, Lcom/vdocipher/aegis/core/j/b;->a:Lcom/vdocipher/aegis/core/z/f$a;
    :try_end_2e
    .catchall {:try_start_3 .. :try_end_2e} :catchall_30

    monitor-exit v0

    return-object p0

    :catchall_30
    move-exception p0

    :try_start_31
    monitor-exit v0
    :try_end_32
    .catchall {:try_start_31 .. :try_end_32} :catchall_30

    throw p0
.end method
