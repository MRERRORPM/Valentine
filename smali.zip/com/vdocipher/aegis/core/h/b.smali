# classes14.dex

.class public final Lcom/vdocipher/aegis/core/h/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lokhttp3/Interceptor;


# instance fields
.field private final a:Ljava/util/List;

.field private final b:Lcom/vdocipher/aegis/core/g/c;

.field private c:Z

.field private d:Ljava/util/List;


# direct methods
.method public constructor <init>(Ljava/util/List;Lcom/vdocipher/aegis/core/g/c;)V
    .registers 5

    const-string v0, "fallbackHostNames"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/h/b;->a:Ljava/util/List;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/h/b;->b:Lcom/vdocipher/aegis/core/g/c;

    const/16 p1, 0x1f4

    .line 5
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/16 p2, 0x1f6

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/16 v0, 0x1f7

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/16 v1, 0x1f8

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {p1, p2, v0, v1}, [Ljava/lang/Integer;

    move-result-object p1

    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/h/b;->d:Ljava/util/List;

    return-void
.end method

.method private final a(Lokhttp3/Interceptor$Chain;I)Lokhttp3/Response;
    .registers 15

    .line 1
    invoke-interface {p1}, Lokhttp3/Interceptor$Chain;->request()Lokhttp3/Request;

    move-result-object v0

    .line 2
    invoke-virtual {v0}, Lokhttp3/Request;->url()Lokhttp3/HttpUrl;

    move-result-object v1

    .line 5
    iget-boolean v2, p0, Lcom/vdocipher/aegis/core/h/b;->c:Z

    const/4 v3, 0x1

    if-eqz v2, :cond_6c

    .line 6
    iget-object v2, p0, Lcom/vdocipher/aegis/core/h/b;->a:Ljava/util/List;

    invoke-interface {v2, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    move-object v4, v2

    check-cast v4, Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v5, 0x0

    .line 11
    const-string v10, ":"

    const/4 v11, 0x0

    invoke-static {v4, v10, v11, v2, v5}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_46

    .line 12
    filled-new-array {v10}, [Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v9, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v4 .. v9}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[Ljava/lang/String;ZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 13
    filled-new-array {v10}, [Ljava/lang/String;

    move-result-object v5

    invoke-static/range {v4 .. v9}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[Ljava/lang/String;ZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v11

    move-object v4, v2

    .line 17
    :cond_46
    invoke-virtual {v1}, Lokhttp3/HttpUrl;->newBuilder()Lokhttp3/HttpUrl$Builder;

    move-result-object v1

    .line 18
    invoke-virtual {v1, v4}, Lokhttp3/HttpUrl$Builder;->host(Ljava/lang/String;)Lokhttp3/HttpUrl$Builder;

    move-result-object v1

    .line 19
    invoke-virtual {v1}, Lokhttp3/HttpUrl$Builder;->build()Lokhttp3/HttpUrl;

    move-result-object v1

    if-eqz v11, :cond_60

    .line 22
    invoke-virtual {v1}, Lokhttp3/HttpUrl;->newBuilder()Lokhttp3/HttpUrl$Builder;

    move-result-object v1

    invoke-virtual {v1, v11}, Lokhttp3/HttpUrl$Builder;->port(I)Lokhttp3/HttpUrl$Builder;

    move-result-object v1

    invoke-virtual {v1}, Lokhttp3/HttpUrl$Builder;->build()Lokhttp3/HttpUrl;

    move-result-object v1

    .line 25
    :cond_60
    invoke-virtual {v0}, Lokhttp3/Request;->newBuilder()Lokhttp3/Request$Builder;

    move-result-object v0

    .line 26
    invoke-virtual {v0, v1}, Lokhttp3/Request$Builder;->url(Lokhttp3/HttpUrl;)Lokhttp3/Request$Builder;

    move-result-object v0

    .line 27
    invoke-virtual {v0}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object v0

    :cond_6c
    move-object v1, v0

    .line 33
    :try_start_6d
    invoke-direct {p0, p1, v1}, Lcom/vdocipher/aegis/core/h/b;->a(Lokhttp3/Interceptor$Chain;Lokhttp3/Request;)Lokhttp3/Response;

    move-result-object v0
    :try_end_71
    .catch Ljava/io/IOException; {:try_start_6d .. :try_end_71} :catch_72

    goto :goto_95

    :catch_72
    move-exception v0

    .line 35
    instance-of v2, v0, Ljava/net/UnknownHostException;

    if-eqz v2, :cond_c8

    .line 37
    iget-object v2, p0, Lcom/vdocipher/aegis/core/h/b;->a:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    sub-int/2addr v2, v3

    if-ge p2, v2, :cond_b8

    .line 38
    iget-object v2, p0, Lcom/vdocipher/aegis/core/h/b;->b:Lcom/vdocipher/aegis/core/g/c;

    if-eqz v2, :cond_8f

    invoke-virtual {v1}, Lokhttp3/Request;->url()Lokhttp3/HttpUrl;

    move-result-object v1

    invoke-virtual {v1}, Lokhttp3/HttpUrl;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v1, v0}, Lcom/vdocipher/aegis/core/g/c;->a(Ljava/lang/String;Ljava/lang/Exception;)V

    :cond_8f
    add-int/lit8 v0, p2, 0x1

    .line 39
    invoke-direct {p0, p1, v0}, Lcom/vdocipher/aegis/core/h/b;->b(Lokhttp3/Interceptor$Chain;I)Lokhttp3/Response;

    move-result-object v0

    .line 51
    :goto_95
    iget-object v1, p0, Lcom/vdocipher/aegis/core/h/b;->d:Ljava/util/List;

    invoke-virtual {v0}, Lokhttp3/Response;->code()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_b7

    iget-object v1, p0, Lcom/vdocipher/aegis/core/h/b;->a:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    sub-int/2addr v1, v3

    if-ge p2, v1, :cond_b7

    .line 52
    invoke-static {v0}, Lokhttp3/internal/_UtilCommonKt;->closeQuietly(Ljava/io/Closeable;)V

    add-int/2addr p2, v3

    .line 53
    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/h/b;->b(Lokhttp3/Interceptor$Chain;I)Lokhttp3/Response;

    move-result-object p1

    return-object p1

    :cond_b7
    return-object v0

    .line 54
    :cond_b8
    iget-object p1, p0, Lcom/vdocipher/aegis/core/h/b;->b:Lcom/vdocipher/aegis/core/g/c;

    if-eqz p1, :cond_c7

    invoke-virtual {v1}, Lokhttp3/Request;->url()Lokhttp3/HttpUrl;

    move-result-object p2

    invoke-virtual {p2}, Lokhttp3/HttpUrl;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, p2, v0}, Lcom/vdocipher/aegis/core/g/c;->a(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 55
    :cond_c7
    throw v0

    .line 58
    :cond_c8
    iget-object p1, p0, Lcom/vdocipher/aegis/core/h/b;->b:Lcom/vdocipher/aegis/core/g/c;

    if-eqz p1, :cond_d7

    invoke-virtual {v1}, Lokhttp3/Request;->url()Lokhttp3/HttpUrl;

    move-result-object p2

    invoke-virtual {p2}, Lokhttp3/HttpUrl;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, p2, v0}, Lcom/vdocipher/aegis/core/g/c;->a(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 59
    :cond_d7
    throw v0
.end method

.method private final a(Lokhttp3/Interceptor$Chain;Lokhttp3/Request;)Lokhttp3/Response;
    .registers 11

    .line 60
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Failed after 2 retries"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v2, 0x0

    move-object v3, v2

    :goto_a
    const/4 v4, 0x2

    if-gt v1, v4, :cond_45

    if-eqz v3, :cond_12

    .line 63
    invoke-static {v3}, Lokhttp3/internal/_UtilCommonKt;->closeQuietly(Ljava/io/Closeable;)V

    :cond_12
    const/4 v5, 0x1

    .line 66
    :try_start_13
    invoke-interface {p1, p2}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Request;)Lokhttp3/Response;

    move-result-object v3

    .line 67
    iget-object v6, p0, Lcom/vdocipher/aegis/core/h/b;->d:Ljava/util/List;

    invoke-virtual {v3}, Lokhttp3/Response;->code()I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v6, v7}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_34

    add-int/lit8 v1, v1, 0x1

    if-gt v1, v4, :cond_34

    .line 71
    new-instance v4, Lcom/vdocipher/aegis/core/h/b$a;

    invoke-direct {v4, v2}, Lcom/vdocipher/aegis/core/h/b$a;-><init>(Lkotlin/coroutines/Continuation;)V

    invoke-static {v2, v4, v5, v2}, Lkotlinx/coroutines/BuildersKt;->runBlocking$default(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Ljava/lang/Object;
    :try_end_33
    .catch Ljava/io/IOException; {:try_start_13 .. :try_end_33} :catch_35

    goto :goto_a

    :cond_34
    return-object v3

    :catch_35
    move-exception v0

    if-eqz v3, :cond_3b

    .line 82
    invoke-static {v3}, Lokhttp3/internal/_UtilCommonKt;->closeQuietly(Ljava/io/Closeable;)V

    :cond_3b
    add-int/2addr v1, v5

    .line 85
    new-instance v4, Lcom/vdocipher/aegis/core/h/b$b;

    invoke-direct {v4, v2}, Lcom/vdocipher/aegis/core/h/b$b;-><init>(Lkotlin/coroutines/Continuation;)V

    invoke-static {v2, v4, v5, v2}, Lkotlinx/coroutines/BuildersKt;->runBlocking$default(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Ljava/lang/Object;

    goto :goto_a

    :cond_45
    if-eqz v3, :cond_48

    return-object v3

    .line 91
    :cond_48
    throw v0
.end method

.method private final b(Lokhttp3/Interceptor$Chain;I)Lokhttp3/Response;
    .registers 4

    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/h/b;->c:Z

    .line 2
    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/h/b;->a(Lokhttp3/Interceptor$Chain;I)Lokhttp3/Response;

    move-result-object p1

    return-object p1
.end method


# virtual methods
.method public intercept(Lokhttp3/Interceptor$Chain;)Lokhttp3/Response;
    .registers 3

    const-string v0, "chain"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, -0x1

    .line 1
    invoke-direct {p0, p1, v0}, Lcom/vdocipher/aegis/core/h/b;->a(Lokhttp3/Interceptor$Chain;I)Lokhttp3/Response;

    move-result-object p1

    return-object p1
.end method
