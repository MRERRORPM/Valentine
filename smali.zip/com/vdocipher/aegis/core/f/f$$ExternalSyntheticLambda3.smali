# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/f/f;

.field public final synthetic f$1:I

.field public final synthetic f$2:Ljava/lang/String;

.field public final synthetic f$3:J


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;J)V
    .registers 6

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda3;->f$0:Lcom/vdocipher/aegis/core/f/f;

    iput p2, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda3;->f$1:I

    iput-object p3, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda3;->f$2:Ljava/lang/String;

    iput-wide p4, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda3;->f$3:J

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 6

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda3;->f$0:Lcom/vdocipher/aegis/core/f/f;

    iget v1, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda3;->f$1:I

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda3;->f$2:Ljava/lang/String;

    iget-wide v3, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda3;->f$3:J

    invoke-static {v0, v1, v2, v3, v4}, Lcom/vdocipher/aegis/core/f/f;->$r8$lambda$OVqV3k4VH98IMCGqLqj7Qaq4KGI(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;J)V

    return-void
.end method
