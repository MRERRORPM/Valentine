# classes14.dex

.class Lcom/vdocipher/aegis/core/f/e$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vdocipher/aegis/core/g/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/f/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/f/e;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/f/e;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/e$a;->a:Lcom/vdocipher/aegis/core/f/e;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(ILjava/lang/String;)V
    .registers 4

    .line 1
    iget-object p1, p0, Lcom/vdocipher/aegis/core/f/e$a;->a:Lcom/vdocipher/aegis/core/f/e;

    iget-object v0, p1, Lcom/vdocipher/aegis/core/f/e;->a:Landroid/content/Context;

    invoke-virtual {p1, v0, p2}, Lcom/vdocipher/aegis/core/f/e;->a(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method public a(Ljava/io/IOException;)V
    .registers 2

    return-void
.end method

.method public b(ILjava/lang/String;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/e$a;->a:Lcom/vdocipher/aegis/core/f/e;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/f/e;->b:Ljava/lang/String;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    filled-new-array {p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    const-string p2, "Error response: %s (%s)"

    invoke-static {p2, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method
