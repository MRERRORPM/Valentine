# classes14.dex

.class public final Lcom/vdocipher/aegis/core/f/i;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/lang/String;

.field private final c:Lcom/vdocipher/aegis/core/f/h;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/f/h;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/i;->a:Ljava/lang/String;

    .line 4
    iput-object p2, p0, Lcom/vdocipher/aegis/core/f/i;->b:Ljava/lang/String;

    .line 5
    iput-object p3, p0, Lcom/vdocipher/aegis/core/f/i;->c:Lcom/vdocipher/aegis/core/f/h;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/f/h;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 46

    and-int/lit8 v0, p4, 0x1

    const-string v1, ""

    if-eqz v0, :cond_8

    move-object v0, v1

    goto :goto_a

    :cond_8
    move-object/from16 v0, p1

    :goto_a
    and-int/lit8 v2, p4, 0x2

    if-eqz v2, :cond_f

    goto :goto_11

    :cond_f
    move-object/from16 v1, p2

    :goto_11
    and-int/lit8 v2, p4, 0x4

    if-eqz v2, :cond_57

    .line 8
    new-instance v3, Lcom/vdocipher/aegis/core/f/h;

    const/16 v38, 0x1

    const/16 v39, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, -0x1

    invoke-direct/range {v3 .. v39}, Lcom/vdocipher/aegis/core/f/h;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;ZLjava/util/ArrayList;Ljava/util/ArrayList;Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;Lcom/vdocipher/aegis/core/f/a;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    goto :goto_59

    :cond_57
    move-object/from16 v3, p3

    :goto_59
    move-object/from16 v2, p0

    .line 9
    invoke-direct {v2, v0, v1, v3}, Lcom/vdocipher/aegis/core/f/i;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/f/h;)V

    return-void
.end method


# virtual methods
.method public final a()Lcom/vdocipher/aegis/core/f/h;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/i;->c:Lcom/vdocipher/aegis/core/f/h;

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    .line 1
    :cond_4
    instance-of v1, p1, Lcom/vdocipher/aegis/core/f/i;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/vdocipher/aegis/core/f/i;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/i;->a:Ljava/lang/String;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/i;->a:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/i;->b:Ljava/lang/String;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/i;->b:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    return v2

    :cond_22
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/i;->c:Lcom/vdocipher/aegis/core/f/h;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/f/i;->c:Lcom/vdocipher/aegis/core/f/h;

    invoke-static {v1, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_2d

    return v2

    :cond_2d
    return v0
.end method

.method public hashCode()I
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/i;->a:Ljava/lang/String;

    const/4 v1, 0x0

    if-nez v0, :cond_7

    move v0, v1

    goto :goto_b

    :cond_7
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    :goto_b
    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/i;->b:Ljava/lang/String;

    if-nez v2, :cond_13

    move v2, v1

    goto :goto_17

    :cond_13
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_17
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/i;->c:Lcom/vdocipher/aegis/core/f/h;

    if-nez v2, :cond_1f

    goto :goto_23

    :cond_1f
    invoke-virtual {v2}, Lcom/vdocipher/aegis/core/f/h;->hashCode()I

    move-result v1

    :goto_23
    add-int/2addr v0, v1

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "PlayerConfig(id="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/i;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", theme="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/i;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", options="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/i;->c:Lcom/vdocipher/aegis/core/f/h;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
