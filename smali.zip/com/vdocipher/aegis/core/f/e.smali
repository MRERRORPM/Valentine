# classes14.dex

.class public final Lcom/vdocipher/aegis/core/f/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field a:Landroid/content/Context;

.field b:Ljava/lang/String;

.field c:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

.field d:Lcom/vdocipher/aegis/core/g/e;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    const-string v0, "LanguageFetcher"

    iput-object v0, p0, Lcom/vdocipher/aegis/core/f/e;->b:Ljava/lang/String;

    .line 25
    new-instance v0, Lcom/vdocipher/aegis/core/f/e$a;

    invoke-direct {v0, p0}, Lcom/vdocipher/aegis/core/f/e$a;-><init>(Lcom/vdocipher/aegis/core/f/e;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/f/e;->d:Lcom/vdocipher/aegis/core/g/e;

    .line 26
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/e;->a:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;Ljava/lang/String;)V
    .registers 5

    .line 12
    invoke-static {p1}, Lcom/vdocipher/aegis/core/z/b;->a(Landroid/content/Context;)Lcom/vdocipher/aegis/core/z/b;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/e;->c:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-virtual {v1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getHash()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, p1, p2, v1}, Lcom/vdocipher/aegis/core/z/b;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 13
    invoke-static {p1}, Lcom/vdocipher/aegis/core/z/b;->a(Landroid/content/Context;)Lcom/vdocipher/aegis/core/z/b;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/vdocipher/aegis/core/z/b;->a(Landroid/content/Context;Ljava/lang/String;)V

    .line 14
    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/c;->a(Landroid/content/Context;)Lcom/vdocipher/aegis/core/t/c;

    move-result-object p1

    iget-object p2, p0, Lcom/vdocipher/aegis/core/f/e;->c:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    invoke-virtual {p1, p2}, Lcom/vdocipher/aegis/core/t/c;->a(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V

    return-void
.end method

.method public a(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)V
    .registers 4

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/e;->c:Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    .line 3
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getId()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_d

    return-void

    .line 5
    :cond_d
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "https://meta.vdocipher.com/api/meta/language/"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->getId()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 7
    new-instance v0, Lcom/vdocipher/aegis/core/g/b;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/e;->a:Landroid/content/Context;

    invoke-direct {v0, v1}, Lcom/vdocipher/aegis/core/g/b;-><init>(Landroid/content/Context;)V

    .line 9
    :try_start_26
    new-instance v1, Ljava/net/URL;

    invoke-direct {v1, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    iget-object p1, p0, Lcom/vdocipher/aegis/core/f/e;->d:Lcom/vdocipher/aegis/core/g/e;

    invoke-virtual {v0, v1, p1}, Lcom/vdocipher/aegis/core/g/b;->a(Ljava/net/URL;Lcom/vdocipher/aegis/core/g/e;)V
    :try_end_30
    .catch Ljava/net/MalformedURLException; {:try_start_26 .. :try_end_30} :catch_31

    return-void

    :catch_31
    move-exception p1

    .line 11
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/e;->b:Ljava/lang/String;

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method
