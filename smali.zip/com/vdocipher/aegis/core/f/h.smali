# classes14.dex

.class public final Lcom/vdocipher/aegis/core/f/h;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final A:Ljava/lang/Boolean;

.field private final B:Ljava/lang/Boolean;

.field private final C:Z

.field private final D:Ljava/util/ArrayList;

.field private final E:Ljava/util/ArrayList;

.field private final F:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

.field private final G:Lcom/vdocipher/aegis/core/f/a;

.field private final a:Ljava/lang/String;

.field private final b:Ljava/lang/Boolean;

.field private final c:Ljava/lang/Boolean;

.field private final d:Ljava/lang/Boolean;

.field private final e:Ljava/lang/Boolean;

.field private final f:Ljava/lang/Boolean;

.field private final g:Ljava/lang/Boolean;

.field private final h:Ljava/lang/Boolean;

.field private final i:Ljava/lang/Boolean;

.field private final j:Ljava/lang/Boolean;

.field private final k:Ljava/lang/Boolean;

.field private final l:Ljava/lang/Boolean;

.field private final m:Ljava/lang/Boolean;

.field private final n:Ljava/lang/Boolean;

.field private final o:Ljava/lang/Boolean;

.field private final p:Ljava/lang/Boolean;

.field private final q:Ljava/lang/Boolean;

.field private final r:Ljava/lang/Boolean;

.field private final s:Ljava/lang/Integer;

.field private final t:Ljava/lang/Boolean;

.field private final u:Ljava/lang/Boolean;

.field private final v:Ljava/lang/Boolean;

.field private final w:Ljava/lang/Boolean;

.field private final x:Ljava/lang/Boolean;

.field private final y:Ljava/lang/Boolean;

.field private final z:Ljava/lang/Boolean;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;ZLjava/util/ArrayList;Ljava/util/ArrayList;Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;Lcom/vdocipher/aegis/core/f/a;)V
    .registers 38

    move-object/from16 v0, p30

    move-object/from16 v1, p31

    move-object/from16 v2, p32

    const-string v3, "collapseInSettings"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "playbackSpeedOptions"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "qualityTrackLabel"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->a:Ljava/lang/String;

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/f/h;->b:Ljava/lang/Boolean;

    .line 4
    iput-object p3, p0, Lcom/vdocipher/aegis/core/f/h;->c:Ljava/lang/Boolean;

    .line 5
    iput-object p4, p0, Lcom/vdocipher/aegis/core/f/h;->d:Ljava/lang/Boolean;

    .line 6
    iput-object p5, p0, Lcom/vdocipher/aegis/core/f/h;->e:Ljava/lang/Boolean;

    .line 7
    iput-object p6, p0, Lcom/vdocipher/aegis/core/f/h;->f:Ljava/lang/Boolean;

    .line 8
    iput-object p7, p0, Lcom/vdocipher/aegis/core/f/h;->g:Ljava/lang/Boolean;

    .line 9
    iput-object p8, p0, Lcom/vdocipher/aegis/core/f/h;->h:Ljava/lang/Boolean;

    .line 10
    iput-object p9, p0, Lcom/vdocipher/aegis/core/f/h;->i:Ljava/lang/Boolean;

    .line 11
    iput-object p10, p0, Lcom/vdocipher/aegis/core/f/h;->j:Ljava/lang/Boolean;

    .line 12
    iput-object p11, p0, Lcom/vdocipher/aegis/core/f/h;->k:Ljava/lang/Boolean;

    move-object/from16 p1, p12

    .line 13
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->l:Ljava/lang/Boolean;

    move-object/from16 p1, p13

    .line 14
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->m:Ljava/lang/Boolean;

    move-object/from16 p1, p14

    .line 15
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->n:Ljava/lang/Boolean;

    move-object/from16 p1, p15

    .line 16
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->o:Ljava/lang/Boolean;

    move-object/from16 p1, p16

    .line 17
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->p:Ljava/lang/Boolean;

    move-object/from16 p1, p17

    .line 18
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->q:Ljava/lang/Boolean;

    move-object/from16 p1, p18

    .line 19
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->r:Ljava/lang/Boolean;

    move-object/from16 p1, p19

    .line 20
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->s:Ljava/lang/Integer;

    move-object/from16 p1, p20

    .line 21
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->t:Ljava/lang/Boolean;

    move-object/from16 p1, p21

    .line 22
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->u:Ljava/lang/Boolean;

    move-object/from16 p1, p22

    .line 23
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->v:Ljava/lang/Boolean;

    move-object/from16 p1, p23

    .line 24
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->w:Ljava/lang/Boolean;

    move-object/from16 p1, p24

    .line 25
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->x:Ljava/lang/Boolean;

    move-object/from16 p1, p25

    .line 26
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->y:Ljava/lang/Boolean;

    move-object/from16 p1, p26

    .line 27
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->z:Ljava/lang/Boolean;

    move-object/from16 p1, p27

    .line 28
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->A:Ljava/lang/Boolean;

    move-object/from16 p1, p28

    .line 29
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->B:Ljava/lang/Boolean;

    move/from16 p1, p29

    .line 30
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/f/h;->C:Z

    .line 31
    iput-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->D:Ljava/util/ArrayList;

    .line 32
    iput-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->E:Ljava/util/ArrayList;

    .line 33
    iput-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->F:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    move-object/from16 p1, p33

    .line 34
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/h;->G:Lcom/vdocipher/aegis/core/f/a;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;ZLjava/util/ArrayList;Ljava/util/ArrayList;Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;Lcom/vdocipher/aegis/core/f/a;IILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 70

    move/from16 v0, p34

    and-int/lit8 v1, v0, 0x1

    if-eqz v1, :cond_9

    .line 35
    const-string v1, ""

    goto :goto_b

    :cond_9
    move-object/from16 v1, p1

    :goto_b
    and-int/lit8 v2, v0, 0x2

    if-eqz v2, :cond_12

    .line 36
    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_14

    :cond_12
    move-object/from16 v2, p2

    :goto_14
    and-int/lit8 v3, v0, 0x4

    if-eqz v3, :cond_1b

    .line 37
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_1d

    :cond_1b
    move-object/from16 v3, p3

    :goto_1d
    and-int/lit8 v4, v0, 0x8

    if-eqz v4, :cond_24

    .line 38
    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_26

    :cond_24
    move-object/from16 v4, p4

    :goto_26
    and-int/lit8 v5, v0, 0x10

    if-eqz v5, :cond_2d

    .line 39
    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_2f

    :cond_2d
    move-object/from16 v5, p5

    :goto_2f
    and-int/lit8 v6, v0, 0x20

    if-eqz v6, :cond_36

    .line 40
    sget-object v6, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_38

    :cond_36
    move-object/from16 v6, p6

    :goto_38
    and-int/lit8 v7, v0, 0x40

    if-eqz v7, :cond_3f

    .line 41
    sget-object v7, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_41

    :cond_3f
    move-object/from16 v7, p7

    :goto_41
    and-int/lit16 v8, v0, 0x80

    if-eqz v8, :cond_48

    .line 42
    sget-object v8, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_4a

    :cond_48
    move-object/from16 v8, p8

    :goto_4a
    and-int/lit16 v9, v0, 0x100

    if-eqz v9, :cond_51

    .line 43
    sget-object v9, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_53

    :cond_51
    move-object/from16 v9, p9

    :goto_53
    and-int/lit16 v10, v0, 0x200

    if-eqz v10, :cond_5a

    .line 44
    sget-object v10, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_5c

    :cond_5a
    move-object/from16 v10, p10

    :goto_5c
    and-int/lit16 v11, v0, 0x400

    if-eqz v11, :cond_63

    .line 45
    sget-object v11, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_65

    :cond_63
    move-object/from16 v11, p11

    :goto_65
    and-int/lit16 v12, v0, 0x800

    if-eqz v12, :cond_6c

    .line 46
    sget-object v12, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_6e

    :cond_6c
    move-object/from16 v12, p12

    :goto_6e
    and-int/lit16 v13, v0, 0x1000

    if-eqz v13, :cond_75

    .line 47
    sget-object v13, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_77

    :cond_75
    move-object/from16 v13, p13

    :goto_77
    and-int/lit16 v14, v0, 0x2000

    if-eqz v14, :cond_7e

    .line 48
    sget-object v14, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_80

    :cond_7e
    move-object/from16 v14, p14

    :goto_80
    and-int/lit16 v15, v0, 0x4000

    if-eqz v15, :cond_87

    .line 49
    sget-object v15, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_89

    :cond_87
    move-object/from16 v15, p15

    :goto_89
    const v16, 0x8000

    and-int v16, v0, v16

    if-eqz v16, :cond_93

    .line 50
    sget-object v16, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_95

    :cond_93
    move-object/from16 v16, p16

    :goto_95
    const/high16 v17, 0x10000

    and-int v17, v0, v17

    if-eqz v17, :cond_9e

    .line 51
    sget-object v17, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_a0

    :cond_9e
    move-object/from16 v17, p17

    :goto_a0
    const/high16 v18, 0x20000

    and-int v18, v0, v18

    if-eqz v18, :cond_a9

    .line 52
    sget-object v18, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_ab

    :cond_a9
    move-object/from16 v18, p18

    :goto_ab
    const/high16 v19, 0x40000

    and-int v19, v0, v19

    if-eqz v19, :cond_b8

    const/16 v19, 0x2710

    .line 53
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v19

    goto :goto_ba

    :cond_b8
    move-object/from16 v19, p19

    :goto_ba
    const/high16 v20, 0x80000

    and-int v20, v0, v20

    if-eqz v20, :cond_c3

    .line 54
    sget-object v20, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_c5

    :cond_c3
    move-object/from16 v20, p20

    :goto_c5
    const/high16 v21, 0x100000

    and-int v21, v0, v21

    if-eqz v21, :cond_ce

    .line 55
    sget-object v21, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_d0

    :cond_ce
    move-object/from16 v21, p21

    :goto_d0
    const/high16 v22, 0x200000

    and-int v22, v0, v22

    if-eqz v22, :cond_d9

    .line 56
    sget-object v22, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    goto :goto_db

    :cond_d9
    move-object/from16 v22, p22

    :goto_db
    const/high16 v23, 0x400000

    and-int v23, v0, v23

    if-eqz v23, :cond_e4

    .line 57
    sget-object v23, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_e6

    :cond_e4
    move-object/from16 v23, p23

    :goto_e6
    const/high16 v24, 0x800000

    and-int v24, v0, v24

    if-eqz v24, :cond_ef

    .line 58
    sget-object v24, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_f1

    :cond_ef
    move-object/from16 v24, p24

    :goto_f1
    const/high16 v25, 0x1000000

    and-int v25, v0, v25

    if-eqz v25, :cond_fa

    .line 59
    sget-object v25, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_fc

    :cond_fa
    move-object/from16 v25, p25

    :goto_fc
    const/high16 v26, 0x2000000

    and-int v26, v0, v26

    if-eqz v26, :cond_105

    .line 60
    sget-object v26, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_107

    :cond_105
    move-object/from16 v26, p26

    :goto_107
    const/high16 v27, 0x4000000

    and-int v27, v0, v27

    if-eqz v27, :cond_110

    .line 61
    sget-object v27, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_112

    :cond_110
    move-object/from16 v27, p27

    :goto_112
    const/high16 v28, 0x8000000

    and-int v28, v0, v28

    if-eqz v28, :cond_11b

    .line 62
    sget-object v28, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    goto :goto_11d

    :cond_11b
    move-object/from16 v28, p28

    :goto_11d
    const/high16 v29, 0x10000000

    and-int v29, v0, v29

    if-eqz v29, :cond_126

    const/16 v29, 0x0

    goto :goto_128

    :cond_126
    move/from16 v29, p29

    :goto_128
    const/high16 v30, 0x20000000

    and-int v30, v0, v30

    if-eqz v30, :cond_134

    .line 64
    new-instance v30, Ljava/util/ArrayList;

    invoke-direct/range {v30 .. v30}, Ljava/util/ArrayList;-><init>()V

    goto :goto_136

    :cond_134
    move-object/from16 v30, p30

    :goto_136
    const/high16 v31, 0x40000000  # 2.0f

    and-int v31, v0, v31

    if-eqz v31, :cond_142

    .line 65
    new-instance v31, Ljava/util/ArrayList;

    invoke-direct/range {v31 .. v31}, Ljava/util/ArrayList;-><init>()V

    goto :goto_144

    :cond_142
    move-object/from16 v31, p31

    :goto_144
    const/high16 v32, -0x80000000

    and-int v0, v0, v32

    if-eqz v0, :cond_155

    .line 66
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->newBuilder()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    goto :goto_157

    :cond_155
    move-object/from16 v0, p32

    :goto_157
    and-int/lit8 v32, p35, 0x1

    if-eqz v32, :cond_160

    const/16 v32, 0x0

    move-object/from16 p34, v32

    goto :goto_162

    :cond_160
    move-object/from16 p34, p33

    :goto_162
    move-object/from16 p1, p0

    move-object/from16 p33, v0

    move-object/from16 p2, v1

    move-object/from16 p3, v2

    move-object/from16 p4, v3

    move-object/from16 p5, v4

    move-object/from16 p6, v5

    move-object/from16 p7, v6

    move-object/from16 p8, v7

    move-object/from16 p9, v8

    move-object/from16 p10, v9

    move-object/from16 p11, v10

    move-object/from16 p12, v11

    move-object/from16 p13, v12

    move-object/from16 p14, v13

    move-object/from16 p15, v14

    move-object/from16 p16, v15

    move-object/from16 p17, v16

    move-object/from16 p18, v17

    move-object/from16 p19, v18

    move-object/from16 p20, v19

    move-object/from16 p21, v20

    move-object/from16 p22, v21

    move-object/from16 p23, v22

    move-object/from16 p24, v23

    move-object/from16 p25, v24

    move-object/from16 p26, v25

    move-object/from16 p27, v26

    move-object/from16 p28, v27

    move-object/from16 p29, v28

    move/from16 p30, v29

    move-object/from16 p31, v30

    move-object/from16 p32, v31

    .line 67
    invoke-direct/range {p1 .. p34}, Lcom/vdocipher/aegis/core/f/h;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;ZLjava/util/ArrayList;Ljava/util/ArrayList;Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;Lcom/vdocipher/aegis/core/f/a;)V

    return-void
.end method


# virtual methods
.method public final A()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->b:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final B()Ljava/lang/Integer;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->s:Ljava/lang/Integer;

    return-object v0
.end method

.method public final a()Lcom/vdocipher/aegis/core/f/a;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->G:Lcom/vdocipher/aegis/core/f/a;

    return-object v0
.end method

.method public final b()Ljava/util/ArrayList;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->D:Ljava/util/ArrayList;

    return-object v0
.end method

.method public final c()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->z:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final d()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->B:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final e()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->A:Ljava/lang/Boolean;

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    .line 1
    :cond_4
    instance-of v1, p1, Lcom/vdocipher/aegis/core/f/h;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/vdocipher/aegis/core/f/h;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->a:Ljava/lang/String;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->a:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->b:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->b:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    return v2

    :cond_22
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->c:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->c:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2d

    return v2

    :cond_2d
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->d:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->d:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_38

    return v2

    :cond_38
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->e:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->e:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_43

    return v2

    :cond_43
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->f:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->f:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4e

    return v2

    :cond_4e
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->g:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->g:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_59

    return v2

    :cond_59
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->h:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->h:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_64

    return v2

    :cond_64
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->i:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->i:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6f

    return v2

    :cond_6f
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->j:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->j:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7a

    return v2

    :cond_7a
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->k:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->k:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_85

    return v2

    :cond_85
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->l:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->l:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_90

    return v2

    :cond_90
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->m:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->m:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9b

    return v2

    :cond_9b
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->n:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->n:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a6

    return v2

    :cond_a6
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->o:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->o:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b1

    return v2

    :cond_b1
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->p:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->p:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_bc

    return v2

    :cond_bc
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->q:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->q:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c7

    return v2

    :cond_c7
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->r:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->r:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d2

    return v2

    :cond_d2
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->s:Ljava/lang/Integer;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->s:Ljava/lang/Integer;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_dd

    return v2

    :cond_dd
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->t:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->t:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e8

    return v2

    :cond_e8
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->u:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->u:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_f3

    return v2

    :cond_f3
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->v:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->v:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_fe

    return v2

    :cond_fe
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->w:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->w:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_109

    return v2

    :cond_109
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->x:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->x:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_114

    return v2

    :cond_114
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->y:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->y:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_11f

    return v2

    :cond_11f
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->z:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->z:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_12a

    return v2

    :cond_12a
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->A:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->A:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_135

    return v2

    :cond_135
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->B:Ljava/lang/Boolean;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->B:Ljava/lang/Boolean;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_140

    return v2

    :cond_140
    iget-boolean v1, p0, Lcom/vdocipher/aegis/core/f/h;->C:Z

    iget-boolean v3, p1, Lcom/vdocipher/aegis/core/f/h;->C:Z

    if-eq v1, v3, :cond_147

    return v2

    :cond_147
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->D:Ljava/util/ArrayList;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->D:Ljava/util/ArrayList;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_152

    return v2

    :cond_152
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->E:Ljava/util/ArrayList;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->E:Ljava/util/ArrayList;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_15d

    return v2

    :cond_15d
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->F:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/f/h;->F:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_168

    return v2

    :cond_168
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->G:Lcom/vdocipher/aegis/core/f/a;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/f/h;->G:Lcom/vdocipher/aegis/core/f/a;

    invoke-static {v1, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_173

    return v2

    :cond_173
    return v0
.end method

.method public final f()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->p:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final g()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->h:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final h()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->x:Ljava/lang/Boolean;

    return-object v0
.end method

.method public hashCode()I
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->a:Ljava/lang/String;

    const/4 v1, 0x0

    if-nez v0, :cond_7

    move v0, v1

    goto :goto_b

    :cond_7
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    :goto_b
    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->b:Ljava/lang/Boolean;

    if-nez v2, :cond_13

    move v2, v1

    goto :goto_17

    :cond_13
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_17
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->c:Ljava/lang/Boolean;

    if-nez v2, :cond_20

    move v2, v1

    goto :goto_24

    :cond_20
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_24
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->d:Ljava/lang/Boolean;

    if-nez v2, :cond_2d

    move v2, v1

    goto :goto_31

    :cond_2d
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_31
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->e:Ljava/lang/Boolean;

    if-nez v2, :cond_3a

    move v2, v1

    goto :goto_3e

    :cond_3a
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_3e
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->f:Ljava/lang/Boolean;

    if-nez v2, :cond_47

    move v2, v1

    goto :goto_4b

    :cond_47
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_4b
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->g:Ljava/lang/Boolean;

    if-nez v2, :cond_54

    move v2, v1

    goto :goto_58

    :cond_54
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_58
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->h:Ljava/lang/Boolean;

    if-nez v2, :cond_61

    move v2, v1

    goto :goto_65

    :cond_61
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_65
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->i:Ljava/lang/Boolean;

    if-nez v2, :cond_6e

    move v2, v1

    goto :goto_72

    :cond_6e
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_72
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->j:Ljava/lang/Boolean;

    if-nez v2, :cond_7b

    move v2, v1

    goto :goto_7f

    :cond_7b
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_7f
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->k:Ljava/lang/Boolean;

    if-nez v2, :cond_88

    move v2, v1

    goto :goto_8c

    :cond_88
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_8c
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->l:Ljava/lang/Boolean;

    if-nez v2, :cond_95

    move v2, v1

    goto :goto_99

    :cond_95
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_99
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->m:Ljava/lang/Boolean;

    if-nez v2, :cond_a2

    move v2, v1

    goto :goto_a6

    :cond_a2
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_a6
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->n:Ljava/lang/Boolean;

    if-nez v2, :cond_af

    move v2, v1

    goto :goto_b3

    :cond_af
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_b3
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->o:Ljava/lang/Boolean;

    if-nez v2, :cond_bc

    move v2, v1

    goto :goto_c0

    :cond_bc
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_c0
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->p:Ljava/lang/Boolean;

    if-nez v2, :cond_c9

    move v2, v1

    goto :goto_cd

    :cond_c9
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_cd
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->q:Ljava/lang/Boolean;

    if-nez v2, :cond_d6

    move v2, v1

    goto :goto_da

    :cond_d6
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_da
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->r:Ljava/lang/Boolean;

    if-nez v2, :cond_e3

    move v2, v1

    goto :goto_e7

    :cond_e3
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_e7
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->s:Ljava/lang/Integer;

    if-nez v2, :cond_f0

    move v2, v1

    goto :goto_f4

    :cond_f0
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_f4
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->t:Ljava/lang/Boolean;

    if-nez v2, :cond_fd

    move v2, v1

    goto :goto_101

    :cond_fd
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_101
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->u:Ljava/lang/Boolean;

    if-nez v2, :cond_10a

    move v2, v1

    goto :goto_10e

    :cond_10a
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_10e
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->v:Ljava/lang/Boolean;

    if-nez v2, :cond_117

    move v2, v1

    goto :goto_11b

    :cond_117
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_11b
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->w:Ljava/lang/Boolean;

    if-nez v2, :cond_124

    move v2, v1

    goto :goto_128

    :cond_124
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_128
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->x:Ljava/lang/Boolean;

    if-nez v2, :cond_131

    move v2, v1

    goto :goto_135

    :cond_131
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_135
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->y:Ljava/lang/Boolean;

    if-nez v2, :cond_13e

    move v2, v1

    goto :goto_142

    :cond_13e
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_142
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->z:Ljava/lang/Boolean;

    if-nez v2, :cond_14b

    move v2, v1

    goto :goto_14f

    :cond_14b
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_14f
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->A:Ljava/lang/Boolean;

    if-nez v2, :cond_158

    move v2, v1

    goto :goto_15c

    :cond_158
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_15c
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->B:Ljava/lang/Boolean;

    if-nez v2, :cond_165

    move v2, v1

    goto :goto_169

    :cond_165
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_169
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-boolean v2, p0, Lcom/vdocipher/aegis/core/f/h;->C:Z

    invoke-static {v2}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->D:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->hashCode()I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->E:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->hashCode()I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->F:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/h;->G:Lcom/vdocipher/aegis/core/f/a;

    if-nez v2, :cond_195

    goto :goto_199

    :cond_195
    invoke-virtual {v2}, Lcom/vdocipher/aegis/core/f/a;->hashCode()I

    move-result v1

    :goto_199
    add-int/2addr v0, v1

    return v0
.end method

.method public final i()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->n:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final j()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->r:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final k()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->m:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final l()Ljava/util/ArrayList;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->E:Ljava/util/ArrayList;

    return-object v0
.end method

.method public final m()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->F:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object v0
.end method

.method public final n()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->l:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final o()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->g:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final p()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->y:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final q()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->v:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final r()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/f/h;->C:Z

    return v0
.end method

.method public final s()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->k:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final t()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->i:Ljava/lang/Boolean;

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Options(primaryColor="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", showTimeText="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->b:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", showPlayPauseBtn="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->c:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", showProgressBar="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->d:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", showSpeedControl="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->e:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", showQualityControl="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->f:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", showCaptionsControl="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->g:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", enableCaptionSearch="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->h:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", showFullScreen="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->i:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", showVolume="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->j:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", showForward="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->k:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", showBackward="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->l:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", hideControlsOnPause="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->m:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", enableLockControls="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->n:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", enableDoubleTapSkip="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->o:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", enableAutoResume="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->p:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", confirmBeforeAutoResume="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->q:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", enableSaveOffline="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->r:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", skipDuration="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->s:Ljava/lang/Integer;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", showReplayAtEnd="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->t:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", showScrubbingPreview="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->u:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", showChapters="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->v:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", enablePip="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->w:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", enableChromecast="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->x:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", showCastWhenDeviceReady="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->y:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", conserveQualityAcrossSession="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->z:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", conserveSpeedAcrossSession="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->A:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", conserveSelectedCaptionLanguage="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->B:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", showClearStorageOption="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Lcom/vdocipher/aegis/core/f/h;->C:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", collapseInSettings="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->D:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", playbackSpeedOptions="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->E:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", qualityTrackLabel="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->F:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", captionGlobalStyle="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/h;->G:Lcom/vdocipher/aegis/core/f/a;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final u()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->c:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final v()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->d:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final w()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->f:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final x()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->t:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final y()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->u:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final z()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/h;->e:Ljava/lang/Boolean;

    return-object v0
.end method
