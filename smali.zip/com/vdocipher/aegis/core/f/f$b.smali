# classes14.dex

.class public interface abstract Lcom/vdocipher/aegis/core/f/f$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/f/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract onMetaNotReceived(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;Ljava/lang/String;)V
.end method

.method public abstract onMetaReceived(Ljava/lang/Object;ILjava/lang/String;JLjava/lang/String;Ljava/lang/String;)V
.end method

.method public abstract onMetaUrlFailed(Ljava/lang/Object;ILjava/lang/String;ZLjava/lang/String;)V
.end method
