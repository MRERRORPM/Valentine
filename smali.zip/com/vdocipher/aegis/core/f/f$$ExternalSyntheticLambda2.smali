# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/f/f;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/f/f;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/f/f;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/f/f;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/f/f;->$r8$lambda$6TzOaM61GMAAcbrS_fYeMPo4NnU(Lcom/vdocipher/aegis/core/f/f;)V

    return-void
.end method
