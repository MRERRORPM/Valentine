# classes14.dex

.class Lcom/vdocipher/aegis/core/f/f$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vdocipher/aegis/core/g/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/vdocipher/aegis/core/f/f;->a()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:Lcom/vdocipher/aegis/core/f/f;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/f/f;J)V
    .registers 4

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/f$a;->b:Lcom/vdocipher/aegis/core/f/f;

    iput-wide p2, p0, Lcom/vdocipher/aegis/core/f/f$a;->a:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(ILjava/lang/String;)V
    .registers 7

    .line 1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, Lcom/vdocipher/aegis/core/f/f$a;->a:J

    sub-long/2addr v0, v2

    .line 2
    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/f$a;->b:Lcom/vdocipher/aegis/core/f/f;

    invoke-static {v2, p1, p2, v0, v1}, Lcom/vdocipher/aegis/core/f/f;->a(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;J)V

    return-void
.end method

.method public a(Ljava/io/IOException;)V
    .registers 6

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/f$a;->b:Lcom/vdocipher/aegis/core/f/f;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/f/f;->a(Lcom/vdocipher/aegis/core/f/f;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v3, -0x1

    invoke-static {v0, v3, v1, v2}, Lcom/vdocipher/aegis/core/f/f;->a(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;Ljava/lang/String;)V

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/f$a;->b:Lcom/vdocipher/aegis/core/f/f;

    const/4 v1, 0x0

    invoke-static {v0, v3, v1, p1}, Lcom/vdocipher/aegis/core/f/f;->a(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method

.method public b(ILjava/lang/String;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/f$a;->b:Lcom/vdocipher/aegis/core/f/f;

    const/4 v1, 0x0

    invoke-static {v0, p1, p2, v1}, Lcom/vdocipher/aegis/core/f/f;->a(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
