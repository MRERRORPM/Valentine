# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/f/f;

.field public final synthetic f$1:I

.field public final synthetic f$2:Ljava/lang/String;

.field public final synthetic f$3:Ljava/lang/Throwable;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;Ljava/lang/Throwable;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/f/f;

    iput p2, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda0;->f$1:I

    iput-object p3, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda0;->f$2:Ljava/lang/String;

    iput-object p4, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda0;->f$3:Ljava/lang/Throwable;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/f/f;

    iget v1, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda0;->f$1:I

    iget-object v2, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda0;->f$2:Ljava/lang/String;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda0;->f$3:Ljava/lang/Throwable;

    invoke-static {v0, v1, v2, v3}, Lcom/vdocipher/aegis/core/f/f;->$r8$lambda$5V5QHUrjDbKKYQ39x_AvCpOLnxs(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
