# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lcom/vdocipher/aegis/core/g/c;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/f/f;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/f/f;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda4;->f$0:Lcom/vdocipher/aegis/core/f/f;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;Ljava/lang/Exception;)V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda4;->f$0:Lcom/vdocipher/aegis/core/f/f;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/aegis/core/f/f;->$r8$lambda$oc2EQrLt2ZIvI0DSAZjoK52_ce8(Lcom/vdocipher/aegis/core/f/f;Ljava/lang/String;Ljava/lang/Exception;)V

    return-void
.end method
