# classes14.dex

.class public final Lcom/vdocipher/aegis/core/f/g;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:Lcom/vdocipher/PlaybackInfo$MetadataTable;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    :try_start_3
    sget-object v0, Lcom/vdocipher/aegis/core/z/d;->a:Lcom/vdocipher/aegis/core/z/d;

    invoke-virtual {v0, p1}, Lcom/vdocipher/aegis/core/z/d;->e(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_12

    .line 5
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/f/g;->f(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-void

    .line 7
    :cond_12
    invoke-static {}, Lcom/google/common/io/BaseEncoding;->base64()Lcom/google/common/io/BaseEncoding;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/google/common/io/BaseEncoding;->decode(Ljava/lang/CharSequence;)[B

    move-result-object p1

    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->parseFrom([B)Lcom/vdocipher/PlaybackInfo$MetadataTable;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;
    :try_end_20
    .catch Lcom/google/protobuf/InvalidProtocolBufferException; {:try_start_3 .. :try_end_20} :catch_25
    .catch Lorg/json/JSONException; {:try_start_3 .. :try_end_20} :catch_23
    .catch Ljava/lang/IllegalArgumentException; {:try_start_3 .. :try_end_20} :catch_21

    return-void

    :catch_21
    move-exception p1

    goto :goto_26

    :catch_23
    move-exception p1

    goto :goto_26

    :catch_25
    move-exception p1

    .line 11
    :goto_26
    new-instance v0, Lcom/vdocipher/aegis/core/f/d;

    const-string v1, "Invalid meta data"

    invoke-direct {v0, v1, p1}, Lcom/vdocipher/aegis/core/f/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0
.end method

.method private a(Lorg/json/JSONObject;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 5

    .line 237
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->newBuilder()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;

    move-result-object v0

    .line 238
    const-string v1, "captionGlobalStyles"

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4e

    .line 240
    :try_start_c
    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    .line 241
    const-string v1, "color"

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->setColor(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;

    .line 242
    const-string v1, "backgroundColor"

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->setBackgroundColor(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;

    .line 243
    const-string v1, "padding"

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->setPadding(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;

    .line 244
    const-string v1, "captionMaxFont"

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;)D

    move-result-wide v1

    double-to-float v1, v1

    invoke-virtual {v0, v1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->setCaptionMaxFont(F)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;

    .line 245
    const-string v1, "captionScaleFactor"

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;)D

    move-result-wide v1

    double-to-float p1, v1

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->setCaptionScaleFactor(F)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;

    .line 246
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    :try_end_4d
    .catch Lorg/json/JSONException; {:try_start_c .. :try_end_4d} :catch_4e

    return-object p1

    .line 250
    :catch_4e
    :cond_4e
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    return-object p1
.end method

.method private a(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 3

    .line 225
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getShowQualityControl()Z

    move-result v0

    if-eqz v0, :cond_15

    .line 227
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getQualityTrackLabels()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    move-result-object p1

    .line 228
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->getLabelList()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_15

    return-object p1

    .line 232
    :cond_15
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->newBuilder()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    move-result-object p1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->KBPS:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 233
    invoke-virtual {p1, v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->addLabel(Lcom/vdocipher/PlaybackInfo$QualityLabels;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    move-result-object p1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->MB:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 234
    invoke-virtual {p1, v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->addLabel(Lcom/vdocipher/PlaybackInfo$QualityLabels;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    move-result-object p1

    .line 235
    const-string/jumbo v0, "•"

    invoke-virtual {p1, v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->setSeparator(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    move-result-object p1

    .line 236
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object p1
.end method

.method private static a(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 5

    .line 251
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->newBuilder()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    move-result-object v0

    .line 253
    :try_start_4
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 254
    const-string p0, "separator"

    invoke-virtual {v1, p0}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    .line 255
    const-string v2, "label"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/json/JSONArray;

    const/4 v2, 0x0

    .line 256
    :goto_1a
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v2, v3, :cond_2e

    .line 257
    invoke-virtual {v1, v2}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/vdocipher/aegis/core/f/g;->b(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->addLabelValue(I)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_1a

    .line 259
    :cond_2e
    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->setSeparator(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    .line 261
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    :try_end_37
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_37} :catch_38

    return-object p0

    .line 267
    :catch_38
    sget-object p0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->KBPS:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 268
    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->addLabel(Lcom/vdocipher/PlaybackInfo$QualityLabels;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    move-result-object p0

    sget-object v0, Lcom/vdocipher/PlaybackInfo$QualityLabels;->MB:Lcom/vdocipher/PlaybackInfo$QualityLabels;

    .line 269
    invoke-virtual {p0, v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->addLabel(Lcom/vdocipher/PlaybackInfo$QualityLabels;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    move-result-object p0

    .line 270
    const-string/jumbo v0, "•"

    invoke-virtual {p0, v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->setSeparator(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    move-result-object p0

    .line 271
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    return-object p0
.end method

.method private static b(Ljava/lang/String;)I
    .registers 2

    .line 32
    const-string v0, "kbps"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    const/4 p0, 0x4

    return p0

    .line 34
    :cond_a
    const-string v0, "MB"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_14

    const/4 p0, 0x0

    return p0

    .line 36
    :cond_14
    const-string v0, "GB_PER_HOUR"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1e

    const/4 p0, 0x5

    return p0

    .line 38
    :cond_1e
    const-string v0, "NATURAL"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_29

    const/16 p0, 0x8

    return p0

    .line 40
    :cond_29
    const-string v0, "DIMENSION"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_33

    const/4 p0, 0x7

    return p0

    .line 42
    :cond_33
    const-string v0, "PIXELS"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3d

    const/4 p0, 0x6

    return p0

    .line 44
    :cond_3d
    const-string v0, "STANDARD_HQ"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_47

    const/4 p0, 0x1

    return p0

    .line 46
    :cond_47
    const-string v0, "STANDARD_HD"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_51

    const/4 p0, 0x2

    return p0

    .line 48
    :cond_51
    const-string v0, "ROUNDED_kbps"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5b

    const/4 p0, 0x3

    return p0

    .line 51
    :cond_5b
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    return p0
.end method

.method private b(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;)Lcom/vdocipher/aegis/core/f/a;
    .registers 12

    .line 20
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getCaptionGlobalStyles()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    move-result-object v0

    if-eqz v0, :cond_3c

    .line 23
    :try_start_6
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getCaptionGlobalStyles()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    move-result-object p1

    .line 24
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getColor()Lcom/google/protobuf/ByteString;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    .line 25
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getBackgroundColor()Lcom/google/protobuf/ByteString;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    .line 26
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getPadding()Ljava/lang/String;

    move-result-object v0

    .line 27
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getCaptionMaxFont()F

    move-result v8

    .line 28
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getCaptionScaleFactor()F

    move-result v9

    .line 30
    invoke-static {v0}, Lcom/vdocipher/aegis/core/f/g;->g(Ljava/lang/String;)[F

    move-result-object p1

    .line 31
    new-instance v1, Lcom/vdocipher/aegis/core/f/a;

    const/4 v0, 0x0

    aget v4, p1, v0

    const/4 v0, 0x1

    aget v5, p1, v0

    const/4 v0, 0x2

    aget v6, p1, v0

    const/4 v0, 0x3

    aget v7, p1, v0

    invoke-direct/range {v1 .. v9}, Lcom/vdocipher/aegis/core/f/a;-><init>(Ljava/lang/String;Ljava/lang/String;FFFFFF)V
    :try_end_3b
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_3b} :catch_3c

    return-object v1

    :catch_3c
    :cond_3c
    const/4 p1, 0x0

    return-object p1
.end method

.method private c(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;)Ljava/lang/Boolean;
    .registers 2

    .line 2
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getEnableSaveOffline()Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

.method private static d(Ljava/lang/String;)I
    .registers 3

    .line 2
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, -0x1

    sparse-switch v0, :sswitch_data_84

    goto :goto_51

    :sswitch_f
    const-string v0, "chapters"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_18

    goto :goto_51

    :cond_18
    const/4 v1, 0x5

    goto :goto_51

    :sswitch_1a
    const-string v0, "quality"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_23

    goto :goto_51

    :cond_23
    const/4 v1, 0x4

    goto :goto_51

    :sswitch_25
    const-string v0, "captionSearch"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2e

    goto :goto_51

    :cond_2e
    const/4 v1, 0x3

    goto :goto_51

    :sswitch_30
    const-string/jumbo v0, "speed"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3a

    goto :goto_51

    :cond_3a
    const/4 v1, 0x2

    goto :goto_51

    :sswitch_3c
    const-string v0, "captions"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_45

    goto :goto_51

    :cond_45
    const/4 v1, 0x1

    goto :goto_51

    :sswitch_47
    const-string v0, "saveOffline"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_50

    goto :goto_51

    :cond_50
    const/4 v1, 0x0

    :goto_51
    packed-switch v1, :pswitch_data_9e

    .line 16
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    return p0

    .line 17
    :pswitch_59  #0x5
    sget-object p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->chapters:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->getNumber()I

    move-result p0

    return p0

    .line 23
    :pswitch_60  #0x4
    sget-object p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->quality:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->getNumber()I

    move-result p0

    return p0

    .line 25
    :pswitch_67  #0x3
    sget-object p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->captionSearch:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->getNumber()I

    move-result p0

    return p0

    .line 26
    :pswitch_6e  #0x2
    sget-object p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->speed:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->getNumber()I

    move-result p0

    return p0

    .line 27
    :pswitch_75  #0x1
    sget-object p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->captions:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->getNumber()I

    move-result p0

    return p0

    .line 35
    :pswitch_7c  #0x0
    sget-object p0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->saveOffline:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->getNumber()I

    move-result p0

    return p0

    nop

    :sswitch_data_84
    .sparse-switch
        -0x3323525a -> :sswitch_47
        -0x2fc5cb3 -> :sswitch_3c
        0x6890047 -> :sswitch_30
        0x2551672e -> :sswitch_25
        0x26d0c0ff -> :sswitch_1a
        0x55830dc6 -> :sswitch_f
    .end sparse-switch

    :pswitch_data_9e
    .packed-switch 0x0
        :pswitch_7c  #00000000
        :pswitch_75  #00000001
        :pswitch_6e  #00000002
        :pswitch_67  #00000003
        :pswitch_60  #00000004
        :pswitch_59  #00000005
    .end packed-switch
.end method

.method private static e(Ljava/lang/String;)I
    .registers 2

    .line 2
    const-string v0, "dash"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_f

    .line 3
    sget-object p0, Lcom/vdocipher/PlaybackInfo$TechOptions;->dash:Lcom/vdocipher/PlaybackInfo$TechOptions;

    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$TechOptions;->getNumber()I

    move-result p0

    return p0

    .line 4
    :cond_f
    const-string v0, "hlse"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1e

    .line 5
    sget-object p0, Lcom/vdocipher/PlaybackInfo$TechOptions;->hlse:Lcom/vdocipher/PlaybackInfo$TechOptions;

    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$TechOptions;->getNumber()I

    move-result p0

    return p0

    .line 6
    :cond_1e
    const-string v0, "h6"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2d

    .line 7
    sget-object p0, Lcom/vdocipher/PlaybackInfo$TechOptions;->h6:Lcom/vdocipher/PlaybackInfo$TechOptions;

    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$TechOptions;->getNumber()I

    move-result p0

    return p0

    .line 8
    :cond_2d
    const-string v0, "h1"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c

    .line 9
    sget-object p0, Lcom/vdocipher/PlaybackInfo$TechOptions;->h1:Lcom/vdocipher/PlaybackInfo$TechOptions;

    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$TechOptions;->getNumber()I

    move-result p0

    return p0

    .line 10
    :cond_3c
    const-string/jumbo v0, "zen"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4c

    .line 11
    sget-object p0, Lcom/vdocipher/PlaybackInfo$TechOptions;->zen:Lcom/vdocipher/PlaybackInfo$TechOptions;

    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$TechOptions;->getNumber()I

    move-result p0

    return p0

    .line 12
    :cond_4c
    const-string v0, "cbcsi"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5b

    .line 13
    sget-object p0, Lcom/vdocipher/PlaybackInfo$TechOptions;->cbcsi:Lcom/vdocipher/PlaybackInfo$TechOptions;

    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$TechOptions;->getNumber()I

    move-result p0

    return p0

    .line 15
    :cond_5b
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    return p0
.end method

.method private static g(Ljava/lang/String;)[F
    .registers 9

    const/4 v0, 0x4

    if-eqz p0, :cond_df

    .line 7
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_f

    goto/16 :goto_df

    .line 11
    :cond_f
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 13
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const-string v2, "px"

    invoke-virtual {p0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    .line 15
    array-length v2, p0

    const/4 v3, 0x0

    move v4, v3

    :goto_21
    if-ge v4, v2, :cond_33

    aget-object v5, p0, v4

    .line 16
    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Float;->valueOf(Ljava/lang/String;)Ljava/lang/Float;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, 0x1

    goto :goto_21

    .line 19
    :cond_33
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p0

    const/4 v2, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eq p0, v5, :cond_ac

    if-eq p0, v4, :cond_79

    if-eq p0, v0, :cond_46

    .line 27
    new-array p0, v0, [F

    fill-array-data p0, :array_e6

    return-object p0

    .line 28
    :cond_46
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Float;

    invoke-virtual {p0}, Ljava/lang/Float;->floatValue()F

    move-result p0

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Float;

    invoke-virtual {v6}, Ljava/lang/Float;->floatValue()F

    move-result v6

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Float;

    invoke-virtual {v7}, Ljava/lang/Float;->floatValue()F

    move-result v7

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Float;

    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    move-result v1

    new-array v0, v0, [F

    aput p0, v0, v3

    aput v6, v0, v5

    aput v7, v0, v4

    aput v1, v0, v2

    return-object v0

    .line 29
    :cond_79
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Float;

    invoke-virtual {p0}, Ljava/lang/Float;->floatValue()F

    move-result p0

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Float;

    invoke-virtual {v6}, Ljava/lang/Float;->floatValue()F

    move-result v6

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Float;

    invoke-virtual {v7}, Ljava/lang/Float;->floatValue()F

    move-result v7

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Float;

    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    move-result v1

    new-array v0, v0, [F

    aput p0, v0, v3

    aput v6, v0, v5

    aput v7, v0, v4

    aput v1, v0, v2

    return-object v0

    .line 30
    :cond_ac
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Float;

    invoke-virtual {p0}, Ljava/lang/Float;->floatValue()F

    move-result p0

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Float;

    invoke-virtual {v6}, Ljava/lang/Float;->floatValue()F

    move-result v6

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Float;

    invoke-virtual {v7}, Ljava/lang/Float;->floatValue()F

    move-result v7

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Float;

    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    move-result v1

    new-array v0, v0, [F

    aput p0, v0, v3

    aput v6, v0, v5

    aput v7, v0, v4

    aput v1, v0, v2

    return-object v0

    .line 31
    :cond_df
    :goto_df
    new-array p0, v0, [F

    fill-array-data p0, :array_f2

    return-object p0

    nop

    :array_e6
    .array-data 4
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_f2
    .array-data 4
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method


# virtual methods
.method public a(Ljava/lang/String;Ljava/util/HashMap;)Lcom/vdocipher/aegis/media/PlayerOption;
    .registers 5

    .line 16
    const-string v0, ""

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2, v0, v1}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/lang/String;Ljava/util/HashMap;Ljava/lang/String;Lcom/vdocipher/aegis/media/Posters;)Lcom/vdocipher/aegis/media/PlayerOption;

    move-result-object p1

    return-object p1
.end method

.method public a(Ljava/lang/String;Ljava/util/HashMap;Ljava/lang/String;)Lcom/vdocipher/aegis/media/PlayerOption;
    .registers 5

    const/4 v0, 0x0

    .line 17
    invoke-virtual {p0, p1, p2, p3, v0}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/lang/String;Ljava/util/HashMap;Ljava/lang/String;Lcom/vdocipher/aegis/media/Posters;)Lcom/vdocipher/aegis/media/PlayerOption;

    move-result-object p1

    return-object p1
.end method

.method public a(Ljava/lang/String;Ljava/util/HashMap;Ljava/lang/String;Lcom/vdocipher/aegis/media/Posters;)Lcom/vdocipher/aegis/media/PlayerOption;
    .registers 45

    move-object/from16 v0, p0

    move-object/from16 v1, p4

    .line 18
    iget-object v2, v0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getPlayerConfig()Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    move-result-object v2

    invoke-virtual {v2}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->toBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v2

    check-cast v2, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;

    .line 20
    invoke-virtual {v2}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->getOptions()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    move-result-object v3

    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->toBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v3

    check-cast v3, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    if-eqz p2, :cond_491

    .line 24
    :try_start_1c
    invoke-virtual/range {p2 .. p2}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_24
    :goto_24
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_491

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/Map$Entry;

    .line 25
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    if-nez v6, :cond_37

    goto :goto_24

    .line 27
    :cond_37
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string/jumbo v7, "skipDuration"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_5c

    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    instance-of v6, v6, Ljava/lang/Integer;

    if-eqz v6, :cond_5c

    .line 28
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    .line 29
    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setSkipDuration(I)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto :goto_24

    .line 30
    :cond_5c
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "playbackSpeedOptions"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_b3

    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    instance-of v6, v6, Ljava/util/List;

    if-eqz v6, :cond_b3

    .line 31
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    .line 32
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->clearPlaybackSpeedOptions()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 33
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_7f
    :goto_7f
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_24

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .line 34
    instance-of v7, v6, Ljava/lang/Double;

    if-eqz v7, :cond_97

    .line 35
    check-cast v6, Ljava/lang/Double;

    invoke-virtual {v6}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v6

    invoke-virtual {v3, v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->addPlaybackSpeedOptions(D)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto :goto_7f

    .line 36
    :cond_97
    instance-of v7, v6, Ljava/lang/Float;

    if-eqz v7, :cond_a5

    .line 37
    check-cast v6, Ljava/lang/Float;

    invoke-virtual {v6}, Ljava/lang/Float;->doubleValue()D

    move-result-wide v6

    invoke-virtual {v3, v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->addPlaybackSpeedOptions(D)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto :goto_7f

    .line 38
    :cond_a5
    instance-of v7, v6, Ljava/lang/Integer;

    if-eqz v7, :cond_7f

    .line 39
    check-cast v6, Ljava/lang/Integer;

    invoke-virtual {v6}, Ljava/lang/Integer;->doubleValue()D

    move-result-wide v6

    invoke-virtual {v3, v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->addPlaybackSpeedOptions(D)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto :goto_7f

    .line 42
    :cond_b3
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "collapseInSettings"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_13b

    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    instance-of v6, v6, Ljava/util/List;

    if-eqz v6, :cond_13b

    .line 43
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    .line 44
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->clearCollapseInSettings()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 45
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_d6
    :goto_d6
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_24

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .line 46
    instance-of v7, v6, Ljava/lang/String;

    if-eqz v7, :cond_d6

    .line 47
    check-cast v6, Ljava/lang/String;

    .line 48
    const-string v7, "chapters"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_f4

    .line 49
    sget-object v6, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->chapters:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    invoke-virtual {v3, v6}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->addCollapseInSettings(Lcom/vdocipher/PlaybackInfo$CollapseSettings;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto :goto_d6

    .line 50
    :cond_f4
    const-string v7, "captions"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_102

    .line 51
    sget-object v6, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->captions:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    invoke-virtual {v3, v6}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->addCollapseInSettings(Lcom/vdocipher/PlaybackInfo$CollapseSettings;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto :goto_d6

    .line 52
    :cond_102
    const-string/jumbo v7, "speed"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_111

    .line 53
    sget-object v6, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->speed:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    invoke-virtual {v3, v6}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->addCollapseInSettings(Lcom/vdocipher/PlaybackInfo$CollapseSettings;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto :goto_d6

    .line 54
    :cond_111
    const-string v7, "quality"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_11f

    .line 55
    sget-object v6, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->quality:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    invoke-virtual {v3, v6}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->addCollapseInSettings(Lcom/vdocipher/PlaybackInfo$CollapseSettings;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto :goto_d6

    .line 56
    :cond_11f
    const-string v7, "captionSearch"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_12d

    .line 57
    sget-object v6, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->captionSearch:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    invoke-virtual {v3, v6}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->addCollapseInSettings(Lcom/vdocipher/PlaybackInfo$CollapseSettings;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto :goto_d6

    .line 58
    :cond_12d
    const-string v7, "saveOffline"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_d6

    .line 59
    sget-object v6, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->saveOffline:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    invoke-virtual {v3, v6}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->addCollapseInSettings(Lcom/vdocipher/PlaybackInfo$CollapseSettings;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto :goto_d6

    .line 63
    :cond_13b
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string/jumbo v7, "showTimeText"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_159

    .line 64
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    .line 65
    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowTimeText(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 66
    :cond_159
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "primaryColor"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_176

    .line 67
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 68
    invoke-static {v5}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setPrimaryColor(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 69
    :cond_176
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string/jumbo v7, "showPlayPauseBtn"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_194

    .line 70
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowPlayPauseBtn(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 71
    :cond_194
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string/jumbo v7, "showProgressBar"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1b2

    .line 72
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowProgressBar(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 73
    :cond_1b2
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string/jumbo v7, "showSpeedControl"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1d0

    .line 74
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowSpeedControl(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 75
    :cond_1d0
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string/jumbo v7, "showQualityControl"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1ee

    .line 76
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowQualityControl(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 77
    :cond_1ee
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string/jumbo v7, "showCaptionsControl"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_20c

    .line 78
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowCaptionsControl(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 79
    :cond_20c
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "enableCaptionSearch"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_229

    .line 80
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableCaptionSearch(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 81
    :cond_229
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string/jumbo v7, "showFullScreen"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_247

    .line 82
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowFullScreen(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 83
    :cond_247
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string/jumbo v7, "showVolume"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_265

    .line 84
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowVolume(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 85
    :cond_265
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string/jumbo v7, "showForward"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_283

    .line 86
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowForward(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 87
    :cond_283
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string/jumbo v7, "showBackward"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2a1

    .line 88
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowBackward(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 89
    :cond_2a1
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "hideControlsOnPause"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2be

    .line 90
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setHideControlsOnPause(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 91
    :cond_2be
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "enableLockControls"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2db

    .line 92
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableLockControls(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 93
    :cond_2db
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "enableDoubleTapSkip"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2f8

    .line 94
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableDoubleTapSkip(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 95
    :cond_2f8
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "enableAutoResumeLocal"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_315

    .line 96
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableAutoResumeLocal(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 97
    :cond_315
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "confirmBeforeAutoResume"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_332

    .line 98
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setConfirmBeforeAutoResume(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 99
    :cond_332
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "enableSaveOffline"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_34f

    .line 100
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableSaveOffline(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 101
    :cond_34f
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string/jumbo v7, "showReplayAtEnd"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_36d

    .line 102
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowReplayAtEnd(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 103
    :cond_36d
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string/jumbo v7, "showScrubbingPreview"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_38b

    .line 104
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowScrubbingPreview(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 105
    :cond_38b
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "enableChapters"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3a8

    .line 106
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableChapters(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 107
    :cond_3a8
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "enablePiP"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3c5

    .line 108
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnablePiP(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 109
    :cond_3c5
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "enableChromecast"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3e2

    .line 110
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableChromecast(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 111
    :cond_3e2
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string/jumbo v7, "showCastWhenDeviceReady"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_400

    .line 112
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowCastWhenDeviceReady(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 113
    :cond_400
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "conserveQualityAcrossSession"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_41d

    .line 114
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setConserveQualityAcrossSession(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 115
    :cond_41d
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "conserveSpeedAcrossSession"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_43a

    .line 116
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setConserveSpeedAcrossSession(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 117
    :cond_43a
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "conserveSelectedCaptionLanguage"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_457

    .line 118
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setConserveSelectedCaptionLanguage(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 119
    :cond_457
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "conserveVolumeAcrossSession"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_474

    .line 120
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setConserveVolumeAcrossSession(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    goto/16 :goto_24

    .line 121
    :cond_474
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "enableReportBug"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_24

    .line 122
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    invoke-virtual {v3, v5}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableReportBug(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    :try_end_48f
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_48f} :catch_491

    goto/16 :goto_24

    .line 128
    :catch_491
    :cond_491
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getPlaybackSpeedOptionsList()Ljava/util/List;

    move-result-object v4

    if-nez v4, :cond_49c

    .line 131
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 132
    :cond_49c
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x0

    .line 134
    :goto_4a2
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v7

    if-ge v6, v7, :cond_4c0

    .line 135
    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Double;

    invoke-virtual {v7}, Ljava/lang/Double;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v7

    invoke-static {v7, v8}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v6, v6, 0x1

    goto :goto_4a2

    .line 138
    :cond_4c0
    iget-object v4, v0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v4}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getAudioOnly()Z

    move-result v4

    .line 140
    invoke-direct {v0, v3}, Lcom/vdocipher/aegis/core/f/g;->c(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;)Ljava/lang/Boolean;

    move-result-object v23

    invoke-virtual/range {v23 .. v23}, Ljava/lang/Boolean;->booleanValue()Z

    move-object/from16 v36, v5

    .line 142
    new-instance v5, Lcom/vdocipher/aegis/core/f/h;

    .line 143
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getPrimaryColor()Lcom/google/protobuf/ByteString;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    .line 144
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getShowTimeText()Z

    move-result v7

    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v7

    .line 145
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getShowPlayPauseBtn()Z

    move-result v8

    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v8

    .line 146
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getShowProgressBar()Z

    move-result v9

    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v9

    .line 147
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getShowSpeedControl()Z

    move-result v10

    invoke-static {v10}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v10

    .line 148
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getShowQualityControl()Z

    move-result v11

    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v11

    .line 149
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getShowCaptionsControl()Z

    move-result v12

    invoke-static {v12}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v12

    .line 150
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getEnableCaptionSearch()Z

    move-result v13

    invoke-static {v13}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v13

    .line 151
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getShowFullScreen()Z

    move-result v14

    invoke-static {v14}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    .line 152
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getShowVolume()Z

    move-result v15

    invoke-static {v15}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v15

    .line 153
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getShowForward()Z

    move-result v16

    invoke-static/range {v16 .. v16}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v16

    .line 154
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getShowBackward()Z

    move-result v17

    invoke-static/range {v17 .. v17}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v17

    .line 155
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getHideControlsOnPause()Z

    move-result v18

    invoke-static/range {v18 .. v18}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v18

    .line 156
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getEnableLockControls()Z

    move-result v19

    invoke-static/range {v19 .. v19}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v19

    .line 157
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getEnableDoubleTapSkip()Z

    move-result v20

    invoke-static/range {v20 .. v20}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v20

    .line 158
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getEnableAutoResumeLocal()Z

    move-result v21

    invoke-static/range {v21 .. v21}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v21

    .line 159
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getConfirmBeforeAutoResume()Z

    move-result v22

    invoke-static/range {v22 .. v22}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v22

    move-object/from16 v39, v2

    .line 160
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getSkipDuration()I

    move-result v2

    mul-int/lit16 v2, v2, 0x3e8

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    .line 161
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getShowReplayAtEnd()Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v25

    .line 162
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getShowScrubbingPreview()Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v26

    .line 163
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getEnableChapters()Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v27

    .line 164
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getEnablePiP()Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v28

    .line 165
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getEnableChromecast()Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v29

    .line 166
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getShowCastWhenDeviceReady()Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v30

    .line 167
    sget-object v31, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 168
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getConserveSpeedAcrossSession()Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v32

    .line 169
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getConserveSelectedCaptionLanguage()Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v33

    .line 170
    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getShowClearStorageOption()Z

    move-result v34

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 171
    invoke-virtual {v0, v2, v3}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/util/ArrayList;Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;)Ljava/util/ArrayList;

    move-result-object v35

    .line 173
    invoke-direct {v0, v3}, Lcom/vdocipher/aegis/core/f/g;->a(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    move-result-object v37

    .line 174
    invoke-direct {v0, v3}, Lcom/vdocipher/aegis/core/f/g;->b(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;)Lcom/vdocipher/aegis/core/f/a;

    move-result-object v38

    invoke-direct/range {v5 .. v38}, Lcom/vdocipher/aegis/core/f/h;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;ZLjava/util/ArrayList;Ljava/util/ArrayList;Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;Lcom/vdocipher/aegis/core/f/a;)V

    .line 177
    invoke-virtual/range {v39 .. v39}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->getId()Lcom/google/protobuf/ByteString;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    .line 179
    invoke-virtual/range {v39 .. v39}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->getTheme()Lcom/google/protobuf/ByteString;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    .line 181
    new-instance v15, Lcom/vdocipher/aegis/core/f/i;

    invoke-direct {v15, v2, v3, v5}, Lcom/vdocipher/aegis/core/f/i;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/f/h;)V

    .line 187
    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/g;->p()Ljava/util/ArrayList;

    move-result-object v2

    if-eqz v1, :cond_5e4

    .line 188
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_5e4

    .line 189
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_5ee

    :cond_5e4
    if-eqz v1, :cond_5ee

    .line 191
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 192
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5ee
    :goto_5ee
    move-object v14, v2

    .line 195
    new-instance v6, Lcom/vdocipher/aegis/media/PlayerOption;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/g;->r()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/g;->e()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/g;->b()Ljava/lang/Double;

    move-result-object v10

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 196
    invoke-virtual {v0, v1}, Lcom/vdocipher/aegis/core/f/g;->b(Ljava/util/ArrayList;)Ljava/util/ArrayList;

    move-result-object v12

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0, v1}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/util/ArrayList;)Ljava/util/ArrayList;

    move-result-object v13

    move-object/from16 v1, p3

    invoke-virtual {v0, v1}, Lcom/vdocipher/aegis/core/f/g;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    move-object/from16 v7, p1

    move v11, v4

    invoke-direct/range {v6 .. v16}, Lcom/vdocipher/aegis/media/PlayerOption;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Double;ZLjava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Lcom/vdocipher/aegis/core/f/i;Ljava/lang/String;)V

    return-object v6
.end method

.method public a(Ljava/util/ArrayList;)Ljava/util/ArrayList;
    .registers 15

    const/4 v1, 0x0

    if-nez p1, :cond_4

    return-object v1

    .line 1
    :cond_4
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getCaptionsList()Ljava/util/List;

    move-result-object v2

    .line 2
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_11

    return-object v1

    :cond_11
    const/4 v0, 0x0

    move v3, v0

    .line 4
    :goto_13
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v0

    if-ge v3, v0, :cond_50

    .line 5
    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lcom/vdocipher/PlaybackInfo$Captions;

    .line 7
    invoke-virtual {v4}, Lcom/vdocipher/PlaybackInfo$Captions;->getIsDefault()Z

    move-result v5

    .line 9
    :try_start_24
    invoke-virtual {v4}, Lcom/vdocipher/PlaybackInfo$Captions;->getCaptionName()Ljava/lang/String;

    move-result-object v0
    :try_end_28
    .catch Ljava/lang/Exception; {:try_start_24 .. :try_end_28} :catch_2a

    move-object v12, v0

    goto :goto_35

    :catch_2a
    move-exception v0

    .line 11
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v6, "MetaParser"

    invoke-static {v6, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    move-object v12, v1

    .line 13
    :goto_35
    new-instance v7, Lcom/vdocipher/aegis/media/Caption;

    invoke-virtual {v4}, Lcom/vdocipher/PlaybackInfo$Captions;->getUrl()Ljava/lang/String;

    move-result-object v8

    .line 14
    invoke-virtual {v4}, Lcom/vdocipher/PlaybackInfo$Captions;->getLang()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4}, Lcom/vdocipher/PlaybackInfo$Captions;->getLabel()Ljava/lang/String;

    move-result-object v10

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v11

    invoke-direct/range {v7 .. v12}, Lcom/vdocipher/aegis/media/Caption;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)V

    .line 15
    invoke-virtual {p1, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_13

    :cond_50
    return-object p1
.end method

.method public a(Ljava/util/ArrayList;Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;)Ljava/util/ArrayList;
    .registers 7

    if-nez p1, :cond_8

    .line 197
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    return-object p1

    .line 199
    :cond_8
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getCollapseInSettingsList()Ljava/util/List;

    move-result-object v0

    .line 201
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_81

    const/4 v1, 0x0

    .line 202
    :goto_13
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_69

    .line 203
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    .line 204
    sget-object v3, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->chapters:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    if-ne v2, v3, :cond_29

    .line 205
    const-string v2, "chapters"

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_66

    .line 206
    :cond_29
    sget-object v3, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->captions:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    if-ne v2, v3, :cond_33

    .line 207
    const-string v2, "captions"

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_66

    .line 208
    :cond_33
    sget-object v3, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->speed:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    if-ne v2, v3, :cond_3e

    .line 209
    const-string/jumbo v2, "speed"

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_66

    .line 210
    :cond_3e
    sget-object v3, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->quality:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    if-ne v2, v3, :cond_48

    .line 211
    const-string v2, "quality"

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_66

    .line 212
    :cond_48
    sget-object v3, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->captionSearch:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    if-ne v2, v3, :cond_52

    .line 213
    const-string v2, "captionSearch"

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_66

    .line 214
    :cond_52
    sget-object v3, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->saveOffline:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    if-ne v2, v3, :cond_66

    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getEnableSaveOffline()Z

    move-result v2

    if-eqz v2, :cond_66

    .line 215
    const-string v2, "saveOffline"

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 216
    const-string v2, "clearOfflineVideos"

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_66
    :goto_66
    add-int/lit8 v1, v1, 0x1

    goto :goto_13

    .line 219
    :cond_69
    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->getEnableReportBug()Z

    move-result p2

    if-eqz p2, :cond_74

    .line 220
    const-string p2, "feedback"

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 222
    :cond_74
    iget-object p2, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getVdocipherBranding()Z

    move-result p2

    if-eqz p2, :cond_81

    .line 223
    const-string p2, "aboutPlayer"

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_81
    return-object p1
.end method

.method public a()Z
    .registers 2

    .line 224
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDash()Lcom/vdocipher/PlaybackInfo$DASH;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getAllowSafetyDetect()Z

    move-result v0

    return v0
.end method

.method public b()Ljava/lang/Double;
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getAspectRatio()F

    move-result v0

    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    return-object v0
.end method

.method public b(Ljava/util/ArrayList;)Ljava/util/ArrayList;
    .registers 9

    const-string v0, "MetaParser"

    if-nez p1, :cond_6

    const/4 p1, 0x0

    return-object p1

    .line 2
    :cond_6
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getChaptersList()Ljava/util/List;

    move-result-object v1

    const/4 v2, 0x0

    move v3, v2

    .line 4
    :goto_e
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v4

    if-ge v3, v4, :cond_42

    .line 5
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/vdocipher/PlaybackInfo$Chapters;

    .line 9
    :try_start_1a
    invoke-virtual {v4}, Lcom/vdocipher/PlaybackInfo$Chapters;->getTitle()Ljava/lang/String;

    move-result-object v5
    :try_end_1e
    .catch Ljava/lang/Exception; {:try_start_1a .. :try_end_1e} :catch_1f

    goto :goto_29

    :catch_1f
    move-exception v5

    .line 11
    invoke-static {v5}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v0, v5}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const-string v5, ""

    .line 14
    :goto_29
    :try_start_29
    invoke-virtual {v4}, Lcom/vdocipher/PlaybackInfo$Chapters;->getStartTime()I

    move-result v4
    :try_end_2d
    .catch Ljava/lang/Exception; {:try_start_29 .. :try_end_2d} :catch_2e

    goto :goto_37

    :catch_2e
    move-exception v4

    .line 16
    invoke-static {v4}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v0, v4}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    move v4, v2

    .line 18
    :goto_37
    new-instance v6, Lcom/vdocipher/aegis/media/Chapter;

    invoke-direct {v6, v5, v4}, Lcom/vdocipher/aegis/media/Chapter;-><init>(Ljava/lang/String;I)V

    .line 19
    invoke-virtual {p1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_e

    :cond_42
    return-object p1
.end method

.method public c()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDescription()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public c(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    if-eqz p1, :cond_9

    .line 3
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_9

    return-object p1

    .line 5
    :cond_9
    iget-object p1, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getScrubbingPreviewUrl()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public d()I
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDesiredBitrate()I

    move-result v0

    return v0
.end method

.method public e()J
    .registers 5

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDuration()I

    move-result v0

    int-to-long v0, v0

    const-wide/16 v2, 0x3e8

    mul-long/2addr v0, v2

    return-wide v0
.end method

.method f(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable;
    .registers 13

    .line 2
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->newBuilder()Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    move-result-object v0

    .line 3
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 6
    const-string/jumbo p1, "title"

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->setTitle(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    .line 7
    const-string v2, "description"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->setDescription(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    .line 8
    const-string v2, "duration"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->setDuration(I)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    .line 9
    const-string v2, "aspectRatio"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;)D

    move-result-wide v2

    double-to-float v2, v2

    invoke-virtual {v0, v2}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->setAspectRatio(F)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    .line 10
    const-string v2, "desiredBitrate"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->setDesiredBitrate(I)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    .line 11
    const-string v2, "integrityCloudId"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->setIntegrityCloudId(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    .line 12
    const-string/jumbo v2, "vdocipherBranding"

    const/4 v3, 0x1

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v2

    invoke-virtual {v0, v2}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->setVdocipherBranding(Z)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    .line 13
    const-string v2, "scrubbingPreviewUrl"

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->setScrubbingPreviewUrl(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    .line 15
    const-string v2, "embedUrl"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->setEmbedUrlBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    .line 16
    const-string v2, "audioOnly"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v2

    invoke-virtual {v0, v2}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->setAudioOnly(Z)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    .line 17
    const-string/jumbo v2, "version"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->setVersion(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    .line 19
    const-string/jumbo v2, "tech"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v2

    const/4 v3, 0x0

    if-eqz v2, :cond_96

    move v4, v3

    .line 21
    :goto_82
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v5

    if-ge v4, v5, :cond_96

    .line 22
    invoke-virtual {v2, v4}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lcom/vdocipher/aegis/core/f/g;->e(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v0, v5}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->addTechValue(I)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    add-int/lit8 v4, v4, 0x1

    goto :goto_82

    .line 27
    :cond_96
    const-string v2, "hostnames"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v2

    if-eqz v2, :cond_af

    move v4, v3

    .line 29
    :goto_9f
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v5

    if-ge v4, v5, :cond_af

    .line 30
    invoke-virtual {v2, v4}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->addHostnames(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    add-int/lit8 v4, v4, 0x1

    goto :goto_9f

    .line 35
    :cond_af
    const-string v2, "dash"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    .line 36
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$DASH;->newBuilder()Lcom/vdocipher/PlaybackInfo$DASH$Builder;

    move-result-object v4

    const-string v5, "manifest"

    if-eqz v2, :cond_142

    .line 38
    invoke-virtual {v2, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v6

    invoke-virtual {v4, v6}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->setManifest(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$DASH$Builder;

    .line 40
    const-string v6, "errorCodesAL3"

    invoke-virtual {v2, v6}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v6

    if-eqz v6, :cond_e1

    move v7, v3

    .line 42
    :goto_d1
    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v8

    if-ge v7, v8, :cond_e1

    .line 43
    invoke-virtual {v6, v7}, Lorg/json/JSONArray;->optInt(I)I

    move-result v8

    invoke-virtual {v4, v8}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->addErrorCodesAL3(I)Lcom/vdocipher/PlaybackInfo$DASH$Builder;

    add-int/lit8 v7, v7, 0x1

    goto :goto_d1

    .line 47
    :cond_e1
    const-string v6, "licenseServers"

    invoke-virtual {v2, v6}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v6

    if-eqz v6, :cond_101

    .line 49
    invoke-virtual {v6}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v7

    :goto_ed
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_101

    .line 50
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    .line 51
    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 52
    invoke-virtual {v4, v8}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->setLicenseServers(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$DASH$Builder;

    goto :goto_ed

    .line 56
    :cond_101
    const-string v6, "fallbackLicenseServers"

    invoke-virtual {v2, v6}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v6

    if-eqz v6, :cond_11e

    move v7, v3

    .line 58
    :goto_10a
    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v8

    if-ge v7, v8, :cond_11e

    .line 59
    invoke-virtual {v6, v7}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v8

    invoke-virtual {v4, v8}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->addFallbackLicenseServersBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$DASH$Builder;

    add-int/lit8 v7, v7, 0x1

    goto :goto_10a

    .line 62
    :cond_11e
    const-string v6, "enforceL3Config"

    invoke-virtual {v2, v6}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v6

    invoke-virtual {v4, v6}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->setEnforceL3Config(Z)Lcom/vdocipher/PlaybackInfo$DASH$Builder;

    .line 63
    const-string v6, "enforceHardwareAttestation"

    invoke-virtual {v2, v6}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v6

    invoke-virtual {v4, v6}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->setEnforceHardwareAttestation(Z)Lcom/vdocipher/PlaybackInfo$DASH$Builder;

    .line 64
    const-string v6, "allowSafetyDetect"

    invoke-virtual {v2, v6}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v2

    invoke-virtual {v4, v2}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->setAllowSafetyDetect(Z)Lcom/vdocipher/PlaybackInfo$DASH$Builder;

    .line 65
    invoke-virtual {v4}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object v2

    check-cast v2, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0, v2}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->setDash(Lcom/vdocipher/PlaybackInfo$DASH;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    .line 69
    :cond_142
    const-string v2, "h6"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    .line 70
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$H6;->newBuilder()Lcom/vdocipher/PlaybackInfo$H6$Builder;

    move-result-object v4

    if-eqz v2, :cond_162

    .line 72
    invoke-virtual {v2, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v2

    invoke-virtual {v4, v2}, Lcom/vdocipher/PlaybackInfo$H6$Builder;->setManifest(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$H6$Builder;

    .line 73
    invoke-virtual {v4}, Lcom/vdocipher/PlaybackInfo$H6$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object v2

    check-cast v2, Lcom/vdocipher/PlaybackInfo$H6;

    invoke-virtual {v0, v2}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->setH6(Lcom/vdocipher/PlaybackInfo$H6;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    .line 77
    :cond_162
    const-string v2, "chapters"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_19c

    .line 78
    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v2

    if-eqz v2, :cond_19c

    move v4, v3

    .line 80
    :goto_171
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v5

    if-ge v4, v5, :cond_19c

    .line 81
    invoke-virtual {v2, v4}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v5

    .line 82
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Chapters;->newBuilder()Lcom/vdocipher/PlaybackInfo$Chapters$Builder;

    move-result-object v6

    .line 83
    invoke-virtual {v5, p1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->setTitle(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$Chapters$Builder;

    .line 84
    const-string/jumbo v7, "startTime"

    invoke-virtual {v5, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v6, v5}, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->setStartTime(I)Lcom/vdocipher/PlaybackInfo$Chapters$Builder;

    .line 85
    invoke-virtual {v6}, Lcom/vdocipher/PlaybackInfo$Chapters$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object v5

    check-cast v5, Lcom/vdocipher/PlaybackInfo$Chapters;

    invoke-virtual {v0, v5}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->addChapters(Lcom/vdocipher/PlaybackInfo$Chapters;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    add-int/lit8 v4, v4, 0x1

    goto :goto_171

    .line 91
    :cond_19c
    const-string p1, "posters"

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    const-string/jumbo v4, "url"

    if-eqz v2, :cond_1d8

    .line 92
    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    if-eqz p1, :cond_1d8

    move v2, v3

    .line 94
    :goto_1ae
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v5

    if-ge v2, v5, :cond_1d8

    .line 95
    invoke-virtual {p1, v2}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v5

    .line 96
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Posters;->newBuilder()Lcom/vdocipher/PlaybackInfo$Posters$Builder;

    move-result-object v6

    .line 97
    invoke-virtual {v5, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->setUrl(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$Posters$Builder;

    .line 98
    const-string v7, "height"

    invoke-virtual {v5, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v6, v5}, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->setHeight(I)Lcom/vdocipher/PlaybackInfo$Posters$Builder;

    .line 99
    invoke-virtual {v6}, Lcom/vdocipher/PlaybackInfo$Posters$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object v5

    check-cast v5, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-virtual {v0, v5}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->addPosters(Lcom/vdocipher/PlaybackInfo$Posters;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_1ae

    .line 105
    :cond_1d8
    const-string p1, "playerConfig"

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    .line 106
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->newBuilder()Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;

    move-result-object v2

    const-string v5, "id"

    if-eqz p1, :cond_38d

    .line 108
    invoke-virtual {p1, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v6

    invoke-virtual {v2, v6}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->setId(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;

    .line 109
    const-string/jumbo v6, "theme"

    invoke-virtual {p1, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v6

    invoke-virtual {v2, v6}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->setTheme(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;

    .line 111
    const-string v6, "options"

    invoke-virtual {p1, v6}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    .line 112
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->newBuilder()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    move-result-object v6

    if-eqz p1, :cond_228

    .line 114
    const-string v7, "collapseInSettings"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v7

    if-eqz v7, :cond_228

    move v8, v3

    .line 116
    :goto_214
    invoke-virtual {v7}, Lorg/json/JSONArray;->length()I

    move-result v9

    if-ge v8, v9, :cond_228

    .line 117
    invoke-virtual {v7, v8}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lcom/vdocipher/aegis/core/f/g;->d(Ljava/lang/String;)I

    move-result v9

    invoke-virtual {v6, v9}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->addCollapseInSettingsValue(I)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    add-int/lit8 v8, v8, 0x1

    goto :goto_214

    :cond_228
    if-eqz p1, :cond_38d

    .line 124
    const-string v7, "playbackSpeedOptions"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v7

    if-eqz v7, :cond_243

    move v8, v3

    .line 126
    :goto_233
    invoke-virtual {v7}, Lorg/json/JSONArray;->length()I

    move-result v9

    if-ge v8, v9, :cond_243

    .line 127
    invoke-virtual {v7, v8}, Lorg/json/JSONArray;->optDouble(I)D

    move-result-wide v9

    invoke-virtual {v6, v9, v10}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->addPlaybackSpeedOptions(D)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    add-int/lit8 v8, v8, 0x1

    goto :goto_233

    .line 131
    :cond_243
    const-string v7, "primaryColor"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setPrimaryColor(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 132
    const-string/jumbo v7, "showTimeText"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowTimeText(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 133
    const-string/jumbo v7, "showPlayPauseBtn"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowPlayPauseBtn(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 134
    const-string/jumbo v7, "showProgressBar"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowProgressBar(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 135
    const-string/jumbo v7, "showSpeedControl"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowSpeedControl(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 136
    const-string/jumbo v7, "showQualityControl"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowQualityControl(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 137
    const-string/jumbo v7, "showCaptionsControl"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowCaptionsControl(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 138
    const-string v7, "enableCaptionSearch"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableCaptionSearch(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 139
    const-string/jumbo v7, "showFullScreen"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowFullScreen(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 140
    const-string/jumbo v7, "showVolume"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowVolume(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 141
    const-string/jumbo v7, "showForward"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowForward(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 142
    const-string/jumbo v7, "showBackward"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowBackward(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 143
    const-string/jumbo v7, "showReplayAtEnd"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v8

    invoke-virtual {v6, v8}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowReplayAtEnd(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 144
    const-string v8, "hideControlsOnPause"

    invoke-virtual {p1, v8}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v8

    invoke-virtual {v6, v8}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setHideControlsOnPause(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 145
    const-string v8, "enableLockControls"

    invoke-virtual {p1, v8}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v8

    invoke-virtual {v6, v8}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableLockControls(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 146
    const-string v8, "enableDoubleTapSkip"

    invoke-virtual {p1, v8}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v8

    invoke-virtual {v6, v8}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableDoubleTapSkip(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 147
    const-string v8, "enableAutoResumeLocal"

    invoke-virtual {p1, v8}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v8

    invoke-virtual {v6, v8}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableAutoResumeLocal(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 148
    const-string v8, "confirmBeforeAutoResume"

    invoke-virtual {p1, v8}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v8

    invoke-virtual {v6, v8}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setConfirmBeforeAutoResume(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 149
    const-string/jumbo v8, "skipDuration"

    const/16 v9, 0xa

    invoke-virtual {p1, v8, v9}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v8

    invoke-virtual {v6, v8}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setSkipDuration(I)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 150
    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowReplayAtEnd(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 151
    const-string/jumbo v7, "showScrubbingPreview"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowScrubbingPreview(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 152
    const-string v7, "enableChapters"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableChapters(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 153
    const-string v7, "enablePiP"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnablePiP(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 154
    const-string v7, "enableChromecast"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableChromecast(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 155
    const-string/jumbo v7, "showCastWhenDeviceReady"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowCastWhenDeviceReady(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 156
    const-string v7, "enableReportBug"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableReportBug(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 157
    const-string v7, "enableSaveOffline"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setEnableSaveOffline(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 158
    invoke-virtual {v6, v3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setConserveQualityAcrossSession(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 159
    const-string v7, "conserveSpeedAcrossSession"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setConserveSpeedAcrossSession(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 160
    const-string v7, "conserveSelectedCaptionLanguage"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setConserveSelectedCaptionLanguage(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 161
    const-string/jumbo v7, "showClearStorageOption"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setShowClearStorageOption(Z)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 162
    const-string v7, "qualityTrackLabels"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    move-result-object v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setQualityTrackLabels(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 163
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/f/g;->a(Lorg/json/JSONObject;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    move-result-object p1

    invoke-virtual {v6, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->setCaptionGlobalStyles(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    .line 164
    invoke-virtual {v6}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v2, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->setOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;

    .line 165
    invoke-virtual {v2}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->setPlayerConfig(Lcom/vdocipher/PlaybackInfo$PlayerConfig;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    .line 170
    :cond_38d
    const-string p1, "captions"

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    if-eqz p1, :cond_3e9

    move v2, v3

    .line 172
    :goto_396
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v6

    if-ge v2, v6, :cond_3e9

    .line 173
    invoke-virtual {p1, v2}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v6

    .line 174
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$Captions;->newBuilder()Lcom/vdocipher/PlaybackInfo$Captions$Builder;

    move-result-object v7

    .line 175
    invoke-virtual {v6, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v8

    invoke-virtual {v7, v8}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->setUrlBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;

    .line 176
    const-string v8, "lang"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->setLang(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;

    .line 177
    const-string v8, "label"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->setLabel(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;

    .line 178
    const-string v8, "isDefault"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v8

    invoke-virtual {v7, v8}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->setIsDefault(Z)Lcom/vdocipher/PlaybackInfo$Captions$Builder;

    .line 179
    const-string v8, "captionName"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->setCaptionName(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;

    .line 180
    const-string/jumbo v8, "subtitleName"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->setSubtitleName(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$Captions$Builder;

    .line 181
    invoke-virtual {v7}, Lcom/vdocipher/PlaybackInfo$Captions$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object v6

    check-cast v6, Lcom/vdocipher/PlaybackInfo$Captions;

    invoke-virtual {v0, v6}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->addCaptions(Lcom/vdocipher/PlaybackInfo$Captions;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_396

    .line 186
    :cond_3e9
    const-string p1, "errorMsgs"

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    if-eqz p1, :cond_437

    move v2, v3

    .line 188
    :goto_3f2
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v2, v4, :cond_437

    .line 189
    invoke-virtual {p1, v2}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    .line 190
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$ErrorMessage;->newBuilder()Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;

    move-result-object v6

    .line 192
    const-string v7, "codes"

    invoke-virtual {v4, v7}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v7

    if-eqz v7, :cond_419

    move v8, v3

    .line 194
    :goto_409
    invoke-virtual {v7}, Lorg/json/JSONArray;->length()I

    move-result v9

    if-ge v8, v9, :cond_419

    .line 195
    invoke-virtual {v7, v8}, Lorg/json/JSONArray;->optInt(I)I

    move-result v9

    invoke-virtual {v6, v9}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->addCodes(I)Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;

    add-int/lit8 v8, v8, 0x1

    goto :goto_409

    .line 199
    :cond_419
    const-string v7, "msgKey"

    invoke-virtual {v4, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->setMsgKey(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;

    .line 200
    const-string v7, "msgDefault"

    invoke-virtual {v4, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v6, v4}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->setMsgDefault(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;

    .line 202
    invoke-virtual {v6}, Lcom/vdocipher/PlaybackInfo$ErrorMessage$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object v4

    check-cast v4, Lcom/vdocipher/PlaybackInfo$ErrorMessage;

    invoke-virtual {v0, v4}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->addErrorMsgs(Lcom/vdocipher/PlaybackInfo$ErrorMessage;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_3f2

    .line 207
    :cond_437
    const-string p1, "language"

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    if-eqz p1, :cond_475

    .line 209
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;->newBuilder()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;

    move-result-object v1

    .line 210
    const-string v2, "direction"

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "rtl"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_454

    sget-object v2, Lcom/vdocipher/PlaybackInfo$MessageDirection;->rtl:Lcom/vdocipher/PlaybackInfo$MessageDirection;

    goto :goto_456

    :cond_454
    sget-object v2, Lcom/vdocipher/PlaybackInfo$MessageDirection;->ltr:Lcom/vdocipher/PlaybackInfo$MessageDirection;

    :goto_456
    invoke-virtual {v1, v2}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->setDirection(Lcom/vdocipher/PlaybackInfo$MessageDirection;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;

    move-result-object v1

    .line 211
    invoke-virtual {p1, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->setId(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;

    move-result-object v1

    .line 212
    const-string v2, "hash"

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->setHash(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;

    move-result-object p1

    .line 213
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    .line 214
    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->setLanguage(Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;)Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;

    .line 221
    :cond_475
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$MetadataTable;

    return-object p1
.end method

.method public f()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDash()Lcom/vdocipher/PlaybackInfo$DASH;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getEnforceHardwareAttestation()Z

    move-result v0

    return v0
.end method

.method public g()Ljava/util/ArrayList;
    .registers 4

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 3
    :try_start_5
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v1}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDash()Lcom/vdocipher/PlaybackInfo$DASH;

    move-result-object v1

    invoke-virtual {v1}, Lcom/vdocipher/PlaybackInfo$DASH;->getErrorCodesAL3List()Ljava/util/List;

    move-result-object v1

    .line 4
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_12} :catch_13

    return-object v0

    :catch_13
    move-exception v1

    .line 6
    invoke-static {v1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "MetaParser"

    invoke-static {v2, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public h()Ljava/lang/String;
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDash()Lcom/vdocipher/PlaybackInfo$DASH;

    move-result-object v0

    .line 2
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 3
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getFallbackLicenseServersList()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_13
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_28

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 4
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ","

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_13

    .line 6
    :cond_28
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public i()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getIntegrityCloudId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public j()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getLanguage()Lcom/vdocipher/PlaybackInfo$ErrorMessageLanguage;

    move-result-object v0

    return-object v0
.end method

.method public k()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDash()Lcom/vdocipher/PlaybackInfo$DASH;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getManifest()Lcom/google/protobuf/ByteString;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public l()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getH6()Lcom/vdocipher/PlaybackInfo$H6;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$H6;->getManifest()Lcom/google/protobuf/ByteString;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public m()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getVersion()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public n()Ljava/lang/String;
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDash()Lcom/vdocipher/PlaybackInfo$DASH;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getMpdString()Lcom/google/protobuf/ByteString;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->isEmpty()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_2f

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDash()Lcom/vdocipher/PlaybackInfo$DASH;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getMpdString()Lcom/google/protobuf/ByteString;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_26

    return-object v1

    .line 5
    :cond_26
    invoke-static {v0}, Lcom/vdocipher/aegis/core/t/b;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 6
    invoke-static {v0}, Lcom/vdocipher/aegis/core/t/b;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_2f
    return-object v1
.end method

.method public o()[Ljava/lang/String;
    .registers 5

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getPostersList()Ljava/util/List;

    move-result-object v0

    .line 2
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    .line 3
    :goto_d
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    if-ge v2, v3, :cond_22

    .line 4
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-virtual {v3}, Lcom/vdocipher/PlaybackInfo$Posters;->getUrl()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_d

    :cond_22
    return-object v1
.end method

.method public p()Ljava/util/ArrayList;
    .registers 7

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getPostersList()Ljava/util/List;

    move-result-object v0

    .line 2
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    .line 3
    :goto_c
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    if-ge v2, v3, :cond_35

    .line 4
    new-instance v3, Lcom/vdocipher/aegis/media/Posters;

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-virtual {v4}, Lcom/vdocipher/PlaybackInfo$Posters;->getUrl()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/vdocipher/PlaybackInfo$Posters;

    invoke-virtual {v5}, Lcom/vdocipher/PlaybackInfo$Posters;->getHeight()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-direct {v3, v4, v5}, Lcom/vdocipher/aegis/media/Posters;-><init>(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 5
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_c

    :cond_35
    return-object v1
.end method

.method public q()[Ljava/lang/String;
    .registers 6

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getTechValueList()Ljava/util/List;

    move-result-object v0

    .line 2
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    .line 3
    :goto_d
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    if-ge v2, v3, :cond_6f

    .line 4
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    if-nez v3, :cond_24

    .line 5
    const-string v3, "dash"

    aput-object v3, v1, v2

    goto :goto_6c

    .line 6
    :cond_24
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const/4 v4, 0x5

    if-ne v3, v4, :cond_36

    .line 7
    const-string v3, "hlse"

    aput-object v3, v1, v2

    goto :goto_6c

    .line 8
    :cond_36
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const/4 v4, 0x4

    if-ne v3, v4, :cond_48

    .line 9
    const-string v3, "h6"

    aput-object v3, v1, v2

    goto :goto_6c

    .line 10
    :cond_48
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const/4 v4, 0x6

    if-ne v3, v4, :cond_5a

    .line 11
    const-string v3, "h1"

    aput-object v3, v1, v2

    goto :goto_6c

    .line 12
    :cond_5a
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const/4 v4, 0x3

    if-ne v3, v4, :cond_6c

    .line 13
    const-string/jumbo v3, "zen"

    aput-object v3, v1, v2

    :cond_6c
    :goto_6c
    add-int/lit8 v2, v2, 0x1

    goto :goto_d

    :cond_6f
    return-object v1
.end method

.method public r()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getTitle()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public s()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/g;->a:Lcom/vdocipher/PlaybackInfo$MetadataTable;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$MetadataTable;->getDash()Lcom/vdocipher/PlaybackInfo$DASH;

    move-result-object v0

    .line 2
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getLicenseServers()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
