# classes14.dex

.class public final Lcom/vdocipher/aegis/core/f/f;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/core/f/f$b;
    }
.end annotation


# instance fields
.field private final a:Landroid/os/HandlerThread;

.field private final b:Landroid/os/Handler;

.field private c:Landroid/os/Handler;

.field private d:Ljava/lang/Object;

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;

.field private g:Lcom/vdocipher/aegis/core/f/f$b;

.field private h:Landroid/content/Context;

.field private final i:Lcom/vdocipher/aegis/core/g/c;


# direct methods
.method public static synthetic $r8$lambda$2mjF7tkxNb2PZHbdrnUpd60_7SY(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/f/f;->a(ILjava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$5V5QHUrjDbKKYQ39x_AvCpOLnxs(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;Ljava/lang/Throwable;)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/f/f;->a(ILjava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method

.method public static synthetic $r8$lambda$6TzOaM61GMAAcbrS_fYeMPo4NnU(Lcom/vdocipher/aegis/core/f/f;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/aegis/core/f/f;->b()V

    return-void
.end method

.method public static synthetic $r8$lambda$OVqV3k4VH98IMCGqLqj7Qaq4KGI(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;J)V
    .registers 5

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/vdocipher/aegis/core/f/f;->a(ILjava/lang/String;J)V

    return-void
.end method

.method public static synthetic $r8$lambda$oc2EQrLt2ZIvI0DSAZjoK52_ce8(Lcom/vdocipher/aegis/core/f/f;Ljava/lang/String;Ljava/lang/Exception;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/f/f;->a(Ljava/lang/String;Ljava/lang/Exception;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lcom/vdocipher/aegis/core/f/f;->g:Lcom/vdocipher/aegis/core/f/f$b;

    .line 37
    new-instance v0, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda4;

    invoke-direct {v0, p0}, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda4;-><init>(Lcom/vdocipher/aegis/core/f/f;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/f/f;->i:Lcom/vdocipher/aegis/core/g/c;

    .line 38
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/f;->h:Landroid/content/Context;

    .line 39
    new-instance p1, Landroid/os/HandlerThread;

    const-string v0, "MF"

    invoke-direct {p1, v0}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/f;->a:Landroid/os/HandlerThread;

    .line 40
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    .line 41
    new-instance v0, Landroid/os/Handler;

    invoke-virtual {p1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object p1

    invoke-direct {v0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/f/f;->b:Landroid/os/Handler;

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/f/f;)Ljava/lang/String;
    .registers 1

    .line 3
    iget-object p0, p0, Lcom/vdocipher/aegis/core/f/f;->e:Ljava/lang/String;

    return-object p0
.end method

.method private a()V
    .registers 8

    .line 12
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 13
    const-string v1, "https://meta.vdocipher.com"

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 15
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    .line 18
    new-instance v3, Lcom/vdocipher/aegis/core/g/b;

    iget-object v4, p0, Lcom/vdocipher/aegis/core/f/f;->h:Landroid/content/Context;

    iget-object v5, p0, Lcom/vdocipher/aegis/core/f/f;->i:Lcom/vdocipher/aegis/core/g/c;

    iget-object v6, p0, Lcom/vdocipher/aegis/core/f/f;->f:Ljava/lang/String;

    invoke-direct {v3, v4, v0, v5, v6}, Lcom/vdocipher/aegis/core/g/b;-><init>(Landroid/content/Context;Ljava/util/List;Lcom/vdocipher/aegis/core/g/c;Ljava/lang/String;)V

    .line 20
    :try_start_21
    new-instance v0, Ljava/net/URL;

    iget-object v4, p0, Lcom/vdocipher/aegis/core/f/f;->e:Ljava/lang/String;

    invoke-direct {v0, v4}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    new-instance v4, Lcom/vdocipher/aegis/core/f/f$a;

    invoke-direct {v4, p0, v1, v2}, Lcom/vdocipher/aegis/core/f/f$a;-><init>(Lcom/vdocipher/aegis/core/f/f;J)V

    invoke-virtual {v3, v0, v4}, Lcom/vdocipher/aegis/core/g/b;->a(Ljava/net/URL;Lcom/vdocipher/aegis/core/g/e;)V
    :try_end_30
    .catchall {:try_start_21 .. :try_end_30} :catchall_31

    return-void

    :catchall_31
    move-exception v0

    .line 39
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "MF"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method private synthetic a(ILjava/lang/String;J)V
    .registers 13

    .line 40
    monitor-enter p0

    .line 41
    :try_start_1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/f;->g:Lcom/vdocipher/aegis/core/f/f$b;

    if-eqz v0, :cond_11

    .line 42
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/f;->d:Ljava/lang/Object;

    iget-object v6, p0, Lcom/vdocipher/aegis/core/f/f;->e:Ljava/lang/String;

    iget-object v7, p0, Lcom/vdocipher/aegis/core/f/f;->f:Ljava/lang/String;

    move v2, p1

    move-object v3, p2

    move-wide v4, p3

    invoke-interface/range {v0 .. v7}, Lcom/vdocipher/aegis/core/f/f$b;->onMetaReceived(Ljava/lang/Object;ILjava/lang/String;JLjava/lang/String;Ljava/lang/String;)V

    .line 43
    :cond_11
    monitor-exit p0

    return-void

    :catchall_13
    move-exception v0

    move-object p1, v0

    monitor-exit p0
    :try_end_16
    .catchall {:try_start_1 .. :try_end_16} :catchall_13

    throw p1
.end method

.method private synthetic a(ILjava/lang/String;Ljava/lang/String;)V
    .registers 10

    .line 48
    monitor-enter p0

    .line 49
    :try_start_1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/f;->g:Lcom/vdocipher/aegis/core/f/f$b;

    if-eqz v0, :cond_e

    .line 50
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/f;->d:Ljava/lang/Object;

    const/4 v4, 0x0

    move v2, p1

    move-object v3, p2

    move-object v5, p3

    invoke-interface/range {v0 .. v5}, Lcom/vdocipher/aegis/core/f/f$b;->onMetaUrlFailed(Ljava/lang/Object;ILjava/lang/String;ZLjava/lang/String;)V

    .line 51
    :cond_e
    monitor-exit p0

    return-void

    :catchall_10
    move-exception v0

    move-object p1, v0

    monitor-exit p0
    :try_end_13
    .catchall {:try_start_1 .. :try_end_13} :catchall_10

    throw p1
.end method

.method private synthetic a(ILjava/lang/String;Ljava/lang/Throwable;)V
    .registers 11

    .line 44
    monitor-enter p0

    .line 45
    :try_start_1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/f;->g:Lcom/vdocipher/aegis/core/f/f$b;

    if-eqz v0, :cond_11

    .line 46
    iget-object v1, p0, Lcom/vdocipher/aegis/core/f/f;->d:Ljava/lang/Object;

    iget-object v5, p0, Lcom/vdocipher/aegis/core/f/f;->e:Ljava/lang/String;

    iget-object v6, p0, Lcom/vdocipher/aegis/core/f/f;->f:Ljava/lang/String;

    move v2, p1

    move-object v3, p2

    move-object v4, p3

    invoke-interface/range {v0 .. v6}, Lcom/vdocipher/aegis/core/f/f$b;->onMetaNotReceived(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;Ljava/lang/String;)V

    .line 47
    :cond_11
    monitor-exit p0

    return-void

    :catchall_13
    move-exception v0

    move-object p1, v0

    monitor-exit p0
    :try_end_16
    .catchall {:try_start_1 .. :try_end_16} :catchall_13

    throw p1
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;J)V
    .registers 5

    .line 1
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/vdocipher/aegis/core/f/f;->b(ILjava/lang/String;J)V

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 4
    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/f/f;->b(ILjava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;Ljava/lang/Throwable;)V
    .registers 4

    .line 2
    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/f/f;->b(ILjava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method

.method private synthetic a(Ljava/lang/String;Ljava/lang/Exception;)V
    .registers 4

    .line 11
    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    const/4 v0, -0x1

    invoke-direct {p0, v0, p1, p2}, Lcom/vdocipher/aegis/core/f/f;->b(ILjava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private synthetic b()V
    .registers 4

    .line 1
    :try_start_0
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/f/f;->a()V
    :try_end_3
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_3} :catch_4

    return-void

    :catch_4
    move-exception v0

    .line 3
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "MF"

    invoke-static {v2, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, -0x1

    const/4 v2, 0x0

    .line 4
    invoke-direct {p0, v1, v2, v0}, Lcom/vdocipher/aegis/core/f/f;->b(ILjava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method

.method private b(ILjava/lang/String;J)V
    .registers 12

    .line 5
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/f;->c:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda3;

    move-object v2, p0

    move v3, p1

    move-object v4, p2

    move-wide v5, p3

    invoke-direct/range {v1 .. v6}, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda3;-><init>(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;J)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private b(ILjava/lang/String;Ljava/lang/String;)V
    .registers 6

    .line 7
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/f;->c:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda1;-><init>(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private b(ILjava/lang/String;Ljava/lang/Throwable;)V
    .registers 6

    .line 6
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/f;->c:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/core/f/f;ILjava/lang/String;Ljava/lang/Throwable;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method


# virtual methods
.method public declared-synchronized a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;Lcom/vdocipher/aegis/core/f/f$b;)V
    .registers 7

    monitor-enter p0

    .line 5
    :try_start_1
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/f/f;->c:Landroid/os/Handler;

    .line 6
    iput-object p1, p0, Lcom/vdocipher/aegis/core/f/f;->e:Ljava/lang/String;

    if-eqz p2, :cond_11

    goto :goto_15

    .line 7
    :cond_11
    invoke-static {}, Lcom/vdocipher/aegis/core/z/d;->b()Ljava/lang/String;

    move-result-object p2

    :goto_15
    iput-object p2, p0, Lcom/vdocipher/aegis/core/f/f;->f:Ljava/lang/String;

    .line 8
    iput-object p3, p0, Lcom/vdocipher/aegis/core/f/f;->d:Ljava/lang/Object;

    .line 9
    iput-object p4, p0, Lcom/vdocipher/aegis/core/f/f;->g:Lcom/vdocipher/aegis/core/f/f$b;

    .line 10
    iget-object p1, p0, Lcom/vdocipher/aegis/core/f/f;->b:Landroid/os/Handler;

    new-instance p2, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda2;

    invoke-direct {p2, p0}, Lcom/vdocipher/aegis/core/f/f$$ExternalSyntheticLambda2;-><init>(Lcom/vdocipher/aegis/core/f/f;)V

    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_25
    .catchall {:try_start_1 .. :try_end_25} :catchall_27

    monitor-exit p0

    return-void

    :catchall_27
    move-exception p1

    :try_start_28
    monitor-exit p0
    :try_end_29
    .catchall {:try_start_28 .. :try_end_29} :catchall_27

    throw p1
.end method

.method public declared-synchronized c()V
    .registers 2

    monitor-enter p0

    const/4 v0, 0x0

    .line 1
    :try_start_2
    iput-object v0, p0, Lcom/vdocipher/aegis/core/f/f;->g:Lcom/vdocipher/aegis/core/f/f$b;

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/f/f;->a:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->quit()Z
    :try_end_9
    .catchall {:try_start_2 .. :try_end_9} :catchall_b

    monitor-exit p0

    return-void

    :catchall_b
    move-exception v0

    :try_start_c
    monitor-exit p0
    :try_end_d
    .catchall {:try_start_c .. :try_end_d} :catchall_b

    throw v0
.end method
