# classes14.dex

.class public interface abstract Lcom/vdocipher/aegis/core/a/a;
.super Ljava/lang/Object;
.source "SourceFile"
