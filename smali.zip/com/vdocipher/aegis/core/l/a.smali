# classes14.dex

.class public final Lcom/vdocipher/aegis/core/l/a;
.super Landroid/database/sqlite/SQLiteOpenHelper;
.source "SourceFile"


# instance fields
.field private a:Ljava/lang/String;

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 5

    const/4 v0, 0x0

    const/16 v1, 0x9

    .line 1
    const-string/jumbo v2, "vdo_offline.db"

    invoke-direct {p0, p1, v2, v0, v1}, Landroid/database/sqlite/SQLiteOpenHelper;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;I)V

    .line 2
    const-string p1, "ALTER TABLE auto_resume ADD COLUMN last_played_at INTEGER"

    iput-object p1, p0, Lcom/vdocipher/aegis/core/l/a;->a:Ljava/lang/String;

    .line 3
    const-string p1, "ALTER TABLE crash_log ADD COLUMN crash_data TEXT"

    iput-object p1, p0, Lcom/vdocipher/aegis/core/l/a;->b:Ljava/lang/String;

    .line 4
    const-string p1, "ALTER TABLE crash_log ADD COLUMN sdk_version TEXT"

    iput-object p1, p0, Lcom/vdocipher/aegis/core/l/a;->c:Ljava/lang/String;

    .line 5
    const-string p1, "ALTER TABLE crash_log ADD COLUMN is_handled INTEGER"

    iput-object p1, p0, Lcom/vdocipher/aegis/core/l/a;->d:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/database/sqlite/SQLiteDatabase;)V
    .registers 4

    .line 1
    const-string v0, "db"

    const-string v1, "create"

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 2
    const-string v0, "CREATE TABLE offline_vdos (_id INTEGER PRIMARY KEY,mediaId TEXT,filePath TEXT,mtype TEXT,manifest TEXT,posters TEXT,title TEXT,description TEXT,durationMs INTEGER,cancelled INTEGER,deleted INTEGER,downloadStatus INTEGER,dlspec TEXT,dlIdentifiers TEXT,status INTEGER,reason INTEGER,error TEXT,mobileReso INTEGER,keyId TEXT,extras TEXT,totalSize INTEGER,bytesDownloaded INTEGER,downloadPercent INTEGER,lastModTime TEXT,log TEXT )"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 3
    const-string v0, "CREATE TABLE vdo_queue (_id INTEGER PRIMARY KEY,mediaId TEXT,cancelled INTEGER,deleted INTEGER,dlspec TEXT,timeAdded TEXT,extras TEXT )"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 4
    const-string v0, "CREATE TABLE sessions (_id INTEGER PRIMARY KEY,mediaId TEXT,sessionId TEXT, UNIQUE(mediaId) )"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 5
    const-string v0, "CREATE TABLE auto_resume (_id INTEGER PRIMARY KEY,mediaId TEXT,position TEXT,last_played_at TEXT, UNIQUE(mediaId) )"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 6
    const-string v0, "CREATE TABLE deletion_entry (_id INTEGER PRIMARY KEY,mediaId TEXT,canDelete INTEGER, UNIQUE(mediaId) )"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 7
    const-string v0, "CREATE TABLE usage_log (_id INTEGER PRIMARY KEY,hash INTEGER,method_name TEXT,class_name INTEGER,count INTEGER DEFAULT 0,is_updated INTEGER DEFAULT 0, UNIQUE(hash) )"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 8
    const-string v0, "CREATE TABLE crash_log (_id INTEGER PRIMARY KEY,stacktrace TEXT,crash_data TEXT,timestamp TEXT,sdk_version TEXT,is_handled INTEGER DEFAULT 0 )"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 9
    const-string v0, "CREATE TABLE media_item_detail (_id INTEGER PRIMARY KEY,media_Id TEXT,cs_session_id TEXT,meta_data TEXT,b64Annotations TEXT, UNIQUE(media_Id) )"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 10
    const-string v0, "CREATE TABLE pre_cache_album_art (_id INTEGER PRIMARY KEY AUTOINCREMENT,media_id TEXT UNIQUE,uri TEXT,file_path TEXT,meta_url TEXT,language_code TEXT,meta_data TEXT )"

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    return-void
.end method

.method public onUpgrade(Landroid/database/sqlite/SQLiteDatabase;II)V
    .registers 10

    .line 1
    const-string p3, "db"

    const-string/jumbo v0, "upgrade"

    invoke-static {p3, v0}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/16 p3, 0x8

    const-string v0, "CREATE TABLE pre_cache_album_art (_id INTEGER PRIMARY KEY AUTOINCREMENT,media_id TEXT UNIQUE,uri TEXT,file_path TEXT,meta_url TEXT,language_code TEXT,meta_data TEXT )"

    if-ne p2, p3, :cond_11

    .line 4
    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    :cond_11
    const/4 p3, 0x7

    const-string v1, "CREATE TABLE media_item_detail (_id INTEGER PRIMARY KEY,media_Id TEXT,cs_session_id TEXT,meta_data TEXT,b64Annotations TEXT, UNIQUE(media_Id) )"

    if-ne p2, p3, :cond_1c

    .line 7
    invoke-virtual {p1, v1}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 8
    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    :cond_1c
    const/4 p3, 0x6

    if-ne p2, p3, :cond_2f

    .line 11
    invoke-virtual {p1, v1}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 12
    iget-object p3, p0, Lcom/vdocipher/aegis/core/l/a;->c:Ljava/lang/String;

    invoke-virtual {p1, p3}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 13
    iget-object p3, p0, Lcom/vdocipher/aegis/core/l/a;->d:Ljava/lang/String;

    invoke-virtual {p1, p3}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 14
    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    :cond_2f
    const/4 p3, 0x5

    if-ne p2, p3, :cond_47

    .line 17
    invoke-virtual {p1, v1}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 18
    iget-object p3, p0, Lcom/vdocipher/aegis/core/l/a;->b:Ljava/lang/String;

    invoke-virtual {p1, p3}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 19
    iget-object p3, p0, Lcom/vdocipher/aegis/core/l/a;->c:Ljava/lang/String;

    invoke-virtual {p1, p3}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 20
    iget-object p3, p0, Lcom/vdocipher/aegis/core/l/a;->d:Ljava/lang/String;

    invoke-virtual {p1, p3}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 21
    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    :cond_47
    const/4 p3, 0x4

    const-string v2, "CREATE TABLE crash_log (_id INTEGER PRIMARY KEY,stacktrace TEXT,crash_data TEXT,timestamp TEXT,sdk_version TEXT,is_handled INTEGER DEFAULT 0 )"

    const-string v3, "CREATE TABLE usage_log (_id INTEGER PRIMARY KEY,hash INTEGER,method_name TEXT,class_name INTEGER,count INTEGER DEFAULT 0,is_updated INTEGER DEFAULT 0, UNIQUE(hash) )"

    if-ne p2, p3, :cond_5a

    .line 24
    invoke-virtual {p1, v3}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 25
    invoke-virtual {p1, v2}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 26
    invoke-virtual {p1, v1}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 27
    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    :cond_5a
    const/4 p3, 0x3

    const-string v4, "CREATE TABLE deletion_entry (_id INTEGER PRIMARY KEY,mediaId TEXT,canDelete INTEGER, UNIQUE(mediaId) )"

    if-ne p2, p3, :cond_73

    .line 30
    invoke-virtual {p1, v4}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 31
    iget-object p3, p0, Lcom/vdocipher/aegis/core/l/a;->a:Ljava/lang/String;

    invoke-virtual {p1, p3}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 32
    invoke-virtual {p1, v3}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 33
    invoke-virtual {p1, v2}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 34
    invoke-virtual {p1, v1}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 35
    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    :cond_73
    const/4 p3, 0x2

    const-string v5, "CREATE TABLE auto_resume (_id INTEGER PRIMARY KEY,mediaId TEXT,position TEXT,last_played_at TEXT, UNIQUE(mediaId) )"

    if-ne p2, p3, :cond_8a

    .line 38
    invoke-virtual {p1, v4}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 39
    invoke-virtual {p1, v5}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 40
    invoke-virtual {p1, v3}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 41
    invoke-virtual {p1, v2}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 42
    invoke-virtual {p1, v1}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 43
    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    :cond_8a
    const/4 p3, 0x1

    if-ne p2, p3, :cond_a4

    .line 46
    invoke-virtual {p1, v4}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 47
    invoke-virtual {p1, v5}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 48
    const-string p2, "CREATE TABLE sessions (_id INTEGER PRIMARY KEY,mediaId TEXT,sessionId TEXT, UNIQUE(mediaId) )"

    invoke-virtual {p1, p2}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 49
    invoke-virtual {p1, v3}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 50
    invoke-virtual {p1, v2}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 51
    invoke-virtual {p1, v1}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 52
    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    :cond_a4
    return-void
.end method
