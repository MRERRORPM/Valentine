# classes14.dex

.class public final Lcom/vdocipher/aegis/core/i/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:I

.field private final b:Ljava/lang/String;

.field private final c:Z

.field private final d:Ljava/lang/String;

.field private final e:Ljava/lang/Exception;

.field private final f:Lokhttp3/Headers;


# direct methods
.method public constructor <init>(ILjava/lang/String;ZLjava/lang/String;Ljava/lang/Exception;Lokhttp3/Headers;)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p1, p0, Lcom/vdocipher/aegis/core/i/a;->a:I

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/i/a;->b:Ljava/lang/String;

    .line 4
    iput-boolean p3, p0, Lcom/vdocipher/aegis/core/i/a;->c:Z

    .line 5
    iput-object p4, p0, Lcom/vdocipher/aegis/core/i/a;->d:Ljava/lang/String;

    .line 6
    iput-object p5, p0, Lcom/vdocipher/aegis/core/i/a;->e:Ljava/lang/Exception;

    .line 7
    iput-object p6, p0, Lcom/vdocipher/aegis/core/i/a;->f:Lokhttp3/Headers;

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;ZLjava/lang/String;Ljava/lang/Exception;Lokhttp3/Headers;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 10

    and-int/lit8 p8, p7, 0x2

    const/4 v0, 0x0

    if-eqz p8, :cond_6

    move-object p2, v0

    :cond_6
    and-int/lit8 p8, p7, 0x4

    if-eqz p8, :cond_b

    const/4 p3, 0x0

    :cond_b
    and-int/lit8 p8, p7, 0x8

    if-eqz p8, :cond_10

    move-object p4, v0

    :cond_10
    and-int/lit8 p8, p7, 0x10

    if-eqz p8, :cond_15

    move-object p5, v0

    :cond_15
    and-int/lit8 p7, p7, 0x20

    if-eqz p7, :cond_1b

    move-object p7, v0

    goto :goto_1c

    :cond_1b
    move-object p7, p6

    :goto_1c
    move-object p6, p5

    move-object p5, p4

    move p4, p3

    move-object p3, p2

    move p2, p1

    move-object p1, p0

    .line 8
    invoke-direct/range {p1 .. p7}, Lcom/vdocipher/aegis/core/i/a;-><init>(ILjava/lang/String;ZLjava/lang/String;Ljava/lang/Exception;Lokhttp3/Headers;)V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/i/a;->b:Ljava/lang/String;

    return-object v0
.end method

.method public final b()I
    .registers 2

    .line 1
    iget v0, p0, Lcom/vdocipher/aegis/core/i/a;->a:I

    return v0
.end method

.method public final c()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/i/a;->d:Ljava/lang/String;

    return-object v0
.end method

.method public final d()Ljava/lang/Exception;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/i/a;->e:Ljava/lang/Exception;

    return-object v0
.end method

.method public final e()Lokhttp3/Headers;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/i/a;->f:Lokhttp3/Headers;

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    .line 1
    :cond_4
    instance-of v1, p1, Lcom/vdocipher/aegis/core/i/a;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/vdocipher/aegis/core/i/a;

    iget v1, p0, Lcom/vdocipher/aegis/core/i/a;->a:I

    iget v3, p1, Lcom/vdocipher/aegis/core/i/a;->a:I

    if-eq v1, v3, :cond_13

    return v2

    :cond_13
    iget-object v1, p0, Lcom/vdocipher/aegis/core/i/a;->b:Ljava/lang/String;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/i/a;->b:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e

    return v2

    :cond_1e
    iget-boolean v1, p0, Lcom/vdocipher/aegis/core/i/a;->c:Z

    iget-boolean v3, p1, Lcom/vdocipher/aegis/core/i/a;->c:Z

    if-eq v1, v3, :cond_25

    return v2

    :cond_25
    iget-object v1, p0, Lcom/vdocipher/aegis/core/i/a;->d:Ljava/lang/String;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/i/a;->d:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_30

    return v2

    :cond_30
    iget-object v1, p0, Lcom/vdocipher/aegis/core/i/a;->e:Ljava/lang/Exception;

    iget-object v3, p1, Lcom/vdocipher/aegis/core/i/a;->e:Ljava/lang/Exception;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3b

    return v2

    :cond_3b
    iget-object v1, p0, Lcom/vdocipher/aegis/core/i/a;->f:Lokhttp3/Headers;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/i/a;->f:Lokhttp3/Headers;

    invoke-static {v1, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_46

    return v2

    :cond_46
    return v0
.end method

.method public final f()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/i/a;->c:Z

    return v0
.end method

.method public hashCode()I
    .registers 4

    .line 1
    iget v0, p0, Lcom/vdocipher/aegis/core/i/a;->a:I

    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lcom/vdocipher/aegis/core/i/a;->b:Ljava/lang/String;

    const/4 v2, 0x0

    if-nez v1, :cond_f

    move v1, v2

    goto :goto_13

    :cond_f
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    :goto_13
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-boolean v1, p0, Lcom/vdocipher/aegis/core/i/a;->c:Z

    invoke-static {v1}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lcom/vdocipher/aegis/core/i/a;->d:Ljava/lang/String;

    if-nez v1, :cond_25

    move v1, v2

    goto :goto_29

    :cond_25
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    :goto_29
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lcom/vdocipher/aegis/core/i/a;->e:Ljava/lang/Exception;

    if-nez v1, :cond_32

    move v1, v2

    goto :goto_36

    :cond_32
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_36
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lcom/vdocipher/aegis/core/i/a;->f:Lokhttp3/Headers;

    if-nez v1, :cond_3e

    goto :goto_42

    :cond_3e
    invoke-virtual {v1}, Lokhttp3/Headers;->hashCode()I

    move-result v2

    :goto_42
    add-int/2addr v0, v2

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 5

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "VdoApiResponse(code="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, Lcom/vdocipher/aegis/core/i/a;->a:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", isSuccessful="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Lcom/vdocipher/aegis/core/i/a;->c:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", body="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/i/a;->b:Ljava/lang/String;

    const/4 v2, 0x0

    if-eqz v1, :cond_27

    const/16 v3, 0xc8

    invoke-static {v1, v3}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    goto :goto_28

    :cond_27
    move-object v1, v2

    :goto_28
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", errorMessage="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2
    iget-object v1, p0, Lcom/vdocipher/aegis/core/i/a;->d:Ljava/lang/String;

    .line 3
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", exception="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4
    iget-object v1, p0, Lcom/vdocipher/aegis/core/i/a;->e:Ljava/lang/Exception;

    if-eqz v1, :cond_47

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    goto :goto_48

    :cond_47
    move-object v1, v2

    .line 5
    :goto_48
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ": "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 6
    iget-object v1, p0, Lcom/vdocipher/aegis/core/i/a;->e:Ljava/lang/Exception;

    if-eqz v1, :cond_58

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    .line 7
    :cond_58
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
