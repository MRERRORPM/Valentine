# classes14.dex

.class public abstract Lcom/vdocipher/aegis/core/k/h;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Landroid/content/Context;Lcom/vdocipher/aegis/core/k/k;Lcom/vdocipher/aegis/core/q/b;)Lcom/vdocipher/aegis/core/k/g;
    .registers 21

    move-object/from16 v0, p1

    const-string v1, "duration license "

    const-string v2, "ac "

    const-string/jumbo v3, "sl "

    const-string v4, "ksid "

    .line 17
    const-string v5, "get lic"

    const-string v6, "OffLicDlStep"

    invoke-static {v6, v5}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 18
    invoke-static {}, Lcom/vdocipher/aegis/core/t/d;->b()Ljava/lang/String;

    move-result-object v5

    .line 20
    new-instance v7, Lcom/vdocipher/aegis/core/z/e;

    move-object/from16 v9, p0

    invoke-direct {v7, v9}, Lcom/vdocipher/aegis/core/z/e;-><init>(Landroid/content/Context;)V

    invoke-virtual {v7}, Lcom/vdocipher/aegis/core/z/e;->a()Lorg/chromium/net/CronetEngine;

    move-result-object v7

    .line 22
    new-instance v8, Lcom/vdocipher/aegis/core/z/f$a;

    invoke-direct {v8, v7}, Lcom/vdocipher/aegis/core/z/f$a;-><init>(Lorg/chromium/net/CronetEngine;)V

    invoke-virtual {v8, v5}, Lcom/vdocipher/aegis/core/z/f$a;->a(Ljava/lang/String;)Lcom/vdocipher/aegis/core/z/f$a;

    move-result-object v10

    .line 25
    iget-object v5, v0, Lcom/vdocipher/aegis/core/k/k;->d:Ljava/lang/String;

    const-string v7, "http"

    invoke-virtual {v5, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_43

    .line 26
    invoke-virtual {v10}, Lcom/vdocipher/aegis/core/z/f$a;->a()Lcom/vdocipher/aegis/core/z/f;

    move-result-object v5

    iget-object v7, v0, Lcom/vdocipher/aegis/core/k/k;->d:Ljava/lang/String;

    invoke-static {v7}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v7

    invoke-static {v5, v7}, Landroidx/media3/exoplayer/dash/DashUtil;->loadManifest(Landroidx/media3/datasource/DataSource;Landroid/net/Uri;)Landroidx/media3/exoplayer/dash/manifest/DashManifest;

    move-result-object v5

    goto :goto_5e

    .line 28
    :cond_43
    iget-object v5, v0, Lcom/vdocipher/aegis/core/k/k;->d:Ljava/lang/String;

    const-string v7, "file://"

    const-string v8, ""

    invoke-virtual {v5, v7, v8}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v5

    .line 29
    invoke-virtual {v10}, Lcom/vdocipher/aegis/core/z/f$a;->a()Lcom/vdocipher/aegis/core/z/f;

    move-result-object v7

    new-instance v8, Ljava/io/File;

    invoke-direct {v8, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-static {v8}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object v5

    invoke-static {v7, v5}, Landroidx/media3/exoplayer/dash/DashUtil;->loadManifest(Landroidx/media3/datasource/DataSource;Landroid/net/Uri;)Landroidx/media3/exoplayer/dash/manifest/DashManifest;

    move-result-object v5

    .line 33
    :goto_5e
    invoke-virtual {v10}, Lcom/vdocipher/aegis/core/z/f$a;->a()Lcom/vdocipher/aegis/core/z/f;

    move-result-object v7

    const/4 v8, 0x0

    .line 34
    invoke-virtual {v5, v8}, Landroidx/media3/exoplayer/dash/manifest/DashManifest;->getPeriod(I)Landroidx/media3/exoplayer/dash/manifest/Period;

    move-result-object v5

    .line 35
    invoke-static {v7, v5}, Landroidx/media3/exoplayer/dash/DashUtil;->loadFormatWithDrmInitData(Landroidx/media3/datasource/DataSource;Landroidx/media3/exoplayer/dash/manifest/Period;)Landroidx/media3/common/Format;

    move-result-object v5

    .line 39
    iget-object v7, v0, Lcom/vdocipher/aegis/core/k/k;->c:Ljava/lang/String;

    if-eqz v7, :cond_76

    invoke-static {v7}, Lcom/vdocipher/aegis/core/t/d;->h(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_76

    const/4 v8, 0x1

    :cond_76
    move v15, v8

    .line 44
    :try_start_77
    new-instance v8, Lcom/vdocipher/aegis/core/k/i;

    iget-object v11, v0, Lcom/vdocipher/aegis/core/k/k;->e:Ljava/lang/String;

    iget-object v12, v0, Lcom/vdocipher/aegis/core/k/k;->f:Ljava/util/ArrayList;

    iget-object v13, v0, Lcom/vdocipher/aegis/core/k/k;->g:Ljava/lang/String;

    iget-object v0, v0, Lcom/vdocipher/aegis/core/k/k;->q:Ljava/lang/String;

    move-object/from16 v14, p2

    move-object/from16 v16, v0

    invoke-direct/range {v8 .. v16}, Lcom/vdocipher/aegis/core/k/i;-><init>(Landroid/content/Context;Lcom/vdocipher/aegis/core/z/f$a;Ljava/lang/String;Ljava/util/ArrayList;Ljava/lang/String;Lcom/vdocipher/aegis/core/q/b;ZLjava/lang/String;)V

    .line 47
    invoke-virtual {v8, v5}, Lcom/vdocipher/aegis/core/k/i;->a(Landroidx/media3/common/Format;)[B

    move-result-object v10
    :try_end_8c
    .catch Ljava/lang/Exception; {:try_start_77 .. :try_end_8c} :catch_116

    if-eqz v10, :cond_10e

    .line 56
    :try_start_8e
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    array-length v4, v10

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, " bytes"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v6, v0}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 57
    invoke-virtual {v8}, Lcom/vdocipher/aegis/core/k/i;->c()Ljava/lang/String;

    move-result-object v12

    .line 58
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v6, v0}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 59
    invoke-virtual {v8}, Lcom/vdocipher/aegis/core/k/i;->a()Ljava/lang/String;

    move-result-object v11

    .line 60
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v6, v0}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 61
    invoke-virtual {v8, v10}, Lcom/vdocipher/aegis/core/k/i;->a([B)Landroid/util/Pair;

    move-result-object v0

    .line 62
    iget-object v2, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v13

    .line 63
    iget-object v2, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v15

    .line 64
    invoke-virtual {v8}, Lcom/vdocipher/aegis/core/k/i;->b()Ljava/lang/String;

    move-result-object v17

    .line 65
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", playback "

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v6, v0}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 66
    invoke-virtual {v8}, Lcom/vdocipher/aegis/core/k/i;->d()V

    .line 67
    new-instance v9, Lcom/vdocipher/aegis/core/k/g;

    invoke-direct/range {v9 .. v17}, Lcom/vdocipher/aegis/core/k/g;-><init>([BLjava/lang/String;Ljava/lang/String;JJLjava/lang/String;)V
    :try_end_104
    .catch Ljava/lang/Exception; {:try_start_8e .. :try_end_104} :catch_105

    return-object v9

    :catch_105
    move-exception v0

    .line 69
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v6, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 70
    throw v0

    .line 71
    :cond_10e
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "null ks"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :catch_116
    move-exception v0

    .line 72
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v6, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 73
    throw v0
.end method

.method public static a(Landroidx/media3/exoplayer/drm/DrmSession$DrmSessionException;)Lcom/vdocipher/aegis/core/m/u$c;
    .registers 2

    .line 74
    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    :goto_4
    if-eqz p0, :cond_12

    .line 76
    instance-of v0, p0, Lcom/vdocipher/aegis/core/m/u$c;

    if-eqz v0, :cond_d

    .line 77
    check-cast p0, Lcom/vdocipher/aegis/core/m/u$c;

    return-object p0

    .line 79
    :cond_d
    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    goto :goto_4

    :cond_12
    const/4 p0, 0x0

    return-object p0
.end method

.method public static a(Landroid/content/Context;Lcom/vdocipher/aegis/core/k/k;)Lcom/vdocipher/aegis/core/q/b;
    .registers 9

    const-string/jumbo v0, "token"

    .line 1
    iget-object v1, p1, Lcom/vdocipher/aegis/core/k/k;->g:Ljava/lang/String;

    if-eqz v1, :cond_44

    .line 3
    :try_start_7
    new-instance v1, Lorg/json/JSONObject;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->g:Ljava/lang/String;

    invoke-direct {v1, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 4
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_44

    .line 5
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_18
    .catch Lorg/json/JSONException; {:try_start_7 .. :try_end_18} :catch_19

    goto :goto_45

    :catch_19
    move-exception v0

    move-object p0, v0

    .line 8
    new-instance p1, Lcom/vdocipher/aegis/core/k/f;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 11
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ": "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x41a

    const/4 v2, -0x1

    invoke-direct {p1, v1, v2, v0, p0}, Lcom/vdocipher/aegis/core/k/f;-><init>(IILjava/lang/String;Ljava/lang/Throwable;)V

    throw p1

    :cond_44
    const/4 v0, 0x0

    :goto_45
    move-object v3, v0

    .line 16
    new-instance v1, Lcom/vdocipher/aegis/core/q/b;

    iget-object v4, p1, Lcom/vdocipher/aegis/core/k/k;->o:Ljava/lang/String;

    iget-object v5, p1, Lcom/vdocipher/aegis/core/k/k;->p:Ljava/lang/String;

    iget-boolean v6, p1, Lcom/vdocipher/aegis/core/k/k;->r:Z

    move-object v2, p0

    invoke-direct/range {v1 .. v6}, Lcom/vdocipher/aegis/core/q/b;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-object v1
.end method

.method public static b(Landroid/content/Context;Lcom/vdocipher/aegis/core/k/k;Lcom/vdocipher/aegis/core/q/b;)Lcom/vdocipher/aegis/core/k/g;
    .registers 8

    const-string v0, ": "

    const/16 v1, 0x424

    const/16 v2, 0x41a

    const/4 v3, -0x1

    .line 1
    :try_start_7
    invoke-static {p0, p1, p2}, Lcom/vdocipher/aegis/core/k/h;->a(Landroid/content/Context;Lcom/vdocipher/aegis/core/k/k;Lcom/vdocipher/aegis/core/q/b;)Lcom/vdocipher/aegis/core/k/g;

    move-result-object p0
    :try_end_b
    .catch Landroidx/media3/exoplayer/drm/DrmSession$DrmSessionException; {:try_start_7 .. :try_end_b} :catch_84
    .catch Landroidx/media3/exoplayer/drm/UnsupportedDrmException; {:try_start_7 .. :try_end_b} :catch_5f
    .catch Ljava/lang/IllegalStateException; {:try_start_7 .. :try_end_b} :catch_5d
    .catch Ljava/lang/InterruptedException; {:try_start_7 .. :try_end_b} :catch_31
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_b} :catch_c

    return-object p0

    :catch_c
    move-exception p0

    .line 58
    new-instance p1, Lcom/vdocipher/aegis/core/k/f;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    .line 61
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, v2, v3, p2, p0}, Lcom/vdocipher/aegis/core/k/f;-><init>(IILjava/lang/String;Ljava/lang/Throwable;)V

    throw p1

    :catch_31
    move-exception p0

    .line 62
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Thread;->interrupt()V

    .line 63
    new-instance p1, Lcom/vdocipher/aegis/core/k/f;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    .line 66
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, v2, v3, p2, p0}, Lcom/vdocipher/aegis/core/k/f;-><init>(IILjava/lang/String;Ljava/lang/Throwable;)V

    throw p1

    :catch_5d
    move-exception p0

    goto :goto_60

    :catch_5f
    move-exception p0

    .line 67
    :goto_60
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 68
    new-instance p2, Lcom/vdocipher/aegis/core/k/f;

    invoke-direct {p2, v1, v3, p1, p0}, Lcom/vdocipher/aegis/core/k/f;-><init>(IILjava/lang/String;Ljava/lang/Throwable;)V

    throw p2

    :catch_84
    move-exception p1

    .line 69
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 71
    invoke-static {p1}, Lcom/vdocipher/aegis/core/k/h;->a(Landroidx/media3/exoplayer/drm/DrmSession$DrmSessionException;)Lcom/vdocipher/aegis/core/m/u$c;

    move-result-object v0

    if-eqz v0, :cond_f1

    .line 73
    iget p2, v0, Lcom/vdocipher/aegis/core/m/u$c;->b:I

    const/16 v1, 0x7ed

    if-lt p2, v1, :cond_c0

    const/16 v1, 0x7f7

    if-gt p2, v1, :cond_c0

    const/16 v2, 0x7f4

    if-eq p2, v2, :cond_b9

    if-ne p2, v1, :cond_c0

    .line 76
    :cond_b9
    invoke-static {p0}, Lcom/vdocipher/aegis/core/q/c;->a(Landroid/content/Context;)Lcom/vdocipher/aegis/core/q/c;

    move-result-object p0

    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/q/c;->a()V

    .line 79
    :cond_c0
    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    instance-of p0, p0, Ljavax/net/ssl/SSLHandshakeException;

    if-eqz p0, :cond_df

    .line 80
    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    .line 81
    instance-of p0, p0, Ljava/security/cert/CertificateException;

    if-eqz p0, :cond_d7

    const/16 p0, 0x41c

    goto :goto_d9

    :cond_d7
    const/16 p0, 0x41d

    :goto_d9
    move v1, p0

    .line 86
    iget v3, v0, Lcom/vdocipher/aegis/core/m/u$c;->d:I

    .line 87
    const-string p2, "Unable to establish a secure connection"

    goto :goto_118

    .line 89
    :cond_df
    iget v1, v0, Lcom/vdocipher/aegis/core/m/u$c;->b:I

    .line 90
    iget v3, v0, Lcom/vdocipher/aegis/core/m/u$c;->d:I

    .line 91
    iget-object p2, v0, Lcom/vdocipher/aegis/core/m/u$c;->c:Ljava/lang/String;

    if-eqz p2, :cond_e8

    goto :goto_118

    :cond_e8
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p2

    goto :goto_118

    .line 93
    :cond_f1
    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    instance-of p0, p0, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;

    if-eqz p0, :cond_118

    .line 95
    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    instance-of p0, p0, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    if-eqz p0, :cond_117

    .line 96
    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    check-cast p0, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    iget v3, p0, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;->responseCode:I

    .line 97
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p2, "License denied: "

    invoke-direct {p0, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    :cond_117
    move v1, v2

    .line 100
    :cond_118
    :goto_118
    new-instance p0, Lcom/vdocipher/aegis/core/k/f;

    if-eqz v0, :cond_11d

    move-object p1, v0

    .line 104
    :cond_11d
    invoke-direct {p0, v1, v3, p2, p1}, Lcom/vdocipher/aegis/core/k/f;-><init>(IILjava/lang/String;Ljava/lang/Throwable;)V

    throw p0
.end method
