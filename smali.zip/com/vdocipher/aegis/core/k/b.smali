# classes14.dex

.class public final Lcom/vdocipher/aegis/core/k/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vdocipher/aegis/core/k/l$a;


# instance fields
.field private final a:Landroid/os/HandlerThread;

.field private final b:Landroid/os/Handler;

.field private c:Landroid/os/Handler;

.field private d:Landroid/content/Context;

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/String;

.field private h:Ljava/lang/String;

.field private i:Ljava/lang/String;

.field private j:Lcom/vdocipher/aegis/offline/OptionsDownloader$Callback;

.field private k:Lcom/vdocipher/aegis/core/f/g;


# direct methods
.method public static synthetic $r8$lambda$di-duXkQnF7x93WZHLTDi2iVRJo(Lcom/vdocipher/aegis/core/k/b;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/aegis/core/k/b;->b()V

    return-void
.end method

.method public static synthetic $r8$lambda$fdpo1nXHiErZFHQH98Qz4t7mW5Q(Lcom/vdocipher/aegis/core/k/b;Lcom/vdocipher/aegis/offline/DownloadOptions;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/k/b;->a(Lcom/vdocipher/aegis/offline/DownloadOptions;)V

    return-void
.end method

.method public static synthetic $r8$lambda$jEQVYTMDNZqHO-6GuE1MEMmC6xI(Lcom/vdocipher/aegis/core/k/b;Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/k/b;->a(Lcom/vdocipher/aegis/media/ErrorDescription;)V

    return-void
.end method

.method public static synthetic $r8$lambda$pdNA6qUIMSA0Vs50hohgnDS594c(Lcom/vdocipher/aegis/core/k/b;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/k/b;->a(Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$y6WnsEfeDz0zh4Amhc3QTRCfCKE(Lcom/vdocipher/aegis/core/k/b;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/aegis/core/k/b;->c()V

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lcom/vdocipher/aegis/core/k/b;->j:Lcom/vdocipher/aegis/offline/OptionsDownloader$Callback;

    .line 6
    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "OpF"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/k/b;->a:Landroid/os/HandlerThread;

    .line 7
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 8
    new-instance v1, Landroid/os/Handler;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {v1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v1, p0, Lcom/vdocipher/aegis/core/k/b;->b:Landroid/os/Handler;

    return-void
.end method

.method private a(Lcom/vdocipher/aegis/core/f/g;)Ljava/lang/String;
    .registers 7

    .line 124
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->q()[Ljava/lang/String;

    move-result-object v0

    .line 125
    invoke-static {v0}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "DOptF"

    invoke-static {v2, v1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 128
    array-length v1, v0

    const/4 v2, 0x0

    :goto_f
    if-ge v2, v1, :cond_2b

    aget-object v3, v0, v2

    .line 129
    const-string v4, "dash"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_28

    .line 132
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->s()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_28

    .line 134
    invoke-static {}, Lcom/vdocipher/aegis/core/t/d;->d()Z

    move-result v3

    if-eqz v3, :cond_28

    return-object v4

    :cond_28
    add-int/lit8 v2, v2, 0x1

    goto :goto_f

    :cond_2b
    const/4 p1, 0x0

    return-object p1
.end method

.method private static a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 136
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    if-eqz p1, :cond_13

    .line 137
    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->i(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_13

    .line 138
    const-string v1, "jwt"

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_1a

    :cond_13
    if-eqz p1, :cond_30

    .line 140
    const-string v1, "otp"

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 144
    :goto_1a
    const-string p1, "playbackInfo"

    invoke-virtual {v0, p1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 147
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "UTF-8"

    invoke-virtual {p0, p1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0

    const/16 p1, 0xa

    invoke-static {p0, p1}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 148
    :cond_30
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p0
.end method

.method private a()V
    .registers 4

    .line 11
    new-instance v0, Lcom/vdocipher/aegis/core/f/g;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/b;->e:Ljava/lang/String;

    invoke-direct {v0, v1}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/k/b;->k:Lcom/vdocipher/aegis/core/f/g;

    .line 13
    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "bgThread"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    .line 14
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 15
    new-instance v1, Landroid/os/Handler;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 16
    new-instance v2, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0}, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda2;-><init>(Lcom/vdocipher/aegis/core/k/b;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 59
    invoke-virtual {v0}, Landroid/os/HandlerThread;->quitSafely()Z

    return-void
.end method

.method private synthetic a(Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 3

    .line 121
    monitor-enter p0

    .line 122
    :try_start_1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/b;->j:Lcom/vdocipher/aegis/offline/OptionsDownloader$Callback;

    if-eqz v0, :cond_8

    invoke-interface {v0, p1}, Lcom/vdocipher/aegis/offline/OptionsDownloader$Callback;->onOptionsNotReceived(Lcom/vdocipher/aegis/media/ErrorDescription;)V

    .line 123
    :cond_8
    monitor-exit p0

    return-void

    :catchall_a
    move-exception p1

    monitor-exit p0
    :try_end_c
    .catchall {:try_start_1 .. :try_end_c} :catchall_a

    throw p1
.end method

.method private a(Lcom/vdocipher/aegis/media/ErrorDescription;Ljava/lang/Throwable;)V
    .registers 4

    .line 120
    iget-object p2, p0, Lcom/vdocipher/aegis/core/k/b;->c:Landroid/os/Handler;

    new-instance v0, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0, p1}, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda1;-><init>(Lcom/vdocipher/aegis/core/k/b;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    invoke-virtual {p2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private synthetic a(Lcom/vdocipher/aegis/offline/DownloadOptions;)V
    .registers 3

    .line 117
    monitor-enter p0

    .line 118
    :try_start_1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/b;->j:Lcom/vdocipher/aegis/offline/OptionsDownloader$Callback;

    if-eqz v0, :cond_8

    invoke-interface {v0, p1}, Lcom/vdocipher/aegis/offline/OptionsDownloader$Callback;->onOptionsReceived(Lcom/vdocipher/aegis/offline/DownloadOptions;)V

    .line 119
    :cond_8
    monitor-exit p0

    return-void

    :catchall_a
    move-exception p1

    monitor-exit p0
    :try_end_c
    .catchall {:try_start_1 .. :try_end_c} :catchall_a

    throw p1
.end method

.method private synthetic a(Ljava/lang/String;)V
    .registers 7

    const/4 v0, -0x1

    const/4 v1, 0x0

    if-eqz p1, :cond_51

    .line 60
    :try_start_4
    const-string v2, "dash"

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_d

    goto :goto_51

    .line 67
    :cond_d
    iget-object p1, p0, Lcom/vdocipher/aegis/core/k/b;->k:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->k()Ljava/lang/String;

    move-result-object p1
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_13} :catch_4f

    .line 71
    :try_start_13
    iget-object v2, p0, Lcom/vdocipher/aegis/core/k/b;->d:Landroid/content/Context;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/k/b;->f:Ljava/lang/String;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lcom/vdocipher/aegis/core/k/b;->e:Ljava/lang/String;

    invoke-static {v2, v3, v4}, Lcom/vdocipher/aegis/core/t/b;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    if-eqz v2, :cond_33

    .line 73
    invoke-virtual {v2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1
    :try_end_27
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_27} :catch_28

    goto :goto_33

    :catch_28
    move-exception v2

    .line 76
    :try_start_29
    iget-object v3, p0, Lcom/vdocipher/aegis/core/k/b;->d:Landroid/content/Context;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/k/c;->b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object v3

    const/4 v4, 0x1

    invoke-virtual {v3, v2, v1, v4}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/Throwable;Ljava/lang/String;Z)V

    :cond_33
    :goto_33
    if-nez p1, :cond_44

    .line 81
    new-instance p1, Lcom/vdocipher/aegis/media/ErrorDescription;

    const/16 v2, 0xc23

    invoke-static {v2}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v3

    invoke-direct {p1, v2, v3, v0}, Lcom/vdocipher/aegis/media/ErrorDescription;-><init>(ILjava/lang/String;I)V

    invoke-direct {p0, p1, v1}, Lcom/vdocipher/aegis/core/k/b;->a(Lcom/vdocipher/aegis/media/ErrorDescription;Ljava/lang/Throwable;)V

    goto :goto_69

    .line 88
    :cond_44
    new-instance v0, Lcom/vdocipher/aegis/core/k/l;

    invoke-direct {v0}, Lcom/vdocipher/aegis/core/k/l;-><init>()V

    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/b;->d:Landroid/content/Context;

    invoke-virtual {v0, v1, p1, p0}, Lcom/vdocipher/aegis/core/k/l;->a(Landroid/content/Context;Ljava/lang/String;Lcom/vdocipher/aegis/core/k/l$a;)V

    goto :goto_69

    :catch_4f
    move-exception p1

    goto :goto_60

    .line 89
    :cond_51
    :goto_51
    new-instance p1, Lcom/vdocipher/aegis/media/ErrorDescription;

    const/16 v2, 0x4c6

    invoke-static {v2}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v3

    invoke-direct {p1, v2, v3, v0}, Lcom/vdocipher/aegis/media/ErrorDescription;-><init>(ILjava/lang/String;I)V

    invoke-direct {p0, p1, v1}, Lcom/vdocipher/aegis/core/k/b;->a(Lcom/vdocipher/aegis/media/ErrorDescription;Ljava/lang/Throwable;)V
    :try_end_5f
    .catch Ljava/lang/Exception; {:try_start_29 .. :try_end_5f} :catch_4f

    return-void

    .line 116
    :goto_60
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "DOptF"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :goto_69
    return-void
.end method

.method private synthetic b()V
    .registers 6

    .line 1
    :try_start_0
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/k/b;->a()V
    :try_end_3
    .catch Lcom/vdocipher/aegis/core/f/d; {:try_start_0 .. :try_end_3} :catch_8
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_3} :catch_6
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_3} :catch_4

    return-void

    :catch_4
    move-exception v0

    goto :goto_9

    :catch_6
    move-exception v0

    goto :goto_9

    :catch_8
    move-exception v0

    .line 3
    :goto_9
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "DOptF"

    invoke-static {v2, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    instance-of v1, v0, Lcom/vdocipher/aegis/core/f/d;

    if-nez v1, :cond_22

    instance-of v1, v0, Ljava/lang/IllegalArgumentException;

    if-nez v1, :cond_22

    instance-of v1, v0, Ljava/io/UnsupportedEncodingException;

    if-eqz v1, :cond_1f

    goto :goto_22

    :cond_1f
    const/16 v1, 0x140a

    goto :goto_24

    :cond_22
    :goto_22
    const/16 v1, 0xc22

    .line 10
    :goto_24
    new-instance v2, Lcom/vdocipher/aegis/media/ErrorDescription;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, -0x1

    invoke-direct {v2, v1, v3, v4}, Lcom/vdocipher/aegis/media/ErrorDescription;-><init>(ILjava/lang/String;I)V

    .line 11
    invoke-direct {p0, v2, v0}, Lcom/vdocipher/aegis/core/k/b;->a(Lcom/vdocipher/aegis/media/ErrorDescription;Ljava/lang/Throwable;)V

    return-void
.end method

.method private b(Lcom/vdocipher/aegis/offline/DownloadOptions;)V
    .registers 4

    .line 12
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/b;->c:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda4;

    invoke-direct {v1, p0, p1}, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda4;-><init>(Lcom/vdocipher/aegis/core/k/b;Lcom/vdocipher/aegis/offline/DownloadOptions;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private synthetic c()V
    .registers 4

    .line 1
    :try_start_0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/b;->k:Lcom/vdocipher/aegis/core/f/g;

    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/k/b;->a(Lcom/vdocipher/aegis/core/f/g;)Ljava/lang/String;

    move-result-object v0

    .line 2
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v2, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda3;

    invoke-direct {v2, p0, v0}, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda3;-><init>(Lcom/vdocipher/aegis/core/k/b;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_17} :catch_18

    return-void

    :catch_18
    move-exception v0

    .line 38
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "DOptF"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public declared-synchronized a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/offline/OptionsDownloader$Callback;)V
    .registers 10

    monitor-enter p0

    .line 1
    :try_start_1
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/k/b;->c:Landroid/os/Handler;

    .line 2
    iput-object p2, p0, Lcom/vdocipher/aegis/core/k/b;->f:Ljava/lang/String;

    .line 3
    iput-object p3, p0, Lcom/vdocipher/aegis/core/k/b;->g:Ljava/lang/String;

    .line 4
    iput-object p4, p0, Lcom/vdocipher/aegis/core/k/b;->e:Ljava/lang/String;

    .line 5
    iput-object p1, p0, Lcom/vdocipher/aegis/core/k/b;->d:Landroid/content/Context;

    .line 6
    iput-object p5, p0, Lcom/vdocipher/aegis/core/k/b;->h:Ljava/lang/String;

    .line 7
    iput-object p6, p0, Lcom/vdocipher/aegis/core/k/b;->i:Ljava/lang/String;

    .line 8
    iput-object p7, p0, Lcom/vdocipher/aegis/core/k/b;->j:Lcom/vdocipher/aegis/offline/OptionsDownloader$Callback;

    .line 10
    iget-object p1, p0, Lcom/vdocipher/aegis/core/k/b;->b:Landroid/os/Handler;

    new-instance p2, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda0;

    invoke-direct {p2, p0}, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/core/k/b;)V

    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_24
    .catchall {:try_start_1 .. :try_end_24} :catchall_26

    monitor-exit p0

    return-void

    :catchall_26
    move-exception p1

    :try_start_27
    monitor-exit p0
    :try_end_28
    .catchall {:try_start_27 .. :try_end_28} :catchall_26

    throw p1
.end method

.method public a(Ljava/io/IOException;)V
    .registers 6

    .line 201
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "DOptF"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 203
    instance-of v0, p1, Ljava/io/UnsupportedEncodingException;

    if-eqz v0, :cond_10

    const/16 v0, 0xc22

    goto :goto_12

    :cond_10
    const/16 v0, 0x140a

    .line 208
    :goto_12
    new-instance v1, Lcom/vdocipher/aegis/media/ErrorDescription;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v2

    const/4 v3, -0x1

    invoke-direct {v1, v0, v2, v3}, Lcom/vdocipher/aegis/media/ErrorDescription;-><init>(ILjava/lang/String;I)V

    .line 209
    invoke-direct {p0, v1, p1}, Lcom/vdocipher/aegis/core/k/b;->a(Lcom/vdocipher/aegis/media/ErrorDescription;Ljava/lang/Throwable;)V

    return-void
.end method

.method public a(Ljava/lang/String;Lcom/vdocipher/aegis/core/k/j;)V
    .registers 22

    move-object/from16 v1, p0

    move-object/from16 v0, p2

    const/4 v2, -0x1

    .line 149
    :try_start_5
    iget-object v3, v1, Lcom/vdocipher/aegis/core/k/b;->k:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v3}, Lcom/vdocipher/aegis/core/f/g;->s()Ljava/lang/String;

    move-result-object v3

    iget-object v4, v1, Lcom/vdocipher/aegis/core/k/b;->f:Ljava/lang/String;

    iget-object v5, v1, Lcom/vdocipher/aegis/core/k/b;->g:Ljava/lang/String;

    .line 150
    invoke-static {v4, v5}, Lcom/vdocipher/aegis/core/k/b;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 151
    invoke-static {v3, v4}, Lcom/vdocipher/aegis/core/t/d;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 154
    iget-object v3, v1, Lcom/vdocipher/aegis/core/k/b;->k:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v3}, Lcom/vdocipher/aegis/core/f/g;->h()Ljava/lang/String;

    move-result-object v13

    .line 159
    iget-object v3, v1, Lcom/vdocipher/aegis/core/k/b;->k:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v3}, Lcom/vdocipher/aegis/core/f/g;->o()[Ljava/lang/String;

    move-result-object v3

    .line 160
    array-length v4, v3

    const/4 v5, 0x0

    if-lez v4, :cond_2c

    const/4 v4, 0x0

    aget-object v3, v3, v4

    move-object v11, v3

    goto :goto_2d

    :cond_2c
    move-object v11, v5

    .line 162
    :goto_2d
    sget-object v3, Lcom/vdocipher/aegis/core/k/j;->b:Lcom/vdocipher/aegis/core/k/j;

    if-ne v0, v3, :cond_40

    .line 164
    new-instance v0, Lcom/vdocipher/aegis/media/ErrorDescription;

    const/16 v3, 0xc24

    invoke-static {v3}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v3, v4, v2}, Lcom/vdocipher/aegis/media/ErrorDescription;-><init>(ILjava/lang/String;I)V

    invoke-direct {v1, v0, v5}, Lcom/vdocipher/aegis/core/k/b;->a(Lcom/vdocipher/aegis/media/ErrorDescription;Ljava/lang/Throwable;)V

    return-void

    .line 169
    :cond_40
    iget-object v3, v1, Lcom/vdocipher/aegis/core/k/b;->f:Ljava/lang/String;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 170
    new-instance v4, Lcom/vdocipher/aegis/media/MediaInfo;

    iget-object v3, v1, Lcom/vdocipher/aegis/core/k/b;->k:Lcom/vdocipher/aegis/core/f/g;

    .line 171
    invoke-virtual {v3}, Lcom/vdocipher/aegis/core/f/g;->r()Ljava/lang/String;

    move-result-object v7

    iget-object v3, v1, Lcom/vdocipher/aegis/core/k/b;->k:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v3}, Lcom/vdocipher/aegis/core/f/g;->c()Ljava/lang/String;

    move-result-object v8

    iget-object v3, v1, Lcom/vdocipher/aegis/core/k/b;->k:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v3}, Lcom/vdocipher/aegis/core/f/g;->e()J

    move-result-wide v9

    const/4 v5, 0x3

    invoke-direct/range {v4 .. v10}, Lcom/vdocipher/aegis/media/MediaInfo;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    .line 174
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    const-string/jumbo v5, "token"

    iget-object v7, v1, Lcom/vdocipher/aegis/core/k/b;->g:Ljava/lang/String;

    .line 175
    invoke-virtual {v3, v5, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v3

    const-string/jumbo v5, "videoId"

    .line 176
    invoke-virtual {v3, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v3

    const-string v5, "playbackInfo"

    iget-object v7, v1, Lcom/vdocipher/aegis/core/k/b;->f:Ljava/lang/String;

    .line 177
    invoke-virtual {v3, v5, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v3

    .line 178
    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v14

    .line 181
    new-instance v15, Ljava/util/ArrayList;

    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    .line 182
    iget-object v3, v1, Lcom/vdocipher/aegis/core/k/b;->k:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v3, v15}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/util/ArrayList;)Ljava/util/ArrayList;

    .line 185
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 186
    iget-object v5, v1, Lcom/vdocipher/aegis/core/k/b;->k:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v5, v3}, Lcom/vdocipher/aegis/core/f/g;->b(Ljava/util/ArrayList;)Ljava/util/ArrayList;

    move-result-object v16

    .line 189
    new-instance v5, Lcom/vdocipher/aegis/core/k/a;

    iget-object v8, v0, Lcom/vdocipher/aegis/core/k/j;->a:[Lcom/vdocipher/aegis/media/Track;

    iget-object v9, v1, Lcom/vdocipher/aegis/core/k/b;->e:Ljava/lang/String;

    iget-object v0, v1, Lcom/vdocipher/aegis/core/k/b;->h:Ljava/lang/String;

    iget-object v3, v1, Lcom/vdocipher/aegis/core/k/b;->i:Ljava/lang/String;

    move-object/from16 v10, p1

    move-object/from16 v17, v0

    move-object/from16 v18, v3

    move-object v7, v4

    invoke-direct/range {v5 .. v18}, Lcom/vdocipher/aegis/core/k/a;-><init>(Ljava/lang/String;Lcom/vdocipher/aegis/media/MediaInfo;[Lcom/vdocipher/aegis/media/Track;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)V

    .line 190
    invoke-direct {v1, v5}, Lcom/vdocipher/aegis/core/k/b;->b(Lcom/vdocipher/aegis/offline/DownloadOptions;)V
    :try_end_ab
    .catch Lorg/json/JSONException; {:try_start_5 .. :try_end_ab} :catch_b0
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_ab} :catch_ae
    .catch Ljava/lang/IllegalArgumentException; {:try_start_5 .. :try_end_ab} :catch_ac

    return-void

    :catch_ac
    move-exception v0

    goto :goto_b1

    :catch_ae
    move-exception v0

    goto :goto_b1

    :catch_b0
    move-exception v0

    .line 192
    :goto_b1
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "DOptF"

    invoke-static {v4, v3}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 194
    instance-of v3, v0, Lorg/json/JSONException;

    if-nez v3, :cond_ca

    instance-of v3, v0, Ljava/lang/IllegalArgumentException;

    if-nez v3, :cond_ca

    instance-of v3, v0, Ljava/io/UnsupportedEncodingException;

    if-eqz v3, :cond_c7

    goto :goto_ca

    :cond_c7
    const/16 v3, 0x140a

    goto :goto_cc

    :cond_ca
    :goto_ca
    const/16 v3, 0xc22

    .line 199
    :goto_cc
    new-instance v4, Lcom/vdocipher/aegis/media/ErrorDescription;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/f/c;->a(I)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v3, v5, v2}, Lcom/vdocipher/aegis/media/ErrorDescription;-><init>(ILjava/lang/String;I)V

    .line 200
    invoke-direct {v1, v4, v0}, Lcom/vdocipher/aegis/core/k/b;->a(Lcom/vdocipher/aegis/media/ErrorDescription;Ljava/lang/Throwable;)V

    return-void
.end method

.method public declared-synchronized d()V
    .registers 2

    monitor-enter p0

    const/4 v0, 0x0

    .line 1
    :try_start_2
    iput-object v0, p0, Lcom/vdocipher/aegis/core/k/b;->j:Lcom/vdocipher/aegis/offline/OptionsDownloader$Callback;

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/b;->a:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->quit()Z
    :try_end_9
    .catchall {:try_start_2 .. :try_end_9} :catchall_b

    monitor-exit p0

    return-void

    :catchall_b
    move-exception v0

    :try_start_c
    monitor-exit p0
    :try_end_d
    .catchall {:try_start_c .. :try_end_d} :catchall_b

    throw v0
.end method
