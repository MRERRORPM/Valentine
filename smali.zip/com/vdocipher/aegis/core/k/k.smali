# classes14.dex

.class public final Lcom/vdocipher/aegis/core/k/k;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final d:Ljava/lang/String;

.field public final e:Ljava/lang/String;

.field public final f:Ljava/util/ArrayList;

.field public final g:Ljava/lang/String;

.field public final h:Ljava/lang/String;

.field public final i:Ljava/lang/String;

.field public final j:Ljava/lang/String;

.field public final k:Ljava/lang/String;

.field public final l:Ljava/lang/String;

.field public final m:Lcom/vdocipher/aegis/media/MediaInfo;

.field public final n:[I

.field public final o:Ljava/lang/String;

.field public p:Ljava/lang/String;

.field public q:Ljava/lang/String;

.field public r:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/media/MediaInfo;[ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    .registers 19

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/k/k;->a:Ljava/lang/String;

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/k/k;->b:Ljava/lang/String;

    .line 4
    iput-object p3, p0, Lcom/vdocipher/aegis/core/k/k;->c:Ljava/lang/String;

    .line 5
    iput-object p4, p0, Lcom/vdocipher/aegis/core/k/k;->d:Ljava/lang/String;

    .line 6
    iput-object p5, p0, Lcom/vdocipher/aegis/core/k/k;->e:Ljava/lang/String;

    .line 7
    iput-object p6, p0, Lcom/vdocipher/aegis/core/k/k;->f:Ljava/util/ArrayList;

    .line 8
    iput-object p7, p0, Lcom/vdocipher/aegis/core/k/k;->g:Ljava/lang/String;

    .line 9
    iput-object p8, p0, Lcom/vdocipher/aegis/core/k/k;->h:Ljava/lang/String;

    .line 10
    iput-object p9, p0, Lcom/vdocipher/aegis/core/k/k;->i:Ljava/lang/String;

    .line 11
    iput-object p10, p0, Lcom/vdocipher/aegis/core/k/k;->j:Ljava/lang/String;

    .line 12
    iput-object p11, p0, Lcom/vdocipher/aegis/core/k/k;->k:Ljava/lang/String;

    .line 13
    iput-object p12, p0, Lcom/vdocipher/aegis/core/k/k;->l:Ljava/lang/String;

    .line 14
    iput-object p13, p0, Lcom/vdocipher/aegis/core/k/k;->m:Lcom/vdocipher/aegis/media/MediaInfo;

    .line 15
    iput-object p14, p0, Lcom/vdocipher/aegis/core/k/k;->n:[I

    .line 16
    iput-object p15, p0, Lcom/vdocipher/aegis/core/k/k;->o:Ljava/lang/String;

    move-object/from16 p1, p16

    .line 17
    iput-object p1, p0, Lcom/vdocipher/aegis/core/k/k;->p:Ljava/lang/String;

    move-object/from16 p1, p17

    .line 18
    iput-object p1, p0, Lcom/vdocipher/aegis/core/k/k;->q:Ljava/lang/String;

    move/from16 p1, p18

    .line 19
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/k/k;->r:Z

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 5

    if-ne p0, p1, :cond_4

    const/4 p1, 0x1

    return p1

    :cond_4
    const/4 v0, 0x0

    if-eqz p1, :cond_d4

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const-class v2, Lcom/vdocipher/aegis/core/k/k;

    if-eq v2, v1, :cond_11

    goto/16 :goto_d4

    .line 3
    :cond_11
    check-cast p1, Lcom/vdocipher/aegis/core/k/k;

    .line 5
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->a:Ljava/lang/String;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e

    return v0

    .line 6
    :cond_1e
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->b:Ljava/lang/String;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->b:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_29

    return v0

    .line 7
    :cond_29
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->c:Ljava/lang/String;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->c:Ljava/lang/String;

    invoke-static {v1, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_34

    return v0

    .line 8
    :cond_34
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->d:Ljava/lang/String;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->d:Ljava/lang/String;

    invoke-static {v1, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3f

    return v0

    .line 10
    :cond_3f
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->e:Ljava/lang/String;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->e:Ljava/lang/String;

    invoke-static {v1, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4a

    return v0

    .line 12
    :cond_4a
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->o:Ljava/lang/String;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->o:Ljava/lang/String;

    invoke-static {v1, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_55

    return v0

    .line 14
    :cond_55
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->g:Ljava/lang/String;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->g:Ljava/lang/String;

    invoke-static {v1, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_60

    return v0

    .line 16
    :cond_60
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->h:Ljava/lang/String;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->h:Ljava/lang/String;

    invoke-static {v1, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6b

    return v0

    .line 18
    :cond_6b
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->i:Ljava/lang/String;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->i:Ljava/lang/String;

    invoke-static {v1, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_76

    return v0

    .line 20
    :cond_76
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->j:Ljava/lang/String;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->j:Ljava/lang/String;

    invoke-static {v1, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_81

    return v0

    .line 22
    :cond_81
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->k:Ljava/lang/String;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->k:Ljava/lang/String;

    invoke-static {v1, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8c

    return v0

    .line 24
    :cond_8c
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->l:Ljava/lang/String;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->l:Ljava/lang/String;

    invoke-static {v1, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_97

    return v0

    .line 26
    :cond_97
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->m:Lcom/vdocipher/aegis/media/MediaInfo;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->m:Lcom/vdocipher/aegis/media/MediaInfo;

    invoke-static {v1, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a2

    return v0

    .line 28
    :cond_a2
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->p:Ljava/lang/String;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->p:Ljava/lang/String;

    invoke-static {v1, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_ad

    return v0

    .line 30
    :cond_ad
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->q:Ljava/lang/String;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/k;->q:Ljava/lang/String;

    invoke-static {v1, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b8

    return v0

    .line 32
    :cond_b8
    iget-boolean v1, p0, Lcom/vdocipher/aegis/core/k/k;->r:Z

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    iget-boolean v2, p1, Lcom/vdocipher/aegis/core/k/k;->r:Z

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_cb

    return v0

    .line 34
    :cond_cb
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/k;->n:[I

    iget-object p1, p1, Lcom/vdocipher/aegis/core/k/k;->n:[I

    invoke-static {v0, p1}, Ljava/util/Arrays;->equals([I[I)Z

    move-result p1

    return p1

    :cond_d4
    :goto_d4
    return v0
.end method

.method public hashCode()I
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/k;->a:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    .line 2
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->b:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 3
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->c:Ljava/lang/String;

    const/4 v2, 0x0

    if-eqz v1, :cond_1b

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    goto :goto_1c

    :cond_1b
    move v1, v2

    :goto_1c
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 4
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->d:Ljava/lang/String;

    if-eqz v1, :cond_28

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    goto :goto_29

    :cond_28
    move v1, v2

    :goto_29
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 5
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->e:Ljava/lang/String;

    if-eqz v1, :cond_35

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    goto :goto_36

    :cond_35
    move v1, v2

    :goto_36
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 6
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->g:Ljava/lang/String;

    if-eqz v1, :cond_42

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    goto :goto_43

    :cond_42
    move v1, v2

    :goto_43
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 7
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->h:Ljava/lang/String;

    if-eqz v1, :cond_4f

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    goto :goto_50

    :cond_4f
    move v1, v2

    :goto_50
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 8
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->i:Ljava/lang/String;

    if-eqz v1, :cond_5c

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    goto :goto_5d

    :cond_5c
    move v1, v2

    :goto_5d
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 9
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->j:Ljava/lang/String;

    if-eqz v1, :cond_69

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    goto :goto_6a

    :cond_69
    move v1, v2

    :goto_6a
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 10
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->k:Ljava/lang/String;

    if-eqz v1, :cond_76

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    goto :goto_77

    :cond_76
    move v1, v2

    :goto_77
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 11
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->l:Ljava/lang/String;

    if-eqz v1, :cond_83

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    goto :goto_84

    :cond_83
    move v1, v2

    :goto_84
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 12
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->m:Lcom/vdocipher/aegis/media/MediaInfo;

    if-eqz v1, :cond_90

    invoke-virtual {v1}, Lcom/vdocipher/aegis/media/MediaInfo;->hashCode()I

    move-result v1

    goto :goto_91

    :cond_90
    move v1, v2

    :goto_91
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 13
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->o:Ljava/lang/String;

    if-eqz v1, :cond_9d

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    goto :goto_9e

    :cond_9d
    move v1, v2

    :goto_9e
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 14
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->p:Ljava/lang/String;

    if-eqz v1, :cond_aa

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    goto :goto_ab

    :cond_aa
    move v1, v2

    :goto_ab
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 15
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->q:Ljava/lang/String;

    if-eqz v1, :cond_b6

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    :cond_b6
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    .line 16
    iget-boolean v1, p0, Lcom/vdocipher/aegis/core/k/k;->r:Z

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    .line 17
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/k;->n:[I

    invoke-static {v1}, Ljava/util/Arrays;->hashCode([I)I

    move-result v1

    add-int/2addr v0, v1

    return v0
.end method
