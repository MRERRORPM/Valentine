# classes14.dex

.class public final Lcom/vdocipher/aegis/core/k/j;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final b:Lcom/vdocipher/aegis/core/k/j;


# instance fields
.field public final a:[Lcom/vdocipher/aegis/media/Track;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lcom/vdocipher/aegis/core/k/j;

    const/4 v1, 0x0

    new-array v1, v1, [Lcom/vdocipher/aegis/media/Track;

    invoke-direct {v0, v1}, Lcom/vdocipher/aegis/core/k/j;-><init>([Lcom/vdocipher/aegis/media/Track;)V

    sput-object v0, Lcom/vdocipher/aegis/core/k/j;->b:Lcom/vdocipher/aegis/core/k/j;

    return-void
.end method

.method constructor <init>([Lcom/vdocipher/aegis/media/Track;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/k/j;->a:[Lcom/vdocipher/aegis/media/Track;

    return-void
.end method
