# classes14.dex

.class public Lcom/vdocipher/aegis/core/k/c;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/core/k/c$a;
    }
.end annotation


# static fields
.field private static b:Lcom/vdocipher/aegis/core/k/c;


# instance fields
.field private final a:Lcom/vdocipher/aegis/core/l/a;


# direct methods
.method public static synthetic $r8$lambda$uhXWltjGNOXwHZq0KTnyLMltbEM(Lcom/vdocipher/aegis/core/k/c;Ljava/lang/Throwable;Ljava/lang/String;Z)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/k/c;->b(Ljava/lang/Throwable;Ljava/lang/String;Z)V

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Lcom/vdocipher/aegis/core/l/a;

    invoke-direct {v0, p1}, Lcom/vdocipher/aegis/core/l/a;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    return-void
.end method

.method private declared-synchronized a(Lcom/vdocipher/aegis/core/k/c$a;Ljava/lang/Class;)Ljava/lang/Object;
    .registers 12

    monitor-enter p0

    .line 197
    :try_start_1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    .line 200
    iget-object v0, p1, Lcom/vdocipher/aegis/core/k/c$a;->b:Ljava/lang/String;

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v3

    .line 204
    iget-object v2, p1, Lcom/vdocipher/aegis/core/k/c$a;->a:Ljava/lang/String;

    iget-object v4, p1, Lcom/vdocipher/aegis/core/k/c$a;->c:Ljava/lang/String;

    iget-object v5, p1, Lcom/vdocipher/aegis/core/k/c$a;->d:[Ljava/lang/String;

    iget-object v6, p1, Lcom/vdocipher/aegis/core/k/c$a;->e:Ljava/lang/String;

    iget-object v7, p1, Lcom/vdocipher/aegis/core/k/c$a;->f:Ljava/lang/String;

    iget-object v8, p1, Lcom/vdocipher/aegis/core/k/c$a;->g:Ljava/lang/String;

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1
    :try_end_1d
    .catchall {:try_start_1 .. :try_end_1d} :catchall_6a

    .line 215
    :try_start_1d
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_5d

    .line 217
    const-class v0, Ljava/lang/String;

    if-ne p2, v0, :cond_33

    .line 218
    iget-object p1, p1, Lcom/vdocipher/aegis/core/k/c$a;->b:Ljava/lang/String;

    invoke-interface {v1, p1}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result p1

    invoke-interface {v1, p1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    goto :goto_58

    .line 219
    :cond_33
    const-class v0, Ljava/lang/Integer;

    if-ne p2, v0, :cond_46

    .line 220
    iget-object p1, p1, Lcom/vdocipher/aegis/core/k/c$a;->b:Ljava/lang/String;

    invoke-interface {v1, p1}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result p1

    invoke-interface {v1, p1}, Landroid/database/Cursor;->getInt(I)I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    goto :goto_58

    .line 221
    :cond_46
    const-class v0, Ljava/lang/Long;

    if-ne p2, v0, :cond_58

    .line 222
    iget-object p1, p1, Lcom/vdocipher/aegis/core/k/c$a;->b:Ljava/lang/String;

    invoke-interface {v1, p1}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result p1

    invoke-interface {v1, p1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide p1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2
    :try_end_58
    .catchall {:try_start_1d .. :try_end_58} :catchall_62

    .line 229
    :cond_58
    :goto_58
    :try_start_58
    invoke-interface {v1}, Landroid/database/Cursor;->close()V
    :try_end_5b
    .catchall {:try_start_58 .. :try_end_5b} :catchall_6a

    monitor-exit p0

    return-object v2

    :cond_5d
    :try_start_5d
    invoke-interface {v1}, Landroid/database/Cursor;->close()V
    :try_end_60
    .catchall {:try_start_5d .. :try_end_60} :catchall_6a

    monitor-exit p0

    return-object v2

    :catchall_62
    move-exception v0

    move-object p1, v0

    if-eqz v1, :cond_69

    :try_start_66
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 230
    :cond_69
    throw p1

    :catchall_6a
    move-exception v0

    move-object p1, v0

    monitor-exit p0
    :try_end_6d
    .catchall {:try_start_66 .. :try_end_6d} :catchall_6a

    throw p1
.end method

.method private a(Lcom/vdocipher/aegis/core/k/c$a;)Ljava/lang/String;
    .registers 3

    .line 194
    const-class v0, Ljava/lang/String;

    invoke-direct {p0, p1, v0}, Lcom/vdocipher/aegis/core/k/c;->a(Lcom/vdocipher/aegis/core/k/c$a;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    if-eqz p1, :cond_b

    .line 196
    check-cast p1, Ljava/lang/String;

    return-object p1

    :cond_b
    const/4 p1, 0x0

    return-object p1
.end method

.method private declared-synchronized a([Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase;)Ljava/util/List;
    .registers 19

    monitor-enter p0

    .line 134
    :try_start_1
    const-string v0, "mediaId"

    const-string/jumbo v1, "timeAdded"

    const-string v2, "dlspec"

    filled-new-array {v0, v1, v2}, [Ljava/lang/String;

    move-result-object v5

    const/4 v0, 0x0

    .line 142
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object v7

    .line 144
    const-string/jumbo v4, "vdo_queue"

    const-string v6, "cancelled = ? AND deleted = ?"

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v8, 0x0

    move-object/from16 v3, p2

    invoke-virtual/range {v3 .. v10}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1
    :try_end_27
    .catchall {:try_start_1 .. :try_end_27} :catchall_c0

    .line 153
    :try_start_27
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 154
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v3

    if-nez v3, :cond_37

    .line 155
    invoke-interface {v1}, Landroid/database/Cursor;->close()V
    :try_end_35
    .catchall {:try_start_27 .. :try_end_35} :catchall_b9

    monitor-exit p0

    return-object v2

    :cond_37
    if-eqz p1, :cond_3c

    move-object/from16 v3, p1

    goto :goto_3f

    .line 159
    :cond_3c
    :try_start_3c
    new-array v0, v0, [Ljava/lang/String;
    :try_end_3e
    .catchall {:try_start_3c .. :try_end_3e} :catchall_b9

    move-object v3, v0

    .line 163
    :cond_3f
    :goto_3f
    :try_start_3f
    const-string v0, "mediaId"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v6

    .line 164
    array-length v0, v3

    if-eqz v0, :cond_52

    invoke-static {v3, v6}, Lcom/vdocipher/aegis/core/k/c;->a([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_ae

    .line 166
    :cond_52
    const-string v0, "dlspec"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 167
    const-string/jumbo v4, "timeAdded"

    invoke-interface {v1, v4}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v4

    invoke-interface {v1, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v4

    .line 168
    invoke-static {v0}, Lcom/vdocipher/aegis/core/k/d;->a(Ljava/lang/String;)Lcom/vdocipher/aegis/core/k/d;

    move-result-object v0

    .line 169
    const-string v5, "dss.loc"

    invoke-virtual {v0, v5}, Lcom/vdocipher/aegis/core/k/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 170
    const-string v5, "dss.meta"

    invoke-virtual {v0, v5}, Lcom/vdocipher/aegis/core/k/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 172
    new-instance v5, Lcom/vdocipher/aegis/core/f/g;

    invoke-direct {v5, v0}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    .line 173
    invoke-virtual {v5}, Lcom/vdocipher/aegis/core/f/g;->r()Ljava/lang/String;

    move-result-object v7

    .line 174
    invoke-virtual {v5}, Lcom/vdocipher/aegis/core/f/g;->c()Ljava/lang/String;

    move-result-object v8

    .line 175
    invoke-virtual {v5}, Lcom/vdocipher/aegis/core/f/g;->e()J

    move-result-wide v9

    .line 176
    invoke-static {v4}, Lcom/vdocipher/aegis/core/k/c;->s(Ljava/lang/String;)J

    move-result-wide v12

    .line 178
    new-instance v4, Lcom/vdocipher/aegis/media/MediaInfo;

    const/4 v5, 0x3

    invoke-direct/range {v4 .. v10}, Lcom/vdocipher/aegis/media/MediaInfo;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    move-wide v9, v12

    const-wide/16 v13, 0x0

    const/4 v15, 0x0

    move-object v8, v11

    const-wide/16 v11, 0x0

    move-object v7, v4

    .line 179
    invoke-static/range {v7 .. v15}, Lcom/vdocipher/aegis/offline/DownloadStatus;->createForPending(Lcom/vdocipher/aegis/media/MediaInfo;Ljava/lang/String;JJJZ)Lcom/vdocipher/aegis/offline/DownloadStatus;

    move-result-object v0

    .line 182
    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_a1
    .catch Lorg/json/JSONException; {:try_start_3f .. :try_end_a1} :catch_a4
    .catch Lcom/vdocipher/aegis/core/f/d; {:try_start_3f .. :try_end_a1} :catch_a2
    .catchall {:try_start_3f .. :try_end_a1} :catchall_b9

    goto :goto_ae

    :catch_a2
    move-exception v0

    goto :goto_a5

    :catch_a4
    move-exception v0

    .line 185
    :goto_a5
    :try_start_a5
    const-string v4, "DbAdapter"

    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 188
    :cond_ae
    :goto_ae
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v0
    :try_end_b2
    .catchall {:try_start_a5 .. :try_end_b2} :catchall_b9

    if-nez v0, :cond_3f

    .line 192
    :try_start_b4
    invoke-interface {v1}, Landroid/database/Cursor;->close()V
    :try_end_b7
    .catchall {:try_start_b4 .. :try_end_b7} :catchall_c0

    monitor-exit p0

    return-object v2

    :catchall_b9
    move-exception v0

    if-eqz v1, :cond_bf

    :try_start_bc
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 193
    :cond_bf
    throw v0

    :catchall_c0
    move-exception v0

    monitor-exit p0
    :try_end_c2
    .catchall {:try_start_bc .. :try_end_c2} :catchall_c0

    throw v0
.end method

.method private declared-synchronized a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V
    .registers 5

    monitor-enter p0

    .line 293
    :try_start_1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    .line 296
    invoke-virtual {v0, p1, p2, p3}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    :try_end_a
    .catchall {:try_start_1 .. :try_end_a} :catchall_c

    monitor-exit p0

    return-void

    :catchall_c
    move-exception p1

    :try_start_d
    monitor-exit p0
    :try_end_e
    .catchall {:try_start_d .. :try_end_e} :catchall_c

    throw p1
.end method

.method private declared-synchronized a(Landroid/content/ContentValues;Ljava/lang/String;Ljava/lang/String;)Z
    .registers 6

    monitor-enter p0

    .line 285
    :try_start_1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    .line 290
    filled-new-array {p3}, [Ljava/lang/String;

    move-result-object p3

    .line 292
    const-string v1, "mediaId = ?"

    invoke-virtual {v0, p2, p1, v1, p3}, Landroid/database/sqlite/SQLiteDatabase;->update(Ljava/lang/String;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    move-result p1
    :try_end_11
    .catchall {:try_start_1 .. :try_end_11} :catchall_18

    const/4 p2, 0x1

    monitor-exit p0

    if-ne p1, p2, :cond_16

    return p2

    :cond_16
    const/4 p1, 0x0

    return p1

    :catchall_18
    move-exception p1

    :try_start_19
    monitor-exit p0
    :try_end_1a
    .catchall {:try_start_19 .. :try_end_1a} :catchall_18

    throw p1
.end method

.method private declared-synchronized a(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)Z
    .registers 7

    const-string v0, ""

    monitor-enter p0

    .line 276
    :try_start_3
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    .line 279
    invoke-virtual {v1, p1, p2, p3}, Landroid/database/sqlite/SQLiteDatabase;->insert(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    move-result-wide p1

    const-wide/16 v1, -0x1

    cmp-long p3, p1, v1

    if-nez p3, :cond_1d

    .line 281
    const-string p1, "DbAdapter"

    const-string p2, "not created"

    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1a
    .catchall {:try_start_3 .. :try_end_1a} :catchall_31

    monitor-exit p0

    const/4 p1, 0x0

    return p1

    .line 284
    :cond_1d
    :try_start_1d
    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "DbAdapter"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2e
    .catchall {:try_start_1d .. :try_end_2e} :catchall_31

    monitor-exit p0

    const/4 p1, 0x1

    return p1

    :catchall_31
    move-exception p1

    :try_start_32
    monitor-exit p0
    :try_end_33
    .catchall {:try_start_32 .. :try_end_33} :catchall_31

    throw p1
.end method

.method private static a([II)Z
    .registers 6

    .line 297
    array-length v0, p0

    const/4 v1, 0x0

    move v2, v1

    :goto_3
    if-ge v2, v0, :cond_e

    aget v3, p0, v2

    if-ne v3, p1, :cond_b

    const/4 p0, 0x1

    return p0

    :cond_b
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_e
    return v1
.end method

.method private static a([Ljava/lang/String;Ljava/lang/String;)Z
    .registers 6

    .line 298
    array-length v0, p0

    const/4 v1, 0x0

    move v2, v1

    :goto_3
    if-ge v2, v0, :cond_12

    aget-object v3, p0, v2

    .line 299
    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_f

    const/4 p0, 0x1

    return p0

    :cond_f
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_12
    return v1
.end method

.method private static a([Ljava/lang/String;[Ljava/lang/String;)[Ljava/lang/String;
    .registers 6

    .line 300
    array-length v0, p0

    .line 301
    array-length v1, p1

    add-int v2, v0, v1

    .line 302
    new-array v2, v2, [Ljava/lang/String;

    const/4 v3, 0x0

    .line 303
    invoke-static {p0, v3, v2, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 304
    invoke-static {p1, v3, v2, v0, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v2
.end method

.method public static declared-synchronized b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;
    .registers 3

    const-class v0, Lcom/vdocipher/aegis/core/k/c;

    monitor-enter v0

    .line 1
    :try_start_3
    sget-object v1, Lcom/vdocipher/aegis/core/k/c;->b:Lcom/vdocipher/aegis/core/k/c;

    if-nez v1, :cond_12

    .line 2
    new-instance v1, Lcom/vdocipher/aegis/core/k/c;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    invoke-direct {v1, p0}, Lcom/vdocipher/aegis/core/k/c;-><init>(Landroid/content/Context;)V

    sput-object v1, Lcom/vdocipher/aegis/core/k/c;->b:Lcom/vdocipher/aegis/core/k/c;

    .line 4
    :cond_12
    sget-object p0, Lcom/vdocipher/aegis/core/k/c;->b:Lcom/vdocipher/aegis/core/k/c;
    :try_end_14
    .catchall {:try_start_3 .. :try_end_14} :catchall_16

    monitor-exit v0

    return-object p0

    :catchall_16
    move-exception p0

    :try_start_17
    monitor-exit v0
    :try_end_18
    .catchall {:try_start_17 .. :try_end_18} :catchall_16

    throw p0
.end method

.method private synthetic b(Ljava/lang/Throwable;Ljava/lang/String;Z)V
    .registers 6

    .line 14
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    .line 15
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 16
    const-string/jumbo v1, "stacktrace"

    invoke-virtual {v0, v1, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 17
    const-string p1, "crash_data"

    invoke-virtual {v0, p1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 18
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const-string p2, "is_handled"

    invoke-virtual {v0, p2, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 19
    const-string p1, "sdk_version"

    const-string p2, "1.29.3"

    invoke-virtual {v0, p1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 20
    const-string p1, "UTC"

    invoke-static {p1}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object p1

    .line 21
    new-instance p2, Ljava/text/SimpleDateFormat;

    sget-object p3, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string/jumbo v1, "yyyy-MM-dd\'T\'HH:mm:ss\'Z\'"

    invoke-direct {p2, v1, p3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 22
    invoke-virtual {p2, p1}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    .line 23
    new-instance p1, Ljava/util/Date;

    invoke-direct {p1}, Ljava/util/Date;-><init>()V

    invoke-virtual {p2, p1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p1

    .line 24
    const-string/jumbo p2, "timestamp"

    invoke-virtual {v0, p2, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 27
    :try_start_46
    const-string p1, "crash_log"

    const/4 p2, 0x0

    invoke-direct {p0, p1, p2, v0}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)Z
    :try_end_4c
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_46 .. :try_end_4c} :catch_4d

    return-void

    :catch_4d
    move-exception p1

    .line 29
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DbAdapter"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private declared-synchronized b(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)Z
    .registers 7

    const-string v0, ""

    monitor-enter p0

    .line 39
    :try_start_3
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    const/4 v2, 0x5

    .line 42
    invoke-virtual {v1, p1, p2, p3, v2}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    move-result-wide p1

    const-wide/16 v1, -0x1

    cmp-long p3, p1, v1

    if-nez p3, :cond_1e

    .line 44
    const-string p1, "DbAdapter"

    const-string p2, "not created"

    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1b
    .catchall {:try_start_3 .. :try_end_1b} :catchall_32

    monitor-exit p0

    const/4 p1, 0x0

    return p1

    .line 47
    :cond_1e
    :try_start_1e
    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "DbAdapter"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2f
    .catchall {:try_start_1e .. :try_end_2f} :catchall_32

    monitor-exit p0

    const/4 p1, 0x1

    return p1

    :catchall_32
    move-exception p1

    :try_start_33
    monitor-exit p0
    :try_end_34
    .catchall {:try_start_33 .. :try_end_34} :catchall_32

    throw p1
.end method

.method private static c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 6
    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_43

    invoke-static {p0}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_e

    goto :goto_43

    .line 10
    :cond_e
    :try_start_e
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_13
    .catch Lorg/json/JSONException; {:try_start_e .. :try_end_13} :catch_39

    .line 17
    invoke-virtual {v0}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object p1

    .line 18
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_38

    .line 19
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object p0, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_38
    return-object v1

    :catch_39
    move-exception p0

    .line 20
    invoke-static {p0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "DbAdapter"

    invoke-static {p1, p0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_43
    :goto_43
    return-object v1
.end method

.method private h()Ljava/lang/String;
    .registers 4

    .line 1
    new-instance v0, Ljava/text/SimpleDateFormat;

    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string/jumbo v2, "yyyy-MM-dd HH:mm:ss"

    invoke-direct {v0, v2, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 3
    new-instance v1, Ljava/util/Date;

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    .line 4
    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private h(Ljava/lang/String;)Ljava/util/Date;
    .registers 5

    .line 5
    new-instance v0, Ljava/text/SimpleDateFormat;

    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string/jumbo v2, "yyyy-MM-dd HH:mm:ss"

    invoke-direct {v0, v2, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 8
    :try_start_a
    invoke-virtual {v0, p1}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object p1
    :try_end_e
    .catch Ljava/text/ParseException; {:try_start_a .. :try_end_e} :catch_f

    return-object p1

    :catch_f
    move-exception p1

    .line 10
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "DbAdapter"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x0

    return-object p1
.end method

.method private static s(Ljava/lang/String;)J
    .registers 3

    .line 1
    :try_start_0
    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0
    :try_end_4
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_4} :catch_5
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_4} :catch_5

    return-wide v0

    :catch_5
    const-wide/16 v0, 0x0

    return-wide v0
.end method


# virtual methods
.method public declared-synchronized a([Ljava/lang/String;[I)Ljava/util/List;
    .registers 28

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    monitor-enter p0

    .line 44
    :try_start_5
    iget-object v2, v1, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v2}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v3

    .line 46
    const-string v4, "mediaId"

    const-string/jumbo v5, "title"

    const-string v6, "description"

    const-string v7, "durationMs"

    const-string v8, "filePath"

    const-string v9, "posters"

    const-string/jumbo v10, "status"

    const-string v11, "reason"

    const-string v12, "error"

    const-string/jumbo v13, "totalSize"

    const-string v14, "bytesDownloaded"

    const-string v15, "downloadPercent"

    const-string v16, "lastModTime"

    filled-new-array/range {v4 .. v16}, [Ljava/lang/String;

    move-result-object v5

    .line 63
    const-string v2, "cancelled = ? AND deleted = ?"

    const/4 v11, 0x0

    .line 65
    invoke-static {v11}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v11}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v6

    filled-new-array {v4, v6}, [Ljava/lang/String;

    move-result-object v4

    if-eqz v0, :cond_8b

    .line 66
    array-length v6, v0

    if-eqz v6, :cond_8b

    .line 67
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 68
    const-string v7, "("

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "?"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    .line 70
    :goto_50
    array-length v8, v0

    if-ge v7, v8, :cond_60

    const-string v8, ","

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "?"

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v7, v7, 0x1

    goto :goto_50

    .line 71
    :cond_60
    const-string v7, ")"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " AND "

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "mediaId"

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " IN "

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 73
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 74
    invoke-static {v4, v0}, Lcom/vdocipher/aegis/core/k/c;->a([Ljava/lang/String;[Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    :cond_8b
    move-object v6, v2

    move-object v7, v4

    .line 77
    const-string v4, "offline_vdos"

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v3 .. v10}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2
    :try_end_96
    .catchall {:try_start_5 .. :try_end_96} :catchall_185

    .line 87
    :try_start_96
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    if-eqz p2, :cond_a0

    move-object/from16 v5, p2

    goto :goto_a2

    .line 88
    :cond_a0
    new-array v5, v11, [I

    .line 91
    :goto_a2
    array-length v6, v5

    if-eqz v6, :cond_ac

    const/4 v6, 0x2

    invoke-static {v5, v6}, Lcom/vdocipher/aegis/core/k/c;->a([II)Z

    move-result v6

    if-eqz v6, :cond_b3

    .line 92
    :cond_ac
    invoke-direct {v1, v0, v3}, Lcom/vdocipher/aegis/core/k/c;->a([Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase;)Ljava/util/List;

    move-result-object v0

    .line 93
    invoke-interface {v4, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 97
    :cond_b3
    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-nez v0, :cond_be

    .line 98
    invoke-interface {v2}, Landroid/database/Cursor;->close()V
    :try_end_bc
    .catchall {:try_start_96 .. :try_end_bc} :catchall_17e

    monitor-exit p0

    return-object v4

    .line 105
    :cond_be
    :try_start_be
    const-string/jumbo v0, "status"

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v9

    .line 106
    array-length v0, v5

    if-eqz v0, :cond_d2

    invoke-static {v5, v9}, Lcom/vdocipher/aegis/core/k/c;->a([II)Z

    move-result v0

    if-eqz v0, :cond_173

    .line 108
    :cond_d2
    const-string v0, "mediaId"

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v12

    .line 109
    const-string/jumbo v0, "title"

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v13

    .line 110
    const-string v0, "description"

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v14

    .line 111
    const-string v0, "durationMs"

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v15

    .line 112
    const-string v0, "filePath"

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v8

    .line 113
    const-string v0, "reason"

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v2, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    .line 114
    const-string v3, "error"

    invoke-interface {v2, v3}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v3

    invoke-interface {v2, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    .line 115
    const-string/jumbo v6, "totalSize"

    invoke-interface {v2, v6}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v6

    invoke-interface {v2, v6}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    .line 116
    const-string v10, "bytesDownloaded"

    invoke-interface {v2, v10}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v10

    invoke-interface {v2, v10}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v18

    .line 117
    const-string v10, "downloadPercent"

    invoke-interface {v2, v10}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v10

    invoke-interface {v2, v10}, Landroid/database/Cursor;->getInt(I)I

    move-result v20

    .line 118
    const-string v10, "lastModTime"

    invoke-interface {v2, v10}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v10

    invoke-interface {v2, v10}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v10

    .line 119
    invoke-static {v10}, Lcom/vdocipher/aegis/core/k/c;->s(Ljava/lang/String;)J

    move-result-wide v21

    .line 120
    const-string v10, "posters"

    invoke-interface {v2, v10}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v10

    invoke-interface {v2, v10}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v10

    .line 121
    invoke-static {v8, v10}, Lcom/vdocipher/aegis/core/k/c;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    .line 123
    new-instance v10, Lcom/vdocipher/aegis/media/MediaInfo;

    const/4 v11, 0x3

    invoke-direct/range {v10 .. v16}, Lcom/vdocipher/aegis/media/MediaInfo;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    move-wide/from16 v14, v21

    move-object/from16 v21, v17

    move-wide/from16 v16, v6

    .line 124
    new-instance v6, Lcom/vdocipher/aegis/offline/DownloadStatus;

    const/16 v23, 0x0

    const/16 v24, 0x0

    const-wide/16 v12, 0x0

    const/16 v22, 0x0

    move-object v11, v3

    move-object v7, v10

    move v10, v0

    invoke-direct/range {v6 .. v24}, Lcom/vdocipher/aegis/offline/DownloadStatus;-><init>(Lcom/vdocipher/aegis/media/MediaInfo;Ljava/lang/String;IILjava/lang/String;JJJJILjava/lang/String;ZLjava/lang/String;Ljava/lang/String;)V

    .line 126
    invoke-interface {v4, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 128
    :cond_173
    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    move-result v0
    :try_end_177
    .catchall {:try_start_be .. :try_end_177} :catchall_17e

    if-nez v0, :cond_be

    .line 132
    :try_start_179
    invoke-interface {v2}, Landroid/database/Cursor;->close()V
    :try_end_17c
    .catchall {:try_start_179 .. :try_end_17c} :catchall_185

    monitor-exit p0

    return-object v4

    :catchall_17e
    move-exception v0

    if-eqz v2, :cond_184

    :try_start_181
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 133
    :cond_184
    throw v0

    :catchall_185
    move-exception v0

    monitor-exit p0
    :try_end_187
    .catchall {:try_start_181 .. :try_end_187} :catchall_185

    throw v0
.end method

.method public varargs a([Ljava/lang/String;)Ljava/util/Map;
    .registers 8

    .line 19
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    .line 21
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    move v3, v2

    .line 23
    :goto_d
    array-length v4, p1

    if-ge v3, v4, :cond_2c

    .line 24
    aget-object v4, p1, v2

    filled-new-array {v4}, [Ljava/lang/Object;

    move-result-object v4

    const-string v5, "\"%s\" "

    invoke-static {v5, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    array-length v4, p1

    add-int/lit8 v4, v4, -0x1

    if-eq v3, v4, :cond_29

    .line 26
    const-string v4, ","

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_29
    add-int/lit8 v3, v3, 0x1

    goto :goto_d

    .line 30
    :cond_2c
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v2, "select * from auto_resume where mediaId in ("

    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ") "

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    .line 32
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 35
    :goto_49
    :try_start_49
    invoke-interface {p1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v1

    if-eqz v1, :cond_6b

    .line 36
    const-string v1, "last_played_at"

    invoke-interface {p1, v1}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v1

    invoke-interface {p1, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 37
    const-string v2, "mediaId"

    invoke-interface {p1, v2}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v2

    invoke-interface {p1, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    .line 38
    invoke-direct {p0, v1}, Lcom/vdocipher/aegis/core/k/c;->h(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v1

    .line 39
    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_6a
    .catchall {:try_start_49 .. :try_end_6a} :catchall_6f

    goto :goto_49

    .line 42
    :cond_6b
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    return-object v0

    :catchall_6f
    move-exception v0

    if-eqz p1, :cond_75

    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 43
    :cond_75
    throw v0
.end method

.method public a()V
    .registers 3

    .line 17
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    .line 18
    const-string v1, "delete from usage_log"

    invoke-virtual {v0, v1}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    return-void
.end method

.method public declared-synchronized a(Landroid/content/Context;)V
    .registers 6

    monitor-enter p0

    .line 313
    :try_start_1
    iget-object p1, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {p1}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p1

    .line 314
    const-string v0, "SELECT * FROM pre_cache_album_art ORDER BY _id ASC LIMIT 1"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    if-eqz v0, :cond_43

    .line 317
    invoke-interface {v0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v1

    if-eqz v1, :cond_3e

    .line 318
    const-string v1, "_id"

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v1

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    .line 319
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v1

    const-string v2, "pre_cache_album_art"

    const-string v3, "_id = ?"

    invoke-virtual {p1, v2, v3, v1}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 320
    const-string p1, "file_path"

    invoke-interface {v0, p1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result p1

    if-ltz p1, :cond_3e

    .line 322
    invoke-interface {v0, p1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 323
    invoke-static {p1}, Lcom/vdocipher/aegis/core/z/d;->c(Ljava/lang/String;)V

    .line 326
    :cond_3e
    invoke-interface {v0}, Landroid/database/Cursor;->close()V
    :try_end_41
    .catchall {:try_start_1 .. :try_end_41} :catchall_45

    monitor-exit p0

    return-void

    :cond_43
    monitor-exit p0

    return-void

    :catchall_45
    move-exception p1

    :try_start_46
    monitor-exit p0
    :try_end_47
    .catchall {:try_start_46 .. :try_end_47} :catchall_45

    throw p1
.end method

.method public a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 7

    .line 1
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/k/c;->b()V

    .line 2
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 3
    const-string v1, "media_Id"

    invoke-virtual {v0, v1, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 4
    const-string p1, "cs_session_id"

    invoke-virtual {v0, p1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    const-string p1, "meta_data"

    invoke-virtual {v0, p1, p3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 6
    const-string p1, "b64Annotations"

    invoke-virtual {v0, p1, p4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    const-string p1, "media_item_detail"

    const/4 p2, 0x0

    invoke-direct {p0, p1, p2, v0}, Lcom/vdocipher/aegis/core/k/c;->b(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)Z

    return-void
.end method

.method public declared-synchronized a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 9

    monitor-enter p0

    .line 305
    :try_start_1
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 306
    const-string/jumbo v1, "uri"

    invoke-virtual {v0, v1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 307
    const-string p2, "media_id"

    invoke-virtual {v0, p2, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 308
    const-string p1, "file_path"

    invoke-virtual {v0, p1, p3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 309
    const-string p1, "meta_url"

    invoke-virtual {v0, p1, p4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 310
    const-string p1, "meta_data"

    invoke-virtual {v0, p1, p6}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 311
    const-string p1, "language_code"

    invoke-virtual {v0, p1, p5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 312
    const-string p1, "pre_cache_album_art"

    const/4 p2, 0x0

    invoke-direct {p0, p1, p2, v0}, Lcom/vdocipher/aegis/core/k/c;->b(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)Z
    :try_end_2b
    .catchall {:try_start_1 .. :try_end_2b} :catchall_2d

    monitor-exit p0

    return-void

    :catchall_2d
    move-exception p1

    :try_start_2e
    monitor-exit p0
    :try_end_2f
    .catchall {:try_start_2e .. :try_end_2f} :catchall_2d

    throw p1
.end method

.method public a(Ljava/lang/Throwable;Ljava/lang/String;Z)V
    .registers 5

    .line 16
    new-instance v0, Lcom/vdocipher/aegis/core/k/c$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/k/c$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/core/k/c;Ljava/lang/Throwable;Ljava/lang/String;Z)V

    invoke-static {v0}, Landroid/os/AsyncTask;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public a(Ljava/lang/String;)Z
    .registers 12

    .line 231
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    .line 235
    const-string v0, "mediaId"

    const-string v9, "canDelete"

    filled-new-array {v0, v9}, [Ljava/lang/String;

    move-result-object v3

    .line 240
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x0

    const/4 v8, 0x0

    .line 242
    const-string v2, "deletion_entry"

    const-string v4, "mediaId = ?"

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    .line 253
    :try_start_1d
    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_34

    .line 254
    invoke-interface {p1, v9}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0
    :try_end_2c
    .catchall {:try_start_1d .. :try_end_2c} :catchall_3f

    const/4 v2, 0x1

    if-ne v0, v2, :cond_30

    move v1, v2

    .line 261
    :cond_30
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    return v1

    .line 262
    :cond_34
    :try_start_34
    const-string v0, "DbAdapter"

    const-string v2, "no rows found"

    invoke-static {v0, v2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3b
    .catchall {:try_start_34 .. :try_end_3b} :catchall_3f

    .line 266
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    return v1

    :catchall_3f
    move-exception v0

    if-eqz p1, :cond_45

    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 267
    :cond_45
    throw v0
.end method

.method public a(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 5

    .line 8
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 9
    const-string v1, "mediaId"

    invoke-virtual {v0, v1, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 10
    const-string p1, "sessionId"

    invoke-virtual {v0, p1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 13
    :try_start_f
    const-string p1, "sessions"

    const/4 p2, 0x0

    invoke-direct {p0, p1, p2, v0}, Lcom/vdocipher/aegis/core/k/c;->b(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)Z

    move-result p1
    :try_end_16
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_f .. :try_end_16} :catch_17

    return p1

    :catch_17
    move-exception p1

    .line 15
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DbAdapter"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x0

    return p1
.end method

.method public a(Ljava/lang/String;Z)Z
    .registers 5

    .line 268
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 269
    const-string v1, "mediaId"

    invoke-virtual {v0, v1, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 270
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const-string v1, "canDelete"

    invoke-virtual {v0, v1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 272
    const-string p2, "deletion_entry"

    const/4 v1, 0x0

    invoke-direct {p0, p2, v1, v0}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)Z

    move-result p2

    if-nez p2, :cond_31

    .line 275
    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Failed to create deletion entry for media id : "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "DbAdapter"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x0

    return p1

    :cond_31
    const/4 p1, 0x1

    return p1
.end method

.method public b()V
    .registers 3

    .line 30
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    .line 31
    const-string v1, "delete from media_item_detail"

    invoke-virtual {v0, v1}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .registers 4

    .line 36
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    .line 38
    const-string v0, "offline_vdos"

    const-string v1, "mediaId = ?"

    invoke-direct {p0, v0, v1, p1}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V

    return-void
.end method

.method public b(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 5

    .line 5
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 6
    const-string v1, "mediaId"

    invoke-virtual {v0, v1, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    const-string p1, "position"

    invoke-virtual {v0, p1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 8
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/k/c;->h()Ljava/lang/String;

    move-result-object p1

    const-string p2, "last_played_at"

    invoke-virtual {v0, p2, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 11
    :try_start_18
    const-string p1, "auto_resume"

    const/4 p2, 0x0

    invoke-direct {p0, p1, p2, v0}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)Z

    move-result p1
    :try_end_1f
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_18 .. :try_end_1f} :catch_20

    return p1

    :catch_20
    move-exception p1

    .line 13
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DbAdapter"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x0

    return p1
.end method

.method public b(Ljava/lang/String;Z)Z
    .registers 5

    .line 32
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 33
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const-string v1, "canDelete"

    invoke-virtual {v0, v1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 35
    const-string p2, "deletion_entry"

    invoke-direct {p0, v0, p2, p1}, Lcom/vdocipher/aegis/core/k/c;->a(Landroid/content/ContentValues;Ljava/lang/String;Ljava/lang/String;)Z

    move-result p1

    return p1
.end method

.method public c()V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    .line 2
    const-string v1, "delete from crash_log"

    invoke-virtual {v0, v1}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    return-void
.end method

.method public c(Ljava/lang/String;)V
    .registers 4

    .line 3
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    .line 5
    const-string v0, "deletion_entry"

    const-string v1, "mediaId = ?"

    invoke-direct {p0, v0, v1, p1}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V

    return-void
.end method

.method public declared-synchronized d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 12

    monitor-enter p0

    .line 4
    :try_start_1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    if-eqz p2, :cond_10

    .line 12
    const-string v0, "meta_url = ? AND language_code = ?"

    .line 13
    filled-new-array {p1, p2}, [Ljava/lang/String;

    move-result-object p1

    goto :goto_16

    .line 16
    :cond_10
    const-string v0, "meta_url = ?"

    .line 17
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    :goto_16
    move-object v5, p1

    move-object v4, v0

    .line 21
    const-string p1, "meta_data"

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v3

    const-string v2, "pre_cache_album_art"

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    if-eqz p1, :cond_41

    .line 32
    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result p2

    if-eqz p2, :cond_3e

    .line 33
    const-string p2, "meta_data"

    invoke-interface {p1, p2}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result p2

    invoke-interface {p1, p2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p2

    .line 34
    invoke-interface {p1}, Landroid/database/Cursor;->close()V
    :try_end_3c
    .catchall {:try_start_1 .. :try_end_3c} :catchall_44

    monitor-exit p0

    return-object p2

    .line 37
    :cond_3e
    :try_start_3e
    invoke-interface {p1}, Landroid/database/Cursor;->close()V
    :try_end_41
    .catchall {:try_start_3e .. :try_end_41} :catchall_44

    :cond_41
    monitor-exit p0

    const/4 p1, 0x0

    return-object p1

    :catchall_44
    move-exception v0

    move-object p1, v0

    :try_start_46
    monitor-exit p0
    :try_end_47
    .catchall {:try_start_46 .. :try_end_47} :catchall_44

    throw p1
.end method

.method public d()V
    .registers 10

    .line 38
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    .line 41
    const-string v0, "file_path"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-string v2, "pre_cache_album_art"

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    if-eqz v2, :cond_30

    .line 43
    :cond_19
    :goto_19
    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    move-result v3

    if-eqz v3, :cond_2d

    .line 44
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v3

    if-ltz v3, :cond_19

    .line 46
    invoke-interface {v2, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    .line 47
    invoke-static {v3}, Lcom/vdocipher/aegis/core/z/d;->c(Ljava/lang/String;)V

    goto :goto_19

    .line 50
    :cond_2d
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 54
    :cond_30
    const-string v0, "pre_cache_album_art"

    const/4 v2, 0x0

    invoke-virtual {v1, v0, v2, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    return-void
.end method

.method public d(Ljava/lang/String;)V
    .registers 4

    .line 1
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    .line 3
    const-string v0, "media_item_detail"

    const-string v1, "media_Id = ?"

    invoke-direct {p0, v0, v1, p1}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V

    return-void
.end method

.method public e()Ljava/util/List;
    .registers 12

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    .line 5
    const-string v0, "method_name"

    const-string v9, "class_name"

    const-string v10, "count"

    filled-new-array {v0, v9, v10}, [Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v8, 0x0

    .line 8
    const-string/jumbo v2, "usage_log"

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 18
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 20
    :goto_21
    :try_start_21
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v3

    if-eqz v3, :cond_55

    .line 21
    invoke-interface {v1, v10}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v3

    invoke-interface {v1, v3}, Landroid/database/Cursor;->getInt(I)I

    move-result v3

    .line 22
    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v4

    invoke-interface {v1, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v4

    .line 23
    invoke-interface {v1, v9}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v5

    invoke-interface {v1, v5}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v5

    .line 24
    new-instance v6, Lcom/vdocipher/aegis/core/a0/a;

    invoke-direct {v6}, Lcom/vdocipher/aegis/core/a0/a;-><init>()V

    .line 25
    invoke-virtual {v6, v5}, Lcom/vdocipher/aegis/core/a0/a;->a(Ljava/lang/String;)V

    .line 26
    invoke-virtual {v6, v4}, Lcom/vdocipher/aegis/core/a0/a;->b(Ljava/lang/String;)V

    .line 27
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v6, v3}, Lcom/vdocipher/aegis/core/a0/a;->a(Ljava/lang/Integer;)V

    .line 28
    invoke-interface {v2, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_54
    .catchall {:try_start_21 .. :try_end_54} :catchall_59

    goto :goto_21

    .line 31
    :cond_55
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    return-object v2

    :catchall_59
    move-exception v0

    if-eqz v1, :cond_5f

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 32
    :cond_5f
    throw v0
.end method

.method public e(Ljava/lang/String;)V
    .registers 4

    .line 44
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    .line 46
    const-string/jumbo v0, "vdo_queue"

    const-string v1, "mediaId = ?"

    invoke-direct {p0, v0, v1, p1}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V

    return-void
.end method

.method public e(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 6

    .line 33
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 34
    const-string v1, "b64Annotations"

    invoke-virtual {v0, v1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 36
    iget-object p2, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {p2}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p2

    .line 41
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    .line 43
    const-string v1, "media_item_detail"

    const-string v2, "media_Id = ?"

    invoke-virtual {p2, v1, v0, v2, p1}, Landroid/database/sqlite/SQLiteDatabase;->update(Ljava/lang/String;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    move-result p1

    const/4 p2, 0x1

    if-ne p1, p2, :cond_20

    return p2

    :cond_20
    const/4 p1, 0x0

    return p1
.end method

.method public declared-synchronized f()I
    .registers 4

    monitor-enter p0

    .line 24
    :try_start_1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    .line 27
    const-string v1, "SELECT COUNT(*) FROM pre_cache_album_art"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_20

    .line 30
    invoke-interface {v0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v2

    if-eqz v2, :cond_1b

    .line 31
    invoke-interface {v0, v1}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    .line 33
    :cond_1b
    invoke-interface {v0}, Landroid/database/Cursor;->close()V
    :try_end_1e
    .catchall {:try_start_1 .. :try_end_1e} :catchall_22

    monitor-exit p0

    return v1

    :cond_20
    monitor-exit p0

    return v1

    :catchall_22
    move-exception v0

    :try_start_23
    monitor-exit p0
    :try_end_24
    .catchall {:try_start_23 .. :try_end_24} :catchall_22

    throw v0
.end method

.method public f(Ljava/lang/String;)V
    .registers 4

    .line 21
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    .line 23
    const-string v0, "sessions"

    const-string v1, "mediaId = ?"

    invoke-direct {p0, v0, v1, p1}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V

    return-void
.end method

.method public f(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 7

    .line 1
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 2
    const-string v1, "position"

    invoke-virtual {v0, v1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/k/c;->h()Ljava/lang/String;

    move-result-object p2

    const-string v1, "last_played_at"

    invoke-virtual {v0, v1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    iget-object p2, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {p2}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p2

    .line 9
    const-string v1, "mediaId = ?"

    .line 10
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    .line 13
    :try_start_20
    const-string v3, "auto_resume"

    invoke-virtual {p2, v3, v0, v1, p1}, Landroid/database/sqlite/SQLiteDatabase;->update(Ljava/lang/String;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    move-result p1
    :try_end_26
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_20 .. :try_end_26} :catch_2b

    const/4 p2, 0x1

    if-ne p1, p2, :cond_2a

    return p2

    :cond_2a
    return v2

    :catch_2b
    move-exception p1

    .line 20
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DbAdapter"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return v2
.end method

.method public g(Ljava/lang/String;)Ljava/lang/String;
    .registers 10

    .line 82
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v4

    .line 84
    new-instance v0, Lcom/vdocipher/aegis/core/k/c$a;

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v1, "offline_vdos"

    const-string v2, "extras"

    const-string v3, "mediaId = ?"

    const/4 v5, 0x0

    invoke-direct/range {v0 .. v7}, Lcom/vdocipher/aegis/core/k/c$a;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/k/c;->a(Lcom/vdocipher/aegis/core/k/c$a;)Ljava/lang/String;

    move-result-object p1

    .line 86
    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_2f

    .line 87
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 88
    const-string p1, "annotationCode"

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2f

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_2f
    return-object v1
.end method

.method public g()Ljava/util/List;
    .registers 14

    .line 45
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    .line 49
    const-string/jumbo v0, "stacktrace"

    const-string/jumbo v9, "timestamp"

    const-string v10, "crash_data"

    const-string v11, "is_handled"

    const-string v12, "sdk_version"

    filled-new-array {v0, v9, v10, v11, v12}, [Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v8, 0x0

    .line 53
    const-string v2, "crash_log"

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 63
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 65
    :goto_26
    :try_start_26
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v3

    if-eqz v3, :cond_71

    .line 66
    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v3

    invoke-interface {v1, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    .line 67
    invoke-interface {v1, v9}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v4

    invoke-interface {v1, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v4

    .line 68
    invoke-interface {v1, v10}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v5

    invoke-interface {v1, v5}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v5

    .line 69
    invoke-interface {v1, v11}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v6

    invoke-interface {v1, v6}, Landroid/database/Cursor;->getInt(I)I

    move-result v6

    .line 70
    invoke-interface {v1, v12}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v7

    invoke-interface {v1, v7}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v7

    .line 71
    new-instance v8, Lcom/vdocipher/aegis/core/a0/b;

    invoke-direct {v8}, Lcom/vdocipher/aegis/core/a0/b;-><init>()V

    .line 72
    invoke-virtual {v8, v3}, Lcom/vdocipher/aegis/core/a0/b;->c(Ljava/lang/String;)V

    .line 73
    invoke-virtual {v8, v4}, Lcom/vdocipher/aegis/core/a0/b;->d(Ljava/lang/String;)V

    .line 74
    invoke-virtual {v8, v5}, Lcom/vdocipher/aegis/core/a0/b;->a(Ljava/lang/String;)V

    const/4 v3, 0x1

    if-ne v6, v3, :cond_66

    goto :goto_67

    :cond_66
    const/4 v3, 0x0

    .line 75
    :goto_67
    invoke-virtual {v8, v3}, Lcom/vdocipher/aegis/core/a0/b;->a(Z)V

    .line 76
    invoke-virtual {v8, v7}, Lcom/vdocipher/aegis/core/a0/b;->b(Ljava/lang/String;)V

    .line 77
    invoke-interface {v2, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_70
    .catchall {:try_start_26 .. :try_end_70} :catchall_75

    goto :goto_26

    .line 80
    :cond_71
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    return-object v2

    :catchall_75
    move-exception v0

    if-eqz v1, :cond_7b

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 81
    :cond_7b
    throw v0
.end method

.method public g(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 14

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    .line 5
    const-string v0, "hash"

    const-string v9, "count"

    filled-new-array {v0, v9}, [Ljava/lang/String;

    move-result-object v3

    .line 8
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v10

    .line 11
    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x0

    const/4 v8, 0x0

    .line 13
    const-string/jumbo v2, "usage_log"

    const-string v4, "hash = ?"

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 25
    :try_start_35
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v2
    :try_end_39
    .catchall {:try_start_35 .. :try_end_39} :catchall_82

    const-string v3, "DbAdapter"

    const/4 v4, 0x0

    if-eqz v2, :cond_47

    .line 26
    :try_start_3e
    invoke-interface {v1, v9}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v2

    invoke-interface {v1, v2}, Landroid/database/Cursor;->getInt(I)I

    move-result v2

    goto :goto_4d

    .line 28
    :cond_47
    const-string v2, "no rows found"

    invoke-static {v3, v2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_4c
    .catchall {:try_start_3e .. :try_end_4c} :catchall_82

    move v2, v4

    .line 31
    :goto_4d
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 33
    new-instance v1, Landroid/content/ContentValues;

    invoke-direct {v1}, Landroid/content/ContentValues;-><init>()V

    .line 34
    const-string v5, "method_name"

    invoke-virtual {v1, v5, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 35
    const-string p1, "class_name"

    invoke-virtual {v1, p1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 36
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v1, v0, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    add-int/lit8 v2, v2, 0x1

    .line 37
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v1, v9, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 40
    :try_start_6f
    const-string/jumbo p1, "usage_log"

    const/4 p2, 0x0

    invoke-direct {p0, p1, p2, v1}, Lcom/vdocipher/aegis/core/k/c;->b(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)Z

    move-result p1
    :try_end_77
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_6f .. :try_end_77} :catch_78

    return p1

    :catch_78
    move-exception v0

    move-object p1, v0

    .line 42
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v3, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return v4

    :catchall_82
    move-exception v0

    move-object p1, v0

    if-eqz v1, :cond_89

    .line 43
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 44
    :cond_89
    throw p1
.end method

.method public i(Ljava/lang/String;)Ljava/lang/String;
    .registers 10

    .line 35
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v4

    .line 37
    new-instance v0, Lcom/vdocipher/aegis/core/k/c$a;

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v1, "offline_vdos"

    const-string v2, "filePath"

    const-string v3, "mediaId = ?"

    const/4 v5, 0x0

    invoke-direct/range {v0 .. v7}, Lcom/vdocipher/aegis/core/k/c$a;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/k/c;->a(Lcom/vdocipher/aegis/core/k/c$a;)Ljava/lang/String;

    move-result-object p1

    .line 39
    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1d

    const/4 p1, 0x0

    :cond_1d
    return-object p1
.end method

.method public declared-synchronized i()Ljava/util/HashSet;
    .registers 10

    monitor-enter p0

    .line 1
    :try_start_1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    .line 3
    const-string v0, "mediaId"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v3

    const/4 v0, 0x1

    .line 8
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v5

    .line 10
    const-string v2, "offline_vdos"

    const-string v4, "deleted = ?"

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1
    :try_end_21
    .catchall {:try_start_1 .. :try_end_21} :catchall_50

    .line 19
    :try_start_21
    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 20
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v2

    if-nez v2, :cond_31

    .line 21
    invoke-interface {v1}, Landroid/database/Cursor;->close()V
    :try_end_2f
    .catchall {:try_start_21 .. :try_end_2f} :catchall_49

    monitor-exit p0

    return-object v0

    .line 27
    :cond_31
    :try_start_31
    const-string v2, "mediaId"

    invoke-interface {v1, v2}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v2

    invoke-interface {v1, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    .line 28
    invoke-virtual {v0, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 29
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v2
    :try_end_42
    .catchall {:try_start_31 .. :try_end_42} :catchall_49

    if-nez v2, :cond_31

    .line 33
    :try_start_44
    invoke-interface {v1}, Landroid/database/Cursor;->close()V
    :try_end_47
    .catchall {:try_start_44 .. :try_end_47} :catchall_50

    monitor-exit p0

    return-object v0

    :catchall_49
    move-exception v0

    if-eqz v1, :cond_4f

    :try_start_4c
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 34
    :cond_4f
    throw v0

    :catchall_50
    move-exception v0

    monitor-exit p0
    :try_end_52
    .catchall {:try_start_4c .. :try_end_52} :catchall_50

    throw v0
.end method

.method public j(Ljava/lang/String;)Ljava/lang/String;
    .registers 10

    .line 1
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v4

    .line 3
    new-instance v0, Lcom/vdocipher/aegis/core/k/c$a;

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v1, "offline_vdos"

    const-string v2, "dlIdentifiers"

    const-string v3, "mediaId = ?"

    const/4 v5, 0x0

    invoke-direct/range {v0 .. v7}, Lcom/vdocipher/aegis/core/k/c$a;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/k/c;->a(Lcom/vdocipher/aegis/core/k/c$a;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public j()Ljava/util/List;
    .registers 11

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    .line 8
    const-string v0, "canDelete"

    const-string v9, "mediaId"

    filled-new-array {v9, v0}, [Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v8, 0x0

    .line 11
    const-string v2, "deletion_entry"

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 21
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 23
    :goto_1e
    :try_start_1e
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v2

    if-eqz v2, :cond_30

    .line 24
    invoke-interface {v1, v9}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v2

    invoke-interface {v1, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    .line 25
    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_2f
    .catchall {:try_start_1e .. :try_end_2f} :catchall_34

    goto :goto_1e

    .line 28
    :cond_30
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    return-object v0

    :catchall_34
    move-exception v0

    if-eqz v1, :cond_3a

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 29
    :cond_3a
    throw v0
.end method

.method public declared-synchronized k(Ljava/lang/String;)Ljava/lang/String;
    .registers 12

    monitor-enter p0

    const/4 v0, 0x0

    if-nez p1, :cond_6

    monitor-exit p0

    return-object v0

    .line 1
    :cond_6
    :try_start_6
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v2

    .line 2
    const-string v1, "file_path"

    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v4

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v6

    const-string v3, "pre_cache_album_art"

    const-string/jumbo v5, "uri = ?"

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v7, 0x0

    invoke-virtual/range {v2 .. v9}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    if-eqz p1, :cond_3c

    .line 13
    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v1

    if-eqz v1, :cond_39

    .line 14
    const-string v0, "file_path"

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 15
    invoke-interface {p1}, Landroid/database/Cursor;->close()V
    :try_end_37
    .catchall {:try_start_6 .. :try_end_37} :catchall_3e

    monitor-exit p0

    return-object v0

    .line 18
    :cond_39
    :try_start_39
    invoke-interface {p1}, Landroid/database/Cursor;->close()V
    :try_end_3c
    .catchall {:try_start_39 .. :try_end_3c} :catchall_3e

    :cond_3c
    monitor-exit p0

    return-object v0

    :catchall_3e
    move-exception v0

    move-object p1, v0

    :try_start_40
    monitor-exit p0
    :try_end_41
    .catchall {:try_start_40 .. :try_end_41} :catchall_3e

    throw p1
.end method

.method public l(Ljava/lang/String;)Ljava/lang/String;
    .registers 10

    .line 1
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v4

    .line 3
    new-instance v0, Lcom/vdocipher/aegis/core/k/c$a;

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v1, "offline_vdos"

    const-string v2, "keyId"

    const-string v3, "mediaId = ?"

    const/4 v5, 0x0

    invoke-direct/range {v0 .. v7}, Lcom/vdocipher/aegis/core/k/c$a;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/k/c;->a(Lcom/vdocipher/aegis/core/k/c$a;)Ljava/lang/String;

    move-result-object p1

    .line 5
    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1d

    const/4 p1, 0x0

    :cond_1d
    return-object p1
.end method

.method public m(Ljava/lang/String;)Ljava/lang/String;
    .registers 10

    .line 1
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v4

    .line 3
    new-instance v0, Lcom/vdocipher/aegis/core/k/c$a;

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v1, "offline_vdos"

    const-string v2, "dlspec"

    const-string v3, "mediaId = ?"

    const/4 v5, 0x0

    invoke-direct/range {v0 .. v7}, Lcom/vdocipher/aegis/core/k/c$a;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/k/c;->a(Lcom/vdocipher/aegis/core/k/c$a;)Ljava/lang/String;

    move-result-object p1

    .line 5
    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1e

    const/4 p1, 0x0

    return-object p1

    .line 9
    :cond_1e
    invoke-static {p1}, Lcom/vdocipher/aegis/core/k/d;->a(Ljava/lang/String;)Lcom/vdocipher/aegis/core/k/d;

    move-result-object p1

    .line 10
    const-string v0, "dss.lic"

    invoke-virtual {p1, v0}, Lcom/vdocipher/aegis/core/k/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public declared-synchronized n(Ljava/lang/String;)Ljava/lang/String;
    .registers 11

    monitor-enter p0

    .line 1
    :try_start_1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    .line 3
    const-string v0, "mediaId"

    const-string v2, "filePath"

    const-string v3, "manifest"

    filled-new-array {v0, v2, v3}, [Ljava/lang/String;

    move-result-object v3

    .line 10
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v5

    .line 12
    const-string v2, "offline_vdos"

    const-string v4, "mediaId = ?"

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1
    :try_end_20
    .catchall {:try_start_1 .. :try_end_20} :catchall_74

    .line 21
    :try_start_20
    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_61

    .line 22
    const-string v0, "filePath"

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 24
    const-string v2, "manifest"

    invoke-interface {p1, v2}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v2

    invoke-interface {p1, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    .line 26
    invoke-static {v0}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_5c

    invoke-static {v2}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_48

    goto :goto_5c

    .line 27
    :cond_48
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v0, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_5c
    .catchall {:try_start_20 .. :try_end_5c} :catchall_6d

    .line 33
    :cond_5c
    :goto_5c
    :try_start_5c
    invoke-interface {p1}, Landroid/database/Cursor;->close()V
    :try_end_5f
    .catchall {:try_start_5c .. :try_end_5f} :catchall_74

    monitor-exit p0

    return-object v1

    .line 34
    :cond_61
    :try_start_61
    const-string v0, "DbAdapter"

    const-string v2, "no rows"

    invoke-static {v0, v2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_68
    .catchall {:try_start_61 .. :try_end_68} :catchall_6d

    .line 38
    :try_start_68
    invoke-interface {p1}, Landroid/database/Cursor;->close()V
    :try_end_6b
    .catchall {:try_start_68 .. :try_end_6b} :catchall_74

    monitor-exit p0

    return-object v1

    :catchall_6d
    move-exception v0

    if-eqz p1, :cond_73

    :try_start_70
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 39
    :cond_73
    throw v0

    :catchall_74
    move-exception v0

    move-object p1, v0

    monitor-exit p0
    :try_end_77
    .catchall {:try_start_70 .. :try_end_77} :catchall_74

    throw p1
.end method

.method public o(Ljava/lang/String;)Lcom/vdocipher/aegis/core/p/c;
    .registers 14

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    .line 5
    const-string v0, "media_Id"

    const-string v9, "cs_session_id"

    const-string v10, "meta_data"

    const-string v11, "b64Annotations"

    filled-new-array {v0, v9, v10, v11}, [Ljava/lang/String;

    move-result-object v3

    .line 14
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x0

    const/4 v8, 0x0

    .line 16
    const-string v2, "media_item_detail"

    const-string v4, "media_Id = ?"

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    .line 25
    :try_start_21
    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v1

    if-eqz v1, :cond_50

    .line 26
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 27
    invoke-interface {p1, v9}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v1

    invoke-interface {p1, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 28
    invoke-interface {p1, v10}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v2

    invoke-interface {p1, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    .line 29
    invoke-interface {p1, v11}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v3

    invoke-interface {p1, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    .line 31
    new-instance v4, Lcom/vdocipher/aegis/core/p/c;

    invoke-direct {v4, v0, v1, v2, v3}, Lcom/vdocipher/aegis/core/p/c;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_4c
    .catchall {:try_start_21 .. :try_end_4c} :catchall_5c

    .line 36
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    return-object v4

    .line 37
    :cond_50
    :try_start_50
    const-string v0, "DbAdapter"

    const-string v1, "no rows found"

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_57
    .catchall {:try_start_50 .. :try_end_57} :catchall_5c

    .line 40
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    const/4 p1, 0x0

    return-object p1

    :catchall_5c
    move-exception v0

    move-object v1, v0

    if-eqz p1, :cond_69

    .line 41
    :try_start_60
    invoke-interface {p1}, Landroid/database/Cursor;->close()V
    :try_end_63
    .catchall {:try_start_60 .. :try_end_63} :catchall_64

    goto :goto_69

    :catchall_64
    move-exception v0

    move-object p1, v0

    invoke-virtual {v1, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_69
    :goto_69
    throw v1
.end method

.method public p(Ljava/lang/String;)Ljava/lang/String;
    .registers 10

    .line 1
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v4

    .line 3
    new-instance v0, Lcom/vdocipher/aegis/core/k/c$a;

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v1, "offline_vdos"

    const-string v2, "dlspec"

    const-string v3, "mediaId = ?"

    const/4 v5, 0x0

    invoke-direct/range {v0 .. v7}, Lcom/vdocipher/aegis/core/k/c$a;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/k/c;->a(Lcom/vdocipher/aegis/core/k/c$a;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_2b

    .line 5
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1f

    goto :goto_2b

    .line 8
    :cond_1f
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 9
    const-string p1, "dss.meta"

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_2b
    :goto_2b
    const/4 p1, 0x0

    return-object p1
.end method

.method public q(Ljava/lang/String;)Landroid/util/Pair;
    .registers 13

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    .line 5
    const-string v0, "mediaId"

    const-string v9, "position"

    const-string v10, "last_played_at"

    filled-new-array {v0, v9, v10}, [Ljava/lang/String;

    move-result-object v3

    .line 10
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x0

    const/4 v8, 0x0

    .line 12
    const-string v2, "auto_resume"

    const-string v4, "mediaId = ?"

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    .line 23
    :try_start_1f
    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-eqz v0, :cond_42

    .line 24
    invoke-interface {p1, v9}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 25
    invoke-interface {p1, v10}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v1

    invoke-interface {p1, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 26
    invoke-direct {p0, v1}, Lcom/vdocipher/aegis/core/k/c;->h(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v1

    .line 27
    new-instance v2, Landroid/util/Pair;

    invoke-direct {v2, v0, v1}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_3e
    .catchall {:try_start_1f .. :try_end_3e} :catchall_4e

    .line 33
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    return-object v2

    .line 34
    :cond_42
    :try_start_42
    const-string v0, "DbAdapter"

    const-string v1, "no rows found"

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_49
    .catchall {:try_start_42 .. :try_end_49} :catchall_4e

    .line 38
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    const/4 p1, 0x0

    return-object p1

    :catchall_4e
    move-exception v0

    if-eqz p1, :cond_54

    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 39
    :cond_54
    throw v0
.end method

.method public r(Ljava/lang/String;)Ljava/lang/String;
    .registers 12

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c;->a:Lcom/vdocipher/aegis/core/l/a;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    .line 5
    const-string v0, "mediaId"

    const-string v9, "sessionId"

    filled-new-array {v0, v9}, [Ljava/lang/String;

    move-result-object v3

    .line 12
    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x0

    const/4 v8, 0x0

    .line 14
    const-string v2, "sessions"

    const-string v4, "mediaId = ?"

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    .line 25
    :try_start_1d
    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-eqz v0, :cond_2f

    .line 26
    invoke-interface {p1, v9}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0
    :try_end_2b
    .catchall {:try_start_1d .. :try_end_2b} :catchall_3b

    .line 32
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    return-object v0

    .line 33
    :cond_2f
    :try_start_2f
    const-string v0, "DbAdapter"

    const-string v1, "no rows found"

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_36
    .catchall {:try_start_2f .. :try_end_36} :catchall_3b

    .line 37
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    const/4 p1, 0x0

    return-object p1

    :catchall_3b
    move-exception v0

    if-eqz p1, :cond_41

    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 38
    :cond_41
    throw v0
.end method

.method public t(Ljava/lang/String;)Z
    .registers 5

    .line 1
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    const/4 v1, 0x1

    .line 2
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "deleted"

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 4
    const-string v1, "offline_vdos"

    invoke-direct {p0, v0, v1, p1}, Lcom/vdocipher/aegis/core/k/c;->a(Landroid/content/ContentValues;Ljava/lang/String;Ljava/lang/String;)Z

    move-result p1

    return p1
.end method
