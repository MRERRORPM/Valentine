# classes14.dex

.class public Lcom/vdocipher/aegis/core/k/d$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/k/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field private final a:Ljava/util/ArrayList;

.field private final b:Lorg/json/JSONObject;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 14

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/k/d$b;->a:Ljava/util/ArrayList;

    .line 3
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    iput-object v1, p0, Lcom/vdocipher/aegis/core/k/d$b;->b:Lorg/json/JSONObject;

    .line 7
    new-instance v1, Lcom/vdocipher/aegis/core/k/d$c;

    const-string v2, "dss.mid"

    invoke-direct {v1, v2, p1}, Lcom/vdocipher/aegis/core/k/d$c;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 8
    new-instance p1, Lcom/vdocipher/aegis/core/k/d$c;

    const-string v1, "dss.loc"

    invoke-direct {p1, v1, p2}, Lcom/vdocipher/aegis/core/k/d$c;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 9
    new-instance p1, Lcom/vdocipher/aegis/core/k/d$c;

    const-string p2, "dss.type"

    invoke-direct {p1, p2, p3}, Lcom/vdocipher/aegis/core/k/d$c;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 10
    new-instance p1, Lcom/vdocipher/aegis/core/k/d$c;

    const-string p2, "dss.meta"

    invoke-direct {p1, p2, p4}, Lcom/vdocipher/aegis/core/k/d$c;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 11
    new-instance p1, Lcom/vdocipher/aegis/core/k/d$c;

    const-string p2, "dss.manf"

    invoke-direct {p1, p2, p5}, Lcom/vdocipher/aegis/core/k/d$c;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 12
    new-instance p1, Lcom/vdocipher/aegis/core/k/d$c;

    const-string p2, "dss.lic"

    invoke-direct {p1, p2, p6}, Lcom/vdocipher/aegis/core/k/d$c;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 13
    new-instance p1, Lcom/vdocipher/aegis/core/k/d$c;

    const-string p2, "dss.fbservers"

    invoke-direct {p1, p2, p7}, Lcom/vdocipher/aegis/core/k/d$c;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 14
    new-instance p1, Lcom/vdocipher/aegis/core/k/d$c;

    const-string p2, "dss.lictokenparams"

    invoke-direct {p1, p2, p8}, Lcom/vdocipher/aegis/core/k/d$c;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 15
    new-instance p1, Lcom/vdocipher/aegis/core/k/d$c;

    const-string p2, "dss.dlopts"

    invoke-direct {p1, p2, p9}, Lcom/vdocipher/aegis/core/k/d$c;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 16
    new-instance p1, Lcom/vdocipher/aegis/core/k/d$c;

    const-string p2, "dss.language"

    invoke-direct {p1, p2, p10}, Lcom/vdocipher/aegis/core/k/d$c;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method


# virtual methods
.method public a(ILjava/lang/String;)Lcom/vdocipher/aegis/core/k/d$b;
    .registers 6

    if-ltz p1, :cond_1f

    .line 1
    invoke-static {p2}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1f

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/d$b;->b:Lorg/json/JSONObject;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "h_"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_1f
    return-object p0
.end method

.method public a()Lcom/vdocipher/aegis/core/k/d;
    .registers 5

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/d$b;->b:Lorg/json/JSONObject;

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    .line 4
    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/d$b;->a:Ljava/util/ArrayList;

    new-instance v2, Lcom/vdocipher/aegis/core/k/d$c;

    const-string v3, "dss.pos"

    invoke-direct {v2, v3, v0}, Lcom/vdocipher/aegis/core/k/d$c;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 5
    new-instance v0, Lcom/vdocipher/aegis/core/k/d;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/d$b;->a:Ljava/util/ArrayList;

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/vdocipher/aegis/core/k/d;-><init>(Ljava/util/List;Lcom/vdocipher/aegis/core/k/d$a;)V

    return-object v0
.end method
