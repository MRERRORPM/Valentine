# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/k/b;

.field public final synthetic f$1:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/k/b;Ljava/lang/String;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda3;->f$0:Lcom/vdocipher/aegis/core/k/b;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda3;->f$1:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda3;->f$0:Lcom/vdocipher/aegis/core/k/b;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda3;->f$1:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/k/b;->$r8$lambda$pdNA6qUIMSA0Vs50hohgnDS594c(Lcom/vdocipher/aegis/core/k/b;Ljava/lang/String;)V

    return-void
.end method
