# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/k/i$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lcom/vdocipher/aegis/core/m/u$d;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/k/i;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/k/i;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/k/i$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/core/k/i;

    return-void
.end method


# virtual methods
.method public final a(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V
    .registers 16

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/i$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/core/k/i;

    move v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-wide v5, p5

    move-object v7, p7

    invoke-static/range {v0 .. v7}, Lcom/vdocipher/aegis/core/k/i;->$r8$lambda$yDhv8sffWQK6YDFWNKw5i6AEjOk(Lcom/vdocipher/aegis/core/k/i;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V

    return-void
.end method
