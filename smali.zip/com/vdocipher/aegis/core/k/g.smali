# classes14.dex

.class public final Lcom/vdocipher/aegis/core/k/g;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private a:[B

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:J

.field private e:J

.field private f:Ljava/lang/String;


# direct methods
.method public constructor <init>([BLjava/lang/String;Ljava/lang/String;JJLjava/lang/String;)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/k/g;->a:[B

    iput-object p2, p0, Lcom/vdocipher/aegis/core/k/g;->b:Ljava/lang/String;

    iput-object p3, p0, Lcom/vdocipher/aegis/core/k/g;->c:Ljava/lang/String;

    iput-wide p4, p0, Lcom/vdocipher/aegis/core/k/g;->d:J

    iput-wide p6, p0, Lcom/vdocipher/aegis/core/k/g;->e:J

    iput-object p8, p0, Lcom/vdocipher/aegis/core/k/g;->f:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/g;->b:Ljava/lang/String;

    return-object v0
.end method

.method public final b()[B
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/g;->a:[B

    return-object v0
.end method

.method public final c()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/g;->c:Ljava/lang/String;

    return-object v0
.end method
