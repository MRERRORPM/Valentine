# classes14.dex

.class public final Lcom/vdocipher/aegis/core/k/a;
.super Lcom/vdocipher/aegis/offline/DownloadOptions;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final d:Ljava/lang/String;

.field public final e:Ljava/lang/String;

.field public final f:Ljava/lang/String;

.field public final g:Ljava/lang/String;

.field public final h:Ljava/lang/String;

.field public final i:Ljava/util/List;

.field public final j:Ljava/util/List;

.field public final k:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/vdocipher/aegis/media/MediaInfo;[Lcom/vdocipher/aegis/media/Track;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)V
    .registers 14

    .line 1
    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/offline/DownloadOptions;-><init>(Ljava/lang/String;Lcom/vdocipher/aegis/media/MediaInfo;[Lcom/vdocipher/aegis/media/Track;)V

    .line 2
    iput-object p4, p0, Lcom/vdocipher/aegis/core/k/a;->a:Ljava/lang/String;

    .line 3
    iput-object p5, p0, Lcom/vdocipher/aegis/core/k/a;->b:Ljava/lang/String;

    .line 4
    iput-object p6, p0, Lcom/vdocipher/aegis/core/k/a;->c:Ljava/lang/String;

    .line 5
    iput-object p7, p0, Lcom/vdocipher/aegis/core/k/a;->e:Ljava/lang/String;

    .line 6
    iput-object p8, p0, Lcom/vdocipher/aegis/core/k/a;->f:Ljava/lang/String;

    .line 7
    iput-object p9, p0, Lcom/vdocipher/aegis/core/k/a;->g:Ljava/lang/String;

    .line 8
    iput-object p10, p0, Lcom/vdocipher/aegis/core/k/a;->i:Ljava/util/List;

    .line 9
    iput-object p11, p0, Lcom/vdocipher/aegis/core/k/a;->j:Ljava/util/List;

    .line 10
    iput-object p12, p0, Lcom/vdocipher/aegis/core/k/a;->h:Ljava/lang/String;

    .line 11
    iput-object p13, p0, Lcom/vdocipher/aegis/core/k/a;->k:Ljava/lang/String;

    .line 13
    const-string p1, ""

    iput-object p1, p0, Lcom/vdocipher/aegis/core/k/a;->d:Ljava/lang/String;

    return-void
.end method
