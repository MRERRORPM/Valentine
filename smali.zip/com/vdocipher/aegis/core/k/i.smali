# classes14.dex

.class public Lcom/vdocipher/aegis/core/k/i;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private a:Landroidx/media3/exoplayer/drm/OfflineLicenseHelper;

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;


# direct methods
.method public static synthetic $r8$lambda$PvlcbNKzjPKIOwvGj5c5rUnx1EA(Ljava/util/UUID;)Landroidx/media3/exoplayer/drm/ExoMediaDrm;
    .registers 1

    invoke-static {p0}, Lcom/vdocipher/aegis/core/k/i;->a(Ljava/util/UUID;)Landroidx/media3/exoplayer/drm/ExoMediaDrm;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$yDhv8sffWQK6YDFWNKw5i6AEjOk(Lcom/vdocipher/aegis/core/k/i;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V
    .registers 8

    invoke-direct/range {p0 .. p7}, Lcom/vdocipher/aegis/core/k/i;->a(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/vdocipher/aegis/core/z/f$a;Ljava/lang/String;Ljava/util/ArrayList;Ljava/lang/String;Lcom/vdocipher/aegis/core/q/b;ZLjava/lang/String;)V
    .registers 28

    move-object/from16 v1, p0

    move-object/from16 v0, p5

    .line 1
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    if-eqz v0, :cond_d

    const/4 v3, 0x1

    move v8, v3

    goto :goto_e

    :cond_d
    move v8, v2

    :goto_e
    const/4 v3, 0x0

    if-eqz v8, :cond_52

    .line 6
    :try_start_11
    invoke-static/range {p3 .. p3}, Lcom/vdocipher/aegis/core/k/i;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_15} :catch_47

    .line 10
    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 11
    const-string/jumbo v0, "token"

    invoke-virtual {v5, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 12
    invoke-static {v6}, Lcom/vdocipher/aegis/core/t/d;->i(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_37

    .line 14
    invoke-virtual {v5, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 15
    const-string/jumbo v6, "videoId"

    invoke-virtual {v5, v6}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 16
    invoke-static {v0, v5}, Lcom/vdocipher/aegis/player/VdoInitParams;->createParamsWithToken(Ljava/lang/String;Ljava/lang/String;)Lcom/vdocipher/aegis/player/VdoInitParams;

    move-result-object v0

    goto :goto_45

    .line 22
    :cond_37
    invoke-virtual {v5, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 23
    const-string v6, "playbackInfo"

    invoke-virtual {v5, v6}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 24
    invoke-static {v0, v5}, Lcom/vdocipher/aegis/player/VdoInitParams;->createParamsWithOtp(Ljava/lang/String;Ljava/lang/String;)Lcom/vdocipher/aegis/player/VdoInitParams;

    move-result-object v0

    :goto_45
    move-object v13, v4

    goto :goto_55

    :catch_47
    move-exception v0

    .line 25
    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_52
    move-object/from16 v13, p3

    move-object v0, v3

    .line 43
    :goto_55
    invoke-static/range {p1 .. p1}, Lcom/vdocipher/aegis/core/t/d;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    .line 45
    new-instance v4, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;

    invoke-direct {v4}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;-><init>()V

    move-object/from16 v5, p1

    invoke-virtual {v4, v5}, Lcom/vdocipher/aegis/analytics/internal/AppAnalytics;->f(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    .line 48
    :try_start_64
    new-instance v7, Landroidx/media3/exoplayer/drm/OfflineLicenseHelper;

    new-instance v9, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;

    invoke-direct {v9}, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;-><init>()V

    sget-object v10, Landroidx/media3/common/C;->WIDEVINE_UUID:Ljava/util/UUID;

    if-nez p7, :cond_72

    .line 50
    sget-object v11, Landroidx/media3/exoplayer/drm/FrameworkMediaDrm;->DEFAULT_PROVIDER:Landroidx/media3/exoplayer/drm/ExoMediaDrm$Provider;

    goto :goto_77

    :cond_72
    new-instance v11, Lcom/vdocipher/aegis/core/k/i$$ExternalSyntheticLambda0;

    invoke-direct {v11}, Lcom/vdocipher/aegis/core/k/i$$ExternalSyntheticLambda0;-><init>()V

    :goto_77
    invoke-virtual {v9, v10, v11}, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;->setUuidAndExoMediaDrmProvider(Ljava/util/UUID;Landroidx/media3/exoplayer/drm/ExoMediaDrm$Provider;)Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;

    move-result-object v9

    new-instance v10, Lcom/vdocipher/aegis/core/m/u$b;

    invoke-direct {v10}, Lcom/vdocipher/aegis/core/m/u$b;-><init>()V

    .line 59
    invoke-virtual {v9, v10}, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;->setLoadErrorHandlingPolicy(Landroidx/media3/exoplayer/upstream/LoadErrorHandlingPolicy;)Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;

    move-result-object v9

    .line 60
    invoke-virtual {v9, v3}, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;->setKeyRequestParameters(Ljava/util/Map;)Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;

    move-result-object v9

    new-instance v10, Lcom/vdocipher/aegis/core/m/u;

    if-eqz v0, :cond_8f

    .line 62
    iget-object v11, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->otp:Ljava/lang/String;

    goto :goto_90

    :cond_8f
    move-object v11, v3

    :goto_90
    if-eqz v0, :cond_94

    .line 63
    iget-object v3, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    :cond_94
    new-instance v15, Landroidx/media3/exoplayer/drm/HttpMediaDrmCallback;

    move-object/from16 v0, p2

    invoke-direct {v15, v13, v2, v0}, Landroidx/media3/exoplayer/drm/HttpMediaDrmCallback;-><init>(Ljava/lang/String;ZLandroidx/media3/datasource/DataSource$Factory;)V

    new-instance v0, Lcom/vdocipher/aegis/core/k/i$$ExternalSyntheticLambda1;

    invoke-direct {v0, v1}, Lcom/vdocipher/aegis/core/k/i$$ExternalSyntheticLambda1;-><init>(Lcom/vdocipher/aegis/core/k/i;)V

    new-instance v2, Lcom/vdocipher/aegis/core/p/a;

    invoke-direct {v2, v4}, Lcom/vdocipher/aegis/core/p/a;-><init>(Ljava/lang/String;)V

    move-object v4, v7

    const/4 v7, 0x0

    move-object v12, v9

    move-object v9, v11

    const/4 v11, 0x0

    move-object/from16 v14, p4

    move-object/from16 v18, p8

    move-object/from16 v16, v0

    move-object/from16 v17, v2

    move-object v0, v4

    move-object v4, v10

    move-object v2, v12

    move-object/from16 v12, p6

    move-object v10, v3

    invoke-direct/range {v4 .. v18}, Lcom/vdocipher/aegis/core/m/u;-><init>(Landroid/content/Context;Ljava/lang/String;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/q/b;Ljava/lang/String;Ljava/util/ArrayList;Landroidx/media3/exoplayer/drm/MediaDrmCallback;Lcom/vdocipher/aegis/core/m/u$d;Lcom/vdocipher/aegis/core/p/a;Ljava/lang/String;)V

    .line 64
    invoke-virtual {v2, v4}, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;->build(Landroidx/media3/exoplayer/drm/MediaDrmCallback;)Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager;

    move-result-object v2

    new-instance v3, Landroidx/media3/exoplayer/drm/DrmSessionEventListener$EventDispatcher;

    invoke-direct {v3}, Landroidx/media3/exoplayer/drm/DrmSessionEventListener$EventDispatcher;-><init>()V

    invoke-direct {v0, v2, v3}, Landroidx/media3/exoplayer/drm/OfflineLicenseHelper;-><init>(Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager;Landroidx/media3/exoplayer/drm/DrmSessionEventListener$EventDispatcher;)V

    iput-object v0, v1, Lcom/vdocipher/aegis/core/k/i;->a:Landroidx/media3/exoplayer/drm/OfflineLicenseHelper;
    :try_end_c9
    .catch Ljava/lang/Exception; {:try_start_64 .. :try_end_c9} :catch_ca

    return-void

    :catch_ca
    move-exception v0

    .line 89
    const-class v2, Lcom/vdocipher/aegis/core/k/i;

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method private static synthetic a(Ljava/util/UUID;)Landroidx/media3/exoplayer/drm/ExoMediaDrm;
    .registers 3

    .line 1
    :try_start_0
    sget-object p0, Landroidx/media3/common/C;->WIDEVINE_UUID:Ljava/util/UUID;

    invoke-static {p0}, Landroidx/media3/exoplayer/drm/FrameworkMediaDrm;->newInstance(Ljava/util/UUID;)Landroidx/media3/exoplayer/drm/FrameworkMediaDrm;

    move-result-object p0

    .line 2
    const-string v0, "securityLevel"

    const-string v1, "L3"

    invoke-virtual {p0, v0, v1}, Landroidx/media3/exoplayer/drm/FrameworkMediaDrm;->setPropertyString(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_d
    .catch Landroidx/media3/exoplayer/drm/UnsupportedDrmException; {:try_start_0 .. :try_end_d} :catch_e

    return-object p0

    .line 5
    :catch_e
    new-instance p0, Landroidx/media3/exoplayer/drm/DummyExoMediaDrm;

    invoke-direct {p0}, Landroidx/media3/exoplayer/drm/DummyExoMediaDrm;-><init>()V

    return-object p0
.end method

.method private static a(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    .line 20
    const-string v0, "/wv"

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    if-gez v0, :cond_9

    return-object p0

    :cond_9
    const/4 v1, 0x0

    .line 22
    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private synthetic a(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V
    .registers 8

    .line 6
    const-string p1, "metaData"

    const-string p2, "annotationCode"

    :try_start_4
    new-instance p3, Lorg/json/JSONObject;

    invoke-direct {p3, p4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 7
    invoke-virtual {p3, p2}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result p4

    if-eqz p4, :cond_15

    .line 8
    invoke-virtual {p3, p2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    iput-object p2, p0, Lcom/vdocipher/aegis/core/k/i;->b:Ljava/lang/String;

    .line 10
    :cond_15
    invoke-virtual {p3, p1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result p2

    if-eqz p2, :cond_25

    .line 11
    invoke-virtual {p3, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/k/i;->c:Ljava/lang/String;

    .line 13
    :cond_25
    iput-object p7, p0, Lcom/vdocipher/aegis/core/k/i;->d:Ljava/lang/String;
    :try_end_27
    .catch Lorg/json/JSONException; {:try_start_4 .. :try_end_27} :catch_28

    return-void

    :catch_28
    move-exception p1

    .line 15
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p2

    const-string p3, "OfflineLicenseDownloader"

    invoke-static {p3, p2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 16
    new-instance p2, Ljava/lang/IllegalArgumentException;

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V

    throw p2
.end method


# virtual methods
.method public a([B)Landroid/util/Pair;
    .registers 3

    .line 19
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/i;->a:Landroidx/media3/exoplayer/drm/OfflineLicenseHelper;

    invoke-virtual {v0, p1}, Landroidx/media3/exoplayer/drm/OfflineLicenseHelper;->getLicenseDurationRemainingSec([B)Landroid/util/Pair;

    move-result-object p1

    return-object p1
.end method

.method public a()Ljava/lang/String;
    .registers 2

    .line 18
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/i;->b:Ljava/lang/String;

    return-object v0
.end method

.method public a(Landroidx/media3/common/Format;)[B
    .registers 3

    .line 17
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/i;->a:Landroidx/media3/exoplayer/drm/OfflineLicenseHelper;

    invoke-virtual {v0, p1}, Landroidx/media3/exoplayer/drm/OfflineLicenseHelper;->downloadLicense(Landroidx/media3/common/Format;)[B

    move-result-object p1

    return-object p1
.end method

.method public b()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/i;->d:Ljava/lang/String;

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/i;->c:Ljava/lang/String;

    return-object v0
.end method

.method public d()V
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/i;->a:Landroidx/media3/exoplayer/drm/OfflineLicenseHelper;

    invoke-virtual {v0}, Landroidx/media3/exoplayer/drm/OfflineLicenseHelper;->release()V

    return-void
.end method
