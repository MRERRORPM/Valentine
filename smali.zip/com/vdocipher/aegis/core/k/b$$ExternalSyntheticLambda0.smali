# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/k/b;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/k/b;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/k/b;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/b$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/k/b;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/k/b;->$r8$lambda$di-duXkQnF7x93WZHLTDi2iVRJo(Lcom/vdocipher/aegis/core/k/b;)V

    return-void
.end method
