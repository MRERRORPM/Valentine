# classes14.dex

.class final Lcom/vdocipher/aegis/core/k/c$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/k/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# instance fields
.field final a:Ljava/lang/String;

.field final b:Ljava/lang/String;

.field final c:Ljava/lang/String;

.field final d:[Ljava/lang/String;

.field final e:Ljava/lang/String;

.field final f:Ljava/lang/String;

.field final g:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 8

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/k/c$a;->a:Ljava/lang/String;

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/k/c$a;->b:Ljava/lang/String;

    .line 4
    iput-object p3, p0, Lcom/vdocipher/aegis/core/k/c$a;->c:Ljava/lang/String;

    .line 5
    iput-object p4, p0, Lcom/vdocipher/aegis/core/k/c$a;->d:[Ljava/lang/String;

    .line 6
    iput-object p5, p0, Lcom/vdocipher/aegis/core/k/c$a;->e:Ljava/lang/String;

    .line 7
    iput-object p6, p0, Lcom/vdocipher/aegis/core/k/c$a;->f:Ljava/lang/String;

    .line 8
    iput-object p7, p0, Lcom/vdocipher/aegis/core/k/c$a;->g:Ljava/lang/String;

    return-void
.end method
