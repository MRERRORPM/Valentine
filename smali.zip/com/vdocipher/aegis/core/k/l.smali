# classes14.dex

.class public Lcom/vdocipher/aegis/core/k/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/media3/exoplayer/offline/DownloadHelper$Callback;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/core/k/l$a;
    }
.end annotation


# instance fields
.field private a:Ljava/lang/String;

.field private b:Lcom/vdocipher/aegis/core/k/l$a;

.field private c:Landroid/content/Context;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;Ljava/lang/String;Lcom/vdocipher/aegis/core/k/l$a;)V
    .registers 5

    .line 1
    iput-object p3, p0, Lcom/vdocipher/aegis/core/k/l;->b:Lcom/vdocipher/aegis/core/k/l$a;

    .line 2
    iput-object p2, p0, Lcom/vdocipher/aegis/core/k/l;->a:Ljava/lang/String;

    .line 3
    iput-object p1, p0, Lcom/vdocipher/aegis/core/k/l;->c:Landroid/content/Context;

    .line 5
    new-instance p3, Landroidx/media3/common/MediaItem$Builder;

    invoke-direct {p3}, Landroidx/media3/common/MediaItem$Builder;-><init>()V

    .line 6
    invoke-virtual {p3, p2}, Landroidx/media3/common/MediaItem$Builder;->setUri(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    move-result-object p2

    .line 7
    invoke-virtual {p2}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    move-result-object p2

    .line 10
    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/b;->a(Landroid/content/Context;)Landroidx/media3/exoplayer/RenderersFactory;

    move-result-object p3

    .line 12
    invoke-static {p1}, Lcom/vdocipher/aegis/core/j/b;->n(Landroid/content/Context;)Lcom/vdocipher/aegis/core/z/f$a;

    move-result-object v0

    invoke-static {p1, p2, p3, v0}, Landroidx/media3/exoplayer/offline/DownloadHelper;->forMediaItem(Landroid/content/Context;Landroidx/media3/common/MediaItem;Landroidx/media3/exoplayer/RenderersFactory;Landroidx/media3/datasource/DataSource$Factory;)Landroidx/media3/exoplayer/offline/DownloadHelper;

    move-result-object p1

    .line 14
    invoke-virtual {p1, p0}, Landroidx/media3/exoplayer/offline/DownloadHelper;->prepare(Landroidx/media3/exoplayer/offline/DownloadHelper$Callback;)V

    return-void
.end method

.method public onPrepareError(Landroidx/media3/exoplayer/offline/DownloadHelper;Ljava/io/IOException;)V
    .registers 4

    .line 1
    instance-of p1, p2, Landroidx/media3/exoplayer/offline/DownloadHelper$LiveContentUnsupportedException;

    if-eqz p1, :cond_7

    .line 3
    const-string p1, "Downloading live content unsupported"

    goto :goto_9

    :cond_7
    const-string p1, "Failed to start download"

    .line 4
    :goto_9
    const-string v0, "VdoTrackExtractor"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    iget-object p1, p0, Lcom/vdocipher/aegis/core/k/l;->b:Lcom/vdocipher/aegis/core/k/l$a;

    invoke-interface {p1, p2}, Lcom/vdocipher/aegis/core/k/l$a;->a(Ljava/io/IOException;)V

    return-void
.end method

.method public onPrepared(Landroidx/media3/exoplayer/offline/DownloadHelper;Z)V
    .registers 13

    .line 1
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    const/4 v0, 0x0

    .line 4
    invoke-virtual {p1, v0}, Landroidx/media3/exoplayer/offline/DownloadHelper;->getTracks(I)Landroidx/media3/common/Tracks;

    move-result-object p1

    invoke-virtual {p1}, Landroidx/media3/common/Tracks;->getGroups()Lcom/google/common/collect/ImmutableList;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/common/collect/ImmutableList;->iterator()Lcom/google/common/collect/UnmodifiableIterator;

    move-result-object p1

    move v1, v0

    :goto_13
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5c

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/media3/common/Tracks$Group;

    .line 5
    invoke-virtual {v2}, Landroidx/media3/common/Tracks$Group;->getMediaTrackGroup()Landroidx/media3/common/TrackGroup;

    move-result-object v3

    .line 6
    invoke-virtual {v2}, Landroidx/media3/common/Tracks$Group;->getType()I

    move-result v2

    .line 8
    iget-object v4, v3, Landroidx/media3/common/TrackGroup;->id:Ljava/lang/String;

    move v5, v0

    .line 10
    :goto_2a
    iget v6, v3, Landroidx/media3/common/TrackGroup;->length:I

    if-ge v5, v6, :cond_59

    .line 12
    invoke-virtual {v3, v5}, Landroidx/media3/common/TrackGroup;->getFormat(I)Landroidx/media3/common/Format;

    move-result-object v6

    const/4 v7, 0x3

    if-ne v2, v7, :cond_3a

    .line 15
    iget-object v7, v6, Landroidx/media3/common/Format;->label:Ljava/lang/String;

    if-nez v7, :cond_3a

    goto :goto_56

    :cond_3a
    const/4 v7, 0x2

    if-ne v2, v7, :cond_42

    .line 18
    iget v8, v6, Landroidx/media3/common/Format;->bitrate:I

    if-gtz v8, :cond_42

    goto :goto_56

    .line 22
    :cond_42
    invoke-static {v1, v4, v5, v2, v6}, Lcom/vdocipher/aegis/core/t/d;->a(ILjava/lang/String;IILandroidx/media3/common/Format;)Lcom/vdocipher/aegis/media/Track;

    move-result-object v8

    if-ne v2, v7, :cond_53

    .line 26
    sget-object v7, Lcom/vdocipher/aegis/core/z/d;->a:Lcom/vdocipher/aegis/core/z/d;

    iget-object v9, p0, Lcom/vdocipher/aegis/core/k/l;->c:Landroid/content/Context;

    invoke-virtual {v7, v9, v6}, Lcom/vdocipher/aegis/core/z/d;->a(Landroid/content/Context;Landroidx/media3/common/Format;)Z

    move-result v6

    if-nez v6, :cond_53

    goto :goto_56

    .line 30
    :cond_53
    invoke-interface {p2, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_56
    add-int/lit8 v5, v5, 0x1

    goto :goto_2a

    :cond_59
    add-int/lit8 v1, v1, 0x1

    goto :goto_13

    .line 35
    :cond_5c
    new-instance p1, Lcom/vdocipher/aegis/core/k/j;

    new-array v0, v0, [Lcom/vdocipher/aegis/media/Track;

    invoke-interface {p2, v0}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p2

    check-cast p2, [Lcom/vdocipher/aegis/media/Track;

    invoke-direct {p1, p2}, Lcom/vdocipher/aegis/core/k/j;-><init>([Lcom/vdocipher/aegis/media/Track;)V

    .line 36
    iget-object p2, p0, Lcom/vdocipher/aegis/core/k/l;->b:Lcom/vdocipher/aegis/core/k/l$a;

    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/l;->a:Ljava/lang/String;

    invoke-interface {p2, v0, p1}, Lcom/vdocipher/aegis/core/k/l$a;->a(Ljava/lang/String;Lcom/vdocipher/aegis/core/k/j;)V

    return-void
.end method
