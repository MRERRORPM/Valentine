# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/k/c$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/k/c;

.field public final synthetic f$1:Ljava/lang/Throwable;

.field public final synthetic f$2:Ljava/lang/String;

.field public final synthetic f$3:Z


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/k/c;Ljava/lang/Throwable;Ljava/lang/String;Z)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/k/c$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/k/c;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/k/c$$ExternalSyntheticLambda0;->f$1:Ljava/lang/Throwable;

    iput-object p3, p0, Lcom/vdocipher/aegis/core/k/c$$ExternalSyntheticLambda0;->f$2:Ljava/lang/String;

    iput-boolean p4, p0, Lcom/vdocipher/aegis/core/k/c$$ExternalSyntheticLambda0;->f$3:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/c$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/k/c;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/k/c$$ExternalSyntheticLambda0;->f$1:Ljava/lang/Throwable;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/k/c$$ExternalSyntheticLambda0;->f$2:Ljava/lang/String;

    iget-boolean v3, p0, Lcom/vdocipher/aegis/core/k/c$$ExternalSyntheticLambda0;->f$3:Z

    invoke-static {v0, v1, v2, v3}, Lcom/vdocipher/aegis/core/k/c;->$r8$lambda$uhXWltjGNOXwHZq0KTnyLMltbEM(Lcom/vdocipher/aegis/core/k/c;Ljava/lang/Throwable;Ljava/lang/String;Z)V

    return-void
.end method
