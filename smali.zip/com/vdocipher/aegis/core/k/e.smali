# classes14.dex

.class public Lcom/vdocipher/aegis/core/k/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Lcom/vdocipher/aegis/core/k/d;

.field private c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/vdocipher/aegis/core/k/d;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/k/e;->b:Lcom/vdocipher/aegis/core/k/d;

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/k/e;->a:Ljava/lang/String;

    .line 4
    iput-object p3, p0, Lcom/vdocipher/aegis/core/k/e;->c:Ljava/lang/String;

    return-void
.end method

.method private a()Ljava/lang/String;
    .registers 9

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/e;->b:Lcom/vdocipher/aegis/core/k/d;

    const-string v1, "dss.pos"

    invoke-virtual {v0, v1}, Lcom/vdocipher/aegis/core/k/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-static {v0}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_10

    return-object v2

    .line 4
    :cond_10
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 7
    invoke-virtual {v1}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v0

    const/4 v3, -0x1

    move-object v4, v2

    .line 8
    :cond_1b
    :goto_1b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_39

    .line 9
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 10
    const-string v6, "_"

    invoke-virtual {v5, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x1

    aget-object v6, v6, v7

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    if-le v6, v3, :cond_1b

    move-object v4, v5

    move v3, v6

    goto :goto_1b

    :cond_39
    if-eqz v4, :cond_40

    .line 17
    invoke-virtual {v1, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_40
    return-object v2
.end method

.method private b()[I
    .registers 5

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/k/e;->b:Lcom/vdocipher/aegis/core/k/d;

    const-string v1, "dss.dlopts"

    invoke-virtual {v0, v1}, Lcom/vdocipher/aegis/core/k/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-static {v0}, Lcom/vdocipher/aegis/core/t/d;->g(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_31

    .line 4
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string/jumbo v0, "tids"

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    .line 6
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v1

    new-array v1, v1, [I

    const/4 v2, 0x0

    .line 7
    :goto_21
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v2, v3, :cond_30

    .line 8
    invoke-virtual {v0, v2}, Lorg/json/JSONArray;->getInt(I)I

    move-result v3

    aput v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_21

    :cond_30
    return-object v1

    .line 9
    :cond_31
    new-instance v0, Lorg/json/JSONException;

    const-string v1, "empty options"

    invoke-direct {v0, v1}, Lorg/json/JSONException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public c()Lcom/vdocipher/aegis/core/k/k;
    .registers 29

    move-object/from16 v0, p0

    .line 1
    iget-object v1, v0, Lcom/vdocipher/aegis/core/k/e;->b:Lcom/vdocipher/aegis/core/k/d;

    const-string v2, "dss.type"

    invoke-virtual {v1, v2}, Lcom/vdocipher/aegis/core/k/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 2
    iget-object v1, v0, Lcom/vdocipher/aegis/core/k/e;->b:Lcom/vdocipher/aegis/core/k/d;

    const-string v2, "dss.language"

    invoke-virtual {v1, v2}, Lcom/vdocipher/aegis/core/k/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    .line 3
    iget-object v1, v0, Lcom/vdocipher/aegis/core/k/e;->b:Lcom/vdocipher/aegis/core/k/d;

    const-string v2, "dss.loc"

    invoke-virtual {v1, v2}, Lcom/vdocipher/aegis/core/k/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 4
    iget-object v1, v0, Lcom/vdocipher/aegis/core/k/e;->b:Lcom/vdocipher/aegis/core/k/d;

    const-string v2, "dss.manf"

    invoke-virtual {v1, v2}, Lcom/vdocipher/aegis/core/k/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 5
    iget-object v1, v0, Lcom/vdocipher/aegis/core/k/e;->b:Lcom/vdocipher/aegis/core/k/d;

    const-string v2, "dss.lic"

    invoke-virtual {v1, v2}, Lcom/vdocipher/aegis/core/k/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 6
    iget-object v1, v0, Lcom/vdocipher/aegis/core/k/e;->b:Lcom/vdocipher/aegis/core/k/d;

    const-string v2, "dss.fbservers"

    invoke-virtual {v1, v2}, Lcom/vdocipher/aegis/core/k/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 7
    invoke-static {v1}, Lcom/vdocipher/aegis/core/t/d;->d(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v9

    .line 8
    iget-object v1, v0, Lcom/vdocipher/aegis/core/k/e;->b:Lcom/vdocipher/aegis/core/k/d;

    const-string v2, "dss.lictokenparams"

    invoke-virtual {v1, v2}, Lcom/vdocipher/aegis/core/k/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 9
    iget-object v1, v0, Lcom/vdocipher/aegis/core/k/e;->b:Lcom/vdocipher/aegis/core/k/d;

    const-string v2, "dss.meta"

    invoke-virtual {v1, v2}, Lcom/vdocipher/aegis/core/k/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 10
    invoke-static {v7}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object v14

    .line 11
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ".ori"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    .line 13
    new-instance v1, Lcom/vdocipher/aegis/core/f/g;

    invoke-direct {v1, v6}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    .line 14
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/f/g;->r()Ljava/lang/String;

    move-result-object v24

    .line 15
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/f/g;->c()Ljava/lang/String;

    move-result-object v25

    .line 16
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/f/g;->e()J

    move-result-wide v26

    .line 17
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/f/g;->f()Z

    move-result v2

    .line 18
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/f/g;->i()Ljava/lang/String;

    move-result-object v18

    .line 19
    new-instance v16, Lcom/vdocipher/aegis/media/MediaInfo;

    iget-object v3, v0, Lcom/vdocipher/aegis/core/k/e;->a:Ljava/lang/String;

    const/16 v22, 0x3

    move-object/from16 v23, v3

    move-object/from16 v21, v16

    invoke-direct/range {v21 .. v27}, Lcom/vdocipher/aegis/media/MediaInfo;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    .line 21
    invoke-direct {v0}, Lcom/vdocipher/aegis/core/k/e;->b()[I

    move-result-object v17

    .line 25
    invoke-direct {v0}, Lcom/vdocipher/aegis/core/k/e;->a()Ljava/lang/String;

    move-result-object v11

    if-eqz v11, :cond_98

    .line 29
    invoke-static {v11}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v3}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object v3

    goto :goto_99

    :cond_98
    const/4 v3, 0x0

    :goto_99
    move-object v13, v3

    .line 35
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/f/g;->a()Z

    move-result v1

    if-nez v1, :cond_a4

    .line 36
    const-string v1, ""

    iput-object v1, v0, Lcom/vdocipher/aegis/core/k/e;->c:Ljava/lang/String;

    .line 39
    :cond_a4
    new-instance v3, Lcom/vdocipher/aegis/core/k/k;

    iget-object v4, v0, Lcom/vdocipher/aegis/core/k/e;->a:Ljava/lang/String;

    iget-object v1, v0, Lcom/vdocipher/aegis/core/k/e;->c:Ljava/lang/String;

    move-object/from16 v19, v1

    move/from16 v21, v2

    invoke-direct/range {v3 .. v21}, Lcom/vdocipher/aegis/core/k/k;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/media/MediaInfo;[ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-object v3
.end method
