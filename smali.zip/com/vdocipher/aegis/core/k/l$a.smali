# classes14.dex

.class interface abstract Lcom/vdocipher/aegis/core/k/l$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/k/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "a"
.end annotation


# virtual methods
.method public abstract a(Ljava/io/IOException;)V
.end method

.method public abstract a(Ljava/lang/String;Lcom/vdocipher/aegis/core/k/j;)V
.end method
