# classes14.dex

.class Lcom/vdocipher/aegis/core/c/b$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/vdocipher/aegis/core/c/b;->a(Ljava/lang/String;Ljava/lang/Object;Lcom/vdocipher/aegis/core/c/b$d;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/c/b;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/c/b;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/c/b$a;->a:Lcom/vdocipher/aegis/core/c/b;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    .line 1
    :try_start_0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/c/b$a;->a:Lcom/vdocipher/aegis/core/c/b;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/c/b;->a(Lcom/vdocipher/aegis/core/c/b;)V
    :try_end_5
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_5} :catch_6

    return-void

    :catch_6
    move-exception v0

    .line 3
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "MF"

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 4
    iget-object v1, p0, Lcom/vdocipher/aegis/core/c/b$a;->a:Lcom/vdocipher/aegis/core/c/b;

    const/4 v2, -0x1

    const/4 v3, 0x0

    invoke-static {v1, v2, v3, v0}, Lcom/vdocipher/aegis/core/c/b;->a(Lcom/vdocipher/aegis/core/c/b;ILjava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
