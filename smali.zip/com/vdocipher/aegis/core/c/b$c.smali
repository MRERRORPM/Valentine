# classes14.dex

.class Lcom/vdocipher/aegis/core/c/b$c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/vdocipher/aegis/core/c/b;->a(ILjava/lang/String;Ljava/lang/Throwable;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Ljava/lang/Throwable;

.field final synthetic d:Lcom/vdocipher/aegis/core/c/b;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/c/b;ILjava/lang/String;Ljava/lang/Throwable;)V
    .registers 5

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/c/b$c;->d:Lcom/vdocipher/aegis/core/c/b;

    iput p2, p0, Lcom/vdocipher/aegis/core/c/b$c;->a:I

    iput-object p3, p0, Lcom/vdocipher/aegis/core/c/b$c;->b:Ljava/lang/String;

    iput-object p4, p0, Lcom/vdocipher/aegis/core/c/b$c;->c:Ljava/lang/Throwable;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 7

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/c/b$c;->d:Lcom/vdocipher/aegis/core/c/b;

    monitor-enter v0

    .line 2
    :try_start_3
    iget-object v1, p0, Lcom/vdocipher/aegis/core/c/b$c;->d:Lcom/vdocipher/aegis/core/c/b;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/c/b;->b(Lcom/vdocipher/aegis/core/c/b;)Lcom/vdocipher/aegis/core/c/b$d;

    move-result-object v1

    if-eqz v1, :cond_20

    iget-object v1, p0, Lcom/vdocipher/aegis/core/c/b$c;->d:Lcom/vdocipher/aegis/core/c/b;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/c/b;->b(Lcom/vdocipher/aegis/core/c/b;)Lcom/vdocipher/aegis/core/c/b$d;

    move-result-object v1

    iget-object v2, p0, Lcom/vdocipher/aegis/core/c/b$c;->d:Lcom/vdocipher/aegis/core/c/b;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/c/b;->c(Lcom/vdocipher/aegis/core/c/b;)Ljava/lang/Object;

    move-result-object v2

    iget v3, p0, Lcom/vdocipher/aegis/core/c/b$c;->a:I

    iget-object v4, p0, Lcom/vdocipher/aegis/core/c/b$c;->b:Ljava/lang/String;

    iget-object v5, p0, Lcom/vdocipher/aegis/core/c/b$c;->c:Ljava/lang/Throwable;

    invoke-interface {v1, v2, v3, v4, v5}, Lcom/vdocipher/aegis/core/c/b$d;->a(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Throwable;)V

    .line 3
    :cond_20
    monitor-exit v0

    return-void

    :catchall_22
    move-exception v1

    monitor-exit v0
    :try_end_24
    .catchall {:try_start_3 .. :try_end_24} :catchall_22

    throw v1
.end method
