# classes14.dex

.class Lcom/vdocipher/aegis/core/c/b$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/vdocipher/aegis/core/c/b;->a(ILjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lcom/vdocipher/aegis/core/c/b;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/c/b;ILjava/lang/String;)V
    .registers 4

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/c/b$b;->c:Lcom/vdocipher/aegis/core/c/b;

    iput p2, p0, Lcom/vdocipher/aegis/core/c/b$b;->a:I

    iput-object p3, p0, Lcom/vdocipher/aegis/core/c/b$b;->b:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/c/b$b;->c:Lcom/vdocipher/aegis/core/c/b;

    monitor-enter v0

    .line 2
    :try_start_3
    iget-object v1, p0, Lcom/vdocipher/aegis/core/c/b$b;->c:Lcom/vdocipher/aegis/core/c/b;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/c/b;->b(Lcom/vdocipher/aegis/core/c/b;)Lcom/vdocipher/aegis/core/c/b$d;

    move-result-object v1

    if-eqz v1, :cond_1e

    iget-object v1, p0, Lcom/vdocipher/aegis/core/c/b$b;->c:Lcom/vdocipher/aegis/core/c/b;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/c/b;->b(Lcom/vdocipher/aegis/core/c/b;)Lcom/vdocipher/aegis/core/c/b$d;

    move-result-object v1

    iget-object v2, p0, Lcom/vdocipher/aegis/core/c/b$b;->c:Lcom/vdocipher/aegis/core/c/b;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/c/b;->c(Lcom/vdocipher/aegis/core/c/b;)Ljava/lang/Object;

    move-result-object v2

    iget v3, p0, Lcom/vdocipher/aegis/core/c/b$b;->a:I

    iget-object v4, p0, Lcom/vdocipher/aegis/core/c/b$b;->b:Ljava/lang/String;

    invoke-interface {v1, v2, v3, v4}, Lcom/vdocipher/aegis/core/c/b$d;->a(Ljava/lang/Object;ILjava/lang/String;)V

    .line 3
    :cond_1e
    monitor-exit v0

    return-void

    :catchall_20
    move-exception v1

    monitor-exit v0
    :try_end_22
    .catchall {:try_start_3 .. :try_end_22} :catchall_20

    throw v1
.end method
