# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ljava/lang/Exception;

.field public final synthetic f$1:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Exception;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda0;->f$0:Ljava/lang/Exception;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda0;->f$1:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda0;->f$0:Ljava/lang/Exception;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda0;->f$1:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/c/a;->$r8$lambda$17xJ0p373edvoPs5HePzq2jkJ4w(Ljava/lang/Exception;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V

    return-void
.end method
