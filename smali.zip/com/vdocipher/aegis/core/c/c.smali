# classes14.dex

.class public abstract Lcom/vdocipher/aegis/core/c/c;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Ljava/lang/String;Lcom/vdocipher/aegis/player/VdoInitParams;)Lcom/vdocipher/aegis/media/MediaInfo;
    .registers 9

    .line 22
    iget-object p1, p1, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    invoke-static {p1}, Lcom/vdocipher/aegis/core/c/c;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 23
    new-instance p1, Lcom/vdocipher/aegis/core/f/g;

    invoke-direct {p1, p0}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    .line 24
    new-instance v0, Lcom/vdocipher/aegis/media/MediaInfo;

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->r()Ljava/lang/String;

    move-result-object v3

    .line 25
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->c()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->e()J

    move-result-wide v5

    const/4 v1, 0x1

    invoke-direct/range {v0 .. v6}, Lcom/vdocipher/aegis/media/MediaInfo;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    return-object v0
.end method

.method public static a(Lcom/vdocipher/aegis/player/VdoInitParams;)Ljava/lang/String;
    .registers 4

    .line 3
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 4
    iget-object v1, p0, Lcom/vdocipher/aegis/player/VdoInitParams;->token:Ljava/lang/String;

    if-eqz v1, :cond_18

    invoke-static {v1}, Lcom/vdocipher/aegis/core/t/d;->i(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_18

    .line 5
    iget-object v1, p0, Lcom/vdocipher/aegis/player/VdoInitParams;->token:Ljava/lang/String;

    const-string/jumbo v2, "token"

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_21

    .line 6
    :cond_18
    iget-object v1, p0, Lcom/vdocipher/aegis/player/VdoInitParams;->token:Ljava/lang/String;

    if-eqz v1, :cond_39

    .line 7
    const-string v2, "otp"

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 11
    :goto_21
    iget-object p0, p0, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    const-string v1, "playbackInfo"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 14
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "UTF-8"

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0

    const/16 v0, 0xa

    invoke-static {p0, v0}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 15
    :cond_39
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p0
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    if-eqz p0, :cond_21

    .line 16
    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_21

    .line 20
    new-instance v0, Lorg/json/JSONObject;

    new-instance v1, Ljava/lang/String;

    const/4 v2, 0x0

    invoke-static {p0, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p0

    const-string v2, "UTF-8"

    invoke-direct {v1, p0, v2}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string/jumbo p0, "videoId"

    invoke-virtual {v0, p0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 21
    :cond_21
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p0
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    if-eqz p0, :cond_10

    if-eqz p1, :cond_10

    .line 1
    const-string v0, ":authToken"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_10

    .line 2
    invoke-virtual {p0, v0, p1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    :cond_10
    return-object p0
.end method
