# classes14.dex

.class public interface abstract Lcom/vdocipher/aegis/core/c/b$d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/c/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/Object;ILjava/lang/String;)V
.end method

.method public abstract a(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Throwable;)V
.end method
