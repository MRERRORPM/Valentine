# classes14.dex

.class public final Lcom/vdocipher/aegis/core/c/b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/core/c/b$d;
    }
.end annotation


# instance fields
.field private final a:Landroid/os/HandlerThread;

.field private final b:Landroid/os/Handler;

.field private c:Landroid/os/Handler;

.field private d:Ljava/lang/Object;

.field private e:Ljava/lang/String;

.field private f:Lcom/vdocipher/aegis/core/c/b$d;


# direct methods
.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lcom/vdocipher/aegis/core/c/b;->f:Lcom/vdocipher/aegis/core/c/b$d;

    .line 5
    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "MF"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/c/b;->a:Landroid/os/HandlerThread;

    .line 6
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 7
    new-instance v1, Landroid/os/Handler;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {v1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v1, p0, Lcom/vdocipher/aegis/core/c/b;->b:Landroid/os/Handler;

    return-void
.end method

.method private a()V
    .registers 9

    .line 8
    const-string v0, "MF"

    const-string v1, "\n"

    .line 0
    const-string v2, "error: "

    const/4 v3, 0x0

    .line 8
    :try_start_7
    new-instance v4, Ljava/net/URL;

    iget-object v5, p0, Lcom/vdocipher/aegis/core/c/b;->e:Ljava/lang/String;

    invoke-direct {v4, v5}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 9
    new-instance v5, Lcom/vdocipher/aegis/core/g/b;

    invoke-direct {v5}, Lcom/vdocipher/aegis/core/g/b;-><init>()V

    .line 10
    invoke-virtual {v5, v4}, Lcom/vdocipher/aegis/core/g/b;->a(Ljava/net/URL;)Lcom/vdocipher/aegis/core/i/a;

    move-result-object v4

    .line 11
    invoke-virtual {v4}, Lcom/vdocipher/aegis/core/i/a;->b()I

    move-result v5

    const/16 v6, 0xc8

    if-ne v5, v6, :cond_27

    .line 13
    invoke-virtual {v4}, Lcom/vdocipher/aegis/core/i/a;->a()Ljava/lang/String;

    move-result-object v4

    invoke-direct {p0, v5, v4}, Lcom/vdocipher/aegis/core/c/b;->a(ILjava/lang/String;)V

    return-void

    .line 15
    :cond_27
    invoke-virtual {v4}, Lcom/vdocipher/aegis/core/i/a;->d()Ljava/lang/Exception;

    move-result-object v6

    if-eqz v6, :cond_4a

    .line 17
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v6}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v0, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 18
    invoke-direct {p0, v5, v3, v6}, Lcom/vdocipher/aegis/core/c/b;->a(ILjava/lang/String;Ljava/lang/Throwable;)V

    return-void

    .line 20
    :cond_4a
    invoke-virtual {v4}, Lcom/vdocipher/aegis/core/i/a;->c()Ljava/lang/String;

    move-result-object v4

    invoke-direct {p0, v5, v4, v3}, Lcom/vdocipher/aegis/core/c/b;->a(ILjava/lang/String;Ljava/lang/Throwable;)V
    :try_end_51
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_51} :catch_52

    return-void

    :catch_52
    move-exception v4

    .line 24
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v4}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, -0x1

    .line 25
    invoke-direct {p0, v0, v3, v4}, Lcom/vdocipher/aegis/core/c/b;->a(ILjava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method

.method private a(ILjava/lang/String;)V
    .registers 5

    .line 26
    iget-object v0, p0, Lcom/vdocipher/aegis/core/c/b;->c:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/c/b$b;

    invoke-direct {v1, p0, p1, p2}, Lcom/vdocipher/aegis/core/c/b$b;-><init>(Lcom/vdocipher/aegis/core/c/b;ILjava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private a(ILjava/lang/String;Ljava/lang/Throwable;)V
    .registers 6

    .line 27
    iget-object v0, p0, Lcom/vdocipher/aegis/core/c/b;->c:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/c/b$c;

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/c/b$c;-><init>(Lcom/vdocipher/aegis/core/c/b;ILjava/lang/String;Ljava/lang/Throwable;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/c/b;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/c/b;->a()V

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/c/b;ILjava/lang/String;Ljava/lang/Throwable;)V
    .registers 4

    .line 2
    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/c/b;->a(ILjava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method

.method static synthetic b(Lcom/vdocipher/aegis/core/c/b;)Lcom/vdocipher/aegis/core/c/b$d;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/c/b;->f:Lcom/vdocipher/aegis/core/c/b$d;

    return-object p0
.end method

.method static synthetic c(Lcom/vdocipher/aegis/core/c/b;)Ljava/lang/Object;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/core/c/b;->d:Ljava/lang/Object;

    return-object p0
.end method


# virtual methods
.method public declared-synchronized a(Ljava/lang/String;Ljava/lang/Object;Lcom/vdocipher/aegis/core/c/b$d;)V
    .registers 6

    monitor-enter p0

    .line 3
    :try_start_1
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/c/b;->c:Landroid/os/Handler;

    .line 4
    iput-object p1, p0, Lcom/vdocipher/aegis/core/c/b;->e:Ljava/lang/String;

    .line 5
    iput-object p2, p0, Lcom/vdocipher/aegis/core/c/b;->d:Ljava/lang/Object;

    .line 6
    iput-object p3, p0, Lcom/vdocipher/aegis/core/c/b;->f:Lcom/vdocipher/aegis/core/c/b$d;

    .line 7
    iget-object p1, p0, Lcom/vdocipher/aegis/core/c/b;->b:Landroid/os/Handler;

    new-instance p2, Lcom/vdocipher/aegis/core/c/b$a;

    invoke-direct {p2, p0}, Lcom/vdocipher/aegis/core/c/b$a;-><init>(Lcom/vdocipher/aegis/core/c/b;)V

    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_1c
    .catchall {:try_start_1 .. :try_end_1c} :catchall_1e

    monitor-exit p0

    return-void

    :catchall_1e
    move-exception p1

    :try_start_1f
    monitor-exit p0
    :try_end_20
    .catchall {:try_start_1f .. :try_end_20} :catchall_1e

    throw p1
.end method

.method public declared-synchronized b()V
    .registers 2

    monitor-enter p0

    const/4 v0, 0x0

    .line 2
    :try_start_2
    iput-object v0, p0, Lcom/vdocipher/aegis/core/c/b;->f:Lcom/vdocipher/aegis/core/c/b$d;

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/core/c/b;->a:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->quit()Z
    :try_end_9
    .catchall {:try_start_2 .. :try_end_9} :catchall_b

    monitor-exit p0

    return-void

    :catchall_b
    move-exception v0

    :try_start_c
    monitor-exit p0
    :try_end_d
    .catchall {:try_start_c .. :try_end_d} :catchall_b

    throw v0
.end method
