# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/c/a;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Ljava/lang/String;

.field public final synthetic f$3:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/c/a;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/c/a;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda2;->f$1:Ljava/lang/String;

    iput-object p3, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda2;->f$2:Ljava/lang/String;

    iput-object p4, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda2;->f$3:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/c/a;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda2;->f$1:Ljava/lang/String;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda2;->f$2:Ljava/lang/String;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda2;->f$3:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;

    invoke-static {v0, v1, v2, v3}, Lcom/vdocipher/aegis/core/c/a;->$r8$lambda$jtWUSpqX8p3sU7brajVdrqGkVPI(Lcom/vdocipher/aegis/core/c/a;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V

    return-void
.end method
