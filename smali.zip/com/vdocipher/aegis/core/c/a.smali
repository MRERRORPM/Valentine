# classes14.dex

.class public final Lcom/vdocipher/aegis/core/c/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private a:Ljava/lang/String;

.field private final b:Ljava/util/concurrent/ConcurrentHashMap;


# direct methods
.method public static synthetic $r8$lambda$-f8JOo9qOfbAdE7Xhg__SxnisRY(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/util/List;)V
    .registers 2

    invoke-static {p0, p1}, Lcom/vdocipher/aegis/core/c/a;->a(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/util/List;)V

    return-void
.end method

.method public static synthetic $r8$lambda$17xJ0p373edvoPs5HePzq2jkJ4w(Ljava/lang/Exception;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V
    .registers 2

    invoke-static {p0, p1}, Lcom/vdocipher/aegis/core/c/a;->a(Ljava/lang/Exception;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V

    return-void
.end method

.method public static synthetic $r8$lambda$jtWUSpqX8p3sU7brajVdrqGkVPI(Lcom/vdocipher/aegis/core/c/a;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/c/a;->a(Lcom/vdocipher/aegis/core/c/a;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    const-string v0, "Caption Search"

    iput-object v0, p0, Lcom/vdocipher/aegis/core/c/a;->a:Ljava/lang/String;

    .line 4
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/c/a;->b:Ljava/util/concurrent/ConcurrentHashMap;

    return-void
.end method

.method private static final a(Lcom/vdocipher/aegis/core/c/a;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V
    .registers 11

    const-string v0, "file://"

    .line 140
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 144
    iget-object v2, p0, Lcom/vdocipher/aegis/core/c/a;->b:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v2, p1}, Ljava/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const-string v3, "getCues(...)"

    const/4 v4, 0x0

    if-nez v2, :cond_82

    .line 146
    :try_start_12
    const-string v2, "https://"

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {p1, v2, v4, v6, v5}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_36

    const-string v2, "http://"

    invoke-static {p1, v2, v4, v6, v5}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_36

    .line 147
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 148
    new-instance v2, Ljava/net/URL;

    invoke-direct {v2, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    goto :goto_3b

    .line 149
    :cond_36
    new-instance v2, Ljava/net/URL;

    invoke-direct {v2, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 150
    :goto_3b
    invoke-virtual {v2}, Ljava/net/URL;->openStream()Ljava/io/InputStream;

    move-result-object v0

    .line 151
    new-instance v2, Lcom/vdocipher/aegis/player/internal/subtitle/a;

    invoke-direct {v2}, Lcom/vdocipher/aegis/player/internal/subtitle/a;-><init>()V

    .line 152
    invoke-virtual {v2, v0}, Lcom/vdocipher/aegis/player/internal/subtitle/a;->a(Ljava/io/InputStream;)Lcom/vdocipher/aegis/core/s/a;

    move-result-object v0
    :try_end_48
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_48} :catch_58

    .line 174
    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/s/a;->a()Ljava/util/List;

    move-result-object v2

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v1, v2}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 177
    iget-object p0, p0, Lcom/vdocipher/aegis/core/c/a;->b:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-interface {p0, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_9f

    :catch_58
    move-exception p1

    .line 178
    iget-object p0, p0, Lcom/vdocipher/aegis/core/c/a;->a:Ljava/lang/String;

    .line 179
    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Subtitle parser failed with msg:"

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 180
    invoke-static {p0, p2}, Lcom/vdocipher/aegis/core/t/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 185
    new-instance p0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p2

    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance p2, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda0;

    invoke-direct {p2, p1, p3}, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda0;-><init>(Ljava/lang/Exception;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V

    invoke-virtual {p0, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 207
    :cond_82
    iget-object v0, p0, Lcom/vdocipher/aegis/core/c/a;->b:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_9f

    .line 208
    iget-object p0, p0, Lcom/vdocipher/aegis/core/c/a;->b:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {p0, p1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast p0, Lcom/vdocipher/aegis/core/s/a;

    .line 209
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/s/a;->a()Ljava/util/List;

    move-result-object p0

    invoke-static {p0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v1, p0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 215
    :cond_9f
    :goto_9f
    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    .line 216
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p1

    :cond_a8
    :goto_a8
    if-ge v4, p1, :cond_c6

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    add-int/lit8 v4, v4, 0x1

    check-cast v0, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleCue;

    .line 217
    invoke-virtual {v0}, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleCue;->getText()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_b9

    goto :goto_a8

    :cond_b9
    if-eqz p2, :cond_a8

    const/4 v3, 0x1

    .line 218
    invoke-static {v2, p2, v3}, Lkotlin/text/StringsKt;->contains(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    move-result v2

    if-eqz v2, :cond_a8

    .line 219
    invoke-interface {p0, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_a8

    .line 224
    :cond_c6
    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p2

    invoke-direct {p1, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance p2, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda1;

    invoke-direct {p2, p3, p0}, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda1;-><init>(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/util/List;)V

    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private static final a(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/util/List;)V
    .registers 2

    .line 236
    invoke-interface {p0, p1}, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;->onResult(Ljava/util/List;)V

    return-void
.end method

.method private static final a(Ljava/lang/Exception;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V
    .registers 3

    .line 225
    instance-of v0, p0, Ljava/net/UnknownHostException;

    if-eqz v0, :cond_a

    .line 226
    sget-object p0, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;->NETWORK_ERROR:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;

    .line 227
    invoke-interface {p1, p0}, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;->onError(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;)V

    return-void

    .line 230
    :cond_a
    instance-of p0, p0, Ljava/net/MalformedURLException;

    if-eqz p0, :cond_14

    .line 231
    sget-object p0, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;->INVALID_FILE_URL:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;

    .line 232
    invoke-interface {p1, p0}, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;->onError(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;)V

    return-void

    .line 235
    :cond_14
    sget-object p0, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;->UNABLE_TO_PARSE_CAPTION_FILE:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;

    invoke-interface {p1, p0}, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;->onError(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;)V

    return-void
.end method

.method private final a(Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V
    .registers 6

    .line 8
    new-instance v0, Ljava/lang/Thread;

    .line 73
    new-instance v1, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda2;-><init>(Lcom/vdocipher/aegis/core/c/a;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V

    .line 74
    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 139
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method


# virtual methods
.method public final a(Lcom/vdocipher/aegis/media/Caption;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V
    .registers 5

    const-string v0, "captionSearchResult"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    if-nez p1, :cond_d

    .line 1
    sget-object p1, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;->CAPTION_NOT_SELECTED:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;

    invoke-interface {p3, p1}, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;->onError(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;)V

    return-void

    .line 5
    :cond_d
    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/Caption;->getUrl()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_16

    .line 7
    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/c/a;->a(Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V

    :cond_16
    return-void
.end method
