# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;

.field public final synthetic f$1:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/util/List;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda1;->f$1:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/c/a$$ExternalSyntheticLambda1;->f$1:Ljava/util/List;

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/c/a;->$r8$lambda$-f8JOo9qOfbAdE7Xhg__SxnisRY(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;Ljava/util/List;)V

    return-void
.end method
