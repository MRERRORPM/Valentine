# classes14.dex

.class public Lcom/vdocipher/aegis/core/p/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field a:Ljava/lang/String;

.field b:Ljava/lang/String;

.field c:Ljava/lang/String;

.field d:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/p/c;->a:Ljava/lang/String;

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/p/c;->b:Ljava/lang/String;

    .line 4
    iput-object p3, p0, Lcom/vdocipher/aegis/core/p/c;->c:Ljava/lang/String;

    .line 5
    iput-object p4, p0, Lcom/vdocipher/aegis/core/p/c;->d:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/p/c;->d:Ljava/lang/String;

    return-object v0
.end method

.method public b()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/p/c;->c:Ljava/lang/String;

    return-object v0
.end method
