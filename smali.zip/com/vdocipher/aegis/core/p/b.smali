# classes14.dex

.class public Lcom/vdocipher/aegis/core/p/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private a:Z

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Lcom/vdocipher/aegis/player/VdoInitParams;


# direct methods
.method public constructor <init>(ZLjava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/player/VdoInitParams;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-boolean p1, p0, Lcom/vdocipher/aegis/core/p/b;->a:Z

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/p/b;->b:Ljava/lang/String;

    .line 4
    iput-object p3, p0, Lcom/vdocipher/aegis/core/p/b;->c:Ljava/lang/String;

    .line 5
    iput-object p4, p0, Lcom/vdocipher/aegis/core/p/b;->d:Lcom/vdocipher/aegis/player/VdoInitParams;

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/p/b;->c:Ljava/lang/String;

    return-object v0
.end method

.method public b()Lcom/vdocipher/aegis/player/VdoInitParams;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/p/b;->d:Lcom/vdocipher/aegis/player/VdoInitParams;

    return-object v0
.end method

.method public c()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/p/b;->a:Z

    return v0
.end method
