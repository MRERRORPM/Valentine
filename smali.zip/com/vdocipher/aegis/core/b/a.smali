# classes14.dex

.class public final Lcom/vdocipher/aegis/core/b/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static b:Lcom/vdocipher/aegis/core/b/a;

.field private static c:Ljava/lang/String;


# instance fields
.field private a:Lcom/vdocipher/aegis/core/k/c;


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    sget-object v0, Lcom/vdocipher/aegis/core/b/a;->b:Lcom/vdocipher/aegis/core/b/a;

    if-nez v0, :cond_e

    .line 3
    invoke-static {p1}, Lcom/vdocipher/aegis/core/k/c;->b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/b/a;->a:Lcom/vdocipher/aegis/core/k/c;

    return-void

    .line 5
    :cond_e
    new-instance p1, Ljava/lang/RuntimeException;

    const-string v0, "Singleton class Logger can only be accessed by `getInstance()` method"

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static a(Landroid/content/Context;)Lcom/vdocipher/aegis/core/b/a;
    .registers 10

    .line 1
    sget-object v0, Lcom/vdocipher/aegis/core/b/a;->b:Lcom/vdocipher/aegis/core/b/a;

    if-nez v0, :cond_59

    if-eqz p0, :cond_59

    .line 2
    new-instance v0, Lcom/vdocipher/aegis/core/b/a;

    invoke-direct {v0, p0}, Lcom/vdocipher/aegis/core/b/a;-><init>(Landroid/content/Context;)V

    sput-object v0, Lcom/vdocipher/aegis/core/b/a;->b:Lcom/vdocipher/aegis/core/b/a;

    .line 3
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/aegis/core/b/a;->c:Ljava/lang/String;

    .line 4
    new-instance v0, Landroidx/work/Constraints$Builder;

    invoke-direct {v0}, Landroidx/work/Constraints$Builder;-><init>()V

    sget-object v1, Landroidx/work/NetworkType;->CONNECTED:Landroidx/work/NetworkType;

    .line 5
    invoke-virtual {v0, v1}, Landroidx/work/Constraints$Builder;->setRequiredNetworkType(Landroidx/work/NetworkType;)Landroidx/work/Constraints$Builder;

    move-result-object v0

    .line 6
    invoke-virtual {v0}, Landroidx/work/Constraints$Builder;->build()Landroidx/work/Constraints;

    move-result-object v0

    .line 8
    new-instance v1, Landroidx/work/PeriodicWorkRequest$Builder;

    sget-object v5, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    const-class v2, Lcom/vdocipher/aegis/workers/ApiUsageDataSyncer;

    const-wide/16 v3, 0x78

    const-wide/16 v6, 0xf

    move-object v8, v5

    invoke-direct/range {v1 .. v8}, Landroidx/work/PeriodicWorkRequest$Builder;-><init>(Ljava/lang/Class;JLjava/util/concurrent/TimeUnit;JLjava/util/concurrent/TimeUnit;)V

    .line 9
    invoke-virtual {v1, v0}, Landroidx/work/PeriodicWorkRequest$Builder;->setConstraints(Landroidx/work/Constraints;)Landroidx/work/WorkRequest$Builder;

    move-result-object v0

    check-cast v0, Landroidx/work/PeriodicWorkRequest$Builder;

    const-wide/16 v1, 0xf

    .line 10
    invoke-virtual {v0, v1, v2, v5}, Landroidx/work/PeriodicWorkRequest$Builder;->setInitialDelay(JLjava/util/concurrent/TimeUnit;)Landroidx/work/WorkRequest$Builder;

    move-result-object v0

    check-cast v0, Landroidx/work/PeriodicWorkRequest$Builder;

    sget-object v1, Landroidx/work/BackoffPolicy;->LINEAR:Landroidx/work/BackoffPolicy;

    const-wide/16 v2, 0x78

    .line 11
    invoke-virtual {v0, v1, v2, v3, v5}, Landroidx/work/PeriodicWorkRequest$Builder;->setBackoffCriteria(Landroidx/work/BackoffPolicy;JLjava/util/concurrent/TimeUnit;)Landroidx/work/WorkRequest$Builder;

    move-result-object v0

    check-cast v0, Landroidx/work/PeriodicWorkRequest$Builder;

    .line 12
    invoke-virtual {v0}, Landroidx/work/PeriodicWorkRequest$Builder;->build()Landroidx/work/WorkRequest;

    move-result-object v0

    check-cast v0, Landroidx/work/PeriodicWorkRequest;

    .line 14
    invoke-static {p0}, Landroidx/work/WorkManager;->getInstance(Landroid/content/Context;)Landroidx/work/WorkManager;

    move-result-object p0

    sget-object v1, Landroidx/work/ExistingPeriodicWorkPolicy;->KEEP:Landroidx/work/ExistingPeriodicWorkPolicy;

    const-string v2, "ApiUsageDataSyncer"

    invoke-virtual {p0, v2, v1, v0}, Landroidx/work/WorkManager;->enqueueUniquePeriodicWork(Ljava/lang/String;Landroidx/work/ExistingPeriodicWorkPolicy;Landroidx/work/PeriodicWorkRequest;)Landroidx/work/Operation;

    .line 20
    :cond_59
    sget-object p0, Lcom/vdocipher/aegis/core/b/a;->b:Lcom/vdocipher/aegis/core/b/a;

    return-object p0
.end method


# virtual methods
.method public a()V
    .registers 4

    .line 21
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v0

    .line 23
    array-length v1, v0

    const/4 v2, 0x3

    if-gt v1, v2, :cond_d

    goto :goto_1e

    .line 26
    :cond_d
    aget-object v1, v0, v2

    const/4 v2, 0x4

    .line 27
    aget-object v0, v0, v2

    .line 29
    invoke-virtual {v0}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v0

    sget-object v2, Lcom/vdocipher/aegis/core/b/a;->c:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1f

    :goto_1e
    return-void

    .line 32
    :cond_1f
    invoke-virtual {v1}, Ljava/lang/StackTraceElement;->getMethodName()Ljava/lang/String;

    move-result-object v0

    .line 33
    invoke-virtual {v1}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v1

    .line 34
    iget-object v2, p0, Lcom/vdocipher/aegis/core/b/a;->a:Lcom/vdocipher/aegis/core/k/c;

    invoke-virtual {v2, v0, v1}, Lcom/vdocipher/aegis/core/k/c;->g(Ljava/lang/String;Ljava/lang/String;)Z

    return-void
.end method
