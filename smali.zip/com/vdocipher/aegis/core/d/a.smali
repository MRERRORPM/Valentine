# classes14.dex

.class public abstract Lcom/vdocipher/aegis/core/d/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method static a()Ljava/lang/String;
    .registers 1

    .line 1
    const-string v0, "https://clipstat.com/api/v2/"

    return-object v0
.end method

.method static b()Ljava/lang/String;
    .registers 1

    .line 1
    const-string v0, "https://clipstat.com/api/v2/update/"

    return-object v0
.end method
