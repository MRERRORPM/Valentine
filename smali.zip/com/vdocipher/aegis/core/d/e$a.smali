# classes14.dex

.class Lcom/vdocipher/aegis/core/d/e$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/d/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/d/e;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/d/e;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/e$a;->a:Lcom/vdocipher/aegis/core/d/e;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    const-wide/16 v0, 0x1388

    .line 1
    :try_start_2
    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/e$a;->a:Lcom/vdocipher/aegis/core/d/e;

    monitor-enter v2
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_5} :catch_22
    .catch Ljava/lang/OutOfMemoryError; {:try_start_2 .. :try_end_5} :catch_20
    .catchall {:try_start_2 .. :try_end_5} :catchall_1e

    .line 2
    :try_start_5
    iget-object v3, p0, Lcom/vdocipher/aegis/core/d/e$a;->a:Lcom/vdocipher/aegis/core/d/e;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/d/e;->a(Lcom/vdocipher/aegis/core/d/e;)V

    .line 3
    monitor-exit v2
    :try_end_b
    .catchall {:try_start_5 .. :try_end_b} :catchall_1b

    .line 7
    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/e$a;->a:Lcom/vdocipher/aegis/core/d/e;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/d/e;->b(Lcom/vdocipher/aegis/core/d/e;)Z

    move-result v2

    if-nez v2, :cond_3b

    .line 8
    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/e$a;->a:Lcom/vdocipher/aegis/core/d/e;

    iget-object v2, v2, Lcom/vdocipher/aegis/core/d/e;->h:Landroid/os/Handler;

    invoke-virtual {v2, p0, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :catchall_1b
    move-exception v3

    .line 9
    :try_start_1c
    monitor-exit v2
    :try_end_1d
    .catchall {:try_start_1c .. :try_end_1d} :catchall_1b

    :try_start_1d
    throw v3
    :try_end_1e
    .catch Ljava/lang/Exception; {:try_start_1d .. :try_end_1e} :catch_22
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1d .. :try_end_1e} :catch_20
    .catchall {:try_start_1d .. :try_end_1e} :catchall_1e

    :catchall_1e
    move-exception v2

    goto :goto_3c

    :catch_20
    move-exception v2

    goto :goto_23

    :catch_22
    move-exception v2

    .line 11
    :goto_23
    :try_start_23
    const-string v3, "DefaultSH"

    invoke-static {v2}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2c
    .catchall {:try_start_23 .. :try_end_2c} :catchall_1e

    .line 13
    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/e$a;->a:Lcom/vdocipher/aegis/core/d/e;

    invoke-static {v2}, Lcom/vdocipher/aegis/core/d/e;->b(Lcom/vdocipher/aegis/core/d/e;)Z

    move-result v2

    if-nez v2, :cond_3b

    .line 14
    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/e$a;->a:Lcom/vdocipher/aegis/core/d/e;

    iget-object v2, v2, Lcom/vdocipher/aegis/core/d/e;->h:Landroid/os/Handler;

    invoke-virtual {v2, p0, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_3b
    return-void

    .line 15
    :goto_3c
    iget-object v3, p0, Lcom/vdocipher/aegis/core/d/e$a;->a:Lcom/vdocipher/aegis/core/d/e;

    invoke-static {v3}, Lcom/vdocipher/aegis/core/d/e;->b(Lcom/vdocipher/aegis/core/d/e;)Z

    move-result v3

    if-nez v3, :cond_4b

    .line 16
    iget-object v3, p0, Lcom/vdocipher/aegis/core/d/e$a;->a:Lcom/vdocipher/aegis/core/d/e;

    iget-object v3, v3, Lcom/vdocipher/aegis/core/d/e;->h:Landroid/os/Handler;

    invoke-virtual {v3, p0, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 18
    :cond_4b
    throw v2
.end method
