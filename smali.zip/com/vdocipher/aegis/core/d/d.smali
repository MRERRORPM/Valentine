# classes14.dex

.class Lcom/vdocipher/aegis/core/d/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vdocipher/aegis/core/d/j;
.implements Landroid/os/Handler$Callback;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/core/d/d$a;
    }
.end annotation


# instance fields
.field private final a:Landroid/os/HandlerThread;

.field private final b:Landroid/os/Handler;

.field private final c:Lcom/vdocipher/aegis/core/g/b;

.field private d:Lokhttp3/Headers;


# direct methods
.method constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Lokhttp3/Headers$Builder;

    invoke-direct {v0}, Lokhttp3/Headers$Builder;-><init>()V

    invoke-virtual {v0}, Lokhttp3/Headers$Builder;->build()Lokhttp3/Headers;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/d/d;->d:Lokhttp3/Headers;

    .line 17
    new-instance v0, Lcom/vdocipher/aegis/core/g/b;

    invoke-direct {v0}, Lcom/vdocipher/aegis/core/g/b;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/d/d;->c:Lcom/vdocipher/aegis/core/g/b;

    .line 18
    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "DefaultRH:NetworkThread"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/d/d;->a:Landroid/os/HandlerThread;

    .line 19
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 20
    new-instance v1, Landroid/os/Handler;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {v1, v0, p0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    iput-object v1, p0, Lcom/vdocipher/aegis/core/d/d;->b:Landroid/os/Handler;

    return-void
.end method

.method private a(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    .line 28
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 29
    const-string p1, "session"

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private a(Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V
    .registers 4

    .line 25
    :try_start_0
    invoke-interface {p2, p1}, Lcom/vdocipher/aegis/core/d/c$a;->a(Ljava/lang/String;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_3} :catch_4

    return-void

    :catch_4
    move-exception p1

    .line 27
    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "init callback failure "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "DefaultRH"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private a(Ljava/net/URL;Ljava/lang/String;)V
    .registers 6

    .line 22
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/d;->c:Lcom/vdocipher/aegis/core/g/b;

    sget-object v1, Lcom/vdocipher/aegis/core/g/a;->d:Lcom/vdocipher/aegis/core/g/a;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/d;->d:Lokhttp3/Headers;

    invoke-virtual {v0, p1, v1, v2, p2}, Lcom/vdocipher/aegis/core/g/b;->a(Ljava/net/URL;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/Headers;Ljava/lang/String;)Lcom/vdocipher/aegis/core/i/a;

    move-result-object p1

    .line 23
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/i/a;->d()Ljava/lang/Exception;

    move-result-object p2

    if-eqz p2, :cond_1d

    .line 24
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/i/a;->d()Ljava/lang/Exception;

    move-result-object p1

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DefaultRH"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1d
    return-void
.end method

.method private a(Ljava/net/URL;Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V
    .registers 7

    .line 9
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/d;->c:Lcom/vdocipher/aegis/core/g/b;

    sget-object v1, Lcom/vdocipher/aegis/core/g/a;->c:Lcom/vdocipher/aegis/core/g/a;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/d;->d:Lokhttp3/Headers;

    invoke-virtual {v0, p1, v1, v2, p2}, Lcom/vdocipher/aegis/core/g/b;->a(Ljava/net/URL;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/Headers;Ljava/lang/String;)Lcom/vdocipher/aegis/core/i/a;

    move-result-object p1

    .line 10
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/i/a;->f()Z

    move-result p2

    const-string v0, "DefaultRH"

    const/4 v1, 0x0

    if-nez p2, :cond_28

    .line 11
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/i/a;->d()Ljava/lang/Exception;

    move-result-object p2

    if-eqz p2, :cond_24

    .line 12
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/i/a;->d()Ljava/lang/Exception;

    move-result-object p1

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 14
    :cond_24
    invoke-direct {p0, v1, p3}, Lcom/vdocipher/aegis/core/d/d;->a(Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V

    return-void

    .line 17
    :cond_28
    :try_start_28
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/i/a;->a()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/d/d;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 18
    invoke-direct {p0, p1, p3}, Lcom/vdocipher/aegis/core/d/d;->a(Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V
    :try_end_33
    .catch Lorg/json/JSONException; {:try_start_28 .. :try_end_33} :catch_34

    return-void

    :catch_34
    move-exception p1

    .line 20
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 21
    invoke-direct {p0, v1, p3}, Lcom/vdocipher/aegis/core/d/d;->a(Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    .line 5
    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 7
    new-instance p1, Lcom/vdocipher/aegis/core/d/d$a;

    const/4 v1, 0x0

    invoke-direct {p1, v0, p2, v1}, Lcom/vdocipher/aegis/core/d/d$a;-><init>(Ljava/net/URL;Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V

    .line 8
    iget-object p2, p0, Lcom/vdocipher/aegis/core/d/d;->b:Landroid/os/Handler;

    const/4 v0, 0x2

    invoke-virtual {p2, v0, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V
    .registers 5

    .line 1
    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 3
    new-instance p1, Lcom/vdocipher/aegis/core/d/d$a;

    invoke-direct {p1, v0, p2, p3}, Lcom/vdocipher/aegis/core/d/d$a;-><init>(Ljava/net/URL;Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V

    .line 4
    iget-object p2, p0, Lcom/vdocipher/aegis/core/d/d;->b:Landroid/os/Handler;

    const/4 p3, 0x1

    invoke-virtual {p2, p3, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    return-void
.end method

.method public close()V
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/d;->a:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->quitSafely()Z

    return-void
.end method

.method public handleMessage(Landroid/os/Message;)Z
    .registers 5

    .line 1
    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_16

    const/4 v2, 0x2

    if-eq v0, v2, :cond_a

    const/4 p1, 0x0

    return p1

    .line 10
    :cond_a
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast p1, Lcom/vdocipher/aegis/core/d/d$a;

    .line 11
    iget-object v0, p1, Lcom/vdocipher/aegis/core/d/d$a;->a:Ljava/net/URL;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/d/d$a;->b:Ljava/lang/String;

    invoke-direct {p0, v0, p1}, Lcom/vdocipher/aegis/core/d/d;->a(Ljava/net/URL;Ljava/lang/String;)V

    return v1

    .line 12
    :cond_16
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast p1, Lcom/vdocipher/aegis/core/d/d$a;

    .line 13
    iget-object v0, p1, Lcom/vdocipher/aegis/core/d/d$a;->a:Ljava/net/URL;

    iget-object v2, p1, Lcom/vdocipher/aegis/core/d/d$a;->b:Ljava/lang/String;

    iget-object p1, p1, Lcom/vdocipher/aegis/core/d/d$a;->c:Lcom/vdocipher/aegis/core/d/c$a;

    invoke-direct {p0, v0, v2, p1}, Lcom/vdocipher/aegis/core/d/d;->a(Ljava/net/URL;Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V

    return v1
.end method
