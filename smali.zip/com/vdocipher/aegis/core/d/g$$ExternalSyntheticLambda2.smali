# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/d/g;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/d/g;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/d/g;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda2;->f$1:Ljava/lang/String;

    iput-object p3, p0, Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda2;->f$2:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/d/g;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda2;->f$1:Ljava/lang/String;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda2;->f$2:Ljava/lang/String;

    invoke-static {v0, v1, v2}, Lcom/vdocipher/aegis/core/d/g;->$r8$lambda$S6geKDCCKSKjV_ZOYi6TUhb-vx0(Lcom/vdocipher/aegis/core/d/g;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
