# classes14.dex

.class interface abstract Lcom/vdocipher/aegis/core/d/j;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/lang/String;Ljava/lang/String;)V
.end method

.method public abstract a(Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V
.end method

.method public abstract close()V
.end method
