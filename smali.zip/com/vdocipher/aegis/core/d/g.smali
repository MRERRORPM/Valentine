# classes14.dex

.class public Lcom/vdocipher/aegis/core/d/g;
.super Lcom/vdocipher/aegis/core/d/e;
.source "SourceFile"


# instance fields
.field private final J:Lcom/vdocipher/aegis/core/k/c;

.field private final K:Lcom/vdocipher/aegis/offline/DownloadRequest;

.field private final L:Ljava/lang/String;


# direct methods
.method public static synthetic $r8$lambda$70s_JYedlQpGKfoZCLDUJzdYUNE(Lcom/vdocipher/aegis/core/d/g;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/aegis/core/d/g;->j()V

    return-void
.end method

.method public static synthetic $r8$lambda$S6geKDCCKSKjV_ZOYi6TUhb-vx0(Lcom/vdocipher/aegis/core/d/g;Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/core/d/g;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$sL6lmZd0L178Cz8RLe_Pg9eBnbI(Lcom/vdocipher/aegis/core/d/g;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/d/g;->q(Ljava/lang/String;)V

    return-void
.end method

.method constructor <init>(Landroid/content/Context;Lorg/json/JSONObject;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/offline/DownloadRequest;Ljava/lang/String;Z)V
    .registers 20

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v6, p6

    move-object/from16 v7, p7

    move/from16 v8, p10

    .line 1
    invoke-direct/range {v0 .. v8}, Lcom/vdocipher/aegis/core/d/e;-><init>(Landroid/content/Context;Lorg/json/JSONObject;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 2
    invoke-static {p1}, Lcom/vdocipher/aegis/core/k/c;->b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/g;->J:Lcom/vdocipher/aegis/core/k/c;

    move-object/from16 p1, p8

    .line 3
    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/g;->K:Lcom/vdocipher/aegis/offline/DownloadRequest;

    move-object/from16 p1, p9

    .line 4
    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/g;->L:Ljava/lang/String;

    return-void
.end method

.method private synthetic b(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/g;->J:Lcom/vdocipher/aegis/core/k/c;

    invoke-virtual {v0, p1, p2}, Lcom/vdocipher/aegis/core/k/c;->a(Ljava/lang/String;Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_f

    .line 5
    const-string p1, "DownloadSH"

    const-string p2, "failed creating entry"

    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_f
    return-void
.end method

.method private c(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/e;->h:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, p1, p2}, Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda2;-><init>(Lcom/vdocipher/aegis/core/d/g;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private i()V
    .registers 5

    const-string v0, "DownloadSH"

    const-string v1, "sending "

    .line 1
    :try_start_4
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/k;->b:Lorg/json/JSONObject;

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/d/l;->c(Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/k;->b:Lorg/json/JSONObject;

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0}, Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda1;-><init>(Lcom/vdocipher/aegis/core/d/g;)V

    invoke-virtual {p0, v1, v2}, Lcom/vdocipher/aegis/core/d/e;->a(Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V
    :try_end_27
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_27} :catch_2a
    .catch Ljava/lang/OutOfMemoryError; {:try_start_4 .. :try_end_27} :catch_28

    return-void

    :catch_28
    move-exception v1

    goto :goto_2b

    :catch_2a
    move-exception v1

    .line 18
    :goto_2b
    new-instance v2, Lcom/vdocipher/aegis/core/d/k$a;

    const-string v3, "Error creating default csh"

    invoke-direct {v2, v3, v1}, Lcom/vdocipher/aegis/core/d/k$a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 19
    invoke-static {v2}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private synthetic j()V
    .registers 3

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/d/g;->k()V

    .line 4
    :try_start_3
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/g;->J:Lcom/vdocipher/aegis/core/k/c;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/k;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/vdocipher/aegis/core/k/c;->r(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_b
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_3 .. :try_end_b} :catch_c

    goto :goto_17

    :catch_c
    move-exception v0

    .line 6
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "DownloadSH"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x0

    :goto_17
    if-eqz v0, :cond_1d

    .line 10
    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/core/d/g;->p(Ljava/lang/String;)V

    goto :goto_20

    .line 13
    :cond_1d
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/d/g;->i()V

    :goto_20
    return-void
.end method

.method private k()V
    .registers 10

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/g;->K:Lcom/vdocipher/aegis/offline/DownloadRequest;

    if-eqz v0, :cond_87

    .line 2
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 6
    :try_start_9
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/g;->K:Lcom/vdocipher/aegis/offline/DownloadRequest;

    iget-object v1, v1, Lcom/vdocipher/aegis/offline/DownloadRequest;->downloadSelections:Lcom/vdocipher/aegis/offline/DownloadSelections;

    iget-object v1, v1, Lcom/vdocipher/aegis/offline/DownloadSelections;->selectedTrackIndices:[I

    array-length v2, v1

    const/4 v3, 0x0

    const/4 v4, 0x0

    move v5, v4

    move-object v4, v3

    :goto_14
    if-ge v5, v2, :cond_2f

    aget v6, v1, v5

    .line 7
    iget-object v7, p0, Lcom/vdocipher/aegis/core/d/g;->K:Lcom/vdocipher/aegis/offline/DownloadRequest;

    iget-object v7, v7, Lcom/vdocipher/aegis/offline/DownloadRequest;->downloadSelections:Lcom/vdocipher/aegis/offline/DownloadSelections;

    iget-object v7, v7, Lcom/vdocipher/aegis/offline/DownloadSelections;->downloadOptions:Lcom/vdocipher/aegis/offline/DownloadOptions;

    iget-object v7, v7, Lcom/vdocipher/aegis/offline/DownloadOptions;->availableTracks:[Lcom/vdocipher/aegis/media/Track;

    aget-object v6, v7, v6

    .line 8
    iget v7, v6, Lcom/vdocipher/aegis/media/Track;->type:I

    const/4 v8, 0x1

    if-ne v7, v8, :cond_28

    move-object v3, v6

    :cond_28
    const/4 v8, 0x2

    if-ne v7, v8, :cond_2c

    move-object v4, v6

    :cond_2c
    add-int/lit8 v5, v5, 0x1

    goto :goto_14

    .line 13
    :cond_2f
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V
    :try_end_34
    .catch Lorg/json/JSONException; {:try_start_9 .. :try_end_34} :catch_7d

    const-string v2, "bitrateKbps"

    if-eqz v3, :cond_44

    .line 15
    :try_start_38
    iget v5, v3, Lcom/vdocipher/aegis/media/Track;->bitrate:I

    invoke-virtual {v1, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 16
    const-string v5, "language"

    iget-object v3, v3, Lcom/vdocipher/aegis/media/Track;->language:Ljava/lang/String;

    invoke-virtual {v1, v5, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 19
    :cond_44
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    if-eqz v4, :cond_5f

    .line 21
    iget v5, v4, Lcom/vdocipher/aegis/media/Track;->bitrate:I

    invoke-virtual {v3, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 22
    const-string v2, "height"

    iget v5, v4, Lcom/vdocipher/aegis/media/Track;->height:I

    invoke-virtual {v3, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 23
    const-string/jumbo v2, "width"

    iget v4, v4, Lcom/vdocipher/aegis/media/Track;->width:I

    invoke-virtual {v3, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 26
    :cond_5f
    const-string v2, "audio"

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 27
    const-string/jumbo v1, "video"

    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 28
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/k;->b:Lorg/json/JSONObject;

    const-string v2, "selectedTracks"

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 29
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/g;->L:Ljava/lang/String;

    if-eqz v0, :cond_87

    .line 30
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/k;->b:Lorg/json/JSONObject;

    const-string v2, "downloadLocation"

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_7c
    .catch Lorg/json/JSONException; {:try_start_38 .. :try_end_7c} :catch_7d

    return-void

    :catch_7d
    move-exception v0

    .line 34
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "DownloadSH"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_87
    return-void
.end method

.method private p(Ljava/lang/String;)V
    .registers 3

    .line 1
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/d/e;->o(Ljava/lang/String;)V

    .line 2
    iget-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->h:Landroid/os/Handler;

    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/e;->I:Ljava/lang/Runnable;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private synthetic q(Ljava/lang/String;)V
    .registers 4

    if-nez p1, :cond_a

    .line 1
    const-string p1, "DownloadSH"

    const-string v0, "sessid not obtained"

    invoke-static {p1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    .line 4
    :cond_a
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "sessid obtained = "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "DownloadSH"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/d/l;->c(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    monitor-enter p0

    .line 6
    :try_start_1e
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/d/g;->p(Ljava/lang/String;)V

    .line 7
    monitor-exit p0
    :try_end_22
    .catchall {:try_start_1e .. :try_end_22} :catchall_28

    .line 9
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/k;->c:Ljava/lang/String;

    invoke-direct {p0, v0, p1}, Lcom/vdocipher/aegis/core/d/g;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :catchall_28
    move-exception p1

    .line 10
    :try_start_29
    monitor-exit p0
    :try_end_2a
    .catchall {:try_start_29 .. :try_end_2a} :catchall_28

    throw p1
.end method


# virtual methods
.method public bridge synthetic a()V
    .registers 1

    .line 1
    invoke-super {p0}, Lcom/vdocipher/aegis/core/d/e;->a()V

    return-void
.end method

.method public bridge synthetic a(I)V
    .registers 2

    .line 2
    invoke-super {p0, p1}, Lcom/vdocipher/aegis/core/d/e;->a(I)V

    return-void
.end method

.method public bridge synthetic a(J)V
    .registers 3

    .line 6
    invoke-super {p0, p1, p2}, Lcom/vdocipher/aegis/core/d/e;->a(J)V

    return-void
.end method

.method public bridge synthetic a(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 9
    invoke-super {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/d/e;->a(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic a(Ljava/lang/String;)V
    .registers 2

    .line 3
    invoke-super {p0, p1}, Lcom/vdocipher/aegis/core/d/e;->a(Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic a(Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    .line 5
    invoke-super {p0, p1, p2}, Lcom/vdocipher/aegis/core/d/e;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic a(Ljava/lang/String;Ljava/lang/String;I[Ljava/lang/String;)V
    .registers 5

    .line 7
    invoke-super {p0, p1, p2, p3, p4}, Lcom/vdocipher/aegis/core/d/e;->a(Ljava/lang/String;Ljava/lang/String;I[Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic a(Ljava/lang/String;[Ljava/lang/String;)V
    .registers 3

    .line 11
    invoke-super {p0, p1, p2}, Lcom/vdocipher/aegis/core/d/e;->a(Ljava/lang/String;[Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic a(Lorg/json/JSONArray;)V
    .registers 2

    .line 8
    invoke-super {p0, p1}, Lcom/vdocipher/aegis/core/d/e;->a(Lorg/json/JSONArray;)V

    return-void
.end method

.method public bridge synthetic a(Lorg/json/JSONObject;)V
    .registers 2

    .line 10
    invoke-super {p0, p1}, Lcom/vdocipher/aegis/core/d/e;->a(Lorg/json/JSONObject;)V

    return-void
.end method

.method public bridge synthetic a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 4
    invoke-super {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/d/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic b(J)V
    .registers 3

    .line 2
    invoke-super {p0, p1, p2}, Lcom/vdocipher/aegis/core/d/e;->b(J)V

    return-void
.end method

.method public bridge synthetic b(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-super {p0, p1}, Lcom/vdocipher/aegis/core/d/e;->b(Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic b(Lorg/json/JSONObject;)V
    .registers 2

    .line 3
    invoke-super {p0, p1}, Lcom/vdocipher/aegis/core/d/e;->b(Lorg/json/JSONObject;)V

    return-void
.end method

.method public bridge synthetic c(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-super {p0, p1}, Lcom/vdocipher/aegis/core/d/e;->c(Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic d(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-super {p0, p1}, Lcom/vdocipher/aegis/core/d/e;->d(Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic e(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-super {p0, p1}, Lcom/vdocipher/aegis/core/d/e;->e(Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic f(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-super {p0, p1}, Lcom/vdocipher/aegis/core/d/e;->f(Ljava/lang/String;)V

    return-void
.end method

.method protected g()V
    .registers 5

    .line 2
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/d/e;->e()V

    .line 4
    new-instance v0, Lcom/vdocipher/aegis/core/d/f;

    invoke-direct {v0}, Lcom/vdocipher/aegis/core/d/f;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/d/e;->j:Lcom/vdocipher/aegis/core/d/j;

    .line 6
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/e;->h:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/core/d/g;)V

    const-wide/16 v2, 0x32

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public bridge synthetic g(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-super {p0, p1}, Lcom/vdocipher/aegis/core/d/e;->g(Ljava/lang/String;)V

    return-void
.end method
