# classes14.dex

.class Lcom/vdocipher/aegis/core/d/e;
.super Lcom/vdocipher/aegis/core/d/k;
.source "SourceFile"


# instance fields
.field private A:Ljava/lang/String;

.field private B:Ljava/lang/String;

.field private final C:Ljava/util/ArrayList;

.field private final D:Ljava/util/ArrayList;

.field private final E:Ljava/util/ArrayList;

.field private final F:Ljava/util/ArrayList;

.field private final G:Ljava/util/Map;

.field private final H:Ljava/util/ArrayList;

.field protected final I:Ljava/lang/Runnable;

.field private volatile g:Landroid/os/HandlerThread;

.field protected h:Landroid/os/Handler;

.field private i:Ljava/lang/String;

.field protected j:Lcom/vdocipher/aegis/core/d/j;

.field private k:Lcom/vdocipher/aegis/core/d/b;

.field private l:Z

.field private m:Z

.field private volatile n:Z

.field private o:Lorg/json/JSONObject;

.field private p:Lorg/json/JSONArray;

.field private q:Ljava/lang/String;

.field private r:Lorg/json/JSONObject;

.field private s:Lorg/json/JSONObject;

.field private t:Lorg/json/JSONObject;

.field private u:Lorg/json/JSONObject;

.field private v:Ljava/lang/String;

.field private w:Ljava/lang/String;

.field private x:[Ljava/lang/String;

.field private y:J

.field private z:J


# direct methods
.method public static synthetic $r8$lambda$btsGB99i5NpeQ2faTHfH1zauMYQ(Lcom/vdocipher/aegis/core/d/e;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/d/e;->h(Ljava/lang/String;)V

    return-void
.end method

.method constructor <init>(Landroid/content/Context;Lorg/json/JSONObject;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    .registers 9

    .line 1
    invoke-direct/range {p0 .. p8}, Lcom/vdocipher/aegis/core/d/k;-><init>(Landroid/content/Context;Lorg/json/JSONObject;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    move-object p1, p0

    const/4 p2, 0x0

    .line 2
    iput-boolean p2, p1, Lcom/vdocipher/aegis/core/d/e;->l:Z

    .line 3
    iput-boolean p2, p1, Lcom/vdocipher/aegis/core/d/e;->m:Z

    .line 4
    iput-boolean p2, p1, Lcom/vdocipher/aegis/core/d/e;->n:Z

    .line 24
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p1, Lcom/vdocipher/aegis/core/d/e;->C:Ljava/util/ArrayList;

    .line 25
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p1, Lcom/vdocipher/aegis/core/d/e;->D:Ljava/util/ArrayList;

    .line 26
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p1, Lcom/vdocipher/aegis/core/d/e;->E:Ljava/util/ArrayList;

    .line 27
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p1, Lcom/vdocipher/aegis/core/d/e;->F:Ljava/util/ArrayList;

    .line 28
    new-instance p2, Ljava/util/HashMap;

    invoke-direct {p2}, Ljava/util/HashMap;-><init>()V

    iput-object p2, p1, Lcom/vdocipher/aegis/core/d/e;->G:Ljava/util/Map;

    .line 29
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p1, Lcom/vdocipher/aegis/core/d/e;->H:Ljava/util/ArrayList;

    .line 80
    new-instance p2, Lcom/vdocipher/aegis/core/d/e$a;

    invoke-direct {p2, p0}, Lcom/vdocipher/aegis/core/d/e$a;-><init>(Lcom/vdocipher/aegis/core/d/e;)V

    iput-object p2, p1, Lcom/vdocipher/aegis/core/d/e;->I:Ljava/lang/Runnable;

    .line 81
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/d/e;->g()V

    return-void
.end method

.method private static a(II)Lorg/json/JSONObject;
    .registers 5

    .line 166
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 167
    const-string v1, "op"

    const-string v2, "replace"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "/coverage/coveredArray/"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 168
    const-string v1, "path"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    .line 169
    const-string/jumbo v0, "value"

    invoke-virtual {p0, v0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static a(I[I)Lorg/json/JSONObject;
    .registers 6

    .line 143
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    .line 144
    array-length v1, p1

    const/4 v2, 0x0

    :goto_7
    if-ge v2, v1, :cond_11

    aget v3, p1, v2

    .line 145
    invoke-virtual {v0, v3}, Lorg/json/JSONArray;->put(I)Lorg/json/JSONArray;

    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    .line 147
    :cond_11
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    .line 148
    const-string v1, "length"

    invoke-virtual {p1, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object p0

    .line 149
    const-string p1, "coveredArray"

    invoke-virtual {p0, p1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    .line 150
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    .line 151
    const-string v0, "op"

    const-string v1, "add"

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p1

    .line 152
    const-string v0, "path"

    const-string v1, "/coverage"

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p1

    .line 153
    const-string/jumbo v0, "value"

    invoke-virtual {p1, v0, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static a(Ljava/lang/Integer;)Lorg/json/JSONObject;
    .registers 4

    .line 154
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 155
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 156
    const-string v1, "path"

    const-string v2, "/mutedError/-"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 157
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static a([Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 5

    .line 158
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    .line 159
    array-length v1, p0

    const/4 v2, 0x0

    :goto_7
    if-ge v2, v1, :cond_11

    aget-object v3, p0, v2

    .line 160
    invoke-virtual {v0, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    .line 162
    :cond_11
    new-instance p0, Lorg/json/JSONObject;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    .line 163
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {p0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    .line 164
    const-string v1, "path"

    const-string v2, "/tags"

    invoke-virtual {p0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    .line 165
    const-string/jumbo v1, "value"

    invoke-virtual {p0, v1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method static synthetic a(Lcom/vdocipher/aegis/core/d/e;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/d/e;->h()V

    return-void
.end method

.method private static b(Lorg/json/JSONArray;)Lorg/json/JSONObject;
    .registers 4

    .line 17
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 18
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 19
    const-string v1, "path"

    const-string v2, "/device/media/decoder"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 20
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method static synthetic b(Lcom/vdocipher/aegis/core/d/e;)Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z

    return p0
.end method

.method private static c(J)Lorg/json/JSONObject;
    .registers 5

    .line 6
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 7
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 8
    const-string v1, "path"

    const-string v2, "/licenseLoadDuration"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 9
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static c(Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .registers 4

    .line 10
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 11
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 12
    const-string v1, "path"

    const-string v2, "/beats/-"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 13
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static d(J)Lorg/json/JSONObject;
    .registers 5

    .line 6
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 7
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 8
    const-string v1, "path"

    const-string v2, "/metaLoadDuration"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 9
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static d(Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .registers 4

    .line 10
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 11
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 12
    const-string v1, "path"

    const-string v2, "/error"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 13
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static e(Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .registers 4

    .line 21
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 22
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 23
    const-string v1, "path"

    const-string v2, "/events/-"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 24
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private f()Ljava/lang/String;
    .registers 7

    .line 7
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    .line 10
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->o:Lorg/json/JSONObject;

    if-eqz v1, :cond_10

    .line 11
    invoke-static {v1}, Lcom/vdocipher/aegis/core/d/e;->k(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 15
    :cond_10
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->p:Lorg/json/JSONArray;

    if-eqz v1, :cond_1b

    .line 16
    invoke-static {v1}, Lcom/vdocipher/aegis/core/d/e;->b(Lorg/json/JSONArray;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 20
    :cond_1b
    iget-wide v1, p0, Lcom/vdocipher/aegis/core/d/e;->y:J

    const-wide/16 v3, 0x0

    cmp-long v5, v1, v3

    if-eqz v5, :cond_2a

    .line 21
    invoke-static {v1, v2}, Lcom/vdocipher/aegis/core/d/e;->d(J)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 25
    :cond_2a
    iget-wide v1, p0, Lcom/vdocipher/aegis/core/d/e;->z:J

    cmp-long v3, v1, v3

    if-eqz v3, :cond_37

    .line 26
    invoke-static {v1, v2}, Lcom/vdocipher/aegis/core/d/e;->c(J)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 30
    :cond_37
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->A:Ljava/lang/String;

    if-eqz v1, :cond_4a

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_4a

    .line 31
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->A:Ljava/lang/String;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/d/e;->l(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 35
    :cond_4a
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->B:Ljava/lang/String;

    if-eqz v1, :cond_5d

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_5d

    .line 36
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->B:Ljava/lang/String;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/d/e;->k(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 40
    :cond_5d
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->u:Lorg/json/JSONObject;

    if-eqz v1, :cond_68

    .line 41
    invoke-static {v1}, Lcom/vdocipher/aegis/core/d/e;->g(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 45
    :cond_68
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->r:Lorg/json/JSONObject;

    if-eqz v1, :cond_73

    .line 46
    invoke-static {v1}, Lcom/vdocipher/aegis/core/d/e;->f(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 50
    :cond_73
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->q:Ljava/lang/String;

    if-eqz v1, :cond_7e

    .line 51
    invoke-static {v1}, Lcom/vdocipher/aegis/core/d/e;->m(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 55
    :cond_7e
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->w:Ljava/lang/String;

    if-eqz v1, :cond_89

    .line 56
    invoke-static {v1}, Lcom/vdocipher/aegis/core/d/e;->n(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 60
    :cond_89
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->x:[Ljava/lang/String;

    if-eqz v1, :cond_94

    .line 61
    invoke-static {v1}, Lcom/vdocipher/aegis/core/d/e;->a([Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 65
    :cond_94
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->s:Lorg/json/JSONObject;

    if-eqz v1, :cond_9f

    .line 66
    invoke-static {v1}, Lcom/vdocipher/aegis/core/d/e;->d(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 70
    :cond_9f
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->C:Ljava/util/ArrayList;

    const/4 v2, 0x0

    if-eqz v1, :cond_bb

    .line 71
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    move v4, v2

    :goto_a9
    if-ge v4, v3, :cond_bb

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    add-int/lit8 v4, v4, 0x1

    check-cast v5, Ljava/lang/Integer;

    .line 72
    invoke-static {v5}, Lcom/vdocipher/aegis/core/d/e;->a(Ljava/lang/Integer;)Lorg/json/JSONObject;

    move-result-object v5

    invoke-virtual {v0, v5}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_a9

    .line 77
    :cond_bb
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->t:Lorg/json/JSONObject;

    if-eqz v1, :cond_c6

    .line 78
    invoke-static {v1}, Lcom/vdocipher/aegis/core/d/e;->h(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 82
    :cond_c6
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->E:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_e7

    .line 83
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->E:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    move v4, v2

    :goto_d5
    if-ge v4, v3, :cond_e7

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    add-int/lit8 v4, v4, 0x1

    check-cast v5, Lorg/json/JSONObject;

    .line 84
    invoke-static {v5}, Lcom/vdocipher/aegis/core/d/e;->e(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v5

    invoke-virtual {v0, v5}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_d5

    .line 89
    :cond_e7
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->F:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_108

    .line 90
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->F:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    move v4, v2

    :goto_f6
    if-ge v4, v3, :cond_108

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    add-int/lit8 v4, v4, 0x1

    check-cast v5, Lorg/json/JSONObject;

    .line 91
    invoke-static {v5}, Lcom/vdocipher/aegis/core/d/e;->i(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v5

    invoke-virtual {v0, v5}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_f6

    .line 96
    :cond_108
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->D:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_129

    .line 97
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->D:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    move v4, v2

    :goto_117
    if-ge v4, v3, :cond_129

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    add-int/lit8 v4, v4, 0x1

    check-cast v5, Lorg/json/JSONObject;

    .line 98
    invoke-static {v5}, Lcom/vdocipher/aegis/core/d/e;->c(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v5

    invoke-virtual {v0, v5}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_117

    .line 103
    :cond_129
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->H:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_149

    .line 104
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->H:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    :goto_137
    if-ge v2, v3, :cond_149

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    add-int/lit8 v2, v2, 0x1

    check-cast v4, Lorg/json/JSONObject;

    .line 105
    invoke-static {v4}, Lcom/vdocipher/aegis/core/d/e;->j(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v4

    invoke-virtual {v0, v4}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_137

    .line 110
    :cond_149
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->G:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z

    move-result v1

    const/4 v2, 0x1

    if-nez v1, :cond_199

    .line 113
    iget-boolean v1, p0, Lcom/vdocipher/aegis/core/d/e;->l:Z

    if-nez v1, :cond_167

    .line 114
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->k:Lcom/vdocipher/aegis/core/d/b;

    .line 117
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/d/b;->a()[I

    move-result-object v1

    const/16 v3, 0x14

    .line 118
    invoke-static {v3, v1}, Lcom/vdocipher/aegis/core/d/e;->a(I[I)Lorg/json/JSONObject;

    move-result-object v1

    .line 119
    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 123
    iput-boolean v2, p0, Lcom/vdocipher/aegis/core/d/e;->l:Z

    .line 126
    :cond_167
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->G:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_171
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_199

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map$Entry;

    .line 128
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    .line 129
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    .line 130
    invoke-static {v4, v3}, Lcom/vdocipher/aegis/core/d/e;->a(II)Lorg/json/JSONObject;

    move-result-object v3

    invoke-virtual {v0, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_171

    .line 137
    :cond_199
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->v:Ljava/lang/String;

    if-eqz v1, :cond_1b2

    .line 139
    iget-boolean v3, p0, Lcom/vdocipher/aegis/core/d/e;->m:Z

    if-nez v3, :cond_1ab

    .line 140
    invoke-static {v1}, Lcom/vdocipher/aegis/core/d/e;->i(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 141
    iput-boolean v2, p0, Lcom/vdocipher/aegis/core/d/e;->m:Z

    goto :goto_1b2

    .line 143
    :cond_1ab
    invoke-static {v1}, Lcom/vdocipher/aegis/core/d/e;->j(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 148
    :cond_1b2
    :goto_1b2
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v1

    if-nez v1, :cond_1ba

    const/4 v0, 0x0

    return-object v0

    :cond_1ba
    invoke-virtual {v0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static f(Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .registers 4

    .line 149
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 150
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 151
    const-string v1, "path"

    const-string v2, "/media"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 152
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static g(Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .registers 4

    .line 42
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 43
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 44
    const-string v1, "path"

    const-string v2, "/perf"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 45
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static h(Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .registers 4

    .line 52
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 53
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 54
    const-string v1, "path"

    const-string v2, "/resumed"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 55
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private h()V
    .registers 5

    .line 9
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/d/k;->c()Z

    move-result v0

    if-nez v0, :cond_7

    goto :goto_61

    .line 14
    :cond_7
    :try_start_7
    monitor-enter p0
    :try_end_8
    .catch Lorg/json/JSONException; {:try_start_7 .. :try_end_8} :catch_65

    .line 15
    :try_start_8
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/d/e;->f()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    .line 17
    iput-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->o:Lorg/json/JSONObject;

    .line 18
    iput-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->p:Lorg/json/JSONArray;

    const-wide/16 v2, 0x0

    .line 19
    iput-wide v2, p0, Lcom/vdocipher/aegis/core/d/e;->y:J

    .line 20
    iput-wide v2, p0, Lcom/vdocipher/aegis/core/d/e;->z:J

    .line 21
    iput-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->q:Ljava/lang/String;

    .line 22
    iput-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->w:Ljava/lang/String;

    .line 23
    iput-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->x:[Ljava/lang/String;

    .line 24
    iput-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->r:Lorg/json/JSONObject;

    .line 25
    iput-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->s:Lorg/json/JSONObject;

    .line 26
    iput-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->t:Lorg/json/JSONObject;

    .line 27
    iput-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->v:Ljava/lang/String;

    .line 28
    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/e;->C:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 29
    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/e;->E:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 30
    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/e;->F:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 31
    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/e;->D:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 32
    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/e;->H:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 33
    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/e;->G:Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->clear()V

    .line 34
    iput-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->u:Lorg/json/JSONObject;

    .line 35
    iput-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->A:Ljava/lang/String;

    .line 36
    iput-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->B:Ljava/lang/String;

    .line 37
    monitor-exit p0
    :try_end_4a
    .catchall {:try_start_8 .. :try_end_4a} :catchall_62

    if-eqz v0, :cond_61

    .line 44
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->j:Lcom/vdocipher/aegis/core/d/j;

    if-nez v1, :cond_51

    goto :goto_61

    .line 46
    :cond_51
    :try_start_51
    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/e;->i:Ljava/lang/String;

    invoke-interface {v1, v2, v0}, Lcom/vdocipher/aegis/core/d/j;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_56
    .catch Ljava/lang/Exception; {:try_start_51 .. :try_end_56} :catch_57

    return-void

    :catch_57
    move-exception v0

    .line 48
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "DefaultSH"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_61
    :goto_61
    return-void

    :catchall_62
    move-exception v0

    .line 49
    :try_start_63
    monitor-exit p0
    :try_end_64
    .catchall {:try_start_63 .. :try_end_64} :catchall_62

    :try_start_64
    throw v0
    :try_end_65
    .catch Lorg/json/JSONException; {:try_start_64 .. :try_end_65} :catch_65

    :catch_65
    move-exception v0

    .line 51
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "DefaultSH"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private synthetic h(Ljava/lang/String;)V
    .registers 4

    if-nez p1, :cond_a

    .line 1
    const-string p1, "DefaultSH"

    const-string v0, "sessid not obtained"

    invoke-static {p1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    .line 4
    :cond_a
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "sessid obtained = "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "DefaultSH"

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/d/l;->c(Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    monitor-enter p0

    .line 6
    :try_start_1e
    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/core/d/e;->o(Ljava/lang/String;)V

    .line 7
    iget-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->h:Landroid/os/Handler;

    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/e;->I:Ljava/lang/Runnable;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 8
    monitor-exit p0

    return-void

    :catchall_2a
    move-exception p1

    monitor-exit p0
    :try_end_2c
    .catchall {:try_start_1e .. :try_end_2c} :catchall_2a

    throw p1
.end method

.method private static i(Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 4

    .line 5
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 6
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 7
    const-string v1, "path"

    const-string v2, "/captionSearch"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 8
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static i(Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .registers 4

    .line 1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 2
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 3
    const-string v1, "path"

    const-string v2, "/traces/-"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 4
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static j(Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 4

    .line 5
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 6
    const-string v1, "op"

    const-string v2, "replace"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 7
    const-string v1, "path"

    const-string v2, "/captionSearch"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 8
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static j(Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .registers 4

    .line 1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 2
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 3
    const-string v1, "path"

    const-string v2, "/trackSupportResults/-"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 4
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static k(Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 4

    .line 5
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 6
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 7
    const-string v1, "path"

    const-string v2, "/licenseVersion"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 8
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static k(Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .registers 4

    .line 1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 2
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 3
    const-string v1, "path"

    const-string v2, "/device/cdm/widevine"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 4
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static l(Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 4

    .line 1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 2
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 3
    const-string v1, "path"

    const-string v2, "/metaVersion"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 4
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static m(Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 4

    .line 1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 2
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 3
    const-string v1, "path"

    const-string v2, "/tech"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 4
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static n(Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 4

    .line 1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 2
    const-string v1, "op"

    const-string v2, "add"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 3
    const-string v1, "path"

    const-string v2, "/userId"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 4
    const-string/jumbo v1, "value"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public declared-synchronized a()V
    .registers 4

    monitor-enter p0

    .line 127
    :try_start_1
    const-string v0, "DefaultSH"

    const-string v1, "close"

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/d/l;->c(Ljava/lang/String;Ljava/lang/String;)V

    .line 128
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z
    :try_end_a
    .catchall {:try_start_1 .. :try_end_a} :catchall_3f

    if-eqz v0, :cond_e

    monitor-exit p0

    return-void

    :cond_e
    const/4 v0, 0x1

    .line 129
    :try_start_f
    iput-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z
    :try_end_11
    .catchall {:try_start_f .. :try_end_11} :catchall_3f

    const/4 v0, 0x0

    .line 131
    :try_start_12
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->h:Landroid/os/Handler;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/e;->I:Ljava/lang/Runnable;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 132
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/d/e;->h()V

    .line 133
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->j:Lcom/vdocipher/aegis/core/d/j;

    invoke-interface {v1}, Lcom/vdocipher/aegis/core/d/j;->close()V

    .line 134
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->g:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->quitSafely()Z
    :try_end_26
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_26} :catch_2e
    .catch Ljava/lang/OutOfMemoryError; {:try_start_12 .. :try_end_26} :catch_2c
    .catchall {:try_start_12 .. :try_end_26} :catchall_2a

    .line 138
    :try_start_26
    iput-object v0, p0, Lcom/vdocipher/aegis/core/d/e;->j:Lcom/vdocipher/aegis/core/d/j;
    :try_end_28
    .catchall {:try_start_26 .. :try_end_28} :catchall_3f

    monitor-exit p0

    return-void

    :catchall_2a
    move-exception v1

    goto :goto_3c

    :catch_2c
    move-exception v1

    goto :goto_2f

    :catch_2e
    move-exception v1

    .line 139
    :goto_2f
    :try_start_2f
    const-string v2, "DefaultSH"

    invoke-static {v1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_38
    .catchall {:try_start_2f .. :try_end_38} :catchall_2a

    .line 141
    :try_start_38
    iput-object v0, p0, Lcom/vdocipher/aegis/core/d/e;->j:Lcom/vdocipher/aegis/core/d/j;
    :try_end_3a
    .catchall {:try_start_38 .. :try_end_3a} :catchall_3f

    monitor-exit p0

    return-void

    :goto_3c
    :try_start_3c
    iput-object v0, p0, Lcom/vdocipher/aegis/core/d/e;->j:Lcom/vdocipher/aegis/core/d/j;

    .line 142
    throw v1

    :catchall_3f
    move-exception v0

    monitor-exit p0
    :try_end_41
    .catchall {:try_start_3c .. :try_end_41} :catchall_3f

    throw v0
.end method

.method public a(I)V
    .registers 4

    .line 83
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z

    if-eqz v0, :cond_5

    goto :goto_2c

    .line 84
    :cond_5
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/e;->k:Lcom/vdocipher/aegis/core/d/b;

    if-nez v0, :cond_a

    goto :goto_2c

    .line 86
    :cond_a
    monitor-enter p0

    .line 88
    :try_start_b
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/e;->k:Lcom/vdocipher/aegis/core/d/b;

    invoke-virtual {v0, p1}, Lcom/vdocipher/aegis/core/d/b;->a(I)Landroid/util/Pair;

    move-result-object p1

    .line 89
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/e;->G:Ljava/util/Map;

    iget-object v1, p1, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Integer;

    iget-object p1, p1, Landroid/util/Pair;->second:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Integer;

    invoke-interface {v0, v1, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1e
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_1e} :catch_21
    .catchall {:try_start_b .. :try_end_1e} :catchall_1f

    goto :goto_2b

    :catchall_1f
    move-exception p1

    goto :goto_2d

    :catch_21
    move-exception p1

    .line 91
    :try_start_22
    const-string v0, "DefaultSH"

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 93
    :goto_2b
    monitor-exit p0

    :goto_2c
    return-void

    :goto_2d
    monitor-exit p0
    :try_end_2e
    .catchall {:try_start_22 .. :try_end_2e} :catchall_1f

    throw p1
.end method

.method public a(J)V
    .registers 4

    .line 8
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z

    if-eqz v0, :cond_5

    return-void

    .line 10
    :cond_5
    monitor-enter p0

    .line 11
    :try_start_6
    iput-wide p1, p0, Lcom/vdocipher/aegis/core/d/e;->z:J

    .line 12
    monitor-exit p0

    return-void

    :catchall_a
    move-exception p1

    monitor-exit p0
    :try_end_c
    .catchall {:try_start_6 .. :try_end_c} :catchall_a

    throw p1
.end method

.method public a(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    .line 65
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z

    if-eqz v0, :cond_5

    return-void

    .line 67
    :cond_5
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 69
    :try_start_a
    const-string v1, "name"

    invoke-virtual {v0, v1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 70
    const-string/jumbo p2, "time"

    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/d/k;->b()I

    move-result v1

    invoke-virtual {v0, p2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    if-eqz p3, :cond_20

    .line 71
    const-string p2, "payload"

    invoke-virtual {v0, p2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_20
    .catch Lorg/json/JSONException; {:try_start_a .. :try_end_20} :catch_30

    .line 78
    :cond_20
    monitor-enter p0

    .line 79
    :try_start_21
    iget-object p2, p0, Lcom/vdocipher/aegis/core/d/e;->E:Ljava/util/ArrayList;

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 80
    iget-object p2, p0, Lcom/vdocipher/aegis/core/d/e;->C:Ljava/util/ArrayList;

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 81
    monitor-exit p0

    return-void

    :catchall_2d
    move-exception p1

    monitor-exit p0
    :try_end_2f
    .catchall {:try_start_21 .. :try_end_2f} :catchall_2d

    throw p1

    :catch_30
    move-exception p1

    .line 82
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DefaultSH"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public declared-synchronized a(Ljava/lang/String;)V
    .registers 5

    const-string v0, "save beat: "

    monitor-enter p0

    .line 94
    :try_start_3
    iget-boolean v1, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z
    :try_end_5
    .catchall {:try_start_3 .. :try_end_5} :catchall_3b

    if-eqz v1, :cond_9

    monitor-exit p0

    return-void

    .line 98
    :cond_9
    :try_start_9
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 99
    const-string p1, "DefaultSH"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/vdocipher/aegis/core/d/l;->c(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_23
    .catch Lorg/json/JSONException; {:try_start_9 .. :try_end_23} :catch_2f
    .catchall {:try_start_9 .. :try_end_23} :catchall_3b

    .line 105
    :try_start_23
    monitor-enter p0
    :try_end_24
    .catchall {:try_start_23 .. :try_end_24} :catchall_3b

    .line 106
    :try_start_24
    iget-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->D:Ljava/util/ArrayList;

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 107
    monitor-exit p0
    :try_end_2a
    .catchall {:try_start_24 .. :try_end_2a} :catchall_2c

    monitor-exit p0

    return-void

    :catchall_2c
    move-exception p1

    :try_start_2d
    monitor-exit p0
    :try_end_2e
    .catchall {:try_start_2d .. :try_end_2e} :catchall_2c

    :try_start_2e
    throw p1

    :catch_2f
    move-exception p1

    .line 108
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "DefaultSH"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_39
    .catchall {:try_start_2e .. :try_end_39} :catchall_3b

    monitor-exit p0

    return-void

    :catchall_3b
    move-exception p1

    :try_start_3c
    monitor-exit p0
    :try_end_3d
    .catchall {:try_start_3c .. :try_end_3d} :catchall_3b

    throw p1
.end method

.method protected a(Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V
    .registers 5

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/e;->j:Lcom/vdocipher/aegis/core/d/j;

    if-eqz v0, :cond_b

    .line 3
    invoke-static {}, Lcom/vdocipher/aegis/core/d/a;->a()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, p1, p2}, Lcom/vdocipher/aegis/core/d/j;->a(Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V

    :cond_b
    return-void
.end method

.method public declared-synchronized a(Ljava/lang/String;Ljava/lang/String;)V
    .registers 7

    const-string v0, "save event "

    monitor-enter p0

    .line 109
    :try_start_3
    iget-boolean v1, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z
    :try_end_5
    .catchall {:try_start_3 .. :try_end_5} :catchall_4d

    if-eqz v1, :cond_9

    monitor-exit p0

    return-void

    .line 111
    :cond_9
    :try_start_9
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V
    :try_end_e
    .catchall {:try_start_9 .. :try_end_e} :catchall_4d

    .line 113
    :try_start_e
    const-string v2, "name"

    invoke-virtual {v1, v2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 114
    const-string/jumbo v2, "time"

    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/d/k;->b()I

    move-result v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    if-eqz p2, :cond_24

    .line 115
    const-string v2, "payload"

    invoke-virtual {v1, v2, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_24
    .catch Lorg/json/JSONException; {:try_start_e .. :try_end_24} :catch_41
    .catchall {:try_start_e .. :try_end_24} :catchall_4d

    .line 122
    :cond_24
    :try_start_24
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "DefaultSH"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/d/l;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 123
    monitor-enter p0
    :try_end_36
    .catchall {:try_start_24 .. :try_end_36} :catchall_4d

    .line 124
    :try_start_36
    iget-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->E:Ljava/util/ArrayList;

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 125
    monitor-exit p0
    :try_end_3c
    .catchall {:try_start_36 .. :try_end_3c} :catchall_3e

    monitor-exit p0

    return-void

    :catchall_3e
    move-exception p1

    :try_start_3f
    monitor-exit p0
    :try_end_40
    .catchall {:try_start_3f .. :try_end_40} :catchall_3e

    :try_start_40
    throw p1

    :catch_41
    move-exception p1

    .line 126
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DefaultSH"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_4b
    .catchall {:try_start_40 .. :try_end_4b} :catchall_4d

    monitor-exit p0

    return-void

    :catchall_4d
    move-exception p1

    :try_start_4e
    monitor-exit p0
    :try_end_4f
    .catchall {:try_start_4e .. :try_end_4f} :catchall_4d

    throw p1
.end method

.method public a(Ljava/lang/String;Ljava/lang/String;I[Ljava/lang/String;)V
    .registers 9

    .line 18
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z

    if-eqz v0, :cond_5

    return-void

    .line 20
    :cond_5
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    if-eqz p4, :cond_18

    .line 22
    array-length v1, p4

    const/4 v2, 0x0

    :goto_e
    if-ge v2, v1, :cond_18

    aget-object v3, p4, v2

    invoke-virtual {v0, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v2, v2, 0x1

    goto :goto_e

    .line 25
    :cond_18
    new-instance p4, Lorg/json/JSONObject;

    invoke-direct {p4}, Lorg/json/JSONObject;-><init>()V

    .line 27
    :try_start_1d
    const-string v1, "id"

    invoke-virtual {p4, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 28
    const-string/jumbo p1, "title"

    invoke-virtual {p4, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 29
    const-string p1, "duration"

    invoke-virtual {p4, p1, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 30
    const-string/jumbo p1, "tech"

    invoke-virtual {p4, p1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_33
    .catch Lorg/json/JSONException; {:try_start_1d .. :try_end_33} :catch_42

    .line 36
    monitor-enter p0

    .line 37
    :try_start_34
    iput-object p4, p0, Lcom/vdocipher/aegis/core/d/e;->r:Lorg/json/JSONObject;

    .line 38
    new-instance p1, Lcom/vdocipher/aegis/core/d/b;

    invoke-direct {p1, p3}, Lcom/vdocipher/aegis/core/d/b;-><init>(I)V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->k:Lcom/vdocipher/aegis/core/d/b;

    .line 39
    monitor-exit p0

    return-void

    :catchall_3f
    move-exception p1

    monitor-exit p0
    :try_end_41
    .catchall {:try_start_34 .. :try_end_41} :catchall_3f

    throw p1

    :catch_42
    move-exception p1

    .line 40
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DefaultSH"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public a(Ljava/lang/String;[Ljava/lang/String;)V
    .registers 4

    .line 41
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z

    if-eqz v0, :cond_5

    return-void

    .line 43
    :cond_5
    monitor-enter p0

    if-eqz p1, :cond_d

    .line 44
    :try_start_8
    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->w:Ljava/lang/String;

    goto :goto_d

    :catchall_b
    move-exception p1

    goto :goto_13

    :cond_d
    :goto_d
    if-eqz p2, :cond_11

    .line 45
    iput-object p2, p0, Lcom/vdocipher/aegis/core/d/e;->x:[Ljava/lang/String;

    .line 46
    :cond_11
    monitor-exit p0

    return-void

    :goto_13
    monitor-exit p0
    :try_end_14
    .catchall {:try_start_8 .. :try_end_14} :catchall_b

    throw p1
.end method

.method public a(Lorg/json/JSONArray;)V
    .registers 3

    .line 4
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z

    if-eqz v0, :cond_5

    return-void

    .line 5
    :cond_5
    monitor-enter p0

    .line 6
    :try_start_6
    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->p:Lorg/json/JSONArray;

    .line 7
    monitor-exit p0

    return-void

    :catchall_a
    move-exception p1

    monitor-exit p0
    :try_end_c
    .catchall {:try_start_6 .. :try_end_c} :catchall_a

    throw p1
.end method

.method public a(Lorg/json/JSONObject;)V
    .registers 3

    .line 13
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z

    if-eqz v0, :cond_5

    return-void

    .line 15
    :cond_5
    monitor-enter p0

    .line 16
    :try_start_6
    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->u:Lorg/json/JSONObject;

    .line 17
    monitor-exit p0

    return-void

    :catchall_a
    move-exception p1

    monitor-exit p0
    :try_end_c
    .catchall {:try_start_6 .. :try_end_c} :catchall_a

    throw p1
.end method

.method public a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    .line 47
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z

    if-eqz v0, :cond_5

    return-void

    .line 49
    :cond_5
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 51
    :try_start_a
    const-string v1, "name"

    invoke-virtual {v0, v1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 52
    const-string/jumbo p2, "time"

    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/d/k;->b()I

    move-result v1

    invoke-virtual {v0, p2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    if-eqz p3, :cond_20

    .line 53
    const-string p2, "payload"

    invoke-virtual {v0, p2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_20
    .catch Lorg/json/JSONException; {:try_start_a .. :try_end_20} :catch_2d

    .line 60
    :cond_20
    monitor-enter p0

    .line 61
    :try_start_21
    iget-object p2, p0, Lcom/vdocipher/aegis/core/d/e;->E:Ljava/util/ArrayList;

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 62
    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->s:Lorg/json/JSONObject;

    .line 63
    monitor-exit p0

    return-void

    :catchall_2a
    move-exception p1

    monitor-exit p0
    :try_end_2c
    .catchall {:try_start_21 .. :try_end_2c} :catchall_2a

    throw p1

    :catch_2d
    move-exception p1

    .line 64
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DefaultSH"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public b(J)V
    .registers 4

    .line 7
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z

    if-eqz v0, :cond_5

    return-void

    .line 9
    :cond_5
    monitor-enter p0

    .line 10
    :try_start_6
    iput-wide p1, p0, Lcom/vdocipher/aegis/core/d/e;->y:J

    .line 11
    monitor-exit p0

    return-void

    :catchall_a
    move-exception p1

    monitor-exit p0
    :try_end_c
    .catchall {:try_start_6 .. :try_end_c} :catchall_a

    throw p1
.end method

.method public declared-synchronized b(Ljava/lang/String;)V
    .registers 3

    monitor-enter p0

    .line 12
    :try_start_1
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_10

    if-eqz v0, :cond_7

    monitor-exit p0

    return-void

    .line 14
    :cond_7
    :try_start_7
    monitor-enter p0
    :try_end_8
    .catchall {:try_start_7 .. :try_end_8} :catchall_10

    .line 15
    :try_start_8
    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->v:Ljava/lang/String;

    .line 16
    monitor-exit p0
    :try_end_b
    .catchall {:try_start_8 .. :try_end_b} :catchall_d

    monitor-exit p0

    return-void

    :catchall_d
    move-exception p1

    :try_start_e
    monitor-exit p0
    :try_end_f
    .catchall {:try_start_e .. :try_end_f} :catchall_d

    :try_start_f
    throw p1

    :catchall_10
    move-exception p1

    monitor-exit p0
    :try_end_12
    .catchall {:try_start_f .. :try_end_12} :catchall_10

    throw p1
.end method

.method public b(Lorg/json/JSONObject;)V
    .registers 3

    .line 2
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z

    if-eqz v0, :cond_5

    return-void

    .line 4
    :cond_5
    monitor-enter p0

    .line 5
    :try_start_6
    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->o:Lorg/json/JSONObject;

    .line 6
    monitor-exit p0

    return-void

    :catchall_a
    move-exception p1

    monitor-exit p0
    :try_end_c
    .catchall {:try_start_6 .. :try_end_c} :catchall_a

    throw p1
.end method

.method public c(Ljava/lang/String;)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z

    if-eqz v0, :cond_5

    return-void

    .line 3
    :cond_5
    monitor-enter p0

    .line 4
    :try_start_6
    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->B:Ljava/lang/String;

    .line 5
    monitor-exit p0

    return-void

    :catchall_a
    move-exception p1

    monitor-exit p0
    :try_end_c
    .catchall {:try_start_6 .. :try_end_c} :catchall_a

    throw p1
.end method

.method public d(Ljava/lang/String;)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z

    if-eqz v0, :cond_5

    return-void

    .line 3
    :cond_5
    monitor-enter p0

    .line 4
    :try_start_6
    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->A:Ljava/lang/String;

    .line 5
    monitor-exit p0

    return-void

    :catchall_a
    move-exception p1

    monitor-exit p0
    :try_end_c
    .catchall {:try_start_6 .. :try_end_c} :catchall_a

    throw p1
.end method

.method protected e()V
    .registers 3

    .line 1
    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "DefaultSH"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/d/e;->g:Landroid/os/HandlerThread;

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/e;->g:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 3
    new-instance v0, Landroid/os/Handler;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->g:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/d/e;->h:Landroid/os/Handler;

    return-void
.end method

.method public declared-synchronized e(Ljava/lang/String;)V
    .registers 5

    const-string v0, "Resume Type: "

    monitor-enter p0

    .line 4
    :try_start_3
    iget-boolean v1, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z
    :try_end_5
    .catchall {:try_start_3 .. :try_end_5} :catchall_44

    if-eqz v1, :cond_9

    monitor-exit p0

    return-void

    .line 8
    :cond_9
    :try_start_9
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    .line 9
    const-string/jumbo v2, "type"

    invoke-virtual {v1, v2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 10
    const-string/jumbo p1, "time"

    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/d/k;->b()I

    move-result v2

    invoke-virtual {v1, p1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 11
    const-string p1, "DefaultSH"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/vdocipher/aegis/core/d/l;->c(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2f
    .catch Lorg/json/JSONException; {:try_start_9 .. :try_end_2f} :catch_38
    .catchall {:try_start_9 .. :try_end_2f} :catchall_44

    .line 17
    :try_start_2f
    monitor-enter p0
    :try_end_30
    .catchall {:try_start_2f .. :try_end_30} :catchall_44

    .line 18
    :try_start_30
    iput-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->t:Lorg/json/JSONObject;

    .line 19
    monitor-exit p0
    :try_end_33
    .catchall {:try_start_30 .. :try_end_33} :catchall_35

    monitor-exit p0

    return-void

    :catchall_35
    move-exception p1

    :try_start_36
    monitor-exit p0
    :try_end_37
    .catchall {:try_start_36 .. :try_end_37} :catchall_35

    :try_start_37
    throw p1

    :catch_38
    move-exception p1

    .line 20
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "DefaultSH"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_42
    .catchall {:try_start_37 .. :try_end_42} :catchall_44

    monitor-exit p0

    return-void

    :catchall_44
    move-exception p1

    :try_start_45
    monitor-exit p0
    :try_end_46
    .catchall {:try_start_45 .. :try_end_46} :catchall_44

    throw p1
.end method

.method public f(Ljava/lang/String;)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z

    if-eqz v0, :cond_5

    return-void

    .line 3
    :cond_5
    monitor-enter p0

    .line 4
    :try_start_6
    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/k;->d:Ljava/lang/String;

    .line 5
    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->q:Ljava/lang/String;

    .line 6
    monitor-exit p0

    return-void

    :catchall_c
    move-exception p1

    monitor-exit p0
    :try_end_e
    .catchall {:try_start_6 .. :try_end_e} :catchall_c

    throw p1
.end method

.method protected g()V
    .registers 4

    const-string v0, "sending "

    .line 1
    iget-boolean v1, p0, Lcom/vdocipher/aegis/core/d/k;->f:Z

    if-eqz v1, :cond_7

    return-void

    .line 5
    :cond_7
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/d/e;->e()V

    .line 8
    :try_start_a
    new-instance v1, Lcom/vdocipher/aegis/core/d/d;

    invoke-direct {v1}, Lcom/vdocipher/aegis/core/d/d;-><init>()V

    iput-object v1, p0, Lcom/vdocipher/aegis/core/d/e;->j:Lcom/vdocipher/aegis/core/d/j;

    .line 10
    const-string v1, "DefaultSH"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/k;->b:Lorg/json/JSONObject;

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/d/l;->c(Ljava/lang/String;Ljava/lang/String;)V

    .line 12
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/k;->b:Lorg/json/JSONObject;

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lcom/vdocipher/aegis/core/d/e$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lcom/vdocipher/aegis/core/d/e$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/core/d/e;)V

    invoke-virtual {p0, v0, v1}, Lcom/vdocipher/aegis/core/d/e;->a(Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V
    :try_end_36
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_36} :catch_39
    .catch Ljava/lang/OutOfMemoryError; {:try_start_a .. :try_end_36} :catch_37

    return-void

    :catch_37
    move-exception v0

    goto :goto_3a

    :catch_39
    move-exception v0

    .line 25
    :goto_3a
    new-instance v1, Lcom/vdocipher/aegis/core/d/k$a;

    const-string v2, "Error creating default csh"

    invoke-direct {v1, v2, v0}, Lcom/vdocipher/aegis/core/d/k$a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1
.end method

.method public declared-synchronized g(Ljava/lang/String;)V
    .registers 5

    const-string v0, "save tracks: "

    monitor-enter p0

    .line 26
    :try_start_3
    iget-boolean v1, p0, Lcom/vdocipher/aegis/core/d/e;->n:Z
    :try_end_5
    .catchall {:try_start_3 .. :try_end_5} :catchall_45

    if-eqz v1, :cond_9

    monitor-exit p0

    return-void

    .line 30
    :cond_9
    :try_start_9
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 31
    const-string/jumbo p1, "time"

    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/d/k;->b()I

    move-result v2

    invoke-virtual {v1, p1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 32
    const-string p1, "DefaultSH"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/vdocipher/aegis/core/d/l;->c(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2d
    .catch Lorg/json/JSONException; {:try_start_9 .. :try_end_2d} :catch_39
    .catchall {:try_start_9 .. :try_end_2d} :catchall_45

    .line 38
    :try_start_2d
    monitor-enter p0
    :try_end_2e
    .catchall {:try_start_2d .. :try_end_2e} :catchall_45

    .line 39
    :try_start_2e
    iget-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->H:Ljava/util/ArrayList;

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 40
    monitor-exit p0
    :try_end_34
    .catchall {:try_start_2e .. :try_end_34} :catchall_36

    monitor-exit p0

    return-void

    :catchall_36
    move-exception p1

    :try_start_37
    monitor-exit p0
    :try_end_38
    .catchall {:try_start_37 .. :try_end_38} :catchall_36

    :try_start_38
    throw p1

    :catch_39
    move-exception p1

    .line 41
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "DefaultSH"

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_43
    .catchall {:try_start_38 .. :try_end_43} :catchall_45

    monitor-exit p0

    return-void

    :catchall_45
    move-exception p1

    :try_start_46
    monitor-exit p0
    :try_end_47
    .catchall {:try_start_46 .. :try_end_47} :catchall_45

    throw p1
.end method

.method protected declared-synchronized o(Ljava/lang/String;)V
    .registers 3

    monitor-enter p0

    .line 1
    :try_start_1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/k;->e:Ljava/lang/String;

    .line 2
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/vdocipher/aegis/core/d/a;->b()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/k;->e:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/e;->i:Ljava/lang/String;
    :try_end_1a
    .catchall {:try_start_1 .. :try_end_1a} :catchall_1c

    monitor-exit p0

    return-void

    :catchall_1c
    move-exception p1

    :try_start_1d
    monitor-exit p0
    :try_end_1e
    .catchall {:try_start_1d .. :try_end_1e} :catchall_1c

    throw p1
.end method
