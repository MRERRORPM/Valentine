# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/d/e$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lcom/vdocipher/aegis/core/d/c$a;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/d/e;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/d/e;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/e$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/d/e;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/e$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/core/d/e;

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/d/e;->$r8$lambda$btsGB99i5NpeQ2faTHfH1zauMYQ(Lcom/vdocipher/aegis/core/d/e;Ljava/lang/String;)V

    return-void
.end method
