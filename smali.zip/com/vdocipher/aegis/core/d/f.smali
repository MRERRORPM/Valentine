# classes14.dex

.class public Lcom/vdocipher/aegis/core/d/f;
.super Lcom/vdocipher/aegis/core/d/d;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/d/d;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    .line 1
    invoke-super {p0, p1, p2}, Lcom/vdocipher/aegis/core/d/d;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic a(Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V
    .registers 4

    .line 2
    invoke-super {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/d/d;->a(Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V

    return-void
.end method

.method public bridge synthetic close()V
    .registers 1

    .line 1
    invoke-super {p0}, Lcom/vdocipher/aegis/core/d/d;->close()V

    return-void
.end method

.method public bridge synthetic handleMessage(Landroid/os/Message;)Z
    .registers 2

    .line 1
    invoke-super {p0, p1}, Lcom/vdocipher/aegis/core/d/d;->handleMessage(Landroid/os/Message;)Z

    move-result p1

    return p1
.end method
