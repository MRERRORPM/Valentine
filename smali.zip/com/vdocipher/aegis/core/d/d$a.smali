# classes14.dex

.class Lcom/vdocipher/aegis/core/d/d$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/core/d/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# instance fields
.field a:Ljava/net/URL;

.field b:Ljava/lang/String;

.field c:Lcom/vdocipher/aegis/core/d/c$a;


# direct methods
.method constructor <init>(Ljava/net/URL;Ljava/lang/String;Lcom/vdocipher/aegis/core/d/c$a;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/d$a;->a:Ljava/net/URL;

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/d/d$a;->b:Ljava/lang/String;

    .line 4
    iput-object p3, p0, Lcom/vdocipher/aegis/core/d/d$a;->c:Lcom/vdocipher/aegis/core/d/c$a;

    return-void
.end method
