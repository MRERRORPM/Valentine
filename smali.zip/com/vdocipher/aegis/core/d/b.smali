# classes14.dex

.class public Lcom/vdocipher/aegis/core/d/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:I

.field private final b:[I


# direct methods
.method public constructor <init>(I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p1, p0, Lcom/vdocipher/aegis/core/d/b;->a:I

    .line 3
    div-int/lit8 v0, p1, 0x14

    .line 4
    rem-int/lit8 p1, p1, 0x14

    if-nez p1, :cond_d

    const/4 p1, 0x0

    goto :goto_e

    :cond_d
    const/4 p1, 0x1

    :goto_e
    add-int/2addr v0, p1

    .line 5
    new-array p1, v0, [I

    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/b;->b:[I

    return-void
.end method


# virtual methods
.method public a(I)Landroid/util/Pair;
    .registers 5

    const/4 v0, 0x1

    if-lt p1, v0, :cond_22

    .line 1
    iget v1, p0, Lcom/vdocipher/aegis/core/d/b;->a:I

    if-gt p1, v1, :cond_22

    sub-int/2addr p1, v0

    .line 6
    div-int/lit8 p1, p1, 0x14

    .line 7
    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/b;->b:[I

    aget v2, v1, p1

    add-int/2addr v2, v0

    aput v2, v1, p1

    .line 9
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/core/d/b;->b:[I

    aget p1, v1, p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-static {v0, p1}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object p1

    return-object p1

    .line 10
    :cond_22
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Invalid position: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public a()[I
    .registers 2

    .line 11
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/b;->b:[I

    return-object v0
.end method
