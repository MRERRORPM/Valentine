# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lcom/vdocipher/aegis/core/d/c$a;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/d/g;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/d/g;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/core/d/g;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/g$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/core/d/g;

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/d/g;->$r8$lambda$sL6lmZd0L178Cz8RLe_Pg9eBnbI(Lcom/vdocipher/aegis/core/d/g;Ljava/lang/String;)V

    return-void
.end method
