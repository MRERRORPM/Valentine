# classes14.dex

.class public final Lcom/vdocipher/aegis/core/d/m;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static volatile c:Lcom/vdocipher/aegis/core/d/m;


# instance fields
.field private final a:Ljava/lang/String;

.field private b:Ljava/lang/String;


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/d/m;->d()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/d/m;->a:Ljava/lang/String;

    return-void
.end method

.method public static c()Lcom/vdocipher/aegis/core/d/m;
    .registers 2

    .line 1
    sget-object v0, Lcom/vdocipher/aegis/core/d/m;->c:Lcom/vdocipher/aegis/core/d/m;

    if-nez v0, :cond_17

    .line 2
    const-class v0, Lcom/vdocipher/aegis/core/d/m;

    monitor-enter v0

    .line 3
    :try_start_7
    sget-object v1, Lcom/vdocipher/aegis/core/d/m;->c:Lcom/vdocipher/aegis/core/d/m;

    if-nez v1, :cond_12

    .line 4
    new-instance v1, Lcom/vdocipher/aegis/core/d/m;

    invoke-direct {v1}, Lcom/vdocipher/aegis/core/d/m;-><init>()V

    sput-object v1, Lcom/vdocipher/aegis/core/d/m;->c:Lcom/vdocipher/aegis/core/d/m;

    .line 6
    :cond_12
    monitor-exit v0

    goto :goto_17

    :catchall_14
    move-exception v1

    monitor-exit v0
    :try_end_16
    .catchall {:try_start_7 .. :try_end_16} :catchall_14

    throw v1

    .line 8
    :cond_17
    :goto_17
    sget-object v0, Lcom/vdocipher/aegis/core/d/m;->c:Lcom/vdocipher/aegis/core/d/m;

    return-object v0
.end method

.method private d()Ljava/lang/String;
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/m;->a:Ljava/lang/String;

    if-eqz v0, :cond_5

    return-object v0

    .line 3
    :cond_5
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0

    .line 4
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    div-int/lit8 v1, v1, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    .line 5
    const-string v1, "-"

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public a()V
    .registers 5

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 2
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "-"

    const-string v3, ""

    invoke-virtual {v0, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 3
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    const/16 v2, 0x20

    if-ge v0, v2, :cond_3b

    .line 4
    :goto_26
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    if-ge v0, v2, :cond_46

    .line 5
    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/16 v3, 0xa

    invoke-virtual {v0, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    goto :goto_26

    .line 8
    :cond_3b
    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    invoke-virtual {v1, v3, v2}, Ljava/lang/StringBuilder;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move-object v1, v0

    .line 10
    :cond_46
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/core/d/m;->b:Ljava/lang/String;

    return-void
.end method

.method public b()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/m;->b:Ljava/lang/String;

    if-eqz v0, :cond_5

    return-object v0

    .line 3
    :cond_5
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/d/m;->a()V

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/m;->b:Ljava/lang/String;

    return-object v0
.end method

.method public e()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/m;->a:Ljava/lang/String;

    return-object v0
.end method
