# classes14.dex

.class public Lcom/vdocipher/aegis/core/d/h;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static c:Lcom/vdocipher/aegis/core/d/h;


# instance fields
.field private final a:Ljava/util/Map;

.field private b:Ljava/util/Map;


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/d/h;->a:Ljava/util/Map;

    .line 6
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/d/h;->b:Ljava/util/Map;

    return-void
.end method

.method public static a()Lcom/vdocipher/aegis/core/d/h;
    .registers 1

    .line 1
    sget-object v0, Lcom/vdocipher/aegis/core/d/h;->c:Lcom/vdocipher/aegis/core/d/h;

    if-nez v0, :cond_b

    .line 2
    new-instance v0, Lcom/vdocipher/aegis/core/d/h;

    invoke-direct {v0}, Lcom/vdocipher/aegis/core/d/h;-><init>()V

    sput-object v0, Lcom/vdocipher/aegis/core/d/h;->c:Lcom/vdocipher/aegis/core/d/h;

    .line 5
    :cond_b
    sget-object v0, Lcom/vdocipher/aegis/core/d/h;->c:Lcom/vdocipher/aegis/core/d/h;

    return-object v0
.end method

.method private a(Landroid/content/Context;Ljava/lang/String;)V
    .registers 3

    .line 59
    invoke-static {p1}, Lcom/vdocipher/aegis/core/k/c;->b(Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/c;

    move-result-object p1

    .line 60
    invoke-virtual {p1, p2}, Lcom/vdocipher/aegis/core/k/c;->f(Ljava/lang/String;)V

    return-void
.end method

.method private a(Landroid/content/Context;Ljava/lang/String;Lcom/vdocipher/aegis/core/k/d;Lcom/vdocipher/aegis/offline/DownloadRequest;Ljava/lang/String;)V
    .registers 15

    .line 6
    iget-object v0, p0, Lcom/vdocipher/aegis/core/d/h;->a:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3c

    if-eqz p3, :cond_3c

    .line 7
    const-string v0, "dss.lictokenparams"

    invoke-virtual {p3, v0}, Lcom/vdocipher/aegis/core/k/d;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    if-eqz p3, :cond_3c

    .line 10
    :try_start_12
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 11
    const-string p3, "playbackInfo"

    invoke-virtual {v0, p3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 12
    const-string/jumbo p3, "token"

    invoke-virtual {v0, p3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 13
    invoke-static {p1}, Lcom/vdocipher/aegis/core/d/c;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v7, p4

    move-object v8, p5

    invoke-direct/range {v1 .. v8}, Lcom/vdocipher/aegis/core/d/h;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/offline/DownloadRequest;Ljava/lang/String;)V
    :try_end_30
    .catch Lorg/json/JSONException; {:try_start_12 .. :try_end_30} :catch_31

    return-void

    :catch_31
    move-exception v0

    move-object p1, v0

    .line 15
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DownloadSessionManager"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3c
    return-void
.end method

.method private a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/offline/DownloadRequest;Ljava/lang/String;)V
    .registers 17

    if-eqz p6, :cond_b

    .line 16
    iget-object v0, p6, Lcom/vdocipher/aegis/offline/DownloadRequest;->downloadSelections:Lcom/vdocipher/aegis/offline/DownloadSelections;

    iget-object v0, v0, Lcom/vdocipher/aegis/offline/DownloadSelections;->downloadOptions:Lcom/vdocipher/aegis/offline/DownloadOptions;

    check-cast v0, Lcom/vdocipher/aegis/core/k/a;

    .line 17
    iget-object v0, v0, Lcom/vdocipher/aegis/core/k/a;->h:Ljava/lang/String;

    goto :goto_c

    :cond_b
    const/4 v0, 0x0

    :goto_c
    move-object v7, v0

    const/4 v8, 0x0

    move-object v0, p1

    move-object v1, p2

    move-object v2, p3

    move-object v3, p4

    move-object v4, p5

    move-object v5, p6

    move-object/from16 v6, p7

    .line 20
    :try_start_16
    invoke-static/range {v0 .. v8}, Lcom/vdocipher/aegis/core/d/c;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/offline/DownloadRequest;Ljava/lang/String;Ljava/lang/String;Z)Lcom/vdocipher/aegis/core/d/k;

    move-result-object v0

    .line 21
    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/h;->a:Ljava/util/Map;

    invoke-interface {v2, p2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1f
    .catch Lcom/vdocipher/aegis/core/d/k$a; {:try_start_16 .. :try_end_1f} :catch_20

    return-void

    :catch_20
    move-exception v0

    .line 23
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "DownloadSessionManager"

    invoke-static {v2, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public declared-synchronized a(Landroid/content/Context;Landroidx/media3/exoplayer/offline/Download;Ljava/lang/String;Lcom/vdocipher/aegis/offline/DownloadRequest;)V
    .registers 13

    const-string v0, "save event "

    monitor-enter p0

    .line 24
    :try_start_3
    iget-object v1, p2, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    iget-object v4, v1, Landroidx/media3/exoplayer/offline/DownloadRequest;->id:Ljava/lang/String;

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/k/d;->a(Landroidx/media3/exoplayer/offline/Download;Landroid/content/Context;)Lcom/vdocipher/aegis/core/k/d;

    move-result-object v5

    invoke-static {p2}, Lcom/vdocipher/aegis/offline/DownloadStatus;->getDownloadStatus(Landroidx/media3/exoplayer/offline/Download;)Lcom/vdocipher/aegis/offline/DownloadStatus;

    move-result-object v1

    iget-object v7, v1, Lcom/vdocipher/aegis/offline/DownloadStatus;->localStorageFolder:Ljava/lang/String;
    :try_end_11
    .catchall {:try_start_3 .. :try_end_11} :catchall_bf

    move-object v2, p0

    move-object v3, p1

    move-object v6, p4

    :try_start_14
    invoke-direct/range {v2 .. v7}, Lcom/vdocipher/aegis/core/d/h;->a(Landroid/content/Context;Ljava/lang/String;Lcom/vdocipher/aegis/core/k/d;Lcom/vdocipher/aegis/offline/DownloadRequest;Ljava/lang/String;)V

    .line 25
    invoke-static {p2}, Lcom/vdocipher/aegis/offline/DownloadStatus;->getDownloadStatus(Landroidx/media3/exoplayer/offline/Download;)Lcom/vdocipher/aegis/offline/DownloadStatus;

    move-result-object p1
    :try_end_1b
    .catchall {:try_start_14 .. :try_end_1b} :catchall_c4

    .line 28
    :try_start_1b
    new-instance p4, Lorg/json/JSONObject;

    invoke-direct {p4}, Lorg/json/JSONObject;-><init>()V

    .line 29
    const-string/jumbo v1, "status"

    iget v4, p1, Lcom/vdocipher/aegis/offline/DownloadStatus;->status:I

    invoke-virtual {p4, v1, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 30
    const-string/jumbo v1, "totalSizeBytes"

    iget-wide v4, p1, Lcom/vdocipher/aegis/offline/DownloadStatus;->totalSizeBytes:J

    invoke-virtual {p4, v1, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 31
    const-string v1, "bytesDownloaded"

    iget-wide v4, p1, Lcom/vdocipher/aegis/offline/DownloadStatus;->bytesDownloaded:J

    invoke-virtual {p4, v1, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 32
    const-string v1, "downloadPercent"

    iget v4, p1, Lcom/vdocipher/aegis/offline/DownloadStatus;->downloadPercent:I

    invoke-virtual {p4, v1, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 33
    const-string v1, "lastModifiedTimestamp"

    iget-wide v4, p1, Lcom/vdocipher/aegis/offline/DownloadStatus;->lastModifiedTimestamp:J

    invoke-virtual {p4, v1, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 36
    const-string v1, "DownloadSessionManager"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/vdocipher/aegis/core/d/l;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 37
    iget-object p1, p1, Lcom/vdocipher/aegis/offline/DownloadStatus;->mediaInfo:Lcom/vdocipher/aegis/media/MediaInfo;

    iget-object p1, p1, Lcom/vdocipher/aegis/media/MediaInfo;->mediaId:Ljava/lang/String;

    .line 38
    iget-object v0, v2, Lcom/vdocipher/aegis/core/d/h;->a:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/aegis/core/d/k;

    if-eqz v0, :cond_8e

    .line 40
    invoke-virtual {p4}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p4

    invoke-virtual {v0, p3, p4}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 41
    iget-object p4, v2, Lcom/vdocipher/aegis/core/d/h;->b:Ljava/util/Map;

    invoke-interface {p4, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/ArrayList;

    if-eqz p1, :cond_8e

    .line 43
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p4

    const/4 v1, 0x0

    :goto_7a
    if-ge v1, p4, :cond_8e

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    add-int/lit8 v1, v1, 0x1

    check-cast v4, Lorg/json/JSONObject;

    .line 44
    const-string v5, "metaFailed"

    invoke-virtual {v4}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v5, v4}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_7a

    .line 49
    :cond_8e
    const-string p1, "downloadRemoved"

    invoke-virtual {p3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_b0

    .line 51
    iget-object p1, v2, Lcom/vdocipher/aegis/core/d/h;->a:Ljava/util/Map;

    iget-object p3, p2, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    iget-object p3, p3, Landroidx/media3/exoplayer/offline/DownloadRequest;->id:Ljava/lang/String;

    invoke-interface {p1, p3}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/aegis/core/d/k;

    if-eqz p1, :cond_a7

    .line 52
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/d/k;->a()V

    .line 54
    :cond_a7
    iget-object p1, p2, Landroidx/media3/exoplayer/offline/Download;->request:Landroidx/media3/exoplayer/offline/DownloadRequest;

    iget-object p1, p1, Landroidx/media3/exoplayer/offline/DownloadRequest;->id:Ljava/lang/String;

    invoke-direct {p0, v3, p1}, Lcom/vdocipher/aegis/core/d/h;->a(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_ae
    .catch Lorg/json/JSONException; {:try_start_1b .. :try_end_ae} :catch_b2
    .catchall {:try_start_1b .. :try_end_ae} :catchall_c4

    monitor-exit p0

    return-void

    :cond_b0
    monitor-exit p0

    return-void

    :catch_b2
    move-exception v0

    move-object p1, v0

    .line 58
    :try_start_b4
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DownloadSessionManager"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_bd
    .catchall {:try_start_b4 .. :try_end_bd} :catchall_c4

    monitor-exit p0

    return-void

    :catchall_bf
    move-exception v0

    move-object v2, p0

    :goto_c1
    move-object p1, v0

    :try_start_c2
    monitor-exit p0
    :try_end_c3
    .catchall {:try_start_c2 .. :try_end_c3} :catchall_c4

    throw p1

    :catchall_c4
    move-exception v0

    goto :goto_c1
.end method

.method public declared-synchronized a(Landroid/content/Context;Lcom/vdocipher/aegis/offline/DownloadStatus;Ljava/lang/String;Lcom/vdocipher/aegis/core/k/d;Lcom/vdocipher/aegis/offline/DownloadRequest;Ljava/lang/String;)V
    .registers 15

    const-string v0, "save event "

    monitor-enter p0

    .line 61
    :try_start_3
    iget-object v1, p2, Lcom/vdocipher/aegis/offline/DownloadStatus;->mediaInfo:Lcom/vdocipher/aegis/media/MediaInfo;

    iget-object v4, v1, Lcom/vdocipher/aegis/media/MediaInfo;->mediaId:Ljava/lang/String;
    :try_end_7
    .catchall {:try_start_3 .. :try_end_7} :catchall_68

    move-object v2, p0

    move-object v3, p1

    move-object v5, p4

    move-object v6, p5

    move-object v7, p6

    :try_start_c
    invoke-direct/range {v2 .. v7}, Lcom/vdocipher/aegis/core/d/h;->a(Landroid/content/Context;Ljava/lang/String;Lcom/vdocipher/aegis/core/k/d;Lcom/vdocipher/aegis/offline/DownloadRequest;Ljava/lang/String;)V
    :try_end_f
    .catchall {:try_start_c .. :try_end_f} :catchall_6d

    .line 65
    :try_start_f
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    .line 66
    const-string/jumbo p4, "status"

    iget p5, p2, Lcom/vdocipher/aegis/offline/DownloadStatus;->status:I

    invoke-virtual {p1, p4, p5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 67
    const-string p4, "reason"

    iget p5, p2, Lcom/vdocipher/aegis/offline/DownloadStatus;->reason:I

    invoke-virtual {p1, p4, p5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 68
    const-string p4, "reasonDescription"

    iget-object p5, p2, Lcom/vdocipher/aegis/offline/DownloadStatus;->reasonDescription:Ljava/lang/String;

    invoke-virtual {p1, p4, p5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 69
    const-string p4, "lastModifiedTimestamp"

    iget-wide p5, p2, Lcom/vdocipher/aegis/offline/DownloadStatus;->lastModifiedTimestamp:J

    invoke-virtual {p1, p4, p5, p6}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 72
    const-string p4, "DownloadSessionManager"

    new-instance p5, Ljava/lang/StringBuilder;

    invoke-direct {p5, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p5, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p5

    invoke-static {p4, p5}, Lcom/vdocipher/aegis/core/d/l;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 73
    iget-object p4, v2, Lcom/vdocipher/aegis/core/d/h;->a:Ljava/util/Map;

    iget-object p2, p2, Lcom/vdocipher/aegis/offline/DownloadStatus;->mediaInfo:Lcom/vdocipher/aegis/media/MediaInfo;

    iget-object p2, p2, Lcom/vdocipher/aegis/media/MediaInfo;->mediaId:Ljava/lang/String;

    invoke-interface {p4, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/aegis/core/d/k;

    if-eqz p2, :cond_59

    .line 75
    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p3, p1}, Lcom/vdocipher/aegis/core/d/k;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_57
    .catch Lorg/json/JSONException; {:try_start_f .. :try_end_57} :catch_5b
    .catchall {:try_start_f .. :try_end_57} :catchall_6d

    monitor-exit p0

    return-void

    :cond_59
    monitor-exit p0

    return-void

    :catch_5b
    move-exception v0

    move-object p1, v0

    .line 79
    :try_start_5d
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DownloadSessionManager"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_66
    .catchall {:try_start_5d .. :try_end_66} :catchall_6d

    monitor-exit p0

    return-void

    :catchall_68
    move-exception v0

    move-object v2, p0

    :goto_6a
    move-object p1, v0

    :try_start_6b
    monitor-exit p0
    :try_end_6c
    .catchall {:try_start_6b .. :try_end_6c} :catchall_6d

    throw p1

    :catchall_6d
    move-exception v0

    goto :goto_6a
.end method

.method public a(Ljava/lang/String;ILjava/lang/String;ZLjava/lang/String;)V
    .registers 8

    .line 80
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 81
    const-string v1, "metaUrl"

    invoke-virtual {v0, v1, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 82
    const-string/jumbo p3, "statusCode"

    invoke-virtual {v0, p3, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 83
    const-string p2, "isCronetEnabled"

    invoke-virtual {v0, p2, p4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 84
    const-string/jumbo p2, "stackTrace"

    invoke-virtual {v0, p2, p5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 86
    monitor-enter p0
    :try_end_1c
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_1c} :catch_36

    .line 87
    :try_start_1c
    iget-object p2, p0, Lcom/vdocipher/aegis/core/d/h;->b:Ljava/util/Map;

    new-instance p3, Ljava/util/ArrayList;

    invoke-direct {p3}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p2, p1, p3}, Ljava/util/Map;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/ArrayList;

    .line 88
    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 89
    iget-object p3, p0, Lcom/vdocipher/aegis/core/d/h;->b:Ljava/util/Map;

    invoke-interface {p3, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 90
    monitor-exit p0

    return-void

    :catchall_33
    move-exception p1

    monitor-exit p0
    :try_end_35
    .catchall {:try_start_1c .. :try_end_35} :catchall_33

    :try_start_35
    throw p1
    :try_end_36
    .catch Lorg/json/JSONException; {:try_start_35 .. :try_end_36} :catch_36

    :catch_36
    move-exception p1

    .line 93
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DownloadSessionManager"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    .line 94
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 95
    const-string v1, "cause"

    invoke-virtual {v0, v1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 96
    const-string p2, "invalidMeta"

    invoke-virtual {v0, p2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 98
    monitor-enter p0
    :try_end_10
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_10} :catch_2a

    .line 99
    :try_start_10
    iget-object p2, p0, Lcom/vdocipher/aegis/core/d/h;->b:Ljava/util/Map;

    new-instance p3, Ljava/util/ArrayList;

    invoke-direct {p3}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p2, p1, p3}, Ljava/util/Map;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/ArrayList;

    .line 100
    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 101
    iget-object p3, p0, Lcom/vdocipher/aegis/core/d/h;->b:Ljava/util/Map;

    invoke-interface {p3, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 102
    monitor-exit p0

    return-void

    :catchall_27
    move-exception p1

    monitor-exit p0
    :try_end_29
    .catchall {:try_start_10 .. :try_end_29} :catchall_27

    :try_start_29
    throw p1
    :try_end_2a
    .catch Lorg/json/JSONException; {:try_start_29 .. :try_end_2a} :catch_2a

    :catch_2a
    move-exception p1

    .line 104
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "DownloadSessionManager"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
