# classes14.dex

.class public Lcom/vdocipher/aegis/core/d/i;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static volatile b:Lcom/vdocipher/aegis/core/d/i;


# instance fields
.field a:Ljava/util/concurrent/ConcurrentHashMap;


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/core/d/i;->a:Ljava/util/concurrent/ConcurrentHashMap;

    return-void
.end method

.method public static a()Lcom/vdocipher/aegis/core/d/i;
    .registers 2

    .line 1
    sget-object v0, Lcom/vdocipher/aegis/core/d/i;->b:Lcom/vdocipher/aegis/core/d/i;

    if-nez v0, :cond_17

    .line 2
    const-class v0, Lcom/vdocipher/aegis/core/d/i;

    monitor-enter v0

    .line 3
    :try_start_7
    sget-object v1, Lcom/vdocipher/aegis/core/d/i;->b:Lcom/vdocipher/aegis/core/d/i;

    if-nez v1, :cond_12

    .line 4
    new-instance v1, Lcom/vdocipher/aegis/core/d/i;

    invoke-direct {v1}, Lcom/vdocipher/aegis/core/d/i;-><init>()V

    sput-object v1, Lcom/vdocipher/aegis/core/d/i;->b:Lcom/vdocipher/aegis/core/d/i;

    .line 6
    :cond_12
    monitor-exit v0

    goto :goto_17

    :catchall_14
    move-exception v1

    monitor-exit v0
    :try_end_16
    .catchall {:try_start_7 .. :try_end_16} :catchall_14

    throw v1

    .line 8
    :cond_17
    :goto_17
    sget-object v0, Lcom/vdocipher/aegis/core/d/i;->b:Lcom/vdocipher/aegis/core/d/i;

    return-object v0
.end method


# virtual methods
.method public a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZ)Lcom/vdocipher/aegis/core/d/k;
    .registers 17

    xor-int/lit8 v4, p6, 0x1

    const/4 v8, 0x0

    .line 9
    :try_start_3
    invoke-static {p1}, Lcom/vdocipher/aegis/core/d/c;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v5

    move-object v0, p1

    move-object v1, p2

    move-object v3, p3

    move-object v2, p4

    move-object v6, p5

    move/from16 v7, p7

    .line 10
    invoke-static/range {v0 .. v7}, Lcom/vdocipher/aegis/core/d/c;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Z)Lcom/vdocipher/aegis/core/d/k;

    move-result-object v8

    .line 12
    new-instance p1, Landroid/util/Pair;

    invoke-static {p6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p3

    invoke-direct {p1, p2, p3}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 13
    iget-object p2, p0, Lcom/vdocipher/aegis/core/d/i;->a:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {p2, p1, v8}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_20
    .catch Lcom/vdocipher/aegis/core/d/k$a; {:try_start_3 .. :try_end_20} :catch_21

    return-object v8

    :catch_21
    move-exception v0

    move-object p1, v0

    .line 15
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "PSManager"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-object v8
.end method

.method public a(Ljava/lang/String;Z)Lcom/vdocipher/aegis/core/d/k;
    .registers 4

    .line 16
    new-instance v0, Landroid/util/Pair;

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    invoke-direct {v0, p1, p2}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 17
    iget-object p1, p0, Lcom/vdocipher/aegis/core/d/i;->a:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {p1, v0}, Ljava/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1a

    .line 18
    iget-object p1, p0, Lcom/vdocipher/aegis/core/d/i;->a:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {p1, v0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/aegis/core/d/k;

    return-object p1

    :cond_1a
    const/4 p1, 0x0

    return-object p1
.end method

.method public a(Lcom/vdocipher/aegis/core/d/k;)V
    .registers 5

    .line 19
    iget-object v0, p1, Lcom/vdocipher/aegis/core/d/k;->c:Ljava/lang/String;

    .line 20
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/d/k;->a()V

    .line 22
    iget-object p1, p0, Lcom/vdocipher/aegis/core/d/i;->a:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {p1}, Ljava/util/concurrent/ConcurrentHashMap;->keySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_f
    :goto_f
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2b

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/util/Pair;

    .line 23
    iget-object v2, v1, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_f

    .line 24
    iget-object v2, p0, Lcom/vdocipher/aegis/core/d/i;->a:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v2, v1}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_f

    :cond_2b
    return-void
.end method

.method protected clone()Ljava/lang/Object;
    .registers 2

    .line 1
    new-instance v0, Ljava/lang/CloneNotSupportedException;

    invoke-direct {v0}, Ljava/lang/CloneNotSupportedException;-><init>()V

    throw v0
.end method
