# classes14.dex

.class public abstract Lcom/vdocipher/aegis/core/d/c;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/core/d/c$a;
    }
.end annotation


# direct methods
.method public static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/offline/DownloadRequest;Ljava/lang/String;Ljava/lang/String;Z)Lcom/vdocipher/aegis/core/d/k;
    .registers 20

    .line 5
    new-instance v0, Lcom/vdocipher/aegis/core/d/g;

    const/4 v1, 0x0

    move-object/from16 v2, p7

    .line 7
    invoke-static {p2, p3, v1, v2}, Lcom/vdocipher/aegis/core/d/c;->a(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    .line 8
    invoke-static {p0}, Lcom/vdocipher/aegis/core/d/c;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v5

    invoke-static {p0}, Lcom/vdocipher/aegis/core/d/c;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    const/4 v4, 0x0

    move-object v1, p0

    move-object v3, p1

    move-object v7, p4

    move-object/from16 v8, p5

    move-object/from16 v9, p6

    move/from16 v10, p8

    invoke-direct/range {v0 .. v10}, Lcom/vdocipher/aegis/core/d/g;-><init>(Landroid/content/Context;Lorg/json/JSONObject;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/vdocipher/aegis/offline/DownloadRequest;Ljava/lang/String;Z)V

    return-object v0
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Z)Lcom/vdocipher/aegis/core/d/k;
    .registers 17

    .line 1
    new-instance v0, Lcom/vdocipher/aegis/core/d/e;

    .line 3
    invoke-static {p2, p3, p4, p6}, Lcom/vdocipher/aegis/core/d/c;->a(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    .line 4
    invoke-static {p0}, Lcom/vdocipher/aegis/core/d/l;->b(Landroid/content/Context;)Lorg/json/JSONObject;

    move-result-object v4

    invoke-static {p0}, Lcom/vdocipher/aegis/core/d/c;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v5

    invoke-static {p0}, Lcom/vdocipher/aegis/core/d/c;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    move-object v1, p0

    move-object v3, p1

    move-object v7, p5

    move/from16 v8, p7

    invoke-direct/range {v0 .. v8}, Lcom/vdocipher/aegis/core/d/e;-><init>(Landroid/content/Context;Lorg/json/JSONObject;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    return-object v0
.end method

.method public static a()Ljava/lang/String;
    .registers 1

    .line 29
    invoke-static {}, Lcom/vdocipher/aegis/core/d/m;->c()Lcom/vdocipher/aegis/core/d/m;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/d/m;->b()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static a(Landroid/content/Context;)Ljava/lang/String;
    .registers 3

    if-nez p0, :cond_5

    .line 26
    const-string p0, "android:NA"

    return-object p0

    .line 27
    :cond_5
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    .line 28
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "android:"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    if-nez p0, :cond_14

    const-string p0, "NA"

    :cond_14
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private static a(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)Lorg/json/JSONObject;
    .registers 8

    const-string/jumbo v0, "token"

    const-string v1, "otp"

    .line 9
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    if-eqz p2, :cond_10

    .line 11
    :try_start_c
    const-string/jumbo p2, "streaming"

    goto :goto_12

    :cond_10
    const-string p2, "offline"

    .line 12
    :goto_12
    const-string v3, "playbackInfo"

    invoke-virtual {v2, v3, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    if-eqz p1, :cond_2e

    .line 14
    invoke-static {p1}, Lcom/vdocipher/aegis/core/t/d;->i(Ljava/lang/String;)Z

    move-result p0
    :try_end_1d
    .catch Lorg/json/JSONException; {:try_start_c .. :try_end_1d} :catch_3b

    const-string v3, "authType"

    if-eqz p0, :cond_28

    .line 15
    :try_start_21
    invoke-virtual {v2, v0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 16
    invoke-virtual {v2, v3, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_2e

    .line 18
    :cond_28
    invoke-virtual {v2, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 19
    invoke-virtual {v2, v3, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 22
    :cond_2e
    :goto_2e
    const-string/jumbo p0, "sourceType"

    invoke-virtual {v2, p0, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 23
    const-string/jumbo p0, "theme"

    invoke-virtual {v2, p0, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_3a
    .catch Lorg/json/JSONException; {:try_start_21 .. :try_end_3a} :catch_3b

    return-object v2

    :catch_3b
    move-exception p0

    .line 25
    invoke-static {p0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "CSEI"

    invoke-static {p1, p0}, Lcom/vdocipher/aegis/core/d/l;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-object v2
.end method

.method public static b(Landroid/content/Context;)Ljava/lang/String;
    .registers 4

    const-string v0, ""

    if-nez p0, :cond_5

    return-object v0

    .line 2
    :cond_5
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    .line 5
    :try_start_9
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    invoke-virtual {v1, p0, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0
    :try_end_12
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_9 .. :try_end_12} :catch_13

    goto :goto_22

    :catch_13
    move-exception p0

    .line 7
    const-class v1, Lcom/vdocipher/aegis/core/d/c;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-static {p0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p0, 0x0

    :goto_22
    if-nez p0, :cond_25

    goto :goto_27

    .line 9
    :cond_25
    iget-object v0, p0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    :goto_27
    return-object v0
.end method

.method public static b()Lorg/json/JSONObject;
    .registers 5

    .line 10
    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Configuration;->getLocales()Landroid/os/LocaleList;

    move-result-object v0

    .line 11
    new-instance v1, Lorg/json/JSONArray;

    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    const/4 v2, 0x0

    move v3, v2

    .line 12
    :goto_13
    invoke-virtual {v0}, Landroid/os/LocaleList;->size()I

    move-result v4

    if-ge v3, v4, :cond_27

    .line 13
    invoke-virtual {v0, v3}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v3, v3, 0x1

    goto :goto_13

    .line 15
    :cond_27
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    .line 17
    :try_start_2c
    invoke-virtual {v0}, Landroid/os/LocaleList;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_3f

    .line 18
    const-string v4, "preferred"

    invoke-virtual {v0, v2}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v4, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 20
    :cond_3f
    const-string v0, "known"

    invoke-virtual {v3, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_44
    .catch Lorg/json/JSONException; {:try_start_2c .. :try_end_44} :catch_44

    :catch_44
    return-object v3
.end method

.method private static c()Ljava/lang/String;
    .registers 3

    .line 14
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0

    .line 15
    const-string v1, "-"

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static c(Landroid/content/Context;)Ljava/lang/String;
    .registers 5

    if-eqz p0, :cond_1f

    .line 1
    invoke-static {p0}, Lcom/vdocipher/aegis/core/t/c;->a(Landroid/content/Context;)Lcom/vdocipher/aegis/core/t/c;

    move-result-object p0

    .line 2
    const-string v0, "clipstat_viewer"

    invoke-virtual {p0, v0}, Lcom/vdocipher/aegis/core/t/c;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_17

    .line 3
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/16 v3, 0x20

    if-ne v2, v3, :cond_17

    return-object v1

    .line 8
    :cond_17
    invoke-static {}, Lcom/vdocipher/aegis/core/d/c;->c()Ljava/lang/String;

    move-result-object v1

    .line 12
    invoke-virtual {p0, v0, v1}, Lcom/vdocipher/aegis/core/t/c;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-object v1

    .line 13
    :cond_1f
    new-instance p0, Ljava/lang/NullPointerException;

    const-string v0, "Context cannot be null"

    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static d()Ljava/lang/String;
    .registers 1

    .line 1
    invoke-static {}, Lcom/vdocipher/aegis/core/d/m;->c()Lcom/vdocipher/aegis/core/d/m;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/d/m;->e()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
