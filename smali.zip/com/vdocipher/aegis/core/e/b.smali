# classes14.dex

.class public final Lcom/vdocipher/aegis/core/e/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field private final a:Landroid/widget/LinearLayout;

.field public final b:Landroidx/appcompat/widget/AppCompatImageView;

.field public final c:Landroidx/appcompat/widget/AppCompatImageView;

.field public final d:Landroidx/appcompat/widget/AppCompatImageView;

.field public final e:Landroidx/appcompat/widget/AppCompatImageView;

.field public final f:Landroid/widget/LinearLayout;

.field public final g:Landroidx/appcompat/widget/AppCompatTextView;

.field public final h:Landroidx/appcompat/widget/AppCompatTextView;

.field public final i:Landroidx/appcompat/widget/AppCompatTextView;

.field public final j:Landroidx/appcompat/widget/AppCompatTextView;

.field public final k:Landroidx/appcompat/widget/AppCompatTextView;

.field public final l:Landroidx/appcompat/widget/AppCompatTextView;

.field public final m:Landroidx/appcompat/widget/AppCompatTextView;

.field public final n:Landroidx/appcompat/widget/AppCompatTextView;

.field public final o:Landroidx/appcompat/widget/AppCompatTextView;

.field public final p:Landroidx/appcompat/widget/AppCompatTextView;

.field public final q:Landroidx/appcompat/widget/AppCompatTextView;

.field public final r:Landroidx/appcompat/widget/AppCompatTextView;

.field public final s:Landroidx/appcompat/widget/AppCompatTextView;

.field public final t:Landroidx/appcompat/widget/AppCompatTextView;

.field public final u:Landroidx/appcompat/widget/AppCompatTextView;


# direct methods
.method private constructor <init>(Landroid/widget/LinearLayout;Landroidx/appcompat/widget/AppCompatImageView;Landroidx/appcompat/widget/AppCompatImageView;Landroidx/appcompat/widget/AppCompatImageView;Landroidx/appcompat/widget/AppCompatImageView;Landroid/widget/LinearLayout;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;)V
    .registers 22

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/e/b;->a:Landroid/widget/LinearLayout;

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/e/b;->b:Landroidx/appcompat/widget/AppCompatImageView;

    .line 4
    iput-object p3, p0, Lcom/vdocipher/aegis/core/e/b;->c:Landroidx/appcompat/widget/AppCompatImageView;

    .line 5
    iput-object p4, p0, Lcom/vdocipher/aegis/core/e/b;->d:Landroidx/appcompat/widget/AppCompatImageView;

    .line 6
    iput-object p5, p0, Lcom/vdocipher/aegis/core/e/b;->e:Landroidx/appcompat/widget/AppCompatImageView;

    .line 7
    iput-object p6, p0, Lcom/vdocipher/aegis/core/e/b;->f:Landroid/widget/LinearLayout;

    .line 8
    iput-object p7, p0, Lcom/vdocipher/aegis/core/e/b;->g:Landroidx/appcompat/widget/AppCompatTextView;

    .line 9
    iput-object p8, p0, Lcom/vdocipher/aegis/core/e/b;->h:Landroidx/appcompat/widget/AppCompatTextView;

    .line 10
    iput-object p9, p0, Lcom/vdocipher/aegis/core/e/b;->i:Landroidx/appcompat/widget/AppCompatTextView;

    .line 11
    iput-object p10, p0, Lcom/vdocipher/aegis/core/e/b;->j:Landroidx/appcompat/widget/AppCompatTextView;

    .line 12
    iput-object p11, p0, Lcom/vdocipher/aegis/core/e/b;->k:Landroidx/appcompat/widget/AppCompatTextView;

    .line 13
    iput-object p12, p0, Lcom/vdocipher/aegis/core/e/b;->l:Landroidx/appcompat/widget/AppCompatTextView;

    .line 14
    iput-object p13, p0, Lcom/vdocipher/aegis/core/e/b;->m:Landroidx/appcompat/widget/AppCompatTextView;

    .line 15
    iput-object p14, p0, Lcom/vdocipher/aegis/core/e/b;->n:Landroidx/appcompat/widget/AppCompatTextView;

    .line 16
    iput-object p15, p0, Lcom/vdocipher/aegis/core/e/b;->o:Landroidx/appcompat/widget/AppCompatTextView;

    move-object/from16 p1, p16

    .line 17
    iput-object p1, p0, Lcom/vdocipher/aegis/core/e/b;->p:Landroidx/appcompat/widget/AppCompatTextView;

    move-object/from16 p1, p17

    .line 18
    iput-object p1, p0, Lcom/vdocipher/aegis/core/e/b;->q:Landroidx/appcompat/widget/AppCompatTextView;

    move-object/from16 p1, p18

    .line 19
    iput-object p1, p0, Lcom/vdocipher/aegis/core/e/b;->r:Landroidx/appcompat/widget/AppCompatTextView;

    move-object/from16 p1, p19

    .line 20
    iput-object p1, p0, Lcom/vdocipher/aegis/core/e/b;->s:Landroidx/appcompat/widget/AppCompatTextView;

    move-object/from16 p1, p20

    .line 21
    iput-object p1, p0, Lcom/vdocipher/aegis/core/e/b;->t:Landroidx/appcompat/widget/AppCompatTextView;

    move-object/from16 p1, p21

    .line 22
    iput-object p1, p0, Lcom/vdocipher/aegis/core/e/b;->u:Landroidx/appcompat/widget/AppCompatTextView;

    return-void
.end method

.method public static a(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/vdocipher/aegis/core/e/b;
    .registers 5

    .line 2
    sget v0, Lcom/vdocipher/aegis/R$layout;->vdo_fragment_bottomsheet_clear_storage:I

    const/4 v1, 0x0

    invoke-virtual {p0, v0, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    if-eqz p2, :cond_c

    .line 4
    invoke-virtual {p1, p0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 6
    :cond_c
    invoke-static {p0}, Lcom/vdocipher/aegis/core/e/b;->a(Landroid/view/View;)Lcom/vdocipher/aegis/core/e/b;

    move-result-object p0

    return-object p0
.end method

.method public static a(Landroid/view/View;)Lcom/vdocipher/aegis/core/e/b;
    .registers 26

    move-object/from16 v0, p0

    .line 7
    sget v1, Lcom/vdocipher/aegis/R$id;->ic_close:I

    .line 8
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v5, v2

    check-cast v5, Landroidx/appcompat/widget/AppCompatImageView;

    if-eqz v5, :cond_f0

    .line 13
    sget v1, Lcom/vdocipher/aegis/R$id;->ic_delete_all:I

    .line 14
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v6, v2

    check-cast v6, Landroidx/appcompat/widget/AppCompatImageView;

    if-eqz v6, :cond_f0

    .line 19
    sget v1, Lcom/vdocipher/aegis/R$id;->ic_delete_last_7:I

    .line 20
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v7, v2

    check-cast v7, Landroidx/appcompat/widget/AppCompatImageView;

    if-eqz v7, :cond_f0

    .line 25
    sget v1, Lcom/vdocipher/aegis/R$id;->ic_delete_last_one_month:I

    .line 26
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v8, v2

    check-cast v8, Landroidx/appcompat/widget/AppCompatImageView;

    if-eqz v8, :cond_f0

    .line 31
    sget v1, Lcom/vdocipher/aegis/R$id;->ll_statistics:I

    .line 32
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v9, v2

    check-cast v9, Landroid/widget/LinearLayout;

    if-eqz v9, :cond_f0

    .line 37
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_delete_all_videos:I

    .line 38
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v10, v2

    check-cast v10, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v10, :cond_f0

    .line 43
    sget v1, Lcom/vdocipher/aegis/R$id;->tvDeleteUnusedVideoInAMonth:I

    .line 44
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v11, v2

    check-cast v11, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v11, :cond_f0

    .line 49
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_files_count:I

    .line 50
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v12, v2

    check-cast v12, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v12, :cond_f0

    .line 55
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_last_month_count:I

    .line 56
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v13, v2

    check-cast v13, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v13, :cond_f0

    .line 61
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_last_seven_days:I

    .line 62
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v14, v2

    check-cast v14, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v14, :cond_f0

    .line 67
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_last_seven_days_count:I

    .line 68
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v15, v2

    check-cast v15, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v15, :cond_f0

    .line 73
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_saved_files_count:I

    .line 74
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v16, v2

    check-cast v16, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v16, :cond_f0

    .line 79
    sget v1, Lcom/vdocipher/aegis/R$id;->tvSavedVideo:I

    .line 80
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v17, v2

    check-cast v17, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v17, :cond_f0

    .line 85
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_subtitle:I

    .line 86
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v18, v2

    check-cast v18, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v18, :cond_f0

    .line 91
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_title:I

    .line 92
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v19, v2

    check-cast v19, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v19, :cond_f0

    .line 97
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_total_size:I

    .line 98
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v20, v2

    check-cast v20, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v20, :cond_f0

    .line 103
    sget v1, Lcom/vdocipher/aegis/R$id;->tvUsedSpace:I

    .line 104
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v21, v2

    check-cast v21, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v21, :cond_f0

    .line 109
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_video_size_7:I

    .line 110
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v22, v2

    check-cast v22, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v22, :cond_f0

    .line 115
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_video_size_all:I

    .line 116
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v23, v2

    check-cast v23, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v23, :cond_f0

    .line 121
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_video_size_one_month:I

    .line 122
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v24, v2

    check-cast v24, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v24, :cond_f0

    .line 127
    new-instance v3, Lcom/vdocipher/aegis/core/e/b;

    move-object v4, v0

    check-cast v4, Landroid/widget/LinearLayout;

    invoke-direct/range {v3 .. v24}, Lcom/vdocipher/aegis/core/e/b;-><init>(Landroid/widget/LinearLayout;Landroidx/appcompat/widget/AppCompatImageView;Landroidx/appcompat/widget/AppCompatImageView;Landroidx/appcompat/widget/AppCompatImageView;Landroidx/appcompat/widget/AppCompatImageView;Landroid/widget/LinearLayout;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;)V

    return-object v3

    .line 133
    :cond_f0
    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object v0

    .line 134
    new-instance v1, Ljava/lang/NullPointerException;

    const-string v2, "Missing required view with ID: "

    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v1
.end method


# virtual methods
.method public a()Landroid/widget/LinearLayout;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/e/b;->a:Landroid/widget/LinearLayout;

    return-object v0
.end method

.method public bridge synthetic getRoot()Landroid/view/View;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/e/b;->a()Landroid/widget/LinearLayout;

    move-result-object v0

    return-object v0
.end method
