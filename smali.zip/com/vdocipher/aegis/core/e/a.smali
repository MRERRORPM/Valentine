# classes14.dex

.class public final Lcom/vdocipher/aegis/core/e/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field private final a:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public final b:Landroidx/appcompat/widget/AppCompatImageButton;

.field public final c:Landroidx/appcompat/widget/AppCompatImageButton;

.field public final d:Landroidx/appcompat/widget/AppCompatImageButton;

.field public final e:Landroidx/appcompat/widget/AppCompatImageButton;

.field public final f:Landroidx/appcompat/widget/AppCompatImageButton;

.field public final g:Landroidx/appcompat/widget/AppCompatImageButton;

.field public final h:Landroidx/appcompat/widget/AppCompatImageButton;

.field public final i:Landroidx/appcompat/widget/AppCompatImageView;

.field public final j:Landroid/widget/LinearLayout;

.field public final k:Landroidx/appcompat/widget/LinearLayoutCompat;

.field public final l:Lcom/google/android/gms/cast/framework/media/widget/CastSeekBar;

.field public final m:Landroidx/appcompat/widget/AppCompatTextView;

.field public final n:Landroidx/appcompat/widget/AppCompatTextView;

.field public final o:Landroidx/appcompat/widget/AppCompatTextView;

.field public final p:Landroidx/appcompat/widget/AppCompatTextView;

.field public final q:Landroidx/appcompat/widget/AppCompatTextView;

.field public final r:Landroidx/appcompat/widget/AppCompatTextView;


# direct methods
.method private constructor <init>(Landroidx/constraintlayout/widget/ConstraintLayout;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatImageView;Landroid/widget/LinearLayout;Landroidx/appcompat/widget/LinearLayoutCompat;Lcom/google/android/gms/cast/framework/media/widget/CastSeekBar;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;)V
    .registers 19

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/e/a;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/e/a;->b:Landroidx/appcompat/widget/AppCompatImageButton;

    .line 4
    iput-object p3, p0, Lcom/vdocipher/aegis/core/e/a;->c:Landroidx/appcompat/widget/AppCompatImageButton;

    .line 5
    iput-object p4, p0, Lcom/vdocipher/aegis/core/e/a;->d:Landroidx/appcompat/widget/AppCompatImageButton;

    .line 6
    iput-object p5, p0, Lcom/vdocipher/aegis/core/e/a;->e:Landroidx/appcompat/widget/AppCompatImageButton;

    .line 7
    iput-object p6, p0, Lcom/vdocipher/aegis/core/e/a;->f:Landroidx/appcompat/widget/AppCompatImageButton;

    .line 8
    iput-object p7, p0, Lcom/vdocipher/aegis/core/e/a;->g:Landroidx/appcompat/widget/AppCompatImageButton;

    .line 9
    iput-object p8, p0, Lcom/vdocipher/aegis/core/e/a;->h:Landroidx/appcompat/widget/AppCompatImageButton;

    .line 10
    iput-object p9, p0, Lcom/vdocipher/aegis/core/e/a;->i:Landroidx/appcompat/widget/AppCompatImageView;

    .line 11
    iput-object p10, p0, Lcom/vdocipher/aegis/core/e/a;->j:Landroid/widget/LinearLayout;

    .line 12
    iput-object p11, p0, Lcom/vdocipher/aegis/core/e/a;->k:Landroidx/appcompat/widget/LinearLayoutCompat;

    .line 13
    iput-object p12, p0, Lcom/vdocipher/aegis/core/e/a;->l:Lcom/google/android/gms/cast/framework/media/widget/CastSeekBar;

    .line 14
    iput-object p13, p0, Lcom/vdocipher/aegis/core/e/a;->m:Landroidx/appcompat/widget/AppCompatTextView;

    .line 15
    iput-object p14, p0, Lcom/vdocipher/aegis/core/e/a;->n:Landroidx/appcompat/widget/AppCompatTextView;

    .line 16
    iput-object p15, p0, Lcom/vdocipher/aegis/core/e/a;->o:Landroidx/appcompat/widget/AppCompatTextView;

    move-object/from16 p1, p16

    .line 17
    iput-object p1, p0, Lcom/vdocipher/aegis/core/e/a;->p:Landroidx/appcompat/widget/AppCompatTextView;

    move-object/from16 p1, p17

    .line 18
    iput-object p1, p0, Lcom/vdocipher/aegis/core/e/a;->q:Landroidx/appcompat/widget/AppCompatTextView;

    move-object/from16 p1, p18

    .line 19
    iput-object p1, p0, Lcom/vdocipher/aegis/core/e/a;->r:Landroidx/appcompat/widget/AppCompatTextView;

    return-void
.end method

.method public static a(Landroid/view/LayoutInflater;)Lcom/vdocipher/aegis/core/e/a;
    .registers 3

    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 2
    invoke-static {p0, v0, v1}, Lcom/vdocipher/aegis/core/e/a;->a(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/vdocipher/aegis/core/e/a;

    move-result-object p0

    return-object p0
.end method

.method public static a(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/vdocipher/aegis/core/e/a;
    .registers 5

    .line 3
    sget v0, Lcom/vdocipher/aegis/R$layout;->vdo_custom_expended_ui_controller:I

    const/4 v1, 0x0

    invoke-virtual {p0, v0, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    if-eqz p2, :cond_c

    .line 5
    invoke-virtual {p1, p0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 7
    :cond_c
    invoke-static {p0}, Lcom/vdocipher/aegis/core/e/a;->a(Landroid/view/View;)Lcom/vdocipher/aegis/core/e/a;

    move-result-object p0

    return-object p0
.end method

.method public static a(Landroid/view/View;)Lcom/vdocipher/aegis/core/e/a;
    .registers 23

    move-object/from16 v0, p0

    .line 8
    sget v1, Lcom/vdocipher/aegis/R$id;->ivBackWard:I

    .line 9
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v5, v2

    check-cast v5, Landroidx/appcompat/widget/AppCompatImageButton;

    if-eqz v5, :cond_cc

    .line 14
    sget v1, Lcom/vdocipher/aegis/R$id;->iv_caption_search:I

    .line 15
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v6, v2

    check-cast v6, Landroidx/appcompat/widget/AppCompatImageButton;

    if-eqz v6, :cond_cc

    .line 20
    sget v1, Lcom/vdocipher/aegis/R$id;->iv_captions:I

    .line 21
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v7, v2

    check-cast v7, Landroidx/appcompat/widget/AppCompatImageButton;

    if-eqz v7, :cond_cc

    .line 26
    sget v1, Lcom/vdocipher/aegis/R$id;->iv_chapters:I

    .line 27
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v8, v2

    check-cast v8, Landroidx/appcompat/widget/AppCompatImageButton;

    if-eqz v8, :cond_cc

    .line 32
    sget v1, Lcom/vdocipher/aegis/R$id;->ivForward:I

    .line 33
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v9, v2

    check-cast v9, Landroidx/appcompat/widget/AppCompatImageButton;

    if-eqz v9, :cond_cc

    .line 38
    sget v1, Lcom/vdocipher/aegis/R$id;->iv_mute_unmute:I

    .line 39
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v10, v2

    check-cast v10, Landroidx/appcompat/widget/AppCompatImageButton;

    if-eqz v10, :cond_cc

    .line 44
    sget v1, Lcom/vdocipher/aegis/R$id;->iv_play_pause:I

    .line 45
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v11, v2

    check-cast v11, Landroidx/appcompat/widget/AppCompatImageButton;

    if-eqz v11, :cond_cc

    .line 50
    sget v1, Lcom/vdocipher/aegis/R$id;->iv_thumbnail:I

    .line 51
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v12, v2

    check-cast v12, Landroidx/appcompat/widget/AppCompatImageView;

    if-eqz v12, :cond_cc

    .line 56
    sget v1, Lcom/vdocipher/aegis/R$id;->ll_button:I

    .line 57
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v13, v2

    check-cast v13, Landroid/widget/LinearLayout;

    if-eqz v13, :cond_cc

    .line 62
    sget v1, Lcom/vdocipher/aegis/R$id;->llTitle:I

    .line 63
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v14, v2

    check-cast v14, Landroidx/appcompat/widget/LinearLayoutCompat;

    if-eqz v14, :cond_cc

    .line 68
    sget v1, Lcom/vdocipher/aegis/R$id;->seek_bar:I

    .line 69
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v15, v2

    check-cast v15, Lcom/google/android/gms/cast/framework/media/widget/CastSeekBar;

    if-eqz v15, :cond_cc

    .line 74
    sget v1, Lcom/vdocipher/aegis/R$id;->tvDeviceName:I

    .line 75
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v16, v2

    check-cast v16, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v16, :cond_cc

    .line 80
    sget v1, Lcom/vdocipher/aegis/R$id;->tvSeekTime:I

    .line 81
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v17, v2

    check-cast v17, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v17, :cond_cc

    .line 86
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_sub_title:I

    .line 87
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v18, v2

    check-cast v18, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v18, :cond_cc

    .line 92
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_title:I

    .line 93
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v19, v2

    check-cast v19, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v19, :cond_cc

    .line 98
    sget v1, Lcom/vdocipher/aegis/R$id;->tvTotalTime:I

    .line 99
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v20, v2

    check-cast v20, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v20, :cond_cc

    .line 104
    sget v1, Lcom/vdocipher/aegis/R$id;->vdo_speed:I

    .line 105
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v21, v2

    check-cast v21, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v21, :cond_cc

    .line 110
    new-instance v3, Lcom/vdocipher/aegis/core/e/a;

    move-object v4, v0

    check-cast v4, Landroidx/constraintlayout/widget/ConstraintLayout;

    invoke-direct/range {v3 .. v21}, Lcom/vdocipher/aegis/core/e/a;-><init>(Landroidx/constraintlayout/widget/ConstraintLayout;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatImageView;Landroid/widget/LinearLayout;Landroidx/appcompat/widget/LinearLayoutCompat;Lcom/google/android/gms/cast/framework/media/widget/CastSeekBar;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;)V

    return-object v3

    .line 115
    :cond_cc
    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object v0

    .line 116
    new-instance v1, Ljava/lang/NullPointerException;

    const-string v2, "Missing required view with ID: "

    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v1
.end method


# virtual methods
.method public a()Landroidx/constraintlayout/widget/ConstraintLayout;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/e/a;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    return-object v0
.end method

.method public bridge synthetic getRoot()Landroid/view/View;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/e/a;->a()Landroidx/constraintlayout/widget/ConstraintLayout;

    move-result-object v0

    return-object v0
.end method
