# classes14.dex

.class public final Lcom/vdocipher/aegis/core/e/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field private final a:Landroid/widget/LinearLayout;

.field public final b:Landroid/widget/ImageView;

.field public final c:Landroid/widget/TextView;


# direct methods
.method private constructor <init>(Landroid/widget/LinearLayout;Landroid/widget/ImageView;Landroid/widget/TextView;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/e/d;->a:Landroid/widget/LinearLayout;

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/e/d;->b:Landroid/widget/ImageView;

    .line 4
    iput-object p3, p0, Lcom/vdocipher/aegis/core/e/d;->c:Landroid/widget/TextView;

    return-void
.end method

.method public static a(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/vdocipher/aegis/core/e/d;
    .registers 5

    .line 2
    sget v0, Lcom/vdocipher/aegis/R$layout;->vdo_fragment_bottomsheet_list_item:I

    const/4 v1, 0x0

    invoke-virtual {p0, v0, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    if-eqz p2, :cond_c

    .line 4
    invoke-virtual {p1, p0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 6
    :cond_c
    invoke-static {p0}, Lcom/vdocipher/aegis/core/e/d;->a(Landroid/view/View;)Lcom/vdocipher/aegis/core/e/d;

    move-result-object p0

    return-object p0
.end method

.method public static a(Landroid/view/View;)Lcom/vdocipher/aegis/core/e/d;
    .registers 4

    .line 7
    sget v0, Lcom/vdocipher/aegis/R$id;->icon:I

    .line 8
    invoke-static {p0, v0}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    if-eqz v1, :cond_1c

    .line 13
    sget v0, Lcom/vdocipher/aegis/R$id;->textTitle:I

    .line 14
    invoke-static {p0, v0}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    if-eqz v2, :cond_1c

    .line 19
    new-instance v0, Lcom/vdocipher/aegis/core/e/d;

    check-cast p0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0, v1, v2}, Lcom/vdocipher/aegis/core/e/d;-><init>(Landroid/widget/LinearLayout;Landroid/widget/ImageView;Landroid/widget/TextView;)V

    return-object v0

    .line 21
    :cond_1c
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object p0

    .line 22
    new-instance v0, Ljava/lang/NullPointerException;

    const-string v1, "Missing required view with ID: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public a()Landroid/widget/LinearLayout;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/e/d;->a:Landroid/widget/LinearLayout;

    return-object v0
.end method

.method public bridge synthetic getRoot()Landroid/view/View;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/e/d;->a()Landroid/widget/LinearLayout;

    move-result-object v0

    return-object v0
.end method
