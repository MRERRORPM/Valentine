# classes14.dex

.class public final Lcom/vdocipher/aegis/core/e/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field private final a:Landroid/widget/LinearLayout;

.field public final b:Landroidx/appcompat/widget/AppCompatImageButton;

.field public final c:Landroidx/appcompat/widget/AppCompatButton;

.field public final d:Landroid/widget/LinearLayout;

.field public final e:Landroid/widget/RadioGroup;

.field public final f:Landroid/widget/RadioGroup;

.field public final g:Landroid/widget/LinearLayout;

.field public final h:Landroid/widget/ScrollView;

.field public final i:Landroidx/appcompat/widget/AppCompatTextView;

.field public final j:Landroid/widget/TextView;

.field public final k:Landroidx/appcompat/widget/AppCompatTextView;

.field public final l:Landroidx/appcompat/widget/AppCompatTextView;

.field public final m:Landroidx/appcompat/widget/AppCompatTextView;


# direct methods
.method private constructor <init>(Landroid/widget/LinearLayout;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatButton;Landroid/widget/LinearLayout;Landroid/widget/RadioGroup;Landroid/widget/RadioGroup;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;Landroidx/appcompat/widget/AppCompatTextView;Landroid/widget/TextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;)V
    .registers 14

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/e/e;->a:Landroid/widget/LinearLayout;

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/e/e;->b:Landroidx/appcompat/widget/AppCompatImageButton;

    .line 4
    iput-object p3, p0, Lcom/vdocipher/aegis/core/e/e;->c:Landroidx/appcompat/widget/AppCompatButton;

    .line 5
    iput-object p4, p0, Lcom/vdocipher/aegis/core/e/e;->d:Landroid/widget/LinearLayout;

    .line 6
    iput-object p5, p0, Lcom/vdocipher/aegis/core/e/e;->e:Landroid/widget/RadioGroup;

    .line 7
    iput-object p6, p0, Lcom/vdocipher/aegis/core/e/e;->f:Landroid/widget/RadioGroup;

    .line 8
    iput-object p7, p0, Lcom/vdocipher/aegis/core/e/e;->g:Landroid/widget/LinearLayout;

    .line 9
    iput-object p8, p0, Lcom/vdocipher/aegis/core/e/e;->h:Landroid/widget/ScrollView;

    .line 10
    iput-object p9, p0, Lcom/vdocipher/aegis/core/e/e;->i:Landroidx/appcompat/widget/AppCompatTextView;

    .line 11
    iput-object p10, p0, Lcom/vdocipher/aegis/core/e/e;->j:Landroid/widget/TextView;

    .line 12
    iput-object p11, p0, Lcom/vdocipher/aegis/core/e/e;->k:Landroidx/appcompat/widget/AppCompatTextView;

    .line 13
    iput-object p12, p0, Lcom/vdocipher/aegis/core/e/e;->l:Landroidx/appcompat/widget/AppCompatTextView;

    .line 14
    iput-object p13, p0, Lcom/vdocipher/aegis/core/e/e;->m:Landroidx/appcompat/widget/AppCompatTextView;

    return-void
.end method

.method public static a(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lcom/vdocipher/aegis/core/e/e;
    .registers 5

    .line 2
    sget v0, Lcom/vdocipher/aegis/R$layout;->vdo_fragment_bottomsheet_option_selector:I

    const/4 v1, 0x0

    invoke-virtual {p0, v0, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    if-eqz p2, :cond_c

    .line 4
    invoke-virtual {p1, p0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 6
    :cond_c
    invoke-static {p0}, Lcom/vdocipher/aegis/core/e/e;->a(Landroid/view/View;)Lcom/vdocipher/aegis/core/e/e;

    move-result-object p0

    return-object p0
.end method

.method public static a(Landroid/view/View;)Lcom/vdocipher/aegis/core/e/e;
    .registers 18

    move-object/from16 v0, p0

    .line 7
    sget v1, Lcom/vdocipher/aegis/R$id;->btn_close:I

    .line 8
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v5, v2

    check-cast v5, Landroidx/appcompat/widget/AppCompatImageButton;

    if-eqz v5, :cond_90

    .line 13
    sget v1, Lcom/vdocipher/aegis/R$id;->btn_download:I

    .line 14
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v6, v2

    check-cast v6, Landroidx/appcompat/widget/AppCompatButton;

    if-eqz v6, :cond_90

    .line 19
    sget v1, Lcom/vdocipher/aegis/R$id;->llProgress:I

    .line 20
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v7, v2

    check-cast v7, Landroid/widget/LinearLayout;

    if-eqz v7, :cond_90

    .line 25
    sget v1, Lcom/vdocipher/aegis/R$id;->rg_audio:I

    .line 26
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v8, v2

    check-cast v8, Landroid/widget/RadioGroup;

    if-eqz v8, :cond_90

    .line 31
    sget v1, Lcom/vdocipher/aegis/R$id;->rg_video:I

    .line 32
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v9, v2

    check-cast v9, Landroid/widget/RadioGroup;

    if-eqz v9, :cond_90

    .line 37
    sget v1, Lcom/vdocipher/aegis/R$id;->root:I

    .line 38
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v10, v2

    check-cast v10, Landroid/widget/LinearLayout;

    if-eqz v10, :cond_90

    .line 43
    sget v1, Lcom/vdocipher/aegis/R$id;->scroll_view:I

    .line 44
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v11, v2

    check-cast v11, Landroid/widget/ScrollView;

    if-eqz v11, :cond_90

    .line 49
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_audio_tracks:I

    .line 50
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v12, v2

    check-cast v12, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v12, :cond_90

    .line 55
    sget v1, Lcom/vdocipher/aegis/R$id;->tvLoading:I

    .line 56
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v13, v2

    check-cast v13, Landroid/widget/TextView;

    if-eqz v13, :cond_90

    .line 61
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_msg:I

    .line 62
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v14, v2

    check-cast v14, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v14, :cond_90

    .line 67
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_title:I

    .line 68
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object v15, v2

    check-cast v15, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v15, :cond_90

    .line 73
    sget v1, Lcom/vdocipher/aegis/R$id;->tv_video_tracks:I

    .line 74
    invoke-static {v0, v1}, Landroidx/viewbinding/ViewBindings;->findChildViewById(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v16, v2

    check-cast v16, Landroidx/appcompat/widget/AppCompatTextView;

    if-eqz v16, :cond_90

    .line 79
    new-instance v3, Lcom/vdocipher/aegis/core/e/e;

    move-object v4, v0

    check-cast v4, Landroid/widget/LinearLayout;

    invoke-direct/range {v3 .. v16}, Lcom/vdocipher/aegis/core/e/e;-><init>(Landroid/widget/LinearLayout;Landroidx/appcompat/widget/AppCompatImageButton;Landroidx/appcompat/widget/AppCompatButton;Landroid/widget/LinearLayout;Landroid/widget/RadioGroup;Landroid/widget/RadioGroup;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;Landroidx/appcompat/widget/AppCompatTextView;Landroid/widget/TextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;)V

    return-object v3

    .line 83
    :cond_90
    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object v0

    .line 84
    new-instance v1, Ljava/lang/NullPointerException;

    const-string v2, "Missing required view with ID: "

    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v1
.end method


# virtual methods
.method public a()Landroid/widget/LinearLayout;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/e/e;->a:Landroid/widget/LinearLayout;

    return-object v0
.end method

.method public bridge synthetic getRoot()Landroid/view/View;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/e/e;->a()Landroid/widget/LinearLayout;

    move-result-object v0

    return-object v0
.end method
