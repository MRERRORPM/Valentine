# classes14.dex

.class public final Lcom/vdocipher/aegis/core/n/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/core/n/b$a;
    }
.end annotation


# instance fields
.field private final a:I

.field private final b:Landroid/os/Handler;

.field private final c:Landroid/content/Context;

.field private final d:Ljava/util/Random;

.field private e:Lcom/vdocipher/aegis/core/n/b$a;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/n/b;->c:Landroid/content/Context;

    const/16 p1, 0xbb8

    .line 3
    iput p1, p0, Lcom/vdocipher/aegis/core/n/b;->a:I

    .line 4
    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/n/b;->b:Landroid/os/Handler;

    .line 5
    new-instance p1, Ljava/util/Random;

    invoke-direct {p1}, Ljava/util/Random;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/n/b;->d:Ljava/util/Random;

    return-void
.end method


# virtual methods
.method public a()V
    .registers 2

    const/4 v0, 0x0

    .line 4
    iput-object v0, p0, Lcom/vdocipher/aegis/core/n/b;->e:Lcom/vdocipher/aegis/core/n/b$a;

    .line 5
    iget-object v0, p0, Lcom/vdocipher/aegis/core/n/b;->b:Landroid/os/Handler;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    return-void
.end method

.method public a(Lcom/vdocipher/aegis/core/n/b$a;)V
    .registers 4

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/core/n/b;->e:Lcom/vdocipher/aegis/core/n/b$a;

    .line 3
    iget-object p1, p0, Lcom/vdocipher/aegis/core/n/b;->b:Landroid/os/Handler;

    iget v0, p0, Lcom/vdocipher/aegis/core/n/b;->a:I

    int-to-long v0, v0

    invoke-virtual {p1, p0, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public run()V
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/n/b;->c:Landroid/content/Context;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/n/a;->a(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_f

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/core/n/b;->e:Lcom/vdocipher/aegis/core/n/b$a;

    if-eqz v0, :cond_f

    .line 3
    invoke-interface {v0}, Lcom/vdocipher/aegis/core/n/b$a;->onAdbEnabled()V

    .line 6
    :cond_f
    iget-object v0, p0, Lcom/vdocipher/aegis/core/n/b;->e:Lcom/vdocipher/aegis/core/n/b$a;

    if-eqz v0, :cond_25

    .line 7
    iget-object v0, p0, Lcom/vdocipher/aegis/core/n/b;->d:Ljava/util/Random;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    .line 8
    iget v1, p0, Lcom/vdocipher/aegis/core/n/b;->a:I

    mul-int/lit16 v0, v0, 0x3e8

    add-int/2addr v1, v0

    .line 9
    iget-object v0, p0, Lcom/vdocipher/aegis/core/n/b;->b:Landroid/os/Handler;

    int-to-long v1, v1

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_25
    return-void
.end method
