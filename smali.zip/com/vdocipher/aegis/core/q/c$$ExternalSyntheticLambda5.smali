# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/q/c;

.field public final synthetic f$1:Lcom/google/android/gms/tasks/OnSuccessListener;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/q/c;Lcom/google/android/gms/tasks/OnSuccessListener;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda5;->f$0:Lcom/vdocipher/aegis/core/q/c;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda5;->f$1:Lcom/google/android/gms/tasks/OnSuccessListener;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda5;->f$0:Lcom/vdocipher/aegis/core/q/c;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda5;->f$1:Lcom/google/android/gms/tasks/OnSuccessListener;

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/q/c;->$r8$lambda$TUkNl8QBaqc3l7zutwMcqkifn0E(Lcom/vdocipher/aegis/core/q/c;Lcom/google/android/gms/tasks/OnSuccessListener;)V

    return-void
.end method
