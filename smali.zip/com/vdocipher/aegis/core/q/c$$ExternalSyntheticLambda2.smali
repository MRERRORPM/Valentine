# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/q/c;

.field public final synthetic f$1:J

.field public final synthetic f$2:Landroid/os/Looper;

.field public final synthetic f$3:Lcom/google/android/gms/tasks/OnSuccessListener;

.field public final synthetic f$4:Lcom/google/android/gms/tasks/OnFailureListener;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/q/c;JLandroid/os/Looper;Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/gms/tasks/OnFailureListener;)V
    .registers 7

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/q/c;

    iput-wide p2, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda2;->f$1:J

    iput-object p4, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda2;->f$2:Landroid/os/Looper;

    iput-object p5, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda2;->f$3:Lcom/google/android/gms/tasks/OnSuccessListener;

    iput-object p6, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda2;->f$4:Lcom/google/android/gms/tasks/OnFailureListener;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 7

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/q/c;

    iget-wide v1, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda2;->f$1:J

    iget-object v3, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda2;->f$2:Landroid/os/Looper;

    iget-object v4, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda2;->f$3:Lcom/google/android/gms/tasks/OnSuccessListener;

    iget-object v5, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda2;->f$4:Lcom/google/android/gms/tasks/OnFailureListener;

    invoke-static/range {v0 .. v5}, Lcom/vdocipher/aegis/core/q/c;->$r8$lambda$k0d43lW2L3kAX4OiElSn0Wyz490(Lcom/vdocipher/aegis/core/q/c;JLandroid/os/Looper;Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/gms/tasks/OnFailureListener;)V

    return-void
.end method
