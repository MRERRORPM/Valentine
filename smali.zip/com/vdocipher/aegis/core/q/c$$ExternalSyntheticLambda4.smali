# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lcom/google/android/gms/tasks/OnFailureListener;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/q/c;

.field public final synthetic f$1:Landroid/os/Looper;

.field public final synthetic f$2:Lcom/google/android/gms/tasks/OnFailureListener;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/q/c;Landroid/os/Looper;Lcom/google/android/gms/tasks/OnFailureListener;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda4;->f$0:Lcom/vdocipher/aegis/core/q/c;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda4;->f$1:Landroid/os/Looper;

    iput-object p3, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda4;->f$2:Lcom/google/android/gms/tasks/OnFailureListener;

    return-void
.end method


# virtual methods
.method public final onFailure(Ljava/lang/Exception;)V
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda4;->f$0:Lcom/vdocipher/aegis/core/q/c;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda4;->f$1:Landroid/os/Looper;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda4;->f$2:Lcom/google/android/gms/tasks/OnFailureListener;

    invoke-static {v0, v1, v2, p1}, Lcom/vdocipher/aegis/core/q/c;->$r8$lambda$BYif1VtboHhA7QA5BqLbtDm8mAI(Lcom/vdocipher/aegis/core/q/c;Landroid/os/Looper;Lcom/google/android/gms/tasks/OnFailureListener;Ljava/lang/Exception;)V

    return-void
.end method
