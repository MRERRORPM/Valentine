# classes14.dex

.class public Lcom/vdocipher/aegis/core/q/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static c:Lcom/vdocipher/aegis/core/q/c;


# instance fields
.field private final a:Landroid/content/Context;

.field private b:Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;


# direct methods
.method public static synthetic $r8$lambda$BYif1VtboHhA7QA5BqLbtDm8mAI(Lcom/vdocipher/aegis/core/q/c;Landroid/os/Looper;Lcom/google/android/gms/tasks/OnFailureListener;Ljava/lang/Exception;)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/q/c;->a(Landroid/os/Looper;Lcom/google/android/gms/tasks/OnFailureListener;Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$RobmO5p_9u198f2MgiKqcz8hFa4(Lcom/google/android/gms/tasks/OnFailureListener;Ljava/lang/Exception;)V
    .registers 2

    invoke-static {p0, p1}, Lcom/vdocipher/aegis/core/q/c;->a(Lcom/google/android/gms/tasks/OnFailureListener;Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$TUkNl8QBaqc3l7zutwMcqkifn0E(Lcom/vdocipher/aegis/core/q/c;Lcom/google/android/gms/tasks/OnSuccessListener;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/core/q/c;->a(Lcom/google/android/gms/tasks/OnSuccessListener;)V

    return-void
.end method

.method public static synthetic $r8$lambda$bcj6B4mbjd1ng9Xnrgvd9qYBT8U(Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;)V
    .registers 2

    invoke-static {p0, p1}, Lcom/vdocipher/aegis/core/q/c;->a(Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;)V

    return-void
.end method

.method public static synthetic $r8$lambda$k0d43lW2L3kAX4OiElSn0Wyz490(Lcom/vdocipher/aegis/core/q/c;JLandroid/os/Looper;Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/gms/tasks/OnFailureListener;)V
    .registers 6

    invoke-direct/range {p0 .. p5}, Lcom/vdocipher/aegis/core/q/c;->a(JLandroid/os/Looper;Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/gms/tasks/OnFailureListener;)V

    return-void
.end method

.method public static synthetic $r8$lambda$sLHOS2YdM5CGhwszLX-a3BksCT0(Lcom/vdocipher/aegis/core/q/c;Landroid/os/Looper;Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/q/c;->a(Landroid/os/Looper;Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;)V

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/q/c;->a:Landroid/content/Context;

    return-void
.end method

.method public static a(Landroid/content/Context;)Lcom/vdocipher/aegis/core/q/c;
    .registers 3

    .line 1
    const-class v0, Lcom/vdocipher/aegis/core/q/c;

    monitor-enter v0

    .line 2
    :try_start_3
    sget-object v1, Lcom/vdocipher/aegis/core/q/c;->c:Lcom/vdocipher/aegis/core/q/c;

    if-nez v1, :cond_e

    .line 3
    new-instance v1, Lcom/vdocipher/aegis/core/q/c;

    invoke-direct {v1, p0}, Lcom/vdocipher/aegis/core/q/c;-><init>(Landroid/content/Context;)V

    sput-object v1, Lcom/vdocipher/aegis/core/q/c;->c:Lcom/vdocipher/aegis/core/q/c;

    .line 5
    :cond_e
    monitor-exit v0
    :try_end_f
    .catchall {:try_start_3 .. :try_end_f} :catchall_12

    .line 6
    sget-object p0, Lcom/vdocipher/aegis/core/q/c;->c:Lcom/vdocipher/aegis/core/q/c;

    return-object p0

    :catchall_12
    move-exception p0

    .line 7
    :try_start_13
    monitor-exit v0
    :try_end_14
    .catchall {:try_start_13 .. :try_end_14} :catchall_12

    throw p0
.end method

.method private synthetic a(JLandroid/os/Looper;Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/gms/tasks/OnFailureListener;)V
    .registers 8

    .line 11
    iget-object v0, p0, Lcom/vdocipher/aegis/core/q/c;->b:Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;

    if-nez v0, :cond_34

    .line 12
    iget-object v0, p0, Lcom/vdocipher/aegis/core/q/c;->a:Landroid/content/Context;

    .line 13
    invoke-static {v0}, Lcom/google/android/play/core/integrity/IntegrityManagerFactory;->createStandard(Landroid/content/Context;)Lcom/google/android/play/core/integrity/StandardIntegrityManager;

    move-result-object v0

    .line 16
    invoke-static {}, Lcom/google/android/play/core/integrity/StandardIntegrityManager$PrepareIntegrityTokenRequest;->builder()Lcom/google/android/play/core/integrity/StandardIntegrityManager$PrepareIntegrityTokenRequest$Builder;

    move-result-object v1

    .line 17
    invoke-virtual {v1, p1, p2}, Lcom/google/android/play/core/integrity/StandardIntegrityManager$PrepareIntegrityTokenRequest$Builder;->setCloudProjectNumber(J)Lcom/google/android/play/core/integrity/StandardIntegrityManager$PrepareIntegrityTokenRequest$Builder;

    move-result-object p1

    .line 18
    invoke-virtual {p1}, Lcom/google/android/play/core/integrity/StandardIntegrityManager$PrepareIntegrityTokenRequest$Builder;->build()Lcom/google/android/play/core/integrity/StandardIntegrityManager$PrepareIntegrityTokenRequest;

    move-result-object p1

    .line 19
    invoke-interface {v0, p1}, Lcom/google/android/play/core/integrity/StandardIntegrityManager;->prepareIntegrityToken(Lcom/google/android/play/core/integrity/StandardIntegrityManager$PrepareIntegrityTokenRequest;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    .line 23
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object p2

    new-instance v0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda3;

    invoke-direct {v0, p0, p3, p4}, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda3;-><init>(Lcom/vdocipher/aegis/core/q/c;Landroid/os/Looper;Lcom/google/android/gms/tasks/OnSuccessListener;)V

    invoke-virtual {p1, p2, v0}, Lcom/google/android/gms/tasks/Task;->addOnSuccessListener(Ljava/util/concurrent/Executor;Lcom/google/android/gms/tasks/OnSuccessListener;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    .line 34
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object p2

    new-instance p4, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda4;

    invoke-direct {p4, p0, p3, p5}, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda4;-><init>(Lcom/vdocipher/aegis/core/q/c;Landroid/os/Looper;Lcom/google/android/gms/tasks/OnFailureListener;)V

    invoke-virtual {p1, p2, p4}, Lcom/google/android/gms/tasks/Task;->addOnFailureListener(Ljava/util/concurrent/Executor;Lcom/google/android/gms/tasks/OnFailureListener;)Lcom/google/android/gms/tasks/Task;

    return-void

    :cond_34
    if-eqz p3, :cond_44

    .line 48
    new-instance p1, Landroid/os/Handler;

    invoke-direct {p1, p3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance p2, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda5;

    invoke-direct {p2, p0, p4}, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda5;-><init>(Lcom/vdocipher/aegis/core/q/c;Lcom/google/android/gms/tasks/OnSuccessListener;)V

    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 50
    :cond_44
    invoke-interface {p4, v0}, Lcom/google/android/gms/tasks/OnSuccessListener;->onSuccess(Ljava/lang/Object;)V

    return-void
.end method

.method private synthetic a(Landroid/os/Looper;Lcom/google/android/gms/tasks/OnFailureListener;Ljava/lang/Exception;)V
    .registers 5

    const/4 v0, 0x0

    .line 59
    iput-object v0, p0, Lcom/vdocipher/aegis/core/q/c;->b:Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;

    if-eqz p1, :cond_13

    .line 63
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance p1, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda1;

    invoke-direct {p1, p2, p3}, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda1;-><init>(Lcom/google/android/gms/tasks/OnFailureListener;Ljava/lang/Exception;)V

    invoke-virtual {v0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 65
    :cond_13
    invoke-interface {p2, p3}, Lcom/google/android/gms/tasks/OnFailureListener;->onFailure(Ljava/lang/Exception;)V

    return-void
.end method

.method private synthetic a(Landroid/os/Looper;Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;)V
    .registers 5

    .line 51
    iput-object p3, p0, Lcom/vdocipher/aegis/core/q/c;->b:Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;

    if-eqz p1, :cond_12

    .line 55
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance p1, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda0;

    invoke-direct {p1, p2, p3}, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda0;-><init>(Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;)V

    invoke-virtual {v0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 57
    :cond_12
    invoke-interface {p2, p3}, Lcom/google/android/gms/tasks/OnSuccessListener;->onSuccess(Ljava/lang/Object;)V

    return-void
.end method

.method private static synthetic a(Lcom/google/android/gms/tasks/OnFailureListener;Ljava/lang/Exception;)V
    .registers 2

    .line 66
    invoke-interface {p0, p1}, Lcom/google/android/gms/tasks/OnFailureListener;->onFailure(Ljava/lang/Exception;)V

    return-void
.end method

.method private synthetic a(Lcom/google/android/gms/tasks/OnSuccessListener;)V
    .registers 3

    .line 67
    iget-object v0, p0, Lcom/vdocipher/aegis/core/q/c;->b:Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;

    invoke-interface {p1, v0}, Lcom/google/android/gms/tasks/OnSuccessListener;->onSuccess(Ljava/lang/Object;)V

    return-void
.end method

.method private static synthetic a(Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;)V
    .registers 2

    .line 58
    invoke-interface {p0, p1}, Lcom/google/android/gms/tasks/OnSuccessListener;->onSuccess(Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public a()V
    .registers 2

    const/4 v0, 0x0

    .line 68
    iput-object v0, p0, Lcom/vdocipher/aegis/core/q/c;->b:Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;

    return-void
.end method

.method public a(Landroid/os/Looper;JLcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/gms/tasks/OnFailureListener;)V
    .registers 14

    .line 8
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 10
    new-instance v1, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda2;

    move-object v2, p0

    move-object v5, p1

    move-wide v3, p2

    move-object v6, p4

    move-object v7, p5

    invoke-direct/range {v1 .. v7}, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda2;-><init>(Lcom/vdocipher/aegis/core/q/c;JLandroid/os/Looper;Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/gms/tasks/OnFailureListener;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method protected clone()Ljava/lang/Object;
    .registers 2

    .line 1
    new-instance v0, Ljava/lang/CloneNotSupportedException;

    invoke-direct {v0}, Ljava/lang/CloneNotSupportedException;-><init>()V

    throw v0
.end method
