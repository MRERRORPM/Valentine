# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/q/d$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/q/d;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/q/d;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/q/d$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/q/d;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/q/d$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/core/q/d;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/q/d;->$r8$lambda$b-SI2qa0XYioCWpOkYcGs71s6rw(Lcom/vdocipher/aegis/core/q/d;)V

    return-void
.end method
