# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lcom/google/android/gms/tasks/OnSuccessListener;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/q/c;

.field public final synthetic f$1:Landroid/os/Looper;

.field public final synthetic f$2:Lcom/google/android/gms/tasks/OnSuccessListener;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/q/c;Landroid/os/Looper;Lcom/google/android/gms/tasks/OnSuccessListener;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda3;->f$0:Lcom/vdocipher/aegis/core/q/c;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda3;->f$1:Landroid/os/Looper;

    iput-object p3, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda3;->f$2:Lcom/google/android/gms/tasks/OnSuccessListener;

    return-void
.end method


# virtual methods
.method public final onSuccess(Ljava/lang/Object;)V
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda3;->f$0:Lcom/vdocipher/aegis/core/q/c;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda3;->f$1:Landroid/os/Looper;

    iget-object v2, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda3;->f$2:Lcom/google/android/gms/tasks/OnSuccessListener;

    check-cast p1, Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;

    invoke-static {v0, v1, v2, p1}, Lcom/vdocipher/aegis/core/q/c;->$r8$lambda$sLHOS2YdM5CGhwszLX-a3BksCT0(Lcom/vdocipher/aegis/core/q/c;Landroid/os/Looper;Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;)V

    return-void
.end method
