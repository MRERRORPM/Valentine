# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/google/android/gms/tasks/OnSuccessListener;

.field public final synthetic f$1:Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda0;->f$0:Lcom/google/android/gms/tasks/OnSuccessListener;

    iput-object p2, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda0;->f$1:Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda0;->f$0:Lcom/google/android/gms/tasks/OnSuccessListener;

    iget-object v1, p0, Lcom/vdocipher/aegis/core/q/c$$ExternalSyntheticLambda0;->f$1:Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/core/q/c;->$r8$lambda$bcj6B4mbjd1ng9Xnrgvd9qYBT8U(Lcom/google/android/gms/tasks/OnSuccessListener;Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;)V

    return-void
.end method
