# classes14.dex

.class public final Lcom/vdocipher/aegis/core/q/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Z

.field public final d:I

.field public final e:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/q/a;->a:Ljava/lang/String;

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/core/q/a;->b:Ljava/lang/String;

    .line 4
    iput-boolean p3, p0, Lcom/vdocipher/aegis/core/q/a;->c:Z

    .line 5
    iput p4, p0, Lcom/vdocipher/aegis/core/q/a;->d:I

    .line 6
    iput-object p5, p0, Lcom/vdocipher/aegis/core/q/a;->e:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/q/a;->a:Ljava/lang/String;

    return-object v0
.end method

.method public b()Z
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/q/a;->b:Ljava/lang/String;

    const/4 v1, 0x0

    if-eqz v0, :cond_1d

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1d

    .line 2
    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/q/a;->a()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1d

    invoke-virtual {p0}, Lcom/vdocipher/aegis/core/q/a;->a()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1d

    const/4 v0, 0x1

    return v0

    :cond_1d
    return v1
.end method

.method public c()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/q/a;->b:Ljava/lang/String;

    if-eqz v0, :cond_d

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_d

    .line 2
    iget-boolean v0, p0, Lcom/vdocipher/aegis/core/q/a;->c:Z

    return v0

    :cond_d
    const/4 v0, 0x0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/q/a;->a:Ljava/lang/String;

    if-eqz v0, :cond_5

    return-object v0

    :cond_5
    const-string v0, "null"

    return-object v0
.end method
