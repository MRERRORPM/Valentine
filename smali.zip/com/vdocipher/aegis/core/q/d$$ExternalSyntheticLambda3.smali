# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/core/q/d$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lcom/google/android/gms/tasks/OnSuccessListener;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/core/q/d;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/core/q/d;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/q/d$$ExternalSyntheticLambda3;->f$0:Lcom/vdocipher/aegis/core/q/d;

    return-void
.end method


# virtual methods
.method public final onSuccess(Ljava/lang/Object;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/core/q/d$$ExternalSyntheticLambda3;->f$0:Lcom/vdocipher/aegis/core/q/d;

    check-cast p1, Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/q/d;->$r8$lambda$GU7_sYyPIM0cojvaCDrjDMG_rHY(Lcom/vdocipher/aegis/core/q/d;Lcom/google/android/play/core/integrity/StandardIntegrityManager$StandardIntegrityTokenProvider;)V

    return-void
.end method
