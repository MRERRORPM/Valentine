# classes14.dex

.class public final Lcom/vdocipher/aegis/core/g/b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/core/g/b$a;,
        Lcom/vdocipher/aegis/core/g/b$b;
    }
.end annotation


# static fields
.field public static final e:Lcom/vdocipher/aegis/core/g/b$a;


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Ljava/lang/String;

.field private final c:Lcom/vdocipher/aegis/core/h/b;

.field private final d:Lokhttp3/OkHttpClient;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lcom/vdocipher/aegis/core/g/b$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/vdocipher/aegis/core/g/b$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/vdocipher/aegis/core/g/b;->e:Lcom/vdocipher/aegis/core/g/b$a;

    return-void
.end method

.method public constructor <init>()V
    .registers 8

    const/16 v5, 0xe

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v0, p0

    .line 40
    invoke-direct/range {v0 .. v6}, Lcom/vdocipher/aegis/core/g/b;-><init>(Landroid/content/Context;Ljava/util/List;Lcom/vdocipher/aegis/core/g/c;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 9

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x0

    move-object v1, p0

    move-object v2, p1

    invoke-direct/range {v1 .. v6}, Lcom/vdocipher/aegis/core/g/b;-><init>(Landroid/content/Context;Ljava/util/List;Lcom/vdocipher/aegis/core/g/c;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/util/List;Lcom/vdocipher/aegis/core/g/c;)V
    .registers 5

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "fallbackHostNames"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    .line 38
    invoke-direct {p0, p1, p2, p3, v0}, Lcom/vdocipher/aegis/core/g/b;-><init>(Landroid/content/Context;Ljava/util/List;Lcom/vdocipher/aegis/core/g/c;Ljava/lang/String;)V

    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;Ljava/util/List;Lcom/vdocipher/aegis/core/g/c;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 6

    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_8

    .line 36
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object p2

    :cond_8
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_d

    const/4 p3, 0x0

    .line 37
    :cond_d
    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/aegis/core/g/b;-><init>(Landroid/content/Context;Ljava/util/List;Lcom/vdocipher/aegis/core/g/c;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/util/List;Lcom/vdocipher/aegis/core/g/c;Ljava/lang/String;)V
    .registers 8

    const-string v0, "fallbackHostNames"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/core/g/b;->a:Landroid/content/Context;

    .line 5
    iput-object p4, p0, Lcom/vdocipher/aegis/core/g/b;->b:Ljava/lang/String;

    .line 22
    new-instance p1, Lcom/vdocipher/aegis/core/h/b;

    invoke-direct {p1, p2, p3}, Lcom/vdocipher/aegis/core/h/b;-><init>(Ljava/util/List;Lcom/vdocipher/aegis/core/g/c;)V

    iput-object p1, p0, Lcom/vdocipher/aegis/core/g/b;->c:Lcom/vdocipher/aegis/core/h/b;

    .line 25
    new-instance p2, Lokhttp3/OkHttpClient$Builder;

    invoke-direct {p2}, Lokhttp3/OkHttpClient$Builder;-><init>()V

    .line 26
    sget-object p3, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v0, 0x1e

    invoke-virtual {p2, v0, v1, p3}, Lokhttp3/OkHttpClient$Builder;->connectTimeout(JLjava/util/concurrent/TimeUnit;)Lokhttp3/OkHttpClient$Builder;

    move-result-object p2

    .line 27
    invoke-virtual {p2, v0, v1, p3}, Lokhttp3/OkHttpClient$Builder;->readTimeout(JLjava/util/concurrent/TimeUnit;)Lokhttp3/OkHttpClient$Builder;

    move-result-object p2

    .line 28
    invoke-virtual {p2, v0, v1, p3}, Lokhttp3/OkHttpClient$Builder;->writeTimeout(JLjava/util/concurrent/TimeUnit;)Lokhttp3/OkHttpClient$Builder;

    move-result-object p2

    const/4 p3, 0x1

    .line 29
    invoke-virtual {p2, p3}, Lokhttp3/OkHttpClient$Builder;->retryOnConnectionFailure(Z)Lokhttp3/OkHttpClient$Builder;

    move-result-object p2

    const/4 v0, 0x2

    .line 30
    new-array v0, v0, [Lokhttp3/Protocol;

    sget-object v1, Lokhttp3/Protocol;->HTTP_2:Lokhttp3/Protocol;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    sget-object v1, Lokhttp3/Protocol;->HTTP_1_1:Lokhttp3/Protocol;

    aput-object v1, v0, p3

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p3

    invoke-virtual {p2, p3}, Lokhttp3/OkHttpClient$Builder;->protocols(Ljava/util/List;)Lokhttp3/OkHttpClient$Builder;

    move-result-object p2

    .line 31
    new-instance p3, Lcom/vdocipher/aegis/core/h/a;

    invoke-direct {p3, p4}, Lcom/vdocipher/aegis/core/h/a;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p3}, Lokhttp3/OkHttpClient$Builder;->addInterceptor(Lokhttp3/Interceptor;)Lokhttp3/OkHttpClient$Builder;

    move-result-object p2

    .line 32
    invoke-virtual {p2, p1}, Lokhttp3/OkHttpClient$Builder;->addInterceptor(Lokhttp3/Interceptor;)Lokhttp3/OkHttpClient$Builder;

    move-result-object p1

    .line 33
    invoke-virtual {p1}, Lokhttp3/OkHttpClient$Builder;->build()Lokhttp3/OkHttpClient;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/core/g/b;->d:Lokhttp3/OkHttpClient;

    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;Ljava/util/List;Lcom/vdocipher/aegis/core/g/c;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 8

    and-int/lit8 p6, p5, 0x1

    const/4 v0, 0x0

    if-eqz p6, :cond_6

    move-object p1, v0

    :cond_6
    and-int/lit8 p6, p5, 0x2

    if-eqz p6, :cond_e

    .line 34
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object p2

    :cond_e
    and-int/lit8 p6, p5, 0x4

    if-eqz p6, :cond_13

    move-object p3, v0

    :cond_13
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_18

    move-object p4, v0

    .line 35
    :cond_18
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/vdocipher/aegis/core/g/b;-><init>(Landroid/content/Context;Ljava/util/List;Lcom/vdocipher/aegis/core/g/c;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic a(Lcom/vdocipher/aegis/core/g/b;Ljava/net/URL;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/Headers;Ljava/lang/String;ILjava/lang/Object;)Lcom/vdocipher/aegis/core/i/a;
    .registers 7

    and-int/lit8 p6, p5, 0x2

    if-eqz p6, :cond_6

    .line 56
    sget-object p2, Lcom/vdocipher/aegis/core/g/a;->a:Lcom/vdocipher/aegis/core/g/a;

    :cond_6
    and-int/lit8 p6, p5, 0x4

    if-eqz p6, :cond_13

    .line 57
    new-instance p3, Lokhttp3/Headers$Builder;

    invoke-direct {p3}, Lokhttp3/Headers$Builder;-><init>()V

    invoke-virtual {p3}, Lokhttp3/Headers$Builder;->build()Lokhttp3/Headers;

    move-result-object p3

    :cond_13
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_18

    const/4 p4, 0x0

    .line 58
    :cond_18
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/vdocipher/aegis/core/g/b;->a(Ljava/net/URL;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/Headers;Ljava/lang/String;)Lcom/vdocipher/aegis/core/i/a;

    move-result-object p0

    return-object p0
.end method

.method private final a()Lokhttp3/OkHttpClient;
    .registers 8

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/core/g/b;->a:Landroid/content/Context;

    if-eqz v0, :cond_9c

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    sget v1, Lcom/vdocipher/aegis/R$raw;->vdo_certificate:I

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->openRawResource(I)Ljava/io/InputStream;

    move-result-object v0

    .line 2
    :try_start_e
    invoke-static {}, Ljava/security/KeyStore;->getDefaultType()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/security/KeyStore;->getInstance(Ljava/lang/String;)Ljava/security/KeyStore;

    move-result-object v1

    .line 3
    const-string/jumbo v2, "vdocipher"

    invoke-virtual {v2}, Ljava/lang/String;->toCharArray()[C

    move-result-object v2

    const-string/jumbo v3, "toCharArray(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1, v0, v2}, Ljava/security/KeyStore;->load(Ljava/io/InputStream;[C)V

    .line 5
    invoke-static {}, Ljavax/net/ssl/TrustManagerFactory;->getDefaultAlgorithm()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/net/ssl/TrustManagerFactory;->getInstance(Ljava/lang/String;)Ljavax/net/ssl/TrustManagerFactory;

    move-result-object v2

    .line 6
    invoke-virtual {v2, v1}, Ljavax/net/ssl/TrustManagerFactory;->init(Ljava/security/KeyStore;)V

    .line 8
    const-string v1, "TLS"

    invoke-static {v1}, Ljavax/net/ssl/SSLContext;->getInstance(Ljava/lang/String;)Ljavax/net/ssl/SSLContext;

    move-result-object v1

    .line 9
    invoke-virtual {v2}, Ljavax/net/ssl/TrustManagerFactory;->getTrustManagers()[Ljavax/net/ssl/TrustManager;

    move-result-object v3

    new-instance v4, Ljava/security/SecureRandom;

    invoke-direct {v4}, Ljava/security/SecureRandom;-><init>()V

    const/4 v5, 0x0

    invoke-virtual {v1, v5, v3, v4}, Ljavax/net/ssl/SSLContext;->init([Ljavax/net/ssl/KeyManager;[Ljavax/net/ssl/TrustManager;Ljava/security/SecureRandom;)V

    .line 11
    new-instance v3, Lokhttp3/OkHttpClient$Builder;

    invoke-direct {v3}, Lokhttp3/OkHttpClient$Builder;-><init>()V

    .line 13
    invoke-virtual {v1}, Ljavax/net/ssl/SSLContext;->getSocketFactory()Ljavax/net/ssl/SSLSocketFactory;

    move-result-object v1

    const-string v4, "getSocketFactory(...)"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    invoke-virtual {v2}, Ljavax/net/ssl/TrustManagerFactory;->getTrustManagers()[Ljavax/net/ssl/TrustManager;

    move-result-object v2

    const/4 v4, 0x0

    aget-object v2, v2, v4

    const-string v6, "null cannot be cast to non-null type javax.net.ssl.X509TrustManager"

    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Ljavax/net/ssl/X509TrustManager;

    .line 15
    invoke-virtual {v3, v1, v2}, Lokhttp3/OkHttpClient$Builder;->sslSocketFactory(Ljavax/net/ssl/SSLSocketFactory;Ljavax/net/ssl/X509TrustManager;)Lokhttp3/OkHttpClient$Builder;

    move-result-object v1

    const/4 v2, 0x1

    .line 19
    invoke-virtual {v1, v2}, Lokhttp3/OkHttpClient$Builder;->retryOnConnectionFailure(Z)Lokhttp3/OkHttpClient$Builder;

    move-result-object v1

    const/4 v3, 0x2

    .line 20
    new-array v3, v3, [Lokhttp3/Protocol;

    sget-object v6, Lokhttp3/Protocol;->HTTP_2:Lokhttp3/Protocol;

    aput-object v6, v3, v4

    sget-object v4, Lokhttp3/Protocol;->HTTP_1_1:Lokhttp3/Protocol;

    aput-object v4, v3, v2

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v1, v2}, Lokhttp3/OkHttpClient$Builder;->protocols(Ljava/util/List;)Lokhttp3/OkHttpClient$Builder;

    move-result-object v1

    .line 21
    new-instance v2, Lcom/vdocipher/aegis/core/h/a;

    iget-object v3, p0, Lcom/vdocipher/aegis/core/g/b;->b:Ljava/lang/String;

    invoke-direct {v2, v3}, Lcom/vdocipher/aegis/core/h/a;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Lokhttp3/OkHttpClient$Builder;->addInterceptor(Lokhttp3/Interceptor;)Lokhttp3/OkHttpClient$Builder;

    move-result-object v1

    .line 22
    iget-object v2, p0, Lcom/vdocipher/aegis/core/g/b;->c:Lcom/vdocipher/aegis/core/h/b;

    invoke-virtual {v1, v2}, Lokhttp3/OkHttpClient$Builder;->addInterceptor(Lokhttp3/Interceptor;)Lokhttp3/OkHttpClient$Builder;

    move-result-object v1

    .line 23
    invoke-virtual {v1}, Lokhttp3/OkHttpClient$Builder;->build()Lokhttp3/OkHttpClient;

    move-result-object v1
    :try_end_91
    .catchall {:try_start_e .. :try_end_91} :catchall_95

    .line 24
    invoke-static {v0, v5}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v1

    :catchall_95
    move-exception v1

    :try_start_96
    throw v1
    :try_end_97
    .catchall {:try_start_96 .. :try_end_97} :catchall_97

    :catchall_97
    move-exception v2

    invoke-static {v0, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v2

    .line 25
    :cond_9c
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Context can not be null with ssl pinning"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private final a(Ljava/net/URL;Lokhttp3/Headers;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;
    .registers 9

    .line 32
    new-instance v0, Lokhttp3/Request$Builder;

    invoke-direct {v0}, Lokhttp3/Request$Builder;-><init>()V

    .line 33
    invoke-virtual {v0, p1}, Lokhttp3/Request$Builder;->url(Ljava/net/URL;)Lokhttp3/Request$Builder;

    move-result-object p1

    .line 34
    invoke-virtual {p1, p2}, Lokhttp3/Request$Builder;->headers(Lokhttp3/Headers;)Lokhttp3/Request$Builder;

    move-result-object p1

    .line 36
    sget-object p2, Lcom/vdocipher/aegis/core/g/b$b;->a:[I

    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    move-result p3

    aget p2, p2, p3

    const/4 p3, 0x1

    if-eq p2, p3, :cond_49

    const/4 v0, 0x2

    if-eq p2, v0, :cond_45

    const/4 v0, 0x3

    if-eq p2, v0, :cond_41

    const/4 v0, 0x4

    if-eq p2, v0, :cond_3d

    const/4 v0, 0x5

    if-ne p2, v0, :cond_37

    .line 42
    invoke-virtual {p4}, Lokhttp3/RequestBody;->contentLength()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long p2, v0, v2

    if-eqz p2, :cond_32

    invoke-virtual {p1, p4}, Lokhttp3/Request$Builder;->delete(Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    return-object p1

    :cond_32
    const/4 p2, 0x0

    .line 43
    invoke-static {p1, p2, p3, p2}, Lokhttp3/Request$Builder;->delete$default(Lokhttp3/Request$Builder;Lokhttp3/RequestBody;ILjava/lang/Object;)Lokhttp3/Request$Builder;

    return-object p1

    .line 36
    :cond_37
    new-instance p1, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {p1}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw p1

    .line 44
    :cond_3d
    invoke-virtual {p1, p4}, Lokhttp3/Request$Builder;->patch(Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    return-object p1

    .line 45
    :cond_41
    invoke-virtual {p1, p4}, Lokhttp3/Request$Builder;->put(Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    return-object p1

    .line 46
    :cond_45
    invoke-virtual {p1, p4}, Lokhttp3/Request$Builder;->post(Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    return-object p1

    .line 47
    :cond_49
    invoke-virtual {p1}, Lokhttp3/Request$Builder;->get()Lokhttp3/Request$Builder;

    return-object p1
.end method

.method public static synthetic a(Lcom/vdocipher/aegis/core/g/b;Ljava/net/URL;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/Headers;Ljava/lang/String;ZLcom/vdocipher/aegis/core/g/e;ILjava/lang/Object;)V
    .registers 16

    and-int/lit8 p8, p7, 0x2

    if-eqz p8, :cond_6

    .line 48
    sget-object p2, Lcom/vdocipher/aegis/core/g/a;->a:Lcom/vdocipher/aegis/core/g/a;

    :cond_6
    move-object v2, p2

    and-int/lit8 p2, p7, 0x4

    if-eqz p2, :cond_14

    .line 49
    new-instance p2, Lokhttp3/Headers$Builder;

    invoke-direct {p2}, Lokhttp3/Headers$Builder;-><init>()V

    invoke-virtual {p2}, Lokhttp3/Headers$Builder;->build()Lokhttp3/Headers;

    move-result-object p3

    :cond_14
    move-object v3, p3

    and-int/lit8 p2, p7, 0x8

    if-eqz p2, :cond_1a

    const/4 p4, 0x0

    :cond_1a
    move-object v4, p4

    and-int/lit8 p2, p7, 0x10

    if-eqz p2, :cond_20

    const/4 p5, 0x0

    :cond_20
    move-object v0, p0

    move-object v1, p1

    move v5, p5

    move-object v6, p6

    .line 50
    invoke-virtual/range {v0 .. v6}, Lcom/vdocipher/aegis/core/g/b;->a(Ljava/net/URL;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/Headers;Ljava/lang/String;ZLcom/vdocipher/aegis/core/g/e;)V

    return-void
.end method

.method private final a(Lokhttp3/Request;Lcom/vdocipher/aegis/core/g/e;Z)V
    .registers 4

    if-eqz p3, :cond_7

    .line 106
    invoke-direct {p0}, Lcom/vdocipher/aegis/core/g/b;->a()Lokhttp3/OkHttpClient;

    move-result-object p3

    goto :goto_9

    .line 108
    :cond_7
    iget-object p3, p0, Lcom/vdocipher/aegis/core/g/b;->d:Lokhttp3/OkHttpClient;

    .line 111
    :goto_9
    invoke-virtual {p3, p1}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object p1

    new-instance p3, Lcom/vdocipher/aegis/core/g/b$c;

    invoke-direct {p3, p2}, Lcom/vdocipher/aegis/core/g/b$c;-><init>(Lcom/vdocipher/aegis/core/g/e;)V

    invoke-interface {p1, p3}, Lokhttp3/Call;->enqueue(Lokhttp3/Callback;)V

    return-void
.end method


# virtual methods
.method public final a(Ljava/net/URL;)Lcom/vdocipher/aegis/core/i/a;
    .registers 10

    const-string/jumbo v0, "url"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v6, 0xe

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v1, p0

    move-object v2, p1

    .line 26
    invoke-static/range {v1 .. v7}, Lcom/vdocipher/aegis/core/g/b;->a(Lcom/vdocipher/aegis/core/g/b;Ljava/net/URL;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/Headers;Ljava/lang/String;ILjava/lang/Object;)Lcom/vdocipher/aegis/core/i/a;

    move-result-object p1

    return-object p1
.end method

.method public final a(Ljava/net/URL;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/Headers;Ljava/lang/String;)Lcom/vdocipher/aegis/core/i/a;
    .registers 12

    const-string/jumbo v0, "url"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "method"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "headers"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x0

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    .line 59
    invoke-virtual/range {v1 .. v6}, Lcom/vdocipher/aegis/core/g/b;->a(Ljava/net/URL;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/Headers;Ljava/lang/String;Z)Lcom/vdocipher/aegis/core/i/a;

    move-result-object p1

    return-object p1
.end method

.method public final a(Ljava/net/URL;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/Headers;Ljava/lang/String;Z)Lcom/vdocipher/aegis/core/i/a;
    .registers 23

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    const-string/jumbo v4, "url"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "method"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "headers"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 60
    sget-object v4, Lokhttp3/RequestBody;->Companion:Lokhttp3/RequestBody$Companion;

    if-nez p4, :cond_1f

    const-string v5, ""

    goto :goto_21

    :cond_1f
    move-object/from16 v5, p4

    :goto_21
    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v4, v5, v7, v6, v7}, Lokhttp3/RequestBody$Companion;->create$default(Lokhttp3/RequestBody$Companion;Ljava/lang/String;Lokhttp3/MediaType;ILjava/lang/Object;)Lokhttp3/RequestBody;

    move-result-object v4

    .line 62
    invoke-direct {v1, v0, v3, v2, v4}, Lcom/vdocipher/aegis/core/g/b;->a(Ljava/net/URL;Lokhttp3/Headers;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    move-result-object v0

    if-eqz p5, :cond_32

    .line 65
    :try_start_2d
    invoke-direct {v1}, Lcom/vdocipher/aegis/core/g/b;->a()Lokhttp3/OkHttpClient;

    move-result-object v2

    goto :goto_34

    :cond_32
    iget-object v2, v1, Lcom/vdocipher/aegis/core/g/b;->d:Lokhttp3/OkHttpClient;
    :try_end_34
    .catch Ljava/lang/Exception; {:try_start_2d .. :try_end_34} :catch_8b

    .line 76
    :goto_34
    :try_start_34
    invoke-virtual {v0}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object v0

    invoke-virtual {v2, v0}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object v0

    invoke-interface {v0}, Lokhttp3/Call;->execute()Lokhttp3/Response;

    move-result-object v2
    :try_end_40
    .catch Ljava/lang/Exception; {:try_start_34 .. :try_end_40} :catch_78

    .line 77
    :try_start_40
    invoke-virtual {v2}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v0

    if-eqz v0, :cond_4c

    invoke-virtual {v0}, Lokhttp3/ResponseBody;->string()Ljava/lang/String;

    move-result-object v0

    move-object v10, v0

    goto :goto_4d

    :cond_4c
    move-object v10, v7

    .line 78
    :goto_4d
    new-instance v8, Lcom/vdocipher/aegis/core/i/a;

    .line 79
    invoke-virtual {v2}, Lokhttp3/Response;->code()I

    move-result v9

    .line 81
    invoke-virtual {v2}, Lokhttp3/Response;->isSuccessful()Z

    move-result v11

    .line 82
    invoke-virtual {v2}, Lokhttp3/Response;->isSuccessful()Z

    move-result v0

    if-nez v0, :cond_5f

    move-object v12, v10

    goto :goto_60

    :cond_5f
    move-object v12, v7

    .line 83
    :goto_60
    invoke-virtual {v2}, Lokhttp3/Response;->headers()Lokhttp3/Headers;

    move-result-object v14

    const/16 v15, 0x10

    const/16 v16, 0x0

    const/4 v13, 0x0

    .line 84
    invoke-direct/range {v8 .. v16}, Lcom/vdocipher/aegis/core/i/a;-><init>(ILjava/lang/String;ZLjava/lang/String;Ljava/lang/Exception;Lokhttp3/Headers;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    :try_end_6c
    .catchall {:try_start_40 .. :try_end_6c} :catchall_70

    .line 85
    :try_start_6c
    invoke-static {v2, v7}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_6f
    .catch Ljava/lang/Exception; {:try_start_6c .. :try_end_6f} :catch_78

    return-object v8

    :catchall_70
    move-exception v0

    move-object v3, v0

    :try_start_72
    throw v3
    :try_end_73
    .catchall {:try_start_72 .. :try_end_73} :catchall_73

    :catchall_73
    move-exception v0

    :try_start_74
    invoke-static {v2, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
    :try_end_78
    .catch Ljava/lang/Exception; {:try_start_74 .. :try_end_78} :catch_78

    :catch_78
    move-exception v0

    move-object v7, v0

    .line 96
    new-instance v2, Lcom/vdocipher/aegis/core/i/a;

    .line 99
    invoke-virtual {v7}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v6

    const/16 v9, 0x22

    const/4 v10, 0x0

    const/4 v3, -0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v8, 0x0

    .line 100
    invoke-direct/range {v2 .. v10}, Lcom/vdocipher/aegis/core/i/a;-><init>(ILjava/lang/String;ZLjava/lang/String;Ljava/lang/Exception;Lokhttp3/Headers;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v2

    :catch_8b
    move-exception v0

    move-object v7, v0

    .line 101
    new-instance v2, Lcom/vdocipher/aegis/core/i/a;

    .line 104
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "Failed to create HTTP client: "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/16 v9, 0x22

    const/4 v10, 0x0

    const/4 v3, -0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v8, 0x0

    .line 105
    invoke-direct/range {v2 .. v10}, Lcom/vdocipher/aegis/core/i/a;-><init>(ILjava/lang/String;ZLjava/lang/String;Ljava/lang/Exception;Lokhttp3/Headers;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v2
.end method

.method public final a(Ljava/net/URL;Ljava/lang/String;)Lcom/vdocipher/aegis/core/i/a;
    .registers 11

    const-string/jumbo v0, "url"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "payload"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    sget-object v3, Lcom/vdocipher/aegis/core/g/a;->b:Lcom/vdocipher/aegis/core/g/a;

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v4, 0x0

    move-object v1, p0

    move-object v2, p1

    move-object v5, p2

    .line 29
    invoke-static/range {v1 .. v7}, Lcom/vdocipher/aegis/core/g/b;->a(Lcom/vdocipher/aegis/core/g/b;Ljava/net/URL;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/Headers;Ljava/lang/String;ILjava/lang/Object;)Lcom/vdocipher/aegis/core/i/a;

    move-result-object p1

    return-object p1
.end method

.method public final a(Ljava/net/URL;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/Headers;Ljava/lang/String;ZLcom/vdocipher/aegis/core/g/e;)V
    .registers 10

    const-string/jumbo v0, "url"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "method"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "headers"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string/jumbo v0, "vdoNetworkCallback"

    invoke-static {p6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 51
    sget-object v0, Lokhttp3/RequestBody;->Companion:Lokhttp3/RequestBody$Companion;

    if-nez p4, :cond_1c

    const-string p4, ""

    :cond_1c
    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0, p4, v2, v1, v2}, Lokhttp3/RequestBody$Companion;->create$default(Lokhttp3/RequestBody$Companion;Ljava/lang/String;Lokhttp3/MediaType;ILjava/lang/Object;)Lokhttp3/RequestBody;

    move-result-object p4

    .line 53
    invoke-direct {p0, p1, p3, p2, p4}, Lcom/vdocipher/aegis/core/g/b;->a(Ljava/net/URL;Lokhttp3/Headers;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    move-result-object p1

    .line 55
    invoke-virtual {p1}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object p1

    invoke-direct {p0, p1, p6, p5}, Lcom/vdocipher/aegis/core/g/b;->a(Lokhttp3/Request;Lcom/vdocipher/aegis/core/g/e;Z)V

    return-void
.end method

.method public final a(Ljava/net/URL;Lcom/vdocipher/aegis/core/g/e;)V
    .registers 13

    const-string/jumbo v0, "url"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string/jumbo v0, "vdoNetworkCallback"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v8, 0x1e

    const/4 v9, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, p0

    move-object v2, p1

    move-object v7, p2

    .line 27
    invoke-static/range {v1 .. v9}, Lcom/vdocipher/aegis/core/g/b;->a(Lcom/vdocipher/aegis/core/g/b;Ljava/net/URL;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/Headers;Ljava/lang/String;ZLcom/vdocipher/aegis/core/g/e;ILjava/lang/Object;)V

    return-void
.end method

.method public final a(Ljava/net/URL;Ljava/lang/String;Lcom/vdocipher/aegis/core/g/e;)V
    .registers 14

    const-string/jumbo v0, "url"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "payload"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string/jumbo v0, "vdoNetworkCallback"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    sget-object v3, Lcom/vdocipher/aegis/core/g/a;->b:Lcom/vdocipher/aegis/core/g/a;

    const/16 v8, 0x14

    const/4 v9, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x0

    move-object v1, p0

    move-object v2, p1

    move-object v5, p2

    move-object v7, p3

    .line 31
    invoke-static/range {v1 .. v9}, Lcom/vdocipher/aegis/core/g/b;->a(Lcom/vdocipher/aegis/core/g/b;Ljava/net/URL;Lcom/vdocipher/aegis/core/g/a;Lokhttp3/Headers;Ljava/lang/String;ZLcom/vdocipher/aegis/core/g/e;ILjava/lang/Object;)V

    return-void
.end method
