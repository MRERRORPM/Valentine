# classes14.dex

.class public final enum Lcom/vdocipher/aegis/core/g/a;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum a:Lcom/vdocipher/aegis/core/g/a;

.field public static final enum b:Lcom/vdocipher/aegis/core/g/a;

.field public static final enum c:Lcom/vdocipher/aegis/core/g/a;

.field public static final enum d:Lcom/vdocipher/aegis/core/g/a;

.field public static final enum e:Lcom/vdocipher/aegis/core/g/a;

.field private static final synthetic f:[Lcom/vdocipher/aegis/core/g/a;

.field private static final synthetic g:Lkotlin/enums/EnumEntries;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lcom/vdocipher/aegis/core/g/a;

    const-string v1, "GET"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/vdocipher/aegis/core/g/a;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/vdocipher/aegis/core/g/a;->a:Lcom/vdocipher/aegis/core/g/a;

    .line 2
    new-instance v0, Lcom/vdocipher/aegis/core/g/a;

    const-string v1, "POST"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lcom/vdocipher/aegis/core/g/a;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/vdocipher/aegis/core/g/a;->b:Lcom/vdocipher/aegis/core/g/a;

    .line 3
    new-instance v0, Lcom/vdocipher/aegis/core/g/a;

    const-string v1, "PUT"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lcom/vdocipher/aegis/core/g/a;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/vdocipher/aegis/core/g/a;->c:Lcom/vdocipher/aegis/core/g/a;

    .line 4
    new-instance v0, Lcom/vdocipher/aegis/core/g/a;

    const-string v1, "PATCH"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Lcom/vdocipher/aegis/core/g/a;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/vdocipher/aegis/core/g/a;->d:Lcom/vdocipher/aegis/core/g/a;

    .line 5
    new-instance v0, Lcom/vdocipher/aegis/core/g/a;

    const-string v1, "DELETE"

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2}, Lcom/vdocipher/aegis/core/g/a;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/vdocipher/aegis/core/g/a;->e:Lcom/vdocipher/aegis/core/g/a;

    invoke-static {}, Lcom/vdocipher/aegis/core/g/a;->a()[Lcom/vdocipher/aegis/core/g/a;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/aegis/core/g/a;->f:[Lcom/vdocipher/aegis/core/g/a;

    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/aegis/core/g/a;->g:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method private static final synthetic a()[Lcom/vdocipher/aegis/core/g/a;
    .registers 5

    .line 1
    sget-object v0, Lcom/vdocipher/aegis/core/g/a;->a:Lcom/vdocipher/aegis/core/g/a;

    sget-object v1, Lcom/vdocipher/aegis/core/g/a;->b:Lcom/vdocipher/aegis/core/g/a;

    sget-object v2, Lcom/vdocipher/aegis/core/g/a;->c:Lcom/vdocipher/aegis/core/g/a;

    sget-object v3, Lcom/vdocipher/aegis/core/g/a;->d:Lcom/vdocipher/aegis/core/g/a;

    sget-object v4, Lcom/vdocipher/aegis/core/g/a;->e:Lcom/vdocipher/aegis/core/g/a;

    filled-new-array {v0, v1, v2, v3, v4}, [Lcom/vdocipher/aegis/core/g/a;

    move-result-object v0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/aegis/core/g/a;
    .registers 2

    const-class v0, Lcom/vdocipher/aegis/core/g/a;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    .line 1
    check-cast p0, Lcom/vdocipher/aegis/core/g/a;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/aegis/core/g/a;
    .registers 1

    sget-object v0, Lcom/vdocipher/aegis/core/g/a;->f:[Lcom/vdocipher/aegis/core/g/a;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    .line 1
    check-cast v0, [Lcom/vdocipher/aegis/core/g/a;

    return-object v0
.end method
