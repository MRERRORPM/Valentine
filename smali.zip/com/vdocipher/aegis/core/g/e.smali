# classes14.dex

.class public interface abstract Lcom/vdocipher/aegis/core/g/e;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(ILjava/lang/String;)V
.end method

.method public abstract a(Ljava/io/IOException;)V
.end method

.method public abstract b(ILjava/lang/String;)V
.end method
