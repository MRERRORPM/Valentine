# classes14.dex

.class public final Lcom/vdocipher/aegis/core/g/b$c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lokhttp3/Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/vdocipher/aegis/core/g/b;->a(Lokhttp3/Request;Lcom/vdocipher/aegis/core/g/e;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/core/g/e;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/core/g/e;)V
    .registers 2

    iput-object p1, p0, Lcom/vdocipher/aegis/core/g/b$c;->a:Lcom/vdocipher/aegis/core/g/e;

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onFailure(Lokhttp3/Call;Ljava/io/IOException;)V
    .registers 4

    const-string v0, "call"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "e"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object p1, p0, Lcom/vdocipher/aegis/core/g/b$c;->a:Lcom/vdocipher/aegis/core/g/e;

    invoke-interface {p1, p2}, Lcom/vdocipher/aegis/core/g/e;->a(Ljava/io/IOException;)V

    return-void
.end method

.method public onResponse(Lokhttp3/Call;Lokhttp3/Response;)V
    .registers 6

    const-string v0, "call"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "response"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object p1, p0, Lcom/vdocipher/aegis/core/g/b$c;->a:Lcom/vdocipher/aegis/core/g/e;

    .line 2
    :try_start_c
    invoke-virtual {p2}, Lokhttp3/Response;->isSuccessful()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_2b

    .line 3
    invoke-virtual {p2}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v0

    if-eqz v0, :cond_1e

    invoke-virtual {v0}, Lokhttp3/ResponseBody;->string()Ljava/lang/String;

    move-result-object v0

    goto :goto_1f

    :cond_1e
    move-object v0, v1

    .line 5
    :goto_1f
    invoke-virtual {p2}, Lokhttp3/Response;->code()I

    move-result v2

    if-nez v0, :cond_27

    .line 6
    const-string v0, "Unknown error"

    .line 7
    :cond_27
    invoke-interface {p1, v2, v0}, Lcom/vdocipher/aegis/core/g/e;->b(ILjava/lang/String;)V

    goto :goto_40

    .line 12
    :cond_2b
    invoke-virtual {p2}, Lokhttp3/Response;->code()I

    move-result v0

    invoke-virtual {p2}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v2

    if-eqz v2, :cond_3b

    invoke-virtual {v2}, Lokhttp3/ResponseBody;->string()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_3d

    :cond_3b
    const-string v2, ""

    :cond_3d
    invoke-interface {p1, v0, v2}, Lcom/vdocipher/aegis/core/g/e;->a(ILjava/lang/String;)V

    .line 14
    :goto_40
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_42
    .catchall {:try_start_c .. :try_end_42} :catchall_46

    .line 15
    invoke-static {p2, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-void

    :catchall_46
    move-exception p1

    :try_start_47
    throw p1
    :try_end_48
    .catchall {:try_start_47 .. :try_end_48} :catchall_48

    :catchall_48
    move-exception v0

    invoke-static {p2, p1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method
