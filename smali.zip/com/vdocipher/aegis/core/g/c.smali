# classes14.dex

.class public interface abstract Lcom/vdocipher/aegis/core/g/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/lang/String;Ljava/lang/Exception;)V
.end method
