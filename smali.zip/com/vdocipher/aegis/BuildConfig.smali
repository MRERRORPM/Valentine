# classes14.dex

.class public final Lcom/vdocipher/aegis/BuildConfig;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final BASE_URL_DEV:Ljava/lang/String; = "https://dev.vdocipher.com"

.field public static final BASE_URL_META:Ljava/lang/String; = "https://meta.vdocipher.com"

.field public static final BUILD_TYPE:Ljava/lang/String; = "release"

.field public static final DEBUG:Z = false

.field public static final LIBRARY_PACKAGE_NAME:Ljava/lang/String; = "com.vdocipher.aegis"

.field public static final MEDIA3_VERSION:Ljava/lang/String; = "1.8.0"

.field public static final VDO_VERSION_CODE:I = 0x8b

.field public static final VDO_VERSION_NAME:Ljava/lang/String; = "1.29.3"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
