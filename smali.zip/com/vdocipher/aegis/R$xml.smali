# classes14.dex

.class public final Lcom/vdocipher/aegis/R$xml;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "xml"
.end annotation


# static fields
.field public static com_vdocipher_aegis_auto_backup_rules:I = 0x7f160001

.field public static m3_button_group_child_size_change:I = 0x7f160005

.field public static m3_split_button_inner_corner_size_state_list:I = 0x7f160006

.field public static m3expressive_button_shape_state_list:I = 0x7f160007

.field public static m3expressive_connected_buttons_inner_corner_size_state_list:I = 0x7f160008


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
