# classes14.dex

.class public final Lcom/vdocipher/aegis/R$menu;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "menu"
.end annotation


# static fields
.field public static vdo_cast_menu:I = 0x7f0f0000

.field public static vdo_expanded_controller:I = 0x7f0f0001


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
