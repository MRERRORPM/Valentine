# classes14.dex

.class Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vdocipher/aegis/core/c/b$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/cast/CastVdoPlayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;


# direct methods
.method public static synthetic $r8$lambda$PxwjzCscybAg0W7IOhigJUO3zNU(Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;->a(Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    return-void
.end method

.method constructor <init>(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private synthetic a(Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 5

    .line 35
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-static {v0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->d(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)Ljava/util/concurrent/CopyOnWriteArraySet;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1a

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 36
    invoke-interface {v1, p1, p2}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onLoadError(Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    goto :goto_a

    :cond_1a
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;ILjava/lang/String;)V
    .registers 4

    .line 1
    iget-object p2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-static {p2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    move-result-object p2

    if-ne p2, p1, :cond_15

    iget-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-static {p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    move-result-object p1

    if-eqz p1, :cond_15

    .line 2
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-static {p1, p3}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Ljava/lang/String;)V

    :cond_15
    return-void
.end method

.method public a(Ljava/lang/Object;ILjava/lang/String;Ljava/lang/Throwable;)V
    .registers 8

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-static {v0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    move-result-object v0

    if-ne v0, p1, :cond_76

    .line 4
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "not received "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    if-eqz p4, :cond_16

    invoke-virtual {p4}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_18

    :cond_16
    const-string v1, ""

    :goto_18
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "CastVdoPlayer"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 5
    check-cast p1, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    iget-object p1, p1, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    const/16 v0, 0x190

    const/16 v1, 0x1f4

    .line 7
    const-string v2, "error getting meta data"

    if-lt p2, v0, :cond_51

    if-ge p2, v1, :cond_51

    .line 11
    invoke-static {p3}, Lcom/vdocipher/aegis/core/t/d;->k(Ljava/lang/String;)Landroid/util/Pair;

    move-result-object p3

    const/16 p4, 0x194

    if-ne p2, p4, :cond_3d

    const/16 p4, 0x140f

    goto :goto_3f

    :cond_3d
    const/16 p4, 0x1402

    .line 19
    :goto_3f
    iget-object v0, p3, Landroid/util/Pair;->first:Ljava/lang/Object;

    if-eqz v0, :cond_49

    .line 20
    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p4

    .line 22
    :cond_49
    iget-object p3, p3, Landroid/util/Pair;->second:Ljava/lang/Object;

    if-eqz p3, :cond_63

    .line 23
    move-object v2, p3

    check-cast v2, Ljava/lang/String;

    goto :goto_63

    :cond_51
    if-lt p2, v1, :cond_5a

    const/16 p3, 0x258

    if-ge p2, p3, :cond_5a

    const/16 p4, 0x1403

    goto :goto_63

    .line 27
    :cond_5a
    instance-of p3, p4, Ljava/io/IOException;

    if-eqz p3, :cond_61

    const/16 p4, 0x1404

    goto :goto_63

    :cond_61
    const/16 p4, 0x1400

    .line 32
    :cond_63
    :goto_63
    new-instance p3, Lcom/vdocipher/aegis/media/ErrorDescription;

    invoke-direct {p3, p4, v2, p2}, Lcom/vdocipher/aegis/media/ErrorDescription;-><init>(ILjava/lang/String;I)V

    .line 34
    iget-object p2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-static {p2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->c(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)Landroid/os/Handler;

    move-result-object p2

    new-instance p4, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a$$ExternalSyntheticLambda0;

    invoke-direct {p4, p0, p1, p3}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    invoke-virtual {p2, p4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_76
    return-void
.end method
