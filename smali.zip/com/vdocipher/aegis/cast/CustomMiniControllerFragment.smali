# classes14.dex

.class public final Lcom/vdocipher/aegis/cast/CustomMiniControllerFragment;
.super Lcom/google/android/gms/cast/framework/media/widget/MiniControllerFragment;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"
    }
    d2 = {
        "Lcom/vdocipher/aegis/cast/CustomMiniControllerFragment;",
        "Lcom/google/android/gms/cast/framework/media/widget/MiniControllerFragment;",
        "<init>",
        "()V",
        "core_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/google/android/gms/cast/framework/media/widget/MiniControllerFragment;-><init>()V

    return-void
.end method
