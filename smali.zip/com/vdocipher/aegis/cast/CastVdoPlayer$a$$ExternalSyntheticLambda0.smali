# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/cast/CastVdoPlayer$a$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;

.field public final synthetic f$1:Lcom/vdocipher/aegis/player/VdoInitParams;

.field public final synthetic f$2:Lcom/vdocipher/aegis/media/ErrorDescription;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;

    iput-object p2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a$$ExternalSyntheticLambda0;->f$1:Lcom/vdocipher/aegis/player/VdoInitParams;

    iput-object p3, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a$$ExternalSyntheticLambda0;->f$2:Lcom/vdocipher/aegis/media/ErrorDescription;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;

    iget-object v1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a$$ExternalSyntheticLambda0;->f$1:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a$$ExternalSyntheticLambda0;->f$2:Lcom/vdocipher/aegis/media/ErrorDescription;

    invoke-static {v0, v1, v2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;->$r8$lambda$PxwjzCscybAg0W7IOhigJUO3zNU(Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    return-void
.end method
