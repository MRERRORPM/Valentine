# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/cast/CastVdoPlayer;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-static {v0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->$r8$lambda$aHTwfA0QT1UjTgyKpHgfK7ZJinc(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)V

    return-void
.end method
