# classes14.dex

.class public Lcom/vdocipher/aegis/cast/internal/CastConnectView;
.super Landroid/widget/FrameLayout;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/cast/internal/CastConnectView$b;,
        Lcom/vdocipher/aegis/cast/internal/CastConnectView$c;
    }
.end annotation


# instance fields
.field private final a:Landroid/content/Context;

.field private b:Lcom/google/android/gms/cast/framework/CastContext;

.field private c:Lcom/vdocipher/aegis/cast/internal/CastConnectView$b;

.field private final d:Landroid/view/View;

.field private final e:Landroid/widget/Button;

.field private final f:Landroid/widget/TextView;

.field private final g:Landroid/widget/TextView;

.field private final h:Landroid/widget/LinearLayout;


# direct methods
.method public static synthetic $r8$lambda$_FFyRDwz7Gr3rJmu9nnHpK_NpZ4(Lcom/vdocipher/aegis/cast/internal/CastConnectView;Lcom/google/android/gms/cast/framework/CastSession;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->a(Lcom/google/android/gms/cast/framework/CastSession;Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, p1, p2, v0}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 8

    .line 3
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 5
    new-instance p2, Lcom/vdocipher/aegis/cast/internal/CastConnectView$c;

    const/4 p3, 0x0

    invoke-direct {p2, p0, p3}, Lcom/vdocipher/aegis/cast/internal/CastConnectView$c;-><init>(Lcom/vdocipher/aegis/cast/internal/CastConnectView;Lcom/vdocipher/aegis/cast/internal/CastConnectView$a;)V

    .line 7
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p3

    sget v0, Lcom/vdocipher/aegis/R$layout;->vdo_cast_connect_screen:I

    invoke-virtual {p3, v0, p0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 9
    sget p3, Lcom/vdocipher/aegis/R$id;->container_all:I

    invoke-virtual {p0, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p3

    check-cast p3, Landroid/widget/LinearLayout;

    iput-object p3, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->h:Landroid/widget/LinearLayout;

    const/4 v0, 0x0

    .line 10
    invoke-virtual {p3, v0}, Landroid/view/View;->setVisibility(I)V

    .line 11
    invoke-virtual {p3, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 12
    sget p3, Lcom/vdocipher/aegis/R$id;->playOnCast:I

    invoke-virtual {p0, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p3

    iput-object p3, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->d:Landroid/view/View;

    .line 13
    invoke-virtual {p3, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 14
    sget p3, Lcom/vdocipher/aegis/R$id;->btn_disconnect:I

    invoke-virtual {p0, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p3

    check-cast p3, Landroid/widget/Button;

    iput-object p3, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->e:Landroid/widget/Button;

    .line 15
    sget-object v1, Lcom/vdocipher/aegis/core/z/d;->a:Lcom/vdocipher/aegis/core/z/d;

    sget v2, Lcom/vdocipher/aegis/R$string;->cast_disconnect:I

    const-string v3, "DISCONNECT"

    invoke-virtual {v1, p1, v3, v2}, Lcom/vdocipher/aegis/core/z/d;->a(Landroid/content/Context;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p3, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 16
    invoke-virtual {p3, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 17
    sget p3, Lcom/vdocipher/aegis/R$id;->tvTitle:I

    invoke-virtual {p0, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p3

    check-cast p3, Landroid/widget/TextView;

    iput-object p3, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->f:Landroid/widget/TextView;

    .line 18
    invoke-virtual {p3, v0}, Landroid/view/View;->setVisibility(I)V

    .line 19
    sget p3, Lcom/vdocipher/aegis/R$id;->deviceInfo:I

    invoke-virtual {p0, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p3

    check-cast p3, Landroid/widget/TextView;

    iput-object p3, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->g:Landroid/widget/TextView;

    .line 20
    invoke-virtual {p3, v0}, Landroid/view/View;->setVisibility(I)V

    .line 21
    invoke-virtual {p3, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 22
    invoke-virtual {p0, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 23
    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->a:Landroid/content/Context;

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)Landroid/widget/Button;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->e:Landroid/widget/Button;

    return-object p0
.end method

.method private a()V
    .registers 3

    .line 31
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->b:Lcom/google/android/gms/cast/framework/CastContext;

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/CastContext;->getSessionManager()Lcom/google/android/gms/cast/framework/SessionManager;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/google/android/gms/cast/framework/SessionManager;->endCurrentSession(Z)V

    return-void
.end method

.method private synthetic a(Lcom/google/android/gms/cast/framework/CastSession;Ljava/lang/String;)V
    .registers 4

    .line 27
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->f:Landroid/widget/TextView;

    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 28
    iget-object p2, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->f:Landroid/widget/TextView;

    const/4 v0, 0x0

    invoke-virtual {p2, v0}, Landroid/view/View;->setVisibility(I)V

    .line 29
    iget-object p2, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->d:Landroid/view/View;

    const/16 v0, 0x8

    invoke-virtual {p2, v0}, Landroid/view/View;->setVisibility(I)V

    .line 30
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->setDeviceInfo(Lcom/google/android/gms/cast/framework/CastSession;)V

    return-void
.end method

.method private b()V
    .registers 2

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->b:Lcom/google/android/gms/cast/framework/CastContext;

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/CastContext;->getSessionManager()Lcom/google/android/gms/cast/framework/SessionManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/SessionManager;->getCurrentCastSession()Lcom/google/android/gms/cast/framework/CastSession;

    move-result-object v0

    if-eqz v0, :cond_21

    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->b:Lcom/google/android/gms/cast/framework/CastContext;

    .line 3
    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/CastContext;->getSessionManager()Lcom/google/android/gms/cast/framework/SessionManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/SessionManager;->getCurrentCastSession()Lcom/google/android/gms/cast/framework/CastSession;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/CastSession;->isConnected()Z

    move-result v0

    if-eqz v0, :cond_21

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->c:Lcom/vdocipher/aegis/cast/internal/CastConnectView$b;

    invoke-interface {v0}, Lcom/vdocipher/aegis/cast/internal/CastConnectView$b;->a()V

    :cond_21
    return-void
.end method

.method static synthetic b(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->a()V

    return-void
.end method

.method static synthetic c(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)Landroid/view/View;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->d:Landroid/view/View;

    return-object p0
.end method

.method static synthetic d(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->b()V

    return-void
.end method

.method static synthetic e(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)Landroid/widget/TextView;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->g:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic f(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)Landroid/widget/LinearLayout;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->h:Landroid/widget/LinearLayout;

    return-object p0
.end method

.method static synthetic g(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)Lcom/google/android/gms/cast/framework/CastContext;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->b:Lcom/google/android/gms/cast/framework/CastContext;

    return-object p0
.end method

.method static synthetic h(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)Landroid/content/Context;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->a:Landroid/content/Context;

    return-object p0
.end method

.method private setDeviceInfo(Lcom/google/android/gms/cast/framework/CastSession;)V
    .registers 6

    if-eqz p1, :cond_7

    .line 1
    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastSession;->getCastDevice()Lcom/google/android/gms/cast/CastDevice;

    move-result-object p1

    goto :goto_8

    :cond_7
    const/4 p1, 0x0

    :goto_8
    if-eqz p1, :cond_29

    .line 4
    sget-object v0, Lcom/vdocipher/aegis/core/z/d;->a:Lcom/vdocipher/aegis/core/z/d;

    iget-object v1, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->a:Landroid/content/Context;

    sget v2, Lcom/vdocipher/aegis/R$string;->vdo_now_playing_on:I

    const-string v3, "CONNECT_WITH"

    invoke-virtual {v0, v1, v3, v2}, Lcom/vdocipher/aegis/core/z/d;->a(Landroid/content/Context;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    .line 5
    iget-object v1, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->g:Landroid/widget/TextView;

    invoke-virtual {p1}, Lcom/google/android/gms/cast/CastDevice;->getFriendlyName()Ljava/lang/String;

    move-result-object p1

    filled-new-array {v0, p1}, [Ljava/lang/Object;

    move-result-object p1

    const-string v0, "%s%s"

    invoke-static {v0, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_29
    return-void
.end method


# virtual methods
.method public a(ZLjava/lang/String;Landroidx/lifecycle/MutableLiveData;)V
    .registers 7

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->h:Landroid/widget/LinearLayout;

    const/4 v1, 0x0

    const/16 v2, 0x8

    if-eqz p1, :cond_9

    move p1, v1

    goto :goto_a

    :cond_9
    move p1, v2

    :goto_a
    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 3
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->b:Lcom/google/android/gms/cast/framework/CastContext;

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastContext;->getSessionManager()Lcom/google/android/gms/cast/framework/SessionManager;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/SessionManager;->getCurrentCastSession()Lcom/google/android/gms/cast/framework/CastSession;

    move-result-object p1

    if-eqz p1, :cond_7c

    .line 5
    :try_start_19
    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastSession;->getRemoteMediaClient()Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    move-result-object v0

    if-eqz v0, :cond_7c

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastSession;->getRemoteMediaClient()Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->getMediaInfo()Lcom/google/android/gms/cast/MediaInfo;

    move-result-object v0

    if-eqz v0, :cond_7c

    .line 7
    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastSession;->getRemoteMediaClient()Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->getMediaInfo()Lcom/google/android/gms/cast/MediaInfo;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/gms/cast/MediaInfo;->getCustomData()Lorg/json/JSONObject;

    move-result-object p1

    const/4 p3, 0x0

    if-eqz p1, :cond_3f

    .line 8
    const-string v0, "playbackInfo"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_40

    :cond_3f
    move-object v0, p3

    :goto_40
    if-eqz p1, :cond_48

    .line 9
    const-string p3, "meta"

    invoke-virtual {p1, p3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    .line 10
    :cond_48
    new-instance p1, Lcom/vdocipher/aegis/core/f/g;

    invoke-direct {p1, p3}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    .line 11
    iget-object p3, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->f:Landroid/widget/TextView;

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->r()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p3, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 12
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    .line 13
    iget-object p2, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->f:Landroid/widget/TextView;

    if-eqz p1, :cond_60

    move p3, v1

    goto :goto_61

    :cond_60
    move p3, v2

    :goto_61
    invoke-virtual {p2, p3}, Landroid/view/View;->setVisibility(I)V

    .line 14
    iget-object p2, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->d:Landroid/view/View;

    if-eqz p1, :cond_69

    move v1, v2

    :cond_69
    invoke-virtual {p2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 15
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->b:Lcom/google/android/gms/cast/framework/CastContext;

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastContext;->getSessionManager()Lcom/google/android/gms/cast/framework/SessionManager;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/SessionManager;->getCurrentCastSession()Lcom/google/android/gms/cast/framework/CastSession;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->setDeviceInfo(Lcom/google/android/gms/cast/framework/CastSession;)V

    return-void

    :catch_7a
    move-exception p1

    goto :goto_88

    :cond_7c
    if-nez p3, :cond_7f

    return-void

    .line 18
    :cond_7f
    new-instance p2, Lcom/vdocipher/aegis/cast/internal/CastConnectView$$ExternalSyntheticLambda0;

    invoke-direct {p2, p0, p1}, Lcom/vdocipher/aegis/cast/internal/CastConnectView$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/cast/internal/CastConnectView;Lcom/google/android/gms/cast/framework/CastSession;)V

    invoke-virtual {p3, p2}, Landroidx/lifecycle/MutableLiveData;->observeForever(Landroidx/lifecycle/Observer;)V
    :try_end_87
    .catch Ljava/lang/Exception; {:try_start_19 .. :try_end_87} :catch_7a

    return-void

    .line 26
    :goto_88
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "CastConnectView"

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public setCastContext(Lcom/google/android/gms/cast/framework/CastContext;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->b:Lcom/google/android/gms/cast/framework/CastContext;

    return-void
.end method

.method public setCastVideoPlayerListener(Lcom/vdocipher/aegis/cast/internal/CastConnectView$b;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->c:Lcom/vdocipher/aegis/cast/internal/CastConnectView$b;

    return-void
.end method
