# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda8;->f$0:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda8;->f$0:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    check-cast p1, Lcom/google/android/gms/cast/framework/CastContext;

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->$r8$lambda$ATwFwtErfAg3W8kMYzudCDGBs_w(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Lcom/google/android/gms/cast/framework/CastContext;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
