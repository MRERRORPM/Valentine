# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/concurrent/Executor;


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final execute(Ljava/lang/Runnable;)V
    .registers 2

    .line 0
    invoke-static {p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->$r8$lambda$n6lTwGOxMJOBjXoRNw4rGYrOcZE(Ljava/lang/Runnable;)V

    return-void
.end method
