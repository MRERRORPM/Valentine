# classes14.dex

.class public final Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;
.super Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0096\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0006\u001a\u00020\u0005*\u00020\u0004H\u0002¢\u0006\u0004\b\u0006\u0010\u0007J\u000f\u0010\b\u001a\u00020\u0005H\u0002¢\u0006\u0004\b\b\u0010\tJ3\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u000e2\u001a\u0010\r\u001a\u0016\u0012\u0004\u0012\u00020\u000b\u0018\u00010\nj\n\u0012\u0004\u0012\u00020\u000b\u0018\u0001`\fH\u0002¢\u0006\u0004\b\u0006\u0010\u0010J\u000f\u0010\u0012\u001a\u00020\u0011H\u0002¢\u0006\u0004\b\u0012\u0010\u0003J\u000f\u0010\u0013\u001a\u00020\u0011H\u0002¢\u0006\u0004\b\u0013\u0010\u0003J\u0019\u0010\u0006\u001a\u00020\u00112\b\u0010\u0015\u001a\u0004\u0018\u00010\u0014H\u0002¢\u0006\u0004\b\u0006\u0010\u0016J\u0019\u0010\u0019\u001a\u00020\u00112\b\u0010\u0018\u001a\u0004\u0018\u00010\u0017H\u0014¢\u0006\u0004\b\u0019\u0010\u001aJ\u0017\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u001c\u001a\u00020\u001bH\u0016¢\u0006\u0004\b\u001e\u0010\u001fJ\u000f\u0010 \u001a\u00020\u0011H\u0014¢\u0006\u0004\b \u0010\u0003R\u0016\u0010#\u001a\u00020!8\u0002@\u0002X\u0082.¢\u0006\u0006\n\u0004\b\u0006\u0010\"R\u0018\u0010\'\u001a\u0004\u0018\u00010$8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b%\u0010&R\u001e\u0010*\u001a\n\u0012\u0004\u0012\u00020(\u0018\u00010\u000e8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\b\u0010)R\u001e\u0010+\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u000e8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0013\u0010)R\u0018\u0010.\u001a\u0004\u0018\u00010,8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0012\u0010-R\u0018\u00102\u001a\u0004\u0018\u00010/8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b0\u00101R\"\u00108\u001a\u0002038\u0006@\u0006X\u0086.¢\u0006\u0012\n\u0004\b4\u00105\u001a\u0004\b\u0006\u00106\"\u0004\b\u0006\u00107R6\u0010?\u001a\u0016\u0012\u0004\u0012\u000209\u0018\u00010\nj\n\u0012\u0004\u0012\u000209\u0018\u0001`\f8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b:\u0010;\u001a\u0004\b%\u0010<\"\u0004\b=\u0010>R\u0016\u0010C\u001a\u00020@8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bA\u0010B¨\u0006D"
    }
    d2 = {
        "Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;",
        "Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;",
        "<init>",
        "()V",
        "Landroid/view/WindowManager;",
        "Landroid/graphics/Point;",
        "a",
        "(Landroid/view/WindowManager;)Landroid/graphics/Point;",
        "c",
        "()Landroid/graphics/Point;",
        "Ljava/util/ArrayList;",
        "",
        "Lkotlin/collections/ArrayList;",
        "playbackSpeedOptions",
        "",
        "",
        "(Ljava/util/ArrayList;)Ljava/util/List;",
        "",
        "e",
        "d",
        "Lcom/google/android/gms/cast/framework/CastSession;",
        "castSession",
        "(Lcom/google/android/gms/cast/framework/CastSession;)V",
        "Landroid/os/Bundle;",
        "savedInstanceState",
        "onCreate",
        "(Landroid/os/Bundle;)V",
        "Landroid/view/Menu;",
        "menu",
        "",
        "onCreateOptionsMenu",
        "(Landroid/view/Menu;)Z",
        "onResume",
        "Lcom/google/android/gms/cast/framework/SessionManager;",
        "Lcom/google/android/gms/cast/framework/SessionManager;",
        "castSessionManager",
        "",
        "b",
        "Ljava/lang/Integer;",
        "chosenSpeedIndex",
        "",
        "Ljava/util/List;",
        "allowedSpeedStrList",
        "allowedSpeedList",
        "Lcom/vdocipher/aegis/media/PlayerOption;",
        "Lcom/vdocipher/aegis/media/PlayerOption;",
        "playerOption",
        "Lcom/vdocipher/aegis/core/f/g;",
        "f",
        "Lcom/vdocipher/aegis/core/f/g;",
        "parser",
        "Lcom/vdocipher/aegis/core/e/a;",
        "g",
        "Lcom/vdocipher/aegis/core/e/a;",
        "()Lcom/vdocipher/aegis/core/e/a;",
        "(Lcom/vdocipher/aegis/core/e/a;)V",
        "binding",
        "Lcom/vdocipher/aegis/media/Caption;",
        "h",
        "Ljava/util/ArrayList;",
        "()Ljava/util/ArrayList;",
        "setCaptionsInfoList",
        "(Ljava/util/ArrayList;)V",
        "captionsInfoList",
        "Lcom/vdocipher/aegis/core/y/a;",
        "i",
        "Lcom/vdocipher/aegis/core/y/a;",
        "actionCallback",
        "core_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private a:Lcom/google/android/gms/cast/framework/SessionManager;

.field private b:Ljava/lang/Integer;

.field private c:Ljava/util/List;

.field private d:Ljava/util/List;

.field private e:Lcom/vdocipher/aegis/media/PlayerOption;

.field private f:Lcom/vdocipher/aegis/core/f/g;

.field public g:Lcom/vdocipher/aegis/core/e/a;

.field private h:Ljava/util/ArrayList;

.field private i:Lcom/vdocipher/aegis/core/y/a;


# direct methods
.method public static synthetic $r8$lambda$ATwFwtErfAg3W8kMYzudCDGBs_w(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Lcom/google/android/gms/cast/framework/CastContext;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Lcom/google/android/gms/cast/framework/CastContext;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$IqxVSCojmUA43rVGGPgwzm-_724(Landroid/app/AlertDialog;Landroidx/appcompat/widget/SearchView;Landroid/content/DialogInterface;)V
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a(Landroid/app/AlertDialog;Landroidx/appcompat/widget/SearchView;Landroid/content/DialogInterface;)V

    return-void
.end method

.method public static synthetic $r8$lambda$RuFHwkjHr28AdrZPv0h_Bundw4I(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/app/AlertDialog;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleCue;)V
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/app/AlertDialog;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleCue;)V

    return-void
.end method

.method public static synthetic $r8$lambda$SCMS263CPdFJjOrwtz-41XP9GI0(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/view/View;)V
    .registers 2

    invoke-static {p0, p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->d(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$ZUz3QXTuyea64yZNgGT5GCBbPzk(Lkotlin/jvm/functions/Function1;Ljava/lang/Object;)V
    .registers 2

    invoke-static {p0, p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a(Lkotlin/jvm/functions/Function1;Ljava/lang/Object;)V

    return-void
.end method

.method public static synthetic $r8$lambda$hsv_VPBBeUeQRY5yt7bZAgZk7fw(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/view/View;)V
    .registers 2

    invoke-static {p0, p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->b(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$n6lTwGOxMJOBjXoRNw4rGYrOcZE(Ljava/lang/Runnable;)V
    .registers 1

    invoke-static {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static synthetic $r8$lambda$ndcQ15exsfl6QG-g80hpTx65vvo(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/view/View;)V
    .registers 2

    invoke-static {p0, p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$t9TcRIQZ6eYCuAI8VBT1FT3VoYA(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/view/View;)V
    .registers 2

    invoke-static {p0, p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->c(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/view/View;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;-><init>()V

    const/4 v0, 0x1

    .line 2
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->b:Ljava/lang/Integer;

    .line 233
    new-instance v0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$a;

    invoke-direct {v0, p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$a;-><init>(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->i:Lcom/vdocipher/aegis/core/y/a;

    return-void
.end method

.method private final a(Landroid/view/WindowManager;)Landroid/graphics/Point;
    .registers 7

    .line 7
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_71

    .line 8
    invoke-static {p1}, Lcoil/fetch/ContentUriFetcher$$ExternalSyntheticApiModelOutline0;->m(Landroid/view/WindowManager;)Landroid/view/WindowMetrics;

    move-result-object v0

    invoke-static {v0}, Lcoil/fetch/ContentUriFetcher$$ExternalSyntheticApiModelOutline0;->m(Landroid/view/WindowMetrics;)Landroid/view/WindowInsets;

    move-result-object v0

    const-string v1, "getWindowInsets(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v1

    invoke-static {v0, v1}, Landroidx/core/view/WindowInsetsCompat;->toWindowInsetsCompat(Landroid/view/WindowInsets;Landroid/view/View;)Landroidx/core/view/WindowInsetsCompat;

    move-result-object v1

    const-string/jumbo v2, "toWindowInsetsCompat(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    invoke-static {}, Landroidx/core/view/WindowCompat$$ExternalSyntheticApiModelOutline0;->m$2()I

    move-result v2

    invoke-static {v0, v2}, Landroidx/core/view/WindowCompat$$ExternalSyntheticApiModelOutline0;->m$1(Landroid/view/WindowInsets;I)Landroid/graphics/Insets;

    move-result-object v0

    const-string v2, "getInsets(...)"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    invoke-virtual {v1}, Landroidx/core/view/WindowInsetsCompat;->getDisplayCutout()Landroidx/core/view/DisplayCutoutCompat;

    move-result-object v1

    if-eqz v1, :cond_53

    .line 14
    invoke-virtual {v1}, Landroidx/core/view/DisplayCutoutCompat;->getSafeInsetLeft()I

    move-result v2

    invoke-virtual {v1}, Landroidx/core/view/DisplayCutoutCompat;->getSafeInsetTop()I

    move-result v3

    invoke-virtual {v1}, Landroidx/core/view/DisplayCutoutCompat;->getSafeInsetRight()I

    move-result v4

    invoke-virtual {v1}, Landroidx/core/view/DisplayCutoutCompat;->getSafeInsetBottom()I

    move-result v1

    invoke-static {v2, v3, v4, v1}, Landroidx/activity/ComponentDialog$$ExternalSyntheticApiModelOutline0;->m(IIII)Landroid/graphics/Insets;

    move-result-object v1

    .line 15
    invoke-static {v0, v1}, Lcom/razorpay/BaseUtils$$ExternalSyntheticApiModelOutline0;->m(Landroid/graphics/Insets;Landroid/graphics/Insets;)Landroid/graphics/Insets;

    .line 20
    :cond_53
    new-instance v0, Landroid/graphics/Point;

    invoke-static {p1}, Lcoil/fetch/ContentUriFetcher$$ExternalSyntheticApiModelOutline0;->m(Landroid/view/WindowManager;)Landroid/view/WindowMetrics;

    move-result-object v1

    invoke-static {v1}, Lcoil/fetch/ContentUriFetcher$$ExternalSyntheticApiModelOutline0;->m(Landroid/view/WindowMetrics;)Landroid/graphics/Rect;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    move-result v1

    invoke-static {p1}, Lcoil/fetch/ContentUriFetcher$$ExternalSyntheticApiModelOutline0;->m(Landroid/view/WindowManager;)Landroid/view/WindowMetrics;

    move-result-object p1

    invoke-static {p1}, Lcoil/fetch/ContentUriFetcher$$ExternalSyntheticApiModelOutline0;->m(Landroid/view/WindowMetrics;)Landroid/graphics/Rect;

    move-result-object p1

    invoke-virtual {p1}, Landroid/graphics/Rect;->height()I

    move-result p1

    invoke-direct {v0, v1, p1}, Landroid/graphics/Point;-><init>(II)V

    return-object v0

    .line 22
    :cond_71
    invoke-direct {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->c()Landroid/graphics/Point;

    move-result-object p1

    return-object p1
.end method

.method public static final synthetic a(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)Ljava/util/List;
    .registers 1

    .line 2
    iget-object p0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->d:Ljava/util/List;

    return-object p0
.end method

.method private final a(Ljava/util/ArrayList;)Ljava/util/List;
    .registers 9

    if-eqz p1, :cond_92

    .line 23
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_92

    .line 24
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->d:Ljava/util/List;

    .line 25
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->c:Ljava/util/List;

    .line 27
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const-string v0, "iterator(...)"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_1f
    :goto_1f
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_92

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "next(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v0

    .line 28
    iget-object v2, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->d:Ljava/util/List;

    if-eqz v2, :cond_40

    double-to-float v3, v0

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_40
    const/16 v2, 0xa

    int-to-double v3, v2

    mul-double/2addr v3, v0

    double-to-int v3, v3

    .line 29
    rem-int/2addr v3, v2

    xor-int/lit8 v4, v3, 0xa

    neg-int v5, v3

    or-int/2addr v5, v3

    and-int/2addr v4, v5

    shr-int/lit8 v4, v4, 0x1f

    and-int/2addr v2, v4

    add-int/2addr v3, v2

    const-string v2, "format(...)"

    const-string v4, "%sx"

    const/4 v5, 0x1

    if-eqz v3, :cond_74

    .line 30
    iget-object v3, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->c:Ljava/util/List;

    if-eqz v3, :cond_1f

    sget-object v6, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    double-to-float v0, v0

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, v5}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    invoke-static {v4, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_1f

    .line 32
    :cond_74
    iget-object v3, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->c:Ljava/util/List;

    if-eqz v3, :cond_1f

    sget-object v6, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    double-to-int v0, v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, v5}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    invoke-static {v4, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_1f

    .line 37
    :cond_92
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->d:Ljava/util/List;

    return-object p1
.end method

.method private static final a(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Lcom/google/android/gms/cast/framework/CastContext;)Lkotlin/Unit;
    .registers 3

    .line 48
    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastContext;->getSessionManager()Lcom/google/android/gms/cast/framework/SessionManager;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a:Lcom/google/android/gms/cast/framework/SessionManager;

    .line 49
    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastContext;->getSessionManager()Lcom/google/android/gms/cast/framework/SessionManager;

    move-result-object p1

    if-eqz p1, :cond_11

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/SessionManager;->getCurrentCastSession()Lcom/google/android/gms/cast/framework/CastSession;

    move-result-object p1

    goto :goto_12

    :cond_11
    const/4 p1, 0x0

    :goto_12
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a(Lcom/google/android/gms/cast/framework/CastSession;)V

    .line 50
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final a(Landroid/app/AlertDialog;Landroidx/appcompat/widget/SearchView;Landroid/content/DialogInterface;)V
    .registers 3

    .line 45
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 p2, 0x3

    invoke-virtual {p0, p2}, Landroid/view/View;->setLayoutDirection(I)V

    .line 46
    invoke-virtual {p1, p2}, Landroidx/appcompat/widget/SearchView;->setLayoutDirection(I)V

    return-void
.end method

.method private final a(Lcom/google/android/gms/cast/framework/CastSession;)V
    .registers 7

    if-eqz p1, :cond_4f

    .line 51
    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastSession;->getCastDevice()Lcom/google/android/gms/cast/CastDevice;

    move-result-object v0

    if-eqz v0, :cond_4f

    .line 52
    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastSession;->getCastDevice()Lcom/google/android/gms/cast/CastDevice;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_14

    invoke-virtual {v0}, Lcom/google/android/gms/cast/CastDevice;->getFriendlyName()Ljava/lang/String;

    move-result-object v0

    goto :goto_15

    :cond_14
    move-object v0, v1

    .line 53
    :goto_15
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_4f

    .line 57
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v2, Lcom/vdocipher/aegis/core/z/d;->a:Lcom/vdocipher/aegis/core/z/d;

    sget v3, Lcom/vdocipher/aegis/R$string;->vdo_connect_with:I

    const-string v4, "CONNECT_WITH"

    invoke-virtual {v2, p0, v4, v3}, Lcom/vdocipher/aegis/core/z/d;->a(Landroid/content/Context;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastSession;->getCastDevice()Lcom/google/android/gms/cast/CastDevice;

    move-result-object p1

    if-eqz p1, :cond_37

    invoke-virtual {p1}, Lcom/google/android/gms/cast/CastDevice;->getFriendlyName()Ljava/lang/String;

    move-result-object v1

    :cond_37
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 58
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object v0

    iget-object v0, v0, Lcom/vdocipher/aegis/core/e/a;->m:Landroidx/appcompat/widget/AppCompatTextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 59
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->onPreloadStatusUpdated()V

    return-void

    .line 61
    :cond_4f
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->m:Landroidx/appcompat/widget/AppCompatTextView;

    const-string v0, ""

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private static final a(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/app/AlertDialog;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleCue;)V
    .registers 6

    if-eqz p2, :cond_29

    .line 38
    new-instance v0, Lcom/google/android/gms/cast/MediaSeekOptions$Builder;

    invoke-direct {v0}, Lcom/google/android/gms/cast/MediaSeekOptions$Builder;-><init>()V

    .line 39
    invoke-virtual {p2}, Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleCue;->getStartTime()J

    move-result-wide v1

    .line 40
    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/cast/MediaSeekOptions$Builder;->setPosition(J)Lcom/google/android/gms/cast/MediaSeekOptions$Builder;

    move-result-object p2

    .line 42
    invoke-virtual {p2}, Lcom/google/android/gms/cast/MediaSeekOptions$Builder;->build()Lcom/google/android/gms/cast/MediaSeekOptions;

    move-result-object p2

    const-string v0, "build(...)"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object p0

    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->getRemoteMediaClient()Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    move-result-object p0

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {p0, p2}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->seek(Lcom/google/android/gms/cast/MediaSeekOptions;)Lcom/google/android/gms/common/api/PendingResult;

    .line 44
    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    :cond_29
    return-void
.end method

.method private static final a(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/view/View;)V
    .registers 2

    .line 6
    invoke-direct {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->d()V

    return-void
.end method

.method public static final synthetic a(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Ljava/lang/Integer;)V
    .registers 2

    .line 3
    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->b:Ljava/lang/Integer;

    return-void
.end method

.method private static final a(Ljava/lang/Runnable;)V
    .registers 1

    return-void
.end method

.method private static final a(Lkotlin/jvm/functions/Function1;Ljava/lang/Object;)V
    .registers 2

    .line 47
    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static final synthetic b(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)Ljava/util/List;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->c:Ljava/util/List;

    return-object p0
.end method

.method private static final b(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/view/View;)V
    .registers 5

    .line 3
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e:Lcom/vdocipher/aegis/media/PlayerOption;

    if-eqz p1, :cond_19

    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/PlayerOption;->getChapters()Ljava/util/ArrayList;

    move-result-object p1

    if-eqz p1, :cond_19

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 5
    sget-object p1, Lcom/vdocipher/aegis/ui/view/internal/a;->g:Lcom/vdocipher/aegis/ui/view/internal/a$a;

    const/4 v1, 0x2

    .line 6
    const-string v2, ""

    invoke-virtual {p1, v1, v2, v0}, Lcom/vdocipher/aegis/ui/view/internal/a$a;->a(ILjava/lang/String;Ljava/util/ArrayList;)Lcom/vdocipher/aegis/ui/view/internal/a;

    move-result-object p1

    goto :goto_1a

    :cond_19
    const/4 p1, 0x0

    :goto_1a
    if-eqz p1, :cond_21

    .line 12
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->i:Lcom/vdocipher/aegis/core/y/a;

    invoke-virtual {p1, v0}, Lcom/vdocipher/aegis/ui/view/internal/a;->a(Lcom/vdocipher/aegis/core/y/a;)V

    :cond_21
    if-eqz p1, :cond_30

    .line 14
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p0

    .line 15
    const-class v0, Lcom/vdocipher/aegis/ui/view/VdoPlayerUIFragment;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    .line 16
    invoke-virtual {p1, p0, v0}, Lcom/google/android/material/bottomsheet/BottomSheetDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    :cond_30
    return-void
.end method

.method private final c()Landroid/graphics/Point;
    .registers 5

    .line 3
    new-instance v0, Landroid/graphics/Point;

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    .line 4
    const-string/jumbo v1, "window"

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const-string v2, "null cannot be cast to non-null type android.view.WindowManager"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Landroid/view/WindowManager;

    .line 6
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1e

    if-lt v2, v3, :cond_33

    .line 7
    invoke-static {v1}, Lcoil/fetch/ContentUriFetcher$$ExternalSyntheticApiModelOutline0;->m(Landroid/view/WindowManager;)Landroid/view/WindowMetrics;

    move-result-object v1

    invoke-static {v1}, Lcoil/fetch/ContentUriFetcher$$ExternalSyntheticApiModelOutline0;->m(Landroid/view/WindowMetrics;)Landroid/graphics/Rect;

    move-result-object v1

    const-string v2, "getBounds(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    move-result v2

    iput v2, v0, Landroid/graphics/Point;->x:I

    .line 9
    invoke-virtual {v1}, Landroid/graphics/Rect;->height()I

    move-result v1

    iput v1, v0, Landroid/graphics/Point;->y:I

    return-object v0

    .line 11
    :cond_33
    new-instance v2, Landroid/util/DisplayMetrics;

    invoke-direct {v2}, Landroid/util/DisplayMetrics;-><init>()V

    .line 12
    invoke-interface {v1}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/view/Display;->getMetrics(Landroid/util/DisplayMetrics;)V

    .line 13
    iget v1, v2, Landroid/util/DisplayMetrics;->widthPixels:I

    iput v1, v0, Landroid/graphics/Point;->x:I

    .line 14
    iget v1, v2, Landroid/util/DisplayMetrics;->heightPixels:I

    iput v1, v0, Landroid/graphics/Point;->y:I

    return-object v0
.end method

.method public static final synthetic c(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)Ljava/lang/Integer;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->b:Ljava/lang/Integer;

    return-object p0
.end method

.method private static final c(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/view/View;)V
    .registers 2

    .line 2
    invoke-direct {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e()V

    return-void
.end method

.method private final d()V
    .registers 6

    .line 17
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 18
    invoke-virtual {p0}, Landroid/app/Activity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v1

    sget v2, Lcom/vdocipher/aegis/R$layout;->vdo_cast_volume:I

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v1

    const-string v2, "inflate(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    sget v2, Lcom/vdocipher/aegis/R$id;->seek_bar_volume:I

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/SeekBar;

    .line 21
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    .line 23
    new-instance v1, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;

    iget-object v4, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a:Lcom/google/android/gms/cast/framework/SessionManager;

    if-nez v4, :cond_2c

    const-string v4, "castSessionManager"

    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_2d

    :cond_2c
    move-object v3, v4

    :goto_2d
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {v1, p0, v3, v2}, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;-><init>(Landroid/content/Context;Lcom/google/android/gms/cast/framework/SessionManager;Landroid/widget/SeekBar;)V

    .line 24
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getLifecycle()Landroidx/lifecycle/Lifecycle;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroidx/lifecycle/Lifecycle;->addObserver(Landroidx/lifecycle/LifecycleObserver;)V

    .line 25
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    const/4 v1, 0x1

    .line 26
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    .line 27
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method private static final d(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/view/View;)V
    .registers 5

    .line 1
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->d:Ljava/util/List;

    if-eqz p1, :cond_1d

    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->toMutableList(Ljava/util/Collection;)Ljava/util/List;

    move-result-object p1

    if-eqz p1, :cond_1d

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 3
    sget-object p1, Lcom/vdocipher/aegis/ui/view/internal/a;->g:Lcom/vdocipher/aegis/ui/view/internal/a$a;

    .line 5
    iget-object v1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->b:Ljava/lang/Integer;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    .line 6
    invoke-virtual {p1, v2, v1, v0}, Lcom/vdocipher/aegis/ui/view/internal/a$a;->a(ILjava/lang/String;Ljava/util/ArrayList;)Lcom/vdocipher/aegis/ui/view/internal/a;

    move-result-object p1

    goto :goto_1e

    :cond_1d
    const/4 p1, 0x0

    :goto_1e
    if-eqz p1, :cond_25

    .line 12
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->i:Lcom/vdocipher/aegis/core/y/a;

    invoke-virtual {p1, v0}, Lcom/vdocipher/aegis/ui/view/internal/a;->a(Lcom/vdocipher/aegis/core/y/a;)V

    :cond_25
    if-eqz p1, :cond_34

    .line 14
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p0

    .line 15
    const-class v0, Lcom/vdocipher/aegis/ui/view/VdoPlayerUIFragment;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    .line 16
    invoke-virtual {p1, p0, v0}, Lcom/google/android/material/bottomsheet/BottomSheetDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    :cond_34
    return-void
.end method

.method private final e()V
    .registers 16

    .line 1
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 3
    invoke-virtual {p0}, Landroid/app/Activity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v1

    sget v2, Lcom/vdocipher/aegis/R$layout;->vdo_caption_search_dialog_view:I

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1, v2, v3, v4}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    const-string v2, "inflate(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 5
    sget v2, Lcom/vdocipher/aegis/R$id;->et_search:I

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const-string v3, "findViewById(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Landroidx/appcompat/widget/SearchView;

    .line 6
    sget-object v5, Lcom/vdocipher/aegis/core/z/d;->a:Lcom/vdocipher/aegis/core/z/d;

    sget v6, Lcom/vdocipher/aegis/R$string;->vdo_type_here:I

    const-string v7, "TYPE_HERE"

    invoke-virtual {v5, p0, v7, v6}, Lcom/vdocipher/aegis/core/z/d;->a(Landroid/content/Context;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Landroidx/appcompat/widget/SearchView;->setQueryHint(Ljava/lang/CharSequence;)V

    .line 7
    sget v5, Lcom/vdocipher/aegis/R$id;->rv_search_result:I

    invoke-virtual {v1, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Landroidx/recyclerview/widget/RecyclerView;

    .line 8
    sget v6, Lcom/vdocipher/aegis/R$id;->tv_error_msg:I

    invoke-virtual {v1, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, Landroidx/appcompat/widget/AppCompatTextView;

    .line 9
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    .line 10
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    .line 11
    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    if-eqz v1, :cond_57

    const/4 v3, 0x5

    invoke-virtual {v1, v3}, Landroid/view/Window;->setSoftInputMode(I)V

    .line 13
    :cond_57
    new-instance v7, Lcom/vdocipher/aegis/ui/view/internal/b;

    .line 14
    new-instance v14, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda1;

    invoke-direct {v14, p0, v0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda1;-><init>(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/app/AlertDialog;)V

    const-wide/16 v10, 0x0

    const-wide/16 v12, 0x0

    const/4 v9, 0x0

    move-object v8, p0

    .line 15
    invoke-direct/range {v7 .. v14}, Lcom/vdocipher/aegis/ui/view/internal/b;-><init>(Landroid/content/Context;ZJJLcom/vdocipher/aegis/ui/view/internal/b$a;)V

    .line 24
    invoke-virtual {v5, v7}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 25
    new-instance v1, Landroidx/recyclerview/widget/LinearLayoutManager;

    const/4 v3, 0x1

    .line 26
    invoke-direct {v1, p0, v3, v4}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;IZ)V

    .line 31
    invoke-virtual {v5, v1}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 32
    new-instance v1, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b;

    invoke-direct {v1, p0, v7, v6}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b;-><init>(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Lcom/vdocipher/aegis/ui/view/internal/b;Landroidx/appcompat/widget/AppCompatTextView;)V

    invoke-virtual {v2, v1}, Landroidx/appcompat/widget/SearchView;->setOnQueryTextListener(Landroidx/appcompat/widget/SearchView$OnQueryTextListener;)V

    .line 73
    new-instance v1, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda2;

    invoke-direct {v1, v0, v2}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda2;-><init>(Landroid/app/AlertDialog;Landroidx/appcompat/widget/SearchView;)V

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 77
    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method


# virtual methods
.method public final a()Lcom/vdocipher/aegis/core/e/a;
    .registers 2

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->g:Lcom/vdocipher/aegis/core/e/a;

    if-eqz v0, :cond_5

    return-object v0

    :cond_5
    const-string v0, "binding"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final a(Lcom/vdocipher/aegis/core/e/a;)V
    .registers 3

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 5
    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->g:Lcom/vdocipher/aegis/core/e/a;

    return-void
.end method

.method public final b()Ljava/util/ArrayList;
    .registers 2

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->h:Ljava/util/ArrayList;

    return-object v0
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 13

    .line 1
    invoke-super {p0, p1}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->onCreate(Landroid/os/Bundle;)V

    .line 3
    invoke-virtual {p0}, Landroid/app/Activity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object p1

    invoke-static {p1}, Lcom/vdocipher/aegis/core/e/a;->a(Landroid/view/LayoutInflater;)Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a(Lcom/vdocipher/aegis/core/e/a;)V

    .line 4
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/e/a;->a()Landroidx/constraintlayout/widget/ConstraintLayout;

    move-result-object p1

    const-string v0, "getRoot(...)"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 5
    invoke-virtual {p0, p1}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V

    .line 7
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->getRemoteMediaClient()Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    move-result-object p1

    const/4 v0, 0x0

    if-eqz p1, :cond_34

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->getMediaInfo()Lcom/google/android/gms/cast/MediaInfo;

    move-result-object p1

    if-eqz p1, :cond_34

    invoke-virtual {p1}, Lcom/google/android/gms/cast/MediaInfo;->getCustomData()Lorg/json/JSONObject;

    move-result-object p1

    goto :goto_35

    :cond_34
    move-object p1, v0

    .line 11
    :goto_35
    :try_start_35
    new-instance v1, Lcom/vdocipher/aegis/core/f/g;

    if-eqz p1, :cond_40

    const-string v2, "meta"

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_41

    :cond_40
    move-object p1, v0

    .line 12
    :goto_41
    invoke-direct {v1, p1}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    iput-object v1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->f:Lcom/vdocipher/aegis/core/f/g;
    :try_end_46
    .catch Ljava/lang/Exception; {:try_start_35 .. :try_end_46} :catch_47

    goto :goto_4a

    .line 14
    :catch_47
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 16
    :goto_4a
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->f:Lcom/vdocipher/aegis/core/f/g;

    if-eqz p1, :cond_53

    invoke-virtual {p1, v0, v0}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/lang/String;Ljava/util/HashMap;)Lcom/vdocipher/aegis/media/PlayerOption;

    move-result-object p1

    goto :goto_54

    :cond_53
    move-object p1, v0

    :goto_54
    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e:Lcom/vdocipher/aegis/media/PlayerOption;

    .line 18
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->h:Ljava/util/ArrayList;

    .line 20
    iget-object v1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->f:Lcom/vdocipher/aegis/core/f/g;

    if-eqz v1, :cond_64

    invoke-virtual {v1, p1}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/util/ArrayList;)Ljava/util/ArrayList;

    .line 23
    :cond_64
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object p1

    .line 24
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object v1

    iget-object v1, v1, Lcom/vdocipher/aegis/core/e/a;->p:Landroidx/appcompat/widget/AppCompatTextView;

    .line 25
    const-string v2, "com.google.android.gms.cast.metadata.TITLE"

    invoke-virtual {p1, v1, v2}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->bindTextViewToMetadataOfCurrentItem(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 29
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object p1

    .line 30
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object v1

    iget-object v1, v1, Lcom/vdocipher/aegis/core/e/a;->o:Landroidx/appcompat/widget/AppCompatTextView;

    .line 31
    const-string v2, "com.google.android.gms.cast.metadata.SUBTITLE"

    invoke-virtual {p1, v1, v2}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->bindTextViewToMetadataOfCurrentItem(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 37
    const-class p1, Landroid/view/WindowManager;

    invoke-virtual {p0, p1}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    const-string v1, "getSystemService(...)"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Landroid/view/WindowManager;

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a(Landroid/view/WindowManager;)Landroid/graphics/Point;

    move-result-object p1

    .line 38
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object v1

    .line 39
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object v2

    iget-object v2, v2, Lcom/vdocipher/aegis/core/e/a;->i:Landroidx/appcompat/widget/AppCompatImageView;

    .line 40
    new-instance v3, Lcom/google/android/gms/cast/framework/media/ImageHints;

    iget v4, p1, Landroid/graphics/Point;->x:I

    iget p1, p1, Landroid/graphics/Point;->y:I

    const/4 v5, 0x4

    invoke-direct {v3, v5, v4, p1}, Lcom/google/android/gms/cast/framework/media/ImageHints;-><init>(III)V

    .line 41
    sget p1, Lcom/vdocipher/aegis/R$drawable;->vdo_logo_thumb:I

    .line 42
    invoke-virtual {v1, v2, v3, p1}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->bindImageViewToImageOfCurrentItem(Landroid/widget/ImageView;Lcom/google/android/gms/cast/framework/media/ImageHints;I)V

    .line 47
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->g:Landroidx/appcompat/widget/AppCompatImageButton;

    new-instance v1, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda3;-><init>(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)V

    invoke-virtual {p1, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 51
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e:Lcom/vdocipher/aegis/media/PlayerOption;

    const/4 v1, 0x0

    if-eqz p1, :cond_d6

    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object p1

    if-eqz p1, :cond_d6

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object p1

    if-eqz p1, :cond_d6

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/h;->v()Ljava/lang/Boolean;

    move-result-object p1

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    goto :goto_d7

    :cond_d6
    move p1, v1

    :goto_d7
    if-eqz p1, :cond_e3

    .line 52
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->l:Lcom/google/android/gms/cast/framework/media/widget/CastSeekBar;

    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    goto :goto_f2

    .line 54
    :cond_e3
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object p1

    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object v2

    iget-object v2, v2, Lcom/vdocipher/aegis/core/e/a;->l:Lcom/google/android/gms/cast/framework/media/widget/CastSeekBar;

    const-wide/16 v3, 0x3e8

    invoke-virtual {p1, v2, v3, v4}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->bindSeekBar(Lcom/google/android/gms/cast/framework/media/widget/CastSeekBar;J)V

    .line 57
    :goto_f2
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e:Lcom/vdocipher/aegis/media/PlayerOption;

    if-eqz p1, :cond_10d

    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object p1

    if-eqz p1, :cond_10d

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object p1

    if-eqz p1, :cond_10d

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/h;->A()Ljava/lang/Boolean;

    move-result-object p1

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    goto :goto_10e

    :cond_10d
    move p1, v1

    :goto_10e
    const/4 v2, 0x1

    if-eqz p1, :cond_124

    .line 58
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->q:Landroidx/appcompat/widget/AppCompatTextView;

    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    .line 59
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->n:Landroidx/appcompat/widget/AppCompatTextView;

    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    goto :goto_13e

    .line 61
    :cond_124
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object p1

    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object v3

    iget-object v3, v3, Lcom/vdocipher/aegis/core/e/a;->n:Landroidx/appcompat/widget/AppCompatTextView;

    invoke-virtual {p1, v3, v2}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->bindTextViewToStreamPosition(Landroid/widget/TextView;Z)V

    .line 62
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object p1

    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object v3

    iget-object v3, v3, Lcom/vdocipher/aegis/core/e/a;->q:Landroidx/appcompat/widget/AppCompatTextView;

    invoke-virtual {p1, v3}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->bindTextViewToStreamDuration(Landroid/widget/TextView;)V

    .line 65
    :goto_13e
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e:Lcom/vdocipher/aegis/media/PlayerOption;

    if-eqz p1, :cond_159

    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object p1

    if-eqz p1, :cond_159

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object p1

    if-eqz p1, :cond_159

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/h;->s()Ljava/lang/Boolean;

    move-result-object p1

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    goto :goto_15a

    :cond_159
    move p1, v1

    :goto_15a
    if-eqz p1, :cond_166

    .line 66
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->f:Landroidx/appcompat/widget/AppCompatImageButton;

    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    goto :goto_18e

    .line 68
    :cond_166
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e:Lcom/vdocipher/aegis/media/PlayerOption;

    if-eqz p1, :cond_18e

    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object p1

    if-eqz p1, :cond_18e

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object p1

    if-eqz p1, :cond_18e

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/h;->B()Ljava/lang/Integer;

    move-result-object p1

    if-eqz p1, :cond_18e

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    .line 69
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object v3

    .line 70
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object v4

    iget-object v4, v4, Lcom/vdocipher/aegis/core/e/a;->f:Landroidx/appcompat/widget/AppCompatImageButton;

    int-to-long v6, p1

    .line 71
    invoke-virtual {v3, v4, v6, v7}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->bindViewToForward(Landroid/view/View;J)V

    .line 78
    :cond_18e
    :goto_18e
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e:Lcom/vdocipher/aegis/media/PlayerOption;

    if-eqz p1, :cond_1a9

    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object p1

    if-eqz p1, :cond_1a9

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object p1

    if-eqz p1, :cond_1a9

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/h;->n()Ljava/lang/Boolean;

    move-result-object p1

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    goto :goto_1aa

    :cond_1a9
    move p1, v1

    :goto_1aa
    if-eqz p1, :cond_1b6

    .line 79
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->b:Landroidx/appcompat/widget/AppCompatImageButton;

    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    goto :goto_1de

    .line 81
    :cond_1b6
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e:Lcom/vdocipher/aegis/media/PlayerOption;

    if-eqz p1, :cond_1de

    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object p1

    if-eqz p1, :cond_1de

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object p1

    if-eqz p1, :cond_1de

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/h;->B()Ljava/lang/Integer;

    move-result-object p1

    if-eqz p1, :cond_1de

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    .line 82
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object v3

    .line 83
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object v4

    iget-object v4, v4, Lcom/vdocipher/aegis/core/e/a;->b:Landroidx/appcompat/widget/AppCompatImageButton;

    int-to-long v6, p1

    .line 84
    invoke-virtual {v3, v4, v6, v7}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->bindViewToRewind(Landroid/view/View;J)V

    .line 91
    :cond_1de
    :goto_1de
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e:Lcom/vdocipher/aegis/media/PlayerOption;

    if-eqz p1, :cond_1f9

    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object p1

    if-eqz p1, :cond_1f9

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object p1

    if-eqz p1, :cond_1f9

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/h;->u()Ljava/lang/Boolean;

    move-result-object p1

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    goto :goto_1fa

    :cond_1f9
    move p1, v1

    :goto_1fa
    if-eqz p1, :cond_206

    .line 92
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->h:Landroidx/appcompat/widget/AppCompatImageButton;

    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    goto :goto_23c

    .line 94
    :cond_206
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    sget v3, Lcom/vdocipher/aegis/R$drawable;->vdo_ic_play:I

    invoke-static {p1, v3, v0}, Landroidx/core/content/res/ResourcesCompat;->getDrawable(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    .line 95
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    sget v3, Lcom/vdocipher/aegis/R$drawable;->vdo_ic_pause:I

    invoke-static {p1, v3, v0}, Landroidx/core/content/res/ResourcesCompat;->getDrawable(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object v7

    .line 96
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    sget v3, Lcom/vdocipher/aegis/R$drawable;->vdo_ic_pause:I

    invoke-static {p1, v3, v0}, Landroidx/core/content/res/ResourcesCompat;->getDrawable(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object v8

    .line 98
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object v4

    .line 99
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object v5, p1, Lcom/vdocipher/aegis/core/e/a;->h:Landroidx/appcompat/widget/AppCompatImageButton;

    .line 100
    invoke-static {v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 101
    invoke-static {v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 102
    invoke-static {v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/4 v9, 0x0

    const/4 v10, 0x0

    .line 103
    invoke-virtual/range {v4 .. v10}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->bindImageViewToPlayPauseToggle(Landroid/widget/ImageView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/view/View;Z)V

    .line 114
    :goto_23c
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e:Lcom/vdocipher/aegis/media/PlayerOption;

    if-eqz p1, :cond_257

    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object p1

    if-eqz p1, :cond_257

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object p1

    if-eqz p1, :cond_257

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/h;->q()Ljava/lang/Boolean;

    move-result-object p1

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    goto :goto_258

    :cond_257
    move p1, v1

    :goto_258
    const/16 v3, 0x8

    if-nez p1, :cond_281

    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e:Lcom/vdocipher/aegis/media/PlayerOption;

    if-eqz p1, :cond_26e

    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/PlayerOption;->getChapters()Ljava/util/ArrayList;

    move-result-object p1

    if-eqz p1, :cond_26e

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-nez p1, :cond_26e

    move p1, v2

    goto :goto_26f

    :cond_26e
    move p1, v1

    :goto_26f
    if-eqz p1, :cond_272

    goto :goto_281

    .line 117
    :cond_272
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->e:Landroidx/appcompat/widget/AppCompatImageButton;

    new-instance v4, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda4;

    invoke-direct {v4, p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda4;-><init>(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)V

    invoke-virtual {p1, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_28a

    .line 118
    :cond_281
    :goto_281
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->e:Landroidx/appcompat/widget/AppCompatImageButton;

    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    .line 140
    :goto_28a
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e:Lcom/vdocipher/aegis/media/PlayerOption;

    if-eqz p1, :cond_2a5

    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object p1

    if-eqz p1, :cond_2a5

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object p1

    if-eqz p1, :cond_2a5

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/h;->g()Ljava/lang/Boolean;

    move-result-object p1

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    goto :goto_2a6

    :cond_2a5
    move p1, v1

    :goto_2a6
    if-nez p1, :cond_2c7

    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->h:Ljava/util/ArrayList;

    if-eqz p1, :cond_2b4

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-nez p1, :cond_2b4

    move p1, v2

    goto :goto_2b5

    :cond_2b4
    move p1, v1

    :goto_2b5
    if-eqz p1, :cond_2b8

    goto :goto_2c7

    .line 143
    :cond_2b8
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->c:Landroidx/appcompat/widget/AppCompatImageButton;

    new-instance v4, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda5;

    invoke-direct {v4, p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda5;-><init>(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)V

    invoke-virtual {p1, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_2d0

    .line 144
    :cond_2c7
    :goto_2c7
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->c:Landroidx/appcompat/widget/AppCompatImageButton;

    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    .line 151
    :goto_2d0
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e:Lcom/vdocipher/aegis/media/PlayerOption;

    if-eqz p1, :cond_2eb

    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object p1

    if-eqz p1, :cond_2eb

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object p1

    if-eqz p1, :cond_2eb

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/h;->g()Ljava/lang/Boolean;

    move-result-object p1

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    goto :goto_2ec

    :cond_2eb
    move p1, v1

    :goto_2ec
    if-nez p1, :cond_30b

    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->h:Ljava/util/ArrayList;

    if-eqz p1, :cond_2f9

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-nez p1, :cond_2f9

    goto :goto_2fa

    :cond_2f9
    move v2, v1

    :goto_2fa
    if-eqz v2, :cond_2fd

    goto :goto_30b

    .line 154
    :cond_2fd
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object p1

    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object v2

    iget-object v2, v2, Lcom/vdocipher/aegis/core/e/a;->d:Landroidx/appcompat/widget/AppCompatImageButton;

    invoke-virtual {p1, v2}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->bindViewToClosedCaption(Landroid/view/View;)V

    goto :goto_314

    .line 155
    :cond_30b
    :goto_30b
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->d:Landroidx/appcompat/widget/AppCompatImageButton;

    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    .line 161
    :goto_314
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e:Lcom/vdocipher/aegis/media/PlayerOption;

    if-eqz p1, :cond_32e

    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object p1

    if-eqz p1, :cond_32e

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object p1

    if-eqz p1, :cond_32e

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/h;->z()Ljava/lang/Boolean;

    move-result-object p1

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    :cond_32e
    if-eqz v1, :cond_33a

    .line 162
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->r:Landroidx/appcompat/widget/AppCompatTextView;

    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    goto :goto_348

    .line 164
    :cond_33a
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->r:Landroidx/appcompat/widget/AppCompatTextView;

    new-instance v1, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda6;

    invoke-direct {v1, p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda6;-><init>(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)V

    invoke-virtual {p1, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 182
    :goto_348
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e:Lcom/vdocipher/aegis/media/PlayerOption;

    if-eqz p1, :cond_35d

    invoke-virtual {p1}, Lcom/vdocipher/aegis/media/PlayerOption;->getPlayerConfig()Lcom/vdocipher/aegis/core/f/i;

    move-result-object p1

    if-eqz p1, :cond_35d

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/i;->a()Lcom/vdocipher/aegis/core/f/h;

    move-result-object p1

    if-eqz p1, :cond_35d

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/h;->l()Ljava/util/ArrayList;

    move-result-object p1

    goto :goto_35e

    :cond_35d
    move-object p1, v0

    :goto_35e
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a(Ljava/util/ArrayList;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->d:Ljava/util/List;

    if-eqz p1, :cond_374

    .line 184
    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->toFloatArray(Ljava/util/Collection;)[F

    move-result-object p1

    const/high16 v0, 0x3f800000  # 1.0f

    .line 185
    invoke-static {p1, v0}, Lcom/vdocipher/aegis/core/z/d;->a([FF)I

    move-result p1

    .line 189
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    .line 190
    :cond_374
    iput-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->b:Ljava/lang/Integer;

    .line 198
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->getRemoteMediaClient()Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    move-result-object p1

    if-eqz p1, :cond_385

    const-wide/high16 v0, 0x3ff0000000000000L  # 1.0

    invoke-virtual {p1, v0, v1}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->setPlaybackRate(D)Lcom/google/android/gms/common/api/PendingResult;

    :cond_385
    return-void
.end method

.method public onCreateOptionsMenu(Landroid/view/Menu;)Z
    .registers 3

    const-string v0, "menu"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-super {p0, p1}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->onCreateOptionsMenu(Landroid/view/Menu;)Z

    .line 2
    sget v0, Lcom/vdocipher/aegis/R$id;->media_route_menu_item:I

    invoke-static {p0, p1, v0}, Lcom/google/android/gms/cast/framework/CastButtonFactory;->setUpMediaRouteButton(Landroid/content/Context;Landroid/view/Menu;I)Landroid/view/MenuItem;

    const/4 p1, 0x1

    return p1
.end method

.method protected onResume()V
    .registers 4

    .line 1
    invoke-super {p0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->onResume()V

    .line 2
    new-instance v0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda7;

    invoke-direct {v0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda7;-><init>()V

    invoke-static {p0, v0}, Lcom/google/android/gms/cast/framework/CastContext;->getSharedInstance(Landroid/content/Context;Ljava/util/concurrent/Executor;)Lcom/google/android/gms/tasks/Task;

    move-result-object v0

    new-instance v1, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda8;

    invoke-direct {v1, p0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda8;-><init>(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)V

    new-instance v2, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda9;

    invoke-direct {v2, v1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda9;-><init>(Lkotlin/jvm/functions/Function1;)V

    invoke-virtual {v0, v2}, Lcom/google/android/gms/tasks/Task;->addOnSuccessListener(Lcom/google/android/gms/tasks/OnSuccessListener;)Lcom/google/android/gms/tasks/Task;

    return-void
.end method
