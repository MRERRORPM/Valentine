# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lcom/vdocipher/aegis/ui/view/internal/b$a;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

.field public final synthetic f$1:Landroid/app/AlertDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/app/AlertDialog;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    iput-object p2, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda1;->f$1:Landroid/app/AlertDialog;

    return-void
.end method


# virtual methods
.method public final a(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleCue;)V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda1;->f$0:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    iget-object v1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda1;->f$1:Landroid/app/AlertDialog;

    invoke-static {v0, v1, p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->$r8$lambda$RuFHwkjHr28AdrZPv0h_Bundw4I(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/app/AlertDialog;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleCue;)V

    return-void
.end method
