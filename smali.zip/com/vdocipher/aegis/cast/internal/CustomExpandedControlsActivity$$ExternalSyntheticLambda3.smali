# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda3;->f$0:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda3;->f$0:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    invoke-static {v0, p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->$r8$lambda$ndcQ15exsfl6QG-g80hpTx65vvo(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Landroid/view/View;)V

    return-void
.end method
