# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnShowListener;


# instance fields
.field public final synthetic f$0:Landroid/app/AlertDialog;

.field public final synthetic f$1:Landroidx/appcompat/widget/SearchView;


# direct methods
.method public synthetic constructor <init>(Landroid/app/AlertDialog;Landroidx/appcompat/widget/SearchView;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda2;->f$0:Landroid/app/AlertDialog;

    iput-object p2, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda2;->f$1:Landroidx/appcompat/widget/SearchView;

    return-void
.end method


# virtual methods
.method public final onShow(Landroid/content/DialogInterface;)V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda2;->f$0:Landroid/app/AlertDialog;

    iget-object v1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$$ExternalSyntheticLambda2;->f$1:Landroidx/appcompat/widget/SearchView;

    invoke-static {v0, v1, p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->$r8$lambda$IqxVSCojmUA43rVGGPgwzm-_724(Landroid/app/AlertDialog;Landroidx/appcompat/widget/SearchView;Landroid/content/DialogInterface;)V

    return-void
.end method
