# classes14.dex

.class public abstract Lcom/vdocipher/aegis/cast/internal/volume/d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/cast/internal/volume/d$a;
    }
.end annotation


# instance fields
.field private final a:Lcom/vdocipher/aegis/cast/internal/volume/d$a;


# direct methods
.method public constructor <init>(Lcom/vdocipher/aegis/cast/internal/volume/d$a;)V
    .registers 3

    const-string/jumbo v0, "volumeListener"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/d;->a:Lcom/vdocipher/aegis/cast/internal/volume/d$a;

    return-void
.end method


# virtual methods
.method public final a()Lcom/vdocipher/aegis/cast/internal/volume/d$a;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/d;->a:Lcom/vdocipher/aegis/cast/internal/volume/d$a;

    return-object v0
.end method

.method public abstract a(I)V
.end method

.method public abstract b()V
.end method

.method public abstract c()V
.end method
