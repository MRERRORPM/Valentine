# classes14.dex

.class public final Lcom/vdocipher/aegis/cast/internal/volume/c;
.super Lcom/vdocipher/aegis/cast/internal/volume/d;
.source "SourceFile"


# instance fields
.field private final b:Landroid/content/Context;

.field private final c:Landroid/media/AudioManager;

.field private final d:Lcom/vdocipher/aegis/cast/internal/volume/c$a;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/vdocipher/aegis/cast/internal/volume/d$a;)V
    .registers 4

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "listener"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0, p2}, Lcom/vdocipher/aegis/cast/internal/volume/d;-><init>(Lcom/vdocipher/aegis/cast/internal/volume/d$a;)V

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/c;->b:Landroid/content/Context;

    .line 3
    const-string p2, "audio"

    invoke-virtual {p1, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const-string p2, "null cannot be cast to non-null type android.media.AudioManager"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Landroid/media/AudioManager;

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/c;->c:Landroid/media/AudioManager;

    .line 4
    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p2

    invoke-direct {p1, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance p2, Lcom/vdocipher/aegis/cast/internal/volume/c$a;

    invoke-direct {p2, p0, p1}, Lcom/vdocipher/aegis/cast/internal/volume/c$a;-><init>(Lcom/vdocipher/aegis/cast/internal/volume/c;Landroid/os/Handler;)V

    iput-object p2, p0, Lcom/vdocipher/aegis/cast/internal/volume/c;->d:Lcom/vdocipher/aegis/cast/internal/volume/c$a;

    return-void
.end method


# virtual methods
.method public a(I)V
    .registers 5

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/c;->c:Landroid/media/AudioManager;

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, v1, p1, v2}, Landroid/media/AudioManager;->setStreamVolume(III)V

    return-void
.end method

.method public b()V
    .registers 5

    .line 1
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/volume/d;->a()Lcom/vdocipher/aegis/cast/internal/volume/d$a;

    move-result-object v0

    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/volume/c;->e()I

    move-result v1

    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/volume/c;->d()I

    move-result v2

    invoke-interface {v0, v1, v2}, Lcom/vdocipher/aegis/cast/internal/volume/d$a;->a(II)V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/c;->b:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    sget-object v1, Landroid/provider/Settings$System;->CONTENT_URI:Landroid/net/Uri;

    iget-object v2, p0, Lcom/vdocipher/aegis/cast/internal/volume/c;->d:Lcom/vdocipher/aegis/cast/internal/volume/c$a;

    const/4 v3, 0x1

    invoke-virtual {v0, v1, v3, v2}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    return-void
.end method

.method public c()V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/c;->b:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/cast/internal/volume/c;->d:Lcom/vdocipher/aegis/cast/internal/volume/c$a;

    invoke-virtual {v0, v1}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    return-void
.end method

.method public d()I
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/c;->c:Landroid/media/AudioManager;

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    move-result v0

    return v0
.end method

.method public e()I
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/c;->c:Landroid/media/AudioManager;

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    return v0
.end method
