# classes14.dex

.class public final Lcom/vdocipher/aegis/cast/internal/volume/c$a;
.super Landroid/database/ContentObserver;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/vdocipher/aegis/cast/internal/volume/c;-><init>(Landroid/content/Context;Lcom/vdocipher/aegis/cast/internal/volume/d$a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/cast/internal/volume/c;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/cast/internal/volume/c;Landroid/os/Handler;)V
    .registers 3

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/c$a;->a:Lcom/vdocipher/aegis/cast/internal/volume/c;

    .line 1
    invoke-direct {p0, p2}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V

    return-void
.end method


# virtual methods
.method public onChange(Z)V
    .registers 4

    .line 1
    invoke-super {p0, p1}, Landroid/database/ContentObserver;->onChange(Z)V

    .line 2
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/c$a;->a:Lcom/vdocipher/aegis/cast/internal/volume/c;

    invoke-virtual {p1}, Lcom/vdocipher/aegis/cast/internal/volume/d;->a()Lcom/vdocipher/aegis/cast/internal/volume/d$a;

    move-result-object p1

    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/c$a;->a:Lcom/vdocipher/aegis/cast/internal/volume/c;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/cast/internal/volume/c;->e()I

    move-result v0

    iget-object v1, p0, Lcom/vdocipher/aegis/cast/internal/volume/c$a;->a:Lcom/vdocipher/aegis/cast/internal/volume/c;

    invoke-virtual {v1}, Lcom/vdocipher/aegis/cast/internal/volume/c;->d()I

    move-result v1

    invoke-interface {p1, v0, v1}, Lcom/vdocipher/aegis/cast/internal/volume/d$a;->a(II)V

    return-void
.end method
