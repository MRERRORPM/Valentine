# classes14.dex

.class public final Lcom/vdocipher/aegis/cast/internal/volume/b$a;
.super Lcom/google/android/gms/cast/Cast$Listener;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/vdocipher/aegis/cast/internal/volume/b;-><init>(Lcom/google/android/gms/cast/framework/CastSession;Lcom/vdocipher/aegis/cast/internal/volume/d$a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/cast/internal/volume/b;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/cast/internal/volume/b;)V
    .registers 2

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/b$a;->a:Lcom/vdocipher/aegis/cast/internal/volume/b;

    .line 1
    invoke-direct {p0}, Lcom/google/android/gms/cast/Cast$Listener;-><init>()V

    return-void
.end method


# virtual methods
.method public onVolumeChanged()V
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/b$a;->a:Lcom/vdocipher/aegis/cast/internal/volume/b;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/cast/internal/volume/d;->a()Lcom/vdocipher/aegis/cast/internal/volume/d$a;

    move-result-object v0

    iget-object v1, p0, Lcom/vdocipher/aegis/cast/internal/volume/b$a;->a:Lcom/vdocipher/aegis/cast/internal/volume/b;

    invoke-virtual {v1}, Lcom/vdocipher/aegis/cast/internal/volume/b;->e()I

    move-result v1

    iget-object v2, p0, Lcom/vdocipher/aegis/cast/internal/volume/b$a;->a:Lcom/vdocipher/aegis/cast/internal/volume/b;

    invoke-virtual {v2}, Lcom/vdocipher/aegis/cast/internal/volume/b;->d()I

    move-result v2

    invoke-interface {v0, v1, v2}, Lcom/vdocipher/aegis/cast/internal/volume/d$a;->a(II)V

    return-void
.end method
