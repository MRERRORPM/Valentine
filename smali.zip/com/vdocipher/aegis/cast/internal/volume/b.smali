# classes14.dex

.class public final Lcom/vdocipher/aegis/cast/internal/volume/b;
.super Lcom/vdocipher/aegis/cast/internal/volume/d;
.source "SourceFile"


# instance fields
.field private final b:Lcom/google/android/gms/cast/framework/CastSession;

.field private final c:D

.field private final d:I

.field private final e:Lcom/vdocipher/aegis/cast/internal/volume/b$a;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/cast/framework/CastSession;Lcom/vdocipher/aegis/cast/internal/volume/d$a;)V
    .registers 4

    const-string v0, "session"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "listener"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0, p2}, Lcom/vdocipher/aegis/cast/internal/volume/d;-><init>(Lcom/vdocipher/aegis/cast/internal/volume/d$a;)V

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/b;->b:Lcom/google/android/gms/cast/framework/CastSession;

    const-wide p1, 0x3fa999999999999aL  # 0.05

    .line 3
    iput-wide p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/b;->c:D

    const/16 p1, 0x14

    .line 4
    iput p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/b;->d:I

    .line 5
    new-instance p1, Lcom/vdocipher/aegis/cast/internal/volume/b$a;

    invoke-direct {p1, p0}, Lcom/vdocipher/aegis/cast/internal/volume/b$a;-><init>(Lcom/vdocipher/aegis/cast/internal/volume/b;)V

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/b;->e:Lcom/vdocipher/aegis/cast/internal/volume/b$a;

    return-void
.end method


# virtual methods
.method public a(I)V
    .registers 7

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/b;->b:Lcom/google/android/gms/cast/framework/CastSession;

    iget-wide v1, p0, Lcom/vdocipher/aegis/cast/internal/volume/b;->c:D

    int-to-double v3, p1

    mul-double/2addr v1, v3

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/cast/framework/CastSession;->setVolume(D)V

    return-void
.end method

.method public b()V
    .registers 4

    .line 1
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/volume/d;->a()Lcom/vdocipher/aegis/cast/internal/volume/d$a;

    move-result-object v0

    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/volume/b;->e()I

    move-result v1

    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/internal/volume/b;->d()I

    move-result v2

    invoke-interface {v0, v1, v2}, Lcom/vdocipher/aegis/cast/internal/volume/d$a;->a(II)V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/b;->b:Lcom/google/android/gms/cast/framework/CastSession;

    iget-object v1, p0, Lcom/vdocipher/aegis/cast/internal/volume/b;->e:Lcom/vdocipher/aegis/cast/internal/volume/b$a;

    invoke-virtual {v0, v1}, Lcom/google/android/gms/cast/framework/CastSession;->addCastListener(Lcom/google/android/gms/cast/Cast$Listener;)V

    return-void
.end method

.method public c()V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/b;->b:Lcom/google/android/gms/cast/framework/CastSession;

    iget-object v1, p0, Lcom/vdocipher/aegis/cast/internal/volume/b;->e:Lcom/vdocipher/aegis/cast/internal/volume/b$a;

    invoke-virtual {v0, v1}, Lcom/google/android/gms/cast/framework/CastSession;->removeCastListener(Lcom/google/android/gms/cast/Cast$Listener;)V

    return-void
.end method

.method public d()I
    .registers 2

    .line 1
    iget v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/b;->d:I

    return v0
.end method

.method public e()I
    .registers 5

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/b;->b:Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/CastSession;->getVolume()D

    move-result-wide v0

    iget-wide v2, p0, Lcom/vdocipher/aegis/cast/internal/volume/b;->c:D

    div-double/2addr v0, v2

    double-to-int v0, v0

    return v0
.end method
