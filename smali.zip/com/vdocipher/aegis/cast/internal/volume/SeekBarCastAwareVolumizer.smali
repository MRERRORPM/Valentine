# classes14.dex

.class public final Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vdocipher/aegis/cast/internal/volume/a;
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;
.implements Lcom/vdocipher/aegis/cast/internal/volume/d$a;
.implements Landroidx/lifecycle/DefaultLifecycleObserver;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/vdocipher/aegis/cast/internal/volume/a;",
        "Landroid/widget/SeekBar$OnSeekBarChangeListener;",
        "Lcom/vdocipher/aegis/cast/internal/volume/d$a;",
        "Landroidx/lifecycle/DefaultLifecycleObserver;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u000e\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u00012\u00020\u00032\u00020\u00042\u00020\u0005B\u001f\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\b\u0012\u0006\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\f\u0010\rJ\u0017\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u000f\u001a\u00020\u000eH\u0002¢\u0006\u0004\b\u0011\u0010\u0012J\u001f\u0010\u0016\u001a\u00020\u00102\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0015\u001a\u00020\u0013H\u0002¢\u0006\u0004\b\u0016\u0010\u0017J\u0017\u0010\u001a\u001a\u00020\u00102\u0006\u0010\u0019\u001a\u00020\u0018H\u0016¢\u0006\u0004\b\u001a\u0010\u001bJ\u0017\u0010\u001c\u001a\u00020\u00102\u0006\u0010\u0019\u001a\u00020\u0018H\u0016¢\u0006\u0004\b\u001c\u0010\u001bJ\u001f\u0010\u0016\u001a\u00020\u00102\u0006\u0010\u001d\u001a\u00020\u00022\u0006\u0010\u001f\u001a\u00020\u001eH\u0016¢\u0006\u0004\b\u0016\u0010 J\u001f\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u001d\u001a\u00020\u00022\u0006\u0010!\u001a\u00020\u0013H\u0016¢\u0006\u0004\b\u0011\u0010\"J\u001f\u0010\u0011\u001a\u00020\u00102\u0006\u0010#\u001a\u00020\u00132\u0006\u0010\u0015\u001a\u00020\u0013H\u0016¢\u0006\u0004\b\u0011\u0010\u0017J)\u0010\'\u001a\u00020\u00102\b\u0010\u000b\u001a\u0004\u0018\u00010\n2\u0006\u0010$\u001a\u00020\u00132\u0006\u0010&\u001a\u00020%H\u0016¢\u0006\u0004\b\'\u0010(J\u0019\u0010)\u001a\u00020\u00102\b\u0010\u000b\u001a\u0004\u0018\u00010\nH\u0016¢\u0006\u0004\b)\u0010*J\u0019\u0010+\u001a\u00020\u00102\b\u0010\u000b\u001a\u0004\u0018\u00010\nH\u0016¢\u0006\u0004\b+\u0010*R\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0011\u0010,R\u0014\u0010\t\u001a\u00020\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0016\u0010-R\u0014\u0010\u000b\u001a\u00020\n8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b.\u0010/R\u0016\u00102\u001a\u00020\u000e8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b0\u00101¨\u00063"
    }
    d2 = {
        "Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;",
        "Lcom/vdocipher/aegis/cast/internal/volume/a;",
        "Lcom/google/android/gms/cast/framework/CastSession;",
        "Landroid/widget/SeekBar$OnSeekBarChangeListener;",
        "Lcom/vdocipher/aegis/cast/internal/volume/d$a;",
        "Landroidx/lifecycle/DefaultLifecycleObserver;",
        "Landroid/content/Context;",
        "context",
        "Lcom/google/android/gms/cast/framework/SessionManager;",
        "castSessionManager",
        "Landroid/widget/SeekBar;",
        "seekBar",
        "<init>",
        "(Landroid/content/Context;Lcom/google/android/gms/cast/framework/SessionManager;Landroid/widget/SeekBar;)V",
        "Lcom/vdocipher/aegis/cast/internal/volume/d;",
        "newVolumizer",
        "",
        "a",
        "(Lcom/vdocipher/aegis/cast/internal/volume/d;)V",
        "",
        "curValue",
        "maxValue",
        "b",
        "(II)V",
        "Landroidx/lifecycle/LifecycleOwner;",
        "owner",
        "onStart",
        "(Landroidx/lifecycle/LifecycleOwner;)V",
        "onStop",
        "session",
        "",
        "sessionId",
        "(Lcom/google/android/gms/cast/framework/CastSession;Ljava/lang/String;)V",
        "error",
        "(Lcom/google/android/gms/cast/framework/CastSession;I)V",
        "currentValue",
        "progress",
        "",
        "fromUser",
        "onProgressChanged",
        "(Landroid/widget/SeekBar;IZ)V",
        "onStartTrackingTouch",
        "(Landroid/widget/SeekBar;)V",
        "onStopTrackingTouch",
        "Landroid/content/Context;",
        "Lcom/google/android/gms/cast/framework/SessionManager;",
        "c",
        "Landroid/widget/SeekBar;",
        "d",
        "Lcom/vdocipher/aegis/cast/internal/volume/d;",
        "volume",
        "core_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Lcom/google/android/gms/cast/framework/SessionManager;

.field private final c:Landroid/widget/SeekBar;

.field private d:Lcom/vdocipher/aegis/cast/internal/volume/d;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/google/android/gms/cast/framework/SessionManager;Landroid/widget/SeekBar;)V
    .registers 5

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "castSessionManager"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "seekBar"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->a:Landroid/content/Context;

    .line 3
    iput-object p2, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->b:Lcom/google/android/gms/cast/framework/SessionManager;

    .line 4
    iput-object p3, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->c:Landroid/widget/SeekBar;

    const/4 v0, 0x0

    .line 14
    invoke-virtual {p3, v0}, Landroid/view/View;->setSaveEnabled(Z)V

    .line 15
    invoke-virtual {p2}, Lcom/google/android/gms/cast/framework/SessionManager;->getCurrentCastSession()Lcom/google/android/gms/cast/framework/CastSession;

    move-result-object p3

    if-eqz p3, :cond_2f

    .line 16
    new-instance p1, Lcom/vdocipher/aegis/cast/internal/volume/b;

    invoke-virtual {p2}, Lcom/google/android/gms/cast/framework/SessionManager;->getCurrentCastSession()Lcom/google/android/gms/cast/framework/CastSession;

    move-result-object p2

    invoke-static {p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {p1, p2, p0}, Lcom/vdocipher/aegis/cast/internal/volume/b;-><init>(Lcom/google/android/gms/cast/framework/CastSession;Lcom/vdocipher/aegis/cast/internal/volume/d$a;)V

    goto :goto_35

    .line 18
    :cond_2f
    new-instance p2, Lcom/vdocipher/aegis/cast/internal/volume/c;

    invoke-direct {p2, p1, p0}, Lcom/vdocipher/aegis/cast/internal/volume/c;-><init>(Landroid/content/Context;Lcom/vdocipher/aegis/cast/internal/volume/d$a;)V

    move-object p1, p2

    .line 19
    :goto_35
    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->d:Lcom/vdocipher/aegis/cast/internal/volume/d;

    return-void
.end method

.method private final a(Lcom/vdocipher/aegis/cast/internal/volume/d;)V
    .registers 3

    .line 6
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->d:Lcom/vdocipher/aegis/cast/internal/volume/d;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/cast/internal/volume/d;->c()V

    .line 7
    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->d:Lcom/vdocipher/aegis/cast/internal/volume/d;

    .line 8
    invoke-virtual {p1}, Lcom/vdocipher/aegis/cast/internal/volume/d;->b()V

    return-void
.end method

.method private final b(II)V
    .registers 5

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->c:Landroid/widget/SeekBar;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 5
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->c:Landroid/widget/SeekBar;

    invoke-virtual {v0, p2}, Landroid/widget/ProgressBar;->setMax(I)V

    .line 6
    iget-object p2, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->c:Landroid/widget/SeekBar;

    invoke-virtual {p2, p1}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 7
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->c:Landroid/widget/SeekBar;

    invoke-virtual {p1, p0}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    return-void
.end method


# virtual methods
.method public a(II)V
    .registers 3

    .line 5
    invoke-direct {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->b(II)V

    return-void
.end method

.method public a(Lcom/google/android/gms/cast/framework/CastSession;)V
    .registers 2

    .line 1
    invoke-static {p0, p1}, Lcom/vdocipher/aegis/cast/internal/volume/a$a;->a(Lcom/vdocipher/aegis/cast/internal/volume/a;Lcom/google/android/gms/cast/framework/Session;)V

    return-void
.end method

.method public a(Lcom/google/android/gms/cast/framework/CastSession;I)V
    .registers 3

    const-string p2, "session"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    new-instance p1, Lcom/vdocipher/aegis/cast/internal/volume/c;

    iget-object p2, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->a:Landroid/content/Context;

    invoke-direct {p1, p2, p0}, Lcom/vdocipher/aegis/cast/internal/volume/c;-><init>(Landroid/content/Context;Lcom/vdocipher/aegis/cast/internal/volume/d$a;)V

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->a(Lcom/vdocipher/aegis/cast/internal/volume/d;)V

    return-void
.end method

.method public a(Lcom/google/android/gms/cast/framework/CastSession;Ljava/lang/String;)V
    .registers 3

    .line 3
    invoke-static {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/volume/a$a;->a(Lcom/vdocipher/aegis/cast/internal/volume/a;Lcom/google/android/gms/cast/framework/Session;Ljava/lang/String;)V

    return-void
.end method

.method public a(Lcom/google/android/gms/cast/framework/CastSession;Z)V
    .registers 3

    .line 2
    invoke-static {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/volume/a$a;->a(Lcom/vdocipher/aegis/cast/internal/volume/a;Lcom/google/android/gms/cast/framework/Session;Z)V

    return-void
.end method

.method public b(Lcom/google/android/gms/cast/framework/CastSession;)V
    .registers 2

    .line 2
    invoke-static {p0, p1}, Lcom/vdocipher/aegis/cast/internal/volume/a$a;->b(Lcom/vdocipher/aegis/cast/internal/volume/a;Lcom/google/android/gms/cast/framework/Session;)V

    return-void
.end method

.method public b(Lcom/google/android/gms/cast/framework/CastSession;I)V
    .registers 3

    .line 1
    invoke-static {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/volume/a$a;->a(Lcom/vdocipher/aegis/cast/internal/volume/a;Lcom/google/android/gms/cast/framework/Session;I)V

    return-void
.end method

.method public b(Lcom/google/android/gms/cast/framework/CastSession;Ljava/lang/String;)V
    .registers 4

    const-string v0, "session"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "sessionId"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    new-instance p2, Lcom/vdocipher/aegis/cast/internal/volume/b;

    invoke-direct {p2, p1, p0}, Lcom/vdocipher/aegis/cast/internal/volume/b;-><init>(Lcom/google/android/gms/cast/framework/CastSession;Lcom/vdocipher/aegis/cast/internal/volume/d$a;)V

    invoke-direct {p0, p2}, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->a(Lcom/vdocipher/aegis/cast/internal/volume/d;)V

    return-void
.end method

.method public c(Lcom/google/android/gms/cast/framework/CastSession;I)V
    .registers 3

    .line 1
    invoke-static {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/volume/a$a;->b(Lcom/vdocipher/aegis/cast/internal/volume/a;Lcom/google/android/gms/cast/framework/Session;I)V

    return-void
.end method

.method public d(Lcom/google/android/gms/cast/framework/CastSession;I)V
    .registers 3

    .line 1
    invoke-static {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/volume/a$a;->c(Lcom/vdocipher/aegis/cast/internal/volume/a;Lcom/google/android/gms/cast/framework/Session;I)V

    return-void
.end method

.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .registers 4

    .line 1
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->d:Lcom/vdocipher/aegis/cast/internal/volume/d;

    invoke-virtual {p1, p2}, Lcom/vdocipher/aegis/cast/internal/volume/d;->a(I)V

    return-void
.end method

.method public bridge synthetic onSessionEnded(Lcom/google/android/gms/cast/framework/Session;I)V
    .registers 3

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->a(Lcom/google/android/gms/cast/framework/CastSession;I)V

    return-void
.end method

.method public bridge synthetic onSessionEnding(Lcom/google/android/gms/cast/framework/Session;)V
    .registers 2

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->a(Lcom/google/android/gms/cast/framework/CastSession;)V

    return-void
.end method

.method public bridge synthetic onSessionResumeFailed(Lcom/google/android/gms/cast/framework/Session;I)V
    .registers 3

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->b(Lcom/google/android/gms/cast/framework/CastSession;I)V

    return-void
.end method

.method public bridge synthetic onSessionResumed(Lcom/google/android/gms/cast/framework/Session;Z)V
    .registers 3

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->a(Lcom/google/android/gms/cast/framework/CastSession;Z)V

    return-void
.end method

.method public bridge synthetic onSessionResuming(Lcom/google/android/gms/cast/framework/Session;Ljava/lang/String;)V
    .registers 3

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->a(Lcom/google/android/gms/cast/framework/CastSession;Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic onSessionStartFailed(Lcom/google/android/gms/cast/framework/Session;I)V
    .registers 3

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->c(Lcom/google/android/gms/cast/framework/CastSession;I)V

    return-void
.end method

.method public bridge synthetic onSessionStarted(Lcom/google/android/gms/cast/framework/Session;Ljava/lang/String;)V
    .registers 3

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->b(Lcom/google/android/gms/cast/framework/CastSession;Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic onSessionStarting(Lcom/google/android/gms/cast/framework/Session;)V
    .registers 2

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->b(Lcom/google/android/gms/cast/framework/CastSession;)V

    return-void
.end method

.method public bridge synthetic onSessionSuspended(Lcom/google/android/gms/cast/framework/Session;I)V
    .registers 3

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->d(Lcom/google/android/gms/cast/framework/CastSession;I)V

    return-void
.end method

.method public onStart(Landroidx/lifecycle/LifecycleOwner;)V
    .registers 3

    const-string v0, "owner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-super {p0, p1}, Landroidx/lifecycle/DefaultLifecycleObserver;->onStart(Landroidx/lifecycle/LifecycleOwner;)V

    .line 2
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->d:Lcom/vdocipher/aegis/cast/internal/volume/d;

    invoke-virtual {p1}, Lcom/vdocipher/aegis/cast/internal/volume/d;->b()V

    .line 3
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->c:Landroid/widget/SeekBar;

    invoke-virtual {p1, p0}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 4
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->b:Lcom/google/android/gms/cast/framework/SessionManager;

    const-class v0, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p1, p0, v0}, Lcom/google/android/gms/cast/framework/SessionManager;->addSessionManagerListener(Lcom/google/android/gms/cast/framework/SessionManagerListener;Ljava/lang/Class;)V

    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 2

    return-void
.end method

.method public onStop(Landroidx/lifecycle/LifecycleOwner;)V
    .registers 3

    const-string v0, "owner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-super {p0, p1}, Landroidx/lifecycle/DefaultLifecycleObserver;->onStop(Landroidx/lifecycle/LifecycleOwner;)V

    .line 2
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->d:Lcom/vdocipher/aegis/cast/internal/volume/d;

    invoke-virtual {p1}, Lcom/vdocipher/aegis/cast/internal/volume/d;->c()V

    .line 3
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->c:Landroid/widget/SeekBar;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 4
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/volume/SeekBarCastAwareVolumizer;->b:Lcom/google/android/gms/cast/framework/SessionManager;

    const-class v0, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p1, p0, v0}, Lcom/google/android/gms/cast/framework/SessionManager;->removeSessionManagerListener(Lcom/google/android/gms/cast/framework/SessionManagerListener;Ljava/lang/Class;)V

    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 2

    return-void
.end method
