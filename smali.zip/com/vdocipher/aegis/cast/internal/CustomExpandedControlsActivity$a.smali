# classes14.dex

.class public final Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vdocipher/aegis/core/y/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)V
    .registers 2

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$a;->a:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;ILjava/lang/Integer;)V
    .registers 9

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$a;->a:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->getRemoteMediaClient()Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    move-result-object v0

    if-eqz v0, :cond_d5

    if-nez p3, :cond_f

    goto :goto_4b

    .line 2
    :cond_f
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v1, 0x2

    if-ne v1, v0, :cond_4b

    instance-of v0, p1, Lcom/vdocipher/aegis/media/Chapter;

    if-eqz v0, :cond_4b

    .line 4
    :try_start_1a
    new-instance v0, Lcom/google/android/gms/cast/MediaSeekOptions$Builder;

    invoke-direct {v0}, Lcom/google/android/gms/cast/MediaSeekOptions$Builder;-><init>()V

    .line 5
    move-object v1, p1

    check-cast v1, Lcom/vdocipher/aegis/media/Chapter;

    invoke-virtual {v1}, Lcom/vdocipher/aegis/media/Chapter;->getStartTime()I

    move-result v1

    int-to-long v1, v1

    const-wide/16 v3, 0x3e8

    mul-long/2addr v1, v3

    .line 6
    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/cast/MediaSeekOptions$Builder;->setPosition(J)Lcom/google/android/gms/cast/MediaSeekOptions$Builder;

    move-result-object v0

    .line 8
    invoke-virtual {v0}, Lcom/google/android/gms/cast/MediaSeekOptions$Builder;->build()Lcom/google/android/gms/cast/MediaSeekOptions;

    move-result-object v0

    .line 9
    const-string v1, "build(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    iget-object v1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$a;->a:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    invoke-virtual {v1}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object v1

    invoke-virtual {v1}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->getRemoteMediaClient()Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    move-result-object v1

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v1, v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->seek(Lcom/google/android/gms/cast/MediaSeekOptions;)Lcom/google/android/gms/common/api/PendingResult;

    move-result-object v0

    .line 12
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V
    :try_end_4b
    .catch Ljava/lang/Exception; {:try_start_1a .. :try_end_4b} :catch_4b

    :catch_4b
    :cond_4b
    :goto_4b
    if-nez p3, :cond_4f

    goto/16 :goto_d5

    .line 19
    :cond_4f
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    const/4 v0, 0x1

    if-ne v0, p3, :cond_d5

    instance-of p3, p1, Ljava/lang/Float;

    if-eqz p3, :cond_d5

    .line 21
    :try_start_5a
    iget-object p3, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$a;->a:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    invoke-static {p3}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)Ljava/util/List;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_76

    .line 22
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->toFloatArray(Ljava/util/Collection;)[F

    move-result-object v0

    .line 25
    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    move-result p1

    .line 26
    invoke-static {v0, p1}, Lcom/vdocipher/aegis/core/z/d;->a([FF)I

    move-result p1

    .line 30
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    goto :goto_77

    :cond_76
    move-object p1, v1

    .line 31
    :goto_77
    invoke-static {p3, p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Ljava/lang/Integer;)V

    .line 39
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$a;->a:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    invoke-virtual {p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a()Lcom/vdocipher/aegis/core/e/a;

    move-result-object p1

    iget-object p1, p1, Lcom/vdocipher/aegis/core/e/a;->r:Landroidx/appcompat/widget/AppCompatTextView;

    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$a;->a:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    invoke-static {v0}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->b(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_a3

    iget-object v1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$a;->a:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    invoke-static {v1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->c(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Ljava/lang/String;

    .line 40
    :cond_a3
    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ""

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 41
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$a;->a:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    invoke-static {p1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->a(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)Ljava/util/List;

    move-result-object p1

    if-eqz p1, :cond_d5

    invoke-interface {p1, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    move-result p1

    iget-object p2, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$a;->a:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    .line 42
    invoke-virtual {p2}, Lcom/google/android/gms/cast/framework/media/widget/ExpandedControllerActivity;->getUIMediaController()Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;

    move-result-object p2

    invoke-virtual {p2}, Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;->getRemoteMediaClient()Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    move-result-object p2

    invoke-static {p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    float-to-double v0, p1

    .line 43
    invoke-virtual {p2, v0, v1}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->setPlaybackRate(D)Lcom/google/android/gms/common/api/PendingResult;
    :try_end_d5
    .catch Ljava/lang/Exception; {:try_start_5a .. :try_end_d5} :catch_d5

    :catch_d5
    :cond_d5
    :goto_d5
    return-void
.end method
