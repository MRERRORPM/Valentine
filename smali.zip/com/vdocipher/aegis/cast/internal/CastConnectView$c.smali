# classes14.dex

.class final Lcom/vdocipher/aegis/cast/internal/CastConnectView$c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/cast/internal/CastConnectView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "c"
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/cast/internal/CastConnectView;


# direct methods
.method private constructor <init>(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView$c;->a:Lcom/vdocipher/aegis/cast/internal/CastConnectView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/aegis/cast/internal/CastConnectView;Lcom/vdocipher/aegis/cast/internal/CastConnectView$a;)V
    .registers 3

    .line 2
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/cast/internal/CastConnectView$c;-><init>(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView$c;->a:Lcom/vdocipher/aegis/cast/internal/CastConnectView;

    invoke-static {v0}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->a(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)Landroid/widget/Button;

    move-result-object v0

    if-ne p1, v0, :cond_e

    .line 2
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView$c;->a:Lcom/vdocipher/aegis/cast/internal/CastConnectView;

    invoke-static {p1}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->b(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)V

    return-void

    .line 3
    :cond_e
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView$c;->a:Lcom/vdocipher/aegis/cast/internal/CastConnectView;

    invoke-static {v0}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->c(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)Landroid/view/View;

    move-result-object v0

    if-ne p1, v0, :cond_1c

    .line 4
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView$c;->a:Lcom/vdocipher/aegis/cast/internal/CastConnectView;

    invoke-static {p1}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->d(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)V

    return-void

    .line 5
    :cond_1c
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView$c;->a:Lcom/vdocipher/aegis/cast/internal/CastConnectView;

    invoke-static {v0}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->e(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)Landroid/widget/TextView;

    move-result-object v0

    if-eq p1, v0, :cond_2c

    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView$c;->a:Lcom/vdocipher/aegis/cast/internal/CastConnectView;

    invoke-static {v0}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->f(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)Landroid/widget/LinearLayout;

    move-result-object v0

    if-ne p1, v0, :cond_67

    .line 7
    :cond_2c
    :try_start_2c
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView$c;->a:Lcom/vdocipher/aegis/cast/internal/CastConnectView;

    invoke-static {p1}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->g(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)Lcom/google/android/gms/cast/framework/CastContext;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastContext;->getSessionManager()Lcom/google/android/gms/cast/framework/SessionManager;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/SessionManager;->getCurrentCastSession()Lcom/google/android/gms/cast/framework/CastSession;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastSession;->getRemoteMediaClient()Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    move-result-object p1

    .line 8
    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->getMediaInfo()Lcom/google/android/gms/cast/MediaInfo;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/gms/cast/MediaInfo;->getCustomData()Lorg/json/JSONObject;

    move-result-object p1

    .line 9
    new-instance v0, Lcom/vdocipher/aegis/core/f/g;

    const-string v1, "meta"

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    .line 11
    new-instance p1, Landroid/content/Intent;

    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView$c;->a:Lcom/vdocipher/aegis/cast/internal/CastConnectView;

    invoke-static {v0}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->h(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)Landroid/content/Context;

    move-result-object v0

    const-class v1, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    invoke-direct {p1, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 12
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView$c;->a:Lcom/vdocipher/aegis/cast/internal/CastConnectView;

    invoke-static {v0}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->h(Lcom/vdocipher/aegis/cast/internal/CastConnectView;)Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_67
    .catch Ljava/lang/Exception; {:try_start_2c .. :try_end_67} :catch_67

    :catch_67
    :cond_67
    return-void
.end method
