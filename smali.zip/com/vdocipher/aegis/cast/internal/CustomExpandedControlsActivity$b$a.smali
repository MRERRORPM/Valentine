# classes14.dex

.class public final Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b;->onQueryTextChange(Ljava/lang/String;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a$a;
    }
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/widget/AppCompatTextView;

.field final synthetic b:Lcom/vdocipher/aegis/ui/view/internal/b;

.field final synthetic c:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;


# direct methods
.method constructor <init>(Landroidx/appcompat/widget/AppCompatTextView;Lcom/vdocipher/aegis/ui/view/internal/b;Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)V
    .registers 4

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;->a:Landroidx/appcompat/widget/AppCompatTextView;

    iput-object p2, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;->b:Lcom/vdocipher/aegis/ui/view/internal/b;

    iput-object p3, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;->c:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onError(Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener$Error;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;->a:Landroidx/appcompat/widget/AppCompatTextView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    if-nez p1, :cond_a

    const/4 p1, -0x1

    goto :goto_12

    .line 2
    :cond_a
    sget-object v0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a$a;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p1, v0, p1

    :goto_12
    const/4 v0, 0x1

    if-eq p1, v0, :cond_50

    const/4 v0, 0x2

    if-eq p1, v0, :cond_42

    const/4 v0, 0x3

    if-eq p1, v0, :cond_34

    const/4 v0, 0x4

    if-eq p1, v0, :cond_26

    .line 11
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;->a:Landroidx/appcompat/widget/AppCompatTextView;

    const-string v0, ""

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 12
    :cond_26
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;->a:Landroidx/appcompat/widget/AppCompatTextView;

    .line 13
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;->c:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    sget v1, Lcom/vdocipher/aegis/R$string;->vdo_network_error:I

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 14
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 15
    :cond_34
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;->a:Landroidx/appcompat/widget/AppCompatTextView;

    .line 16
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;->c:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    sget v1, Lcom/vdocipher/aegis/R$string;->vdo_invalid_file_url:I

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 17
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 18
    :cond_42
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;->a:Landroidx/appcompat/widget/AppCompatTextView;

    .line 19
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;->c:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    sget v1, Lcom/vdocipher/aegis/R$string;->vdo_unable_to_parse_caption_file:I

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 20
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 21
    :cond_50
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;->a:Landroidx/appcompat/widget/AppCompatTextView;

    .line 22
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;->c:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    sget v1, Lcom/vdocipher/aegis/R$string;->vdo_caption_not_selected:I

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 23
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public onResult(Ljava/util/List;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;->a:Landroidx/appcompat/widget/AppCompatTextView;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;->b:Lcom/vdocipher/aegis/ui/view/internal/b;

    invoke-virtual {v0, p1}, Lcom/vdocipher/aegis/ui/view/internal/b;->a(Ljava/util/List;)V

    return-void
.end method
