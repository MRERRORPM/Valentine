# classes14.dex

.class public final Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/appcompat/widget/SearchView$OnQueryTextListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->e()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

.field final synthetic b:Lcom/vdocipher/aegis/ui/view/internal/b;

.field final synthetic c:Landroidx/appcompat/widget/AppCompatTextView;


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;Lcom/vdocipher/aegis/ui/view/internal/b;Landroidx/appcompat/widget/AppCompatTextView;)V
    .registers 4

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b;->a:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    iput-object p2, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b;->b:Lcom/vdocipher/aegis/ui/view/internal/b;

    iput-object p3, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b;->c:Landroidx/appcompat/widget/AppCompatTextView;

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onQueryTextChange(Ljava/lang/String;)Z
    .registers 8

    const-string v0, "newText"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-lez v0, :cond_30

    .line 2
    new-instance v0, Lcom/vdocipher/aegis/core/c/a;

    invoke-direct {v0}, Lcom/vdocipher/aegis/core/c/a;-><init>()V

    .line 5
    iget-object v1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b;->a:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    invoke-virtual {v1}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;->b()Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v1, :cond_20

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/media/Caption;

    goto :goto_21

    :cond_20
    const/4 v1, 0x0

    .line 7
    :goto_21
    new-instance v2, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;

    iget-object v3, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b;->c:Landroidx/appcompat/widget/AppCompatTextView;

    iget-object v4, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b;->b:Lcom/vdocipher/aegis/ui/view/internal/b;

    iget-object v5, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b;->a:Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;

    invoke-direct {v2, v3, v4, v5}, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b$a;-><init>(Landroidx/appcompat/widget/AppCompatTextView;Lcom/vdocipher/aegis/ui/view/internal/b;Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity;)V

    .line 8
    invoke-virtual {v0, v1, p1, v2}, Lcom/vdocipher/aegis/core/c/a;->a(Lcom/vdocipher/aegis/media/Caption;Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V

    goto :goto_3c

    .line 34
    :cond_30
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b;->b:Lcom/vdocipher/aegis/ui/view/internal/b;

    invoke-virtual {p1}, Lcom/vdocipher/aegis/ui/view/internal/b;->a()V

    .line 35
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CustomExpandedControlsActivity$b;->c:Landroidx/appcompat/widget/AppCompatTextView;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    :goto_3c
    const/4 p1, 0x1

    return p1
.end method

.method public onQueryTextSubmit(Ljava/lang/String;)Z
    .registers 3

    const-string v0, "query"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p1, 0x0

    return p1
.end method
