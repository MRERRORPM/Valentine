# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/cast/internal/CastConnectView$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroidx/lifecycle/Observer;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/cast/internal/CastConnectView;

.field public final synthetic f$1:Lcom/google/android/gms/cast/framework/CastSession;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/cast/internal/CastConnectView;Lcom/google/android/gms/cast/framework/CastSession;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/cast/internal/CastConnectView;

    iput-object p2, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView$$ExternalSyntheticLambda0;->f$1:Lcom/google/android/gms/cast/framework/CastSession;

    return-void
.end method


# virtual methods
.method public final onChanged(Ljava/lang/Object;)V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView$$ExternalSyntheticLambda0;->f$0:Lcom/vdocipher/aegis/cast/internal/CastConnectView;

    iget-object v1, p0, Lcom/vdocipher/aegis/cast/internal/CastConnectView$$ExternalSyntheticLambda0;->f$1:Lcom/google/android/gms/cast/framework/CastSession;

    check-cast p1, Ljava/lang/String;

    invoke-static {v0, v1, p1}, Lcom/vdocipher/aegis/cast/internal/CastConnectView;->$r8$lambda$_FFyRDwz7Gr3rJmu9nnHpK_NpZ4(Lcom/vdocipher/aegis/cast/internal/CastConnectView;Lcom/google/android/gms/cast/framework/CastSession;Ljava/lang/String;)V

    return-void
.end method
