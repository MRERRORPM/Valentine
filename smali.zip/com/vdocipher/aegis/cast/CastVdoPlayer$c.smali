# classes14.dex

.class final Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/cast/CastVdoPlayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "c"
.end annotation


# instance fields
.field final a:Lcom/vdocipher/aegis/player/VdoInitParams;

.field b:Lcom/vdocipher/aegis/media/MediaInfo;

.field c:J

.field d:J

.field e:Z


# direct methods
.method constructor <init>(Lcom/vdocipher/aegis/player/VdoInitParams;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    return-void
.end method
