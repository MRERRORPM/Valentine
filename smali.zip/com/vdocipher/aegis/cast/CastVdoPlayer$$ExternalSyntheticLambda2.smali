# classes14.dex

.class public final synthetic Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

.field public final synthetic f$1:Lcom/vdocipher/aegis/media/ErrorDescription;


# direct methods
.method public synthetic constructor <init>(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    iput-object p2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda2;->f$1:Lcom/vdocipher/aegis/media/ErrorDescription;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda2;->f$0:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    iget-object v1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda2;->f$1:Lcom/vdocipher/aegis/media/ErrorDescription;

    invoke-static {v0, v1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->$r8$lambda$chgtcjesFZahQN3UAdArWD0NJk8(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    return-void
.end method
