# classes14.dex

.class public interface abstract Lcom/vdocipher/aegis/cast/CastSessionAvailabilityListener;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract onCastSessionAvailable()V
.end method

.method public abstract onCastSessionUnavailable()V
.end method
