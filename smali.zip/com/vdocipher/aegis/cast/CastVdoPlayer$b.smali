# classes14.dex

.class final Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;
.super Lcom/google/android/gms/cast/framework/media/RemoteMediaClient$Callback;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/cast/framework/SessionManagerListener;
.implements Lcom/google/android/gms/cast/framework/media/RemoteMediaClient$ProgressListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/cast/CastVdoPlayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;


# direct methods
.method private constructor <init>(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-direct {p0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient$Callback;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;)V
    .registers 3

    .line 2
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;-><init>(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)V

    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/gms/cast/framework/CastSession;)V
    .registers 4

    .line 3
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Session Ended "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastSession;->getSessionId()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "CastVdoPlayer"

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public a(Lcom/google/android/gms/cast/framework/CastSession;I)V
    .registers 4

    .line 4
    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Session Ended "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastSession;->getSessionId()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "CastVdoPlayer"

    invoke-static {p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 5
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    const/4 p2, 0x0

    invoke-static {p1, p2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;)V

    return-void
.end method

.method public a(Lcom/google/android/gms/cast/framework/CastSession;Ljava/lang/String;)V
    .registers 3

    return-void
.end method

.method public a(Lcom/google/android/gms/cast/framework/CastSession;Z)V
    .registers 3

    .line 2
    iget-object p2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastSession;->getRemoteMediaClient()Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    move-result-object p1

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;)V

    return-void
.end method

.method public b(Lcom/google/android/gms/cast/framework/CastSession;)V
    .registers 2

    return-void
.end method

.method public b(Lcom/google/android/gms/cast/framework/CastSession;I)V
    .registers 4

    .line 3
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "Session resume failed. Error code "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "CastVdoPlayer"

    invoke-static {p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public b(Lcom/google/android/gms/cast/framework/CastSession;Ljava/lang/String;)V
    .registers 3

    .line 2
    iget-object p2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastSession;->getRemoteMediaClient()Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    move-result-object p1

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;)V

    return-void
.end method

.method public c(Lcom/google/android/gms/cast/framework/CastSession;I)V
    .registers 4

    .line 1
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "Session start failed. Error code "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "CastVdoPlayer"

    invoke-static {p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public d(Lcom/google/android/gms/cast/framework/CastSession;I)V
    .registers 3

    .line 1
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    const/4 p2, 0x0

    invoke-static {p1, p2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;)V

    return-void
.end method

.method public onAdBreakStatusUpdated()V
    .registers 1

    return-void
.end method

.method public onMetadataUpdated()V
    .registers 1

    return-void
.end method

.method public onPreloadStatusUpdated()V
    .registers 1

    return-void
.end method

.method public onProgressUpdated(JJ)V
    .registers 6

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-static {v0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    move-result-object v0

    if-eqz v0, :cond_32

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-static {v0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    move-result-object v0

    iput-wide p1, v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->c:J

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-static {v0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    move-result-object v0

    iput-wide p3, v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->d:J

    .line 5
    iget-object p3, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-static {p3}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->d(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)Ljava/util/concurrent/CopyOnWriteArraySet;

    move-result-object p3

    invoke-virtual {p3}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :goto_22
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result p4

    if-eqz p4, :cond_32

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 6
    invoke-interface {p4, p1, p2}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onProgress(J)V

    goto :goto_22

    :cond_32
    return-void
.end method

.method public onQueueStatusUpdated()V
    .registers 1

    return-void
.end method

.method public onSendingRemoteMediaRequest()V
    .registers 1

    return-void
.end method

.method public bridge synthetic onSessionEnded(Lcom/google/android/gms/cast/framework/Session;I)V
    .registers 3

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->a(Lcom/google/android/gms/cast/framework/CastSession;I)V

    return-void
.end method

.method public bridge synthetic onSessionEnding(Lcom/google/android/gms/cast/framework/Session;)V
    .registers 2

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->a(Lcom/google/android/gms/cast/framework/CastSession;)V

    return-void
.end method

.method public bridge synthetic onSessionResumeFailed(Lcom/google/android/gms/cast/framework/Session;I)V
    .registers 3

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->b(Lcom/google/android/gms/cast/framework/CastSession;I)V

    return-void
.end method

.method public bridge synthetic onSessionResumed(Lcom/google/android/gms/cast/framework/Session;Z)V
    .registers 3

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->a(Lcom/google/android/gms/cast/framework/CastSession;Z)V

    return-void
.end method

.method public bridge synthetic onSessionResuming(Lcom/google/android/gms/cast/framework/Session;Ljava/lang/String;)V
    .registers 3

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->a(Lcom/google/android/gms/cast/framework/CastSession;Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic onSessionStartFailed(Lcom/google/android/gms/cast/framework/Session;I)V
    .registers 3

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->c(Lcom/google/android/gms/cast/framework/CastSession;I)V

    return-void
.end method

.method public bridge synthetic onSessionStarted(Lcom/google/android/gms/cast/framework/Session;Ljava/lang/String;)V
    .registers 3

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->b(Lcom/google/android/gms/cast/framework/CastSession;Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic onSessionStarting(Lcom/google/android/gms/cast/framework/Session;)V
    .registers 2

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->b(Lcom/google/android/gms/cast/framework/CastSession;)V

    return-void
.end method

.method public bridge synthetic onSessionSuspended(Lcom/google/android/gms/cast/framework/Session;I)V
    .registers 3

    .line 1
    check-cast p1, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p0, p1, p2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->d(Lcom/google/android/gms/cast/framework/CastSession;I)V

    return-void
.end method

.method public onStatusUpdated()V
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;->a:Lcom/vdocipher/aegis/cast/CastVdoPlayer;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->updateInternalState()V

    return-void
.end method
