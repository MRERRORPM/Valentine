# classes14.dex

.class public Lcom/vdocipher/aegis/cast/CastVdoPlayer;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vdocipher/aegis/player/VdoPlayer;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;,
        Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;
    }
.end annotation


# instance fields
.field private final a:Lcom/google/android/gms/cast/framework/CastContext;

.field private b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

.field private c:Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;

.field private d:Lcom/vdocipher/aegis/core/c/b;

.field private final e:Landroid/os/Handler;

.field private f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

.field private g:I

.field private h:Z

.field private final i:Lcom/vdocipher/aegis/core/b/a;

.field private final j:Ljava/util/concurrent/CopyOnWriteArraySet;

.field private k:Ljava/lang/ref/WeakReference;

.field private l:Lcom/vdocipher/aegis/media/PlayerOption;

.field m:Landroidx/lifecycle/MutableLiveData;

.field n:Landroidx/lifecycle/MutableLiveData;

.field o:Lcom/vdocipher/aegis/core/f/g;

.field private p:Lcom/vdocipher/aegis/core/c/b$d;


# direct methods
.method public static synthetic $r8$lambda$5bAhGlqMP7yFqIH8UmhZnyKk0ZM(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;)V

    return-void
.end method

.method public static synthetic $r8$lambda$PCSEjNMxeBEUfkTsGcnD6u4NIiw(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->c(Lcom/vdocipher/aegis/media/ErrorDescription;)V

    return-void
.end method

.method public static synthetic $r8$lambda$aHTwfA0QT1UjTgyKpHgfK7ZJinc(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->d()V

    return-void
.end method

.method public static synthetic $r8$lambda$chgtcjesFZahQN3UAdArWD0NJk8(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b(Lcom/vdocipher/aegis/media/ErrorDescription;)V

    return-void
.end method

.method public static synthetic $r8$lambda$zKk5T4pBrjKnOP53M-2bsIFXEmU(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/vdocipher/aegis/media/ErrorDescription;)V

    return-void
.end method

.method public constructor <init>(Lcom/google/android/gms/cast/framework/CastContext;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Lcom/vdocipher/aegis/media/PlayerOption;

    invoke-direct {v0}, Lcom/vdocipher/aegis/media/PlayerOption;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->l:Lcom/vdocipher/aegis/media/PlayerOption;

    .line 3
    new-instance v0, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->m:Landroidx/lifecycle/MutableLiveData;

    .line 4
    new-instance v0, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->n:Landroidx/lifecycle/MutableLiveData;

    .line 309
    new-instance v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;

    invoke-direct {v0, p0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;-><init>(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->p:Lcom/vdocipher/aegis/core/c/b$d;

    .line 310
    iput-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a:Lcom/google/android/gms/cast/framework/CastContext;

    .line 312
    new-instance v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;-><init>(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/vdocipher/aegis/cast/CastVdoPlayer$a;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->c:Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;

    .line 313
    new-instance v0, Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>()V

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->j:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 314
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v0, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->e:Landroid/os/Handler;

    .line 315
    invoke-static {v1}, Lcom/vdocipher/aegis/core/b/a;->a(Landroid/content/Context;)Lcom/vdocipher/aegis/core/b/a;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    .line 317
    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastContext;->getSessionManager()Lcom/google/android/gms/cast/framework/SessionManager;

    move-result-object p1

    .line 318
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->c:Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;

    const-class v2, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {p1, v0, v2}, Lcom/google/android/gms/cast/framework/SessionManager;->addSessionManagerListener(Lcom/google/android/gms/cast/framework/SessionManagerListener;Ljava/lang/Class;)V

    .line 319
    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/SessionManager;->getCurrentCastSession()Lcom/google/android/gms/cast/framework/CastSession;

    move-result-object p1

    if-eqz p1, :cond_56

    .line 320
    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/CastSession;->getRemoteMediaClient()Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    move-result-object v1

    .line 321
    :cond_56
    invoke-direct {p0, v1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;)V

    const/4 p1, 0x1

    .line 323
    iput p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->g:I

    .line 324
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->updateInternalState()V

    return-void
.end method

.method private a(Ljava/lang/String;Lcom/vdocipher/aegis/player/VdoInitParams;)Landroid/util/Pair;
    .registers 4

    .line 186
    const-string v0, "dash"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_21

    .line 187
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->o:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->s()Ljava/lang/String;

    move-result-object p1

    .line 189
    invoke-static {p2}, Lcom/vdocipher/aegis/core/c/c;->a(Lcom/vdocipher/aegis/player/VdoInitParams;)Ljava/lang/String;

    move-result-object p2

    .line 190
    invoke-static {p1, p2}, Lcom/vdocipher/aegis/core/c/c;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 192
    iget-object p2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->o:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {p2}, Lcom/vdocipher/aegis/core/f/g;->k()Ljava/lang/String;

    move-result-object p2

    invoke-static {p2, p1}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object p1

    return-object p1

    .line 193
    :cond_21
    const-string p2, "hlse"

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_35

    .line 194
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->o:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->l()Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x0

    invoke-static {p1, p2}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object p1

    return-object p1

    .line 196
    :cond_35
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1
.end method

.method private static a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)Lcom/google/android/gms/cast/MediaInfo;
    .registers 10

    .line 197
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 199
    :try_start_5
    const-string v1, "playbackInfo"

    invoke-virtual {v0, v1, p5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 200
    const-string p5, "meta"

    invoke-virtual {v0, p5, p6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    if-eqz p1, :cond_16

    .line 202
    const-string p5, "licenseUrl"

    invoke-virtual {v0, p5, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_16
    .catch Lorg/json/JSONException; {:try_start_5 .. :try_end_16} :catch_16

    .line 207
    :catch_16
    :cond_16
    const-string p1, "dash"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_21

    .line 208
    const-string p1, "application/dash+xml"

    goto :goto_2b

    .line 209
    :cond_21
    const-string p1, "hlse"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_68

    .line 210
    const-string p1, "application/x-mpegURL"

    .line 214
    :goto_2b
    new-instance p2, Lcom/google/android/gms/cast/MediaMetadata;

    const/4 p5, 0x1

    invoke-direct {p2, p5}, Lcom/google/android/gms/cast/MediaMetadata;-><init>(I)V

    if-eqz p4, :cond_45

    .line 215
    array-length p6, p4

    if-lez p6, :cond_45

    .line 216
    new-instance p6, Lcom/google/android/gms/common/images/WebImage;

    const/4 v1, 0x0

    aget-object p4, p4, v1

    invoke-static {p4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p4

    invoke-direct {p6, p4}, Lcom/google/android/gms/common/images/WebImage;-><init>(Landroid/net/Uri;)V

    invoke-virtual {p2, p6}, Lcom/google/android/gms/cast/MediaMetadata;->addImage(Lcom/google/android/gms/common/images/WebImage;)V

    .line 218
    :cond_45
    const-string p4, "com.google.android.gms.cast.metadata.TITLE"

    invoke-virtual {p2, p4, p3}, Lcom/google/android/gms/cast/MediaMetadata;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 219
    new-instance p3, Lcom/google/android/gms/cast/MediaInfo$Builder;

    invoke-direct {p3, p0}, Lcom/google/android/gms/cast/MediaInfo$Builder;-><init>(Ljava/lang/String;)V

    .line 220
    invoke-virtual {p3, p5}, Lcom/google/android/gms/cast/MediaInfo$Builder;->setStreamType(I)Lcom/google/android/gms/cast/MediaInfo$Builder;

    move-result-object p0

    .line 221
    invoke-virtual {p0, p1}, Lcom/google/android/gms/cast/MediaInfo$Builder;->setContentType(Ljava/lang/String;)Lcom/google/android/gms/cast/MediaInfo$Builder;

    move-result-object p0

    .line 222
    invoke-virtual {p0, p7}, Lcom/google/android/gms/cast/MediaInfo$Builder;->setMediaTracks(Ljava/util/List;)Lcom/google/android/gms/cast/MediaInfo$Builder;

    move-result-object p0

    .line 223
    invoke-virtual {p0, p2}, Lcom/google/android/gms/cast/MediaInfo$Builder;->setMetadata(Lcom/google/android/gms/cast/MediaMetadata;)Lcom/google/android/gms/cast/MediaInfo$Builder;

    move-result-object p0

    .line 224
    invoke-virtual {p0, v0}, Lcom/google/android/gms/cast/MediaInfo$Builder;->setCustomData(Lorg/json/JSONObject;)Lcom/google/android/gms/cast/MediaInfo$Builder;

    move-result-object p0

    .line 225
    invoke-virtual {p0}, Lcom/google/android/gms/cast/MediaInfo$Builder;->build()Lcom/google/android/gms/cast/MediaInfo;

    move-result-object p0

    return-object p0

    .line 226
    :cond_68
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p0
.end method

.method static synthetic a(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    return-object p0
.end method

.method private static a(Ljava/lang/Exception;I)Lcom/vdocipher/aegis/media/ErrorDescription;
    .registers 4

    .line 227
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_c

    .line 229
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_e

    :cond_c
    const-string p0, "meta data in bad format"

    .line 230
    :cond_e
    new-instance v0, Lcom/vdocipher/aegis/media/ErrorDescription;

    const/4 v1, -0x1

    invoke-direct {v0, p1, p0, v1}, Lcom/vdocipher/aegis/media/ErrorDescription;-><init>(ILjava/lang/String;I)V

    return-object v0
.end method

.method private a(Lcom/vdocipher/aegis/core/f/g;)Ljava/lang/String;
    .registers 8

    .line 173
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->q()[Ljava/lang/String;

    move-result-object v0

    .line 174
    invoke-static {v0}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "CastVdoPlayer"

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 177
    array-length v1, v0

    const/4 v2, 0x0

    :goto_f
    if-ge v2, v1, :cond_32

    aget-object v3, v0, v2

    .line 178
    const-string v4, "dash"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_26

    .line 180
    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/f/g;->s()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_2f

    return-object v4

    .line 184
    :cond_26
    const-string v4, "hlse"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2f

    return-object v4

    :cond_2f
    add-int/lit8 v2, v2, 0x1

    goto :goto_f

    :cond_32
    const/4 p1, 0x0

    return-object p1
.end method

.method private a(Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;)V
    .registers 5

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    if-ne v0, p1, :cond_5

    goto :goto_51

    :cond_5
    if-eqz v0, :cond_13

    .line 9
    iget-object v1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->c:Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;

    invoke-virtual {v0, v1}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->unregisterCallback(Lcom/google/android/gms/cast/framework/media/RemoteMediaClient$Callback;)V

    .line 10
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    iget-object v1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->c:Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;

    invoke-virtual {v0, v1}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->removeProgressListener(Lcom/google/android/gms/cast/framework/media/RemoteMediaClient$ProgressListener;)V

    .line 13
    :cond_13
    iput-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    if-eqz p1, :cond_3c

    .line 15
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->c:Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;

    invoke-virtual {p1, v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->registerCallback(Lcom/google/android/gms/cast/framework/media/RemoteMediaClient$Callback;)V

    .line 16
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->c:Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;

    const-wide/16 v1, 0x3e8

    invoke-virtual {p1, v0, v1, v2}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->addProgressListener(Lcom/google/android/gms/cast/framework/media/RemoteMediaClient$ProgressListener;J)Z

    .line 17
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->updateInternalState()V

    .line 18
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->k:Ljava/lang/ref/WeakReference;

    if-eqz p1, :cond_51

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    if-eqz p1, :cond_51

    .line 19
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->k:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/aegis/cast/CastSessionAvailabilityListener;

    invoke-interface {p1}, Lcom/vdocipher/aegis/cast/CastSessionAvailabilityListener;->onCastSessionAvailable()V

    return-void

    .line 22
    :cond_3c
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->k:Ljava/lang/ref/WeakReference;

    if-eqz p1, :cond_51

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    if-eqz p1, :cond_51

    .line 23
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->k:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/aegis/cast/CastSessionAvailabilityListener;

    invoke-interface {p1}, Lcom/vdocipher/aegis/cast/CastSessionAvailabilityListener;->onCastSessionUnavailable()V

    :cond_51
    :goto_51
    return-void
.end method

.method private synthetic a(Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;)V
    .registers 9

    .line 24
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->j:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_22

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 25
    iget-object v2, p1, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    new-instance v3, Lcom/vdocipher/aegis/media/ErrorDescription;

    const-string v4, "init params invalid"

    const/4 v5, -0x1

    const/16 v6, 0x1005

    invoke-direct {v3, v6, v4, v5}, Lcom/vdocipher/aegis/media/ErrorDescription;-><init>(ILjava/lang/String;I)V

    invoke-interface {v1, v2, v3}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onLoadError(Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    goto :goto_6

    :cond_22
    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;)V
    .registers 2

    .line 3
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;)V

    return-void
.end method

.method static synthetic a(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Ljava/lang/String;)V
    .registers 2

    .line 2
    invoke-direct {p0, p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Ljava/lang/String;)V

    return-void
.end method

.method private synthetic a(Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 5

    .line 46
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    if-eqz v0, :cond_1e

    .line 47
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->j:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1e

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 48
    iget-object v2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    iget-object v2, v2, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-interface {v1, v2, p1}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onLoadError(Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    goto :goto_a

    :cond_1e
    return-void
.end method

.method private a(Lcom/vdocipher/aegis/player/VdoInitParams;Ljava/lang/String;)V
    .registers 4

    .line 26
    new-instance v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    invoke-direct {v0, p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;-><init>(Lcom/vdocipher/aegis/player/VdoInitParams;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    .line 28
    :try_start_7
    iget-object p1, v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-static {p2, p1}, Lcom/vdocipher/aegis/core/c/c;->a(Ljava/lang/String;Lcom/vdocipher/aegis/player/VdoInitParams;)Lcom/vdocipher/aegis/media/MediaInfo;

    move-result-object p1

    iput-object p1, v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->b:Lcom/vdocipher/aegis/media/MediaInfo;
    :try_end_f
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_7 .. :try_end_f} :catch_1b
    .catch Lorg/json/JSONException; {:try_start_7 .. :try_end_f} :catch_19
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7 .. :try_end_f} :catch_17
    .catch Lcom/vdocipher/aegis/core/f/d; {:try_start_7 .. :try_end_f} :catch_15

    .line 42
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    invoke-virtual {p1}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->requestStatus()Lcom/google/android/gms/common/api/PendingResult;

    return-void

    :catch_15
    move-exception p1

    goto :goto_1c

    :catch_17
    move-exception p1

    goto :goto_1c

    :catch_19
    move-exception p1

    goto :goto_1c

    :catch_1b
    move-exception p1

    .line 43
    :goto_1c
    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p2

    const-string v0, "CastVdoPlayer"

    invoke-static {v0, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/16 p2, 0xc1f

    .line 44
    invoke-static {p1, p2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Ljava/lang/Exception;I)Lcom/vdocipher/aegis/media/ErrorDescription;

    move-result-object p1

    .line 45
    iget-object p2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->e:Landroid/os/Handler;

    new-instance v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda4;

    invoke-direct {v0, p0, p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda4;-><init>(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    invoke-virtual {p2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private a(Ljava/lang/String;)V
    .registers 25

    move-object/from16 v1, p0

    move-object/from16 v8, p1

    const-string v2, "CastVdoPlayer"

    .line 49
    iget-object v0, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    if-nez v0, :cond_b

    return-void

    .line 55
    :cond_b
    :try_start_b
    new-instance v0, Lcom/vdocipher/aegis/core/f/g;

    invoke-direct {v0, v8}, Lcom/vdocipher/aegis/core/f/g;-><init>(Ljava/lang/String;)V

    iput-object v0, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->o:Lcom/vdocipher/aegis/core/f/g;

    .line 56
    invoke-direct {v1, v0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/vdocipher/aegis/core/f/g;)Ljava/lang/String;

    move-result-object v4

    .line 57
    iget-object v0, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    iget-object v3, v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-static {v8, v3}, Lcom/vdocipher/aegis/core/c/c;->a(Ljava/lang/String;Lcom/vdocipher/aegis/player/VdoInitParams;)Lcom/vdocipher/aegis/media/MediaInfo;

    move-result-object v3

    iput-object v3, v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->b:Lcom/vdocipher/aegis/media/MediaInfo;
    :try_end_20
    .catch Lorg/json/JSONException; {:try_start_b .. :try_end_20} :catch_192
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_b .. :try_end_20} :catch_190
    .catch Ljava/lang/IllegalArgumentException; {:try_start_b .. :try_end_20} :catch_18e
    .catch Lcom/vdocipher/aegis/core/f/d; {:try_start_b .. :try_end_20} :catch_18c

    if-nez v4, :cond_32

    .line 74
    const-string v0, "not supported"

    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 77
    iget-object v0, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->e:Landroid/os/Handler;

    new-instance v2, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda0;

    invoke-direct {v2, v1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda0;-><init>(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 88
    :cond_32
    :try_start_32
    iget-object v0, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    iget-object v0, v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-direct {v1, v4, v0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Ljava/lang/String;Lcom/vdocipher/aegis/player/VdoInitParams;)Landroid/util/Pair;

    move-result-object v0

    .line 89
    iget-object v3, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    .line 90
    iget-object v0, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    move-object v5, v0

    check-cast v5, Ljava/lang/String;

    .line 91
    iget-object v0, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->o:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/g;->r()Ljava/lang/String;

    move-result-object v6

    .line 92
    iget-object v0, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->o:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/f/g;->o()[Ljava/lang/String;

    move-result-object v7
    :try_end_4f
    .catch Ljava/lang/Exception; {:try_start_32 .. :try_end_4f} :catch_173

    .line 106
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    const/4 v0, 0x1

    .line 108
    new-array v10, v0, [J

    .line 110
    :try_start_57
    iget-object v11, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->o:Lcom/vdocipher/aegis/core/f/g;

    iget-object v12, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    iget-object v12, v12, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v13, v12, Lcom/vdocipher/aegis/player/VdoInitParams;->mediaId:Ljava/lang/String;

    iget-object v12, v12, Lcom/vdocipher/aegis/player/VdoInitParams;->configMap:Ljava/util/HashMap;

    invoke-virtual {v11, v13, v12}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/lang/String;Ljava/util/HashMap;)Lcom/vdocipher/aegis/media/PlayerOption;

    move-result-object v11

    .line 111
    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    .line 112
    iget-object v13, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->o:Lcom/vdocipher/aegis/core/f/g;

    invoke-virtual {v13, v12}, Lcom/vdocipher/aegis/core/f/g;->a(Ljava/util/ArrayList;)Ljava/util/ArrayList;

    .line 116
    iget-object v13, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    iget-object v13, v13, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v13, v13, Lcom/vdocipher/aegis/player/VdoInitParams;->preferredCaptionsLanguage:Ljava/lang/String;

    const/4 v14, 0x0

    if-eqz v13, :cond_7a

    move-object v15, v14

    goto :goto_80

    .line 120
    :cond_7a
    invoke-static {v14, v12}, Lcom/vdocipher/aegis/core/t/d;->a(Landroid/content/Context;Ljava/util/List;)Lcom/vdocipher/aegis/media/Caption;

    move-result-object v13

    move-object v15, v13

    move-object v13, v14

    .line 125
    :goto_80
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    move-result v14
    :try_end_84
    .catch Ljava/lang/Exception; {:try_start_57 .. :try_end_84} :catch_113

    const/16 v16, 0x0

    move-object/from16 v17, v3

    move-object/from16 v18, v4

    move/from16 v0, v16

    const/4 v3, -0x1

    const/4 v4, 0x1

    :goto_8e
    if-ge v0, v14, :cond_fb

    :try_start_90
    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v19

    add-int/lit8 v0, v0, 0x1

    move/from16 v20, v0

    move-object/from16 v0, v19

    check-cast v0, Lcom/vdocipher/aegis/media/Caption;
    :try_end_9c
    .catch Ljava/lang/Exception; {:try_start_90 .. :try_end_9c} :catch_f9

    if-eqz v13, :cond_b2

    move-object/from16 v19, v5

    .line 126
    :try_start_a0
    invoke-virtual {v0}, Lcom/vdocipher/aegis/media/Caption;->getLang()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v13, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5
    :try_end_a8
    .catch Ljava/lang/Exception; {:try_start_a0 .. :try_end_a8} :catch_af

    if-eqz v5, :cond_b4

    move-object v5, v7

    int-to-long v7, v4

    .line 127
    :try_start_ac
    aput-wide v7, v10, v16

    goto :goto_bc

    :catch_af
    move-exception v0

    goto/16 :goto_11a

    :cond_b2
    move-object/from16 v19, v5

    :cond_b4
    move-object v5, v7

    .line 128
    invoke-virtual {v0, v15}, Lcom/vdocipher/aegis/media/Caption;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_bc

    move v3, v4

    .line 131
    :cond_bc
    :goto_bc
    new-instance v7, Lcom/google/android/gms/cast/MediaTrack$Builder;

    move-object v8, v12

    move-object/from16 v21, v13

    int-to-long v12, v4

    move-object/from16 v22, v0

    const/4 v0, 0x1

    invoke-direct {v7, v12, v13, v0}, Lcom/google/android/gms/cast/MediaTrack$Builder;-><init>(JI)V

    .line 132
    invoke-virtual/range {v22 .. v22}, Lcom/vdocipher/aegis/media/Caption;->getLabel()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v7, v12}, Lcom/google/android/gms/cast/MediaTrack$Builder;->setName(Ljava/lang/String;)Lcom/google/android/gms/cast/MediaTrack$Builder;

    move-result-object v7

    const/4 v12, 0x2

    .line 133
    invoke-virtual {v7, v12}, Lcom/google/android/gms/cast/MediaTrack$Builder;->setSubtype(I)Lcom/google/android/gms/cast/MediaTrack$Builder;

    move-result-object v7

    .line 134
    invoke-virtual/range {v22 .. v22}, Lcom/vdocipher/aegis/media/Caption;->getUrl()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v7, v12}, Lcom/google/android/gms/cast/MediaTrack$Builder;->setContentId(Ljava/lang/String;)Lcom/google/android/gms/cast/MediaTrack$Builder;

    move-result-object v7

    .line 135
    invoke-virtual/range {v22 .. v22}, Lcom/vdocipher/aegis/media/Caption;->getLang()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v7, v12}, Lcom/google/android/gms/cast/MediaTrack$Builder;->setLanguage(Ljava/lang/String;)Lcom/google/android/gms/cast/MediaTrack$Builder;

    move-result-object v7

    invoke-virtual {v7}, Lcom/google/android/gms/cast/MediaTrack$Builder;->build()Lcom/google/android/gms/cast/MediaTrack;

    move-result-object v7

    .line 136
    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, 0x2

    move-object v7, v5

    move-object v12, v8

    move-object/from16 v5, v19

    move/from16 v0, v20

    move-object/from16 v13, v21

    move-object/from16 v8, p1

    goto :goto_8e

    :catch_f9
    move-exception v0

    goto :goto_118

    :cond_fb
    move-object/from16 v19, v5

    move-object v5, v7

    .line 144
    aget-wide v7, v10, v16

    const-wide/16 v12, 0x0

    cmp-long v0, v7, v12

    if-nez v0, :cond_10d

    const/4 v0, -0x1

    if-eq v3, v0, :cond_10d

    int-to-long v3, v3

    .line 145
    aput-wide v3, v10, v16

    goto :goto_10e

    :cond_10d
    const/4 v10, 0x0

    .line 148
    :goto_10e
    iput-object v11, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->l:Lcom/vdocipher/aegis/media/PlayerOption;
    :try_end_110
    .catch Ljava/lang/Exception; {:try_start_ac .. :try_end_110} :catch_111

    goto :goto_129

    :catch_111
    move-exception v0

    goto :goto_11b

    :catch_113
    move-exception v0

    move-object/from16 v17, v3

    move-object/from16 v18, v4

    :goto_118
    move-object/from16 v19, v5

    :goto_11a
    move-object v5, v7

    .line 151
    :goto_11b
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Lcom/vdocipher/aegis/core/t/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 152
    new-instance v0, Lcom/vdocipher/aegis/media/PlayerOption;

    invoke-direct {v0}, Lcom/vdocipher/aegis/media/PlayerOption;-><init>()V

    iput-object v0, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->l:Lcom/vdocipher/aegis/media/PlayerOption;

    .line 155
    :goto_129
    iget-object v0, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->m:Landroidx/lifecycle/MutableLiveData;

    invoke-virtual {v0, v6}, Landroidx/lifecycle/MutableLiveData;->setValue(Ljava/lang/Object;)V

    .line 156
    iget-object v0, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    iget-object v0, v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v7, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    move-object v2, v6

    move-object v6, v5

    move-object v5, v2

    move-object/from16 v8, p1

    move-object/from16 v2, v17

    move-object/from16 v4, v18

    move-object/from16 v3, v19

    .line 157
    invoke-static/range {v2 .. v9}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)Lcom/google/android/gms/cast/MediaInfo;

    move-result-object v0

    .line 160
    new-instance v2, Lcom/google/android/gms/cast/MediaLoadRequestData$Builder;

    invoke-direct {v2}, Lcom/google/android/gms/cast/MediaLoadRequestData$Builder;-><init>()V

    .line 161
    invoke-virtual {v2, v0}, Lcom/google/android/gms/cast/MediaLoadRequestData$Builder;->setMediaInfo(Lcom/google/android/gms/cast/MediaInfo;)Lcom/google/android/gms/cast/MediaLoadRequestData$Builder;

    move-result-object v0

    .line 162
    invoke-virtual {v0, v10}, Lcom/google/android/gms/cast/MediaLoadRequestData$Builder;->setActiveTrackIds([J)Lcom/google/android/gms/cast/MediaLoadRequestData$Builder;

    move-result-object v0

    iget-object v2, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    iget-object v2, v2, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget v2, v2, Lcom/vdocipher/aegis/player/VdoInitParams;->resumeTimeMs:I

    int-to-long v2, v2

    .line 163
    invoke-virtual {v0, v2, v3}, Lcom/google/android/gms/cast/MediaLoadRequestData$Builder;->setCurrentTime(J)Lcom/google/android/gms/cast/MediaLoadRequestData$Builder;

    move-result-object v0

    iget-object v2, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    iget-object v2, v2, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-boolean v2, v2, Lcom/vdocipher/aegis/player/VdoInitParams;->autoplay:Z

    .line 164
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/google/android/gms/cast/MediaLoadRequestData$Builder;->setAutoplay(Ljava/lang/Boolean;)Lcom/google/android/gms/cast/MediaLoadRequestData$Builder;

    move-result-object v0

    .line 165
    invoke-virtual {v0}, Lcom/google/android/gms/cast/MediaLoadRequestData$Builder;->build()Lcom/google/android/gms/cast/MediaLoadRequestData;

    move-result-object v0

    .line 166
    iget-object v2, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    invoke-virtual {v2, v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->load(Lcom/google/android/gms/cast/MediaLoadRequestData;)Lcom/google/android/gms/common/api/PendingResult;

    return-void

    :catch_173
    move-exception v0

    .line 167
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/16 v2, 0xc21

    .line 168
    invoke-static {v0, v2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Ljava/lang/Exception;I)Lcom/vdocipher/aegis/media/ErrorDescription;

    move-result-object v0

    .line 169
    iget-object v2, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->e:Landroid/os/Handler;

    new-instance v3, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda1;

    invoke-direct {v3, v1, v0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda1;-><init>(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :catch_18c
    move-exception v0

    goto :goto_193

    :catch_18e
    move-exception v0

    goto :goto_193

    :catch_190
    move-exception v0

    goto :goto_193

    :catch_192
    move-exception v0

    .line 170
    :goto_193
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/16 v2, 0xc20

    .line 171
    invoke-static {v0, v2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Ljava/lang/Exception;I)Lcom/vdocipher/aegis/media/ErrorDescription;

    move-result-object v0

    .line 172
    iget-object v2, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->e:Landroid/os/Handler;

    new-instance v3, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda2;

    invoke-direct {v3, v1, v0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda2;-><init>(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private static b(Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;)I
    .registers 3

    .line 43
    invoke-virtual {p0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->getPlayerState()I

    move-result p0

    const/4 v0, 0x3

    const/4 v1, 0x2

    if-eq p0, v1, :cond_10

    if-eq p0, v0, :cond_10

    const/4 v0, 0x4

    if-eq p0, v0, :cond_f

    const/4 p0, 0x1

    return p0

    :cond_f
    return v1

    :cond_10
    return v0
.end method

.method static synthetic b(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    return-object p0
.end method

.method private b(Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;)V
    .registers 5

    .line 9
    :try_start_0
    iget-object v0, p1, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v0, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    invoke-static {v0}, Lcom/vdocipher/aegis/core/c/c;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_8
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_8} :catch_69
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_8} :catch_67
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_8} :catch_65

    .line 24
    iget-object v1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->d:Lcom/vdocipher/aegis/core/c/b;

    if-eqz v1, :cond_f

    .line 25
    invoke-virtual {v1}, Lcom/vdocipher/aegis/core/c/b;->b()V

    .line 28
    :cond_f
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "https://meta.vdocipher.com/api/meta/"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 29
    iget-object v1, p1, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v1, v1, Lcom/vdocipher/aegis/player/VdoInitParams;->token:Ljava/lang/String;

    invoke-static {v1}, Lcom/vdocipher/aegis/core/t/d;->i(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_40

    .line 30
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "?token="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p1, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v0, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->token:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_58

    .line 32
    :cond_40
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "?otp="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p1, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v0, v0, Lcom/vdocipher/aegis/player/VdoInitParams;->token:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 34
    :goto_58
    new-instance v1, Lcom/vdocipher/aegis/core/c/b;

    invoke-direct {v1}, Lcom/vdocipher/aegis/core/c/b;-><init>()V

    iput-object v1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->d:Lcom/vdocipher/aegis/core/c/b;

    .line 35
    iget-object v2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->p:Lcom/vdocipher/aegis/core/c/b$d;

    invoke-virtual {v1, v0, p1, v2}, Lcom/vdocipher/aegis/core/c/b;->a(Ljava/lang/String;Ljava/lang/Object;Lcom/vdocipher/aegis/core/c/b$d;)V

    return-void

    :catch_65
    move-exception v0

    goto :goto_6a

    :catch_67
    move-exception v0

    goto :goto_6a

    :catch_69
    move-exception v0

    .line 36
    :goto_6a
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "CastVdoPlayer"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 39
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->e:Landroid/os/Handler;

    new-instance v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0, p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$$ExternalSyntheticLambda3;-><init>(Lcom/vdocipher/aegis/cast/CastVdoPlayer;Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private synthetic b(Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 5

    .line 40
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    if-eqz v0, :cond_1e

    .line 41
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->j:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1e

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 42
    iget-object v2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    iget-object v2, v2, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-interface {v1, v2, p1}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onLoadError(Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    goto :goto_a

    :cond_1e
    return-void
.end method

.method static synthetic c(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)Landroid/os/Handler;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->e:Landroid/os/Handler;

    return-object p0
.end method

.method private c()Lcom/google/android/gms/cast/MediaStatus;
    .registers 2

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    if-eqz v0, :cond_9

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->getMediaStatus()Lcom/google/android/gms/cast/MediaStatus;

    move-result-object v0

    return-object v0

    :cond_9
    const/4 v0, 0x0

    return-object v0
.end method

.method private synthetic c(Lcom/vdocipher/aegis/media/ErrorDescription;)V
    .registers 5

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    if-eqz v0, :cond_1e

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->j:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1e

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 5
    iget-object v2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    iget-object v2, v2, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-interface {v1, v2, p1}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onLoadError(Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    goto :goto_a

    :cond_1e
    return-void
.end method

.method static synthetic d(Lcom/vdocipher/aegis/cast/CastVdoPlayer;)Ljava/util/concurrent/CopyOnWriteArraySet;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->j:Ljava/util/concurrent/CopyOnWriteArraySet;

    return-object p0
.end method

.method private synthetic d()V
    .registers 8

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    if-eqz v0, :cond_28

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->j:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_28

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 4
    iget-object v2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    iget-object v2, v2, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    new-instance v3, Lcom/vdocipher/aegis/media/ErrorDescription;

    const-string v4, "no supported media delivery format available"

    const/4 v5, -0x1

    const/16 v6, 0x4c4

    invoke-direct {v3, v6, v4, v5}, Lcom/vdocipher/aegis/media/ErrorDescription;-><init>(ILjava/lang/String;I)V

    invoke-interface {v1, v2, v3}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onLoadError(Lcom/vdocipher/aegis/player/VdoInitParams;Lcom/vdocipher/aegis/media/ErrorDescription;)V

    goto :goto_a

    :cond_28
    return-void
.end method


# virtual methods
.method public addPlaybackEventListener(Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    :cond_7
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->j:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/CopyOnWriteArraySet;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method b()V
    .registers 4

    .line 2
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    if-eqz v0, :cond_35

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->hasMediaSession()Z

    move-result v0

    if-eqz v0, :cond_35

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->getMediaInfo()Lcom/google/android/gms/cast/MediaInfo;

    move-result-object v0

    if-eqz v0, :cond_35

    .line 5
    invoke-virtual {v0}, Lcom/google/android/gms/cast/MediaInfo;->getCustomData()Lorg/json/JSONObject;

    move-result-object v0

    if-eqz v0, :cond_1f

    .line 6
    const-string v1, "playbackInfo"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_20

    :cond_1f
    const/4 v0, 0x0

    .line 7
    :goto_20
    iget-object v1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    if-eqz v1, :cond_35

    .line 8
    iget-object v2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->n:Landroidx/lifecycle/MutableLiveData;

    iget-object v1, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    iget-object v1, v1, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroidx/lifecycle/MutableLiveData;->setValue(Ljava/lang/Object;)V

    :cond_35
    return-void
.end method

.method public getAvailableTracks()[Lcom/vdocipher/aegis/media/Track;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    :cond_7
    const/4 v0, 0x0

    .line 2
    new-array v0, v0, [Lcom/vdocipher/aegis/media/Track;

    return-object v0
.end method

.method public getBufferedTime()J
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    :cond_7
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->getCurrentTime()J

    move-result-wide v0

    return-wide v0
.end method

.method public getCurrentLiveOffset()J
    .registers 3

    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public getCurrentMedia()Lcom/vdocipher/aegis/media/MediaInfo;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    :cond_7
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    if-eqz v0, :cond_e

    iget-object v0, v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->b:Lcom/vdocipher/aegis/media/MediaInfo;

    return-object v0

    :cond_e
    const/4 v0, 0x0

    return-object v0
.end method

.method public getCurrentMediaItemIndex()I
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public getCurrentTime()J
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    :cond_7
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    if-eqz v0, :cond_10

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->getApproximateStreamPosition()J

    move-result-wide v0

    return-wide v0

    .line 3
    :cond_10
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    if-eqz v0, :cond_17

    iget-wide v0, v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->c:J

    return-wide v0

    :cond_17
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public getCurrentTimeline()Lcom/vdocipher/aegis/player/VdoTimeLine;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public getDuration()J
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    :cond_7
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    if-eqz v0, :cond_10

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->getStreamDuration()J

    move-result-wide v0

    return-wide v0

    .line 3
    :cond_10
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    if-eqz v0, :cond_17

    iget-wide v0, v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->d:J

    return-wide v0

    :cond_17
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public getPlayWhenReady()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    :cond_7
    iget-boolean v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->h:Z

    return v0
.end method

.method public getPlaybackProperty(Ljava/lang/String;)Ljava/lang/Object;
    .registers 2

    .line 1
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz p1, :cond_7

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/b/a;->a()V

    :cond_7
    const/4 p1, 0x0

    return-object p1
.end method

.method public getPlaybackSpeed()F
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    :cond_7
    const/high16 v0, 0x3f800000  # 1.0f

    return v0
.end method

.method public getPlaybackState()I
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    :cond_7
    iget v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->g:I

    return v0
.end method

.method public getPlayerOptions()Lcom/vdocipher/aegis/media/PlayerOption;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->l:Lcom/vdocipher/aegis/media/PlayerOption;

    return-object v0
.end method

.method public getSelectedTracks()[Lcom/vdocipher/aegis/media/Track;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    :cond_7
    const/4 v0, 0x0

    .line 2
    new-array v0, v0, [Lcom/vdocipher/aegis/media/Track;

    return-object v0
.end method

.method public getTitle()Landroidx/lifecycle/MutableLiveData;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroidx/lifecycle/MutableLiveData<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->m:Landroidx/lifecycle/MutableLiveData;

    return-object v0
.end method

.method public isAdaptive()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    :cond_7
    const/4 v0, 0x0

    return v0
.end method

.method public isCastSessionAvailable()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    :cond_7
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    if-eqz v0, :cond_d

    const/4 v0, 0x1

    return v0

    :cond_d
    const/4 v0, 0x0

    return v0
.end method

.method public isCurrentMediaItemLive()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public isCurrentMediaItemSeekable()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public isCurrentWindowDynamic()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public isSpeedControlSupported()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    :cond_7
    const/4 v0, 0x0

    return v0
.end method

.method public isVideoPlaying()Z
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    const/4 v1, 0x0

    if-eqz v0, :cond_26

    .line 2
    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->hasMediaSession()Z

    move-result v0

    if-eqz v0, :cond_26

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->getMediaStatus()Lcom/google/android/gms/cast/MediaStatus;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/cast/MediaStatus;->getPlayerState()I

    move-result v0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_25

    .line 4
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    .line 5
    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->getMediaStatus()Lcom/google/android/gms/cast/MediaStatus;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/cast/MediaStatus;->getIdleReason()I

    move-result v0

    if-ne v0, v2, :cond_25

    return v1

    :cond_25
    return v2

    :cond_26
    return v1
.end method

.method public joinSession(Lcom/vdocipher/aegis/player/VdoInitParams;)Z
    .registers 6

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 5
    :cond_7
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    const/4 v1, 0x0

    if-eqz v0, :cond_41

    .line 8
    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->hasMediaSession()Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_39

    .line 9
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->getMediaInfo()Lcom/google/android/gms/cast/MediaInfo;

    move-result-object v0

    if-eqz v0, :cond_39

    .line 11
    invoke-virtual {v0}, Lcom/google/android/gms/cast/MediaInfo;->getCustomData()Lorg/json/JSONObject;

    move-result-object v0

    if-eqz v0, :cond_28

    .line 12
    const-string v3, "playbackInfo"

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_29

    :cond_28
    move-object v3, v2

    :goto_29
    if-eqz v0, :cond_32

    .line 13
    const-string v2, "meta"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object v2, v0

    .line 14
    :cond_32
    iget-object v0, p1, Lcom/vdocipher/aegis/player/VdoInitParams;->playbackInfo:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    goto :goto_3a

    :cond_39
    move v0, v1

    :goto_3a
    if-eqz v0, :cond_41

    .line 24
    invoke-direct {p0, p1, v2}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a(Lcom/vdocipher/aegis/player/VdoInitParams;Ljava/lang/String;)V

    const/4 p1, 0x1

    return p1

    :cond_41
    return v1
.end method

.method public load(Lcom/vdocipher/aegis/player/VdoInitParams;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    :cond_7
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    if-eqz v0, :cond_16

    .line 3
    new-instance v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    invoke-direct {v0, p1}, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;-><init>(Lcom/vdocipher/aegis/player/VdoInitParams;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    .line 4
    invoke-direct {p0, v0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b(Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;)V

    return-void

    .line 7
    :cond_16
    const-string p1, "CastVdoPlayer"

    const-string v0, "Cannot load, cast session not available"

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public release()V
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    :cond_7
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->a:Lcom/google/android/gms/cast/framework/CastContext;

    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/CastContext;->getSessionManager()Lcom/google/android/gms/cast/framework/SessionManager;

    move-result-object v0

    .line 3
    iget-object v1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->c:Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;

    const-class v2, Lcom/google/android/gms/cast/framework/CastSession;

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/cast/framework/SessionManager;->removeSessionManagerListener(Lcom/google/android/gms/cast/framework/SessionManagerListener;Ljava/lang/Class;)V

    .line 5
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    if-eqz v0, :cond_24

    .line 6
    iget-object v1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->c:Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;

    invoke-virtual {v0, v1}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->unregisterCallback(Lcom/google/android/gms/cast/framework/media/RemoteMediaClient$Callback;)V

    .line 7
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    iget-object v1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->c:Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;

    invoke-virtual {v0, v1}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->removeProgressListener(Lcom/google/android/gms/cast/framework/media/RemoteMediaClient$ProgressListener;)V

    :cond_24
    const/4 v0, 0x0

    .line 9
    iput-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->c:Lcom/vdocipher/aegis/cast/CastVdoPlayer$b;

    .line 10
    iput-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->k:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method public removePlaybackEventListener(Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    :cond_7
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->j:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/CopyOnWriteArraySet;->remove(Ljava/lang/Object;)Z

    return-void
.end method

.method public retry()V
    .registers 1

    return-void
.end method

.method public searchInSelectedSubtitle(Ljava/lang/String;Lcom/vdocipher/aegis/player/internal/subtitle/SubtitleSearchListener;)V
    .registers 3

    return-void
.end method

.method public seekTo(J)V
    .registers 5

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    :cond_7
    invoke-direct {p0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->c()Lcom/google/android/gms/cast/MediaStatus;

    move-result-object v0

    if-eqz v0, :cond_1f

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    new-instance v1, Lcom/google/android/gms/cast/MediaSeekOptions$Builder;

    invoke-direct {v1}, Lcom/google/android/gms/cast/MediaSeekOptions$Builder;-><init>()V

    .line 4
    invoke-virtual {v1, p1, p2}, Lcom/google/android/gms/cast/MediaSeekOptions$Builder;->setPosition(J)Lcom/google/android/gms/cast/MediaSeekOptions$Builder;

    move-result-object p1

    .line 5
    invoke-virtual {p1}, Lcom/google/android/gms/cast/MediaSeekOptions$Builder;->build()Lcom/google/android/gms/cast/MediaSeekOptions;

    move-result-object p1

    .line 6
    invoke-virtual {v0, p1}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->seek(Lcom/google/android/gms/cast/MediaSeekOptions;)Lcom/google/android/gms/common/api/PendingResult;

    :cond_1f
    return-void
.end method

.method public seekToDefaultPosition()V
    .registers 1

    return-void
.end method

.method public setAutoResumeCallback(Lcom/vdocipher/aegis/player/internal/util/AutoResumeCallback;)V
    .registers 2

    return-void
.end method

.method public setPlayWhenReady(Z)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    :cond_7
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    if-eqz v0, :cond_14

    if-eqz p1, :cond_11

    .line 4
    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->play()Lcom/google/android/gms/common/api/PendingResult;

    return-void

    .line 6
    :cond_11
    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->pause()Lcom/google/android/gms/common/api/PendingResult;

    :cond_14
    return-void
.end method

.method public setPlaybackSpeed(F)V
    .registers 2

    .line 1
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz p1, :cond_7

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/b/a;->a()V

    :cond_7
    return-void
.end method

.method public setSelectedTracks([Lcom/vdocipher/aegis/media/Track;)V
    .registers 2

    .line 1
    iget-object p1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz p1, :cond_7

    invoke-virtual {p1}, Lcom/vdocipher/aegis/core/b/a;->a()V

    :cond_7
    return-void
.end method

.method public setSessionAvailabilityListenerWeakRef(Lcom/vdocipher/aegis/cast/CastSessionAvailabilityListener;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    .line 2
    :cond_7
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->k:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method public stop()V
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->i:Lcom/vdocipher/aegis/core/b/a;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/vdocipher/aegis/core/b/a;->a()V

    :cond_7
    const/4 v0, 0x1

    .line 2
    iput v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->g:I

    .line 3
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    if-eqz v0, :cond_11

    .line 4
    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->stop()Lcom/google/android/gms/common/api/PendingResult;

    :cond_11
    return-void
.end method

.method public updateInternalState()V
    .registers 7

    .line 1
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    if-nez v0, :cond_5

    return-void

    .line 5
    :cond_5
    invoke-virtual {v0}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->getPlayerState()I

    move-result v0

    .line 8
    iget-object v1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v1, :cond_36

    .line 9
    iget-boolean v1, v1, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->e:Z

    if-nez v1, :cond_36

    if-eq v0, v3, :cond_18

    if-ne v0, v2, :cond_36

    .line 11
    :cond_18
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->j:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_32

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 12
    iget-object v5, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    iget-object v5, v5, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-interface {v1, v5}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onLoaded(Lcom/vdocipher/aegis/player/VdoInitParams;)V

    goto :goto_1e

    .line 14
    :cond_32
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    iput-boolean v4, v0, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->e:Z

    .line 18
    :cond_36
    iget-object v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    invoke-static {v0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b(Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;)I

    move-result v0

    const/4 v1, 0x4

    if-ne v0, v4, :cond_46

    .line 20
    iget v5, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->g:I

    if-eq v5, v3, :cond_45

    if-ne v5, v2, :cond_46

    :cond_45
    move v0, v1

    .line 25
    :cond_46
    iget-object v2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    if-eqz v2, :cond_66

    if-ne v0, v1, :cond_66

    .line 26
    iget-object v1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->j:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_52
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_66

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 27
    iget-object v3, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->f:Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;

    iget-object v3, v3, Lcom/vdocipher/aegis/cast/CastVdoPlayer$c;->a:Lcom/vdocipher/aegis/player/VdoInitParams;

    invoke-interface {v2, v3}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onMediaEnded(Lcom/vdocipher/aegis/player/VdoInitParams;)V

    goto :goto_52

    .line 30
    :cond_66
    iget-object v1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b:Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;

    invoke-virtual {v1}, Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;->isPaused()Z

    move-result v1

    xor-int/2addr v1, v4

    .line 31
    iget v2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->g:I

    if-ne v2, v0, :cond_75

    iget-boolean v2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->h:Z

    if-eq v2, v1, :cond_8f

    .line 32
    :cond_75
    iput v0, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->g:I

    .line 33
    iput-boolean v1, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->h:Z

    .line 34
    iget-object v2, p0, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->j:Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-virtual {v2}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_7f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_8f

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;

    .line 35
    invoke-interface {v3, v1, v0}, Lcom/vdocipher/aegis/player/VdoPlayer$PlaybackEventListener;->onPlayerStateChanged(ZI)V

    goto :goto_7f

    .line 39
    :cond_8f
    invoke-virtual {p0}, Lcom/vdocipher/aegis/cast/CastVdoPlayer;->b()V

    return-void
.end method
