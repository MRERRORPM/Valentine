# classes14.dex

.class public final Lcom/vdocipher/aegis/R$array;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "array"
.end annotation


# static fields
.field public static cast_expanded_controller_control_buttons:I = 0x7f030002

.field public static cast_expanded_controller_default_control_buttons:I = 0x7f030003

.field public static cast_mini_controller_control_buttons:I = 0x7f030004

.field public static cast_mini_controller_default_control_buttons:I = 0x7f030005

.field public static exo_controls_playback_speeds:I = 0x7f030007

.field public static prefs_termination_policy_names:I = 0x7f030008

.field public static prefs_termination_policy_values:I = 0x7f030009

.field public static prefs_volume_names:I = 0x7f03000a

.field public static prefs_volume_values:I = 0x7f03000b


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
