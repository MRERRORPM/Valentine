# classes14.dex

.class public Lcom/vdocipher/aegis/BR;
.super Ljava/lang/Object;
.source "BR.java"


# static fields
.field public static final _all:I


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
