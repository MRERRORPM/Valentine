# classes14.dex

.class public final Lcom/vdocipher/aegis/R$layout;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static abc_action_bar_title_item:I = 0x7f0d0000

.field public static abc_action_bar_up_container:I = 0x7f0d0001

.field public static abc_action_menu_item_layout:I = 0x7f0d0002

.field public static abc_action_menu_layout:I = 0x7f0d0003

.field public static abc_action_mode_bar:I = 0x7f0d0004

.field public static abc_action_mode_close_item_material:I = 0x7f0d0005

.field public static abc_activity_chooser_view:I = 0x7f0d0006

.field public static abc_activity_chooser_view_list_item:I = 0x7f0d0007

.field public static abc_alert_dialog_button_bar_material:I = 0x7f0d0008

.field public static abc_alert_dialog_material:I = 0x7f0d0009

.field public static abc_alert_dialog_title_material:I = 0x7f0d000a

.field public static abc_cascading_menu_item_layout:I = 0x7f0d000b

.field public static abc_dialog_title_material:I = 0x7f0d000c

.field public static abc_expanded_menu_layout:I = 0x7f0d000d

.field public static abc_list_menu_item_checkbox:I = 0x7f0d000e

.field public static abc_list_menu_item_icon:I = 0x7f0d000f

.field public static abc_list_menu_item_layout:I = 0x7f0d0010

.field public static abc_list_menu_item_radio:I = 0x7f0d0011

.field public static abc_popup_menu_header_item_layout:I = 0x7f0d0012

.field public static abc_popup_menu_item_layout:I = 0x7f0d0013

.field public static abc_screen_content_include:I = 0x7f0d0014

.field public static abc_screen_simple:I = 0x7f0d0015

.field public static abc_screen_simple_overlay_action_mode:I = 0x7f0d0016

.field public static abc_screen_toolbar:I = 0x7f0d0017

.field public static abc_search_dropdown_item_icons_2line:I = 0x7f0d0018

.field public static abc_search_view:I = 0x7f0d0019

.field public static abc_select_dialog_material:I = 0x7f0d001a

.field public static abc_tooltip:I = 0x7f0d001b

.field public static cast_expanded_controller_activity:I = 0x7f0d0032

.field public static cast_help_text:I = 0x7f0d0033

.field public static cast_intro_overlay:I = 0x7f0d0034

.field public static cast_mini_controller:I = 0x7f0d0035

.field public static cast_tracks_chooser_dialog_layout:I = 0x7f0d0036

.field public static cast_tracks_chooser_dialog_row_layout:I = 0x7f0d0037

.field public static custom_dialog:I = 0x7f0d003a

.field public static design_bottom_navigation_item:I = 0x7f0d003b

.field public static design_bottom_sheet_dialog:I = 0x7f0d003c

.field public static design_layout_snackbar:I = 0x7f0d003d

.field public static design_layout_snackbar_include:I = 0x7f0d003e

.field public static design_layout_tab_icon:I = 0x7f0d003f

.field public static design_layout_tab_text:I = 0x7f0d0040

.field public static design_menu_item_action_area:I = 0x7f0d0041

.field public static design_navigation_item:I = 0x7f0d0042

.field public static design_navigation_item_header:I = 0x7f0d0043

.field public static design_navigation_item_separator:I = 0x7f0d0044

.field public static design_navigation_item_subheader:I = 0x7f0d0045

.field public static design_navigation_menu:I = 0x7f0d0046

.field public static design_navigation_menu_item:I = 0x7f0d0047

.field public static design_text_input_end_icon:I = 0x7f0d0048

.field public static design_text_input_start_icon:I = 0x7f0d0049

.field public static exo_legacy_player_control_view:I = 0x7f0d0051

.field public static exo_list_divider:I = 0x7f0d0052

.field public static exo_player_control_ffwd_button:I = 0x7f0d0053

.field public static exo_player_control_rewind_button:I = 0x7f0d0054

.field public static exo_player_control_view:I = 0x7f0d0055

.field public static exo_player_view:I = 0x7f0d0056

.field public static exo_styled_settings_list:I = 0x7f0d005b

.field public static exo_styled_settings_list_item:I = 0x7f0d005c

.field public static exo_styled_sub_settings_list_item:I = 0x7f0d005d

.field public static exo_track_selection_dialog:I = 0x7f0d005e

.field public static ime_base_split_test_activity:I = 0x7f0d0086

.field public static ime_secondary_split_test_activity:I = 0x7f0d0087

.field public static m3_alert_dialog:I = 0x7f0d008d

.field public static m3_alert_dialog_actions:I = 0x7f0d008e

.field public static m3_alert_dialog_title:I = 0x7f0d008f

.field public static m3_auto_complete_simple_item:I = 0x7f0d0090

.field public static m3_navigation_menu_divider:I = 0x7f0d0091

.field public static m3_navigation_menu_subheader:I = 0x7f0d0092

.field public static m3_side_sheet_dialog:I = 0x7f0d0093

.field public static material_chip_input_combo:I = 0x7f0d0094

.field public static material_clock_display:I = 0x7f0d0095

.field public static material_clock_display_divider:I = 0x7f0d0096

.field public static material_clock_period_toggle:I = 0x7f0d0097

.field public static material_clock_period_toggle_land:I = 0x7f0d0098

.field public static material_clockface_textview:I = 0x7f0d0099

.field public static material_clockface_view:I = 0x7f0d009a

.field public static material_radial_view_group:I = 0x7f0d009b

.field public static material_textinput_timepicker:I = 0x7f0d009c

.field public static material_time_chip:I = 0x7f0d009d

.field public static material_time_input:I = 0x7f0d009e

.field public static material_timepicker:I = 0x7f0d009f

.field public static material_timepicker_dialog:I = 0x7f0d00a0

.field public static material_timepicker_textinput_display:I = 0x7f0d00a1

.field public static media3_notification_media_action:I = 0x7f0d00a2

.field public static media3_notification_template_big_media:I = 0x7f0d00a3

.field public static media3_notification_template_big_media_custom:I = 0x7f0d00a4

.field public static media3_notification_template_big_media_narrow:I = 0x7f0d00a5

.field public static media3_notification_template_big_media_narrow_custom:I = 0x7f0d00a6

.field public static media3_notification_template_lines_media:I = 0x7f0d00a7

.field public static media3_notification_template_media:I = 0x7f0d00a8

.field public static media3_notification_template_media_custom:I = 0x7f0d00a9

.field public static mr_cast_dialog:I = 0x7f0d00b1

.field public static mr_cast_group_item:I = 0x7f0d00b2

.field public static mr_cast_group_volume_item:I = 0x7f0d00b3

.field public static mr_cast_header_item:I = 0x7f0d00b4

.field public static mr_cast_media_metadata:I = 0x7f0d00b5

.field public static mr_cast_route_item:I = 0x7f0d00b6

.field public static mr_chooser_dialog:I = 0x7f0d00b7

.field public static mr_chooser_list_item:I = 0x7f0d00b8

.field public static mr_controller_material_dialog_b:I = 0x7f0d00b9

.field public static mr_controller_volume_item:I = 0x7f0d00ba

.field public static mr_picker_dialog:I = 0x7f0d00bb

.field public static mr_picker_header_item:I = 0x7f0d00bc

.field public static mr_picker_route_item:I = 0x7f0d00bd

.field public static mr_playback_control:I = 0x7f0d00be

.field public static mr_volume_control:I = 0x7f0d00bf

.field public static mtrl_alert_dialog:I = 0x7f0d00c0

.field public static mtrl_alert_dialog_actions:I = 0x7f0d00c1

.field public static mtrl_alert_dialog_title:I = 0x7f0d00c2

.field public static mtrl_alert_select_dialog_item:I = 0x7f0d00c3

.field public static mtrl_alert_select_dialog_multichoice:I = 0x7f0d00c4

.field public static mtrl_alert_select_dialog_singlechoice:I = 0x7f0d00c5

.field public static mtrl_auto_complete_simple_item:I = 0x7f0d00c6

.field public static mtrl_calendar_day:I = 0x7f0d00c7

.field public static mtrl_calendar_day_of_week:I = 0x7f0d00c8

.field public static mtrl_calendar_days_of_week:I = 0x7f0d00c9

.field public static mtrl_calendar_horizontal:I = 0x7f0d00ca

.field public static mtrl_calendar_month:I = 0x7f0d00cb

.field public static mtrl_calendar_month_labeled:I = 0x7f0d00cc

.field public static mtrl_calendar_month_navigation:I = 0x7f0d00cd

.field public static mtrl_calendar_months:I = 0x7f0d00ce

.field public static mtrl_calendar_vertical:I = 0x7f0d00cf

.field public static mtrl_calendar_year:I = 0x7f0d00d0

.field public static mtrl_layout_snackbar:I = 0x7f0d00d1

.field public static mtrl_layout_snackbar_include:I = 0x7f0d00d2

.field public static mtrl_navigation_rail_item:I = 0x7f0d00d3

.field public static mtrl_picker_actions:I = 0x7f0d00d4

.field public static mtrl_picker_dialog:I = 0x7f0d00d5

.field public static mtrl_picker_fullscreen:I = 0x7f0d00d6

.field public static mtrl_picker_header_dialog:I = 0x7f0d00d7

.field public static mtrl_picker_header_fullscreen:I = 0x7f0d00d8

.field public static mtrl_picker_header_selection_text:I = 0x7f0d00d9

.field public static mtrl_picker_header_title_text:I = 0x7f0d00da

.field public static mtrl_picker_header_toggle:I = 0x7f0d00db

.field public static mtrl_picker_text_input_date:I = 0x7f0d00dc

.field public static mtrl_picker_text_input_date_range:I = 0x7f0d00dd

.field public static mtrl_search_bar:I = 0x7f0d00de

.field public static mtrl_search_view:I = 0x7f0d00df

.field public static notification_action:I = 0x7f0d00e3

.field public static notification_action_tombstone:I = 0x7f0d00e4

.field public static notification_media_action:I = 0x7f0d00e5

.field public static notification_media_cancel_action:I = 0x7f0d00e6

.field public static notification_template_big_media:I = 0x7f0d00e7

.field public static notification_template_big_media_custom:I = 0x7f0d00e8

.field public static notification_template_big_media_narrow:I = 0x7f0d00e9

.field public static notification_template_big_media_narrow_custom:I = 0x7f0d00ea

.field public static notification_template_custom_big:I = 0x7f0d00eb

.field public static notification_template_icon_group:I = 0x7f0d00ec

.field public static notification_template_lines_media:I = 0x7f0d00ed

.field public static notification_template_media:I = 0x7f0d00ee

.field public static notification_template_media_custom:I = 0x7f0d00ef

.field public static notification_template_part_chronometer:I = 0x7f0d00f0

.field public static notification_template_part_time:I = 0x7f0d00f1

.field public static select_dialog_item_material:I = 0x7f0d0104

.field public static select_dialog_multichoice_material:I = 0x7f0d0105

.field public static select_dialog_singlechoice_material:I = 0x7f0d0106

.field public static support_simple_spinner_dropdown_item:I = 0x7f0d0115

.field public static vdo_about_player_dialog_view:I = 0x7f0d0116

.field public static vdo_btn_media_route_button:I = 0x7f0d0117

.field public static vdo_caption_search_dialog_view:I = 0x7f0d0118

.field public static vdo_cast_connect_screen:I = 0x7f0d0119

.field public static vdo_cast_volume:I = 0x7f0d011a

.field public static vdo_control_view:I = 0x7f0d011b

.field public static vdo_control_view_theme:I = 0x7f0d011c

.field public static vdo_custom_cast_mini_controller:I = 0x7f0d011d

.field public static vdo_custom_expended_ui_controller:I = 0x7f0d011e

.field public static vdo_fragment_bottomsheet_clear_storage:I = 0x7f0d011f

.field public static vdo_fragment_bottomsheet_dialog:I = 0x7f0d0120

.field public static vdo_fragment_bottomsheet_list_item:I = 0x7f0d0121

.field public static vdo_fragment_bottomsheet_option_selector:I = 0x7f0d0122

.field public static vdo_list_divider:I = 0x7f0d0123

.field public static vdo_player_fragment_activity:I = 0x7f0d0124

.field public static vdo_sample_player:I = 0x7f0d0125

.field public static vdo_scrubbing_player_view:I = 0x7f0d0126

.field public static vdo_subtile_search_result_view:I = 0x7f0d0127

.field public static vdo_track_selection_dialog:I = 0x7f0d0128


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
