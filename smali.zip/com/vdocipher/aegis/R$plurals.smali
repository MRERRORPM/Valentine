# classes14.dex

.class public final Lcom/vdocipher/aegis/R$plurals;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "plurals"
.end annotation


# static fields
.field public static exo_controls_fastforward_by_amount_description:I = 0x7f110000

.field public static exo_controls_rewind_by_amount_description:I = 0x7f110001

.field public static mtrl_badge_content_description:I = 0x7f110015


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
