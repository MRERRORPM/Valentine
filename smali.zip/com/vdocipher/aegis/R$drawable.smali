# classes14.dex

.class public final Lcom/vdocipher/aegis/R$drawable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/aegis/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static abc_ab_share_pack_mtrl_alpha:I = 0x7f0800dc

.field public static abc_action_bar_item_background_material:I = 0x7f0800dd

.field public static abc_btn_borderless_material:I = 0x7f0800de

.field public static abc_btn_check_material:I = 0x7f0800df

.field public static abc_btn_check_material_anim:I = 0x7f0800e0

.field public static abc_btn_check_to_on_mtrl_000:I = 0x7f0800e1

.field public static abc_btn_check_to_on_mtrl_015:I = 0x7f0800e2

.field public static abc_btn_colored_material:I = 0x7f0800e3

.field public static abc_btn_default_mtrl_shape:I = 0x7f0800e4

.field public static abc_btn_radio_material:I = 0x7f0800e5

.field public static abc_btn_radio_material_anim:I = 0x7f0800e6

.field public static abc_btn_radio_to_on_mtrl_000:I = 0x7f0800e7

.field public static abc_btn_radio_to_on_mtrl_015:I = 0x7f0800e8

.field public static abc_btn_switch_to_on_mtrl_00001:I = 0x7f0800e9

.field public static abc_btn_switch_to_on_mtrl_00012:I = 0x7f0800ea

.field public static abc_cab_background_internal_bg:I = 0x7f0800eb

.field public static abc_cab_background_top_material:I = 0x7f0800ec

.field public static abc_cab_background_top_mtrl_alpha:I = 0x7f0800ed

.field public static abc_control_background_material:I = 0x7f0800ee

.field public static abc_dialog_material_background:I = 0x7f0800ef

.field public static abc_edit_text_material:I = 0x7f0800f0

.field public static abc_ic_ab_back_material:I = 0x7f0800f1

.field public static abc_ic_arrow_drop_right_black_24dp:I = 0x7f0800f2

.field public static abc_ic_clear_material:I = 0x7f0800f3

.field public static abc_ic_commit_search_api_mtrl_alpha:I = 0x7f0800f4

.field public static abc_ic_go_search_api_material:I = 0x7f0800f5

.field public static abc_ic_menu_copy_mtrl_am_alpha:I = 0x7f0800f6

.field public static abc_ic_menu_cut_mtrl_alpha:I = 0x7f0800f7

.field public static abc_ic_menu_overflow_material:I = 0x7f0800f8

.field public static abc_ic_menu_paste_mtrl_am_alpha:I = 0x7f0800f9

.field public static abc_ic_menu_selectall_mtrl_alpha:I = 0x7f0800fa

.field public static abc_ic_menu_share_mtrl_alpha:I = 0x7f0800fb

.field public static abc_ic_search_api_material:I = 0x7f0800fc

.field public static abc_ic_voice_search_api_material:I = 0x7f0800fd

.field public static abc_item_background_holo_dark:I = 0x7f0800fe

.field public static abc_item_background_holo_light:I = 0x7f0800ff

.field public static abc_list_divider_material:I = 0x7f080100

.field public static abc_list_divider_mtrl_alpha:I = 0x7f080101

.field public static abc_list_focused_holo:I = 0x7f080102

.field public static abc_list_longpressed_holo:I = 0x7f080103

.field public static abc_list_pressed_holo_dark:I = 0x7f080104

.field public static abc_list_pressed_holo_light:I = 0x7f080105

.field public static abc_list_selector_background_transition_holo_dark:I = 0x7f080106

.field public static abc_list_selector_background_transition_holo_light:I = 0x7f080107

.field public static abc_list_selector_disabled_holo_dark:I = 0x7f080108

.field public static abc_list_selector_disabled_holo_light:I = 0x7f080109

.field public static abc_list_selector_holo_dark:I = 0x7f08010a

.field public static abc_list_selector_holo_light:I = 0x7f08010b

.field public static abc_menu_hardkey_panel_mtrl_mult:I = 0x7f08010c

.field public static abc_popup_background_mtrl_mult:I = 0x7f08010d

.field public static abc_ratingbar_indicator_material:I = 0x7f08010e

.field public static abc_ratingbar_material:I = 0x7f08010f

.field public static abc_ratingbar_small_material:I = 0x7f080110

.field public static abc_scrubber_control_off_mtrl_alpha:I = 0x7f080111

.field public static abc_scrubber_control_to_pressed_mtrl_000:I = 0x7f080112

.field public static abc_scrubber_control_to_pressed_mtrl_005:I = 0x7f080113

.field public static abc_scrubber_primary_mtrl_alpha:I = 0x7f080114

.field public static abc_scrubber_track_mtrl_alpha:I = 0x7f080115

.field public static abc_seekbar_thumb_material:I = 0x7f080116

.field public static abc_seekbar_tick_mark_material:I = 0x7f080117

.field public static abc_seekbar_track_material:I = 0x7f080118

.field public static abc_spinner_mtrl_am_alpha:I = 0x7f080119

.field public static abc_spinner_textfield_background_material:I = 0x7f08011a

.field public static abc_star_black_48dp:I = 0x7f08011b

.field public static abc_star_half_black_48dp:I = 0x7f08011c

.field public static abc_switch_thumb_material:I = 0x7f08011d

.field public static abc_switch_track_mtrl_alpha:I = 0x7f08011e

.field public static abc_tab_indicator_material:I = 0x7f08011f

.field public static abc_tab_indicator_mtrl_alpha:I = 0x7f080120

.field public static abc_text_cursor_material:I = 0x7f080121

.field public static abc_text_select_handle_left_mtrl:I = 0x7f080122

.field public static abc_text_select_handle_middle_mtrl:I = 0x7f080123

.field public static abc_text_select_handle_right_mtrl:I = 0x7f080124

.field public static abc_textfield_activated_mtrl_alpha:I = 0x7f080125

.field public static abc_textfield_default_mtrl_alpha:I = 0x7f080126

.field public static abc_textfield_search_activated_mtrl_alpha:I = 0x7f080127

.field public static abc_textfield_search_default_mtrl_alpha:I = 0x7f080128

.field public static abc_textfield_search_material:I = 0x7f080129

.field public static abc_vector_test:I = 0x7f08012a

.field public static avd_hide_password:I = 0x7f080138

.field public static avd_show_password:I = 0x7f080139

.field public static baseline_square_24:I = 0x7f08013d

.field public static btn_checkbox_checked_mtrl:I = 0x7f080167

.field public static btn_checkbox_checked_to_unchecked_mtrl_animation:I = 0x7f080168

.field public static btn_checkbox_unchecked_mtrl:I = 0x7f080169

.field public static btn_checkbox_unchecked_to_checked_mtrl_animation:I = 0x7f08016a

.field public static btn_radio_off_mtrl:I = 0x7f08016f

.field public static btn_radio_off_to_on_mtrl_animation:I = 0x7f080170

.field public static btn_radio_on_mtrl:I = 0x7f080171

.field public static btn_radio_on_to_off_mtrl_animation:I = 0x7f080172

.field public static cast_abc_scrubber_control_off_mtrl_alpha:I = 0x7f080180

.field public static cast_abc_scrubber_control_to_pressed_mtrl_000:I = 0x7f080181

.field public static cast_abc_scrubber_control_to_pressed_mtrl_005:I = 0x7f080182

.field public static cast_abc_scrubber_primary_mtrl_alpha:I = 0x7f080183

.field public static cast_album_art_placeholder:I = 0x7f080184

.field public static cast_album_art_placeholder_large:I = 0x7f080185

.field public static cast_expanded_controller_actionbar_bg_gradient_light:I = 0x7f080186

.field public static cast_expanded_controller_bg_gradient_light:I = 0x7f080187

.field public static cast_expanded_controller_live_indicator_drawable:I = 0x7f080188

.field public static cast_expanded_controller_seekbar_thumb:I = 0x7f080189

.field public static cast_expanded_controller_seekbar_track:I = 0x7f08018a

.field public static cast_ic_expanded_controller_closed_caption:I = 0x7f08018b

.field public static cast_ic_expanded_controller_forward30:I = 0x7f08018c

.field public static cast_ic_expanded_controller_mute:I = 0x7f08018d

.field public static cast_ic_expanded_controller_pause:I = 0x7f08018e

.field public static cast_ic_expanded_controller_play:I = 0x7f08018f

.field public static cast_ic_expanded_controller_rewind30:I = 0x7f080190

.field public static cast_ic_expanded_controller_skip_next:I = 0x7f080191

.field public static cast_ic_expanded_controller_skip_previous:I = 0x7f080192

.field public static cast_ic_expanded_controller_stop:I = 0x7f080193

.field public static cast_ic_mini_controller_closed_caption:I = 0x7f080194

.field public static cast_ic_mini_controller_forward30:I = 0x7f080195

.field public static cast_ic_mini_controller_mute:I = 0x7f080196

.field public static cast_ic_mini_controller_pause:I = 0x7f080197

.field public static cast_ic_mini_controller_pause_large:I = 0x7f080198

.field public static cast_ic_mini_controller_play:I = 0x7f080199

.field public static cast_ic_mini_controller_play_large:I = 0x7f08019a

.field public static cast_ic_mini_controller_rewind30:I = 0x7f08019b

.field public static cast_ic_mini_controller_skip_next:I = 0x7f08019c

.field public static cast_ic_mini_controller_skip_prev:I = 0x7f08019d

.field public static cast_ic_mini_controller_stop:I = 0x7f08019e

.field public static cast_ic_mini_controller_stop_large:I = 0x7f08019f

.field public static cast_ic_notification_0:I = 0x7f0801a0

.field public static cast_ic_notification_1:I = 0x7f0801a1

.field public static cast_ic_notification_2:I = 0x7f0801a2

.field public static cast_ic_notification_connecting:I = 0x7f0801a3

.field public static cast_ic_notification_disconnect:I = 0x7f0801a4

.field public static cast_ic_notification_forward:I = 0x7f0801a5

.field public static cast_ic_notification_forward10:I = 0x7f0801a6

.field public static cast_ic_notification_forward30:I = 0x7f0801a7

.field public static cast_ic_notification_on:I = 0x7f0801a8

.field public static cast_ic_notification_pause:I = 0x7f0801a9

.field public static cast_ic_notification_play:I = 0x7f0801aa

.field public static cast_ic_notification_rewind:I = 0x7f0801ab

.field public static cast_ic_notification_rewind10:I = 0x7f0801ac

.field public static cast_ic_notification_rewind30:I = 0x7f0801ad

.field public static cast_ic_notification_skip_next:I = 0x7f0801ae

.field public static cast_ic_notification_skip_prev:I = 0x7f0801af

.field public static cast_ic_notification_small_icon:I = 0x7f0801b0

.field public static cast_ic_notification_stop_live_stream:I = 0x7f0801b1

.field public static cast_ic_stop_circle_filled_grey600:I = 0x7f0801b2

.field public static cast_ic_stop_circle_filled_white:I = 0x7f0801b3

.field public static cast_mini_controller_gradient_light:I = 0x7f0801b4

.field public static cast_mini_controller_progress_drawable:I = 0x7f0801b5

.field public static cast_skip_ad_label_border:I = 0x7f0801b6

.field public static cast_tooltip_background:I = 0x7f0801b7

.field public static common_full_open_on_phone:I = 0x7f0801be

.field public static common_google_signin_btn_icon_dark:I = 0x7f0801bf

.field public static common_google_signin_btn_icon_dark_focused:I = 0x7f0801c0

.field public static common_google_signin_btn_icon_dark_normal:I = 0x7f0801c1

.field public static common_google_signin_btn_icon_dark_normal_background:I = 0x7f0801c2

.field public static common_google_signin_btn_icon_disabled:I = 0x7f0801c3

.field public static common_google_signin_btn_icon_light:I = 0x7f0801c4

.field public static common_google_signin_btn_icon_light_focused:I = 0x7f0801c5

.field public static common_google_signin_btn_icon_light_normal:I = 0x7f0801c6

.field public static common_google_signin_btn_icon_light_normal_background:I = 0x7f0801c7

.field public static common_google_signin_btn_text_dark:I = 0x7f0801c8

.field public static common_google_signin_btn_text_dark_focused:I = 0x7f0801c9

.field public static common_google_signin_btn_text_dark_normal:I = 0x7f0801ca

.field public static common_google_signin_btn_text_dark_normal_background:I = 0x7f0801cb

.field public static common_google_signin_btn_text_disabled:I = 0x7f0801cc

.field public static common_google_signin_btn_text_light:I = 0x7f0801cd

.field public static common_google_signin_btn_text_light_focused:I = 0x7f0801ce

.field public static common_google_signin_btn_text_light_normal:I = 0x7f0801cf

.field public static common_google_signin_btn_text_light_normal_background:I = 0x7f0801d0

.field public static design_fab_background:I = 0x7f0801e8

.field public static design_ic_visibility:I = 0x7f0801e9

.field public static design_ic_visibility_off:I = 0x7f0801ea

.field public static design_password_eye:I = 0x7f0801eb

.field public static design_snackbar_background:I = 0x7f0801ec

.field public static exo_edit_mode_logo:I = 0x7f08022e

.field public static exo_ic_audiotrack:I = 0x7f08022f

.field public static exo_ic_check:I = 0x7f080230

.field public static exo_ic_chevron_left:I = 0x7f080231

.field public static exo_ic_chevron_right:I = 0x7f080232

.field public static exo_ic_default_album_image:I = 0x7f080233

.field public static exo_ic_forward:I = 0x7f080234

.field public static exo_ic_fullscreen_enter:I = 0x7f080235

.field public static exo_ic_fullscreen_exit:I = 0x7f080236

.field public static exo_ic_pause_circle_filled:I = 0x7f080237

.field public static exo_ic_play_circle_filled:I = 0x7f080238

.field public static exo_ic_rewind:I = 0x7f080239

.field public static exo_ic_settings:I = 0x7f08023a

.field public static exo_ic_skip_next:I = 0x7f08023b

.field public static exo_ic_skip_previous:I = 0x7f08023c

.field public static exo_ic_speed:I = 0x7f08023d

.field public static exo_ic_subtitle_off:I = 0x7f08023e

.field public static exo_ic_subtitle_on:I = 0x7f08023f

.field public static exo_icon_circular_play:I = 0x7f080240

.field public static exo_icon_fastforward:I = 0x7f080241

.field public static exo_icon_fullscreen_enter:I = 0x7f080242

.field public static exo_icon_fullscreen_exit:I = 0x7f080243

.field public static exo_icon_next:I = 0x7f080244

.field public static exo_icon_pause:I = 0x7f080245

.field public static exo_icon_play:I = 0x7f080246

.field public static exo_icon_previous:I = 0x7f080247

.field public static exo_icon_repeat_all:I = 0x7f080248

.field public static exo_icon_repeat_off:I = 0x7f080249

.field public static exo_icon_repeat_one:I = 0x7f08024a

.field public static exo_icon_rewind:I = 0x7f08024b

.field public static exo_icon_shuffle_off:I = 0x7f08024c

.field public static exo_icon_shuffle_on:I = 0x7f08024d

.field public static exo_icon_stop:I = 0x7f08024e

.field public static exo_icon_vr:I = 0x7f08024f

.field public static exo_legacy_controls_fastforward:I = 0x7f080250

.field public static exo_legacy_controls_fullscreen_enter:I = 0x7f080251

.field public static exo_legacy_controls_fullscreen_exit:I = 0x7f080252

.field public static exo_legacy_controls_next:I = 0x7f080253

.field public static exo_legacy_controls_pause:I = 0x7f080254

.field public static exo_legacy_controls_play:I = 0x7f080255

.field public static exo_legacy_controls_previous:I = 0x7f080256

.field public static exo_legacy_controls_repeat_all:I = 0x7f080257

.field public static exo_legacy_controls_repeat_off:I = 0x7f080258

.field public static exo_legacy_controls_repeat_one:I = 0x7f080259

.field public static exo_legacy_controls_rewind:I = 0x7f08025a

.field public static exo_legacy_controls_shuffle_off:I = 0x7f08025b

.field public static exo_legacy_controls_shuffle_on:I = 0x7f08025c

.field public static exo_legacy_controls_vr:I = 0x7f08025d

.field public static exo_notification_fastforward:I = 0x7f08025e

.field public static exo_notification_next:I = 0x7f08025f

.field public static exo_notification_pause:I = 0x7f080260

.field public static exo_notification_play:I = 0x7f080261

.field public static exo_notification_previous:I = 0x7f080262

.field public static exo_notification_rewind:I = 0x7f080263

.field public static exo_notification_small_icon:I = 0x7f080264

.field public static exo_notification_stop:I = 0x7f080265

.field public static exo_rounded_rectangle:I = 0x7f080266

.field public static exo_styled_controls_audiotrack:I = 0x7f080267

.field public static exo_styled_controls_check:I = 0x7f080268

.field public static exo_styled_controls_fastforward:I = 0x7f080269

.field public static exo_styled_controls_fullscreen_enter:I = 0x7f08026a

.field public static exo_styled_controls_fullscreen_exit:I = 0x7f08026b

.field public static exo_styled_controls_next:I = 0x7f08026c

.field public static exo_styled_controls_overflow_hide:I = 0x7f08026d

.field public static exo_styled_controls_overflow_show:I = 0x7f08026e

.field public static exo_styled_controls_pause:I = 0x7f08026f

.field public static exo_styled_controls_play:I = 0x7f080270

.field public static exo_styled_controls_previous:I = 0x7f080271

.field public static exo_styled_controls_repeat_all:I = 0x7f080272

.field public static exo_styled_controls_repeat_off:I = 0x7f080273

.field public static exo_styled_controls_repeat_one:I = 0x7f080274

.field public static exo_styled_controls_rewind:I = 0x7f080275

.field public static exo_styled_controls_settings:I = 0x7f080276

.field public static exo_styled_controls_shuffle_off:I = 0x7f080277

.field public static exo_styled_controls_shuffle_on:I = 0x7f080278

.field public static exo_styled_controls_simple_fastforward:I = 0x7f080279

.field public static exo_styled_controls_simple_rewind:I = 0x7f08027a

.field public static exo_styled_controls_speed:I = 0x7f08027b

.field public static exo_styled_controls_subtitle_off:I = 0x7f08027c

.field public static exo_styled_controls_subtitle_on:I = 0x7f08027d

.field public static exo_styled_controls_vr:I = 0x7f08027e

.field public static googleg_disabled_color_18:I = 0x7f080285

.field public static googleg_standard_color_18:I = 0x7f080286

.field public static ic_arrow_back_black_24:I = 0x7f0802b9

.field public static ic_audiotrack_dark:I = 0x7f0802c8

.field public static ic_audiotrack_light:I = 0x7f0802c9

.field public static ic_call_answer:I = 0x7f0802da

.field public static ic_call_answer_low:I = 0x7f0802db

.field public static ic_call_answer_video:I = 0x7f0802dc

.field public static ic_call_answer_video_low:I = 0x7f0802dd

.field public static ic_call_decline:I = 0x7f0802de

.field public static ic_call_decline_low:I = 0x7f0802df

.field public static ic_checked_checkbox:I = 0x7f0802ec

.field public static ic_clear_black_24:I = 0x7f0802ee

.field public static ic_clock_black_24dp:I = 0x7f0802ef

.field public static ic_dialog_close_dark:I = 0x7f080307

.field public static ic_dialog_close_light:I = 0x7f080308

.field public static ic_expand_less_22px:I = 0x7f08032a

.field public static ic_expand_more_22px:I = 0x7f08032b

.field public static ic_group_collapse_00:I = 0x7f080339

.field public static ic_group_collapse_01:I = 0x7f08033a

.field public static ic_group_collapse_02:I = 0x7f08033b

.field public static ic_group_collapse_03:I = 0x7f08033c

.field public static ic_group_collapse_04:I = 0x7f08033d

.field public static ic_group_collapse_05:I = 0x7f08033e

.field public static ic_group_collapse_06:I = 0x7f08033f

.field public static ic_group_collapse_07:I = 0x7f080340

.field public static ic_group_collapse_08:I = 0x7f080341

.field public static ic_group_collapse_09:I = 0x7f080342

.field public static ic_group_collapse_10:I = 0x7f080343

.field public static ic_group_collapse_11:I = 0x7f080344

.field public static ic_group_collapse_12:I = 0x7f080345

.field public static ic_group_collapse_13:I = 0x7f080346

.field public static ic_group_collapse_14:I = 0x7f080347

.field public static ic_group_collapse_15:I = 0x7f080348

.field public static ic_group_expand_00:I = 0x7f080349

.field public static ic_group_expand_01:I = 0x7f08034a

.field public static ic_group_expand_02:I = 0x7f08034b

.field public static ic_group_expand_03:I = 0x7f08034c

.field public static ic_group_expand_04:I = 0x7f08034d

.field public static ic_group_expand_05:I = 0x7f08034e

.field public static ic_group_expand_06:I = 0x7f08034f

.field public static ic_group_expand_07:I = 0x7f080350

.field public static ic_group_expand_08:I = 0x7f080351

.field public static ic_group_expand_09:I = 0x7f080352

.field public static ic_group_expand_10:I = 0x7f080353

.field public static ic_group_expand_11:I = 0x7f080354

.field public static ic_group_expand_12:I = 0x7f080355

.field public static ic_group_expand_13:I = 0x7f080356

.field public static ic_group_expand_14:I = 0x7f080357

.field public static ic_group_expand_15:I = 0x7f080358

.field public static ic_keyboard_black_24dp:I = 0x7f080388

.field public static ic_m3_chip_check:I = 0x7f080391

.field public static ic_m3_chip_checked_circle:I = 0x7f080392

.field public static ic_m3_chip_close:I = 0x7f080393

.field public static ic_media_pause_dark:I = 0x7f080394

.field public static ic_media_pause_light:I = 0x7f080395

.field public static ic_media_play_dark:I = 0x7f080396

.field public static ic_media_play_light:I = 0x7f080397

.field public static ic_media_stop_dark:I = 0x7f080398

.field public static ic_media_stop_light:I = 0x7f080399

.field public static ic_mr_button_connected_00_dark:I = 0x7f0803ab

.field public static ic_mr_button_connected_00_light:I = 0x7f0803ac

.field public static ic_mr_button_connected_01_dark:I = 0x7f0803ad

.field public static ic_mr_button_connected_01_light:I = 0x7f0803ae

.field public static ic_mr_button_connected_02_dark:I = 0x7f0803af

.field public static ic_mr_button_connected_02_light:I = 0x7f0803b0

.field public static ic_mr_button_connected_03_dark:I = 0x7f0803b1

.field public static ic_mr_button_connected_03_light:I = 0x7f0803b2

.field public static ic_mr_button_connected_04_dark:I = 0x7f0803b3

.field public static ic_mr_button_connected_04_light:I = 0x7f0803b4

.field public static ic_mr_button_connected_05_dark:I = 0x7f0803b5

.field public static ic_mr_button_connected_05_light:I = 0x7f0803b6

.field public static ic_mr_button_connected_06_dark:I = 0x7f0803b7

.field public static ic_mr_button_connected_06_light:I = 0x7f0803b8

.field public static ic_mr_button_connected_07_dark:I = 0x7f0803b9

.field public static ic_mr_button_connected_07_light:I = 0x7f0803ba

.field public static ic_mr_button_connected_08_dark:I = 0x7f0803bb

.field public static ic_mr_button_connected_08_light:I = 0x7f0803bc

.field public static ic_mr_button_connected_09_dark:I = 0x7f0803bd

.field public static ic_mr_button_connected_09_light:I = 0x7f0803be

.field public static ic_mr_button_connected_10_dark:I = 0x7f0803bf

.field public static ic_mr_button_connected_10_light:I = 0x7f0803c0

.field public static ic_mr_button_connected_11_dark:I = 0x7f0803c1

.field public static ic_mr_button_connected_11_light:I = 0x7f0803c2

.field public static ic_mr_button_connected_12_dark:I = 0x7f0803c3

.field public static ic_mr_button_connected_12_light:I = 0x7f0803c4

.field public static ic_mr_button_connected_13_dark:I = 0x7f0803c5

.field public static ic_mr_button_connected_13_light:I = 0x7f0803c6

.field public static ic_mr_button_connected_14_dark:I = 0x7f0803c7

.field public static ic_mr_button_connected_14_light:I = 0x7f0803c8

.field public static ic_mr_button_connected_15_dark:I = 0x7f0803c9

.field public static ic_mr_button_connected_15_light:I = 0x7f0803ca

.field public static ic_mr_button_connected_16_dark:I = 0x7f0803cb

.field public static ic_mr_button_connected_16_light:I = 0x7f0803cc

.field public static ic_mr_button_connected_17_dark:I = 0x7f0803cd

.field public static ic_mr_button_connected_17_light:I = 0x7f0803ce

.field public static ic_mr_button_connected_18_dark:I = 0x7f0803cf

.field public static ic_mr_button_connected_18_light:I = 0x7f0803d0

.field public static ic_mr_button_connected_19_dark:I = 0x7f0803d1

.field public static ic_mr_button_connected_19_light:I = 0x7f0803d2

.field public static ic_mr_button_connected_20_dark:I = 0x7f0803d3

.field public static ic_mr_button_connected_20_light:I = 0x7f0803d4

.field public static ic_mr_button_connected_21_dark:I = 0x7f0803d5

.field public static ic_mr_button_connected_21_light:I = 0x7f0803d6

.field public static ic_mr_button_connected_22_dark:I = 0x7f0803d7

.field public static ic_mr_button_connected_22_light:I = 0x7f0803d8

.field public static ic_mr_button_connected_23_dark:I = 0x7f0803d9

.field public static ic_mr_button_connected_23_light:I = 0x7f0803da

.field public static ic_mr_button_connected_24_dark:I = 0x7f0803db

.field public static ic_mr_button_connected_24_light:I = 0x7f0803dc

.field public static ic_mr_button_connected_25_dark:I = 0x7f0803dd

.field public static ic_mr_button_connected_25_light:I = 0x7f0803de

.field public static ic_mr_button_connected_26_dark:I = 0x7f0803df

.field public static ic_mr_button_connected_26_light:I = 0x7f0803e0

.field public static ic_mr_button_connected_27_dark:I = 0x7f0803e1

.field public static ic_mr_button_connected_27_light:I = 0x7f0803e2

.field public static ic_mr_button_connected_28_dark:I = 0x7f0803e3

.field public static ic_mr_button_connected_28_light:I = 0x7f0803e4

.field public static ic_mr_button_connected_29_dark:I = 0x7f0803e5

.field public static ic_mr_button_connected_29_light:I = 0x7f0803e6

.field public static ic_mr_button_connected_30_dark:I = 0x7f0803e7

.field public static ic_mr_button_connected_30_light:I = 0x7f0803e8

.field public static ic_mr_button_connecting_00_dark:I = 0x7f0803e9

.field public static ic_mr_button_connecting_00_light:I = 0x7f0803ea

.field public static ic_mr_button_connecting_01_dark:I = 0x7f0803eb

.field public static ic_mr_button_connecting_01_light:I = 0x7f0803ec

.field public static ic_mr_button_connecting_02_dark:I = 0x7f0803ed

.field public static ic_mr_button_connecting_02_light:I = 0x7f0803ee

.field public static ic_mr_button_connecting_03_dark:I = 0x7f0803ef

.field public static ic_mr_button_connecting_03_light:I = 0x7f0803f0

.field public static ic_mr_button_connecting_04_dark:I = 0x7f0803f1

.field public static ic_mr_button_connecting_04_light:I = 0x7f0803f2

.field public static ic_mr_button_connecting_05_dark:I = 0x7f0803f3

.field public static ic_mr_button_connecting_05_light:I = 0x7f0803f4

.field public static ic_mr_button_connecting_06_dark:I = 0x7f0803f5

.field public static ic_mr_button_connecting_06_light:I = 0x7f0803f6

.field public static ic_mr_button_connecting_07_dark:I = 0x7f0803f7

.field public static ic_mr_button_connecting_07_light:I = 0x7f0803f8

.field public static ic_mr_button_connecting_08_dark:I = 0x7f0803f9

.field public static ic_mr_button_connecting_08_light:I = 0x7f0803fa

.field public static ic_mr_button_connecting_09_dark:I = 0x7f0803fb

.field public static ic_mr_button_connecting_09_light:I = 0x7f0803fc

.field public static ic_mr_button_connecting_10_dark:I = 0x7f0803fd

.field public static ic_mr_button_connecting_10_light:I = 0x7f0803fe

.field public static ic_mr_button_connecting_11_dark:I = 0x7f0803ff

.field public static ic_mr_button_connecting_11_light:I = 0x7f080400

.field public static ic_mr_button_connecting_12_dark:I = 0x7f080401

.field public static ic_mr_button_connecting_12_light:I = 0x7f080402

.field public static ic_mr_button_connecting_13_dark:I = 0x7f080403

.field public static ic_mr_button_connecting_13_light:I = 0x7f080404

.field public static ic_mr_button_connecting_14_dark:I = 0x7f080405

.field public static ic_mr_button_connecting_14_light:I = 0x7f080406

.field public static ic_mr_button_connecting_15_dark:I = 0x7f080407

.field public static ic_mr_button_connecting_15_light:I = 0x7f080408

.field public static ic_mr_button_connecting_16_dark:I = 0x7f080409

.field public static ic_mr_button_connecting_16_light:I = 0x7f08040a

.field public static ic_mr_button_connecting_17_dark:I = 0x7f08040b

.field public static ic_mr_button_connecting_17_light:I = 0x7f08040c

.field public static ic_mr_button_connecting_18_dark:I = 0x7f08040d

.field public static ic_mr_button_connecting_18_light:I = 0x7f08040e

.field public static ic_mr_button_connecting_19_dark:I = 0x7f08040f

.field public static ic_mr_button_connecting_19_light:I = 0x7f080410

.field public static ic_mr_button_connecting_20_dark:I = 0x7f080411

.field public static ic_mr_button_connecting_20_light:I = 0x7f080412

.field public static ic_mr_button_connecting_21_dark:I = 0x7f080413

.field public static ic_mr_button_connecting_21_light:I = 0x7f080414

.field public static ic_mr_button_connecting_22_dark:I = 0x7f080415

.field public static ic_mr_button_connecting_22_light:I = 0x7f080416

.field public static ic_mr_button_connecting_23_dark:I = 0x7f080417

.field public static ic_mr_button_connecting_23_light:I = 0x7f080418

.field public static ic_mr_button_connecting_24_dark:I = 0x7f080419

.field public static ic_mr_button_connecting_24_light:I = 0x7f08041a

.field public static ic_mr_button_connecting_25_dark:I = 0x7f08041b

.field public static ic_mr_button_connecting_25_light:I = 0x7f08041c

.field public static ic_mr_button_connecting_26_dark:I = 0x7f08041d

.field public static ic_mr_button_connecting_26_light:I = 0x7f08041e

.field public static ic_mr_button_connecting_27_dark:I = 0x7f08041f

.field public static ic_mr_button_connecting_27_light:I = 0x7f080420

.field public static ic_mr_button_connecting_28_dark:I = 0x7f080421

.field public static ic_mr_button_connecting_28_light:I = 0x7f080422

.field public static ic_mr_button_connecting_29_dark:I = 0x7f080423

.field public static ic_mr_button_connecting_29_light:I = 0x7f080424

.field public static ic_mr_button_connecting_30_dark:I = 0x7f080425

.field public static ic_mr_button_connecting_30_light:I = 0x7f080426

.field public static ic_mr_button_disabled_dark:I = 0x7f080427

.field public static ic_mr_button_disabled_light:I = 0x7f080428

.field public static ic_mr_button_disconnected_dark:I = 0x7f080429

.field public static ic_mr_button_disconnected_light:I = 0x7f08042a

.field public static ic_mr_button_grey:I = 0x7f08042b

.field public static ic_mr_wifi_icon_dark:I = 0x7f08042c

.field public static ic_mr_wifi_icon_light:I = 0x7f08042d

.field public static ic_mtrl_arrow_circle:I = 0x7f08042e

.field public static ic_mtrl_checked_circle:I = 0x7f08042f

.field public static ic_mtrl_chip_checked_black:I = 0x7f080430

.field public static ic_mtrl_chip_checked_circle:I = 0x7f080431

.field public static ic_mtrl_chip_close_circle:I = 0x7f080432

.field public static ic_search_black_24:I = 0x7f080462

.field public static ic_unchecked_checkbox:I = 0x7f080490

.field public static ic_vol_mute:I = 0x7f0804b3

.field public static ic_vol_type_speaker_dark:I = 0x7f0804b4

.field public static ic_vol_type_speaker_group_dark:I = 0x7f0804b5

.field public static ic_vol_type_speaker_group_light:I = 0x7f0804b6

.field public static ic_vol_type_speaker_light:I = 0x7f0804b7

.field public static ic_vol_type_tv_dark:I = 0x7f0804b8

.field public static ic_vol_type_tv_light:I = 0x7f0804b9

.field public static ic_vol_unmute:I = 0x7f0804ba

.field public static m3_avd_hide_password:I = 0x7f080538

.field public static m3_avd_show_password:I = 0x7f080539

.field public static m3_bottom_sheet_drag_handle:I = 0x7f08053a

.field public static m3_password_eye:I = 0x7f08053b

.field public static m3_popupmenu_background_overlay:I = 0x7f08053c

.field public static m3_radiobutton_ripple:I = 0x7f08053d

.field public static m3_selection_control_ripple:I = 0x7f08053e

.field public static m3_split_button_chevron_avd:I = 0x7f08053f

.field public static m3_tabs_background:I = 0x7f080540

.field public static m3_tabs_line_indicator:I = 0x7f080541

.field public static m3_tabs_rounded_line_indicator:I = 0x7f080542

.field public static m3_tabs_transparent_background:I = 0x7f080543

.field public static material_cursor_drawable:I = 0x7f080545

.field public static material_ic_calendar_black_24dp:I = 0x7f080546

.field public static material_ic_clear_black_24dp:I = 0x7f080547

.field public static material_ic_edit_black_24dp:I = 0x7f080548

.field public static material_ic_keyboard_arrow_left_black_24dp:I = 0x7f080549

.field public static material_ic_keyboard_arrow_next_black_24dp:I = 0x7f08054a

.field public static material_ic_keyboard_arrow_previous_black_24dp:I = 0x7f08054b

.field public static material_ic_keyboard_arrow_right_black_24dp:I = 0x7f08054c

.field public static material_ic_menu_arrow_down_black_24dp:I = 0x7f08054d

.field public static material_ic_menu_arrow_up_black_24dp:I = 0x7f08054e

.field public static media3_icon_album:I = 0x7f080550

.field public static media3_icon_artist:I = 0x7f080551

.field public static media3_icon_block:I = 0x7f080552

.field public static media3_icon_bookmark_filled:I = 0x7f080553

.field public static media3_icon_bookmark_unfilled:I = 0x7f080554

.field public static media3_icon_check_circle_filled:I = 0x7f080555

.field public static media3_icon_check_circle_unfilled:I = 0x7f080556

.field public static media3_icon_circular_play:I = 0x7f080557

.field public static media3_icon_closed_captions:I = 0x7f080558

.field public static media3_icon_closed_captions_off:I = 0x7f080559

.field public static media3_icon_fast_forward:I = 0x7f08055a

.field public static media3_icon_feed:I = 0x7f08055b

.field public static media3_icon_flag_filled:I = 0x7f08055c

.field public static media3_icon_flag_unfilled:I = 0x7f08055d

.field public static media3_icon_heart_filled:I = 0x7f08055e

.field public static media3_icon_heart_unfilled:I = 0x7f08055f

.field public static media3_icon_minus:I = 0x7f080560

.field public static media3_icon_minus_circle_filled:I = 0x7f080561

.field public static media3_icon_minus_circle_unfilled:I = 0x7f080562

.field public static media3_icon_next:I = 0x7f080563

.field public static media3_icon_pause:I = 0x7f080564

.field public static media3_icon_play:I = 0x7f080565

.field public static media3_icon_playback_speed:I = 0x7f080566

.field public static media3_icon_playback_speed_0_5:I = 0x7f080567

.field public static media3_icon_playback_speed_0_8:I = 0x7f080568

.field public static media3_icon_playback_speed_1_0:I = 0x7f080569

.field public static media3_icon_playback_speed_1_2:I = 0x7f08056a

.field public static media3_icon_playback_speed_1_5:I = 0x7f08056b

.field public static media3_icon_playback_speed_1_8:I = 0x7f08056c

.field public static media3_icon_playback_speed_2_0:I = 0x7f08056d

.field public static media3_icon_playlist_add:I = 0x7f08056e

.field public static media3_icon_playlist_remove:I = 0x7f08056f

.field public static media3_icon_plus:I = 0x7f080570

.field public static media3_icon_plus_circle_filled:I = 0x7f080571

.field public static media3_icon_plus_circle_unfilled:I = 0x7f080572

.field public static media3_icon_previous:I = 0x7f080573

.field public static media3_icon_quality:I = 0x7f080574

.field public static media3_icon_queue_add:I = 0x7f080575

.field public static media3_icon_queue_next:I = 0x7f080576

.field public static media3_icon_queue_remove:I = 0x7f080577

.field public static media3_icon_radio:I = 0x7f080578

.field public static media3_icon_repeat_all:I = 0x7f080579

.field public static media3_icon_repeat_off:I = 0x7f08057a

.field public static media3_icon_repeat_one:I = 0x7f08057b

.field public static media3_icon_rewind:I = 0x7f08057c

.field public static media3_icon_settings:I = 0x7f08057d

.field public static media3_icon_share:I = 0x7f08057e

.field public static media3_icon_shuffle_off:I = 0x7f08057f

.field public static media3_icon_shuffle_on:I = 0x7f080580

.field public static media3_icon_shuffle_star:I = 0x7f080581

.field public static media3_icon_signal:I = 0x7f080582

.field public static media3_icon_skip_back:I = 0x7f080583

.field public static media3_icon_skip_back_10:I = 0x7f080584

.field public static media3_icon_skip_back_15:I = 0x7f080585

.field public static media3_icon_skip_back_30:I = 0x7f080586

.field public static media3_icon_skip_back_5:I = 0x7f080587

.field public static media3_icon_skip_forward:I = 0x7f080588

.field public static media3_icon_skip_forward_10:I = 0x7f080589

.field public static media3_icon_skip_forward_15:I = 0x7f08058a

.field public static media3_icon_skip_forward_30:I = 0x7f08058b

.field public static media3_icon_skip_forward_5:I = 0x7f08058c

.field public static media3_icon_star_filled:I = 0x7f08058d

.field public static media3_icon_star_unfilled:I = 0x7f08058e

.field public static media3_icon_stop:I = 0x7f08058f

.field public static media3_icon_subtitles:I = 0x7f080590

.field public static media3_icon_subtitles_off:I = 0x7f080591

.field public static media3_icon_sync:I = 0x7f080592

.field public static media3_icon_thumb_down_filled:I = 0x7f080593

.field public static media3_icon_thumb_down_unfilled:I = 0x7f080594

.field public static media3_icon_thumb_up_filled:I = 0x7f080595

.field public static media3_icon_thumb_up_unfilled:I = 0x7f080596

.field public static media3_icon_volume_down:I = 0x7f080597

.field public static media3_icon_volume_off:I = 0x7f080598

.field public static media3_icon_volume_up:I = 0x7f080599

.field public static media3_notification_small_icon:I = 0x7f08059a

.field public static media_session_service_notification_ic_music_note:I = 0x7f08059b

.field public static mr_button_connected_dark:I = 0x7f0805a3

.field public static mr_button_connected_light:I = 0x7f0805a4

.field public static mr_button_connecting_dark:I = 0x7f0805a5

.field public static mr_button_connecting_light:I = 0x7f0805a6

.field public static mr_button_dark:I = 0x7f0805a7

.field public static mr_button_dark_static:I = 0x7f0805a8

.field public static mr_button_light:I = 0x7f0805a9

.field public static mr_button_light_static:I = 0x7f0805aa

.field public static mr_cast_checkbox:I = 0x7f0805ab

.field public static mr_cast_group_seekbar_track:I = 0x7f0805ac

.field public static mr_cast_mute_button:I = 0x7f0805ad

.field public static mr_cast_route_seekbar_track:I = 0x7f0805ae

.field public static mr_cast_stop:I = 0x7f0805af

.field public static mr_cast_thumb:I = 0x7f0805b0

.field public static mr_dialog_close_dark:I = 0x7f0805b1

.field public static mr_dialog_close_light:I = 0x7f0805b2

.field public static mr_dialog_material_background_dark:I = 0x7f0805b3

.field public static mr_dialog_material_background_light:I = 0x7f0805b4

.field public static mr_group_collapse:I = 0x7f0805b5

.field public static mr_group_expand:I = 0x7f0805b6

.field public static mr_media_pause_dark:I = 0x7f0805b7

.field public static mr_media_pause_light:I = 0x7f0805b8

.field public static mr_media_play_dark:I = 0x7f0805b9

.field public static mr_media_play_light:I = 0x7f0805ba

.field public static mr_media_stop_dark:I = 0x7f0805bb

.field public static mr_media_stop_light:I = 0x7f0805bc

.field public static mr_vol_type_audiotrack_dark:I = 0x7f0805bd

.field public static mr_vol_type_audiotrack_light:I = 0x7f0805be

.field public static mr_wifi_icon_dark:I = 0x7f0805bf

.field public static mr_wifi_icon_light:I = 0x7f0805c0

.field public static mtrl_bottomsheet_drag_handle:I = 0x7f0805c1

.field public static mtrl_checkbox_button:I = 0x7f0805c2

.field public static mtrl_checkbox_button_checked_unchecked:I = 0x7f0805c3

.field public static mtrl_checkbox_button_icon:I = 0x7f0805c4

.field public static mtrl_checkbox_button_icon_checked_indeterminate:I = 0x7f0805c5

.field public static mtrl_checkbox_button_icon_checked_unchecked:I = 0x7f0805c6

.field public static mtrl_checkbox_button_icon_indeterminate_checked:I = 0x7f0805c7

.field public static mtrl_checkbox_button_icon_indeterminate_unchecked:I = 0x7f0805c8

.field public static mtrl_checkbox_button_icon_unchecked_checked:I = 0x7f0805c9

.field public static mtrl_checkbox_button_icon_unchecked_indeterminate:I = 0x7f0805ca

.field public static mtrl_checkbox_button_unchecked_checked:I = 0x7f0805cb

.field public static mtrl_dialog_background:I = 0x7f0805cc

.field public static mtrl_dropdown_arrow:I = 0x7f0805cd

.field public static mtrl_ic_arrow_drop_down:I = 0x7f0805ce

.field public static mtrl_ic_arrow_drop_up:I = 0x7f0805cf

.field public static mtrl_ic_cancel:I = 0x7f0805d0

.field public static mtrl_ic_check_mark:I = 0x7f0805d1

.field public static mtrl_ic_checkbox_checked:I = 0x7f0805d2

.field public static mtrl_ic_checkbox_unchecked:I = 0x7f0805d3

.field public static mtrl_ic_error:I = 0x7f0805d4

.field public static mtrl_ic_indeterminate:I = 0x7f0805d5

.field public static mtrl_navigation_bar_item_background:I = 0x7f0805d6

.field public static mtrl_popupmenu_background:I = 0x7f0805d7

.field public static mtrl_popupmenu_background_overlay:I = 0x7f0805d8

.field public static mtrl_switch_thumb:I = 0x7f0805d9

.field public static mtrl_switch_thumb_checked:I = 0x7f0805da

.field public static mtrl_switch_thumb_checked_pressed:I = 0x7f0805db

.field public static mtrl_switch_thumb_checked_unchecked:I = 0x7f0805dc

.field public static mtrl_switch_thumb_pressed:I = 0x7f0805dd

.field public static mtrl_switch_thumb_pressed_checked:I = 0x7f0805de

.field public static mtrl_switch_thumb_pressed_unchecked:I = 0x7f0805df

.field public static mtrl_switch_thumb_unchecked:I = 0x7f0805e0

.field public static mtrl_switch_thumb_unchecked_checked:I = 0x7f0805e1

.field public static mtrl_switch_thumb_unchecked_pressed:I = 0x7f0805e2

.field public static mtrl_switch_track:I = 0x7f0805e3

.field public static mtrl_switch_track_decoration:I = 0x7f0805e4

.field public static mtrl_tabs_default_indicator:I = 0x7f0805e5

.field public static navigation_empty_icon:I = 0x7f0805ec

.field public static notification_action_background:I = 0x7f0805f1

.field public static notification_bg:I = 0x7f0805f3

.field public static notification_bg_low:I = 0x7f0805f4

.field public static notification_bg_low_normal:I = 0x7f0805f5

.field public static notification_bg_low_pressed:I = 0x7f0805f6

.field public static notification_bg_normal:I = 0x7f0805f7

.field public static notification_bg_normal_pressed:I = 0x7f0805f8

.field public static notification_icon_background:I = 0x7f0805f9

.field public static notification_oversize_large_icon_bg:I = 0x7f0805fa

.field public static notification_template_icon_bg:I = 0x7f0805fb

.field public static notification_template_icon_low_bg:I = 0x7f0805fc

.field public static notification_tile_bg:I = 0x7f0805fd

.field public static notify_panel_notification_icon_bg:I = 0x7f0805fe

.field public static quantum_ic_art_track_grey600_48:I = 0x7f080618

.field public static quantum_ic_bigtop_updates_white_24:I = 0x7f080619

.field public static quantum_ic_cast_connected_white_24:I = 0x7f08061a

.field public static quantum_ic_cast_white_36:I = 0x7f08061b

.field public static quantum_ic_clear_white_24:I = 0x7f08061c

.field public static quantum_ic_closed_caption_grey600_36:I = 0x7f08061d

.field public static quantum_ic_closed_caption_white_36:I = 0x7f08061e

.field public static quantum_ic_forward_10_white_24:I = 0x7f08061f

.field public static quantum_ic_forward_30_grey600_36:I = 0x7f080620

.field public static quantum_ic_forward_30_white_24:I = 0x7f080621

.field public static quantum_ic_forward_30_white_36:I = 0x7f080622

.field public static quantum_ic_keyboard_arrow_down_white_36:I = 0x7f080623

.field public static quantum_ic_pause_circle_filled_grey600_36:I = 0x7f080624

.field public static quantum_ic_pause_circle_filled_white_36:I = 0x7f080625

.field public static quantum_ic_pause_grey600_36:I = 0x7f080626

.field public static quantum_ic_pause_grey600_48:I = 0x7f080627

.field public static quantum_ic_pause_white_24:I = 0x7f080628

.field public static quantum_ic_play_arrow_grey600_36:I = 0x7f080629

.field public static quantum_ic_play_arrow_grey600_48:I = 0x7f08062a

.field public static quantum_ic_play_arrow_white_24:I = 0x7f08062b

.field public static quantum_ic_play_circle_filled_grey600_36:I = 0x7f08062c

.field public static quantum_ic_play_circle_filled_white_36:I = 0x7f08062d

.field public static quantum_ic_refresh_white_24:I = 0x7f08062e

.field public static quantum_ic_replay_10_white_24:I = 0x7f08062f

.field public static quantum_ic_replay_30_grey600_36:I = 0x7f080630

.field public static quantum_ic_replay_30_white_24:I = 0x7f080631

.field public static quantum_ic_replay_30_white_36:I = 0x7f080632

.field public static quantum_ic_replay_white_24:I = 0x7f080633

.field public static quantum_ic_skip_next_grey600_36:I = 0x7f080634

.field public static quantum_ic_skip_next_white_24:I = 0x7f080635

.field public static quantum_ic_skip_next_white_36:I = 0x7f080636

.field public static quantum_ic_skip_previous_grey600_36:I = 0x7f080637

.field public static quantum_ic_skip_previous_white_24:I = 0x7f080638

.field public static quantum_ic_skip_previous_white_36:I = 0x7f080639

.field public static quantum_ic_stop_grey600_36:I = 0x7f08063a

.field public static quantum_ic_stop_grey600_48:I = 0x7f08063b

.field public static quantum_ic_stop_white_24:I = 0x7f08063c

.field public static quantum_ic_volume_off_grey600_36:I = 0x7f08063d

.field public static quantum_ic_volume_off_white_36:I = 0x7f08063e

.field public static quantum_ic_volume_up_grey600_36:I = 0x7f08063f

.field public static quantum_ic_volume_up_white_36:I = 0x7f080640

.field public static test_level_drawable:I = 0x7f0806b1

.field public static tooltip_frame_dark:I = 0x7f0806c5

.field public static tooltip_frame_light:I = 0x7f0806c6

.field public static vdo_arrow_up:I = 0x7f0806d1

.field public static vdo_ic_about:I = 0x7f0806d2

.field public static vdo_ic_action_search_light:I = 0x7f0806d3

.field public static vdo_ic_baseline_delete_forever_24:I = 0x7f0806d4

.field public static vdo_ic_baseline_lock_24:I = 0x7f0806d5

.field public static vdo_ic_baseline_lock_open_24:I = 0x7f0806d6

.field public static vdo_ic_baseline_manage_search_24:I = 0x7f0806d7

.field public static vdo_ic_baseline_navigate_next_20:I = 0x7f0806d8

.field public static vdo_ic_baseline_replay_24:I = 0x7f0806d9

.field public static vdo_ic_captions:I = 0x7f0806da

.field public static vdo_ic_chapter_marker:I = 0x7f0806db

.field public static vdo_ic_chapters:I = 0x7f0806dc

.field public static vdo_ic_close:I = 0x7f0806dd

.field public static vdo_ic_download:I = 0x7f0806de

.field public static vdo_ic_download_done:I = 0x7f0806df

.field public static vdo_ic_error_white_36dp:I = 0x7f0806e0

.field public static vdo_ic_feedabck:I = 0x7f0806e1

.field public static vdo_ic_forward:I = 0x7f0806e2

.field public static vdo_ic_forward_10_white_24dp:I = 0x7f0806e3

.field public static vdo_ic_fullscreen:I = 0x7f0806e4

.field public static vdo_ic_fullscreen_exit_white_24dp:I = 0x7f0806e5

.field public static vdo_ic_fullscreen_exit_white_36dp:I = 0x7f0806e6

.field public static vdo_ic_high_quality_white_24dp:I = 0x7f0806e7

.field public static vdo_ic_outline_closed_caption_off_24:I = 0x7f0806e8

.field public static vdo_ic_outline_cloud_done_24:I = 0x7f0806e9

.field public static vdo_ic_outline_delete_forever_24:I = 0x7f0806ea

.field public static vdo_ic_outline_high_quality_24:I = 0x7f0806eb

.field public static vdo_ic_outline_save_offline_24:I = 0x7f0806ec

.field public static vdo_ic_outline_settings_24:I = 0x7f0806ed

.field public static vdo_ic_pause:I = 0x7f0806ee

.field public static vdo_ic_play:I = 0x7f0806ef

.field public static vdo_ic_player_chapter:I = 0x7f0806f0

.field public static vdo_ic_replay_10_white_24dp:I = 0x7f0806f1

.field public static vdo_ic_right:I = 0x7f0806f2

.field public static vdo_ic_video_speed:I = 0x7f0806f3

.field public static vdo_ic_volume:I = 0x7f0806f4

.field public static vdo_input_box_bg:I = 0x7f0806f5

.field public static vdo_logo_small:I = 0x7f0806f6

.field public static vdo_logo_thumb:I = 0x7f0806f7

.field public static vdo_media3_notification_pause:I = 0x7f0806f8

.field public static vdo_media3_notification_play:I = 0x7f0806f9

.field public static vdo_media3_notification_seek_to_previous:I = 0x7f0806fa

.field public static vdo_media3_notification_stop:I = 0x7f0806fb

.field public static vdo_red_circle_button:I = 0x7f0806fc

.field public static vdo_ripple:I = 0x7f0806fd

.field public static vdo_rounded_dialog:I = 0x7f0806fe

.field public static vdo_scrub_preview_background:I = 0x7f0806ff

.field public static vdo_white_circle_button:I = 0x7f080700


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
