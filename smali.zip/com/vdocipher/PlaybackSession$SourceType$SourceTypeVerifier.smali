# classes14.dex

.class final Lcom/vdocipher/PlaybackSession$SourceType$SourceTypeVerifier;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumVerifier;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$SourceType;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "SourceTypeVerifier"
.end annotation


# static fields
.field static final INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 174
    new-instance v0, Lcom/vdocipher/PlaybackSession$SourceType$SourceTypeVerifier;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$SourceType$SourceTypeVerifier;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackSession$SourceType$SourceTypeVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 172
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public isInRange(I)Z
    .registers 2

    .line 177
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$SourceType;->forNumber(I)Lcom/vdocipher/PlaybackSession$SourceType;

    move-result-object p1

    if-eqz p1, :cond_8

    const/4 p1, 0x1

    return p1

    :cond_8
    const/4 p1, 0x0

    return p1
.end method
