# classes14.dex

.class public final Lcom/vdocipher/Manifest$MPDTable$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$MPDTableOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest$MPDTable;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/Manifest$MPDTable;",
        "Lcom/vdocipher/Manifest$MPDTable$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$MPDTableOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 9441
    invoke-static {}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$MPDTable;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/Manifest-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public addAllPeriods(Ljava/lang/Iterable;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/Manifest$Period;",
            ">;)",
            "Lcom/vdocipher/Manifest$MPDTable$Builder;"
        }
    .end annotation

    .line 9921
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9922
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$maddAllPeriods(Lcom/vdocipher/Manifest$MPDTable;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addPeriods(ILcom/vdocipher/Manifest$Period$Builder;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 4

    .line 9911
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9912
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    .line 9913
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$Period$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$Period;

    .line 9912
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$maddPeriods(Lcom/vdocipher/Manifest$MPDTable;ILcom/vdocipher/Manifest$Period;)V

    return-object p0
.end method

.method public addPeriods(ILcom/vdocipher/Manifest$Period;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 4

    .line 9893
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9894
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$maddPeriods(Lcom/vdocipher/Manifest$MPDTable;ILcom/vdocipher/Manifest$Period;)V

    return-object p0
.end method

.method public addPeriods(Lcom/vdocipher/Manifest$Period$Builder;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9902
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9903
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$Period$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$Period;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$maddPeriods(Lcom/vdocipher/Manifest$MPDTable;Lcom/vdocipher/Manifest$Period;)V

    return-object p0
.end method

.method public addPeriods(Lcom/vdocipher/Manifest$Period;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9884
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9885
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$maddPeriods(Lcom/vdocipher/Manifest$MPDTable;Lcom/vdocipher/Manifest$Period;)V

    return-object p0
.end method

.method public clearMediaPresentationDuration()Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 2

    .line 9835
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9836
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$mclearMediaPresentationDuration(Lcom/vdocipher/Manifest$MPDTable;)V

    return-object p0
.end method

.method public clearMinBufferTime()Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 2

    .line 9761
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9762
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$mclearMinBufferTime(Lcom/vdocipher/Manifest$MPDTable;)V

    return-object p0
.end method

.method public clearPeriods()Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 2

    .line 9929
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9930
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$mclearPeriods(Lcom/vdocipher/Manifest$MPDTable;)V

    return-object p0
.end method

.method public clearProfiles()Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 2

    .line 9714
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9715
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$mclearProfiles(Lcom/vdocipher/Manifest$MPDTable;)V

    return-object p0
.end method

.method public clearType()Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 2

    .line 9807
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9808
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$mclearType(Lcom/vdocipher/Manifest$MPDTable;)V

    return-object p0
.end method

.method public clearXmlns()Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 2

    .line 9486
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9487
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$mclearXmlns(Lcom/vdocipher/Manifest$MPDTable;)V

    return-object p0
.end method

.method public clearXmlnsCenc()Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 2

    .line 9657
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9658
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$mclearXmlnsCenc(Lcom/vdocipher/Manifest$MPDTable;)V

    return-object p0
.end method

.method public clearXmlnsXsi()Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 2

    .line 9543
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9544
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$mclearXmlnsXsi(Lcom/vdocipher/Manifest$MPDTable;)V

    return-object p0
.end method

.method public clearXsiSchemaLocation()Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 2

    .line 9600
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9601
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$mclearXsiSchemaLocation(Lcom/vdocipher/Manifest$MPDTable;)V

    return-object p0
.end method

.method public getMediaPresentationDuration()F
    .registers 2

    .line 9818
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getMediaPresentationDuration()F

    move-result v0

    return v0
.end method

.method public getMinBufferTime()D
    .registers 3

    .line 9744
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getMinBufferTime()D

    move-result-wide v0

    return-wide v0
.end method

.method public getPeriods(I)Lcom/vdocipher/Manifest$Period;
    .registers 3

    .line 9859
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->getPeriods(I)Lcom/vdocipher/Manifest$Period;

    move-result-object p1

    return-object p1
.end method

.method public getPeriodsCount()I
    .registers 2

    .line 9853
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getPeriodsCount()I

    move-result v0

    return v0
.end method

.method public getPeriodsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$Period;",
            ">;"
        }
    .end annotation

    .line 9845
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    .line 9846
    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getPeriodsList()Ljava/util/List;

    move-result-object v0

    .line 9845
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getProfiles()Ljava/lang/String;
    .registers 2

    .line 9687
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getProfiles()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getProfilesBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9696
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getProfilesBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getType()Lcom/vdocipher/Manifest$MPDType;
    .registers 2

    .line 9790
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getType()Lcom/vdocipher/Manifest$MPDType;

    move-result-object v0

    return-object v0
.end method

.method public getTypeValue()I
    .registers 2

    .line 9772
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getTypeValue()I

    move-result v0

    return v0
.end method

.method public getXmlns()Ljava/lang/String;
    .registers 2

    .line 9459
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getXmlns()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getXmlnsBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9468
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getXmlnsBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getXmlnsCenc()Ljava/lang/String;
    .registers 2

    .line 9630
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getXmlnsCenc()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getXmlnsCencBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9639
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getXmlnsCencBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getXmlnsXsi()Ljava/lang/String;
    .registers 2

    .line 9516
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getXmlnsXsi()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getXmlnsXsiBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9525
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getXmlnsXsiBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getXsiSchemaLocation()Ljava/lang/String;
    .registers 2

    .line 9573
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getXsiSchemaLocation()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getXsiSchemaLocationBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 9582
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->getXsiSchemaLocationBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public hasMinBufferTime()Z
    .registers 2

    .line 9736
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->hasMinBufferTime()Z

    move-result v0

    return v0
.end method

.method public hasProfiles()Z
    .registers 2

    .line 9679
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->hasProfiles()Z

    move-result v0

    return v0
.end method

.method public hasXmlns()Z
    .registers 2

    .line 9451
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->hasXmlns()Z

    move-result v0

    return v0
.end method

.method public hasXmlnsCenc()Z
    .registers 2

    .line 9622
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->hasXmlnsCenc()Z

    move-result v0

    return v0
.end method

.method public hasXmlnsXsi()Z
    .registers 2

    .line 9508
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->hasXmlnsXsi()Z

    move-result v0

    return v0
.end method

.method public hasXsiSchemaLocation()Z
    .registers 2

    .line 9565
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$MPDTable;->hasXsiSchemaLocation()Z

    move-result v0

    return v0
.end method

.method public removePeriods(I)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9937
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9938
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$mremovePeriods(Lcom/vdocipher/Manifest$MPDTable;I)V

    return-object p0
.end method

.method public setMediaPresentationDuration(F)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9826
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9827
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetMediaPresentationDuration(Lcom/vdocipher/Manifest$MPDTable;F)V

    return-object p0
.end method

.method public setMinBufferTime(D)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 4

    .line 9752
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9753
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetMinBufferTime(Lcom/vdocipher/Manifest$MPDTable;D)V

    return-object p0
.end method

.method public setPeriods(ILcom/vdocipher/Manifest$Period$Builder;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 4

    .line 9875
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9876
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    .line 9877
    invoke-virtual {p2}, Lcom/vdocipher/Manifest$Period$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p2

    check-cast p2, Lcom/vdocipher/Manifest$Period;

    .line 9876
    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetPeriods(Lcom/vdocipher/Manifest$MPDTable;ILcom/vdocipher/Manifest$Period;)V

    return-object p0
.end method

.method public setPeriods(ILcom/vdocipher/Manifest$Period;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 4

    .line 9866
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9867
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetPeriods(Lcom/vdocipher/Manifest$MPDTable;ILcom/vdocipher/Manifest$Period;)V

    return-object p0
.end method

.method public setProfiles(Ljava/lang/String;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9705
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9706
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetProfiles(Lcom/vdocipher/Manifest$MPDTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setProfilesBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9725
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9726
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetProfilesBytes(Lcom/vdocipher/Manifest$MPDTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setType(Lcom/vdocipher/Manifest$MPDType;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9798
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9799
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetType(Lcom/vdocipher/Manifest$MPDTable;Lcom/vdocipher/Manifest$MPDType;)V

    return-object p0
.end method

.method public setTypeValue(I)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9780
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9781
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetTypeValue(Lcom/vdocipher/Manifest$MPDTable;I)V

    return-object p0
.end method

.method public setXmlns(Ljava/lang/String;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9477
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9478
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetXmlns(Lcom/vdocipher/Manifest$MPDTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setXmlnsBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9497
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9498
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetXmlnsBytes(Lcom/vdocipher/Manifest$MPDTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setXmlnsCenc(Ljava/lang/String;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9648
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9649
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetXmlnsCenc(Lcom/vdocipher/Manifest$MPDTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setXmlnsCencBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9668
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9669
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetXmlnsCencBytes(Lcom/vdocipher/Manifest$MPDTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setXmlnsXsi(Ljava/lang/String;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9534
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9535
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetXmlnsXsi(Lcom/vdocipher/Manifest$MPDTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setXmlnsXsiBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9554
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9555
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetXmlnsXsiBytes(Lcom/vdocipher/Manifest$MPDTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setXsiSchemaLocation(Ljava/lang/String;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9591
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9592
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetXsiSchemaLocation(Lcom/vdocipher/Manifest$MPDTable;Ljava/lang/String;)V

    return-object p0
.end method

.method public setXsiSchemaLocationBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$MPDTable$Builder;
    .registers 3

    .line 9611
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$MPDTable$Builder;->copyOnWrite()V

    .line 9612
    iget-object v0, p0, Lcom/vdocipher/Manifest$MPDTable$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$MPDTable;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$MPDTable;->-$$Nest$msetXsiSchemaLocationBytes(Lcom/vdocipher/Manifest$MPDTable;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
