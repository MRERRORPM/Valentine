# classes14.dex

.class public final enum Lcom/vdocipher/Manifest$CpSchemeIdUri;
.super Ljava/lang/Enum;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "CpSchemeIdUri"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$CpSchemeIdUri$CpSchemeIdUriVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/Manifest$CpSchemeIdUri;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/Manifest$CpSchemeIdUri;

.field public static final enum MP4_PROTECTION:Lcom/vdocipher/Manifest$CpSchemeIdUri;

.field public static final MP4_PROTECTION_VALUE:I = 0x0

.field public static final enum PLAY_READY:Lcom/vdocipher/Manifest$CpSchemeIdUri;

.field public static final PLAY_READY_VALUE:I = 0x2

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/Manifest$CpSchemeIdUri;

.field public static final enum WIDEVINE:Lcom/vdocipher/Manifest$CpSchemeIdUri;

.field public static final WIDEVINE_VALUE:I = 0x1

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/Manifest$CpSchemeIdUri;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 7

    .line 109
    new-instance v0, Lcom/vdocipher/Manifest$CpSchemeIdUri;

    const-string v1, "MP4_PROTECTION"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/Manifest$CpSchemeIdUri;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/Manifest$CpSchemeIdUri;->MP4_PROTECTION:Lcom/vdocipher/Manifest$CpSchemeIdUri;

    .line 113
    new-instance v1, Lcom/vdocipher/Manifest$CpSchemeIdUri;

    const-string v2, "WIDEVINE"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/Manifest$CpSchemeIdUri;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/Manifest$CpSchemeIdUri;->WIDEVINE:Lcom/vdocipher/Manifest$CpSchemeIdUri;

    .line 117
    new-instance v2, Lcom/vdocipher/Manifest$CpSchemeIdUri;

    const-string v3, "PLAY_READY"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4, v4}, Lcom/vdocipher/Manifest$CpSchemeIdUri;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/Manifest$CpSchemeIdUri;->PLAY_READY:Lcom/vdocipher/Manifest$CpSchemeIdUri;

    .line 118
    new-instance v3, Lcom/vdocipher/Manifest$CpSchemeIdUri;

    const/4 v4, 0x3

    const/4 v5, -0x1

    const-string v6, "UNRECOGNIZED"

    invoke-direct {v3, v6, v4, v5}, Lcom/vdocipher/Manifest$CpSchemeIdUri;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lcom/vdocipher/Manifest$CpSchemeIdUri;->UNRECOGNIZED:Lcom/vdocipher/Manifest$CpSchemeIdUri;

    .line 104
    filled-new-array {v0, v1, v2, v3}, [Lcom/vdocipher/Manifest$CpSchemeIdUri;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/Manifest$CpSchemeIdUri;->$VALUES:[Lcom/vdocipher/Manifest$CpSchemeIdUri;

    .line 168
    new-instance v0, Lcom/vdocipher/Manifest$CpSchemeIdUri$1;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$CpSchemeIdUri$1;-><init>()V

    sput-object v0, Lcom/vdocipher/Manifest$CpSchemeIdUri;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 192
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 193
    iput p3, p0, Lcom/vdocipher/Manifest$CpSchemeIdUri;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/Manifest$CpSchemeIdUri;
    .registers 2

    if-eqz p0, :cond_10

    const/4 v0, 0x1

    if-eq p0, v0, :cond_d

    const/4 v0, 0x2

    if-eq p0, v0, :cond_a

    const/4 p0, 0x0

    return-object p0

    .line 158
    :cond_a
    sget-object p0, Lcom/vdocipher/Manifest$CpSchemeIdUri;->PLAY_READY:Lcom/vdocipher/Manifest$CpSchemeIdUri;

    return-object p0

    .line 157
    :cond_d
    sget-object p0, Lcom/vdocipher/Manifest$CpSchemeIdUri;->WIDEVINE:Lcom/vdocipher/Manifest$CpSchemeIdUri;

    return-object p0

    .line 156
    :cond_10
    sget-object p0, Lcom/vdocipher/Manifest$CpSchemeIdUri;->MP4_PROTECTION:Lcom/vdocipher/Manifest$CpSchemeIdUri;

    return-object p0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/Manifest$CpSchemeIdUri;",
            ">;"
        }
    .end annotation

    .line 165
    sget-object v0, Lcom/vdocipher/Manifest$CpSchemeIdUri;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 178
    sget-object v0, Lcom/vdocipher/Manifest$CpSchemeIdUri$CpSchemeIdUriVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/Manifest$CpSchemeIdUri;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 151
    invoke-static {p0}, Lcom/vdocipher/Manifest$CpSchemeIdUri;->forNumber(I)Lcom/vdocipher/Manifest$CpSchemeIdUri;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/Manifest$CpSchemeIdUri;
    .registers 2

    .line 104
    const-class v0, Lcom/vdocipher/Manifest$CpSchemeIdUri;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$CpSchemeIdUri;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/Manifest$CpSchemeIdUri;
    .registers 1

    .line 104
    sget-object v0, Lcom/vdocipher/Manifest$CpSchemeIdUri;->$VALUES:[Lcom/vdocipher/Manifest$CpSchemeIdUri;

    invoke-virtual {v0}, [Lcom/vdocipher/Manifest$CpSchemeIdUri;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/Manifest$CpSchemeIdUri;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 137
    sget-object v0, Lcom/vdocipher/Manifest$CpSchemeIdUri;->UNRECOGNIZED:Lcom/vdocipher/Manifest$CpSchemeIdUri;

    if-eq p0, v0, :cond_7

    .line 141
    iget v0, p0, Lcom/vdocipher/Manifest$CpSchemeIdUri;->value:I

    return v0

    .line 138
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
