# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$PerfMetricsOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$PerfMetrics;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$PerfMetrics;",
        "Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$PerfMetricsOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 6576
    invoke-static {}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$PerfMetrics;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearAudioUnderrunRate()Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 2

    .line 6855
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6856
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$mclearAudioUnderrunRate(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-object p0
.end method

.method public clearDroppedFramesRate()Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 2

    .line 6883
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6884
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$mclearDroppedFramesRate(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-object p0
.end method

.method public clearJoinTime()Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 2

    .line 6687
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6688
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$mclearJoinTime(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-object p0
.end method

.method public clearLicenseLoadDuration()Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 2

    .line 6631
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6632
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$mclearLicenseLoadDuration(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-object p0
.end method

.method public clearMaxRebufferTime()Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 2

    .line 6799
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6800
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$mclearMaxRebufferTime(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-object p0
.end method

.method public clearMeanBandwidth()Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 2

    .line 6715
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6716
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$mclearMeanBandwidth(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-object p0
.end method

.method public clearMeanSeekTime()Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 2

    .line 6659
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6660
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$mclearMeanSeekTime(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-object p0
.end method

.method public clearMetaLoadDuration()Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 2

    .line 6603
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6604
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$mclearMetaLoadDuration(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-object p0
.end method

.method public clearRebufferCount()Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 2

    .line 6827
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6828
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$mclearRebufferCount(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-object p0
.end method

.method public clearRebufferRate()Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 2

    .line 6771
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6772
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$mclearRebufferRate(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-object p0
.end method

.method public clearRebufferTimeRatio()Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 2

    .line 6743
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6744
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$mclearRebufferTimeRatio(Lcom/vdocipher/PlaybackSession$PerfMetrics;)V

    return-object p0
.end method

.method public getAudioUnderrunRate()D
    .registers 3

    .line 6838
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->getAudioUnderrunRate()D

    move-result-wide v0

    return-wide v0
.end method

.method public getDroppedFramesRate()D
    .registers 3

    .line 6866
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->getDroppedFramesRate()D

    move-result-wide v0

    return-wide v0
.end method

.method public getJoinTime()I
    .registers 2

    .line 6670
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->getJoinTime()I

    move-result v0

    return v0
.end method

.method public getLicenseLoadDuration()I
    .registers 2

    .line 6614
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->getLicenseLoadDuration()I

    move-result v0

    return v0
.end method

.method public getMaxRebufferTime()I
    .registers 2

    .line 6782
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->getMaxRebufferTime()I

    move-result v0

    return v0
.end method

.method public getMeanBandwidth()D
    .registers 3

    .line 6698
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->getMeanBandwidth()D

    move-result-wide v0

    return-wide v0
.end method

.method public getMeanSeekTime()I
    .registers 2

    .line 6642
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->getMeanSeekTime()I

    move-result v0

    return v0
.end method

.method public getMetaLoadDuration()I
    .registers 2

    .line 6586
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->getMetaLoadDuration()I

    move-result v0

    return v0
.end method

.method public getRebufferCount()I
    .registers 2

    .line 6810
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->getRebufferCount()I

    move-result v0

    return v0
.end method

.method public getRebufferRate()D
    .registers 3

    .line 6754
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->getRebufferRate()D

    move-result-wide v0

    return-wide v0
.end method

.method public getRebufferTimeRatio()D
    .registers 3

    .line 6726
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->getRebufferTimeRatio()D

    move-result-wide v0

    return-wide v0
.end method

.method public setAudioUnderrunRate(D)Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 4

    .line 6846
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6847
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$msetAudioUnderrunRate(Lcom/vdocipher/PlaybackSession$PerfMetrics;D)V

    return-object p0
.end method

.method public setDroppedFramesRate(D)Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 4

    .line 6874
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6875
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$msetDroppedFramesRate(Lcom/vdocipher/PlaybackSession$PerfMetrics;D)V

    return-object p0
.end method

.method public setJoinTime(I)Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 3

    .line 6678
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6679
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$msetJoinTime(Lcom/vdocipher/PlaybackSession$PerfMetrics;I)V

    return-object p0
.end method

.method public setLicenseLoadDuration(I)Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 3

    .line 6622
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6623
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$msetLicenseLoadDuration(Lcom/vdocipher/PlaybackSession$PerfMetrics;I)V

    return-object p0
.end method

.method public setMaxRebufferTime(I)Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 3

    .line 6790
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6791
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$msetMaxRebufferTime(Lcom/vdocipher/PlaybackSession$PerfMetrics;I)V

    return-object p0
.end method

.method public setMeanBandwidth(D)Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 4

    .line 6706
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6707
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$msetMeanBandwidth(Lcom/vdocipher/PlaybackSession$PerfMetrics;D)V

    return-object p0
.end method

.method public setMeanSeekTime(I)Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 3

    .line 6650
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6651
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$msetMeanSeekTime(Lcom/vdocipher/PlaybackSession$PerfMetrics;I)V

    return-object p0
.end method

.method public setMetaLoadDuration(I)Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 3

    .line 6594
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6595
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$msetMetaLoadDuration(Lcom/vdocipher/PlaybackSession$PerfMetrics;I)V

    return-object p0
.end method

.method public setRebufferCount(I)Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 3

    .line 6818
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6819
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$msetRebufferCount(Lcom/vdocipher/PlaybackSession$PerfMetrics;I)V

    return-object p0
.end method

.method public setRebufferRate(D)Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 4

    .line 6762
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6763
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$msetRebufferRate(Lcom/vdocipher/PlaybackSession$PerfMetrics;D)V

    return-object p0
.end method

.method public setRebufferTimeRatio(D)Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;
    .registers 4

    .line 6734
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->copyOnWrite()V

    .line 6735
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$PerfMetrics$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$PerfMetrics;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackSession$PerfMetrics;->-$$Nest$msetRebufferTimeRatio(Lcom/vdocipher/PlaybackSession$PerfMetrics;D)V

    return-object p0
.end method
