# classes14.dex

.class public final Lcom/vdocipher/Manifest$SegmentTimeline;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$SegmentTimelineOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "SegmentTimeline"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$SegmentTimeline$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/Manifest$SegmentTimeline;",
        "Lcom/vdocipher/Manifest$SegmentTimeline$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$SegmentTimelineOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

.field public static final DURATION_FIELD_NUMBER:I = 0x1

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$SegmentTimeline;",
            ">;"
        }
    .end annotation
.end field

.field public static final REPEAT_FIELD_NUMBER:I = 0x2


# instance fields
.field private duration_:I

.field private repeat_:I


# direct methods
.method static bridge synthetic -$$Nest$mclearDuration(Lcom/vdocipher/Manifest$SegmentTimeline;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentTimeline;->clearDuration()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearRepeat(Lcom/vdocipher/Manifest$SegmentTimeline;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentTimeline;->clearRepeat()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDuration(Lcom/vdocipher/Manifest$SegmentTimeline;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentTimeline;->setDuration(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetRepeat(Lcom/vdocipher/Manifest$SegmentTimeline;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentTimeline;->setRepeat(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 1

    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 2777
    new-instance v0, Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$SegmentTimeline;-><init>()V

    .line 2780
    sput-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    .line 2781
    const-class v1, Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 2513
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    return-void
.end method

.method private clearDuration()V
    .registers 2

    const/4 v0, 0x0

    .line 2538
    iput v0, p0, Lcom/vdocipher/Manifest$SegmentTimeline;->duration_:I

    return-void
.end method

.method private clearRepeat()V
    .registers 2

    const/4 v0, 0x0

    .line 2564
    iput v0, p0, Lcom/vdocipher/Manifest$SegmentTimeline;->repeat_:I

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 1

    .line 2786
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/Manifest$SegmentTimeline$Builder;
    .registers 1

    .line 2644
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTimeline;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/Manifest$SegmentTimeline;)Lcom/vdocipher/Manifest$SegmentTimeline$Builder;
    .registers 2

    .line 2647
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-virtual {v0, p0}, Lcom/vdocipher/Manifest$SegmentTimeline;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2620
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0, p0}, Lcom/vdocipher/Manifest$SegmentTimeline;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTimeline;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2627
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/Manifest$SegmentTimeline;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTimeline;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2583
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTimeline;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2590
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTimeline;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2632
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTimeline;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2639
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTimeline;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2607
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTimeline;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 2614
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTimeline;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2570
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTimeline;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2577
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTimeline;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2595
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTimeline;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 2602
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTimeline;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$SegmentTimeline;",
            ">;"
        }
    .end annotation

    .line 2792
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTimeline;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setDuration(I)V
    .registers 2

    .line 2531
    iput p1, p0, Lcom/vdocipher/Manifest$SegmentTimeline;->duration_:I

    return-void
.end method

.method private setRepeat(I)V
    .registers 2

    .line 2557
    iput p1, p0, Lcom/vdocipher/Manifest$SegmentTimeline;->repeat_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 2727
    sget-object p2, Lcom/vdocipher/Manifest$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_54

    .line 2770
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 2764
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 2749
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/Manifest$SegmentTimeline;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 2751
    const-class p2, Lcom/vdocipher/Manifest$SegmentTimeline;

    monitor-enter p2

    .line 2752
    :try_start_20
    sget-object p1, Lcom/vdocipher/Manifest$SegmentTimeline;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 2754
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 2757
    sput-object p1, Lcom/vdocipher/Manifest$SegmentTimeline;->PARSER:Lcom/google/protobuf/Parser;

    .line 2759
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 2746
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    return-object p1

    .line 2735
    :pswitch_36  #0x3
    const-string p1, "duration_"

    const-string p2, "repeat_"

    filled-new-array {p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    .line 2739
    const-string p2, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u000b\u0002\u0004"

    .line 2742
    sget-object p3, Lcom/vdocipher/Manifest$SegmentTimeline;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/Manifest$SegmentTimeline;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 2732
    :pswitch_47  #0x2
    new-instance p1, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;-><init>(Lcom/vdocipher/Manifest-IA;)V

    return-object p1

    .line 2729
    :pswitch_4d  #0x1
    new-instance p1, Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-direct {p1}, Lcom/vdocipher/Manifest$SegmentTimeline;-><init>()V

    return-object p1

    nop

    :pswitch_data_54
    .packed-switch 0x1
        :pswitch_4d  #00000001
        :pswitch_47  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getDuration()I
    .registers 2

    .line 2523
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentTimeline;->duration_:I

    return v0
.end method

.method public getRepeat()I
    .registers 2

    .line 2549
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentTimeline;->repeat_:I

    return v0
.end method
