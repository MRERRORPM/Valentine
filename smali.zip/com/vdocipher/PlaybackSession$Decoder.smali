# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Decoder;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$DecoderOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Decoder"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$Decoder$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$Decoder;",
        "Lcom/vdocipher/PlaybackSession$Decoder$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$DecoderOrBuilder;"
    }
.end annotation


# static fields
.field public static final DECODERNAME_FIELD_NUMBER:I = 0x1

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Decoder;",
            ">;"
        }
    .end annotation
.end field

.field public static final SUPPORTEDTYPES_FIELD_NUMBER:I = 0x2


# instance fields
.field private decoderName_:Ljava/lang/String;

.field private supportedTypes_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$mclearDecoderName(Lcom/vdocipher/PlaybackSession$Decoder;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Decoder;->clearDecoderName()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSupportedTypes(Lcom/vdocipher/PlaybackSession$Decoder;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Decoder;->clearSupportedTypes()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDecoderName(Lcom/vdocipher/PlaybackSession$Decoder;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Decoder;->setDecoderName(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDecoderNameBytes(Lcom/vdocipher/PlaybackSession$Decoder;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Decoder;->setDecoderNameBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSupportedTypes(Lcom/vdocipher/PlaybackSession$Decoder;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Decoder;->setSupportedTypes(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSupportedTypesBytes(Lcom/vdocipher/PlaybackSession$Decoder;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Decoder;->setSupportedTypesBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 11451
    new-instance v0, Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$Decoder;-><init>()V

    .line 11454
    sput-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    .line 11455
    const-class v1, Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 11101
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 11102
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder;->decoderName_:Ljava/lang/String;

    .line 11103
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder;->supportedTypes_:Ljava/lang/String;

    return-void
.end method

.method private clearDecoderName()V
    .registers 2

    .line 11139
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Decoder;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Decoder;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Decoder;->getDecoderName()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder;->decoderName_:Ljava/lang/String;

    return-void
.end method

.method private clearSupportedTypes()V
    .registers 2

    .line 11186
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Decoder;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Decoder;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Decoder;->getSupportedTypes()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder;->supportedTypes_:Ljava/lang/String;

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 1

    .line 11460
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$Decoder$Builder;
    .registers 1

    .line 11276
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Decoder;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$Decoder$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$Decoder;)Lcom/vdocipher/PlaybackSession$Decoder$Builder;
    .registers 2

    .line 11279
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$Decoder;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Decoder$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11252
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$Decoder;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Decoder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11259
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$Decoder;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Decoder;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11215
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Decoder;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11222
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Decoder;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11264
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Decoder;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11271
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Decoder;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11239
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Decoder;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 11246
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Decoder;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11202
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Decoder;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11209
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Decoder;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11227
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Decoder;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Decoder;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 11234
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Decoder;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Decoder;",
            ">;"
        }
    .end annotation

    .line 11466
    sget-object v0, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Decoder;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setDecoderName(Ljava/lang/String;)V
    .registers 2

    .line 11130
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11132
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Decoder;->decoderName_:Ljava/lang/String;

    return-void
.end method

.method private setDecoderNameBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 11147
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Decoder;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 11148
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Decoder;->decoderName_:Ljava/lang/String;

    return-void
.end method

.method private setSupportedTypes(Ljava/lang/String;)V
    .registers 2

    .line 11177
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11179
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Decoder;->supportedTypes_:Ljava/lang/String;

    return-void
.end method

.method private setSupportedTypesBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 11194
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Decoder;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 11195
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Decoder;->supportedTypes_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 11401
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_54

    .line 11444
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 11438
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 11423
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$Decoder;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 11425
    const-class p2, Lcom/vdocipher/PlaybackSession$Decoder;

    monitor-enter p2

    .line 11426
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$Decoder;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 11428
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 11431
    sput-object p1, Lcom/vdocipher/PlaybackSession$Decoder;->PARSER:Lcom/google/protobuf/Parser;

    .line 11433
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 11420
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    return-object p1

    .line 11409
    :pswitch_36  #0x3
    const-string p1, "decoderName_"

    const-string/jumbo p2, "supportedTypes_"

    filled-new-array {p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    .line 11413
    const-string p2, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ"

    .line 11416
    sget-object p3, Lcom/vdocipher/PlaybackSession$Decoder;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$Decoder;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 11406
    :pswitch_48  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$Decoder$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$Decoder$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 11403
    :pswitch_4e  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$Decoder;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$Decoder;-><init>()V

    return-object p1

    :pswitch_data_54
    .packed-switch 0x1
        :pswitch_4e  #00000001
        :pswitch_48  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getDecoderName()Ljava/lang/String;
    .registers 2

    .line 11113
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder;->decoderName_:Ljava/lang/String;

    return-object v0
.end method

.method public getDecoderNameBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 11122
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder;->decoderName_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getSupportedTypes()Ljava/lang/String;
    .registers 2

    .line 11160
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder;->supportedTypes_:Ljava/lang/String;

    return-object v0
.end method

.method public getSupportedTypesBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 11169
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Decoder;->supportedTypes_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method
