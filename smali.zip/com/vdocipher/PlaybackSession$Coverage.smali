# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Coverage;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$CoverageOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Coverage"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$Coverage$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$Coverage;",
        "Lcom/vdocipher/PlaybackSession$Coverage$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$CoverageOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

.field public static final INDICES_FIELD_NUMBER:I = 0x1

.field public static final LENGTH_FIELD_NUMBER:I = 0x3

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Coverage;",
            ">;"
        }
    .end annotation
.end field

.field public static final VALUES_FIELD_NUMBER:I = 0x2


# instance fields
.field private indicesMemoizedSerializedSize:I

.field private indices_:Lcom/google/protobuf/Internal$IntList;

.field private length_:I

.field private valuesMemoizedSerializedSize:I

.field private values_:Lcom/google/protobuf/Internal$IntList;


# direct methods
.method static bridge synthetic -$$Nest$maddAllIndices(Lcom/vdocipher/PlaybackSession$Coverage;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Coverage;->addAllIndices(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllValues(Lcom/vdocipher/PlaybackSession$Coverage;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Coverage;->addAllValues(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddIndices(Lcom/vdocipher/PlaybackSession$Coverage;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Coverage;->addIndices(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddValues(Lcom/vdocipher/PlaybackSession$Coverage;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Coverage;->addValues(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearIndices(Lcom/vdocipher/PlaybackSession$Coverage;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Coverage;->clearIndices()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearLength(Lcom/vdocipher/PlaybackSession$Coverage;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Coverage;->clearLength()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearValues(Lcom/vdocipher/PlaybackSession$Coverage;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Coverage;->clearValues()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIndices(Lcom/vdocipher/PlaybackSession$Coverage;II)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackSession$Coverage;->setIndices(II)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetLength(Lcom/vdocipher/PlaybackSession$Coverage;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Coverage;->setLength(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetValues(Lcom/vdocipher/PlaybackSession$Coverage;II)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackSession$Coverage;->setValues(II)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 5642
    new-instance v0, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$Coverage;-><init>()V

    .line 5645
    sput-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    .line 5646
    const-class v1, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 5149
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    const/4 v0, -0x1

    .line 5181
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->indicesMemoizedSerializedSize:I

    .line 5252
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->valuesMemoizedSerializedSize:I

    .line 5150
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Coverage;->emptyIntList()Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->indices_:Lcom/google/protobuf/Internal$IntList;

    .line 5151
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Coverage;->emptyIntList()Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->values_:Lcom/google/protobuf/Internal$IntList;

    return-void
.end method

.method private addAllIndices(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .line 5213
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Coverage;->ensureIndicesIsMutable()V

    .line 5214
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->indices_:Lcom/google/protobuf/Internal$IntList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addAllValues(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .line 5284
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Coverage;->ensureValuesIsMutable()V

    .line 5285
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->values_:Lcom/google/protobuf/Internal$IntList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addIndices(I)V
    .registers 3

    .line 5204
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Coverage;->ensureIndicesIsMutable()V

    .line 5205
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->indices_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    return-void
.end method

.method private addValues(I)V
    .registers 3

    .line 5275
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Coverage;->ensureValuesIsMutable()V

    .line 5276
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->values_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    return-void
.end method

.method private clearIndices()V
    .registers 2

    .line 5221
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Coverage;->emptyIntList()Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->indices_:Lcom/google/protobuf/Internal$IntList;

    return-void
.end method

.method private clearLength()V
    .registers 2

    const/4 v0, 0x0

    .line 5318
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->length_:I

    return-void
.end method

.method private clearValues()V
    .registers 2

    .line 5292
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Coverage;->emptyIntList()Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->values_:Lcom/google/protobuf/Internal$IntList;

    return-void
.end method

.method private ensureIndicesIsMutable()V
    .registers 3

    .line 5183
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->indices_:Lcom/google/protobuf/Internal$IntList;

    .line 5184
    invoke-interface {v0}, Lcom/google/protobuf/Internal$IntList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 5186
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$IntList;)Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->indices_:Lcom/google/protobuf/Internal$IntList;

    :cond_e
    return-void
.end method

.method private ensureValuesIsMutable()V
    .registers 3

    .line 5254
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->values_:Lcom/google/protobuf/Internal$IntList;

    .line 5255
    invoke-interface {v0}, Lcom/google/protobuf/Internal$IntList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 5257
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$IntList;)Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->values_:Lcom/google/protobuf/Internal$IntList;

    :cond_e
    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 1

    .line 5651
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$Coverage$Builder;
    .registers 1

    .line 5398
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Coverage;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$Coverage;)Lcom/vdocipher/PlaybackSession$Coverage$Builder;
    .registers 2

    .line 5401
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$Coverage;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Coverage$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5374
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$Coverage;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Coverage;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5381
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$Coverage;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Coverage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5337
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Coverage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5344
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Coverage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5386
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Coverage;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5393
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Coverage;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5361
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Coverage;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5368
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Coverage;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5324
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Coverage;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5331
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Coverage;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5349
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Coverage;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Coverage;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5356
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Coverage;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Coverage;",
            ">;"
        }
    .end annotation

    .line 5657
    sget-object v0, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Coverage;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setIndices(II)V
    .registers 4

    .line 5196
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Coverage;->ensureIndicesIsMutable()V

    .line 5197
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->indices_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$IntList;->setInt(II)I

    return-void
.end method

.method private setLength(I)V
    .registers 2

    .line 5311
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Coverage;->length_:I

    return-void
.end method

.method private setValues(II)V
    .registers 4

    .line 5267
    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Coverage;->ensureValuesIsMutable()V

    .line 5268
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->values_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$IntList;->setInt(II)I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 5591
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_56

    .line 5635
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 5629
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 5614
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$Coverage;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 5616
    const-class p2, Lcom/vdocipher/PlaybackSession$Coverage;

    monitor-enter p2

    .line 5617
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$Coverage;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 5619
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 5622
    sput-object p1, Lcom/vdocipher/PlaybackSession$Coverage;->PARSER:Lcom/google/protobuf/Parser;

    .line 5624
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 5611
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    return-object p1

    .line 5599
    :pswitch_36  #0x3
    const-string p1, "indices_"

    const-string/jumbo p2, "values_"

    const-string p3, "length_"

    filled-new-array {p1, p2, p3}, [Ljava/lang/Object;

    move-result-object p1

    .line 5604
    const-string p2, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0002\u0000\u0001+\u0002+\u0003\u000b"

    .line 5607
    sget-object p3, Lcom/vdocipher/PlaybackSession$Coverage;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$Coverage;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 5596
    :pswitch_4a  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$Coverage$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$Coverage$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 5593
    :pswitch_50  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$Coverage;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$Coverage;-><init>()V

    return-object p1

    :pswitch_data_56
    .packed-switch 0x1
        :pswitch_50  #00000001
        :pswitch_4a  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getIndices(I)I
    .registers 3

    .line 5179
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->indices_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->getInt(I)I

    move-result p1

    return p1
.end method

.method public getIndicesCount()I
    .registers 2

    .line 5170
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->indices_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$IntList;->size()I

    move-result v0

    return v0
.end method

.method public getIndicesList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 5162
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->indices_:Lcom/google/protobuf/Internal$IntList;

    return-object v0
.end method

.method public getLength()I
    .registers 2

    .line 5303
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->length_:I

    return v0
.end method

.method public getValues(I)I
    .registers 3

    .line 5250
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->values_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->getInt(I)I

    move-result p1

    return p1
.end method

.method public getValuesCount()I
    .registers 2

    .line 5241
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->values_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$IntList;->size()I

    move-result v0

    return v0
.end method

.method public getValuesList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 5233
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Coverage;->values_:Lcom/google/protobuf/Internal$IntList;

    return-object v0
.end method
