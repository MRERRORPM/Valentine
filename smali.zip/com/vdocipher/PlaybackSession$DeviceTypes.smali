# classes14.dex

.class public final enum Lcom/vdocipher/PlaybackSession$DeviceTypes;
.super Ljava/lang/Enum;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "DeviceTypes"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$DeviceTypes$DeviceTypesVerifier;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/vdocipher/PlaybackSession$DeviceTypes;",
        ">;",
        "Lcom/google/protobuf/Internal$EnumLite;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/vdocipher/PlaybackSession$DeviceTypes;

.field public static final enum UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$DeviceTypes;

.field public static final enum android:Lcom/vdocipher/PlaybackSession$DeviceTypes;

.field public static final android_VALUE:I = 0x0

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$DeviceTypes;",
            ">;"
        }
    .end annotation
.end field

.field public static final enum ios:Lcom/vdocipher/PlaybackSession$DeviceTypes;

.field public static final ios_VALUE:I = 0x1

.field public static final enum web:Lcom/vdocipher/PlaybackSession$DeviceTypes;

.field public static final web_VALUE:I = 0x2


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .registers 7

    .line 198
    new-instance v0, Lcom/vdocipher/PlaybackSession$DeviceTypes;

    const-string v1, "android"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/vdocipher/PlaybackSession$DeviceTypes;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/vdocipher/PlaybackSession$DeviceTypes;->android:Lcom/vdocipher/PlaybackSession$DeviceTypes;

    .line 202
    new-instance v1, Lcom/vdocipher/PlaybackSession$DeviceTypes;

    const-string v2, "ios"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lcom/vdocipher/PlaybackSession$DeviceTypes;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/vdocipher/PlaybackSession$DeviceTypes;->ios:Lcom/vdocipher/PlaybackSession$DeviceTypes;

    .line 206
    new-instance v2, Lcom/vdocipher/PlaybackSession$DeviceTypes;

    const-string/jumbo v3, "web"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4, v4}, Lcom/vdocipher/PlaybackSession$DeviceTypes;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lcom/vdocipher/PlaybackSession$DeviceTypes;->web:Lcom/vdocipher/PlaybackSession$DeviceTypes;

    .line 207
    new-instance v3, Lcom/vdocipher/PlaybackSession$DeviceTypes;

    const/4 v4, 0x3

    const/4 v5, -0x1

    const-string v6, "UNRECOGNIZED"

    invoke-direct {v3, v6, v4, v5}, Lcom/vdocipher/PlaybackSession$DeviceTypes;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lcom/vdocipher/PlaybackSession$DeviceTypes;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$DeviceTypes;

    .line 193
    filled-new-array {v0, v1, v2, v3}, [Lcom/vdocipher/PlaybackSession$DeviceTypes;

    move-result-object v0

    sput-object v0, Lcom/vdocipher/PlaybackSession$DeviceTypes;->$VALUES:[Lcom/vdocipher/PlaybackSession$DeviceTypes;

    .line 257
    new-instance v0, Lcom/vdocipher/PlaybackSession$DeviceTypes$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$DeviceTypes$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackSession$DeviceTypes;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 281
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 282
    iput p3, p0, Lcom/vdocipher/PlaybackSession$DeviceTypes;->value:I

    return-void
.end method

.method public static forNumber(I)Lcom/vdocipher/PlaybackSession$DeviceTypes;
    .registers 2

    if-eqz p0, :cond_10

    const/4 v0, 0x1

    if-eq p0, v0, :cond_d

    const/4 v0, 0x2

    if-eq p0, v0, :cond_a

    const/4 p0, 0x0

    return-object p0

    .line 247
    :cond_a
    sget-object p0, Lcom/vdocipher/PlaybackSession$DeviceTypes;->web:Lcom/vdocipher/PlaybackSession$DeviceTypes;

    return-object p0

    .line 246
    :cond_d
    sget-object p0, Lcom/vdocipher/PlaybackSession$DeviceTypes;->ios:Lcom/vdocipher/PlaybackSession$DeviceTypes;

    return-object p0

    .line 245
    :cond_10
    sget-object p0, Lcom/vdocipher/PlaybackSession$DeviceTypes;->android:Lcom/vdocipher/PlaybackSession$DeviceTypes;

    return-object p0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/vdocipher/PlaybackSession$DeviceTypes;",
            ">;"
        }
    .end annotation

    .line 254
    sget-object v0, Lcom/vdocipher/PlaybackSession$DeviceTypes;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    return-object v0
.end method

.method public static internalGetVerifier()Lcom/google/protobuf/Internal$EnumVerifier;
    .registers 1

    .line 267
    sget-object v0, Lcom/vdocipher/PlaybackSession$DeviceTypes$DeviceTypesVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-object v0
.end method

.method public static valueOf(I)Lcom/vdocipher/PlaybackSession$DeviceTypes;
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 240
    invoke-static {p0}, Lcom/vdocipher/PlaybackSession$DeviceTypes;->forNumber(I)Lcom/vdocipher/PlaybackSession$DeviceTypes;

    move-result-object p0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$DeviceTypes;
    .registers 2

    .line 193
    const-class v0, Lcom/vdocipher/PlaybackSession$DeviceTypes;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$DeviceTypes;

    return-object p0
.end method

.method public static values()[Lcom/vdocipher/PlaybackSession$DeviceTypes;
    .registers 1

    .line 193
    sget-object v0, Lcom/vdocipher/PlaybackSession$DeviceTypes;->$VALUES:[Lcom/vdocipher/PlaybackSession$DeviceTypes;

    invoke-virtual {v0}, [Lcom/vdocipher/PlaybackSession$DeviceTypes;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/vdocipher/PlaybackSession$DeviceTypes;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 3

    .line 226
    sget-object v0, Lcom/vdocipher/PlaybackSession$DeviceTypes;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$DeviceTypes;

    if-eq p0, v0, :cond_7

    .line 230
    iget v0, p0, Lcom/vdocipher/PlaybackSession$DeviceTypes;->value:I

    return v0

    .line 227
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Can\'t get the number of an unknown enum value."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
