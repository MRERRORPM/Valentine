# classes14.dex

.class public interface abstract Lcom/vdocipher/Manifest$SegmentBaseOrBuilder;
.super Ljava/lang/Object;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "SegmentBaseOrBuilder"
.end annotation


# virtual methods
.method public abstract getIndexRangeEnd()I
.end method

.method public abstract getIndexRangeStart()I
.end method

.method public abstract getInitialization()Lcom/vdocipher/Manifest$Initialization;
.end method

.method public abstract getPresentationTimeOffset()I
.end method

.method public abstract getTimescale()I
.end method

.method public abstract hasInitialization()Z
.end method

.method public abstract hasPresentationTimeOffset()Z
.end method
