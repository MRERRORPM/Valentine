# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Media;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$MediaOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Media"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$Media$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$Media;",
        "Lcom/vdocipher/PlaybackSession$Media$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$MediaOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

.field public static final ID_FIELD_NUMBER:I = 0x1

.field private static volatile PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Media;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private id_:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$mclearId(Lcom/vdocipher/PlaybackSession$Media;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Media;->clearId()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetId(Lcom/vdocipher/PlaybackSession$Media;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Media;->setId(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIdBytes(Lcom/vdocipher/PlaybackSession$Media;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Media;->setIdBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Media;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 3484
    new-instance v0, Lcom/vdocipher/PlaybackSession$Media;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$Media;-><init>()V

    .line 3487
    sput-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    .line 3488
    const-class v1, Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 3233
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 3234
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Media;->id_:Ljava/lang/String;

    return-void
.end method

.method private clearId()V
    .registers 2

    .line 3270
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Media;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Media;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Media;->getId()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Media;->id_:Ljava/lang/String;

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$Media;
    .registers 1

    .line 3493
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$Media$Builder;
    .registers 1

    .line 3360
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Media;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$Media$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$Media;)Lcom/vdocipher/PlaybackSession$Media$Builder;
    .registers 2

    .line 3363
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$Media;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Media$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Media;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3336
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$Media;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Media;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Media;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3343
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$Media;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Media;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Media;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3299
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Media;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Media;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3306
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Media;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$Media;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3348
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Media;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Media;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3355
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Media;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Media;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3323
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Media;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Media;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3330
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Media;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$Media;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3286
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Media;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Media;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3293
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Media;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$Media;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3311
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Media;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Media;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3318
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Media;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Media;",
            ">;"
        }
    .end annotation

    .line 3499
    sget-object v0, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Media;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setId(Ljava/lang/String;)V
    .registers 2

    .line 3261
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3263
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Media;->id_:Ljava/lang/String;

    return-void
.end method

.method private setIdBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 3278
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Media;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 3279
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Media;->id_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 3436
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_52

    .line 3477
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 3471
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 3456
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$Media;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 3458
    const-class p2, Lcom/vdocipher/PlaybackSession$Media;

    monitor-enter p2

    .line 3459
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$Media;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 3461
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 3464
    sput-object p1, Lcom/vdocipher/PlaybackSession$Media;->PARSER:Lcom/google/protobuf/Parser;

    .line 3466
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 3453
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    return-object p1

    .line 3444
    :pswitch_36  #0x3
    const-string p1, "id_"

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    .line 3447
    const-string p2, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ"

    .line 3449
    sget-object p3, Lcom/vdocipher/PlaybackSession$Media;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Media;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$Media;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 3441
    :pswitch_45  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$Media$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$Media$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 3438
    :pswitch_4b  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$Media;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$Media;-><init>()V

    return-object p1

    nop

    :pswitch_data_52
    .packed-switch 0x1
        :pswitch_4b  #00000001
        :pswitch_45  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getId()Ljava/lang/String;
    .registers 2

    .line 3244
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Media;->id_:Ljava/lang/String;

    return-object v0
.end method

.method public getIdBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 3253
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Media;->id_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method
