# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackSession$PlaybackSessionTableOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "PlaybackSessionTableOrBuilder"
.end annotation


# virtual methods
.method public abstract getAndroid()Lcom/vdocipher/PlaybackSession$Android;
.end method

.method public abstract getBeats(I)Lcom/vdocipher/PlaybackSession$Beat;
.end method

.method public abstract getBeatsCount()I
.end method

.method public abstract getBeatsList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackSession$Beat;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getCaptionSearch()Lcom/vdocipher/PlaybackSession$CaptionSearch;
.end method

.method public abstract getCaptionSearchValue()I
.end method

.method public abstract getCoverage()Lcom/vdocipher/PlaybackSession$Coverage;
.end method

.method public abstract getDevice()Lcom/vdocipher/PlaybackSession$Device;
.end method

.method public abstract getDimensions()Lcom/vdocipher/PlaybackSession$Dimension;
.end method

.method public abstract getDownloadLocation()Ljava/lang/String;
.end method

.method public abstract getDownloadLocationBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getEmbedInfo()Lcom/vdocipher/PlaybackSession$EmbedInfo;
.end method

.method public abstract getError()Lcom/vdocipher/PlaybackSession$Error;
.end method

.method public abstract getEvents(I)Lcom/vdocipher/PlaybackSession$Event;
.end method

.method public abstract getEventsCount()I
.end method

.method public abstract getEventsList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackSession$Event;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getIsUIEnabled()Z
.end method

.method public abstract getMedia()Lcom/vdocipher/PlaybackSession$Media;
.end method

.method public abstract getNavigator()Ljava/lang/String;
.end method

.method public abstract getNavigatorBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getNavigatorProps()Lcom/vdocipher/PlaybackSession$NavigatorProps;
.end method

.method public abstract getPlatform()Ljava/lang/String;
.end method

.method public abstract getPlatformBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getPlayerPerf()Lcom/vdocipher/PlaybackSession$PerfMetrics;
.end method

.method public abstract getRefUrl()Ljava/lang/String;
.end method

.method public abstract getRefUrlBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getResumed()Lcom/vdocipher/PlaybackSession$PlaybackResume;
.end method

.method public abstract getSelectedTrack()Lcom/vdocipher/PlaybackSession$SelectedTrack;
.end method

.method public abstract getSession()Ljava/lang/String;
.end method

.method public abstract getSessionBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getSessionInitTime()Ljava/lang/String;
.end method

.method public abstract getSessionInitTimeBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getTech()Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;
.end method

.method public abstract getTechValue()I
.end method

.method public abstract getToolkit()Lcom/vdocipher/PlaybackSession$Toolkit;
.end method

.method public abstract getTrackCount()Lcom/vdocipher/PlaybackSession$TrackCount;
.end method

.method public abstract getViewer()Ljava/lang/String;
.end method

.method public abstract getViewerBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getWatermarkCount()I
.end method

.method public abstract getWidevineCDM()Lcom/vdocipher/PlaybackSession$WidevineCDM;
.end method

.method public abstract hasAndroid()Z
.end method

.method public abstract hasCoverage()Z
.end method

.method public abstract hasDevice()Z
.end method

.method public abstract hasDimensions()Z
.end method

.method public abstract hasEmbedInfo()Z
.end method

.method public abstract hasError()Z
.end method

.method public abstract hasMedia()Z
.end method

.method public abstract hasNavigatorProps()Z
.end method

.method public abstract hasPlayerPerf()Z
.end method

.method public abstract hasResumed()Z
.end method

.method public abstract hasSelectedTrack()Z
.end method

.method public abstract hasToolkit()Z
.end method

.method public abstract hasTrackCount()Z
.end method

.method public abstract hasWidevineCDM()Z
.end method
