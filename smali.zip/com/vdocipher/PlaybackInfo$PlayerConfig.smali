# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$PlayerConfig;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$PlayerConfigOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "PlayerConfig"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackInfo$PlayerConfig;",
        "Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$PlayerConfigOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

.field public static final ID_FIELD_NUMBER:I = 0x1

.field public static final OPTIONS_FIELD_NUMBER:I = 0x3

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$PlayerConfig;",
            ">;"
        }
    .end annotation
.end field

.field public static final THEME_FIELD_NUMBER:I = 0x2


# instance fields
.field private bitField0_:I

.field private id_:Lcom/google/protobuf/ByteString;

.field private options_:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

.field private theme_:Lcom/google/protobuf/ByteString;


# direct methods
.method static bridge synthetic -$$Nest$mclearId(Lcom/vdocipher/PlaybackInfo$PlayerConfig;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->clearId()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfig;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->clearOptions()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearTheme(Lcom/vdocipher/PlaybackInfo$PlayerConfig;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->clearTheme()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfig;Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->mergeOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetId(Lcom/vdocipher/PlaybackInfo$PlayerConfig;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->setId(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfig;Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->setOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTheme(Lcom/vdocipher/PlaybackInfo$PlayerConfig;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->setTheme(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 5847
    new-instance v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;-><init>()V

    .line 5850
    sput-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    .line 5851
    const-class v1, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 5483
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 5484
    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->id_:Lcom/google/protobuf/ByteString;

    .line 5485
    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->theme_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private clearId()V
    .registers 2

    .line 5512
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->getId()Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->id_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private clearOptions()V
    .registers 2

    const/4 v0, 0x0

    .line 5584
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->options_:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    .line 5585
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->bitField0_:I

    and-int/lit8 v0, v0, -0x2

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->bitField0_:I

    return-void
.end method

.method private clearTheme()V
    .registers 2

    .line 5539
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->getTheme()Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->theme_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 1

    .line 5856
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    return-object v0
.end method

.method private mergeOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 4

    .line 5571
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5572
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->options_:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    if-eqz v0, :cond_22

    .line 5573
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 5574
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->options_:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    .line 5575
    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->newBuilder(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->options_:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    goto :goto_24

    .line 5577
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->options_:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    .line 5579
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->bitField0_:I

    return-void
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;
    .registers 1

    .line 5665
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackInfo$PlayerConfig;)Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;
    .registers 2

    .line 5668
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5641
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5648
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5604
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5611
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5653
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5660
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5628
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5635
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5591
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5598
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5616
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$PlayerConfig;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5623
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$PlayerConfig;",
            ">;"
        }
    .end annotation

    .line 5862
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setId(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 5503
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5505
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->id_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private setOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 2

    .line 5562
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5563
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->options_:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    .line 5564
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->bitField0_:I

    return-void
.end method

.method private setTheme(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 5530
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5532
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->theme_:Lcom/google/protobuf/ByteString;

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 5795
    sget-object p2, Lcom/vdocipher/PlaybackInfo$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_58

    .line 5840
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 5834
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 5819
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 5821
    const-class p2, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    monitor-enter p2

    .line 5822
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 5824
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 5827
    sput-object p1, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->PARSER:Lcom/google/protobuf/Parser;

    .line 5829
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 5816
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    return-object p1

    .line 5803
    :pswitch_36  #0x3
    const-string p1, "bitField0_"

    const-string p2, "id_"

    const-string/jumbo p3, "theme_"

    const-string v0, "options_"

    filled-new-array {p1, p2, p3, v0}, [Ljava/lang/Object;

    move-result-object p1

    .line 5809
    const-string p2, "\u0000\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\n\u0002\n\u0003ဉ\u0000"

    .line 5812
    sget-object p3, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 5800
    :pswitch_4c  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackInfo$PlayerConfig$Builder;-><init>(Lcom/vdocipher/PlaybackInfo-IA;)V

    return-object p1

    .line 5797
    :pswitch_52  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackInfo$PlayerConfig;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfig;-><init>()V

    return-object p1

    :pswitch_data_58
    .packed-switch 0x1
        :pswitch_52  #00000001
        :pswitch_4c  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getId()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 5496
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->id_:Lcom/google/protobuf/ByteString;

    return-object v0
.end method

.method public getOptions()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 2

    .line 5556
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->options_:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getTheme()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 5523
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->theme_:Lcom/google/protobuf/ByteString;

    return-object v0
.end method

.method public hasOptions()Z
    .registers 3

    .line 5549
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfig;->bitField0_:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_7

    return v1

    :cond_7
    const/4 v0, 0x0

    return v0
.end method
