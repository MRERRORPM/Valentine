# classes14.dex

.class public final Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$SegmentTemplateOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest$SegmentTemplate;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/Manifest$SegmentTemplate;",
        "Lcom/vdocipher/Manifest$SegmentTemplate$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$SegmentTemplateOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 3209
    invoke-static {}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$SegmentTemplate;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/Manifest-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearDuration()Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 2

    .line 3409
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3410
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$mclearDuration(Lcom/vdocipher/Manifest$SegmentTemplate;)V

    return-object p0
.end method

.method public clearIndexRangeExact()Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 2

    .line 3465
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3466
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$mclearIndexRangeExact(Lcom/vdocipher/Manifest$SegmentTemplate;)V

    return-object p0
.end method

.method public clearInitialization()Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 2

    .line 3323
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3324
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$mclearInitialization(Lcom/vdocipher/Manifest$SegmentTemplate;)V

    return-object p0
.end method

.method public clearMedia()Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 2

    .line 3274
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3275
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$mclearMedia(Lcom/vdocipher/Manifest$SegmentTemplate;)V

    return-object p0
.end method

.method public clearPresentationTimeOffset()Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 2

    .line 3437
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3438
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$mclearPresentationTimeOffset(Lcom/vdocipher/Manifest$SegmentTemplate;)V

    return-object p0
.end method

.method public clearSegmentTimeline()Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 2

    .line 3381
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3382
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$mclearSegmentTimeline(Lcom/vdocipher/Manifest$SegmentTemplate;)V

    return-object p0
.end method

.method public clearTimescale()Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 2

    .line 3236
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3237
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$mclearTimescale(Lcom/vdocipher/Manifest$SegmentTemplate;)V

    return-object p0
.end method

.method public getDuration()I
    .registers 2

    .line 3392
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->getDuration()I

    move-result v0

    return v0
.end method

.method public getIndexRangeExact()Z
    .registers 2

    .line 3448
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->getIndexRangeExact()Z

    move-result v0

    return v0
.end method

.method public getInitialization()Ljava/lang/String;
    .registers 2

    .line 3296
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->getInitialization()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getInitializationBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 3305
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->getInitializationBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getMedia()Ljava/lang/String;
    .registers 2

    .line 3247
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->getMedia()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getMediaBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 3256
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->getMediaBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getPresentationTimeOffset()I
    .registers 2

    .line 3420
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->getPresentationTimeOffset()I

    move-result v0

    return v0
.end method

.method public getSegmentTimeline()Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 2

    .line 3351
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->getSegmentTimeline()Lcom/vdocipher/Manifest$SegmentTimeline;

    move-result-object v0

    return-object v0
.end method

.method public getTimescale()I
    .registers 2

    .line 3219
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->getTimescale()I

    move-result v0

    return v0
.end method

.method public hasSegmentTimeline()Z
    .registers 2

    .line 3344
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->hasSegmentTimeline()Z

    move-result v0

    return v0
.end method

.method public mergeSegmentTimeline(Lcom/vdocipher/Manifest$SegmentTimeline;)Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 3

    .line 3374
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3375
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$mmergeSegmentTimeline(Lcom/vdocipher/Manifest$SegmentTemplate;Lcom/vdocipher/Manifest$SegmentTimeline;)V

    return-object p0
.end method

.method public setDuration(I)Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 3

    .line 3400
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3401
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$msetDuration(Lcom/vdocipher/Manifest$SegmentTemplate;I)V

    return-object p0
.end method

.method public setIndexRangeExact(Z)Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 3

    .line 3456
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3457
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$msetIndexRangeExact(Lcom/vdocipher/Manifest$SegmentTemplate;Z)V

    return-object p0
.end method

.method public setInitialization(Ljava/lang/String;)Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 3

    .line 3314
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3315
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$msetInitialization(Lcom/vdocipher/Manifest$SegmentTemplate;Ljava/lang/String;)V

    return-object p0
.end method

.method public setInitializationBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 3

    .line 3334
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3335
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$msetInitializationBytes(Lcom/vdocipher/Manifest$SegmentTemplate;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setMedia(Ljava/lang/String;)Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 3

    .line 3265
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3266
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$msetMedia(Lcom/vdocipher/Manifest$SegmentTemplate;Ljava/lang/String;)V

    return-object p0
.end method

.method public setMediaBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 3

    .line 3285
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3286
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$msetMediaBytes(Lcom/vdocipher/Manifest$SegmentTemplate;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setPresentationTimeOffset(I)Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 3

    .line 3428
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3429
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$msetPresentationTimeOffset(Lcom/vdocipher/Manifest$SegmentTemplate;I)V

    return-object p0
.end method

.method public setSegmentTimeline(Lcom/vdocipher/Manifest$SegmentTimeline$Builder;)Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 3

    .line 3366
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3367
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;->build()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$SegmentTimeline;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$msetSegmentTimeline(Lcom/vdocipher/Manifest$SegmentTemplate;Lcom/vdocipher/Manifest$SegmentTimeline;)V

    return-object p0
.end method

.method public setSegmentTimeline(Lcom/vdocipher/Manifest$SegmentTimeline;)Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 3

    .line 3357
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3358
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$msetSegmentTimeline(Lcom/vdocipher/Manifest$SegmentTemplate;Lcom/vdocipher/Manifest$SegmentTimeline;)V

    return-object p0
.end method

.method public setTimescale(I)Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 3

    .line 3227
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->copyOnWrite()V

    .line 3228
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->-$$Nest$msetTimescale(Lcom/vdocipher/Manifest$SegmentTemplate;I)V

    return-object p0
.end method
