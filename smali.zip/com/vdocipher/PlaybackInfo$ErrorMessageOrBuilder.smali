# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackInfo$ErrorMessageOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "ErrorMessageOrBuilder"
.end annotation


# virtual methods
.method public abstract getCodes(I)I
.end method

.method public abstract getCodesCount()I
.end method

.method public abstract getCodesList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getMsgDefault()Ljava/lang/String;
.end method

.method public abstract getMsgDefaultBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getMsgKey()Ljava/lang/String;
.end method

.method public abstract getMsgKeyBytes()Lcom/google/protobuf/ByteString;
.end method
