# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Event;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$EventOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Event"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$Event$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$Event;",
        "Lcom/vdocipher/PlaybackSession$Event$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$EventOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

.field public static final NAME_FIELD_NUMBER:I = 0x1

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Event;",
            ">;"
        }
    .end annotation
.end field

.field public static final PAYLOAD_FIELD_NUMBER:I = 0x2

.field public static final TIME_FIELD_NUMBER:I = 0x3


# instance fields
.field private name_:I

.field private payload_:Ljava/lang/String;

.field private time_:I


# direct methods
.method static bridge synthetic -$$Nest$mclearName(Lcom/vdocipher/PlaybackSession$Event;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Event;->clearName()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPayload(Lcom/vdocipher/PlaybackSession$Event;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Event;->clearPayload()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearTime(Lcom/vdocipher/PlaybackSession$Event;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Event;->clearTime()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetName(Lcom/vdocipher/PlaybackSession$Event;Lcom/vdocipher/PlaybackSession$EventName;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Event;->setName(Lcom/vdocipher/PlaybackSession$EventName;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetNameValue(Lcom/vdocipher/PlaybackSession$Event;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Event;->setNameValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPayload(Lcom/vdocipher/PlaybackSession$Event;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Event;->setPayload(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPayloadBytes(Lcom/vdocipher/PlaybackSession$Event;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Event;->setPayloadBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTime(Lcom/vdocipher/PlaybackSession$Event;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Event;->setTime(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Event;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 6098
    new-instance v0, Lcom/vdocipher/PlaybackSession$Event;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$Event;-><init>()V

    .line 6101
    sput-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    .line 6102
    const-class v1, Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 5702
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 5703
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Event;->payload_:Ljava/lang/String;

    return-void
.end method

.method private clearName()V
    .registers 2

    const/4 v0, 0x0

    .line 5744
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Event;->name_:I

    return-void
.end method

.method private clearPayload()V
    .registers 2

    .line 5781
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Event;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Event;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Event;->getPayload()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Event;->payload_:Ljava/lang/String;

    return-void
.end method

.method private clearTime()V
    .registers 2

    const/4 v0, 0x0

    .line 5817
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Event;->time_:I

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$Event;
    .registers 1

    .line 6107
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$Event$Builder;
    .registers 1

    .line 5897
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Event;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$Event$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$Event;)Lcom/vdocipher/PlaybackSession$Event$Builder;
    .registers 2

    .line 5900
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$Event;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Event$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Event;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5873
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$Event;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Event;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Event;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5880
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$Event;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Event;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Event;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5836
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Event;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Event;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5843
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Event;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$Event;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5885
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Event;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Event;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5892
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Event;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Event;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5860
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Event;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Event;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 5867
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Event;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$Event;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5823
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Event;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Event;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5830
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Event;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$Event;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5848
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Event;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Event;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 5855
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Event;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Event;",
            ">;"
        }
    .end annotation

    .line 6113
    sget-object v0, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Event;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setName(Lcom/vdocipher/PlaybackSession$EventName;)V
    .registers 2

    .line 5736
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$EventName;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/PlaybackSession$Event;->name_:I

    return-void
.end method

.method private setNameValue(I)V
    .registers 2

    .line 5729
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Event;->name_:I

    return-void
.end method

.method private setPayload(Ljava/lang/String;)V
    .registers 2

    .line 5772
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5774
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Event;->payload_:Ljava/lang/String;

    return-void
.end method

.method private setPayloadBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 5789
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Event;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 5790
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Event;->payload_:Ljava/lang/String;

    return-void
.end method

.method private setTime(I)V
    .registers 2

    .line 5810
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Event;->time_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 6047
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_56

    .line 6091
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 6085
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 6070
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$Event;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 6072
    const-class p2, Lcom/vdocipher/PlaybackSession$Event;

    monitor-enter p2

    .line 6073
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$Event;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 6075
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 6078
    sput-object p1, Lcom/vdocipher/PlaybackSession$Event;->PARSER:Lcom/google/protobuf/Parser;

    .line 6080
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 6067
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    return-object p1

    .line 6055
    :pswitch_36  #0x3
    const-string p1, "name_"

    const-string p2, "payload_"

    const-string/jumbo p3, "time_"

    filled-new-array {p1, p2, p3}, [Ljava/lang/Object;

    move-result-object p1

    .line 6060
    const-string p2, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\f\u0002Ȉ\u0003\u000b"

    .line 6063
    sget-object p3, Lcom/vdocipher/PlaybackSession$Event;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Event;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$Event;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 6052
    :pswitch_4a  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$Event$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$Event$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 6049
    :pswitch_50  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$Event;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$Event;-><init>()V

    return-object p1

    :pswitch_data_56
    .packed-switch 0x1
        :pswitch_50  #00000001
        :pswitch_4a  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getName()Lcom/vdocipher/PlaybackSession$EventName;
    .registers 2

    .line 5721
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Event;->name_:I

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$EventName;->forNumber(I)Lcom/vdocipher/PlaybackSession$EventName;

    move-result-object v0

    if-nez v0, :cond_a

    .line 5722
    sget-object v0, Lcom/vdocipher/PlaybackSession$EventName;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$EventName;

    :cond_a
    return-object v0
.end method

.method public getNameValue()I
    .registers 2

    .line 5713
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Event;->name_:I

    return v0
.end method

.method public getPayload()Ljava/lang/String;
    .registers 2

    .line 5755
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Event;->payload_:Ljava/lang/String;

    return-object v0
.end method

.method public getPayloadBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 5764
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Event;->payload_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getTime()I
    .registers 2

    .line 5802
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Event;->time_:I

    return v0
.end method
