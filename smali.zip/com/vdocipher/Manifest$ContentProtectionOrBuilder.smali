# classes14.dex

.class public interface abstract Lcom/vdocipher/Manifest$ContentProtectionOrBuilder;
.super Ljava/lang/Object;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "ContentProtectionOrBuilder"
.end annotation


# virtual methods
.method public abstract getCencDefaultKid()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getPssh()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getSchemeIdUri()Lcom/vdocipher/Manifest$CpSchemeIdUri;
.end method

.method public abstract getSchemeIdUriValue()I
.end method

.method public abstract getValue()Lcom/vdocipher/Manifest$ContentProtectionValue;
.end method

.method public abstract getValueValue()I
.end method

.method public abstract hasCencDefaultKid()Z
.end method

.method public abstract hasPssh()Z
.end method

.method public abstract hasValue()Z
.end method
