# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$PlayerConfigOptionsOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "PlayerConfigOptions"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;",
        "Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$PlayerConfigOptionsOrBuilder;"
    }
.end annotation


# static fields
.field public static final CAPTIONGLOBALSTYLES_FIELD_NUMBER:I = 0x2a

.field public static final CAPTIONSCALEFACTOR_FIELD_NUMBER:I = 0x20

.field public static final COLLAPSEINSETTINGS_FIELD_NUMBER:I = 0x21

.field public static final CONFIRMBEFOREAUTORESUME_FIELD_NUMBER:I = 0x1f

.field public static final CONSERVEQUALITYACROSSSESSION_FIELD_NUMBER:I = 0x1c

.field public static final CONSERVESELECTEDCAPTIONLANGUAGE_FIELD_NUMBER:I = 0x1e

.field public static final CONSERVESPEEDACROSSSESSION_FIELD_NUMBER:I = 0x1d

.field public static final CONSERVEVOLUMEACROSSSESSION_FIELD_NUMBER:I = 0x1b

.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

.field public static final ENABLEABOUTPLAYER_FIELD_NUMBER:I = 0x22

.field public static final ENABLEAIRPLAY_FIELD_NUMBER:I = 0xc

.field public static final ENABLEAUTORESUMELOCAL_FIELD_NUMBER:I = 0x1a

.field public static final ENABLECAPTIONSEARCH_FIELD_NUMBER:I = 0x12

.field public static final ENABLECHAPTERS_FIELD_NUMBER:I = 0x26

.field public static final ENABLECHROMECAST_FIELD_NUMBER:I = 0xd

.field public static final ENABLEDOUBLETAPSKIP_FIELD_NUMBER:I = 0x17

.field public static final ENABLEKEYBOARDSHORTCUTS_FIELD_NUMBER:I = 0x19

.field public static final ENABLELOCKCONTROLS_FIELD_NUMBER:I = 0x14

.field public static final ENABLEPIP_FIELD_NUMBER:I = 0x11

.field public static final ENABLEREPORTBUG_FIELD_NUMBER:I = 0x23

.field public static final ENABLESAVEOFFLINE_FIELD_NUMBER:I = 0x18

.field public static final HIDECONTEXTMENU_FIELD_NUMBER:I = 0x15

.field public static final HIDECONTROLSONPAUSE_FIELD_NUMBER:I = 0xe

.field public static final INITIALDURATIONPOSITION_FIELD_NUMBER:I = 0x25

.field public static final INITIALPLAYBUTTONSHAPE_FIELD_NUMBER:I = 0x24

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;",
            ">;"
        }
    .end annotation
.end field

.field public static final PLAYBACKSPEEDOPTIONS_FIELD_NUMBER:I = 0xf

.field public static final PRIMARYCOLOR_FIELD_NUMBER:I = 0x1

.field public static final QUALITYTRACKLABELS_FIELD_NUMBER:I = 0x29

.field public static final SHOWBACKWARD_FIELD_NUMBER:I = 0xb

.field public static final SHOWCAPTIONSCONTROL_FIELD_NUMBER:I = 0x7

.field public static final SHOWCASTWHENDEVICEREADY_FIELD_NUMBER:I = 0x27

.field public static final SHOWCLEARSTORAGEOPTION_FIELD_NUMBER:I = 0x28

.field public static final SHOWFORWARD_FIELD_NUMBER:I = 0xa

.field public static final SHOWFULLSCREEN_FIELD_NUMBER:I = 0x8

.field public static final SHOWPLAYPAUSEBTN_FIELD_NUMBER:I = 0x3

.field public static final SHOWPROGRESSBAR_FIELD_NUMBER:I = 0x4

.field public static final SHOWQUALITYCONTROL_FIELD_NUMBER:I = 0x6

.field public static final SHOWREPLAYATEND_FIELD_NUMBER:I = 0x13

.field public static final SHOWSCRUBBINGPREVIEW_FIELD_NUMBER:I = 0x16

.field public static final SHOWSPEEDCONTROL_FIELD_NUMBER:I = 0x5

.field public static final SHOWTIMETEXT_FIELD_NUMBER:I = 0x2

.field public static final SHOWVOLUME_FIELD_NUMBER:I = 0x9

.field public static final SKIPDURATION_FIELD_NUMBER:I = 0x10

.field private static final collapseInSettings_converter_:Lcom/google/protobuf/Internal$ListAdapter$Converter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$ListAdapter$Converter<",
            "Ljava/lang/Integer;",
            "Lcom/vdocipher/PlaybackInfo$CollapseSettings;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private bitField0_:I

.field private captionGlobalStyles_:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

.field private captionScaleFactor_:I

.field private collapseInSettingsMemoizedSerializedSize:I

.field private collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

.field private confirmBeforeAutoResume_:Z

.field private conserveQualityAcrossSession_:Z

.field private conserveSelectedCaptionLanguage_:Z

.field private conserveSpeedAcrossSession_:Z

.field private conserveVolumeAcrossSession_:Z

.field private enableAboutPlayer_:Z

.field private enableAirPlay_:Z

.field private enableAutoResumeLocal_:Z

.field private enableCaptionSearch_:Z

.field private enableChapters_:Z

.field private enableChromecast_:Z

.field private enableDoubleTapSkip_:Z

.field private enableKeyboardShortcuts_:Z

.field private enableLockControls_:Z

.field private enablePiP_:Z

.field private enableReportBug_:Z

.field private enableSaveOffline_:Z

.field private hideContextMenu_:Z

.field private hideControlsOnPause_:Z

.field private initialDurationPosition_:I

.field private initialPlayButtonShape_:I

.field private playbackSpeedOptionsMemoizedSerializedSize:I

.field private playbackSpeedOptions_:Lcom/google/protobuf/Internal$DoubleList;

.field private primaryColor_:Lcom/google/protobuf/ByteString;

.field private qualityTrackLabels_:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

.field private showBackward_:Z

.field private showCaptionsControl_:Z

.field private showCastWhenDeviceReady_:Z

.field private showClearStorageOption_:Z

.field private showForward_:Z

.field private showFullScreen_:Z

.field private showPlayPauseBtn_:Z

.field private showProgressBar_:Z

.field private showQualityControl_:Z

.field private showReplayAtEnd_:Z

.field private showScrubbingPreview_:Z

.field private showSpeedControl_:Z

.field private showTimeText_:Z

.field private showVolume_:Z

.field private skipDuration_:I


# direct methods
.method static bridge synthetic -$$Nest$maddAllCollapseInSettings(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->addAllCollapseInSettings(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllCollapseInSettingsValue(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->addAllCollapseInSettingsValue(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddAllPlaybackSpeedOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Ljava/lang/Iterable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->addAllPlaybackSpeedOptions(Ljava/lang/Iterable;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddCollapseInSettings(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$CollapseSettings;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->addCollapseInSettings(Lcom/vdocipher/PlaybackInfo$CollapseSettings;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddCollapseInSettingsValue(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->addCollapseInSettingsValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$maddPlaybackSpeedOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;D)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->addPlaybackSpeedOptions(D)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearCaptionGlobalStyles(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearCaptionGlobalStyles()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearCaptionScaleFactor(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearCaptionScaleFactor()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearCollapseInSettings(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearCollapseInSettings()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearConfirmBeforeAutoResume(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearConfirmBeforeAutoResume()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearConserveQualityAcrossSession(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearConserveQualityAcrossSession()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearConserveSelectedCaptionLanguage(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearConserveSelectedCaptionLanguage()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearConserveSpeedAcrossSession(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearConserveSpeedAcrossSession()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearConserveVolumeAcrossSession(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearConserveVolumeAcrossSession()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEnableAboutPlayer(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearEnableAboutPlayer()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEnableAirPlay(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearEnableAirPlay()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEnableAutoResumeLocal(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearEnableAutoResumeLocal()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEnableCaptionSearch(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearEnableCaptionSearch()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEnableChapters(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearEnableChapters()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEnableChromecast(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearEnableChromecast()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEnableDoubleTapSkip(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearEnableDoubleTapSkip()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEnableKeyboardShortcuts(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearEnableKeyboardShortcuts()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEnableLockControls(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearEnableLockControls()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEnablePiP(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearEnablePiP()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEnableReportBug(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearEnableReportBug()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearEnableSaveOffline(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearEnableSaveOffline()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearHideContextMenu(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearHideContextMenu()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearHideControlsOnPause(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearHideControlsOnPause()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearInitialDurationPosition(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearInitialDurationPosition()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearInitialPlayButtonShape(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearInitialPlayButtonShape()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPlaybackSpeedOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearPlaybackSpeedOptions()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPrimaryColor(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearPrimaryColor()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearQualityTrackLabels(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearQualityTrackLabels()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearShowBackward(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearShowBackward()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearShowCaptionsControl(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearShowCaptionsControl()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearShowCastWhenDeviceReady(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearShowCastWhenDeviceReady()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearShowClearStorageOption(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearShowClearStorageOption()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearShowForward(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearShowForward()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearShowFullScreen(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearShowFullScreen()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearShowPlayPauseBtn(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearShowPlayPauseBtn()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearShowProgressBar(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearShowProgressBar()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearShowQualityControl(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearShowQualityControl()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearShowReplayAtEnd(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearShowReplayAtEnd()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearShowScrubbingPreview(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearShowScrubbingPreview()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearShowSpeedControl(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearShowSpeedControl()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearShowTimeText(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearShowTimeText()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearShowVolume(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearShowVolume()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSkipDuration(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->clearSkipDuration()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeCaptionGlobalStyles(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->mergeCaptionGlobalStyles(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeQualityTrackLabels(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->mergeQualityTrackLabels(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCaptionGlobalStyles(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setCaptionGlobalStyles(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCaptionScaleFactor(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setCaptionScaleFactor(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCollapseInSettings(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;ILcom/vdocipher/PlaybackInfo$CollapseSettings;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setCollapseInSettings(ILcom/vdocipher/PlaybackInfo$CollapseSettings;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetCollapseInSettingsValue(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;II)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setCollapseInSettingsValue(II)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetConfirmBeforeAutoResume(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setConfirmBeforeAutoResume(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetConserveQualityAcrossSession(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setConserveQualityAcrossSession(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetConserveSelectedCaptionLanguage(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setConserveSelectedCaptionLanguage(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetConserveSpeedAcrossSession(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setConserveSpeedAcrossSession(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetConserveVolumeAcrossSession(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setConserveVolumeAcrossSession(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnableAboutPlayer(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setEnableAboutPlayer(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnableAirPlay(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setEnableAirPlay(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnableAutoResumeLocal(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setEnableAutoResumeLocal(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnableCaptionSearch(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setEnableCaptionSearch(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnableChapters(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setEnableChapters(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnableChromecast(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setEnableChromecast(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnableDoubleTapSkip(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setEnableDoubleTapSkip(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnableKeyboardShortcuts(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setEnableKeyboardShortcuts(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnableLockControls(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setEnableLockControls(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnablePiP(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setEnablePiP(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnableReportBug(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setEnableReportBug(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetEnableSaveOffline(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setEnableSaveOffline(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetHideContextMenu(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setHideContextMenu(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetHideControlsOnPause(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setHideControlsOnPause(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetInitialDurationPosition(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$ElementPosition;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setInitialDurationPosition(Lcom/vdocipher/PlaybackInfo$ElementPosition;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetInitialDurationPositionValue(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setInitialDurationPositionValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetInitialPlayButtonShape(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$PlayButtonShape;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setInitialPlayButtonShape(Lcom/vdocipher/PlaybackInfo$PlayButtonShape;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetInitialPlayButtonShapeValue(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setInitialPlayButtonShapeValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPlaybackSpeedOptions(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;ID)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setPlaybackSpeedOptions(ID)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPrimaryColor(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setPrimaryColor(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetQualityTrackLabels(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setQualityTrackLabels(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetShowBackward(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setShowBackward(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetShowCaptionsControl(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setShowCaptionsControl(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetShowCastWhenDeviceReady(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setShowCastWhenDeviceReady(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetShowClearStorageOption(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setShowClearStorageOption(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetShowForward(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setShowForward(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetShowFullScreen(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setShowFullScreen(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetShowPlayPauseBtn(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setShowPlayPauseBtn(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetShowProgressBar(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setShowProgressBar(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetShowQualityControl(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setShowQualityControl(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetShowReplayAtEnd(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setShowReplayAtEnd(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetShowScrubbingPreview(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setShowScrubbingPreview(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetShowSpeedControl(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setShowSpeedControl(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetShowTimeText(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setShowTimeText(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetShowVolume(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setShowVolume(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSkipDuration(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->setSkipDuration(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 3414
    new-instance v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$1;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$1;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_converter_:Lcom/google/protobuf/Internal$ListAdapter$Converter;

    .line 5429
    new-instance v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;-><init>()V

    .line 5432
    sput-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    .line 5433
    const-class v1, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 2527
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    const/4 v0, -0x1

    .line 2926
    iput v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->playbackSpeedOptionsMemoizedSerializedSize:I

    .line 2528
    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->primaryColor_:Lcom/google/protobuf/ByteString;

    .line 2529
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->emptyDoubleList()Lcom/google/protobuf/Internal$DoubleList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->playbackSpeedOptions_:Lcom/google/protobuf/Internal$DoubleList;

    .line 2530
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->emptyIntList()Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

    return-void
.end method

.method private addAllCollapseInSettings(Ljava/lang/Iterable;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/vdocipher/PlaybackInfo$CollapseSettings;",
            ">;)V"
        }
    .end annotation

    .line 3502
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->ensureCollapseInSettingsIsMutable()V

    .line 3503
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_7
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1d

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    .line 3504
    iget-object v1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->getNumber()I

    move-result v0

    invoke-interface {v1, v0}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    goto :goto_7

    :cond_1d
    return-void
.end method

.method private addAllCollapseInSettingsValue(Ljava/lang/Iterable;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .line 3536
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->ensureCollapseInSettingsIsMutable()V

    .line 3537
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_7
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1d

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 3538
    iget-object v1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v1, v0}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    goto :goto_7

    :cond_1d
    return-void
.end method

.method private addAllPlaybackSpeedOptions(Ljava/lang/Iterable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Ljava/lang/Double;",
            ">;)V"
        }
    .end annotation

    .line 2958
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->ensurePlaybackSpeedOptionsIsMutable()V

    .line 2959
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->playbackSpeedOptions_:Lcom/google/protobuf/Internal$DoubleList;

    invoke-static {p1, v0}, Lcom/google/protobuf/AbstractMessageLite;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method private addCollapseInSettings(Lcom/vdocipher/PlaybackInfo$CollapseSettings;)V
    .registers 3

    .line 3492
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3493
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->ensureCollapseInSettingsIsMutable()V

    .line 3494
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->getNumber()I

    move-result p1

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    return-void
.end method

.method private addCollapseInSettingsValue(I)V
    .registers 3

    .line 3527
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->ensureCollapseInSettingsIsMutable()V

    .line 3528
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->addInt(I)V

    return-void
.end method

.method private addPlaybackSpeedOptions(D)V
    .registers 4

    .line 2949
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->ensurePlaybackSpeedOptionsIsMutable()V

    .line 2950
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->playbackSpeedOptions_:Lcom/google/protobuf/Internal$DoubleList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$DoubleList;->addDouble(D)V

    return-void
.end method

.method private clearCaptionGlobalStyles()V
    .registers 2

    const/4 v0, 0x0

    .line 3844
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->captionGlobalStyles_:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    .line 3845
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->bitField0_:I

    and-int/lit8 v0, v0, -0x3

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->bitField0_:I

    return-void
.end method

.method private clearCaptionScaleFactor()V
    .registers 2

    const/4 v0, 0x0

    .line 3408
    iput v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->captionScaleFactor_:I

    return-void
.end method

.method private clearCollapseInSettings()V
    .registers 2

    .line 3511
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->emptyIntList()Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

    return-void
.end method

.method private clearConfirmBeforeAutoResume()V
    .registers 2

    const/4 v0, 0x0

    .line 3382
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->confirmBeforeAutoResume_:Z

    return-void
.end method

.method private clearConserveQualityAcrossSession()V
    .registers 2

    const/4 v0, 0x0

    .line 3304
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->conserveQualityAcrossSession_:Z

    return-void
.end method

.method private clearConserveSelectedCaptionLanguage()V
    .registers 2

    const/4 v0, 0x0

    .line 3356
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->conserveSelectedCaptionLanguage_:Z

    return-void
.end method

.method private clearConserveSpeedAcrossSession()V
    .registers 2

    const/4 v0, 0x0

    .line 3330
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->conserveSpeedAcrossSession_:Z

    return-void
.end method

.method private clearConserveVolumeAcrossSession()V
    .registers 2

    const/4 v0, 0x0

    .line 3278
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->conserveVolumeAcrossSession_:Z

    return-void
.end method

.method private clearEnableAboutPlayer()V
    .registers 2

    const/4 v0, 0x0

    .line 3565
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableAboutPlayer_:Z

    return-void
.end method

.method private clearEnableAirPlay()V
    .registers 2

    const/4 v0, 0x0

    .line 2843
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableAirPlay_:Z

    return-void
.end method

.method private clearEnableAutoResumeLocal()V
    .registers 2

    const/4 v0, 0x0

    .line 3252
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableAutoResumeLocal_:Z

    return-void
.end method

.method private clearEnableCaptionSearch()V
    .registers 2

    const/4 v0, 0x0

    .line 3044
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableCaptionSearch_:Z

    return-void
.end method

.method private clearEnableChapters()V
    .registers 2

    const/4 v0, 0x0

    .line 3701
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableChapters_:Z

    return-void
.end method

.method private clearEnableChromecast()V
    .registers 2

    const/4 v0, 0x0

    .line 2869
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableChromecast_:Z

    return-void
.end method

.method private clearEnableDoubleTapSkip()V
    .registers 2

    const/4 v0, 0x0

    .line 3174
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableDoubleTapSkip_:Z

    return-void
.end method

.method private clearEnableKeyboardShortcuts()V
    .registers 2

    const/4 v0, 0x0

    .line 3226
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableKeyboardShortcuts_:Z

    return-void
.end method

.method private clearEnableLockControls()V
    .registers 2

    const/4 v0, 0x0

    .line 3096
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableLockControls_:Z

    return-void
.end method

.method private clearEnablePiP()V
    .registers 2

    const/4 v0, 0x0

    .line 3018
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enablePiP_:Z

    return-void
.end method

.method private clearEnableReportBug()V
    .registers 2

    const/4 v0, 0x0

    .line 3591
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableReportBug_:Z

    return-void
.end method

.method private clearEnableSaveOffline()V
    .registers 2

    const/4 v0, 0x0

    .line 3200
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableSaveOffline_:Z

    return-void
.end method

.method private clearHideContextMenu()V
    .registers 2

    const/4 v0, 0x0

    .line 3122
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->hideContextMenu_:Z

    return-void
.end method

.method private clearHideControlsOnPause()V
    .registers 2

    const/4 v0, 0x0

    .line 2895
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->hideControlsOnPause_:Z

    return-void
.end method

.method private clearInitialDurationPosition()V
    .registers 2

    const/4 v0, 0x0

    .line 3675
    iput v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->initialDurationPosition_:I

    return-void
.end method

.method private clearInitialPlayButtonShape()V
    .registers 2

    const/4 v0, 0x0

    .line 3633
    iput v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->initialPlayButtonShape_:I

    return-void
.end method

.method private clearPlaybackSpeedOptions()V
    .registers 2

    .line 2966
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->emptyDoubleList()Lcom/google/protobuf/Internal$DoubleList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->playbackSpeedOptions_:Lcom/google/protobuf/Internal$DoubleList;

    return-void
.end method

.method private clearPrimaryColor()V
    .registers 2

    .line 2557
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getPrimaryColor()Lcom/google/protobuf/ByteString;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->primaryColor_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private clearQualityTrackLabels()V
    .registers 2

    const/4 v0, 0x0

    .line 3798
    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->qualityTrackLabels_:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    .line 3799
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->bitField0_:I

    and-int/lit8 v0, v0, -0x2

    iput v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->bitField0_:I

    return-void
.end method

.method private clearShowBackward()V
    .registers 2

    const/4 v0, 0x0

    .line 2817
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showBackward_:Z

    return-void
.end method

.method private clearShowCaptionsControl()V
    .registers 2

    const/4 v0, 0x0

    .line 2713
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showCaptionsControl_:Z

    return-void
.end method

.method private clearShowCastWhenDeviceReady()V
    .registers 2

    const/4 v0, 0x0

    .line 3727
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showCastWhenDeviceReady_:Z

    return-void
.end method

.method private clearShowClearStorageOption()V
    .registers 2

    const/4 v0, 0x0

    .line 3753
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showClearStorageOption_:Z

    return-void
.end method

.method private clearShowForward()V
    .registers 2

    const/4 v0, 0x0

    .line 2791
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showForward_:Z

    return-void
.end method

.method private clearShowFullScreen()V
    .registers 2

    const/4 v0, 0x0

    .line 2739
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showFullScreen_:Z

    return-void
.end method

.method private clearShowPlayPauseBtn()V
    .registers 2

    const/4 v0, 0x0

    .line 2609
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showPlayPauseBtn_:Z

    return-void
.end method

.method private clearShowProgressBar()V
    .registers 2

    const/4 v0, 0x0

    .line 2635
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showProgressBar_:Z

    return-void
.end method

.method private clearShowQualityControl()V
    .registers 2

    const/4 v0, 0x0

    .line 2687
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showQualityControl_:Z

    return-void
.end method

.method private clearShowReplayAtEnd()V
    .registers 2

    const/4 v0, 0x0

    .line 3070
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showReplayAtEnd_:Z

    return-void
.end method

.method private clearShowScrubbingPreview()V
    .registers 2

    const/4 v0, 0x0

    .line 3148
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showScrubbingPreview_:Z

    return-void
.end method

.method private clearShowSpeedControl()V
    .registers 2

    const/4 v0, 0x0

    .line 2661
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showSpeedControl_:Z

    return-void
.end method

.method private clearShowTimeText()V
    .registers 2

    const/4 v0, 0x0

    .line 2583
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showTimeText_:Z

    return-void
.end method

.method private clearShowVolume()V
    .registers 2

    const/4 v0, 0x0

    .line 2765
    iput-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showVolume_:Z

    return-void
.end method

.method private clearSkipDuration()V
    .registers 2

    const/4 v0, 0x0

    .line 2992
    iput v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->skipDuration_:I

    return-void
.end method

.method private ensureCollapseInSettingsIsMutable()V
    .registers 3

    .line 3470
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

    .line 3471
    invoke-interface {v0}, Lcom/google/protobuf/Internal$IntList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 3473
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$IntList;)Lcom/google/protobuf/Internal$IntList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

    :cond_e
    return-void
.end method

.method private ensurePlaybackSpeedOptionsIsMutable()V
    .registers 3

    .line 2928
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->playbackSpeedOptions_:Lcom/google/protobuf/Internal$DoubleList;

    .line 2929
    invoke-interface {v0}, Lcom/google/protobuf/Internal$DoubleList;->isModifiable()Z

    move-result v1

    if-nez v1, :cond_e

    .line 2931
    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite;->mutableCopy(Lcom/google/protobuf/Internal$DoubleList;)Lcom/google/protobuf/Internal$DoubleList;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->playbackSpeedOptions_:Lcom/google/protobuf/Internal$DoubleList;

    :cond_e
    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 1

    .line 5438
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    return-object v0
.end method

.method private mergeCaptionGlobalStyles(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V
    .registers 4

    .line 3831
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3832
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->captionGlobalStyles_:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    if-eqz v0, :cond_22

    .line 3833
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 3834
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->captionGlobalStyles_:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    .line 3835
    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->newBuilder(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->captionGlobalStyles_:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    goto :goto_24

    .line 3837
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->captionGlobalStyles_:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    .line 3839
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->bitField0_:I

    or-int/lit8 p1, p1, 0x2

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->bitField0_:I

    return-void
.end method

.method private mergeQualityTrackLabels(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)V
    .registers 4

    .line 3785
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3786
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->qualityTrackLabels_:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    if-eqz v0, :cond_22

    .line 3787
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 3788
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->qualityTrackLabels_:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    .line 3789
    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->newBuilder(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->qualityTrackLabels_:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    goto :goto_24

    .line 3791
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->qualityTrackLabels_:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    .line 3793
    :goto_24
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->bitField0_:I

    return-void
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 1

    .line 3925
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;
    .registers 2

    .line 3928
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3901
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3908
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3864
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3871
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3913
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3920
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3888
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3895
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3851
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3858
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3876
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3883
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;",
            ">;"
        }
    .end annotation

    .line 5444
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setCaptionGlobalStyles(Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;)V
    .registers 2

    .line 3822
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3823
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->captionGlobalStyles_:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    .line 3824
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->bitField0_:I

    or-int/lit8 p1, p1, 0x2

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->bitField0_:I

    return-void
.end method

.method private setCaptionScaleFactor(I)V
    .registers 2

    .line 3401
    iput p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->captionScaleFactor_:I

    return-void
.end method

.method private setCollapseInSettings(ILcom/vdocipher/PlaybackInfo$CollapseSettings;)V
    .registers 4

    .line 3483
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3484
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->ensureCollapseInSettingsIsMutable()V

    .line 3485
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

    invoke-virtual {p2}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->getNumber()I

    move-result p2

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$IntList;->setInt(II)I

    return-void
.end method

.method private setCollapseInSettingsValue(II)V
    .registers 4

    .line 3519
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->ensureCollapseInSettingsIsMutable()V

    .line 3520
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1, p2}, Lcom/google/protobuf/Internal$IntList;->setInt(II)I

    return-void
.end method

.method private setConfirmBeforeAutoResume(Z)V
    .registers 2

    .line 3375
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->confirmBeforeAutoResume_:Z

    return-void
.end method

.method private setConserveQualityAcrossSession(Z)V
    .registers 2

    .line 3297
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->conserveQualityAcrossSession_:Z

    return-void
.end method

.method private setConserveSelectedCaptionLanguage(Z)V
    .registers 2

    .line 3349
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->conserveSelectedCaptionLanguage_:Z

    return-void
.end method

.method private setConserveSpeedAcrossSession(Z)V
    .registers 2

    .line 3323
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->conserveSpeedAcrossSession_:Z

    return-void
.end method

.method private setConserveVolumeAcrossSession(Z)V
    .registers 2

    .line 3271
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->conserveVolumeAcrossSession_:Z

    return-void
.end method

.method private setEnableAboutPlayer(Z)V
    .registers 2

    .line 3558
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableAboutPlayer_:Z

    return-void
.end method

.method private setEnableAirPlay(Z)V
    .registers 2

    .line 2836
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableAirPlay_:Z

    return-void
.end method

.method private setEnableAutoResumeLocal(Z)V
    .registers 2

    .line 3245
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableAutoResumeLocal_:Z

    return-void
.end method

.method private setEnableCaptionSearch(Z)V
    .registers 2

    .line 3037
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableCaptionSearch_:Z

    return-void
.end method

.method private setEnableChapters(Z)V
    .registers 2

    .line 3694
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableChapters_:Z

    return-void
.end method

.method private setEnableChromecast(Z)V
    .registers 2

    .line 2862
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableChromecast_:Z

    return-void
.end method

.method private setEnableDoubleTapSkip(Z)V
    .registers 2

    .line 3167
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableDoubleTapSkip_:Z

    return-void
.end method

.method private setEnableKeyboardShortcuts(Z)V
    .registers 2

    .line 3219
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableKeyboardShortcuts_:Z

    return-void
.end method

.method private setEnableLockControls(Z)V
    .registers 2

    .line 3089
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableLockControls_:Z

    return-void
.end method

.method private setEnablePiP(Z)V
    .registers 2

    .line 3011
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enablePiP_:Z

    return-void
.end method

.method private setEnableReportBug(Z)V
    .registers 2

    .line 3584
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableReportBug_:Z

    return-void
.end method

.method private setEnableSaveOffline(Z)V
    .registers 2

    .line 3193
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableSaveOffline_:Z

    return-void
.end method

.method private setHideContextMenu(Z)V
    .registers 2

    .line 3115
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->hideContextMenu_:Z

    return-void
.end method

.method private setHideControlsOnPause(Z)V
    .registers 2

    .line 2888
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->hideControlsOnPause_:Z

    return-void
.end method

.method private setInitialDurationPosition(Lcom/vdocipher/PlaybackInfo$ElementPosition;)V
    .registers 2

    .line 3667
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$ElementPosition;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->initialDurationPosition_:I

    return-void
.end method

.method private setInitialDurationPositionValue(I)V
    .registers 2

    .line 3660
    iput p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->initialDurationPosition_:I

    return-void
.end method

.method private setInitialPlayButtonShape(Lcom/vdocipher/PlaybackInfo$PlayButtonShape;)V
    .registers 2

    .line 3625
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->initialPlayButtonShape_:I

    return-void
.end method

.method private setInitialPlayButtonShapeValue(I)V
    .registers 2

    .line 3618
    iput p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->initialPlayButtonShape_:I

    return-void
.end method

.method private setPlaybackSpeedOptions(ID)V
    .registers 5

    .line 2941
    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->ensurePlaybackSpeedOptionsIsMutable()V

    .line 2942
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->playbackSpeedOptions_:Lcom/google/protobuf/Internal$DoubleList;

    invoke-interface {v0, p1, p2, p3}, Lcom/google/protobuf/Internal$DoubleList;->setDouble(ID)D

    return-void
.end method

.method private setPrimaryColor(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 2548
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2550
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->primaryColor_:Lcom/google/protobuf/ByteString;

    return-void
.end method

.method private setQualityTrackLabels(Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;)V
    .registers 2

    .line 3776
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3777
    iput-object p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->qualityTrackLabels_:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    .line 3778
    iget p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->bitField0_:I

    return-void
.end method

.method private setShowBackward(Z)V
    .registers 2

    .line 2810
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showBackward_:Z

    return-void
.end method

.method private setShowCaptionsControl(Z)V
    .registers 2

    .line 2706
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showCaptionsControl_:Z

    return-void
.end method

.method private setShowCastWhenDeviceReady(Z)V
    .registers 2

    .line 3720
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showCastWhenDeviceReady_:Z

    return-void
.end method

.method private setShowClearStorageOption(Z)V
    .registers 2

    .line 3746
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showClearStorageOption_:Z

    return-void
.end method

.method private setShowForward(Z)V
    .registers 2

    .line 2784
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showForward_:Z

    return-void
.end method

.method private setShowFullScreen(Z)V
    .registers 2

    .line 2732
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showFullScreen_:Z

    return-void
.end method

.method private setShowPlayPauseBtn(Z)V
    .registers 2

    .line 2602
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showPlayPauseBtn_:Z

    return-void
.end method

.method private setShowProgressBar(Z)V
    .registers 2

    .line 2628
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showProgressBar_:Z

    return-void
.end method

.method private setShowQualityControl(Z)V
    .registers 2

    .line 2680
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showQualityControl_:Z

    return-void
.end method

.method private setShowReplayAtEnd(Z)V
    .registers 2

    .line 3063
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showReplayAtEnd_:Z

    return-void
.end method

.method private setShowScrubbingPreview(Z)V
    .registers 2

    .line 3141
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showScrubbingPreview_:Z

    return-void
.end method

.method private setShowSpeedControl(Z)V
    .registers 2

    .line 2654
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showSpeedControl_:Z

    return-void
.end method

.method private setShowTimeText(Z)V
    .registers 2

    .line 2576
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showTimeText_:Z

    return-void
.end method

.method private setShowVolume(Z)V
    .registers 2

    .line 2758
    iput-boolean p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showVolume_:Z

    return-void
.end method

.method private setSkipDuration(I)V
    .registers 2

    .line 2985
    iput p1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->skipDuration_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 49

    .line 5334
    sget-object v0, Lcom/vdocipher/PlaybackInfo$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual/range {p1 .. p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_b4

    .line 5422
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0

    :pswitch_12  #0x7
    return-object v1

    :pswitch_13  #0x6
    const/4 v0, 0x1

    .line 5416
    invoke-static {v0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v0

    return-object v0

    .line 5401
    :pswitch_19  #0x5
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->PARSER:Lcom/google/protobuf/Parser;

    if-nez v0, :cond_32

    .line 5403
    const-class v1, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    monitor-enter v1

    .line 5404
    :try_start_20
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->PARSER:Lcom/google/protobuf/Parser;

    if-nez v0, :cond_2d

    .line 5406
    new-instance v0, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object v2, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-direct {v0, v2}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 5409
    sput-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->PARSER:Lcom/google/protobuf/Parser;

    .line 5411
    :cond_2d
    monitor-exit v1

    return-object v0

    :catchall_2f
    move-exception v0

    monitor-exit v1
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw v0

    :cond_32
    return-object v0

    .line 5398
    :pswitch_33  #0x4
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    return-object v0

    .line 5342
    :pswitch_36  #0x3
    const-string v2, "bitField0_"

    const-string v3, "primaryColor_"

    const-string/jumbo v4, "showTimeText_"

    const-string/jumbo v5, "showPlayPauseBtn_"

    const-string/jumbo v6, "showProgressBar_"

    const-string/jumbo v7, "showSpeedControl_"

    const-string/jumbo v8, "showQualityControl_"

    const-string/jumbo v9, "showCaptionsControl_"

    const-string/jumbo v10, "showFullScreen_"

    const-string/jumbo v11, "showVolume_"

    const-string/jumbo v12, "showForward_"

    const-string/jumbo v13, "showBackward_"

    const-string v14, "enableAirPlay_"

    const-string v15, "enableChromecast_"

    const-string v16, "hideControlsOnPause_"

    const-string v17, "playbackSpeedOptions_"

    const-string/jumbo v18, "skipDuration_"

    const-string v19, "enablePiP_"

    const-string v20, "enableCaptionSearch_"

    const-string/jumbo v21, "showReplayAtEnd_"

    const-string v22, "enableLockControls_"

    const-string v23, "hideContextMenu_"

    const-string/jumbo v24, "showScrubbingPreview_"

    const-string v25, "enableDoubleTapSkip_"

    const-string v26, "enableSaveOffline_"

    const-string v27, "enableKeyboardShortcuts_"

    const-string v28, "enableAutoResumeLocal_"

    const-string v29, "conserveVolumeAcrossSession_"

    const-string v30, "conserveQualityAcrossSession_"

    const-string v31, "conserveSpeedAcrossSession_"

    const-string v32, "conserveSelectedCaptionLanguage_"

    const-string v33, "confirmBeforeAutoResume_"

    const-string v34, "captionScaleFactor_"

    const-string v35, "collapseInSettings_"

    const-string v36, "enableAboutPlayer_"

    const-string v37, "enableReportBug_"

    const-string v38, "initialPlayButtonShape_"

    const-string v39, "initialDurationPosition_"

    const-string v40, "enableChapters_"

    const-string/jumbo v41, "showCastWhenDeviceReady_"

    const-string/jumbo v42, "showClearStorageOption_"

    const-string v43, "qualityTrackLabels_"

    const-string v44, "captionGlobalStyles_"

    filled-new-array/range {v2 .. v44}, [Ljava/lang/Object;

    move-result-object v0

    .line 5387
    const-string v1, "\u0000*\u0000\u0001\u0001**\u0000\u0002\u0000\u0001\n\u0002\u0007\u0003\u0007\u0004\u0007\u0005\u0007\u0006\u0007\u0007\u0007\b\u0007\t\u0007\n\u0007\u000b\u0007\f\u0007\r\u0007\u000e\u0007\u000f#\u0010\u000b\u0011\u0007\u0012\u0007\u0013\u0007\u0014\u0007\u0015\u0007\u0016\u0007\u0017\u0007\u0018\u0007\u0019\u0007\u001a\u0007\u001b\u0007\u001c\u0007\u001d\u0007\u001e\u0007\u001f\u0007 \u000b!,\"\u0007#\u0007$\f%\f&\u0007\'\u0007(\u0007)ဉ\u0000*ဉ\u0001"

    .line 5394
    sget-object v2, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-static {v2, v1, v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    .line 5339
    :pswitch_a8  #0x2
    new-instance v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;

    invoke-direct {v0, v1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$Builder;-><init>(Lcom/vdocipher/PlaybackInfo-IA;)V

    return-object v0

    .line 5336
    :pswitch_ae  #0x1
    new-instance v0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;-><init>()V

    return-object v0

    :pswitch_data_b4
    .packed-switch 0x1
        :pswitch_ae  #00000001
        :pswitch_a8  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getCaptionGlobalStyles()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
    .registers 2

    .line 3816
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->captionGlobalStyles_:Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getCaptionScaleFactor()I
    .registers 2

    .line 3393
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->captionScaleFactor_:I

    return v0
.end method

.method public getCollapseInSettings(I)Lcom/vdocipher/PlaybackInfo$CollapseSettings;
    .registers 3

    .line 3447
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->getInt(I)I

    move-result p1

    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->forNumber(I)Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    move-result-object p1

    if-nez p1, :cond_e

    .line 3448
    sget-object p1, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    :cond_e
    return-object p1
.end method

.method public getCollapseInSettingsCount()I
    .registers 2

    .line 3438
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$IntList;->size()I

    move-result v0

    return v0
.end method

.method public getCollapseInSettingsList()Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$CollapseSettings;",
            ">;"
        }
    .end annotation

    .line 3429
    new-instance v0, Lcom/google/protobuf/Internal$ListAdapter;

    iget-object v1, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

    sget-object v2, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_converter_:Lcom/google/protobuf/Internal$ListAdapter$Converter;

    invoke-direct {v0, v1, v2}, Lcom/google/protobuf/Internal$ListAdapter;-><init>(Ljava/util/List;Lcom/google/protobuf/Internal$ListAdapter$Converter;)V

    return-object v0
.end method

.method public getCollapseInSettingsValue(I)I
    .registers 3

    .line 3466
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$IntList;->getInt(I)I

    move-result p1

    return p1
.end method

.method public getCollapseInSettingsValueList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 3457
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->collapseInSettings_:Lcom/google/protobuf/Internal$IntList;

    return-object v0
.end method

.method public getConfirmBeforeAutoResume()Z
    .registers 2

    .line 3367
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->confirmBeforeAutoResume_:Z

    return v0
.end method

.method public getConserveQualityAcrossSession()Z
    .registers 2

    .line 3289
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->conserveQualityAcrossSession_:Z

    return v0
.end method

.method public getConserveSelectedCaptionLanguage()Z
    .registers 2

    .line 3341
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->conserveSelectedCaptionLanguage_:Z

    return v0
.end method

.method public getConserveSpeedAcrossSession()Z
    .registers 2

    .line 3315
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->conserveSpeedAcrossSession_:Z

    return v0
.end method

.method public getConserveVolumeAcrossSession()Z
    .registers 2

    .line 3263
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->conserveVolumeAcrossSession_:Z

    return v0
.end method

.method public getEnableAboutPlayer()Z
    .registers 2

    .line 3550
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableAboutPlayer_:Z

    return v0
.end method

.method public getEnableAirPlay()Z
    .registers 2

    .line 2828
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableAirPlay_:Z

    return v0
.end method

.method public getEnableAutoResumeLocal()Z
    .registers 2

    .line 3237
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableAutoResumeLocal_:Z

    return v0
.end method

.method public getEnableCaptionSearch()Z
    .registers 2

    .line 3029
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableCaptionSearch_:Z

    return v0
.end method

.method public getEnableChapters()Z
    .registers 2

    .line 3686
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableChapters_:Z

    return v0
.end method

.method public getEnableChromecast()Z
    .registers 2

    .line 2854
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableChromecast_:Z

    return v0
.end method

.method public getEnableDoubleTapSkip()Z
    .registers 2

    .line 3159
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableDoubleTapSkip_:Z

    return v0
.end method

.method public getEnableKeyboardShortcuts()Z
    .registers 2

    .line 3211
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableKeyboardShortcuts_:Z

    return v0
.end method

.method public getEnableLockControls()Z
    .registers 2

    .line 3081
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableLockControls_:Z

    return v0
.end method

.method public getEnablePiP()Z
    .registers 2

    .line 3003
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enablePiP_:Z

    return v0
.end method

.method public getEnableReportBug()Z
    .registers 2

    .line 3576
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableReportBug_:Z

    return v0
.end method

.method public getEnableSaveOffline()Z
    .registers 2

    .line 3185
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->enableSaveOffline_:Z

    return v0
.end method

.method public getHideContextMenu()Z
    .registers 2

    .line 3107
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->hideContextMenu_:Z

    return v0
.end method

.method public getHideControlsOnPause()Z
    .registers 2

    .line 2880
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->hideControlsOnPause_:Z

    return v0
.end method

.method public getInitialDurationPosition()Lcom/vdocipher/PlaybackInfo$ElementPosition;
    .registers 2

    .line 3652
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->initialDurationPosition_:I

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$ElementPosition;->forNumber(I)Lcom/vdocipher/PlaybackInfo$ElementPosition;

    move-result-object v0

    if-nez v0, :cond_a

    .line 3653
    sget-object v0, Lcom/vdocipher/PlaybackInfo$ElementPosition;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$ElementPosition;

    :cond_a
    return-object v0
.end method

.method public getInitialDurationPositionValue()I
    .registers 2

    .line 3644
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->initialDurationPosition_:I

    return v0
.end method

.method public getInitialPlayButtonShape()Lcom/vdocipher/PlaybackInfo$PlayButtonShape;
    .registers 2

    .line 3610
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->initialPlayButtonShape_:I

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->forNumber(I)Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    move-result-object v0

    if-nez v0, :cond_a

    .line 3611
    sget-object v0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    :cond_a
    return-object v0
.end method

.method public getInitialPlayButtonShapeValue()I
    .registers 2

    .line 3602
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->initialPlayButtonShape_:I

    return v0
.end method

.method public getPlaybackSpeedOptions(I)D
    .registers 4

    .line 2924
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->playbackSpeedOptions_:Lcom/google/protobuf/Internal$DoubleList;

    invoke-interface {v0, p1}, Lcom/google/protobuf/Internal$DoubleList;->getDouble(I)D

    move-result-wide v0

    return-wide v0
.end method

.method public getPlaybackSpeedOptionsCount()I
    .registers 2

    .line 2915
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->playbackSpeedOptions_:Lcom/google/protobuf/Internal$DoubleList;

    invoke-interface {v0}, Lcom/google/protobuf/Internal$DoubleList;->size()I

    move-result v0

    return v0
.end method

.method public getPlaybackSpeedOptionsList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Double;",
            ">;"
        }
    .end annotation

    .line 2907
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->playbackSpeedOptions_:Lcom/google/protobuf/Internal$DoubleList;

    return-object v0
.end method

.method public getPrimaryColor()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 2541
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->primaryColor_:Lcom/google/protobuf/ByteString;

    return-object v0
.end method

.method public getQualityTrackLabels()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
    .registers 2

    .line 3770
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->qualityTrackLabels_:Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;->getDefaultInstance()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getShowBackward()Z
    .registers 2

    .line 2802
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showBackward_:Z

    return v0
.end method

.method public getShowCaptionsControl()Z
    .registers 2

    .line 2698
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showCaptionsControl_:Z

    return v0
.end method

.method public getShowCastWhenDeviceReady()Z
    .registers 2

    .line 3712
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showCastWhenDeviceReady_:Z

    return v0
.end method

.method public getShowClearStorageOption()Z
    .registers 2

    .line 3738
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showClearStorageOption_:Z

    return v0
.end method

.method public getShowForward()Z
    .registers 2

    .line 2776
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showForward_:Z

    return v0
.end method

.method public getShowFullScreen()Z
    .registers 2

    .line 2724
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showFullScreen_:Z

    return v0
.end method

.method public getShowPlayPauseBtn()Z
    .registers 2

    .line 2594
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showPlayPauseBtn_:Z

    return v0
.end method

.method public getShowProgressBar()Z
    .registers 2

    .line 2620
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showProgressBar_:Z

    return v0
.end method

.method public getShowQualityControl()Z
    .registers 2

    .line 2672
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showQualityControl_:Z

    return v0
.end method

.method public getShowReplayAtEnd()Z
    .registers 2

    .line 3055
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showReplayAtEnd_:Z

    return v0
.end method

.method public getShowScrubbingPreview()Z
    .registers 2

    .line 3133
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showScrubbingPreview_:Z

    return v0
.end method

.method public getShowSpeedControl()Z
    .registers 2

    .line 2646
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showSpeedControl_:Z

    return v0
.end method

.method public getShowTimeText()Z
    .registers 2

    .line 2568
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showTimeText_:Z

    return v0
.end method

.method public getShowVolume()Z
    .registers 2

    .line 2750
    iget-boolean v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->showVolume_:Z

    return v0
.end method

.method public getSkipDuration()I
    .registers 2

    .line 2977
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->skipDuration_:I

    return v0
.end method

.method public hasCaptionGlobalStyles()Z
    .registers 2

    .line 3809
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->bitField0_:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    return v0

    :cond_8
    const/4 v0, 0x0

    return v0
.end method

.method public hasQualityTrackLabels()Z
    .registers 3

    .line 3763
    iget v0, p0, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;->bitField0_:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_7

    return v1

    :cond_7
    const/4 v0, 0x0

    return v0
.end method
