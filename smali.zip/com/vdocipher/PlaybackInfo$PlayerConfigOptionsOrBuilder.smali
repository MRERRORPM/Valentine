# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackInfo$PlayerConfigOptionsOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "PlayerConfigOptionsOrBuilder"
.end annotation


# virtual methods
.method public abstract getCaptionGlobalStyles()Lcom/vdocipher/PlaybackInfo$CaptionGlobalStyles;
.end method

.method public abstract getCaptionScaleFactor()I
.end method

.method public abstract getCollapseInSettings(I)Lcom/vdocipher/PlaybackInfo$CollapseSettings;
.end method

.method public abstract getCollapseInSettingsCount()I
.end method

.method public abstract getCollapseInSettingsList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$CollapseSettings;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getCollapseInSettingsValue(I)I
.end method

.method public abstract getCollapseInSettingsValueList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getConfirmBeforeAutoResume()Z
.end method

.method public abstract getConserveQualityAcrossSession()Z
.end method

.method public abstract getConserveSelectedCaptionLanguage()Z
.end method

.method public abstract getConserveSpeedAcrossSession()Z
.end method

.method public abstract getConserveVolumeAcrossSession()Z
.end method

.method public abstract getEnableAboutPlayer()Z
.end method

.method public abstract getEnableAirPlay()Z
.end method

.method public abstract getEnableAutoResumeLocal()Z
.end method

.method public abstract getEnableCaptionSearch()Z
.end method

.method public abstract getEnableChapters()Z
.end method

.method public abstract getEnableChromecast()Z
.end method

.method public abstract getEnableDoubleTapSkip()Z
.end method

.method public abstract getEnableKeyboardShortcuts()Z
.end method

.method public abstract getEnableLockControls()Z
.end method

.method public abstract getEnablePiP()Z
.end method

.method public abstract getEnableReportBug()Z
.end method

.method public abstract getEnableSaveOffline()Z
.end method

.method public abstract getHideContextMenu()Z
.end method

.method public abstract getHideControlsOnPause()Z
.end method

.method public abstract getInitialDurationPosition()Lcom/vdocipher/PlaybackInfo$ElementPosition;
.end method

.method public abstract getInitialDurationPositionValue()I
.end method

.method public abstract getInitialPlayButtonShape()Lcom/vdocipher/PlaybackInfo$PlayButtonShape;
.end method

.method public abstract getInitialPlayButtonShapeValue()I
.end method

.method public abstract getPlaybackSpeedOptions(I)D
.end method

.method public abstract getPlaybackSpeedOptionsCount()I
.end method

.method public abstract getPlaybackSpeedOptionsList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Double;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getPrimaryColor()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getQualityTrackLabels()Lcom/vdocipher/PlaybackInfo$QualityTrackLabels;
.end method

.method public abstract getShowBackward()Z
.end method

.method public abstract getShowCaptionsControl()Z
.end method

.method public abstract getShowCastWhenDeviceReady()Z
.end method

.method public abstract getShowClearStorageOption()Z
.end method

.method public abstract getShowForward()Z
.end method

.method public abstract getShowFullScreen()Z
.end method

.method public abstract getShowPlayPauseBtn()Z
.end method

.method public abstract getShowProgressBar()Z
.end method

.method public abstract getShowQualityControl()Z
.end method

.method public abstract getShowReplayAtEnd()Z
.end method

.method public abstract getShowScrubbingPreview()Z
.end method

.method public abstract getShowSpeedControl()Z
.end method

.method public abstract getShowTimeText()Z
.end method

.method public abstract getShowVolume()Z
.end method

.method public abstract getSkipDuration()I
.end method

.method public abstract hasCaptionGlobalStyles()Z
.end method

.method public abstract hasQualityTrackLabels()Z
.end method
