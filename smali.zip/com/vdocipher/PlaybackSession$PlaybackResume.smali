# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$PlaybackResume;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$PlaybackResumeOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "PlaybackResume"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$PlaybackResume;",
        "Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$PlaybackResumeOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$PlaybackResume;",
            ">;"
        }
    .end annotation
.end field

.field public static final TIME_FIELD_NUMBER:I = 0x1

.field public static final TYPE_FIELD_NUMBER:I = 0x2


# instance fields
.field private time_:I

.field private type_:I


# direct methods
.method static bridge synthetic -$$Nest$mclearTime(Lcom/vdocipher/PlaybackSession$PlaybackResume;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->clearTime()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearType(Lcom/vdocipher/PlaybackSession$PlaybackResume;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->clearType()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTime(Lcom/vdocipher/PlaybackSession$PlaybackResume;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->setTime(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetType(Lcom/vdocipher/PlaybackSession$PlaybackResume;Lcom/vdocipher/PlaybackSession$ResumeType;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->setType(Lcom/vdocipher/PlaybackSession$ResumeType;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTypeValue(Lcom/vdocipher/PlaybackSession$PlaybackResume;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->setTypeValue(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 13688
    new-instance v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$PlaybackResume;-><init>()V

    .line 13691
    sput-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    .line 13692
    const-class v1, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 13390
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    return-void
.end method

.method private clearTime()V
    .registers 2

    const/4 v0, 0x0

    .line 13415
    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->time_:I

    return-void
.end method

.method private clearType()V
    .registers 2

    const/4 v0, 0x0

    .line 13457
    iput v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->type_:I

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 1

    .line 13697
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;
    .registers 1

    .line 13537
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$PlaybackResume;)Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;
    .registers 2

    .line 13540
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 13513
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 13520
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 13476
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 13483
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 13525
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 13532
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 13500
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 13507
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 13463
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 13470
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 13488
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$PlaybackResume;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 13495
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$PlaybackResume;",
            ">;"
        }
    .end annotation

    .line 13703
    sget-object v0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setTime(I)V
    .registers 2

    .line 13408
    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->time_:I

    return-void
.end method

.method private setType(Lcom/vdocipher/PlaybackSession$ResumeType;)V
    .registers 2

    .line 13449
    invoke-virtual {p1}, Lcom/vdocipher/PlaybackSession$ResumeType;->getNumber()I

    move-result p1

    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->type_:I

    return-void
.end method

.method private setTypeValue(I)V
    .registers 2

    .line 13442
    iput p1, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->type_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 13638
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_56

    .line 13681
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 13675
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 13660
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$PlaybackResume;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 13662
    const-class p2, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    monitor-enter p2

    .line 13663
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$PlaybackResume;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 13665
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 13668
    sput-object p1, Lcom/vdocipher/PlaybackSession$PlaybackResume;->PARSER:Lcom/google/protobuf/Parser;

    .line 13670
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 13657
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    return-object p1

    .line 13646
    :pswitch_36  #0x3
    const-string/jumbo p1, "time_"

    const-string/jumbo p2, "type_"

    filled-new-array {p1, p2}, [Ljava/lang/Object;

    move-result-object p1

    .line 13650
    const-string p2, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u000b\u0002\f"

    .line 13653
    sget-object p3, Lcom/vdocipher/PlaybackSession$PlaybackResume;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$PlaybackResume;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 13643
    :pswitch_49  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$PlaybackResume$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 13640
    :pswitch_4f  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$PlaybackResume;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$PlaybackResume;-><init>()V

    return-object p1

    nop

    :pswitch_data_56
    .packed-switch 0x1
        :pswitch_4f  #00000001
        :pswitch_49  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getTime()I
    .registers 2

    .line 13400
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->time_:I

    return v0
.end method

.method public getType()Lcom/vdocipher/PlaybackSession$ResumeType;
    .registers 2

    .line 13434
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->type_:I

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$ResumeType;->forNumber(I)Lcom/vdocipher/PlaybackSession$ResumeType;

    move-result-object v0

    if-nez v0, :cond_a

    .line 13435
    sget-object v0, Lcom/vdocipher/PlaybackSession$ResumeType;->UNRECOGNIZED:Lcom/vdocipher/PlaybackSession$ResumeType;

    :cond_a
    return-object v0
.end method

.method public getTypeValue()I
    .registers 2

    .line 13426
    iget v0, p0, Lcom/vdocipher/PlaybackSession$PlaybackResume;->type_:I

    return v0
.end method
