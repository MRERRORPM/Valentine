# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$WidevineCDMOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$WidevineCDM;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackSession$WidevineCDM;",
        "Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$WidevineCDMOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 10601
    invoke-static {}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$WidevineCDM;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackSession-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearDeviceUniqueId()Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 2

    .line 10687
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10688
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$mclearDeviceUniqueId(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V

    return-object p0
.end method

.method public clearDowngradedToL3()Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 2

    .line 10976
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10977
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$mclearDowngradedToL3(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V

    return-object p0
.end method

.method public clearHdcpLevel()Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 2

    .line 10744
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10745
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$mclearHdcpLevel(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V

    return-object p0
.end method

.method public clearMaxHDCPLevel()Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 2

    .line 10790
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10791
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$mclearMaxHDCPLevel(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V

    return-object p0
.end method

.method public clearMaxNumberOfSessions()Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 2

    .line 10818
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10819
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$mclearMaxNumberOfSessions(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V

    return-object p0
.end method

.method public clearNumberOfOpenSessions()Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 2

    .line 10846
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10847
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$mclearNumberOfOpenSessions(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V

    return-object p0
.end method

.method public clearOemCryptoApiVersion()Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 2

    .line 10874
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10875
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$mclearOemCryptoApiVersion(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V

    return-object p0
.end method

.method public clearSecurityLevel()Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 2

    .line 10920
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10921
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$mclearSecurityLevel(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V

    return-object p0
.end method

.method public clearSystemId()Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 2

    .line 10948
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10949
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$mclearSystemId(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V

    return-object p0
.end method

.method public clearVersion()Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 2

    .line 10638
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10639
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$mclearVersion(Lcom/vdocipher/PlaybackSession$WidevineCDM;)V

    return-object p0
.end method

.method public getDeviceUniqueId()Ljava/lang/String;
    .registers 2

    .line 10660
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getDeviceUniqueId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getDeviceUniqueIdBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 10669
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getDeviceUniqueIdBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getDowngradedToL3()Z
    .registers 2

    .line 10959
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getDowngradedToL3()Z

    move-result v0

    return v0
.end method

.method public getHdcpLevel()Lcom/vdocipher/PlaybackSession$HDCPLevel;
    .registers 2

    .line 10727
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getHdcpLevel()Lcom/vdocipher/PlaybackSession$HDCPLevel;

    move-result-object v0

    return-object v0
.end method

.method public getHdcpLevelValue()I
    .registers 2

    .line 10709
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getHdcpLevelValue()I

    move-result v0

    return v0
.end method

.method public getMaxHDCPLevel()Lcom/vdocipher/PlaybackSession$HDCPLevel;
    .registers 2

    .line 10773
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getMaxHDCPLevel()Lcom/vdocipher/PlaybackSession$HDCPLevel;

    move-result-object v0

    return-object v0
.end method

.method public getMaxHDCPLevelValue()I
    .registers 2

    .line 10755
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getMaxHDCPLevelValue()I

    move-result v0

    return v0
.end method

.method public getMaxNumberOfSessions()I
    .registers 2

    .line 10801
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getMaxNumberOfSessions()I

    move-result v0

    return v0
.end method

.method public getNumberOfOpenSessions()I
    .registers 2

    .line 10829
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getNumberOfOpenSessions()I

    move-result v0

    return v0
.end method

.method public getOemCryptoApiVersion()I
    .registers 2

    .line 10857
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getOemCryptoApiVersion()I

    move-result v0

    return v0
.end method

.method public getSecurityLevel()Lcom/vdocipher/PlaybackSession$CdmLevel;
    .registers 2

    .line 10903
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getSecurityLevel()Lcom/vdocipher/PlaybackSession$CdmLevel;

    move-result-object v0

    return-object v0
.end method

.method public getSecurityLevelValue()I
    .registers 2

    .line 10885
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getSecurityLevelValue()I

    move-result v0

    return v0
.end method

.method public getSystemId()I
    .registers 2

    .line 10931
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getSystemId()I

    move-result v0

    return v0
.end method

.method public getVersion()Ljava/lang/String;
    .registers 2

    .line 10611
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getVersion()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getVersionBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 10620
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->getVersionBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public setDeviceUniqueId(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 3

    .line 10678
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10679
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$msetDeviceUniqueId(Lcom/vdocipher/PlaybackSession$WidevineCDM;Ljava/lang/String;)V

    return-object p0
.end method

.method public setDeviceUniqueIdBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 3

    .line 10698
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10699
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$msetDeviceUniqueIdBytes(Lcom/vdocipher/PlaybackSession$WidevineCDM;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setDowngradedToL3(Z)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 3

    .line 10967
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10968
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$msetDowngradedToL3(Lcom/vdocipher/PlaybackSession$WidevineCDM;Z)V

    return-object p0
.end method

.method public setHdcpLevel(Lcom/vdocipher/PlaybackSession$HDCPLevel;)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 3

    .line 10735
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10736
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$msetHdcpLevel(Lcom/vdocipher/PlaybackSession$WidevineCDM;Lcom/vdocipher/PlaybackSession$HDCPLevel;)V

    return-object p0
.end method

.method public setHdcpLevelValue(I)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 3

    .line 10717
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10718
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$msetHdcpLevelValue(Lcom/vdocipher/PlaybackSession$WidevineCDM;I)V

    return-object p0
.end method

.method public setMaxHDCPLevel(Lcom/vdocipher/PlaybackSession$HDCPLevel;)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 3

    .line 10781
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10782
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$msetMaxHDCPLevel(Lcom/vdocipher/PlaybackSession$WidevineCDM;Lcom/vdocipher/PlaybackSession$HDCPLevel;)V

    return-object p0
.end method

.method public setMaxHDCPLevelValue(I)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 3

    .line 10763
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10764
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$msetMaxHDCPLevelValue(Lcom/vdocipher/PlaybackSession$WidevineCDM;I)V

    return-object p0
.end method

.method public setMaxNumberOfSessions(I)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 3

    .line 10809
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10810
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$msetMaxNumberOfSessions(Lcom/vdocipher/PlaybackSession$WidevineCDM;I)V

    return-object p0
.end method

.method public setNumberOfOpenSessions(I)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 3

    .line 10837
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10838
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$msetNumberOfOpenSessions(Lcom/vdocipher/PlaybackSession$WidevineCDM;I)V

    return-object p0
.end method

.method public setOemCryptoApiVersion(I)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 3

    .line 10865
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10866
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$msetOemCryptoApiVersion(Lcom/vdocipher/PlaybackSession$WidevineCDM;I)V

    return-object p0
.end method

.method public setSecurityLevel(Lcom/vdocipher/PlaybackSession$CdmLevel;)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 3

    .line 10911
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10912
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$msetSecurityLevel(Lcom/vdocipher/PlaybackSession$WidevineCDM;Lcom/vdocipher/PlaybackSession$CdmLevel;)V

    return-object p0
.end method

.method public setSecurityLevelValue(I)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 3

    .line 10893
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10894
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$msetSecurityLevelValue(Lcom/vdocipher/PlaybackSession$WidevineCDM;I)V

    return-object p0
.end method

.method public setSystemId(I)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 3

    .line 10939
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10940
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$msetSystemId(Lcom/vdocipher/PlaybackSession$WidevineCDM;I)V

    return-object p0
.end method

.method public setVersion(Ljava/lang/String;)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 3

    .line 10629
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10630
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$msetVersion(Lcom/vdocipher/PlaybackSession$WidevineCDM;Ljava/lang/String;)V

    return-object p0
.end method

.method public setVersionBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;
    .registers 3

    .line 10649
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->copyOnWrite()V

    .line 10650
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$WidevineCDM$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackSession$WidevineCDM;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackSession$WidevineCDM;->-$$Nest$msetVersionBytes(Lcom/vdocipher/PlaybackSession$WidevineCDM;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method
