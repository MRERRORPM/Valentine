# classes14.dex

.class public final Lcom/vdocipher/Manifest$Initialization$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$InitializationOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest$Initialization;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/Manifest$Initialization;",
        "Lcom/vdocipher/Manifest$Initialization$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$InitializationOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 1796
    invoke-static {}, Lcom/vdocipher/Manifest$Initialization;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$Initialization;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/Manifest-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/Manifest$Initialization$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public clearEnd()Lcom/vdocipher/Manifest$Initialization$Builder;
    .registers 2

    .line 1851
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Initialization$Builder;->copyOnWrite()V

    .line 1852
    iget-object v0, p0, Lcom/vdocipher/Manifest$Initialization$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Initialization;->-$$Nest$mclearEnd(Lcom/vdocipher/Manifest$Initialization;)V

    return-object p0
.end method

.method public clearStart()Lcom/vdocipher/Manifest$Initialization$Builder;
    .registers 2

    .line 1823
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Initialization$Builder;->copyOnWrite()V

    .line 1824
    iget-object v0, p0, Lcom/vdocipher/Manifest$Initialization$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0}, Lcom/vdocipher/Manifest$Initialization;->-$$Nest$mclearStart(Lcom/vdocipher/Manifest$Initialization;)V

    return-object p0
.end method

.method public getEnd()I
    .registers 2

    .line 1834
    iget-object v0, p0, Lcom/vdocipher/Manifest$Initialization$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Initialization;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Initialization;->getEnd()I

    move-result v0

    return v0
.end method

.method public getStart()I
    .registers 2

    .line 1806
    iget-object v0, p0, Lcom/vdocipher/Manifest$Initialization$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Initialization;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$Initialization;->getStart()I

    move-result v0

    return v0
.end method

.method public setEnd(I)Lcom/vdocipher/Manifest$Initialization$Builder;
    .registers 3

    .line 1842
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Initialization$Builder;->copyOnWrite()V

    .line 1843
    iget-object v0, p0, Lcom/vdocipher/Manifest$Initialization$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Initialization;->-$$Nest$msetEnd(Lcom/vdocipher/Manifest$Initialization;I)V

    return-object p0
.end method

.method public setStart(I)Lcom/vdocipher/Manifest$Initialization$Builder;
    .registers 3

    .line 1814
    invoke-virtual {p0}, Lcom/vdocipher/Manifest$Initialization$Builder;->copyOnWrite()V

    .line 1815
    iget-object v0, p0, Lcom/vdocipher/Manifest$Initialization$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/Manifest$Initialization;

    invoke-static {v0, p1}, Lcom/vdocipher/Manifest$Initialization;->-$$Nest$msetStart(Lcom/vdocipher/Manifest$Initialization;I)V

    return-object p0
.end method
