# classes14.dex

.class public final Lcom/vdocipher/PlaybackInfo$DASH$Builder;
.super Lcom/google/protobuf/GeneratedMessageLite$Builder;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/vdocipher/PlaybackInfo$DASHOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$DASH;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite$Builder<",
        "Lcom/vdocipher/PlaybackInfo$DASH;",
        "Lcom/vdocipher/PlaybackInfo$DASH$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackInfo$DASHOrBuilder;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 7349
    invoke-static {}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackInfo$DASH;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method synthetic constructor <init>(Lcom/vdocipher/PlaybackInfo-IA;)V
    .registers 2

    invoke-direct {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;-><init>()V

    return-void
.end method


# virtual methods
.method public addAllErrorCodesAL3(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Ljava/lang/Integer;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$DASH$Builder;"
        }
    .end annotation

    .line 7541
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7542
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$maddAllErrorCodesAL3(Lcom/vdocipher/PlaybackInfo$DASH;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addAllFallbackLicenseServers(Ljava/lang/Iterable;)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/vdocipher/PlaybackInfo$DASH$Builder;"
        }
    .end annotation

    .line 7650
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7651
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$maddAllFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$DASH;Ljava/lang/Iterable;)V

    return-object p0
.end method

.method public addErrorCodesAL3(I)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 3

    .line 7530
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7531
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$maddErrorCodesAL3(Lcom/vdocipher/PlaybackInfo$DASH;I)V

    return-object p0
.end method

.method public addFallbackLicenseServers(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 3

    .line 7639
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7640
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$maddFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$DASH;Ljava/lang/String;)V

    return-object p0
.end method

.method public addFallbackLicenseServersBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 3

    .line 7670
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7671
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$maddFallbackLicenseServersBytes(Lcom/vdocipher/PlaybackInfo$DASH;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public clearAllowSafetyDetect()Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 2

    .line 7778
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7779
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$mclearAllowSafetyDetect(Lcom/vdocipher/PlaybackInfo$DASH;)V

    return-object p0
.end method

.method public clearEnforceAL3()Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 2

    .line 7481
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7482
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$mclearEnforceAL3(Lcom/vdocipher/PlaybackInfo$DASH;)V

    return-object p0
.end method

.method public clearEnforceHardwareAttestation()Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 2

    .line 7742
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7743
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$mclearEnforceHardwareAttestation(Lcom/vdocipher/PlaybackInfo$DASH;)V

    return-object p0
.end method

.method public clearEnforceL3Config()Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 2

    .line 7453
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7454
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$mclearEnforceL3Config(Lcom/vdocipher/PlaybackInfo$DASH;)V

    return-object p0
.end method

.method public clearErrorCodesAL3()Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 2

    .line 7550
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7551
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$mclearErrorCodesAL3(Lcom/vdocipher/PlaybackInfo$DASH;)V

    return-object p0
.end method

.method public clearFallbackLicenseServers()Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 2

    .line 7659
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7660
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$mclearFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$DASH;)V

    return-object p0
.end method

.method public clearLicenseServers()Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 2

    .line 7386
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7387
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$mclearLicenseServers(Lcom/vdocipher/PlaybackInfo$DASH;)V

    return-object p0
.end method

.method public clearManifest()Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 2

    .line 7425
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7426
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$mclearManifest(Lcom/vdocipher/PlaybackInfo$DASH;)V

    return-object p0
.end method

.method public clearMpdString()Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 2

    .line 7578
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7579
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$mclearMpdString(Lcom/vdocipher/PlaybackInfo$DASH;)V

    return-object p0
.end method

.method public clearPsr()Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 2

    .line 7706
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7707
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$mclearPsr(Lcom/vdocipher/PlaybackInfo$DASH;)V

    return-object p0
.end method

.method public getAllowSafetyDetect()Z
    .registers 2

    .line 7761
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getAllowSafetyDetect()Z

    move-result v0

    return v0
.end method

.method public getEnforceAL3()Z
    .registers 2

    .line 7464
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getEnforceAL3()Z

    move-result v0

    return v0
.end method

.method public getEnforceHardwareAttestation()Z
    .registers 2

    .line 7725
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getEnforceHardwareAttestation()Z

    move-result v0

    return v0
.end method

.method public getEnforceL3Config()Z
    .registers 2

    .line 7436
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getEnforceL3Config()Z

    move-result v0

    return v0
.end method

.method public getErrorCodesAL3(I)I
    .registers 3

    .line 7511
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->getErrorCodesAL3(I)I

    move-result p1

    return p1
.end method

.method public getErrorCodesAL3Count()I
    .registers 2

    .line 7502
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getErrorCodesAL3Count()I

    move-result v0

    return v0
.end method

.method public getErrorCodesAL3List()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 7493
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    .line 7494
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getErrorCodesAL3List()Ljava/util/List;

    move-result-object v0

    .line 7493
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getFallbackLicenseServers(I)Ljava/lang/String;
    .registers 3

    .line 7608
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->getFallbackLicenseServers(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public getFallbackLicenseServersBytes(I)Lcom/google/protobuf/ByteString;
    .registers 3

    .line 7618
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->getFallbackLicenseServersBytes(I)Lcom/google/protobuf/ByteString;

    move-result-object p1

    return-object p1
.end method

.method public getFallbackLicenseServersCount()I
    .registers 2

    .line 7599
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getFallbackLicenseServersCount()I

    move-result v0

    return v0
.end method

.method public getFallbackLicenseServersList()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 7590
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    .line 7591
    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getFallbackLicenseServersList()Ljava/util/List;

    move-result-object v0

    .line 7590
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getLicenseServers()Ljava/lang/String;
    .registers 2

    .line 7359
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getLicenseServers()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getLicenseServersBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 7368
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getLicenseServersBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getManifest()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 7408
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getManifest()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getMpdString()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 7561
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getMpdString()Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getPsr()Z
    .registers 2

    .line 7689
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->getPsr()Z

    move-result v0

    return v0
.end method

.method public hasAllowSafetyDetect()Z
    .registers 2

    .line 7753
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->hasAllowSafetyDetect()Z

    move-result v0

    return v0
.end method

.method public hasEnforceHardwareAttestation()Z
    .registers 2

    .line 7717
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->hasEnforceHardwareAttestation()Z

    move-result v0

    return v0
.end method

.method public hasPsr()Z
    .registers 2

    .line 7681
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackInfo$DASH;->hasPsr()Z

    move-result v0

    return v0
.end method

.method public setAllowSafetyDetect(Z)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 3

    .line 7769
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7770
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$msetAllowSafetyDetect(Lcom/vdocipher/PlaybackInfo$DASH;Z)V

    return-object p0
.end method

.method public setEnforceAL3(Z)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 3

    .line 7472
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7473
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$msetEnforceAL3(Lcom/vdocipher/PlaybackInfo$DASH;Z)V

    return-object p0
.end method

.method public setEnforceHardwareAttestation(Z)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 3

    .line 7733
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7734
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$msetEnforceHardwareAttestation(Lcom/vdocipher/PlaybackInfo$DASH;Z)V

    return-object p0
.end method

.method public setEnforceL3Config(Z)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 3

    .line 7444
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7445
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$msetEnforceL3Config(Lcom/vdocipher/PlaybackInfo$DASH;Z)V

    return-object p0
.end method

.method public setErrorCodesAL3(II)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 4

    .line 7520
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7521
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$msetErrorCodesAL3(Lcom/vdocipher/PlaybackInfo$DASH;II)V

    return-object p0
.end method

.method public setFallbackLicenseServers(ILjava/lang/String;)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 4

    .line 7628
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7629
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1, p2}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$msetFallbackLicenseServers(Lcom/vdocipher/PlaybackInfo$DASH;ILjava/lang/String;)V

    return-object p0
.end method

.method public setLicenseServers(Ljava/lang/String;)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 3

    .line 7377
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7378
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$msetLicenseServers(Lcom/vdocipher/PlaybackInfo$DASH;Ljava/lang/String;)V

    return-object p0
.end method

.method public setLicenseServersBytes(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 3

    .line 7397
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7398
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$msetLicenseServersBytes(Lcom/vdocipher/PlaybackInfo$DASH;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setManifest(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 3

    .line 7416
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7417
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$msetManifest(Lcom/vdocipher/PlaybackInfo$DASH;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setMpdString(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 3

    .line 7569
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7570
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$msetMpdString(Lcom/vdocipher/PlaybackInfo$DASH;Lcom/google/protobuf/ByteString;)V

    return-object p0
.end method

.method public setPsr(Z)Lcom/vdocipher/PlaybackInfo$DASH$Builder;
    .registers 3

    .line 7697
    invoke-virtual {p0}, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->copyOnWrite()V

    .line 7698
    iget-object v0, p0, Lcom/vdocipher/PlaybackInfo$DASH$Builder;->instance:Lcom/google/protobuf/GeneratedMessageLite;

    check-cast v0, Lcom/vdocipher/PlaybackInfo$DASH;

    invoke-static {v0, p1}, Lcom/vdocipher/PlaybackInfo$DASH;->-$$Nest$msetPsr(Lcom/vdocipher/PlaybackInfo$DASH;Z)V

    return-object p0
.end method
