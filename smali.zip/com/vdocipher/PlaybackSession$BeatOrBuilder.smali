# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackSession$BeatOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "BeatOrBuilder"
.end annotation


# virtual methods
.method public abstract getBl()I
.end method

.method public abstract getBw()I
.end method

.method public abstract getCc()Ljava/lang/String;
.end method

.method public abstract getCcBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getFps()I
.end method

.method public abstract getIb()Z
.end method

.method public abstract getIs()Z
.end method

.method public abstract getIsInView()Z
.end method

.method public abstract getIsVideoInFocus()Z
.end method

.method public abstract getIsWindowInFocus()Z
.end method

.method public abstract getPt()F
.end method

.method public abstract getQb()I
.end method

.method public abstract getQp()Lcom/vdocipher/PlaybackSession$QualityPreference;
.end method

.method public abstract getQpValue()I
.end method

.method public abstract getSt()I
.end method

.method public abstract getT()I
.end method

.method public abstract getTc()I
.end method

.method public abstract getTp()F
.end method

.method public abstract getVo()F
.end method
