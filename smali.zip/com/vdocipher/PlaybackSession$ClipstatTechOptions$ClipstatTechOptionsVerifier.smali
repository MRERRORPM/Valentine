# classes14.dex

.class final Lcom/vdocipher/PlaybackSession$ClipstatTechOptions$ClipstatTechOptionsVerifier;
.super Ljava/lang/Object;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumVerifier;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "ClipstatTechOptionsVerifier"
.end annotation


# static fields
.field static final INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1292
    new-instance v0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions$ClipstatTechOptionsVerifier;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions$ClipstatTechOptionsVerifier;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions$ClipstatTechOptionsVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 1290
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public isInRange(I)Z
    .registers 2

    .line 1295
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;->forNumber(I)Lcom/vdocipher/PlaybackSession$ClipstatTechOptions;

    move-result-object p1

    if-eqz p1, :cond_8

    const/4 p1, 0x1

    return p1

    :cond_8
    const/4 p1, 0x0

    return p1
.end method
