# classes14.dex

.class Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$1;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/Internal$ListAdapter$Converter;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/google/protobuf/Internal$ListAdapter$Converter<",
        "Ljava/lang/Integer;",
        "Lcom/vdocipher/PlaybackInfo$CollapseSettings;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .line 3416
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public convert(Ljava/lang/Integer;)Lcom/vdocipher/PlaybackInfo$CollapseSettings;
    .registers 2

    .line 3419
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->forNumber(I)Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    move-result-object p1

    if-nez p1, :cond_c

    .line 3420
    sget-object p1, Lcom/vdocipher/PlaybackInfo$CollapseSettings;->UNRECOGNIZED:Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    :cond_c
    return-object p1
.end method

.method public bridge synthetic convert(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 3416
    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p0, p1}, Lcom/vdocipher/PlaybackInfo$PlayerConfigOptions$1;->convert(Ljava/lang/Integer;)Lcom/vdocipher/PlaybackInfo$CollapseSettings;

    move-result-object p1

    return-object p1
.end method
