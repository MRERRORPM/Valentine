# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackInfo$H6OrBuilder;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "H6OrBuilder"
.end annotation


# virtual methods
.method public abstract getManifest()Lcom/google/protobuf/ByteString;
.end method
