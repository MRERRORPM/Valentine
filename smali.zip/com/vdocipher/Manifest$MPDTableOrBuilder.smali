# classes14.dex

.class public interface abstract Lcom/vdocipher/Manifest$MPDTableOrBuilder;
.super Ljava/lang/Object;
.source "Manifest.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "MPDTableOrBuilder"
.end annotation


# virtual methods
.method public abstract getMediaPresentationDuration()F
.end method

.method public abstract getMinBufferTime()D
.end method

.method public abstract getPeriods(I)Lcom/vdocipher/Manifest$Period;
.end method

.method public abstract getPeriodsCount()I
.end method

.method public abstract getPeriodsList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/Manifest$Period;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getProfiles()Ljava/lang/String;
.end method

.method public abstract getProfilesBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getType()Lcom/vdocipher/Manifest$MPDType;
.end method

.method public abstract getTypeValue()I
.end method

.method public abstract getXmlns()Ljava/lang/String;
.end method

.method public abstract getXmlnsBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getXmlnsCenc()Ljava/lang/String;
.end method

.method public abstract getXmlnsCencBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getXmlnsXsi()Ljava/lang/String;
.end method

.method public abstract getXmlnsXsiBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getXsiSchemaLocation()Ljava/lang/String;
.end method

.method public abstract getXsiSchemaLocationBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract hasMinBufferTime()Z
.end method

.method public abstract hasProfiles()Z
.end method

.method public abstract hasXmlns()Z
.end method

.method public abstract hasXmlnsCenc()Z
.end method

.method public abstract hasXmlnsXsi()Z
.end method

.method public abstract hasXsiSchemaLocation()Z
.end method
