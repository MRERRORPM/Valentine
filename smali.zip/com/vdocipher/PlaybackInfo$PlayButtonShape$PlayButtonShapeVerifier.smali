# classes14.dex

.class final Lcom/vdocipher/PlaybackInfo$PlayButtonShape$PlayButtonShapeVerifier;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/Internal$EnumVerifier;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo$PlayButtonShape;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "PlayButtonShapeVerifier"
.end annotation


# static fields
.field static final INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 371
    new-instance v0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape$PlayButtonShapeVerifier;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackInfo$PlayButtonShape$PlayButtonShapeVerifier;-><init>()V

    sput-object v0, Lcom/vdocipher/PlaybackInfo$PlayButtonShape$PlayButtonShapeVerifier;->INSTANCE:Lcom/google/protobuf/Internal$EnumVerifier;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 369
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public isInRange(I)Z
    .registers 2

    .line 374
    invoke-static {p1}, Lcom/vdocipher/PlaybackInfo$PlayButtonShape;->forNumber(I)Lcom/vdocipher/PlaybackInfo$PlayButtonShape;

    move-result-object p1

    if-eqz p1, :cond_8

    const/4 p1, 0x1

    return p1

    :cond_8
    const/4 p1, 0x0

    return p1
.end method
