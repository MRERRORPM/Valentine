# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackInfo$QualityTrackLabelsOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "QualityTrackLabelsOrBuilder"
.end annotation


# virtual methods
.method public abstract getLabel(I)Lcom/vdocipher/PlaybackInfo$QualityLabels;
.end method

.method public abstract getLabelCount()I
.end method

.method public abstract getLabelList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vdocipher/PlaybackInfo$QualityLabels;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getLabelValue(I)I
.end method

.method public abstract getLabelValueList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getSeparator()Ljava/lang/String;
.end method

.method public abstract getSeparatorBytes()Lcom/google/protobuf/ByteString;
.end method
