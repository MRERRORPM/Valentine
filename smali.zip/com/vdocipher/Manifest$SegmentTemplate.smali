# classes14.dex

.class public final Lcom/vdocipher/Manifest$SegmentTemplate;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "Manifest.java"

# interfaces
.implements Lcom/vdocipher/Manifest$SegmentTemplateOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/Manifest;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "SegmentTemplate"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/Manifest$SegmentTemplate;",
        "Lcom/vdocipher/Manifest$SegmentTemplate$Builder;",
        ">;",
        "Lcom/vdocipher/Manifest$SegmentTemplateOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

.field public static final DURATION_FIELD_NUMBER:I = 0x5

.field public static final INDEXRANGEEXACT_FIELD_NUMBER:I = 0x7

.field public static final INITIALIZATION_FIELD_NUMBER:I = 0x3

.field public static final MEDIA_FIELD_NUMBER:I = 0x2

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$SegmentTemplate;",
            ">;"
        }
    .end annotation
.end field

.field public static final PRESENTATIONTIMEOFFSET_FIELD_NUMBER:I = 0x6

.field public static final SEGMENTTIMELINE_FIELD_NUMBER:I = 0x4

.field public static final TIMESCALE_FIELD_NUMBER:I = 0x1


# instance fields
.field private bitField0_:I

.field private duration_:I

.field private indexRangeExact_:Z

.field private initialization_:Ljava/lang/String;

.field private media_:Ljava/lang/String;

.field private presentationTimeOffset_:I

.field private segmentTimeline_:Lcom/vdocipher/Manifest$SegmentTimeline;

.field private timescale_:I


# direct methods
.method static bridge synthetic -$$Nest$mclearDuration(Lcom/vdocipher/Manifest$SegmentTemplate;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentTemplate;->clearDuration()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearIndexRangeExact(Lcom/vdocipher/Manifest$SegmentTemplate;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentTemplate;->clearIndexRangeExact()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearInitialization(Lcom/vdocipher/Manifest$SegmentTemplate;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentTemplate;->clearInitialization()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearMedia(Lcom/vdocipher/Manifest$SegmentTemplate;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentTemplate;->clearMedia()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPresentationTimeOffset(Lcom/vdocipher/Manifest$SegmentTemplate;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentTemplate;->clearPresentationTimeOffset()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearSegmentTimeline(Lcom/vdocipher/Manifest$SegmentTemplate;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentTemplate;->clearSegmentTimeline()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearTimescale(Lcom/vdocipher/Manifest$SegmentTemplate;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/Manifest$SegmentTemplate;->clearTimescale()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mmergeSegmentTimeline(Lcom/vdocipher/Manifest$SegmentTemplate;Lcom/vdocipher/Manifest$SegmentTimeline;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->mergeSegmentTimeline(Lcom/vdocipher/Manifest$SegmentTimeline;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDuration(Lcom/vdocipher/Manifest$SegmentTemplate;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->setDuration(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetIndexRangeExact(Lcom/vdocipher/Manifest$SegmentTemplate;Z)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->setIndexRangeExact(Z)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetInitialization(Lcom/vdocipher/Manifest$SegmentTemplate;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->setInitialization(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetInitializationBytes(Lcom/vdocipher/Manifest$SegmentTemplate;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->setInitializationBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMedia(Lcom/vdocipher/Manifest$SegmentTemplate;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->setMedia(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetMediaBytes(Lcom/vdocipher/Manifest$SegmentTemplate;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->setMediaBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPresentationTimeOffset(Lcom/vdocipher/Manifest$SegmentTemplate;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->setPresentationTimeOffset(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetSegmentTimeline(Lcom/vdocipher/Manifest$SegmentTemplate;Lcom/vdocipher/Manifest$SegmentTimeline;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->setSegmentTimeline(Lcom/vdocipher/Manifest$SegmentTimeline;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetTimescale(Lcom/vdocipher/Manifest$SegmentTemplate;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->setTimescale(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 1

    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 3533
    new-instance v0, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-direct {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;-><init>()V

    .line 3536
    sput-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    .line 3537
    const-class v1, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 2867
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 2868
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->media_:Ljava/lang/String;

    .line 2869
    iput-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->initialization_:Ljava/lang/String;

    return-void
.end method

.method private clearDuration()V
    .registers 2

    const/4 v0, 0x0

    .line 3061
    iput v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->duration_:I

    return-void
.end method

.method private clearIndexRangeExact()V
    .registers 2

    const/4 v0, 0x0

    .line 3113
    iput-boolean v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->indexRangeExact_:Z

    return-void
.end method

.method private clearInitialization()V
    .registers 2

    .line 2979
    invoke-static {}, Lcom/vdocipher/Manifest$SegmentTemplate;->getDefaultInstance()Lcom/vdocipher/Manifest$SegmentTemplate;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->getInitialization()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->initialization_:Ljava/lang/String;

    return-void
.end method

.method private clearMedia()V
    .registers 2

    .line 2932
    invoke-static {}, Lcom/vdocipher/Manifest$SegmentTemplate;->getDefaultInstance()Lcom/vdocipher/Manifest$SegmentTemplate;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->getMedia()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->media_:Ljava/lang/String;

    return-void
.end method

.method private clearPresentationTimeOffset()V
    .registers 2

    const/4 v0, 0x0

    .line 3087
    iput v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->presentationTimeOffset_:I

    return-void
.end method

.method private clearSegmentTimeline()V
    .registers 2

    const/4 v0, 0x0

    .line 3034
    iput-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->segmentTimeline_:Lcom/vdocipher/Manifest$SegmentTimeline;

    .line 3035
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->bitField0_:I

    and-int/lit8 v0, v0, -0x2

    iput v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->bitField0_:I

    return-void
.end method

.method private clearTimescale()V
    .registers 2

    const/4 v0, 0x0

    .line 2895
    iput v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->timescale_:I

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 1

    .line 3542
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object v0
.end method

.method private mergeSegmentTimeline(Lcom/vdocipher/Manifest$SegmentTimeline;)V
    .registers 4

    .line 3021
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3022
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->segmentTimeline_:Lcom/vdocipher/Manifest$SegmentTimeline;

    if-eqz v0, :cond_22

    .line 3023
    invoke-static {}, Lcom/vdocipher/Manifest$SegmentTimeline;->getDefaultInstance()Lcom/vdocipher/Manifest$SegmentTimeline;

    move-result-object v1

    if-eq v0, v1, :cond_22

    .line 3024
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->segmentTimeline_:Lcom/vdocipher/Manifest$SegmentTimeline;

    .line 3025
    invoke-static {v0}, Lcom/vdocipher/Manifest$SegmentTimeline;->newBuilder(Lcom/vdocipher/Manifest$SegmentTimeline;)Lcom/vdocipher/Manifest$SegmentTimeline$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;

    invoke-virtual {p1}, Lcom/vdocipher/Manifest$SegmentTimeline$Builder;->buildPartial()Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p1

    check-cast p1, Lcom/vdocipher/Manifest$SegmentTimeline;

    iput-object p1, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->segmentTimeline_:Lcom/vdocipher/Manifest$SegmentTimeline;

    goto :goto_24

    .line 3027
    :cond_22
    iput-object p1, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->segmentTimeline_:Lcom/vdocipher/Manifest$SegmentTimeline;

    .line 3029
    :goto_24
    iget p1, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->bitField0_:I

    return-void
.end method

.method public static newBuilder()Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 1

    .line 3193
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/Manifest$SegmentTemplate;)Lcom/vdocipher/Manifest$SegmentTemplate$Builder;
    .registers 2

    .line 3196
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-virtual {v0, p0}, Lcom/vdocipher/Manifest$SegmentTemplate;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3169
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p0}, Lcom/vdocipher/Manifest$SegmentTemplate;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3176
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3132
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3139
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3181
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3188
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3156
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3163
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3119
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3126
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3144
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/Manifest$SegmentTemplate;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 3151
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/Manifest$SegmentTemplate;",
            ">;"
        }
    .end annotation

    .line 3548
    sget-object v0, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-virtual {v0}, Lcom/vdocipher/Manifest$SegmentTemplate;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setDuration(I)V
    .registers 2

    .line 3054
    iput p1, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->duration_:I

    return-void
.end method

.method private setIndexRangeExact(Z)V
    .registers 2

    .line 3106
    iput-boolean p1, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->indexRangeExact_:Z

    return-void
.end method

.method private setInitialization(Ljava/lang/String;)V
    .registers 2

    .line 2970
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2972
    iput-object p1, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->initialization_:Ljava/lang/String;

    return-void
.end method

.method private setInitializationBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 2987
    invoke-static {p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 2988
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->initialization_:Ljava/lang/String;

    return-void
.end method

.method private setMedia(Ljava/lang/String;)V
    .registers 2

    .line 2923
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2925
    iput-object p1, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->media_:Ljava/lang/String;

    return-void
.end method

.method private setMediaBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 2940
    invoke-static {p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 2941
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->media_:Ljava/lang/String;

    return-void
.end method

.method private setPresentationTimeOffset(I)V
    .registers 2

    .line 3080
    iput p1, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->presentationTimeOffset_:I

    return-void
.end method

.method private setSegmentTimeline(Lcom/vdocipher/Manifest$SegmentTimeline;)V
    .registers 2

    .line 3012
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3013
    iput-object p1, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->segmentTimeline_:Lcom/vdocipher/Manifest$SegmentTimeline;

    .line 3014
    iget p1, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->bitField0_:I

    return-void
.end method

.method private setTimescale(I)V
    .registers 2

    .line 2888
    iput p1, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->timescale_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .line 3477
    sget-object p2, Lcom/vdocipher/Manifest$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_62

    .line 3526
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 3520
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 3505
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/Manifest$SegmentTemplate;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_33

    .line 3507
    const-class p2, Lcom/vdocipher/Manifest$SegmentTemplate;

    monitor-enter p2

    .line 3508
    :try_start_20
    sget-object p1, Lcom/vdocipher/Manifest$SegmentTemplate;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 3510
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 3513
    sput-object p1, Lcom/vdocipher/Manifest$SegmentTemplate;->PARSER:Lcom/google/protobuf/Parser;

    .line 3515
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception v0

    move-object p1, v0

    monitor-exit p2
    :try_end_32
    .catchall {:try_start_20 .. :try_end_32} :catchall_2f

    throw p1

    :cond_33
    return-object p1

    .line 3502
    :pswitch_34  #0x4
    sget-object p1, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    return-object p1

    .line 3485
    :pswitch_37  #0x3
    const-string v0, "bitField0_"

    const-string/jumbo v1, "timescale_"

    const-string v2, "media_"

    const-string v3, "initialization_"

    const-string v4, "segmentTimeline_"

    const-string v5, "duration_"

    const-string v6, "presentationTimeOffset_"

    const-string v7, "indexRangeExact_"

    filled-new-array/range {v0 .. v7}, [Ljava/lang/Object;

    move-result-object p1

    .line 3495
    const-string p2, "\u0000\u0007\u0000\u0001\u0001\u0007\u0007\u0000\u0000\u0000\u0001\u000b\u0002Ȉ\u0003Ȉ\u0004ဉ\u0000\u0005\u000b\u0006\u000b\u0007\u0007"

    .line 3498
    sget-object p3, Lcom/vdocipher/Manifest$SegmentTemplate;->DEFAULT_INSTANCE:Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/Manifest$SegmentTemplate;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 3482
    :pswitch_55  #0x2
    new-instance p1, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/Manifest$SegmentTemplate$Builder;-><init>(Lcom/vdocipher/Manifest-IA;)V

    return-object p1

    .line 3479
    :pswitch_5b  #0x1
    new-instance p1, Lcom/vdocipher/Manifest$SegmentTemplate;

    invoke-direct {p1}, Lcom/vdocipher/Manifest$SegmentTemplate;-><init>()V

    return-object p1

    nop

    :pswitch_data_62
    .packed-switch 0x1
        :pswitch_5b  #00000001
        :pswitch_55  #00000002
        :pswitch_37  #00000003
        :pswitch_34  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getDuration()I
    .registers 2

    .line 3046
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->duration_:I

    return v0
.end method

.method public getIndexRangeExact()Z
    .registers 2

    .line 3098
    iget-boolean v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->indexRangeExact_:Z

    return v0
.end method

.method public getInitialization()Ljava/lang/String;
    .registers 2

    .line 2953
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->initialization_:Ljava/lang/String;

    return-object v0
.end method

.method public getInitializationBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 2962
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->initialization_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getMedia()Ljava/lang/String;
    .registers 2

    .line 2906
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->media_:Ljava/lang/String;

    return-object v0
.end method

.method public getMediaBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 2915
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->media_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getPresentationTimeOffset()I
    .registers 2

    .line 3072
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->presentationTimeOffset_:I

    return v0
.end method

.method public getSegmentTimeline()Lcom/vdocipher/Manifest$SegmentTimeline;
    .registers 2

    .line 3006
    iget-object v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->segmentTimeline_:Lcom/vdocipher/Manifest$SegmentTimeline;

    if-nez v0, :cond_8

    invoke-static {}, Lcom/vdocipher/Manifest$SegmentTimeline;->getDefaultInstance()Lcom/vdocipher/Manifest$SegmentTimeline;

    move-result-object v0

    :cond_8
    return-object v0
.end method

.method public getTimescale()I
    .registers 2

    .line 2880
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->timescale_:I

    return v0
.end method

.method public hasSegmentTimeline()Z
    .registers 3

    .line 2999
    iget v0, p0, Lcom/vdocipher/Manifest$SegmentTemplate;->bitField0_:I

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-eqz v0, :cond_7

    return v1

    :cond_7
    const/4 v0, 0x0

    return v0
.end method
