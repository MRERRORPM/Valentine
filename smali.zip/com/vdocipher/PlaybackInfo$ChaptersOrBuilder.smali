# classes14.dex

.class public interface abstract Lcom/vdocipher/PlaybackInfo$ChaptersOrBuilder;
.super Ljava/lang/Object;
.source "PlaybackInfo.java"

# interfaces
.implements Lcom/google/protobuf/MessageLiteOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "ChaptersOrBuilder"
.end annotation


# virtual methods
.method public abstract getId()Lcom/google/protobuf/ByteString;
.end method

.method public abstract getStartTime()I
.end method

.method public abstract getTitle()Ljava/lang/String;
.end method

.method public abstract getTitleBytes()Lcom/google/protobuf/ByteString;
.end method
