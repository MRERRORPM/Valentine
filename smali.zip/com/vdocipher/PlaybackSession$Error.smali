# classes14.dex

.class public final Lcom/vdocipher/PlaybackSession$Error;
.super Lcom/google/protobuf/GeneratedMessageLite;
.source "PlaybackSession.java"

# interfaces
.implements Lcom/vdocipher/PlaybackSession$ErrorOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vdocipher/PlaybackSession;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Error"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vdocipher/PlaybackSession$Error$Builder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/GeneratedMessageLite<",
        "Lcom/vdocipher/PlaybackSession$Error;",
        "Lcom/vdocipher/PlaybackSession$Error$Builder;",
        ">;",
        "Lcom/vdocipher/PlaybackSession$ErrorOrBuilder;"
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

.field public static final DISPLAYMSG_FIELD_NUMBER:I = 0x4

.field public static final INTERNALCODE_FIELD_NUMBER:I = 0x1

.field private static volatile PARSER:Lcom/google/protobuf/Parser; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Error;",
            ">;"
        }
    .end annotation
.end field

.field public static final PAYLOAD_FIELD_NUMBER:I = 0x3

.field public static final VDO_FIELD_NUMBER:I = 0x2


# instance fields
.field private displayMsg_:Ljava/lang/String;

.field private internalCode_:I

.field private payload_:Ljava/lang/String;

.field private vdo_:I


# direct methods
.method static bridge synthetic -$$Nest$mclearDisplayMsg(Lcom/vdocipher/PlaybackSession$Error;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Error;->clearDisplayMsg()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearInternalCode(Lcom/vdocipher/PlaybackSession$Error;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Error;->clearInternalCode()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearPayload(Lcom/vdocipher/PlaybackSession$Error;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Error;->clearPayload()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclearVdo(Lcom/vdocipher/PlaybackSession$Error;)V
    .registers 1

    invoke-direct {p0}, Lcom/vdocipher/PlaybackSession$Error;->clearVdo()V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDisplayMsg(Lcom/vdocipher/PlaybackSession$Error;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Error;->setDisplayMsg(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetDisplayMsgBytes(Lcom/vdocipher/PlaybackSession$Error;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Error;->setDisplayMsgBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetInternalCode(Lcom/vdocipher/PlaybackSession$Error;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Error;->setInternalCode(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPayload(Lcom/vdocipher/PlaybackSession$Error;Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Error;->setPayload(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetPayloadBytes(Lcom/vdocipher/PlaybackSession$Error;Lcom/google/protobuf/ByteString;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Error;->setPayloadBytes(Lcom/google/protobuf/ByteString;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$msetVdo(Lcom/vdocipher/PlaybackSession$Error;I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/vdocipher/PlaybackSession$Error;->setVdo(I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetDEFAULT_INSTANCE()Lcom/vdocipher/PlaybackSession$Error;
    .registers 1

    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 9038
    new-instance v0, Lcom/vdocipher/PlaybackSession$Error;

    invoke-direct {v0}, Lcom/vdocipher/PlaybackSession$Error;-><init>()V

    .line 9041
    sput-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    .line 9042
    const-class v1, Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageLite;->registerDefaultInstance(Ljava/lang/Class;Lcom/google/protobuf/GeneratedMessageLite;)V

    return-void
.end method

.method private constructor <init>()V
    .registers 2

    .line 8578
    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V

    .line 8579
    const-string v0, ""

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Error;->payload_:Ljava/lang/String;

    .line 8580
    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Error;->displayMsg_:Ljava/lang/String;

    return-void
.end method

.method private clearDisplayMsg()V
    .registers 2

    .line 8715
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Error;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Error;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Error;->getDisplayMsg()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Error;->displayMsg_:Ljava/lang/String;

    return-void
.end method

.method private clearInternalCode()V
    .registers 2

    const/4 v0, 0x0

    .line 8605
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Error;->internalCode_:I

    return-void
.end method

.method private clearPayload()V
    .registers 2

    .line 8668
    invoke-static {}, Lcom/vdocipher/PlaybackSession$Error;->getDefaultInstance()Lcom/vdocipher/PlaybackSession$Error;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Error;->getPayload()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vdocipher/PlaybackSession$Error;->payload_:Ljava/lang/String;

    return-void
.end method

.method private clearVdo()V
    .registers 2

    const/4 v0, 0x0

    .line 8631
    iput v0, p0, Lcom/vdocipher/PlaybackSession$Error;->vdo_:I

    return-void
.end method

.method public static getDefaultInstance()Lcom/vdocipher/PlaybackSession$Error;
    .registers 1

    .line 9047
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    return-object v0
.end method

.method public static newBuilder()Lcom/vdocipher/PlaybackSession$Error$Builder;
    .registers 1

    .line 8805
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Error;->createBuilder()Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object v0

    check-cast v0, Lcom/vdocipher/PlaybackSession$Error$Builder;

    return-object v0
.end method

.method public static newBuilder(Lcom/vdocipher/PlaybackSession$Error;)Lcom/vdocipher/PlaybackSession$Error$Builder;
    .registers 2

    .line 8808
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-virtual {v0, p0}, Lcom/vdocipher/PlaybackSession$Error;->createBuilder(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Error$Builder;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Error;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8781
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p0}, Lcom/vdocipher/PlaybackSession$Error;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Error;

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Error;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8788
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p0, p1}, Lcom/vdocipher/PlaybackSession$Error;->parseDelimitedFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Error;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/vdocipher/PlaybackSession$Error;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8744
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Error;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Error;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8751
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Error;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/vdocipher/PlaybackSession$Error;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8793
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Error;

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Error;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8800
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Error;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/vdocipher/PlaybackSession$Error;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8768
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Error;

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Error;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 8775
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Error;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/vdocipher/PlaybackSession$Error;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8731
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Error;

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Error;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8738
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Error;

    return-object p0
.end method

.method public static parseFrom([B)Lcom/vdocipher/PlaybackSession$Error;
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8756
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[B)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Error;

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/vdocipher/PlaybackSession$Error;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    .line 8763
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageLite;->parseFrom(Lcom/google/protobuf/GeneratedMessageLite;[BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/GeneratedMessageLite;

    move-result-object p0

    check-cast p0, Lcom/vdocipher/PlaybackSession$Error;

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/vdocipher/PlaybackSession$Error;",
            ">;"
        }
    .end annotation

    .line 9053
    sget-object v0, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-virtual {v0}, Lcom/vdocipher/PlaybackSession$Error;->getParserForType()Lcom/google/protobuf/Parser;

    move-result-object v0

    return-object v0
.end method

.method private setDisplayMsg(Ljava/lang/String;)V
    .registers 2

    .line 8706
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8708
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Error;->displayMsg_:Ljava/lang/String;

    return-void
.end method

.method private setDisplayMsgBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 8723
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Error;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 8724
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Error;->displayMsg_:Ljava/lang/String;

    return-void
.end method

.method private setInternalCode(I)V
    .registers 2

    .line 8598
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Error;->internalCode_:I

    return-void
.end method

.method private setPayload(Ljava/lang/String;)V
    .registers 2

    .line 8659
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8661
    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Error;->payload_:Ljava/lang/String;

    return-void
.end method

.method private setPayloadBytes(Lcom/google/protobuf/ByteString;)V
    .registers 2

    .line 8676
    invoke-static {p1}, Lcom/vdocipher/PlaybackSession$Error;->checkByteStringIsUtf8(Lcom/google/protobuf/ByteString;)V

    .line 8677
    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/vdocipher/PlaybackSession$Error;->payload_:Ljava/lang/String;

    return-void
.end method

.method private setVdo(I)V
    .registers 2

    .line 8624
    iput p1, p0, Lcom/vdocipher/PlaybackSession$Error;->vdo_:I

    return-void
.end method


# virtual methods
.method protected final dynamicMethod(Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 8986
    sget-object p2, Lcom/vdocipher/PlaybackSession$1;->$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke:[I

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageLite$MethodToInvoke;->ordinal()I

    move-result p1

    aget p1, p2, p1

    const/4 p2, 0x0

    packed-switch p1, :pswitch_data_58

    .line 9031
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1

    :pswitch_12  #0x7
    return-object p2

    :pswitch_13  #0x6
    const/4 p1, 0x1

    .line 9025
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    return-object p1

    .line 9010
    :pswitch_19  #0x5
    sget-object p1, Lcom/vdocipher/PlaybackSession$Error;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_32

    .line 9012
    const-class p2, Lcom/vdocipher/PlaybackSession$Error;

    monitor-enter p2

    .line 9013
    :try_start_20
    sget-object p1, Lcom/vdocipher/PlaybackSession$Error;->PARSER:Lcom/google/protobuf/Parser;

    if-nez p1, :cond_2d

    .line 9015
    new-instance p1, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;

    sget-object p3, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-direct {p1, p3}, Lcom/google/protobuf/GeneratedMessageLite$DefaultInstanceBasedParser;-><init>(Lcom/google/protobuf/GeneratedMessageLite;)V

    .line 9018
    sput-object p1, Lcom/vdocipher/PlaybackSession$Error;->PARSER:Lcom/google/protobuf/Parser;

    .line 9020
    :cond_2d
    monitor-exit p2

    return-object p1

    :catchall_2f
    move-exception p1

    monitor-exit p2
    :try_end_31
    .catchall {:try_start_20 .. :try_end_31} :catchall_2f

    throw p1

    :cond_32
    return-object p1

    .line 9007
    :pswitch_33  #0x4
    sget-object p1, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    return-object p1

    .line 8994
    :pswitch_36  #0x3
    const-string p1, "internalCode_"

    const-string/jumbo p2, "vdo_"

    const-string p3, "payload_"

    const-string v0, "displayMsg_"

    filled-new-array {p1, p2, p3, v0}, [Ljava/lang/Object;

    move-result-object p1

    .line 9000
    const-string p2, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u000b\u0002\u000b\u0003Ȉ\u0004Ȉ"

    .line 9003
    sget-object p3, Lcom/vdocipher/PlaybackSession$Error;->DEFAULT_INSTANCE:Lcom/vdocipher/PlaybackSession$Error;

    invoke-static {p3, p2, p1}, Lcom/vdocipher/PlaybackSession$Error;->newMessageInfo(Lcom/google/protobuf/MessageLite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    .line 8991
    :pswitch_4c  #0x2
    new-instance p1, Lcom/vdocipher/PlaybackSession$Error$Builder;

    invoke-direct {p1, p2}, Lcom/vdocipher/PlaybackSession$Error$Builder;-><init>(Lcom/vdocipher/PlaybackSession-IA;)V

    return-object p1

    .line 8988
    :pswitch_52  #0x1
    new-instance p1, Lcom/vdocipher/PlaybackSession$Error;

    invoke-direct {p1}, Lcom/vdocipher/PlaybackSession$Error;-><init>()V

    return-object p1

    :pswitch_data_58
    .packed-switch 0x1
        :pswitch_52  #00000001
        :pswitch_4c  #00000002
        :pswitch_36  #00000003
        :pswitch_33  #00000004
        :pswitch_19  #00000005
        :pswitch_13  #00000006
        :pswitch_12  #00000007
    .end packed-switch
.end method

.method public getDisplayMsg()Ljava/lang/String;
    .registers 2

    .line 8689
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error;->displayMsg_:Ljava/lang/String;

    return-object v0
.end method

.method public getDisplayMsgBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8698
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error;->displayMsg_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getInternalCode()I
    .registers 2

    .line 8590
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Error;->internalCode_:I

    return v0
.end method

.method public getPayload()Ljava/lang/String;
    .registers 2

    .line 8642
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error;->payload_:Ljava/lang/String;

    return-object v0
.end method

.method public getPayloadBytes()Lcom/google/protobuf/ByteString;
    .registers 2

    .line 8651
    iget-object v0, p0, Lcom/vdocipher/PlaybackSession$Error;->payload_:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    return-object v0
.end method

.method public getVdo()I
    .registers 2

    .line 8616
    iget v0, p0, Lcom/vdocipher/PlaybackSession$Error;->vdo_:I

    return v0
.end method
